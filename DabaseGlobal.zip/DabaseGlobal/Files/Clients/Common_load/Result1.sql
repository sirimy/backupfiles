-- CREATE TABLE ds_ace_output_tbl_first
-- AS
-- SELECT
--   *
-- FROM ds_ace_output_tbl;


select count(*) from ds_ace_output_tbl_first;--328
select count(*) from  ACE_LOAD_HOLD_TBL;--328

select count(*) from COMMON_LOAD_HOLD_TBL;--328
select count(*) from ADDRESS_OUTPUT_TBL;
select count(*) from ds_ace_output_tbl;--328
select count(*) from SI_OUTPUT_TBL;
select count(*) from CUSTOMER_OUTPUT_TBL;

select count(*) from visitor_dim;--278
select count(*) from visitor_lkp;--0
select count(*) from visitor_history_tbl;--285
select count(*) from  address_dim;--277
select count(*) from  address_lkp;--76
select count(*) from  visitor_address_xref;--325
select count(*) from  visitor_address_lkp;--77
select count(*) from  serialized_item_dim;--328
select count(*) from  serialized_item_lkp;--0
select count(*) from  visitor_ownership_xref;--336
select count(*) from  email_lkp;--0
select count(*) from  email_dim;--277
select count(*) from  visitor_email_xref;--277
select count(*) from  visitor_email_lkp;--1
select count(*) from  phone_dim;--277
select count(*) from  phone_lkp;--0
select count(*) from  visitor_phone_xref;--277
select count(*) from  visitor_phone_lkp;--0
select count(*) from  VISITOR_PREFERENCE_TBL;--831
select count(*) from  purl_dim;--0
select count(*) from  VISITOR_PURL_XREF;--0
select count(*) from  CUSTOMER_DIM;--277
select count(*) from  HOUSEHOLD_LKP;--0
select count(*) from  CUSTOMER_LKP;--0

select substr(ACE_ERROR_CD,1,1),count(*) from  address_dim group by substr(ACE_ERROR_CD,1,1);
+------------------------+--------+
|SUBSTR(ACE_ERROR_CD,1,1)|COUNT(*)|
+------------------------+--------+
|E                       |234     |
|S                       |43      |
+------------------------+--------+
select substr(ACE_ERROR_CD,1,1),count(*) from ds_ace_output_tbl group by substr(ACE_ERROR_CD,1,1);
+------------------------+--------+
|SUBSTR(ACE_ERROR_CD,1,1)|COUNT(*)|
+------------------------+--------+
|E                       |258     |
|S                       |70      |
+------------------------+--------+
