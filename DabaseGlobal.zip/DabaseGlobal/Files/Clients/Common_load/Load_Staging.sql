-- 'load/load_visitor_dim',
-- 'load/load_visitor_lkp',
-- 'load/load_customer_lkp',
-- 'load/load_household_lkp',
-- 'load/load_visitor_history_tbl',
-- 'load/load_address_dim',
-- 'load/load_address_lkp',
-- 'load/load_visitor_address_xref',
-- 'load/load_visitor_address_lkp',
'load/load_serialized_item_dim',
'load/load_serialized_item_lkp',
'load/load_visitor_ownership_xref',
'load/load_email_lkp',
'load/load_email_dim',
'load/load_visitor_email_xref',
'load/load_visitor_email_lkp',
'load/load_phone_dim',
'load/load_phone_lkp',
'load/load_visitor_phone_xref',
'load/load_visitor_phone_lkp',
'load/load_visitor_preference_tbl',
'load/load_purl_dim',
-- 'load/load_customer_dim',

-- ##########################################################################################
-- [1]-- 'load/load_visitor_dim',
-- ##########################################################################################

-- ##Pull all the visitors from core where old customer key has been changed to new customer key
		
		INSERT INTO VISITOR_DIM(visitor_key, customer_key, household_key,visitor_type_cd,dim_status_cd,insert_audit_key)

                SELECT DISTINCT CORE.visitor_key,WAS_IS.NEW_CUSTOMER_KEY as customer_key,WAS_IS.NEW_HH_KEY,CORE.visitor_type_cd,
                       CORE.dim_status_cd,CORE.insert_audit_key
                       FROM P_VISITOR_DIM CORE,
                            (  
				 select DISTINCT OLD_CUSTOMER_KEY,MIN(NEW_CUSTOMER_KEY) AS NEW_CUSTOMER_KEY,MIN(NEW_HH_KEY) AS NEW_HH_KEY 
                            		from (
						SELECT          T1.CUSTOMER_KEY AS OLD_CUSTOMER_KEY,
                                        			MIN(T1.CUSTOMER_KEY) OVER(PARTITION BY t1.customer_group_no) AS NEW_CUSTOMER_KEY,
								MIN(T1.HOUSEHOLD_KEY) OVER(PARTITION BY t1.customer_group_no) AS NEW_HH_KEY
                                			FROM 	CUSTOMER_GROUP_RAW_TBL T1,
                                        			(
								select customer_group_no, 
								count(distinct customer_key) from customer_group_raw_tbl 
								group by customer_group_no 
								having count(distinct customer_key) > 1
								) T2
							WHERE T1.customer_group_no=t2.customer_group_no
					     )
					where OLD_CUSTOMER_KEY<>NEW_CUSTOMER_KEY
					group by old_customer_key
                            )WAS_IS
                        WHERE CORE.CUSTOMER_KEY=WAS_IS.OLD_CUSTOMER_KEY
                        AND not exists
                                (
                                        SELECT 1 FROM VISITOR_DIM STG WHERE CORE.VISITOR_KEY=STG.VISITOR_KEY
                                );
-- 				,
-- 		COMMIT,

-- 	       ##Log the change details in was_is_log_tbl

		INSERT INTO WAS_IS_LOG_TBL(VISITOR_KEY,OLD_KEY,NEW_KEY,INSERT_DATE,INSERT_AUDIT_KEY)
		
		  SELECT DISTINCT t1.VISITOR_KEY,t2.CUSTOMER_KEY AS OLD_KEY,t1.CUSTOMER_KEY AS NEW_KEY,sysdate as INSERT_DATE,
				  MAX(t1.INSERT_AUDIT_KEY) OVER(PARTITION BY T1.CUSTOMER_KEY) AS INSERT_AUDIT_KEY
				FROM VISITOR_DIM T1,P_VISITOR_DIM T2 
				WHERE T1.VISITOR_KEY=T2.VISITOR_KEY AND T1.CUSTOMER_KEY<>T2.CUSTOMER_KEY;
-- 		COMMIT

-- ##########################################################################################
-- [2]-- 'load/load_visitor_lkp',
-- ##########################################################################################
INSERT /*+ append */
       INTO   visitor_lkp (visitor_key,visitor_xid,source_system_cd,EXT_ID_TYPE_CD,insert_audit_key)
       SELECT  DISTINCT
              clot.visitor_key,
              TRIM(cl.VISITOR_XID),
              cl.source_system_cd,
              1, --Always 1 since this is the created by external system
              MAX(cl.insert_audit_key) OVER (PARTITION BY TRIM(cl.VISITOR_XID),cl.source_system_cd )
       FROM   common_load_output_tbl clot
       JOIN   common_load_tbl cl
       USING  (unique_seq_no)
       WHERE  TRIM(cl.VISITOR_XID) IS NOT NULL AND NOT EXISTS
               (       SELECT 1
                       FROM v_visitor_lkp vlkp
                       WHERE TRIM(cl.VISITOR_XID)=vlkp.visitor_xid
                       AND cl.source_system_cd=vlkp.source_system_cd
                );
-- ##########################################################################################
-- [3]-- 'load/load_customer_lkp',
-- ##########################################################################################
 INSERT /*+ append */
       INTO   customer_lkp (customer_key,customer_xid,source_system_cd,EXT_ID_TYPE_CD,insert_audit_key)
       SELECT DISTINCT
              clot.posted_customer_key,
              TRIM (cl.customer_xid),
              cl.source_system_cd,
              1,                --Always 1 since this is the created by external system
              MAX (cl.insert_audit_key)
                 OVER (PARTITION BY TRIM (cl.customer_xid), cl.source_system_cd)
         FROM customer_output_tbl clot JOIN common_load_tbl cl USING (unique_seq_no)
        WHERE     TRIM (cl.customer_xid) IS NOT NULL
              AND NOT EXISTS
                         (SELECT 1
                            FROM v_customer_lkp vlkp
                           WHERE     TRIM (cl.customer_xid) = vlkp.customer_xid
                                 AND cl.source_system_cd = vlkp.source_system_cd);
       INSERT /*+ append */
              INTO  customer_lkp (customer_key,
                                  customer_xid,
                                  source_system_cd,
                                  ext_id_type_cd,
                                  insert_audit_key)
           SELECT DISTINCT
                  clot.posted_customer_key,
                  TRIM (cl.customer_unique_id),
                  0 source_system_cd,
                  2,
                  MIN (cl.insert_audit_key)
                     OVER (PARTITION BY TRIM (cl.customer_unique_id))
             FROM customer_output_tbl clot
                  JOIN common_load_tbl cl USING (unique_seq_no)
            WHERE     TRIM (cl.customer_unique_id) IS NOT NULL
                  AND NOT EXISTS
                             (SELECT 1
                                FROM v_customer_lkp vlkp
                               WHERE     TRIM (cl.customer_unique_id) = vlkp.customer_xid
                                     AND 0 = vlkp.source_system_cd);

	INSERT /*+ append */
       INTO   customer_lkp (customer_key,customer_xid,source_system_cd,EXT_ID_TYPE_CD,insert_audit_key)
       SELECT DISTINCT
              clot.posted_customer_key,
              clot.posted_customer_key,
              cl.source_system_cd,
              2,                --Always 2 since we use dw customer key as customer id on web
              MAX (cl.insert_audit_key)
                 OVER (PARTITION BY  clot.posted_customer_key, cl.source_system_cd)
         FROM customer_output_tbl clot JOIN common_load_tbl cl USING (unique_seq_no)
        WHERE     clot.posted_customer_key IS NOT NULL
              AND NOT EXISTS
                         (SELECT 1
                            FROM v_customer_lkp vlkp
                           WHERE      to_char(clot.posted_customer_key) = vlkp.customer_xid
                                 AND cl.source_system_cd = vlkp.source_system_cd);
-- ##########################################################################################
-- [4]-- 'load/load_household_lkp'
-- ##########################################################################################
INSERT /*+ append */
               INTO   household_lkp (household_key,household_xid,source_system_cd,EXT_ID_TYPE_CD,insert_audit_key)
               SELECT DISTINCT
                      clot.posted_household_key,
                      TRIM (cl.household_xid),
                      cl.source_system_cd,
                      1,                --Always 1 since this is the created by external system
                      MAX (cl.insert_audit_key)
                         OVER (PARTITION BY TRIM (cl.household_xid), cl.source_system_cd)
                 FROM customer_output_tbl clot JOIN common_load_tbl cl USING (unique_seq_no)
                WHERE     TRIM (cl.household_xid) IS NOT NULL
                      AND NOT EXISTS
                                 (SELECT 1
                                    FROM v_household_lkp vlkp
                                   WHERE     TRIM (cl.household_xid) = vlkp.household_xid
                                         AND cl.source_system_cd = vlkp.source_system_cd);
       INSERT /*+ append */
                      INTO  household_lkp (household_key,household_xid,source_system_cd,EXT_ID_TYPE_CD,insert_audit_key)
                   SELECT DISTINCT
                          clot.posted_household_key,
                          TRIM (cl.household_unique_id),
                          0 source_system_cd,
                          2,
                          MIN (cl.insert_audit_key)
                             OVER (PARTITION BY TRIM (cl.household_unique_id))
                     FROM customer_output_tbl clot
                          JOIN common_load_tbl cl USING (unique_seq_no)
                    WHERE     TRIM (cl.household_unique_id) IS NOT NULL
                          AND NOT EXISTS
                                     (SELECT 1
                                        FROM v_household_lkp vlkp
                                       WHERE     TRIM (cl.household_unique_id) = vlkp.household_xid
                                             AND 0 = vlkp.source_system_cd);
-- ##########################################################################################
-- [5]-- 'load/load_visitor_history_tbl'
-- ##########################################################################################
INSERT	/*+ append */
			INTO		visitor_history_tbl (visitor_key, customer_key, household_key, eff_dt_key,insert_audit_key)
			SELECT	DISTINCT
							clot.visitor_key,
							cot.posted_customer_key customer_key,
							cot.posted_household_key household_key,
							clot.effective_dt_key,
		          MAX(cl.insert_audit_key) OVER (PARTITION BY clot.visitor_key,cot.posted_customer_key,cot.posted_household_key,clot.effective_dt_key)
			FROM		common_load_output_tbl clot
			JOIN		common_load_tbl cl
			ON		  (clot.unique_seq_no = cl.unique_seq_no)
			JOIN		customer_output_tbl cot
			ON			(clot.unique_seq_no = cot.unique_seq_no)
			and clot.visitor_key is not null
-- ##########################################################################################
-- [6]-- 'load/load_address_dim',
-- ##########################################################################################
INSERT	/*+ append */
      INTO		address_dim (
              address_key,
              firm_nm,
              first_nm,
              middle_nm,
              last_nm,
              address_line1_tx,
              address_line2_tx,
              city_nm,
              state_cd,
              zip_code5_tx,
              zip_code4_tx,
              ace_error_cd,
              dim_status_cd,
              eff_dt_key,
              commercial_ind,
              primary_street_nm,
              primary_street_no,
              unit_no,
              rr_box_no,
              rr_route_no,
              po_box_no,
              dpv_status_cd,
              country_cd,
              status_cd,
              foreign_address_ind,
              assignment_type,
              actual_assignment_level,
              insert_audit_key,
              suppression_cd)
			SELECT	address_key,
							firm_nm,
							first_nm,
							middle_nm,
							last_nm,
							address_line1_tx,
							address_line2_tx,
							city_nm,
							state_cd,
							zip5,
							zip4,
							ace_error_stat,
							'A',
							effective_dt_key,
							NVL2 (firm_nm, 'Y', 'N'),
							primary_street_nm,
							primary_street_no,
							unit_no,
							rr_box_no,
							rr_route_no,
							po_box_no,
							dpv_status_cd,
							country_cd,
							status_cd,
							foreign_address_ind,
							assignment_type,
							actual_assignment_level,
							insert_audit_key,
							DECODE(mail_pref_ind,'N','Y','N')
			FROM (SELECT	aot.address_key,
										aot.firm_nm,
										aot.first_nm,
										aot.middle_nm,
										aot.last_nm,
										aot.address_line1_tx,
										aot.address_line2_tx,
										aot.city_nm,
										aot.state_cd,
										aot.zip_code5_tx zip5,
										aot.zip_code4_tx zip4,
										daot.ace_error_cd ace_error_stat,
										clot.effective_dt_key,
										daot.primary_street_nm,
										daot.primary_street_no,
										daot.unit_no,
										daot.rural_route_box_no rr_box_no,
										daot.rural_route_no rr_route_no,
										daot.postal_box_no po_box_no,
										daot.dpv_status_cd,
										NVL(daot.country_cd,upper(trim(cl.country_cd))) as country_cd,
										daot.status_cd,
										daot.foreign_address_ind,
										daot.assignment_type,
										daot.actual_assignment_level,
										cl.insert_audit_key,
										NVL(cl.mail_pref_ind,'Y') as mail_pref_ind,
										ROW_NUMBER () OVER (PARTITION BY aot.address_key ORDER BY clot.effective_dt_key DESC) rn
						FROM		common_load_output_tbl clot
						JOIN		common_load_tbl cl
						ON		(clot.unique_seq_no = cl.unique_seq_no)	
						JOIN		ds_ace_output_tbl daot
						ON			(clot.unique_seq_no = daot.unique_seq_no)
						JOIN		address_output_tbl aot
						ON			(clot.unique_seq_no = aot.unique_seq_no)
						)
			WHERE rn = 1
-- ##########################################################################################
-- [7]-- 'load/load_address_lkp',
-- ##########################################################################################
	INSERT	/*+ append */
      INTO		address_lkp	(address_key,
              address_xid,
              source_system_cd,
              ext_id_type_cd,
              insert_audit_key)
      SELECT	DISTINCT aot.address_key,
              NVL(cl.address_unique_id,aot.address_hash_key),
              0,
              2,
              MAX(cl.insert_audit_key) OVER (PARTITION BY NVL(cl.address_unique_id,aot.address_hash_key),0)
			FROM		address_output_tbl aot 
			JOIN		common_load_tbl cl
			ON			(aot.unique_seq_no = cl.unique_seq_no)
			WHERE		NOT EXISTS
							(	SELECT 1
								FROM v_address_lkp vlkp
								WHERE NVL(cl.address_unique_id,aot.address_hash_key)=vlkp.address_xid
								AND vlkp.source_system_cd=0);

          INSERT  /*+ append */
            INTO   address_lkp     (address_key,
                                    address_xid,
                                   source_system_cd,
                                  ext_id_type_cd,
                                  insert_audit_key)
                        SELECT  DISTINCT aot.address_key,
                                         cl.address_xid,
                                         cl.source_system_cd,
                                         1,
                                         MAX(cl.insert_audit_key) OVER (PARTITION BY address_xid,source_system_cd)
                        FROM            address_output_tbl aot
                        JOIN            common_load_tbl cl
                        ON              (aot.unique_seq_no = cl.unique_seq_no)
                        WHERE      cl.address_xid IS NOT NULL AND  aot.address_key is not null and 
			NOT EXISTS
                                                        (       SELECT 1
                                                                FROM v_address_lkp vlkp
                                                                WHERE cl.address_xid=vlkp.address_xid
                                                                AND  cl.source_system_cd = vlkp.source_system_cd);

-- 		 "-- Create an external if for fcrm_web for any new address that came in through different source
                        -- previously done through p_populate_lkp_tbls
			INSERT  /*+ append */
                        INTO            address_lkp
                                                        (address_key,
                                                        address_xid,
                                                        EXT_ID_TYPE_CD,
                                                        source_system_cd,
                                                        insert_audit_key)
                        SELECT 
                                                        address_key,
                                                        ADDRESS_SEQ.nextval as address_xid,
                                                        1 as EXT_ID_TYPE_CD,
                                                        2 as source_system_cd, --as of now we only create exter id for fcrm_web
                                                        insert_audit_key
                                                        FROM (
								                                            SELECT DISTINCT  ADDRESS_KEY ,
                                                            MIN(INSERT_AUDIT_KEY) OVER (PARTITION BY ADDRESS_KEY) AS insert_audit_key
                                                        		FROM  address_lkp alkp
                                                        		where NOT EXISTS
                                                                			(
                                                                       	 			SELECT 1 from v_address_lkp valkp 
												                                                      where
                                                                              alkp.address_key=valkp.address_key and valkp.source_system_cd=2
                                                                			)
								);
-- ##########################################################################################
-- [8]-- 'load/load_address_lkp',
-- ##########################################################################################
--   ##This query would dedupe the staging data and populate the visitor_address_xref
--     ## Inserts records only when one essential field is populated

    	INSERT	/*+ append */
      INTO  visitor_address_xref (visitor_key, address_key,role_key, eff_dt_key,end_dt_key,primary_ind,insert_audit_key)
      SELECT visitor_key, address_key,role_key, eff_dt_key,end_dt_key,primary_ind,insert_audit_key from
      (
       SELECT	 
        clot.visitor_key,
        aot.address_key,
        NVL(clot.address_role_key,(SELECT MIN(role_key) from p_role_dim where UPPER(ROLE_TYPE)='ADDRESS')) as role_key,
        clot.effective_dt_key as eff_dt_key,
        '99999' as end_dt_key,
        NVL(UPPER(cl.PRIMARY_ADDRESS_IND),'Y') as primary_ind,
        cl.insert_audit_key,
       ROW_NUMBER() OVER(PARTITION BY clot.visitor_key,aot.address_key, 
                                      NVL(clot.address_role_key,(SELECT MIN(role_key) from p_role_dim where UPPER(ROLE_TYPE)='ADDRESS')) 
                                      ORDER BY purchase_dt_key desc nulls last,clot.effective_dt_key desc,NVL(UPPER(cl.PRIMARY_ADDRESS_IND),'Y') desc )rn
      FROM  common_load_output_tbl clot
      JOIN  common_load_tbl cl
      ON    (clot.unique_seq_no = cl.unique_seq_no) 
      JOIN address_output_tbl aot 
      ON    (clot.unique_seq_no = aot.unique_seq_no)
      where ADDRESS_HASH_KEY<>'d41d8cd98f00b204e9800998ecf8427e'
      )
      where rn=1 and visitor_key is not null 
      ;
		


  --  ##This query would bring the core primary indicators to staging to calculate its rank and updates the eff dt with latest

	MERGE INTO visitor_address_xref vax
		 USING
		 (SELECT VISITOR_KEY,ADDRESS_KEY,ROLE_KEY,EFF_DT_KEY,END_DT_KEY,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY,PRIMARY_IND 
		   FROM p_visitor_address_xref core
		   where primary_ind='Y' and exists(
						select 1 from visitor_address_xref stg where stg.visitor_key=core.visitor_key
						    )
			
		 )vrx
		 ON(vax.VISITOR_KEY=vrx.VISITOR_KEY and vax.ADDRESS_KEY=vrx.ADDRESS_KEY)
		 WHEN MATCHED THEN UPDATE
		 set vax.EFF_DT_KEY=GREATEST(vrx.EFF_DT_KEY,vax.EFF_DT_KEY)
		WHEN NOT MATCHED THEN 
		INSERT(VISITOR_KEY,ADDRESS_KEY,ROLE_KEY,EFF_DT_KEY,END_DT_KEY,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY,PRIMARY_IND)
		VALUES(vrx.VISITOR_KEY,vrx.ADDRESS_KEY,vrx.role_key,vrx.EFF_DT_KEY,vrx.END_DT_KEY,vrx.INSERT_AUDIT_KEY,vrx.UPDATE_AUDIT_KEY,vrx.PRIMARY_IND);

		--"COMMIT;
		
		--##This query updates primary indicator with latest purchase dt and latest effective date


 		MERGE INTO visitor_address_xref vax
		 USING
		 (SELECT visitor_key, address_key,
			CASE WHEN rank=1 THEN '99999' ELSE ( select TO_CHAR(MAX(date_key)) from fas.date_dim where full_dt=trunc(sysdate)) END AS end_dt_key,
			CASE WHEN rank=1 THEN 'Y' ELSE 'N' END AS primary_ind FROM
			(
				SELECT visitor_key,t1.address_key,
                                DENSE_RANK() OVER 
				(PARTITION BY visitor_key ORDER BY DECODE( COUNTRY_CD,'USA',DECODE(SUBSTR(ACE_ERROR_CD,1,1),'E','2','1'),'1'),
                                                   t1.eff_dt_key desc,t1.address_key desc) as rank
                                FROM visitor_address_xref t1 left join
                                     v_address_dim t2--to find valid address as primary
                                ON (t1.address_key=t2.address_key) where  primary_ind='Y'
			)
		 )vrx
		ON(vax.visitor_key=vrx.visitor_key and vax.address_key=vrx.address_key)
		WHEN MATCHED THEN UPDATE SET
		vax.primary_ind=vrx.primary_ind,
		vax.end_dt_key=vrx.end_dt_key;
-- ##########################################################################################
-- [9]-- ''load/load_visitor_address_lkp',
-- ##########################################################################################
--step1:
                --Load  address_xid  and its primary indicators  for all visitors where address_xid is populated
                INSERT /*+ append */
                INTO            visitor_address_lkp (visitor_key,address_key,address_xid,source_system_cd,active_ind,primary_ind,insert_audit_key)
                select visitor_key,address_key,address_xid,source_system_cd,active_ind,primary_ind,insert_audit_key from
                 (
                     SELECT DISTINCT
                            clot.visitor_key,
                            aot.address_key,
                            NVL(plkp.address_XID,trim(cl.address_xid)) as address_xid,
                            NVL(plkp.source_system_cd,cl.source_system_cd) as source_system_cd,
                            'Y' as active_ind, --Intially it is assumed that all records are active
                            NVL(UPPER(primary_address_ind),'Y') as primary_ind,
                            cl.insert_audit_key,
                            row_number() OVER(partition by NVL(plkp.address_XID,trim(cl.address_xid)),
					            		  NVL(plkp.source_system_cd,cl.source_system_cd)
                     ORDER BY purchase_dt_key desc nulls last,clot.effective_dt_key desc) as rno
                     FROM     common_load_output_tbl clot
                     JOIN     common_load_tbl cl
                     ON       (clot.unique_seq_no = cl.unique_seq_no)
                     JOIN  	  address_output_tbl aot
                     ON	(cl.unique_seq_no=aot.unique_seq_no)
                     LEFT JOIN  (SELECT address_KEY,address_XID,source_system_cd FROM address_lkp where  SOURCE_SYSTEM_CD<>0) plkp
                     ON       (aot.address_key=plkp.address_key)
                  )
                  where visitor_key is not null and address_xid is not null and  rno=1;



--                 "--step2:
--                 --Bring active address records from core  if same address no for same customer came in with different address id
--                 -- OR
--                 -- active address records where customer keys got updated in staging WAS/IS
--                 --OR
--                 -- Bring active primary address records for those customers whose primary address got updated
                INSERT /*+ append */
                INTO            visitor_address_lkp (visitor_key,address_key,address_xid,source_system_cd,active_ind,primary_ind,insert_audit_key)
                SELECT distinct  visitor_key,address_key,address_xid,source_system_cd,active_ind,primary_ind,insert_audit_key
                FROM  p_visitor_address_lkp core
                WHERE EXISTS
                                  (
                                        SELECT 1 from
                                                (
                                             --active address records that exists in core for customers is stg where same address address have come with diff address id
                                                                SELECT  valkp.address_XID,valkp.source_system_cd FROM p_visitor_address_lkp  valkp
                                                                        join v_visitor_dim vdim on(valkp.visitor_key=vdim.visitor_key)
                                                                        WHERE  active_ind='Y'  AND EXISTS
                                                                        (
                                                                        SELECT 1 FROM
                                                                                (
                                                                                  SELECT valkp.address_XID,valkp.source_system_cd,customer_key,address_KEY
                                                                                        FROM visitor_address_lkp  valkp
                                                                                        join v_visitor_dim vdim on(valkp.visitor_key=vdim.visitor_key)
                                                                                )stg_vis
                                                                                WHERE vdim.customer_key=stg_vis.customer_key
                                                                                and valkp.address_key=stg_vis.address_key
										                                                            and valkp.source_system_cd=stg_vis.source_system_cd
                                                                                and valkp.address_xid<>stg_vis.address_xid
                                                                          )

                                                                        UNION ALL
                                               -- WAS/IS active address records that exists in core where customer_key has been updated
                                                                 SELECT valkp.address_XID,valkp.source_system_cd FROM p_visitor_address_lkp  valkp
                                                                        join p_visitor_dim vdim on(valkp.visitor_key=vdim.visitor_key)
                                                                        WHERE  active_ind='Y'
                                                                        AND EXISTS
                                                                (
                                                                        SELECT 1 FROM (
                                                                                        SELECT core.CUSTOMER_KEY
                                                                                        FROM p_visitor_dim  core
                                                                                        join    visitor_dim stg
                                                                                        on(core.visitor_key=stg.visitor_key)
                                                                                        where core.customer_key<>stg.customer_key
                                                                                       )stg_vis
                                                                                        WHERE vdim.customer_key=stg_vis.customer_key

                                                                )

                                                                UNION ALL
                                                 --primary address records for the customer whose primary address got updated
                                                                 SELECT address_XID,source_system_cd FROM p_visitor_address_lkp  valkp
                                                                        JOIN  v_visitor_dim  vdim ON(valkp.visitor_key=vdim.visitor_key)
                                                                        WHERE  primary_ind='Y'
                                                                        AND EXISTS
                                                                                  (
                                                                                      SELECT 1 FROM (
                                                                                                     select address_xid,source_system_cd,customer_key
													                                                                              from visitor_address_lkp vaddress
                                                                                                        join  v_visitor_dim vdim
                                                                                                        on (vaddress.visitor_key=vdim.visitor_key)
                                                                                                        where primary_ind='Y'
                                                                                                     )    stg_vis
                                                                                                     where  vdim.customer_key=stg_vis.customer_key
													                                                                           and valkp.source_system_cd=stg_vis.source_system_cd
                                                                                                     and valkp.address_xid<>stg_vis.address_xid
                                                                                  )


                                                               ) stg
                                                                  where core.address_xid=stg.address_xid and core.source_system_cd=stg.source_system_cd
                                                   )
                                                   AND NOT EXISTS(
                                                                      SELECT 1 FROM visitor_address_lkp stg
                                                                      where core.address_xid=stg.address_xid and
									                                                    core.source_system_cd=stg.source_system_cd
                                                                );

                      --  "COMMIT",


              --  "--step3: Update  records  to inactive if same customer and same address no came in with new address id
                -- we consider the old address_id to be active and make all other new address id to inactive

                                MERGE INTO VISITOR_address_LKP T1
                                USING(
                                                SELECT  address_XID,source_system_cd
                                                FROM
                                                (       select address_xid,source_system_cd,
							ROW_NUMBER() OVER(PARTITION BY address_key,customer_key,source_system_cd
                                                        order by UPPER(PRIMARY_IND) desc,ACTIVE_IND desc, address_xid asc) rn
                                                        from VISITOR_address_LKP valkp join v_visitor_dim vdim
                                                        on(valkp.visitor_key= vdim.visitor_key)
                                                )
                                                where rn>1
                                      )T2
                                ON(T1.address_XID=T2.address_XID and T1.source_system_cd=t2.source_system_cd)
                                WHEN MATCHED THEN UPDATE
                                SET T1.ACTIVE_IND='N',T1.PRIMARY_IND='N';



              --  "--step4: Update  records   where a customer has more than 1 primary address
                 -- we consider the latest address_id to be primary address and make all other old address id to inactive

                                MERGE INTO VISITOR_address_LKP T1
                                USING(
                                                SELECT  address_XID,source_system_cd
                                                FROM
                                                (       select address_xid,source_system_cd,
							                                          ROW_NUMBER() OVER(PARTITION BY customer_key,source_system_cd order by address_xid desc) rn
                                                        from VISITOR_address_LKP valkp join v_visitor_dim vdim
                                                        on(valkp.visitor_key= vdim.visitor_key)
                                                        WHERE PRIMARY_IND='Y'
                                                )
                                                where rn>1
                                      )T2
                                ON(T1.address_XID=T2.address_XID and T1.source_system_cd=T2.source_system_cd)
                                WHEN MATCHED THEN UPDATE
                                SET T1.PRIMARY_IND='N';
-- ##########################################################################################
-- [9]-- 	'load/load_serialized_item_dim',
-- 			'load/load_serialized_item_lkp',
-- 			'load/load_visitor_ownership_xref',
-- 			'load/load_email_lkp',
-- 			'load/load_email_dim',
-- 			'load/load_visitor_email_xref',
-- 			'load/load_visitor_email_lkp',
-- 			'load/load_phone_dim',
-- 			'load/load_phone_lkp',
-- 			'load/load_visitor_phone_xref',
-- 			'load/load_visitor_phone_lkp',
-- 			'load/load_visitor_preference_tbl',
-- 			'load/load_purl_dim',
-- ##########################################################################################

-- ##########################################################################################
-- [last]-- 	'load/load_customer_dim',
-- ##########################################################################################
   INSERT INTO CUSTOMER_DIM (CUSTOMER_KEY,
                                   HOUSEHOLD_KEY,
                                   PRIMARY_VISITOR_KEY,
                                   DERIVED_SUPPRESSION_CD,
                                   DIM_STATUS_CD,
                                   PRIMARY_PURL_KEY,
                                   PRIMARY_ADDRESS_KEY,
                                   ADDRESS_SUPPRESSION_CD,
                                   PRIMARY_PHONE_KEY,
                                   PHONE_SUPPRESSION_CD,
                                   PRIMARY_EMAIL_KEY,
                                   EMAIL_SUPPRESSION_CD,
                                   INSERT_AUDIT_KEY)
                        SELECT                          base.customer_key,
                                                        base.household_key,
                                                        base.visitor_key,
                                                        'N' DERIVED_SUPPRESSION_CD,
                                                        'N' DIM_STATUS_CD,
                                                        purl.purl_key,
                                                        address.address_key,
                                                        CASE WHEN address_supp.PREFERENCE_VALUE = 'N' THEN 'Y' ELSE 'N' END ADDRESS_SUPPRESSION_CD,
                                                        phone.phone_key,
                                                        CASE WHEN phone_supp.PREFERENCE_VALUE = 'N' THEN 'Y' ELSE 'N' END PHONE_SUPPRESSION_CD,
                                                        email.email_key,
                                                        CASE WHEN email_supp.PREFERENCE_VALUE = 'N' THEN 'Y' ELSE 'N' END EMAIL_SUPPRESSION_CD,
                                                        base.insert_audit_key
                        FROM    
				(	
					select visitor_key,customer_key,household_key,vis_addr,vis_email,insert_audit_key from
                                                (
                                                      SELECT t1.visitor_key,customer_key,household_key,
                                                             MAX(t1.insert_audit_key) OVER (PARTITION BY customer_key) as insert_audit_key,
                                                 MIN(t1.VISITOR_KEY) over(
								partition by customer_key  ORDER BY 
								DECODE(SUBSTR(ACE_ERROR_CD,1,1),'E','3','S','1','2'),SUBSTR(ACE_ERROR_CD,1,1),eff_dt_key desc
								) as vis_addr,
						    MIN(t1.VISITOR_KEY) over(
                                                                partition by customer_key  ORDER BY
                                                                UPPER(bad_email_ind),eff_dt_key desc
                                                                ) as vis_email,
                                                             row_number() over (partition by customer_key order by  eff_dt_key desc,t1.visitor_key desc) as rno
                                                             FROM     v_visitor_history t1 
                                                             left join v_visitor_address t2
                                                             ON(t1.visitor_key=t2.visitor_key)
                                                             left join v_address_dim t3
                                                             ON(t2.address_key=t3.address_key)
								                                             left join v_visitor_email t4
									                                           ON(t1.visitor_key=t4.visitor_key)
								                                             left join v_email_dim t5
									                                           ON(t4.email_key=t5.email_key)
                                                )
                                                where rno=1
                                ) base
                        LEFT JOIN(      SELECT DISTINCT  
					                              visitor_key,
					                              MIN(PURL_KEY) OVER (PARTITION BY VISITOR_KEY) AS purl_key
					                              FROM visitor_purl_xref 
                                 ) purl
                        ON              (base.visitor_key = purl.visitor_key)
                        LEFT JOIN(v_visitor_address) address
                        ON  (base.vis_addr = address.visitor_key)
                        LEFT JOIN(v_visitor_email) email
                        ON  (base.vis_email = email.visitor_key)
                        LEFT JOIN(
					              select DISTINCT visitor_key,phone_key from visitor_phone_xref
                        where primary_ind='Y'      
                               ) phone
                        ON  (base.visitor_key = phone.visitor_key)
                        LEFT JOIN(     select visitor_key,PREFERENCE_VALUE,PREFERENCE_DIM_KEY as address_key from
                                          (
                                            SELECT  visitor_key,
                                                   	PREFERENCE_VALUE,
								                                    PREFERENCE_DIM_KEY,
                                                    row_number() over (partition by visitor_key,PREFERENCE_DIM_KEY order by EFFECTIVE_DT desc,visitor_key desc) as rno
                                                     from
                                                        (
                                                                select *
                                                                FROM visitor_preference_tbl stg,p_preference_type_ref pref
                                                                WHERE stg.preference_type_key=pref.preference_type_key
								                                                and pref.PREFERENCE_TYPE_NM='MAIL'
                                                                UNION ALL
                                                                select *
                                                                FROM p_visitor_preference_tbl core,p_preference_type_ref pref
                                                                WHERE core.preference_type_key=pref.preference_type_key
								                                                and pref.PREFERENCE_TYPE_NM='MAIL'
                                                                ))where rno=1 
                                ) address_supp
                        ON              (address.visitor_key = address_supp.visitor_key AND address.address_key = address_supp.address_key)
                        LEFT JOIN(
					              select visitor_key,PREFERENCE_VALUE,PREFERENCE_DIM_KEY as email_key from
                                                (
                                                   SELECT  visitor_key,
                                                   		PREFERENCE_VALUE,
                                                      PREFERENCE_DIM_KEY,
                                                      row_number() over (partition by visitor_key,PREFERENCE_DIM_KEY order by EFFECTIVE_DT desc,visitor_key desc) as rno
                                                     from
                                                        (
								                                          select *
                                                                FROM visitor_preference_tbl stg,p_preference_type_ref pref
                                                                WHERE stg.preference_type_key=pref.preference_type_key
                                                                and pref.PREFERENCE_TYPE_NM='EMAIL'
                                                                UNION ALL
                                                                select *
                                                                FROM p_visitor_preference_tbl core,p_preference_type_ref pref
                                                                WHERE core.preference_type_key=pref.preference_type_key
                                                                and pref.PREFERENCE_TYPE_NM='EMAIL'
                                                                ))where rno=1      
                                ) email_supp
                        ON (email.visitor_key = email_supp.visitor_key AND email.email_key = email_supp.email_key)
                        LEFT JOIN(
					              select visitor_key,PREFERENCE_VALUE,PREFERENCE_DIM_KEY as phone_key from
                                                (
                                                   SELECT  visitor_key,
                                                          PREFERENCE_VALUE,
                                                          PREFERENCE_DIM_KEY,
                                                    row_number() over (partition by visitor_key,PREFERENCE_DIM_KEY order by EFFECTIVE_DT desc,visitor_key desc) as rno
                                                     from
                                                        (
                                                             select *
                                                                FROM visitor_preference_tbl stg,p_preference_type_ref pref
                                                                WHERE stg.preference_type_key=pref.preference_type_key
                                                                and pref.PREFERENCE_TYPE_NM='PHONE;'
                                                                UNION ALL
                                                                select *
                                                                FROM p_visitor_preference_tbl core,p_preference_type_ref pref
                                                                WHERE core.preference_type_key=pref.preference_type_key
                                                                and pref.PREFERENCE_TYPE_NM='PHONE;'
                                                                ))where rno=1      
                                ) phone_supp
                        ON (base.visitor_key = phone_supp.visitor_key AND phone.phone_key = phone_supp.phone_key)
