'../../../fcrm_jobs/commonload/process-cl-v2'

job_names =>
[
'jobs/populate_cl_tbl',
'jobs/clean_tables',
'process-1',
'process-ace',
'jobs/serial_item/process_serialitem_lkp',
'process-customer',
'jobs/populate_staging',
],

1.'jobs/populate_cl_tbl',
                            load data in COMMON_LOAD_TBL  from COMMON_LOAD_HOLD_TBL
2. 'jobs/clean_tables',
                         clean stg tables
3. 'process-1',
                   This process is main starting points
job_names =>
[
'jobs/common_load',
# This job does all lookups and creates keys for output tbl                    #
# Validates that the email addresses contained in the input file are well      #
'jobs/load/load_common_load_output_tbl',
 out_columns=>
  [
    'unique_seq_no',
    'visitor_key',
    'quality_score "NVL(:quality_score,0)"',
    'purchase_dt_key',
    'email_key',
    'phone_key',
    'product_key',
    'effective_dt_key',
    'load_dt_key',
    'email_address_tx_cleaned',
    'phone_no_cleaned',
    'valid_email_format_ind',
    'valid_email_domain_ind',
    'package_key',
    'email_role_key',
    'phone_role_key',
    'address_role_key',
    'package_type_key',
  ],
  table       => 'common_load_output_tbl',

],

4'process-ace',
# This process does name and address cleansing
# on the records extracted from COMMON_LOAD_TBL.

# It relies on the presence of ~/jobs/ds/process.job  
# It also makes use of ~/jobs/lookup/address_lookup.job

# Tables affected by this process:
## CLNTSTG.ADDRESS_OUTPUT_TBL gets truncated and typically loaded with new data
job_names =>
[
'../../../common/jobs/clean_entity_folder',
'extract_ace',
'../../../ace/process-ACE',
],

job_names =>
[
'../ds/process_ace',
'jobs/load/load_ace_output_tbl',
'jobs/address',
'jobs/load/load_address_output_tbl',
   ],

 

Extract as follows
   SELECT t1.unique_seq_no,
      firm_nm,
      first_nm,
      middle_nm,
      last_nm,
      address_line1_tx,
      address_line2_tx,
      city_nm,
      state_cd,
      zip_cd_tx,
      null zip_code4_tx,
      DECODE(upper(NVL(t1.primary_phone_ind,'Y')),'Y',t2.phone_no_cleaned) as  phone_no,
      DECODE(upper(NVL(t1.primary_phone_ind,'Y')),'N',t2.phone_no_cleaned) prior_phone_no,
      email_address_tx,
      country_cd
FROMcommon_load_tbl t1,common_load_output_tbl t2
where t1.unique_seq_no=t2.unique_seq_no
ORDER BY zip_cd_tx",

Load out put as
out_columns=>
[
'unique_seq_no',
'firm_nm',
'first_nm',
'middle_nm',
'last_nm',
'address_line1_tx',
'address_line2_tx',
'city_nm',
'state_cd',
'zip_code5_tx',
'zip_code4_tx',
'address_hash_key',
'address_key',
],
table => 'address_output_tbl',

out_columns=>
[
'UNIQUE_SEQ_NO',
'FIRM_NM',
'PRE_NM',
'FIRST_NM',
'MIDDLE_NM',
'LAST_NM',
'POST_NM',
'ADDRESS_LINE1_TX',
'ADDRESS_LINE2_TX',
'CITY_NM',
'STATE_CD "substr(:STATE_CD,1,2)"',
'ZIP_CODE5_TX',
'ZIP_CODE4_TX',
'ACE_ERROR_CD',
'PRIMARY_STREET_NO',
'PRIMARY_STREET_NM',
'UNIT_NO',
'RURAL_ROUTE_BOX_NO',
'RURAL_ROUTE_NO',
'POSTAL_BOX_NO',
'DPV_STATUS_CD',
'WORK_PHONE_NO',
'HOME_PHONE_NO',
'EMAIL_ADDRESS_TX',
'GENDER',
'FOREIGN_ADDRESS_IND',
'CASS_RECORD_TYPE_CD',
'CHECK_DIGIT',
'POSTCODE_TYPE',
'UNDELIVERABLE_IND',
'DPV_CMRA_CD',
'COUNTRY_CD',
'ADDRESS_LINE_REMAIN1',
'ADDRESS_TYPE',
'ASSIGNMENT_TYPE',
'EXTRA1',
'STATUS_CD',
'INFO_CD',
'QUALITY_CD',
'ACTUAL_ASSIGNMENT_LEVEL',
],
table => 'ds_ace_output_tbl',
dsn_param => 'staging_dsn',


5, 'jobs/serial_item/process_serialitem_lkp',
    this we can ignore as it handle SI data

6,'process-customer',
Here it handle customer and 
new Staging::Job
('Staging::Job::Sequence',
local_context=>
{
entity              =>  'customer',
ds_jobname          =>  'JOB_${client.CLIENT}_CUSTOMER.sh',
visitor_match_ind   =>'${client.VISITOR_MATCH_IND}',
serial_match_ind    =>  '${client.SERIAL_MATCH_IND}',
addr_match_ind      =>  '${client.ADDR_MATCH_IND}',
firm_match_ind      =>  '${client.FIRM_MATCH_IND}',
email_match_ind     =>  '${client.EMAIL_MATCH_IND}',
phone_match_ind     =>  '${client.PHONE_MATCH_IND}',

},

job_names =>
[
'../../../common/jobs/clean_entity_folder',
'truncate_group_raw_tbl',
'extract_customers',
'extract_history',
'../../../ds/process',
'clean_customer_group',
'load/load_customer_group_raw_tbl',
'populate_group_tbls',
'customer',
'load/load_customer_output_tbl',
],
);
7,'jobs/populate_staging',
Here we can clean tables on stg before core update to handle address changes go only 
job_names =>
[
'clean_tables',
'load/load_visitor_dim',
'load/load_visitor_lkp',
'load/load_customer_lkp',
'load/load_household_lkp',
'load/load_visitor_history_tbl',
'load/load_address_dim',
'load/load_address_lkp',
'load/load_visitor_address_xref',
'load/load_visitor_address_lkp',
-- 'load/load_serialized_item_dim',
-- 'load/load_serialized_item_lkp',
-- 'load/load_visitor_ownership_xref',
-- 'load/load_email_lkp',
-- 'load/load_email_dim',
-- 'load/load_visitor_email_xref',
-- 'load/load_visitor_email_lkp',
-- 'load/load_phone_dim',
-- 'load/load_phone_lkp',
-- 'load/load_visitor_phone_xref',
-- 'load/load_visitor_phone_lkp',
'load/load_visitor_preference_tbl',
'load/load_purl_dim',
'load/load_customer_dim',
],