--------------------------------------------------------------------------------
  --Start of Backup
  --BUNDLE_DIM -- done
  --CELL_SELECTION_FCT --done
  --BUNDLE_STATE_TBL --done
  --CAMPAIGN_PARTICIPATION_FCT --done
--------------------------------------------------------------------------------
create table BUNDLE_DIM_202401030 as select * from BUNDLE_DIM;
select * from BUNDLE_DIM_202401030;

select count(*) from BUNDLE_DIM
        union all
select count(*) from BUNDLE_DIM_202401030;
-- +--------+
-- |COUNT(*)|
-- +--------+
-- |133418  |
-- |133418  |
-- +--------+


create table CELL_SELECTION_FCT_202401030 as select * from CELL_SELECTION_FCT;
select * from CELL_SELECTION_FCT_202401030;

select count(*) from CELL_SELECTION_FCT
        union all
select count(*) from CELL_SELECTION_FCT_202401030;
-- 133307
-- 133307


create table BUNDLE_STATE_TBL_202401030 as select * from BUNDLE_STATE_TBL ; --as of timestamp (systimestamp - interval '1' hour);
select * from BUNDLE_STATE_TBL_202401030;

select count(*) from BUNDLE_STATE_TBL
        union all
select count(*) from BUNDLE_STATE_TBL_202401030;
-- 366670
-- 366670


select count(*) from BUNDLE_STATE_TBL t1 join BUNDLE_STATE_TBL_202401030 t2 using (bundle_key)
 where t1.DATE_KEY <> t2.DATE_KEY;
--0


create table CAMPAIGN_PARTICIPATION_FCT_202401030 as select * from CAMPAIGN_PARTICIPATION_FCT;
select * from CAMPAIGN_PARTICIPATION_FCT_202401030;

select count(*) from CAMPAIGN_PARTICIPATION_FCT
        union all
select count(*) from CAMPAIGN_PARTICIPATION_FCT_202401030;
-- 275558
-- 275558


--------------------------------------------------------------------------------
  --End of Backup
--------------------------------------------------------------------------------