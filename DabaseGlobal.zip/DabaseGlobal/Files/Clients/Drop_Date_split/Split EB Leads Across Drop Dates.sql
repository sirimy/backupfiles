--------------------------------------------------------------------------------
  --Start of Backup
  --BUNDLE_DIM
  --CELL_SELECTION_FCT
  --BUNDLE_STATE_TBL
  --CAMPAIGN_PARTICIPATION_FCT
--------------------------------------------------------------------------------
create table BUNDLE_DIM_20240826 as select * from BUNDLE_DIM;
select * from BUNDLE_DIM_20240826;

select count(*) from BUNDLE_DIM
        union all
select count(*) from BUNDLE_DIM_20240826;
-- 579088
-- 579088

create table CELL_SELECTION_FCT_20240826 as select * from CELL_SELECTION_FCT;
select * from CELL_SELECTION_FCT_20240826;

select count(*) from CELL_SELECTION_FCT
        union all
select count(*) from CELL_SELECTION_FCT_20240826;
-- COUNT(*)
-- 578982
-- 578982

create table BUNDLE_STATE_TBL_20240826 as select * from BUNDLE_STATE_TBL as of timestamp (systimestamp - interval '1' hour);
select * from BUNDLE_STATE_TBL_20240826;

select count(*) from BUNDLE_STATE_TBL
        union all
select count(*) from BUNDLE_STATE_TBL_20240826;
-- COUNT(*)
-- 763466
-- 763466

select count(*) from BUNDLE_STATE_TBL t1 join BUNDLE_STATE_TBL_20240826 t2 using (bundle_key)
 where t1.DATE_KEY <> t2.DATE_KEY;
--257723


create table CAMPAIGN_PARTICIPATION_FCT_20240826 as select * from CAMPAIGN_PARTICIPATION_FCT;
select * from CAMPAIGN_PARTICIPATION_FCT_20240826;

select count(*) from CAMPAIGN_PARTICIPATION_FCT
        union all
select count(*) from CAMPAIGN_PARTICIPATION_FCT_20240826;
-- COUNT(*)
-- 803301
-- 803301

--------------------------------------------------------------------------------
  --End of Backup
--------------------------------------------------------------------------------

--Find Bosch EB2 leads from first drop week
select CRITERIA_CD, DROP_DT, substr(GUARANTEE_ID, 7, 5), count(*), count(distinct  bundle_key)
  from bundle_dim bd join p_criteria_dim cri using (criteria_key)
       join CELL_SELECTION_FCT using (bundle_key)
       join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
 where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
   and bd.SUPPRESSION_CD is null
   and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
   and brand_full_desc = 'Bosch'
   and substr(GUARANTEE_ID, 7, 3) = 'BSH'  --Excluding counter top coffee makers (BSC)
   and MAIL_DROP_DATE = date '2024-11-19'
 group by CRITERIA_CD, DROP_DT, substr(GUARANTEE_ID, 7, 5) order by CRITERIA_CD, substr(GUARANTEE_ID, 7, 5), DROP_DT;
/*
+-----------+----------+------------------------+--------+-------------------------+
|CRITERIA_CD|DROP_DT   |SUBSTR(GUARANTEE_ID,7,5)|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
+-----------+----------+------------------------+--------+-------------------------+
|AS000      |2024-09-17|BSHAS                   |203094  |203094                   |
+-----------+----------+------------------------+--------+-------------------------+
 */


    select DROP_DT, DATE_KEY, SUN_YEAR_WEEK_NO from BUNDLE_DIM join DATE_DIM on DROP_DT = FULL_DT
    group by DROP_DT, DATE_KEY, SUN_YEAR_WEEK_NO
    order by 1;
-- +----------+--------+----------------+
-- |DROP_DT   |DATE_KEY|SUN_YEAR_WEEK_NO|
-- +----------+--------+----------------+
-- |2024-11-19|12742   |202446          |
-- |2024-11-26|12749   |202447          |
-- |2024-12-03|12756   |202448          |
-- |2024-12-10|12763   |202449          |
-- +----------+--------+----------------+

--Fetch 22K leads randomly using sql above and update their drop_date to 2024-11-26
               select DROP_DT,
                       GUARANTEE_ID_9 as existing_gid,
                       '202447' ||  substr(GUARANTEE_ID_9, 7) as new_gid, count(distinct BUNDLE_KEY) as bundles
                  from bundle_dim bd join p_criteria_dim cri using (criteria_key)
                       join CELL_SELECTION_FCT using (bundle_key)
                       join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
                 where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
                   and bd.SUPPRESSION_CD is null
                   and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
                   and brand_full_desc = 'Bosch'
                   and substr(GUARANTEE_ID, 7, 3) = 'BSH'
                   and MAIL_DROP_DATE = date '2024-11-19'
               group by DROP_DT, GUARANTEE_ID_9,
                       '202447' ||  substr(GUARANTEE_ID_9, 7);
-- +----------+----------------+----------------+-------+
-- |DROP_DT   |EXISTING_GID    |NEW_GID         |BUNDLES|
-- +----------+----------------+----------------+-------+
-- |2024-11-19|202446BSHE200001|202447BSHE200001|10921  |
-- |2024-11-19|202446BSHE200002|202447BSHE200002|29797  |
-- +----------+----------------+----------------+-------+


    merge
     into BUNDLE_DIM bd
    using (
            select * from (
                select CRITERIA_CD, DROP_DT, GUARANTEE_ID, bundle_key,
                       date '2024-11-26' as new_drop_date,
                       '202447' ||  substr(GUARANTEE_ID_9, 7) as new_gid
                  from bundle_dim bd join p_criteria_dim cri using (criteria_key)
                       join CELL_SELECTION_FCT using (bundle_key)
                       join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
                 where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
                   and bd.SUPPRESSION_CD is null
                   and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
                   and brand_full_desc = 'Bosch'
                   and substr(GUARANTEE_ID, 7, 3) = 'BSH'
                   and MAIL_DROP_DATE = date '2024-11-19'
                 order by DBMS_RANDOM.RANDOM()
                  ) tmp
             where ROWNUM <= 22000
          ) tmp
    on    (bd.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when  matched then
    update
    set   GUARANTEE_ID_9 = new_gid,
          DROP_DT = new_drop_date
;
--271289 rows
commit;


--Once the bundle_dim gets updated then we can update date_key in other tables by joining on bundle_key
select CRITERIA_CD, DROP_DT, GUARANTEE_ID_9, count(*), count(distinct  bundle_key)
  from bundle_dim bd join p_criteria_dim cri using (criteria_key)
       join CELL_SELECTION_FCT using (bundle_key)
       join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
 where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
   and brand_full_desc = 'Bosch'
   and substr(GUARANTEE_ID, 7, 3) = 'BSH'
   and bd.SUPPRESSION_CD is null
   and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
 group by CRITERIA_CD, DROP_DT, GUARANTEE_ID_9 order by CRITERIA_CD, substr(GUARANTEE_ID_9, 7,5), DROP_DT;
/*
+-----------+----------+----------------+--------+-------------------------+
|CRITERIA_CD|DROP_DT   |GUARANTEE_ID_9  |COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
+-----------+----------+----------------+--------+-------------------------+
|AS000      |2024-09-17|202437BSHAS00000|10434   |10434                    |

 */


    --Fix BUNDLE_STATE_TBL
    select bst.DATE_KEY, dd.date_key, count(*)
    from   BUNDLE_STATE_TBL bst 
           join BUNDLE_DIM  bd using (BUNDLE_KEY)
           join p_criteria_dim cri using (criteria_key)
           join DATE_DIM    dd on bd.drop_dt = full_dt
           join CELL_SELECTION_FCT using (bundle_key)
           join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
 where  CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
   and brand_full_desc = 'Bosch'
   and substr(GUARANTEE_ID, 7, 3) = 'BSH'
  and bd.SUPPRESSION_CD is null
  and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
--     and    bst.DATE_KEY <> dd.date_key
    group by bst.DATE_KEY, dd.date_key
    order by bst.DATE_KEY, dd.date_key;
/*DATE_KEY,DATE_KEY,COUNT(*)

 */


    merge into BUNDLE_STATE_TBL bst
    using (
            select BUNDLE_KEY, dd.date_key, dd.full_dt
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join DATE_DIM dd on drop_dt = full_dt
                   join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
            where 
                   CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
               and brand_full_desc = 'Bosch'
               and substr(GUARANTEE_ID, 7, 3) = 'BSH'
          ) tmp
    on    (bst.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when matched then  update
    set   bst.DATE_KEY = tmp.date_key
    where bst.DATE_KEY <> tmp.date_key
    ;
    --257,723   --this is less than total count of 271K as we are updating mismatched dates only
   commit;


    --Fix CELL_SELECTION_FCT
    select bst.DATE_KEY, dd.date_key, count(*)
    from   CELL_SELECTION_FCT bst
           join BUNDLE_DIM  bd using (BUNDLE_KEY)
           join p_criteria_dim cri using (criteria_key)
           join DATE_DIM    dd on bd.drop_dt = full_dt
           join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
    where
           CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
       and brand_full_desc = 'Bosch'
       and substr(GUARANTEE_ID, 7, 3) = 'BSH'
--     and    bst.DATE_KEY <> dd.date_key
    group by bst.DATE_KEY, dd.date_key
    order by bst.DATE_KEY, dd.date_key;
/*DATE_KEY,DATE_KEY,COUNT(*)

*/


    merge into CELL_SELECTION_FCT bst
    using (
            select BUNDLE_KEY, dd.date_key, dd.full_dt
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join DATE_DIM dd on drop_dt = full_dt
                   join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
            where
                   CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
               and brand_full_desc = 'Bosch'
               and substr(GUARANTEE_ID, 7, 3) = 'BSH'
          ) tmp
    on    (bst.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when matched then  update
    set   bst.DATE_KEY = tmp.date_key
    where bst.DATE_KEY <> tmp.date_key
    ;
    --257,723
   commit;



    --Fix CAMPAIGN_PARTICIPATION_FCT
    select bst.DATE_KEY, dd.date_key, count(*)
    from   CAMPAIGN_PARTICIPATION_FCT bst
           join BUNDLE_DIM  bd using (BUNDLE_KEY)
           join p_criteria_dim cri using (criteria_key)
           join DATE_DIM    dd on bd.drop_dt = full_dt
           join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
    where
           CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
       and brand_full_desc = 'Bosch'
       and substr(GUARANTEE_ID, 7, 3) = 'BSH'
--     and    bst.DATE_KEY <> dd.date_key
    group by bst.DATE_KEY, dd.date_key
    order by bst.DATE_KEY, dd.date_key;
/*DATE_KEY,DATE_KEY,COUNT(*)

*/


    merge into CAMPAIGN_PARTICIPATION_FCT bst
    using (
            select BUNDLE_KEY, dd.date_key, dd.full_dt
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join DATE_DIM dd on drop_dt = full_dt
                   join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
            where
                   CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
               and brand_full_desc = 'Bosch'
               and substr(GUARANTEE_ID, 7, 3) = 'BSH'
          ) tmp
    on    (bst.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when matched then  update
    set   bst.DATE_KEY = tmp.date_key
    where bst.DATE_KEY <> tmp.date_key
    ;
    --379,222  --this includes Mail only and Mail+Email bundles
   commit;



    --Fix OFFER_XREF
    select distinct OFFER_EXP_DT - OFFER_START_DT from OFFER_XREF;
    --41 days

    select DROP_DT, OFFER_START_DT, OFFER_EXP_DT, count(*), count(distinct BUNDLE_KEY), count(distinct offer_key)
        from (
            select bd.BUNDLE_KEY, DROP_DT, OFFER_START_DT, OFFER_EXP_DT, offer_key
            from   BUNDLE_DIM bd
                   join p_criteria_dim cri using (criteria_key)
                   join CAMPAIGN_PARTICIPATION_FCT cp on (cp.bundle_key = bd.BUNDLE_KEY) join OFFER_XREF ox using (offer_key)
                   join CAMPAIGN_SPOOL_FILE_TBL spl  on (spl.bundle_key = bd.BUNDLE_KEY)
            where  CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
              and brand_full_desc = 'Bosch'
              and substr(GUARANTEE_ID, 7, 3) = 'BSH'
           )
        group by DROP_DT, OFFER_START_DT, OFFER_EXP_DT
        order by DROP_DT;
/*DROP_DT,OFFER_START_DT,OFFER_EXP_DT,COUNT(*),COUNT(DISTINCTBUNDLE_KEY),COUNT(DISTINCTOFFER_KEY)

 */


    merge into OFFER_XREF ox
    using (
            select distinct BUNDLE_KEY, DROP_DT, offer_key
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join CAMPAIGN_PARTICIPATION_FCT cp using (bundle_key)
                   join CAMPAIGN_SPOOL_FILE_TBL spl  using (bundle_key)
            where  CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
              and brand_full_desc = 'Bosch'
              and substr(GUARANTEE_ID, 7, 3) = 'BSH'
           ) tmp
    on    (ox.offer_key = tmp.offer_key)
    when matched then  update
    set   OFFER_START_DT = DROP_DT,
          OFFER_EXP_DT = DROP_DT + 41
    where OFFER_START_DT <> DROP_DT
    ;
    --257,723
    commit;



    --Fix CAMPAIGN_SPOOL_FILE_TBL
    select substr(GUARANTEE_ID_9, 1, 6), drop_dt, substr(GUARANTEE_ID, 1, 6), MAIL_DROP_DATE,  count(*), count(distinct BUNDLE_KEY)
    from BUNDLE_DIM
         join p_criteria_dim cri using (criteria_key)
         join CAMPAIGN_SPOOL_FILE_TBL
    using (bundle_key)
    where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
       and brand_full_desc = 'Bosch'
       and substr(GUARANTEE_ID, 7, 3) = 'BSH'
    group by  substr(GUARANTEE_ID_9, 1, 6), drop_dt, substr(GUARANTEE_ID, 1, 6), MAIL_DROP_DATE
    order by 1, 2;
/*"SUBSTR(GUARANTEE_ID_9,1,6)",DROP_DT,"SUBSTR(GUARANTEE_ID,1,6)",MAIL_DROP_DATE,COUNT(*),COUNT(DISTINCTBUNDLE_KEY)

*/

    select *
    from BUNDLE_DIM
    where GUARANTEE_ID_9 like '%E2%';

    select * From tmp_update_gid;

--     drop table tmp_update_gid purge;

    create table tmp_update_gid as
        select distinct
               GUARANTEE_ID_9 || substr(GUARANTEE_ID, 17, 2) || cell_cd as newgid,
               DROP_DT,
               BUNDLE_KEY
        from BUNDLE_DIM
             join p_criteria_dim cri using (criteria_key)
        join CAMPAIGN_SPOOL_FILE_TBL
        using (bundle_key)
        join campaign_participation_fct
        using (bundle_key)
        join p_cell_dim
        using(cell_key)
        where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
          and brand_full_desc = 'Bosch'
          and substr(GUARANTEE_ID, 7, 3) = 'BSH';



    merge into CAMPAIGN_SPOOL_FILE_TBL csft
    using  tmp_update_gid tmp
    on     (csft.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when matched then
    update  
    set    GUARANTEE_ID =  newgid, 
           MAIL_DROP_DATE = drop_dt, 
           EST_MAIL_IN_HOME_DT = drop_dt + 7,
           EMAIL_START_DT = DROP_DT + 8, 
           OFFER_EXPIRE_DT = DROP_DT + 41
    where MAIL_DROP_DATE <> drop_dt
    ;
    --379,222   --including emails

-- , CHANNEL_NM
    select  --substr(GUARANTEE_ID, 17, 2) , GUARANTEE_ID--
          substr(GUARANTEE_ID,1,6), mail_drop_date, OFFER_EXPIRE_DT,
          count(*)
   from CAMPAIGN_SPOOL_FILE_TBL join BUNDLE_DIM using (bundle_key)
        join p_criteria_dim cri using (criteria_key)
   where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
     and brand_full_desc = 'Bosch'
     and substr(GUARANTEE_ID, 7, 3) = 'BSH'
   group by  mail_drop_date, substr(GUARANTEE_ID,1,6), OFFER_EXPIRE_DT
   order by mail_drop_date;
/*+------------------------+--------------+---------------+--------+
|SUBSTR(GUARANTEE_ID,1,6)|MAIL_DROP_DATE|OFFER_EXPIRE_DT|COUNT(*)|
+------------------------+--------------+---------------+--------+
|202437                  |2024-09-17    |2024-10-28     |13566   |
+------------------------+--------------+---------------+--------+
 */

    select BRAND_FULL_DESC,
          substr(GUARANTEE_ID,1,6), mail_drop_date, OFFER_EXPIRE_DT,
          count(*)
   from CAMPAIGN_SPOOL_FILE_TBL join BUNDLE_DIM using (bundle_key)
        join p_criteria_dim cri using (criteria_key)
   where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
     and brand_full_desc = 'Bosch'
     and substr(GUARANTEE_ID, 7, 3) = 'BSH'
   group by BRAND_FULL_DESC, mail_drop_date, substr(GUARANTEE_ID,1,6), OFFER_EXPIRE_DT
   order by BRAND_FULL_DESC, mail_drop_date;
--looks good

   commit;
------------------------------------------------------------------------------------
