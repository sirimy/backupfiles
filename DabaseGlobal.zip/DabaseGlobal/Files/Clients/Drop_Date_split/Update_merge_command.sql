  select DROP_DT,
                       GUARANTEE_ID_9 as existing_gid,
                       '202447' ||  substr(GUARANTEE_ID_9, 7) as new_gid, count(distinct BUNDLE_KEY) as bundles_cnt
                  from bundle_dim bd join p_criteria_dim cri using (criteria_key)
                       join CELL_SELECTION_FCT using (bundle_key)
                       join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
                 where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
                   and bd.SUPPRESSION_CD is null
                   and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
                   and brand_full_desc = 'Bosch'
                   and substr(GUARANTEE_ID, 7, 3) = 'BSH'
                   and MAIL_DROP_DATE = date '2024-11-19'
               group by DROP_DT, GUARANTEE_ID_9,
                       '202447' ||  substr(GUARANTEE_ID_9, 7);
-- +----------+----------------+----------------+-------+
-- |DROP_DT   |EXISTING_GID    |NEW_GID         |BUNDLES|
-- +----------+----------------+----------------+-------+
-- |2024-11-19|202446BSHE200001|202447BSHE200001|10906  |
-- |2024-11-19|202446BSHE200002|202447BSHE200002|29662  |
-- +----------+----------------+----------------+-------+


    merge
     into BUNDLE_DIM bd
    using (
            select * from (
                select CRITERIA_CD, DROP_DT, GUARANTEE_ID, bundle_key,
                       date '2024-11-26' as new_drop_date,
                       '202447' ||  substr(GUARANTEE_ID_9, 7) as new_gid
                  from bundle_dim bd join p_criteria_dim cri using (criteria_key)
                       join CELL_SELECTION_FCT using (bundle_key)
                       join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
                 where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
                   and bd.SUPPRESSION_CD is null
                   and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
                   and brand_full_desc = 'Bosch'
                   and substr(GUARANTEE_ID, 7, 3) = 'BSH'
                   and MAIL_DROP_DATE = date '2024-11-19'
                 order by DBMS_RANDOM.RANDOM()
                  ) tmp
             where ROWNUM <= 22000
          ) tmp
    on    (bd.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when  matched then
    update
    set   GUARANTEE_ID_9 = new_gid,
          DROP_DT = new_drop_date
;
--[2024-10-30 14:02:38] 22,000 rows affected in 1 s 719 ms
--commit;
  select DROP_DT,MAIL_DROP_DATE,
                       GUARANTEE_ID_9 as existing_gid,
                       '202447' ||  substr(GUARANTEE_ID_9, 7) as new_gid, count(distinct BUNDLE_KEY) as bundles_cnt
                  from bundle_dim bd join p_criteria_dim cri using (criteria_key)
                       join CELL_SELECTION_FCT using (bundle_key)
                       join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
                 where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
                   and bd.SUPPRESSION_CD is null
                   and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
                   and brand_full_desc = 'Bosch'
                   and substr(GUARANTEE_ID, 7, 3) = 'BSH'
                   and MAIL_DROP_DATE = date '2024-11-19'
               group by DROP_DT,MAIL_DROP_DATE, GUARANTEE_ID_9,
                       '202447' ||  substr(GUARANTEE_ID_9, 7)
                order by DROP_DT;
-- +----------+--------------+----------------+----------------+-----------+
-- |DROP_DT   |MAIL_DROP_DATE|EXISTING_GID    |NEW_GID         |BUNDLES_CNT|
-- +----------+--------------+----------------+----------------+-----------+
-- |2024-11-19|2024-11-19    |202446BSHE200001|202447BSHE200001|4981       |
-- |2024-11-19|2024-11-19    |202446BSHE200002|202447BSHE200002|13587      |
-- |2024-11-26|2024-11-19    |202447BSHE200001|202447BSHE200001|5925       |
-- |2024-11-26|2024-11-19    |202447BSHE200002|202447BSHE200002|16075      |
-- +----------+--------------+----------------+----------------+-----------+
--commit;


    --Fix BUNDLE_STATE_TBL
    select bst.DATE_KEY, dd.date_key, count(*)
    from   BUNDLE_STATE_TBL bst
           join BUNDLE_DIM  bd using (BUNDLE_KEY)
           join p_criteria_dim cri using (criteria_key)
           join DATE_DIM    dd on bd.drop_dt = full_dt
           join CELL_SELECTION_FCT using (bundle_key)
           join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
 where  CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
   and brand_full_desc = 'Bosch'
   and substr(GUARANTEE_ID, 7, 3) = 'BSH'
  and bd.SUPPRESSION_CD is null
  and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
--     and    bst.DATE_KEY <> dd.date_key
    group by bst.DATE_KEY, dd.date_key
    order by bst.DATE_KEY, dd.date_key;
-- +--------+--------+--------+
-- |DATE_KEY|DATE_KEY|COUNT(*)|
-- +--------+--------+--------+
-- |12742   |12742   |18568   |
-- |12742   |12749   |22000   |
-- +--------+--------+--------+


    merge into BUNDLE_STATE_TBL bst
    using (
            select BUNDLE_KEY, dd.date_key, dd.full_dt
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join DATE_DIM dd on drop_dt = full_dt
                   join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
            where
                   CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
               and brand_full_desc = 'Bosch'
               and substr(GUARANTEE_ID, 7, 3) = 'BSH'
          ) tmp
    on    (bst.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when matched then  update
    set   bst.DATE_KEY = tmp.date_key
    where bst.DATE_KEY <> tmp.date_key
    ;
    -- 22,000 rows affected in 1 s 824 ms  --this is less than total count of 271K as we are updating mismatched dates only
    -- +--------+--------+--------+
    -- |DATE_KEY|DATE_KEY|COUNT(*)|
    -- +--------+--------+--------+
    -- |12742   |12742   |18568   |
    -- |12749   |12749   |22000   |
    -- +--------+--------+--------+
   --commit;

 --Fix CELL_SELECTION_FCT
    select bst.DATE_KEY, dd.date_key, count(*)
    from   CELL_SELECTION_FCT bst
           join BUNDLE_DIM  bd using (BUNDLE_KEY)
           join p_criteria_dim cri using (criteria_key)
           join DATE_DIM    dd on bd.drop_dt = full_dt
           join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
    where
           CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
       and brand_full_desc = 'Bosch'
       and substr(GUARANTEE_ID, 7, 3) = 'BSH'
       --and    bst.DATE_KEY = dd.date_key
    group by bst.DATE_KEY, dd.date_key
    order by bst.DATE_KEY, dd.date_key;
-- +--------+--------+--------+
-- |DATE_KEY|DATE_KEY|COUNT(*)|
-- +--------+--------+--------+
-- |12742   |12742   |18568   |
-- |12742   |12749   |22000   |
-- +--------+--------+--------+


    merge into CELL_SELECTION_FCT bst
    using (
            select BUNDLE_KEY, dd.date_key, dd.full_dt
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join DATE_DIM dd on drop_dt = full_dt
                   join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
            where
                   CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
               and brand_full_desc = 'Bosch'
               and substr(GUARANTEE_ID, 7, 3) = 'BSH'
          ) tmp
    on    (bst.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when matched then  update
    set   bst.DATE_KEY = tmp.date_key
    where bst.DATE_KEY <> tmp.date_key
    ;
    --[2024-10-30 14:20:14] 22,000 rows affected in 1 s 367 ms
   --commit;
-- +--------+--------+--------+
-- |DATE_KEY|DATE_KEY|COUNT(*)|
-- +--------+--------+--------+
-- |12742   |12742   |18568   |
-- |12749   |12749   |22000   |
-- +--------+--------+--------+


    --Fix CAMPAIGN_PARTICIPATION_FCT
    select bst.DATE_KEY, dd.date_key, count(*), count(distinct BUNDLE_KEY)
    from   CAMPAIGN_PARTICIPATION_FCT bst
           join BUNDLE_DIM  bd using (BUNDLE_KEY)
           join p_criteria_dim cri using (criteria_key)
           join DATE_DIM    dd on bd.drop_dt = full_dt
           join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
    where
           CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
       and brand_full_desc = 'Bosch'
       and substr(GUARANTEE_ID, 7, 3) = 'BSH'
--     and    bst.DATE_KEY <> dd.date_key
    group by bst.DATE_KEY, dd.date_key
    order by bst.DATE_KEY, dd.date_key;
-- +--------+--------+--------+-------------------------+
-- |DATE_KEY|DATE_KEY|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
-- +--------+--------+--------+-------------------------+
-- |12742   |12742   |29875   |18568                    |
-- |12742   |12749   |35351   |22000                    |
-- +--------+--------+--------+-------------------------+

    merge into CAMPAIGN_PARTICIPATION_FCT bst
    using (
            select BUNDLE_KEY, dd.date_key, dd.full_dt
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join DATE_DIM dd on drop_dt = full_dt
                   join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
            where
                   CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
               and brand_full_desc = 'Bosch'
               and substr(GUARANTEE_ID, 7, 3) = 'BSH'
          ) tmp
    on    (bst.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when matched then  update
    set   bst.DATE_KEY = tmp.date_key
    where bst.DATE_KEY <> tmp.date_key
    ;
    --  [2024-10-30 14:23:22] 35,351 rows affected in 1 s 500 ms --this includes Mail only and Mail+Email bundles
   --commit;
-- +--------+--------+--------+-------------------------+
-- |DATE_KEY|DATE_KEY|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
-- +--------+--------+--------+-------------------------+
-- |12742   |12742   |29875   |18568                    |
-- |12749   |12749   |35351   |22000                    |
-- +--------+--------+--------+-------------------------+



    --Fix OFFER_XREF
    select distinct OFFER_EXP_DT - OFFER_START_DT from OFFER_XREF;
    --41 days

    select DROP_DT, OFFER_START_DT, OFFER_EXP_DT, count(*), count(distinct BUNDLE_KEY), count(distinct offer_key)
        from (
            select bd.BUNDLE_KEY, DROP_DT, OFFER_START_DT, OFFER_EXP_DT, offer_key
            from   BUNDLE_DIM bd
                   join p_criteria_dim cri using (criteria_key)
                   join CAMPAIGN_PARTICIPATION_FCT cp on (cp.bundle_key = bd.BUNDLE_KEY) join OFFER_XREF ox using (offer_key)
                   join CAMPAIGN_SPOOL_FILE_TBL spl  on (spl.bundle_key = bd.BUNDLE_KEY)
            where  CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
              and brand_full_desc = 'Bosch'
              and substr(GUARANTEE_ID, 7, 3) = 'BSH'
           )
        group by DROP_DT, OFFER_START_DT, OFFER_EXP_DT
        order by DROP_DT;
-- +----------+--------------+------------+--------+-------------------------+------------------------+
-- |DROP_DT   |OFFER_START_DT|OFFER_EXP_DT|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|COUNT(DISTINCTOFFER_KEY)|
-- +----------+--------------+------------+--------+-------------------------+------------------------+
-- |2024-11-19|2024-11-19    |2024-12-30  |29875   |18568                    |18568                   |
-- |2024-11-26|2024-11-19    |2024-12-30  |35351   |22000                    |22000                   |
-- +----------+--------------+------------+--------+-------------------------+------------------------+


select ox.OFFER_START_DT,OFFER_EXP_DT,DROP_DT,DROP_DT + 41,COUNT(*) from (select distinct BUNDLE_KEY, DROP_DT, offer_key
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join CAMPAIGN_PARTICIPATION_FCT cp using (bundle_key)
                   join CAMPAIGN_SPOOL_FILE_TBL spl  using (bundle_key)
            where  CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
              and brand_full_desc = 'Bosch'
              and substr(GUARANTEE_ID, 7, 3) = 'BSH' ) tmp
    join  OFFER_XREF ox on ox.offer_key = tmp.offer_key
    group by ox.OFFER_START_DT,OFFER_EXP_DT,DROP_DT
;
-- +--------------+------------+----------+----------+--------+
-- |OFFER_START_DT|OFFER_EXP_DT|DROP_DT   |DROP_DT+41|COUNT(*)|
-- +--------------+------------+----------+----------+--------+
-- |2024-11-19    |2024-12-30  |2024-11-19|2024-12-30|18568   |
-- |2024-11-19    |2024-12-30  |2024-11-26|2025-01-06|22000   |
-- +--------------+------------+----------+----------+--------+

    merge into OFFER_XREF ox
    using (
            select distinct BUNDLE_KEY, DROP_DT, offer_key
            from   BUNDLE_DIM
                   join p_criteria_dim cri using (criteria_key)
                   join CAMPAIGN_PARTICIPATION_FCT cp using (bundle_key)
                   join CAMPAIGN_SPOOL_FILE_TBL spl  using (bundle_key)
            where  CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
              and brand_full_desc = 'Bosch'
              and substr(GUARANTEE_ID, 7, 3) = 'BSH'
           ) tmp
    on    (ox.offer_key = tmp.offer_key)
    when matched then  update
    set   OFFER_START_DT = DROP_DT,
          OFFER_EXP_DT = DROP_DT + 41
    where OFFER_START_DT <> DROP_DT
    ;
    --22,000 rows affected in 1 s 513 ms
    commit;
-- +--------------+------------+----------+----------+--------+
-- |OFFER_START_DT|OFFER_EXP_DT|DROP_DT   |DROP_DT+41|COUNT(*)|
-- +--------------+------------+----------+----------+--------+
-- |2024-11-19    |2024-12-30  |2024-11-19|2024-12-30|18568   |
-- |2024-11-26    |2025-01-06  |2024-11-26|2025-01-06|22000   |
-- +--------------+------------+----------+----------+--------+
-- +----------+--------------+------------+--------+-------------------------+------------------------+
-- |DROP_DT   |OFFER_START_DT|OFFER_EXP_DT|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|COUNT(DISTINCTOFFER_KEY)|
-- +----------+--------------+------------+--------+-------------------------+------------------------+
-- |2024-11-19|2024-11-19    |2024-12-30  |29875   |18568                    |18568                   |
-- |2024-11-26|2024-11-26    |2025-01-06  |35351   |22000                    |22000                   |
-- +----------+--------------+------------+--------+-------------------------+------------------------+



    select * From tmp_update_gid;

    ---- drop table tmp_update_gid purge;

    create table tmp_update_gid as
        select distinct
               GUARANTEE_ID_9 || substr(GUARANTEE_ID, 17, 2) || cell_cd as newgid,
               DROP_DT,
               BUNDLE_KEY
        from BUNDLE_DIM
             join p_criteria_dim cri using (criteria_key)
        join CAMPAIGN_SPOOL_FILE_TBL
        using (bundle_key)
        join campaign_participation_fct
        using (bundle_key)
        join p_cell_dim
        using(cell_key)
        where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
          and brand_full_desc = 'Bosch'
          and substr(GUARANTEE_ID, 7, 3) = 'BSH';
--[2024-10-30 15:22:29] 40,568 rows affected in 1 s 660 ms


select GUARANTEE_ID ,  newgid,
           MAIL_DROP_DATE , drop_dt,
           EST_MAIL_IN_HOME_DT , drop_dt + 7,
           EMAIL_START_DT , DROP_DT + 8,
           OFFER_EXPIRE_DT , DROP_DT + 41,COUNT(*) CNT, Count(distinct tmp.BUNDLE_KEY)
from CAMPAIGN_SPOOL_FILE_TBL csft join  tmp_update_gid tmp
    on     csft.BUNDLE_KEY = tmp.BUNDLE_KEY
 where MAIL_DROP_DATE <> drop_dt
GROUP BY  GUARANTEE_ID ,  newgid,
           MAIL_DROP_DATE , drop_dt,
           EST_MAIL_IN_HOME_DT , drop_dt + 7,
           EMAIL_START_DT , DROP_DT + 8,
           OFFER_EXPIRE_DT , DROP_DT + 41
;
-- +--------------------+--------------------+--------------+----------+-------------------+----------+--------------+----------+---------------+----------+-----+-----------------------------+
-- |GUARANTEE_ID        |NEWGID              |MAIL_DROP_DATE|DROP_DT   |EST_MAIL_IN_HOME_DT|DROP_DT+7 |EMAIL_START_DT|DROP_DT+8 |OFFER_EXPIRE_DT|DROP_DT+41|CNT  |COUNT(DISTINCTTMP.BUNDLE_KEY)|
-- +--------------------+--------------------+--------------+----------+-------------------+----------+--------------+----------+---------------+----------+-----+-----------------------------+
-- |202446BSHE200001M101|202447BSHE200001M101|2024-11-19    |2024-11-26|2024-11-26         |2024-12-03|2024-11-27    |2024-12-04|2024-12-30     |2025-01-06|5925 |5925                         |
-- |202446BSHE200002M101|202447BSHE200002M101|2024-11-19    |2024-11-26|2024-11-26         |2024-12-03|2024-11-27    |2024-12-04|2024-12-30     |2025-01-06|2724 |2724                         |
-- |202446BSHE200002B101|202447BSHE200002B101|2024-11-19    |2024-11-26|2024-11-26         |2024-12-03|2024-11-27    |2024-12-04|2024-12-30     |2025-01-06|26702|13351                        |
-- +--------------------+--------------------+--------------+----------+-------------------+----------+--------------+----------+---------------+----------+-----+-----------------------------+
    merge into CAMPAIGN_SPOOL_FILE_TBL csft
    using  tmp_update_gid tmp
    on     (csft.BUNDLE_KEY = tmp.BUNDLE_KEY)
    when matched then
    update
    set    GUARANTEE_ID =  newgid,
           MAIL_DROP_DATE = drop_dt,
           EST_MAIL_IN_HOME_DT = drop_dt + 7,
           EMAIL_START_DT = DROP_DT + 8,
           OFFER_EXPIRE_DT = DROP_DT + 41
    where MAIL_DROP_DATE <> drop_dt
    ;
    -- [2024-10-30 15:29:04] 35,351 rows affected in 1 s 651 ms  --including emails

select GUARANTEE_ID ,  newgid,
           MAIL_DROP_DATE , drop_dt,
           EST_MAIL_IN_HOME_DT , drop_dt + 7,
           EMAIL_START_DT , DROP_DT + 8,
           OFFER_EXPIRE_DT , DROP_DT + 41,COUNT(*) CNT, Count(distinct tmp.BUNDLE_KEY)
from CAMPAIGN_SPOOL_FILE_TBL csft join  tmp_update_gid tmp
    on     csft.BUNDLE_KEY = tmp.BUNDLE_KEY
 --where MAIL_DROP_DATE <> drop_dt
GROUP BY  GUARANTEE_ID ,  newgid,
           MAIL_DROP_DATE , drop_dt,
           EST_MAIL_IN_HOME_DT , drop_dt + 7,
           EMAIL_START_DT , DROP_DT + 8,
           OFFER_EXPIRE_DT , DROP_DT + 41
;

--Find Bosch EB2 leads from first drop week
select CRITERIA_CD, DROP_DT, spl.MAIL_DROP_DATE,substr(GUARANTEE_ID, 7, 5), count(*), count(distinct  bundle_key)
  from bundle_dim bd join p_criteria_dim cri using (criteria_key)
       join CELL_SELECTION_FCT using (bundle_key)
       join CAMPAIGN_SPOOL_FILE_TBL spl using (bundle_key)
 where CRITERIA_CD like 'E2%' and CHANNEL_NM = 'MAIL'
   and bd.SUPPRESSION_CD is null
   and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
   and brand_full_desc = 'Bosch'
   and substr(GUARANTEE_ID, 7, 3) = 'BSH'  --Excluding counter top coffee makers (BSC)
   --and MAIL_DROP_DATE = date '2024-11-19'
 group by CRITERIA_CD, DROP_DT, spl.MAIL_DROP_DATE,substr(GUARANTEE_ID, 7, 5) order by CRITERIA_CD, substr(GUARANTEE_ID, 7, 5), DROP_DT;


select sup.suppression_cd, suppression_reason, count(*), count(distinct BUNDLE_KEY), sum(count(*)) over() as total
from suppression_tbl sup
   -- join BUNDLE_DIM using (bundle_key)
   where inserted_dt >= trunc(sysdate)--
   group by sup.suppression_cd, suppression_reason order by suppression_reason;
-- +--------------+----------------------------+--------+-------------------------+-----+
-- |SUPPRESSION_CD|SUPPRESSION_REASON          |COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|TOTAL|
-- +--------------+----------------------------+--------+-------------------------+-----+
-- |M             |Builder address without apt#|872     |872                      |1121 |
-- |M             |GGN Ambassador suppression  |3       |3                        |1121 |
-- |M             |GIDs not scheduled          |246     |246                      |1121 |
-- +--------------+----------------------------+--------+-------------------------+-----+

-- DELETE
-- FROM      boshstg.campaign_spool_file_tbl
-- WHERE   bundle_key IN
--                    ( SELECT sup.bundle_key FROM v_suppression_tbl sup
--                    );
--[2024-10-30 16:07:33] 15 rows affected in 8 s 486 ms

