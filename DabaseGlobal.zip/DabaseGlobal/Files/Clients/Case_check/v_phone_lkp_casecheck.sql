
select * from COMMON_LOAD_OUTPUT_TBL where UNIQUE_SEQ_NO =1813095;

SELECT * FROM v_phone_lkp WHERE phone_xid = 6823758;
--PHONE_KEY = 1558800

select * from gnrc.PHONE_DIM where PHONE_KEY = 1558800;


select * from gnrc.PHONE_DIM where PHONE_NO = '3134105678';
--PHONE_KEY = 1753742

SELECT * FROM v_phone_lkp WHERE PHONE_KEY = 1753742
UNION ALL
SELECT * FROM v_phone_lkp WHERE PHONE_KEY = 1558800;

-- PHONE_KEY,PHONE_XID,SOURCE_SYSTEM_CD,EXT_ID_TYPE_CD,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY
-- 1753742,3134105678,0,2,768114,
-- 1753742,86404441,2,1,768114,
-- 1558800,3134109088,0,2,673014,
-- 1558800,6823758,2,1,673014,


select  *   from GNRC.sync_process_status_tbl  where 1=1    and process_end_ts >= date '2022-08-12'    and lower(target_schema) = 'gnrcstg';

select t.*
  from GNRC.sync_process_status_tbl t
 where 1=1
   and process_end_ts >= date '2022-08-12' --and process_end_ts <= date '2020-09-02'
   and lower(target_schema) = 'gnrcstg'
--   and lower(target_schema) = 'gnrcexlwweb'
--    and status NOT IN ( 'IMPORTED','EXPORT_SKIPPED','EXPORTED','IMPORT_SKIPPED')
--     and TABLE_NAME = 'policy_tbl'
 order by process_start_ts desc;



SELECT vpx.VISITOR_KEY,
                          vpx.PHONE_KEY,
                          plkp.PHONE_XID,
                          plkp.SOURCE_SYSTEM_CD
                     FROM (SELECT VISITOR_KEY, PHONE_KEY
                             FROM (SELECT VISITOR_KEY,
                                          PHONE_KEY,
                                          ROW_NUMBER ()
                                          OVER (
                                             PARTITION BY VISITOR_KEY
                                             ORDER BY
                                                EFF_DT_KEY DESC,
                                                NVL (UPDATE_AUDIT_KEY,
                                                     INSERT_AUDIT_KEY) DESC)
                                             rno
                                     FROM visitor_phone_xref
                                    WHERE     PRIMARY_IND = 'N'
                                          AND END_DT_KEY = '99999')
                            WHERE rno = 1) vpx,
                          phone_lkp plkp
                    WHERE vpx.PHONE_KEY = plkp.PHONE_KEY and vpx.PHONE_KEY = 1558800;


select * from V_SYNC_CUSTOMER_DIM where CUSTOMER_ID= 2380262;

select * from visitor_phone_xref where PHONE_KEY = 1558800;
select * from phone_lkp where PHONE_KEY = 1558800;
select * from CUSTOMER_DIM where PRIMARY_PHONE_KEY = 1558800;

select * from USER_TAB_COLS where COLUMN_NAME like '%PHONE_KEY' order by TABLE_NAME;
--select * from BILLING_INFO_TBL where SECONDARY_PHONE_KEY = 1558800 ;-- 0 rows
--select * from BILLING_INFO_TBL where  PHONE_KEY = 1558800;-- 0 rows
--select * from CLAIM_DIM where SERVICE_PHONE_KEY = 1558800;-- 0 rows
--select * from CLAIM_OUTPUT_TBL_ARCH where SERVICE_PHONE_KEY = 1558800;-- 0 rows
--select * from COMMON_LOAD_OUTPUT_TBL_ARCH where PHONE_KEY = 1558800;
---select * from CUSTOMER_DIM where PRIMARY_PHONE_KEY = 1558800;-- 0 rows
--select * from CUSTOMER_PHONE_EXT where PHONE_KEY = 1558800;-- 0 rows
--select * from OB_PHONE_APPEND_INPUT_TBL where PHONE_KEY = 1558800;-- 0 rows
--select * from ORDER_OUTPUT_TBL_ARCH where BILLING_PHONE_KEY = 1558800;-- 0 rows
--select * from ORDER_OUTPUT_TBL_ARCH where BILL_SECONDARY_PHONE_KEY = 1558800;-- 0 rows
--select * from ORDER_OUTPUT_TBL_ARCH where SHIPPING_PHONE_KEY = 1558800;-- 0 rows
--select * from OUTBOUND_AVAIL_UNIVERSE_TBL where PRIMARY_PHONE_KEY = 1558800;-- 0 rows
select * from PHONE_DIM where PHONE_KEY = 1558800;-- 1 rows
--select * from PHONE_EXT_DIM where PHONE_KEY = 1558800;-- 0 rows
select * from PHONE_LKP where PHONE_KEY = 1558800;-- 2 rows
--select * from SHIPPING_INFO_TBL where PHONE_KEY = 1558800;-- 0 rows
select * from VISITOR_PHONE_LKP where PHONE_KEY = 1558800;-- 1 rows
select * from VISITOR_PHONE_XREF where PHONE_KEY = 1558800;-- 1 rows

--Delete from PHONE_DIM where PHONE_KEY = 1558800;

select *  from GNRC.sync_process_status_tbl  where 1=1 and RUN_ID = 78240 and TABLE_NAME = 'customer_tbl'   and process_end_ts >= date '2022-08-12';
--Delete from GNRC.sync_process_status_tbl  where 1=1 and RUN_ID = 78240 and TABLE_NAME = 'customer_tbl'   and process_end_ts >= date '2022-08-12';

select * from SYNC_PROCESS_MAPPING_TBL where TARGET_TABLE_NAME = 'CUSTOMER_TBL';

COMMIT;