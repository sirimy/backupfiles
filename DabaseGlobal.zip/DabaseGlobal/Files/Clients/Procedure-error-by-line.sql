SELECT line, type,position, text
FROM all_errors
WHERE owner = 'BOSHSTG'
  AND upper(name) = upper('BOSCH_LEADS_DATA_FOR_ASSURANT_EXTRACT')
  AND type = 'PROCEDURE'
ORDER BY sequence;