

select   s.latest_coverage_type , c.latest_coverage_type
    --count(*)
  from serialized_item_dim s
       join gnrc.serialized_item_dim c
          on c.si_key = s.si_key

 where (
       1=2
--    or s.purchase_dt_key <> c.purchase_dt_key  --00
--      or nvl(s.product_key, 1) <> nvl(c.product_key, 1)   --9
--       or s.warranty_expiration_dt <> c.warranty_expiration_dt --0
--      or s.registration_dt <> c.registration_dt               --0
       or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --1628
        or s.latest_coverage_type <> c.latest_coverage_type     --2120
    )  ;
-- total =2132


select distinct  s.latest_coverage_type , c.latest_coverage_type
    --count(*)
  from serialized_item_dim s
       join gnrc.serialized_item_dim c
          on c.si_key = s.si_key

 where (
       1=2
--    or s.purchase_dt_key <> c.purchase_dt_key  --00
--      or nvl(s.product_key, 1) <> nvl(c.product_key, 1)   --9
--       or s.warranty_expiration_dt <> c.warranty_expiration_dt --0
--      or s.registration_dt <> c.registration_dt               --0
       or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --1628
        or s.latest_coverage_type <> c.latest_coverage_type     --2120
    )  ;
-- total =2132
+--------------------+--------------------+
|LATEST_COVERAGE_TYPE|LATEST_COVERAGE_TYPE|
+--------------------+--------------------+
|1                   |7                   |
|1                   |18                  |
|1                   |5                   |
|1                   |21                  |
|1                   |6                   |
|1                   |17                  |
|1                   |2                   |
|1                   |19                  |
|1                   |20                  |
|1                   |1                   |
+--------------------+--------------------+


--Comparing diff in data between stg and core
--Main diff is in registration_dt but difficult to say, which one is correct.
select s.warranty_expiration_dt, c.warranty_expiration_dt, s.registration_dt, trunc(c.registration_dt)
       ,s.latest_coverage_exp_dt, c.latest_coverage_exp_dt
       ,s.latest_coverage_type, c.latest_coverage_type
  from serialized_item_dim s
       join gnrc.serialized_item_dim c
          on c.si_key = s.si_key
 where (1=2
--     or s.purchase_dt_key <> c.purchase_dt_key  --0
--     or s.product_key <> c.product_key   --0
--     or s.warranty_expiration_dt <> c.warranty_expiration_dt --
--     or s.registration_dt <> c.registration_dt               --
--     or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --
    or s.latest_coverage_type <> c.latest_coverage_type     --
    );



-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
    --Updating serial data
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

--set insert_audit_key from core for existing records
merge into serialized_item_dim tgt
using (
       select * from gnrc.serialized_item_dim src
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set tgt.insert_audit_key        = src.insert_audit_key
where tgt.insert_audit_key      <> src.insert_audit_key;
--706

--update serialized_item_dim to match with core (for existing records)
merge into serialized_item_dim tgt
using (
       select * from gnrc.serialized_item_dim src
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set
    tgt.purchase_dt_key         = src.purchase_dt_key,
    tgt.product_key             = src.product_key,
    tgt.MODEL_NO                = src.MODEL_NO,
    tgt.warranty_expiration_dt  = src.warranty_expiration_dt,
    tgt.registration_dt         = src.registration_dt,
    tgt.latest_coverage_exp_dt  = src.latest_coverage_exp_dt,
    tgt.latest_coverage_type    = src.latest_coverage_type
where (
       1=2
    or src.purchase_dt_key          <> tgt.purchase_dt_key  --0
    or src.product_key              <> tgt.product_key   --0
    or src.warranty_expiration_dt   <> tgt.warranty_expiration_dt --1
    or src.registration_dt          <> tgt.registration_dt               --666
    or src.latest_coverage_exp_dt   <> tgt.latest_coverage_exp_dt --814
    or src.latest_coverage_type     <> tgt.latest_coverage_type     --813
    );
--706 rows
commit;
