
select TRUNC(AD_CREATED_TS, 'YEAR'),COUNT(*) from ACE_LOAD_HOLD_TBL
group by TRUNC(AD_CREATED_TS, 'YEAR')
ORDER BY TRUNC(AD_CREATED_TS, 'YEAR')
;
+---------------------------+--------+
|TRUNC(AD_CREATED_TS,'YEAR')|COUNT(*)|
+---------------------------+--------+
|2017-01-01                 |5978    |
|2018-01-01                 |4743    |
|2019-01-01                 |3711    |
|2020-01-01                 |4184    |
|2021-01-01                 |4793    |
|2022-01-01                 |2976    |
|2023-01-01                 |7145    |
|2024-01-01                 |1678    |
+---------------------------+--------+


-- We are not populating visiter lkp in gnrc for source system code 0 and 1
     -- INSERT  INTO COMMON_LOAD_HOLD_TBL

select
--   ad.FIRM_NM,gad.FIRM_NM,
--         ad.FIRST_NM,gad.FIRST_NM,
--         ad.MIDDLE_NM,gad.MIDDLE_NM,
--         ad.LAST_NM,gad.LAST_NM,
--         ad.ADDRESS_LINE1_TX,gad.ADDRESS_LINE1_TX,
--         ad.ADDRESS_LINE2_TX,acel.ADDRESS_LINE2_TX,
--         ad.CITY_NM,gad.CITY_NM,
--         ad.STATE_CD,gad.STATE_CD,
--         ad.ZIP_CODE5_TX,gad.ZIP_CODE5_TX,
--         ad.ZIP_CODE4_TX,gad.ZIP_CODE4_TX
COUNT(*)
from ds_ace_output_tbl ad join  ACE_LOAD_HOLD_TBL acel
        on ad.UNIQUE_SEQ_NO = acel.UNIQUE_SEQ_NO
        join gnrc.ADDRESS_DIM gad on gad.ADDRESS_KEY = acel.ADDRESS_KEY

where
    (  1 <> 1
--     or   coalesce(ad.FIRM_NM,'xyz')  <> coalesce(gad.FIRM_NM,'xyz') -- 97
--    or coalesce(ad.FIRST_NM ,'xyz') <> coalesce(gad.FIRST_NM,'xyz') -- 85
--    or   coalesce(ad.MIDDLE_NM,'xyz')  <> coalesce(gad.MIDDLE_NM,'xyz') -- 20
--  or   coalesce(ad.LAST_NM,'xyz')  <> coalesce(gad.LAST_NM,'xyz') -- 187
--   or   coalesce(ad.ADDRESS_LINE2_TX,'xyz')  <> coalesce(gad.ADDRESS_LINE2_TX,'xyz') --61
--   or    coalesce(ad.CITY_NM ,'xyz') <> coalesce(gad.CITY_NM,'xyz') --55
--     or     coalesce(ad.ZIP_CODE5_TX,'xyz')  <> coalesce(gad.ZIP_CODE5_TX ,'xyz')-- 146
--       or    coalesce(ad.ZIP_CODE4_TX,'xyz')   <> coalesce(gad.ZIP_CODE4_TX,'xyz')  --new 6522  and old 11366
--   or     coalesce(ad.STATE_CD,'xyz')   <> coalesce(gad.STATE_CD,'xyz')  -- 0
    )
ORDER BY DBMS_RANDOM.RANDOM()
;
-- address key changes then is new customer create
     --here we are checking if on address key change is proces generate new customer key or it just update primary key and allow
     -- same customer key so need to verify here

--
-- #Now compare the two keys retrived by two lookups and populate the customer key
--
-- ##Condition 1 if both the keys are equal assign one of the key as customer key
-- '$customer_key=$v_ext_key if($v_unique_key eq $v_ext_key)',
--
-- ##Condition 2 if external key is not null and natural key is either null or new value then assign external customer key as customer_key
-- '$customer_key=$v_ext_key if($v_unique_key ne $v_ext_key) && ($v_unique_key eq "" ||$v_unique_key eq 0) && ($v_ext_key ne "")',
--
-- ##Condition 3 if natural key is not null and external key  is either null or new value then assign natural's customer key as customer key
-- '$customer_key=$v_unique_key if($v_unique_key ne $v_ext_key) && ($v_ext_key eq "" ||$v_ext_key eq 0) && ($v_unique_key ne "")',
--
-- #Creating a new customer key is split into two steps
-- # First check if natural key is not null . If yes create a new key.
-- # This would make sure that if the same natural key comes in same file again it gets the same customer key from buffer

-- # Second if the natural key is null then create a new key based on external id.
-- # This would make sure if same external key  comes in same file it gets the same customer key from buffer



-- here zip4 need to check adddress key new created for these zip4 change counts
    -- here we checking if new adddress key is genrated due to zip4 change so means its used  in adddress hash keu generate
    --Result:
        --     	# Generate an address_hash_key using MD5.
        -- 		'$address_string = (	$IN_FIRM_NM . $IN_FIRST_NM . $IN_MIDDLE_NM . $IN_LAST_NM .
        -- 	  	$IN_ADDRESS_LINE1_TX . $IN_ADDRESS_LINE2_TX . $IN_CITY_NM .
        -- 			$IN_STATE_CD . $IN_ZIP_CODE5_TX . $IN_ZIP_CODE4_TX	)',
        -- 		'use Digest::MD5 qw(md5_hex)',
        -- 		'use Encode qw(encode_utf8)',
        -- 		'$address_hash_key = md5_hex(encode_utf8($address_string))',




-- Other than zip4 what are total changes count
     -- here we see variation count of affect change by all other fields
     --result
        -- coalesce(ad.ZIP_CODE4_TX,'xyz')   <> coalesce(gad.ZIP_CODE4_TX,'xyz')  -- 11366
        -- other counts comes as = 467


--Those customer key where address key is different and customer key same-- those customers primary address key
        --here we like to see primary address key it updated for same customer key due to new address generated

select --s.primary_address_key, c.primary_address_key
       count(*)
   from customer_dim s
        join gnrc.customer_dim c
           on c.customer_key = s.customer_key
 where s.primary_address_key <> c.primary_address_key;
--6524
-- out of those new address keys which are not coming in these 6524 set
        -- here  we found new adddress key allot for 6k customers so we need to check if these address from new generated address keys
        -- or it also used any existing address key

 select count(*) from address_dim
                 where ADDRESS_KEY not in (select c.ADDRESS_KEY from GNRC.address_dim c)
                       AND ADDRESS_KEY in(
                            select  s.primary_address_key
                                from customer_dim s
                                join gnrc.customer_dim c
                                   on c.customer_key = s.customer_key
                            where s.primary_address_key <> c.primary_address_key)
;--6410
 select count(*) from address_dim
                 where ADDRESS_KEY in (select c.ADDRESS_KEY from GNRC.address_dim c)
                       AND ADDRESS_KEY in(
                            select  s.primary_address_key
                                from customer_dim s
                                join gnrc.customer_dim c
                                   on c.customer_key = s.customer_key
                            where s.primary_address_key <> c.primary_address_key)
;--113


select  s.primary_address_key,c.PRIMARY_ADDRESS_KEY from customer_dim s
                                join gnrc.customer_dim c on c.customer_key = s.customer_key
                            where s.primary_address_key <> c.primary_address_key
                                    and s.primary_address_key in (
                                                        select ADDRESS_KEY from address_dim
                                                         where ADDRESS_KEY in (select c.ADDRESS_KEY from GNRC.address_dim c)
                                                               AND ADDRESS_KEY in(
                                                                    select  s.primary_address_key
                                                                        from customer_dim s
                                                                        join gnrc.customer_dim c
                                                                           on c.customer_key = s.customer_key
                                                                    where s.primary_address_key <> c.primary_address_key)

                                                                    )    ;
+-------------------+-------------------+
|PRIMARY_ADDRESS_KEY|PRIMARY_ADDRESS_KEY|
+-------------------+-------------------+
|2029862            |377024             |
|1979226            |637428             |
|4840820            |339754             |
|5160452            |687510             |
|5038614            |168130             |
|4945372            |523646             |
|1421046            |429000             |
|4980450            |691256             |
|6659764            |219838             |
|6103080            |93792              |
+-------------------+-------------------+
select * from ADDRESS_DIM where ADDRESS_KEY = 2029862
UNION
select * from GNRC.ADDRESS_DIM where ADDRESS_KEY = 377024;
+-----------+-------+---------+--------+---------+-------+-----------------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX       |ADDRESS_LINE2_TX|CITY_NM  |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
+-----------+-------+---------+--------+---------+-------+-----------------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|377024     |NULL   |NULL     |MIKE    |NULL     |MELTON |423 HILL WICK ST       |NULL            |SHEFFIELD|AL      |35660       |7209        |N             |E412        |NULL    |A            |NULL                 |NULL       |9713      |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |HILL WICK        |423              |NULL   |NULL     |NULL       |NULL     |NULL         |1095            |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |1122          |
|2029862    |NULL   |NULL     |MIKE    |NULL     |MELTON |9770 OLD NATCHEUZ TRACE|NULL            |CHEROKEE |AL      |35616       |NULL        |N             |E421        |NULL    |A            |NULL                 |NULL       |10292     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |OLD NATCHEUZ     |9770             |NULL   |NULL     |NULL       |NULL     |NULL         |989762          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |
+-----------+-------+---------+--------+---------+-------+-----------------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
select * from ADDRESS_DIM where ADDRESS_KEY = 1979226
UNION
select * from GNRC.ADDRESS_DIM where ADDRESS_KEY = 637428;
+-----------+-------+---------+--------+---------+--------+----------------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM |ADDRESS_LINE1_TX      |ADDRESS_LINE2_TX|CITY_NM|STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
+-----------+-------+---------+--------+---------+--------+----------------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|637428     |NULL   |NULL     |CURTIS  |NULL     |CRADDOCK|16342 N 1680 RD       |NULL            |HOLLIS |OK      |73550       |NULL        |N             |E421        |NULL    |A            |NULL                 |NULL       |9573      |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |1680             |16342            |NULL   |NULL     |NULL       |NULL     |NULL         |1095            |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |1122          |
|1979226    |NULL   |NULL     |CURTISS |NULL     |CRADDOCK|16432 N COUNTY ROAD 80|NULL            |HOLLIS |OK      |73550       |NULL        |N             |E412        |NULL    |A            |NULL                 |NULL       |10250     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |COUNTY ROAD      |16432            |NULL   |NULL     |NULL       |NULL     |NULL         |989762          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |
+-----------+-------+---------+--------+---------+--------+----------------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
select * from ADDRESS_DIM where ADDRESS_KEY = 4840820
UNION
select * from GNRC.ADDRESS_DIM where ADDRESS_KEY = 339754;
+-----------+-------+---------+--------+---------+-----------+------------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM    |ADDRESS_LINE1_TX  |ADDRESS_LINE2_TX|CITY_NM  |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
+-----------+-------+---------+--------+---------+-----------+------------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|339754     |NULL   |NULL     |BORIS   |NULL     |KRUEGER    |84 PASTURE RD     |NULL            |GLENVILLE|NC      |28736       |NULL        |N             |E412        |NULL    |A            |NULL                 |NULL       |9506      |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |PASTURE          |84               |NULL   |NULL     |NULL       |NULL     |NULL         |1095            |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |1122          |
|4840820    |NULL   |NULL     |SIMS    |NULL     |VALLEY WELL|2037 PILOT KNOB RD|NULL            |GLENVILLE|NC      |28736       |NULL        |N             |E421        |NULL    |A            |NULL                 |NULL       |11460     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |PILOT KNOB       |2037             |NULL   |NULL     |NULL       |NULL     |NULL         |989762          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |
+-----------+-------+---------+--------+---------+-----------+------------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+


