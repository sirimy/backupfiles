
CREATE TABLE NCOA_DEBUG_ADDRESS_CHANGE_OCT2024  AS
(
        select distinct INPUT_FIRST_NM,
               INPUT_LAST_NM,
               STG_ADD,
               NCOA_INPUT_ADD,
               NCOA_OUT_ADD,
               RAW_ADD,
               EQUIPMENT,
               SI_KEY,
               MODEL_NO,
               PURCHASE_DATE,
                CITY_NM,NEW_CITY_NM,OWNER_CITY,
                STATE_CD,NEW_STATE_CD,OWNER_STATE
               from (
                SELECT upper(RLT.OWNER_NAME),AD1.ADDRESS_KEY,NUAT.ADDRESS_KEY,
                        AD1.FIRST_NM,NUAT.INPUT_FIRST_NM,
                        AD1.LAST_NM,NUAT.INPUT_LAST_NM,
                        AD1.ADDRESS_LINE1_TX STG_ADD,
                        NUAT2.INPUT_ADDRESS_LINE1_TX NCOA_INPUT_ADD,
                        NUAT.NEW_ADDRESS_LINE1_TX NCOA_OUT_ADD,
                        RLT.OWNER_ADDRESS1 RAW_ADD,
                        AD2.ADDRESS_LINE1_TX CORE_ADDD ,
                        RLT.EQUIPMENT,SI.LATEST_COVERAGE_TYPE LC_TYPE,SI.MODEL_NO ,SI.SI_KEY,RLT.PURCHASE_DATE,
                        AD1.CITY_NM,NUAT.NEW_CITY_NM,RLT.OWNER_CITY,
                        AD1.STATE_CD,NUAT.NEW_STATE_CD,RLT.OWNER_STATE,
                        AD1.ZIP_CODE5_TX,NUAT.NEW_ZIP_CODE5_TX,
                        AD1.ZIP_CODE4_TX,NUAT.NEW_ZIP_CODE4_TX
                from ADDRESS_DIM AD1
                                join ncoa_updated_address_tbl NUAT ON UPPER(NUAT.NEW_ADDRESS_LINE1_TX) = AD1.ADDRESS_LINE1_TX
                                                                      AND UPPER(NUAT.NEW_STATE_CD) = AD1.STATE_CD
                                                                      AND UPPER(NUAT.NEW_CITY_NM) = AD1.CITY_NM
                                                                      AND UPPER(NUAT.NEW_ZIP_CODE5_TX) = AD1.ZIP_CODE5_TX
                                                                      AND UPPER(NUAT.NEW_ZIP_CODE4_TX) = AD1.ZIP_CODE4_TX
                                JOIN GNRC.RAW_LEADS_TBL RLT ON  upper(RLT.OWNER_NAME) = AD1.FIRST_NM || ' ' || AD1.LAST_NM
                                                                    and upper(RLT.OWNER_STATE) = UPPER(NUAT.NEW_STATE_CD)
                                                                   -- and upper(RLT.OWNER_CITY) = UPPER(NUAT.NEW_CITY_NM)
                                LEFT join GNRC.SERIALIZED_ITEM_DIM SI on SI.SERIAL_NO = LTRIM(TRIM(RLT.EQUIPMENT),'0')
                                join GNRC.ADDRESS_DIM AD2 on AD2.ADDRESS_KEY =   NUAT.ADDRESS_KEY
                                join ncoa_updated_address_tbl NUAT2 on NUAT2.ADDRESS_KEY = NUAT.ADDRESS_KEY -- To get input address
                               -- join GNRC.ADDRESS_DIM AD3 on AD3.ADDRESS_KEY =   AD1.ADDRESS_KEY -- this address exist in core

                          where AD1.SOURCE_CD = 'NCOA' and
                                AD1.ADDRESS_KEY in (select AD.ADDRESS_KEY from GNRC.ADDRESS_DIM AD )
                                --AND AD1.ADDRESS_KEY = 24282
                                AND NUAT2.INPUT_FIRST_NM || NUAT2.INPUT_LAST_NM = NUAT.INPUT_FIRST_NM || NUAT.INPUT_LAST_NM
                                AND (upper(RLT.OWNER_CITY) =  upper(NUAT2.INPUT_CITY_NM) OR upper(RLT.OWNER_CITY) =  upper(NUAT.NEW_CITY_NM))
                                AND  NUAT2.INPUT_ADDRESS_LINE1_TX is not null
                          ORDER BY UPPER(RLT.OWNER_NAME),RLT.INSERT_AUDIT_KEY,AD1.ADDRESS_KEY
        ) A1
        where  INPUT_FIRST_NM || INPUT_LAST_NM in
               (

                     select  INPUT_FIRST_NM || INPUT_LAST_NM

                               from (
                                SELECT upper(RLT.OWNER_NAME),AD1.ADDRESS_KEY,NUAT.ADDRESS_KEY,
                                        AD1.FIRST_NM,NUAT.INPUT_FIRST_NM,
                                        AD1.LAST_NM,NUAT.INPUT_LAST_NM,
                                        AD1.ADDRESS_LINE1_TX STG_ADD,
                                        NUAT2.INPUT_ADDRESS_LINE1_TX NCOA_INPUT_ADD,
                                        NUAT.NEW_ADDRESS_LINE1_TX NCOA_OUT_ADD,
                                        RLT.OWNER_ADDRESS1 RAW_ADD,
                                        AD2.ADDRESS_LINE1_TX CORE_ADDD ,
                                        RLT.EQUIPMENT,SI.LATEST_COVERAGE_TYPE LC_TYPE,SI.MODEL_NO ,RLT.PURCHASE_DATE,
                                        AD1.CITY_NM,NUAT.NEW_CITY_NM,RLT.OWNER_CITY,
                                        AD1.STATE_CD,NUAT.NEW_STATE_CD,RLT.OWNER_STATE,
                                        AD1.ZIP_CODE5_TX,NUAT.NEW_ZIP_CODE5_TX,
                                        AD1.ZIP_CODE4_TX,NUAT.NEW_ZIP_CODE4_TX
                                from ADDRESS_DIM AD1
                                                join ncoa_updated_address_tbl NUAT ON UPPER(NUAT.NEW_ADDRESS_LINE1_TX) = AD1.ADDRESS_LINE1_TX
                                                                                      AND UPPER(NUAT.NEW_STATE_CD) = AD1.STATE_CD
                                                                                      AND UPPER(NUAT.NEW_CITY_NM) = AD1.CITY_NM
                                                                                      AND UPPER(NUAT.NEW_ZIP_CODE5_TX) = AD1.ZIP_CODE5_TX
                                                                                      AND UPPER(NUAT.NEW_ZIP_CODE4_TX) = AD1.ZIP_CODE4_TX
                                                JOIN GNRC.RAW_LEADS_TBL RLT ON  upper(RLT.OWNER_NAME) = AD1.FIRST_NM || ' ' || AD1.LAST_NM
                                                                                    and upper(RLT.OWNER_STATE) = UPPER(NUAT.NEW_STATE_CD)
                                                                                   -- and upper(RLT.OWNER_CITY) = UPPER(NUAT.NEW_CITY_NM)
                                                LEFT join GNRC.SERIALIZED_ITEM_DIM SI on SI.SERIAL_NO = LTRIM(TRIM(RLT.EQUIPMENT),'0')
                                                join GNRC.ADDRESS_DIM AD2 on AD2.ADDRESS_KEY =   NUAT.ADDRESS_KEY
                                                join ncoa_updated_address_tbl NUAT2 on NUAT2.ADDRESS_KEY = NUAT.ADDRESS_KEY -- To get input address
                                               -- join GNRC.ADDRESS_DIM AD3 on AD3.ADDRESS_KEY =   AD1.ADDRESS_KEY -- this address exist in core

                                          where AD1.SOURCE_CD = 'NCOA' and
                                                AD1.ADDRESS_KEY in (select AD.ADDRESS_KEY from GNRC.ADDRESS_DIM AD )
                                                --AND AD1.ADDRESS_KEY = 24282
                                                AND NUAT2.INPUT_FIRST_NM || NUAT2.INPUT_LAST_NM = NUAT.INPUT_FIRST_NM || NUAT.INPUT_LAST_NM
                                                AND (upper(RLT.OWNER_CITY) =  upper(NUAT2.INPUT_CITY_NM) OR upper(RLT.OWNER_CITY) =  upper(NUAT.NEW_CITY_NM))
                                                AND  NUAT2.INPUT_ADDRESS_LINE1_TX is not null
                                          ORDER BY UPPER(RLT.OWNER_NAME),RLT.INSERT_AUDIT_KEY,AD1.ADDRESS_KEY
                        ) B1 Group By   INPUT_FIRST_NM || INPUT_LAST_NM
                             Having COUNT(*) > 1

                   )

);


    select   --CD.CUSTOMER_KEY,NCOA.SI_KEY,CD.PRIMARY_ADDRESS_KEY,AD.ADDRESS_LINE1_TX,NCOA.*
            COUNT(*),COUNT(distinct CD.CUSTOMER_KEY ),COUNT( distinct  NCOA.SI_KEY)
    from NCOA_DEBUG_ADDRESS_CHANGE_OCT2024 NCOA
             join GNRC.VISITOR_OWNERSHIP_XREF OX on OX.SI_KEY = NCOA.SI_KEY  AND OX.PRIMARY_IND = 'Y'
             join GNRC.CUSTOMER_DIM CD on CD.PRIMARY_VISITOR_KEY = OX.VISITOR_KEY
             join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
    ORDER BY INPUT_FIRST_NM || INPUT_LAST_NM
;--331
+--------+------------------------------+--------------------------+
|COUNT(*)|COUNT(DISTINCTCD.CUSTOMER_KEY)|COUNT(DISTINCTNCOA.SI_KEY)|
+--------+------------------------------+--------------------------+
|354     |307                           |333                       |
+--------+------------------------------+--------------------------+



    select   CD.CUSTOMER_KEY,NCOA.SI_KEY,CD.PRIMARY_ADDRESS_KEY,AD.ADDRESS_LINE1_TX,NCOA.*
    from NCOA_DEBUG_ADDRESS_CHANGE_OCT2024 NCOA
             join GNRC.VISITOR_OWNERSHIP_XREF OX on OX.SI_KEY = NCOA.SI_KEY  AND OX.PRIMARY_IND = 'Y'
             join GNRC.CUSTOMER_DIM CD on CD.PRIMARY_VISITOR_KEY = OX.VISITOR_KEY
             join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
    ORDER BY INPUT_FIRST_NM || INPUT_LAST_NM







