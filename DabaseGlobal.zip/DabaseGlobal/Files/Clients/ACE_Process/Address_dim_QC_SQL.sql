 select count(*) from address_dim
 union all
 select count(*) from address_dim where ADDRESS_KEY in (select c.ADDRESS_KEY from bosh.address_dim c)
 union all
 select count(*) from address_dim where ADDRESS_KEY not in (select c.ADDRESS_KEY from bosh.address_dim c);
/*
--10740   --total addresses in stg
-- 3198   --existing addresses
-- 7542   --new addresses
*/
+--------+
|COUNT(*)|
+--------+
|10740   |
|3209    |
|7531    |
+--------+
+--------+
|COUNT(*)|
+--------+
|11266   |
|4011    |
|7255    |
+--------+

select * from address_dim
         where ADDRESS_KEY not in (select c.ADDRESS_KEY from bosh.address_dim c)
;
-- +-----------+-------+---------+--------+---------+--------+----------------------------------+----------------+--------------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM |ADDRESS_LINE1_TX                  |ADDRESS_LINE2_TX|CITY_NM             |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
-- +-----------+-------+---------+--------+---------+--------+----------------------------------+----------------+--------------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |13224704   |NULL   |NULL     |MICHAEL |NULL     |RASA    |31420 WILLOW CREEK RD             |NULL            |STEAMBOAT SPRINGS   |CO      |80487       |9240        |N             |S90000      |NULL    |A            |NULL                 |NULL       |10436     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |WILLOW CREEK     |31420            |NULL   |NULL     |NULL       |NULL     |Y            |820097          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |
-- |13219974   |NULL   |NULL     |MARY    |NULL     |HUEGEL  |1184 VILLAGE GREEN UNIT 46 UNIT 46|UNIT 46         |WILLIAMSBURG        |VA      |23185       |NULL        |N             |E421        |NULL    |A            |NULL                 |NULL       |11833     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |VILLAGE          |1184             |46     |NULL     |NULL       |NULL     |NULL         |820097          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |
-- |13224214   |NULL   |NULL     |C.      |NULL     |SCHULTZ |21030 MEMORY LN                   |NULL            |BULLARD             |TX      |75757       |1332        |N             |S80000      |NULL    |A            |NULL                 |NULL       |12358     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |MEMORY           |21030            |NULL   |NULL     |NULL       |NULL     |Y            |820097          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |
-- |13217542   |NULL   |NULL     |ANDREW  |NULL     |MATTHEWS|68 MASSCHUSETTS RD                |NULL            |WEST BOOTHBAY HARBOR|ME      |04575       |1722        |N             |S88000      |NULL    |A            |NULL                 |NULL       |10351     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |MASSCHUSETTS     |68               |NULL   |NULL     |NULL       |NULL     |N            |820097          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |
-- |13223080   |NULL   |NULL     |CECELIA |NULL     |MAIOGAN |1071 LISMORE DR                   |NULL            |DES PLAINES         |IL      |60016       |8707        |N             |S80000      |NULL    |A            |NULL                 |NULL       |10737     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |LISMORE          |1071             |NULL   |NULL     |NULL       |NULL     |Y            |820097          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |
-- +-----------+-------+---------+--------+---------+--------+----------------------------------+----------------+--------------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+

select * from bosh.address_dim where FIRST_NM like '%C.%'  and LAST_NM like '%SCHULTZ%';
+-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX|ADDRESS_LINE2_TX|CITY_NM|STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |12494920   |NULL   |NULL     |C.      |NULL     |SCHULTZ|21030 MEMORY LN |NULL            |BULLARD|TX      |75757       |NULL        |N             |E421        |NULL    |A            |NULL                 |NULL       |12358     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |MEMORY           |21030            |NULL   |NULL     |NULL       |NULL     |NULL         |745517          |746748          |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |746748        |
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |13224214   |NULL   |NULL     |C.      |NULL     |SCHULTZ|21030 MEMORY LN |NULL            |BULLARD|TX      |75757       |1332        |N             |S80000      |NULL    |A            |NULL                 |NULL       |12358     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |MEMORY           |21030            |NULL   |NULL     |NULL       |NULL     |Y            |820097          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |

select * from bosh.address_dim where FIRST_NM like '%MARY%'  and LAST_NM like '%HUEGEL%';
-- +-----------+-------+---------+--------+---------+-------+--------------------------+----------------+------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX          |ADDRESS_LINE2_TX|CITY_NM     |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
-- +-----------+-------+---------+--------+---------+-------+--------------------------+----------------+------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |10666438   |NULL   |NULL     |MARY    |NULL     |HUEGEL |1184 VILLAGE GREEN UNIT 46|UNIT 46         |WILLIAMSBURG|VA      |23185       |NULL        |N             |E421        |NULL    |A            |NULL                 |NULL       |11833     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |VILLAGE          |1184             |46     |NULL     |NULL       |NULL     |NULL         |558297          |596255          |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |596255        |
-- +-----------+-------+---------+--------+---------+-------+--------------------------+----------------+------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+



select * from bosh.address_dim where FIRST_NM like '%MICHAEL%'  and LAST_NM like '%RASA%';
-- +-----------+-------+---------+--------+---------+-------+-----------------------+----------------+-----------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX       |ADDRESS_LINE2_TX|CITY_NM          |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
-- +-----------+-------+---------+--------+---------+-------+-----------------------+----------------+-----------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |4269504    |NULL   |NULL     |MICHAEL |NULL     |RASA   |31420 WILLOW CREEK ROAD|NULL            |STEAMBOAT SPRINGS|CO      |80477       |NULL        |N             |E421        |NULL    |A            |NULL                 |NULL       |10436     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |WILLOW CREEK     |31420            |NULL   |NULL     |NULL       |NULL     |NULL         |159061          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |159064        |
-- +-----------+-------+---------+--------+---------+-------+-----------------------+----------------+-----------------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |13224704   |NULL   |NULL     |MICHAEL |NULL     |RASA    |31420 WILLOW CREEK RD             |NULL            |STEAMBOAT SPRINGS   |CO      |80487       |9240        |N             |S90000      |NULL    |A            |NULL                 |NULL       |10436     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |WILLOW CREEK     |31420            |NULL   |NULL     |NULL       |NULL     |Y            |820097          |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |NULL          |


select ad.ADDRESS_LINE1_TX,bad.ADDRESS_LINE1_TX
,ad.ADDRESS_LINE2_TX,bad.ADDRESS_LINE2_TX
---,ad.CITY_NM,bad.CITY_NM
--,ad.STATE_CD,bad.STATE_CD
--,ad.ZIP_CODE5_TX,bad.ZIP_CODE5_TX
,ad.ZIP_CODE4_TX,bad.ZIP_CODE4_TX
from address_dim ad
         join bosh.ADDRESS_DIM bad on ad.FIRST_NM = bad.FIRST_NM  and  ad.LAST_NM = bad.LAST_NM and  ad.MIDDLE_NM = bad.MIDDLE_NM
                                    and ad.ZIP_CODE5_TX = bad.ZIP_CODE5_TX  and  ad.STATE_CD = bad.STATE_CD and  ad.CITY_NM = bad.CITY_NM
         where ad.ADDRESS_KEY not in (select c.ADDRESS_KEY from bosh.address_dim c)
;

select * from ADDRESS_DIM where ADDRESS_LINE1_TX ='1441 DEEP WOOD DR'
union
select * from BOSH.ADDRESS_DIM where ADDRESS_LINE1_TX ='1441 DEEP WOOD DR';

+-----------+-------+---------+--------+---------+-------+-----------------+----------------+----------+--------+------------+------------+
|ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX |ADDRESS_LINE2_TX|CITY_NM   |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
+-----------+-------+---------+--------+---------+-------+-----------------+----------------+----------+--------+------------+------------+
|42616      |NULL   |NULL     |THOMAS  |F.       |SOROKA |1441 DEEP WOOD DR|NULL            |PITTSBURGH|PA      |15241       |3440        |
|13218840   |NULL   |NULL     |THOMAS  |NULL     |SOROKA |1441 DEEP WOOD DR|NULL            |PITTSBURGH|PA      |15241       |3440        |
+-----------+-------+---------+--------+---------+-------+-----------------+----------------+----------+--------+------------+------------+

-- select adr.*, creation_dt
select count(*)
  from address_dim adr join audit_tbl dd on dd.audit_key = adr.insert_audit_key
 where 1=1
   --and address_line1_tx is null
--   and address_line2_tx is not null
   and substr(ACE_ERROR_CD, 1, 1) = 'E'
--   and creation_dt >= date '2020-04-22'
 order by dbms_random.random;
--order by ADDRESS_LINE1_TX, ADDRESS_LINE2_TX, ADDRESS_KEY;

  --ADDRESS_LINE1_TX,ADDRESS_LINE2_TX,CITY_NM,STATE_CD,ZIP_CODE5_TX
--1327 OVERLOOK RD,,GREENSBORO,VT,05841
--276
--237


--records are with address and ACE_ERROR_CD is good
--data looks good

select --s.primary_address_key, c.primary_address_key
       count(*)
   from customer_dim  ;
--10669
--11189


--customers with change in address
select --s.primary_address_key, c.primary_address_key
       count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
 where s.primary_address_key <> c.primary_address_key;
--246
--279


--further checking how many of these may have a sale as in that case the address in core should be used
select --s.primary_address_key, c.primary_address_key
       count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
        join visitor_dim vd on vd.customer_key = s.customer_key
        join visitor_ownership_xref vox on vox.visitor_key = vd.visitor_key
        join serialized_item_dim si_stg on si_stg.si_key = vox.si_key
        join bosh.serialized_item_dim si_core on si_core.si_key = si_stg.si_key
 where s.primary_address_key <> c.primary_address_key
  and   si_core.latest_coverage_type in (2, 3);
--0 --good
--0--



--update in stg same addreskey as in cor if sales exist against him
merge into customer_dim tgt
using (
        select s.customer_key, c.primary_address_key
           from customer_dim s
                join bosh.customer_dim c
                   on c.customer_key = s.customer_key
                join visitor_dim vd on vd.customer_key = s.customer_key
                join visitor_ownership_xref vox on vox.visitor_key = vd.visitor_key
                join serialized_item_dim si_stg on si_stg.si_key = vox.si_key
                join bosh.serialized_item_dim si_core on si_core.si_key = si_stg.si_key
         where s.primary_address_key <> c.primary_address_key
          and   si_core.latest_coverage_type in (2, 3)
     ) src
     on (src.customer_key = tgt.customer_key)
when matched then
update
set    tgt.primary_address_key = src.primary_address_key
where  tgt.primary_address_key <> src.primary_address_key;
--0 rows

commit;
