

select count(*) from  ACE_LOAD_HOLD_TBL;--28096

select count(*) from COMMON_LOAD_HOLD_TBL;--28096

select count(*) from COMMON_LOAD_TBL;--28096

select count(*) from visitor_dim;--35082
select count(*) from visitor_lkp;--0
select count(*) from visitor_history_tbl;--34972
select count(*) from  address_dim;--34823
select count(*) from  address_lkp where SOURCE_SYSTEM_CD = 0;--6777

select SOURCE_SYSTEM_CD,COUNT(*) from  address_lkp group by  SOURCE_SYSTEM_CD;--0
+----------------+--------+
|SOURCE_SYSTEM_CD|COUNT(*)|
+----------------+--------+
|2               |6777    |
|0               |6777    |
+----------------+--------+


select count(*) from  visitor_address_xref;--34824
select count(*) from  visitor_address_lkp;--13698
select count(*) from  serialized_item_dim;--35208
select count(*) from  serialized_item_lkp;--0
select count(*) from  visitor_ownership_xref;--42520
select count(*) from  email_lkp;--0
select count(*) from  email_dim;--21806
select count(*) from  visitor_email_xref;--22028
select count(*) from  visitor_email_lkp;--71
select count(*) from  phone_dim;--32885
select count(*) from  phone_lkp;--0
select count(*) from  visitor_phone_xref;--33323
select count(*) from  visitor_phone_lkp;--48
select count(*) from  VISITOR_PREFERENCE_TBL;--90160
select count(*) from  purl_dim;--34823
select count(*) from  VISITOR_PURL_XREF;--57898
select count(*) from  CUSTOMER_DIM;--34592
select count(*) from  HOUSEHOLD_LKP;--0
select count(*) from  CUSTOMER_LKP;--34592
select * from  CUSTOMER_LKP;--34592

select count(*) from ADDRESS_OUTPUT_TBL;--28096
select count(*) from ds_ace_output_tbl;--28096

select dsa.ADDRESS_LINE1_TX,dsa.ZIP_CODE5_TX,
       dsa.ACE_ERROR_CD,
        acel.ADDRESS_LINE1_TX,acel.ZIP_CD_TX,
        acel.ACE_ERROR_CD
from ds_ace_output_tbl dsa join  ACE_LOAD_HOLD_TBL acel
        on dsa.UNIQUE_SEQ_NO = acel.UNIQUE_SEQ_NO
where dsa.ACE_ERROR_CD  <> acel.ACE_ERROR_CD
;
select substr(ACE_ERROR_CD,1,1),count(*) from ds_ace_output_tbl group by substr(ACE_ERROR_CD,1,1);
+------------------------+--------+
|SUBSTR(ACE_ERROR_CD,1,1)|COUNT(*)|
+------------------------+--------+
|E                       |20910   |
|S                       |7185    |
|NULL                    |1       |
+------------------------+--------+

select substr(ACE_ERROR_CD,1,1),count(*) from ACE_LOAD_HOLD_TBL group by substr(ACE_ERROR_CD,1,1);
+------------------------+--------+
|SUBSTR(ACE_ERROR_CD,1,1)|COUNT(*)|
+------------------------+--------+
|E                       |28096   |
+------------------------+--------+


select count(*) from SI_OUTPUT_TBL;--28096
select count(*) from CUSTOMER_OUTPUT_TBL;

select count(*) from visitor_dim;--0
select count(*) from visitor_lkp;--0
select count(*) from visitor_history_tbl;--0
select count(*) from  address_dim;--0
select count(*) from  address_lkp;--0
select count(*) from  visitor_address_xref;--0
select count(*) from  visitor_address_lkp;--0
select count(*) from  serialized_item_dim;--0
select count(*) from  serialized_item_lkp;--0
select count(*) from  visitor_ownership_xref;--0
select count(*) from  email_lkp;--0
select count(*) from  email_dim;--0
select count(*) from  visitor_email_xref;--0
select count(*) from  visitor_email_lkp;--0
select count(*) from  phone_dim;--0
select count(*) from  phone_lkp;--0
select count(*) from  visitor_phone_xref;--0
select count(*) from  visitor_phone_lkp;--0
select count(*) from  VISITOR_PREFERENCE_TBL;--0
select count(*) from  purl_dim;--0
select count(*) from  VISITOR_PURL_XREF;--0
select count(*) from  CUSTOMER_DIM;--0
select count(*) from  HOUSEHOLD_LKP;--0
select count(*) from  CUSTOMER_LKP;--0

select substr(ACE_ERROR_CD,1,1),count(*) from  address_dim group by substr(ACE_ERROR_CD,1,1);

select substr(ACE_ERROR_CD,1,1),count(*) from ds_ace_output_tbl group by substr(ACE_ERROR_CD,1,1);



select dsa.ADDRESS_LINE1_TX,dsa.ZIP_CODE5_TX,
       dsa.ACE_ERROR_CD,
        acel.ADDRESS_LINE1_TX,acel.ZIP_CD_TX,
        acel.ACE_ERROR_CD
from ds_ace_output_tbl dsa join  ACE_LOAD_HOLD_TBL acel
        on dsa.UNIQUE_SEQ_NO = acel.UNIQUE_SEQ_NO
where dsa.ACE_ERROR_CD  <> acel.ACE_ERROR_CD
;


