--NCOA insert key for latest NCOA process
select  NCO.INSERT_AUDIT_KEY,AT2.CREATION_DT,COUNT(*)  from GNRC.NCOA_UPDATED_ADDRESS_TBL NCO
    join AUDIT_TBL AT2 on NCO.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
Where    AT2.CREATION_DT > date '2024-08-01'
group by NCO.INSERT_AUDIT_KEY,AT2.CREATION_DT;
+----------------+--------------------------+--------+
|INSERT_AUDIT_KEY|CREATION_DT               |COUNT(*)|
+----------------+--------------------------+--------+
|986575          |2024-08-06 16:57:36.000000|195647  |
+----------------+--------------------------+--------+


-- GET Address insert key for NCOA
select * from AUDIT_TBL where PROGRAM_NM = 'NCOA' AND TABLE_NM = 'ADDRESS_DIM' AND CREATION_DT > date '2024-08-01'
                        order by AUDIT_KEY;
+---------+--------------------------+----------+------------------+-----------------+-------------------------+--------+---------+----------+--------------+-----------+
|AUDIT_KEY|CREATION_DT               |PROGRAM_NM|PROGRAM_VERSION_NO|TRANSFORMATION_NM|TRANSFORMATION_VERSION_NO|USER_NM |AUTHOR_NM|PROCESS_NM|DESCRIPTIVE_TX|TABLE_NM   |
+---------+--------------------------+----------+------------------+-----------------+-------------------------+--------+---------+----------+--------------+-----------+
|986570   |2024-08-06 16:57:27.000000|NCOA      |1.0               |NULL             |1.0                      |gnrc-etl|GNRC     |NULL      |NULL          |ADDRESS_DIM|
+---------+--------------------------+----------+------------------+-----------------+-------------------------+--------+---------+----------+--------------+-----------+


select COUNT(*)  from GNRC.NCOA_UPDATED_ADDRESS_TBL where INSERT_AUDIT_KEY =    986575;--195647

select COUNT(*)  from GNRC.ADDRESS_DIM where UPDATE_AUDIT_KEY =    986570;--195330

select COUNT(*)  from GNRC.ADDRESS_DIM where SOURCE_CD = 'NCOA' AND UPDATE_AUDIT_KEY =    986570;--1606


select COUNT(*)  from GNRC.ADDRESS_DIM where SOURCE_CD = 'NCOA' AND UPDATE_AUDIT_KEY =    986570 and ADDRESS_LINE2_TX is not NULL ;--148


select  upper(RLT.OWNER_NAME),AD1.ADDRESS_KEY,NUAT.ADDRESS_KEY,
        AD1.FIRST_NM,NUAT.INPUT_FIRST_NM,
        AD1.LAST_NM,NUAT.INPUT_LAST_NM,
        AD1.ADDRESS_LINE1_TX STG_ADD,
        NUAT.INPUT_ADDRESS_LINE1_TX NCOA_INPUT_ADD,
        NUAT.NEW_ADDRESS_LINE1_TX NCOA_OUT_ADD,
        RLT.OWNER_ADDRESS1 RAW_ADD,
        --AD2.ADDRESS_LINE1_TX CORE_ADDD ,
        RLT.EQUIPMENT,SI.LATEST_COVERAGE_TYPE LC_TYPE,SI.MODEL_NO,SI.SI_KEY ,RLT.PURCHASE_DATE,
        AD1.CITY_NM,NUAT.NEW_CITY_NM,RLT.OWNER_CITY,
        AD1.STATE_CD,NUAT.NEW_STATE_CD,RLT.OWNER_STATE,
        AD1.ZIP_CODE5_TX,NUAT.NEW_ZIP_CODE5_TX,
        AD1.ZIP_CODE4_TX,NUAT.NEW_ZIP_CODE4_TX  from GNRC.ADDRESS_DIM
          AD1
                join GNRC.NCOA_UPDATED_ADDRESS_TBL NUAT ON UPPER(NUAT.NEW_ADDRESS_LINE1_TX) = AD1.ADDRESS_LINE1_TX  AND
                                                       upper(NUAT.INPUT_FIRST_NM) = AD1.FIRST_NM and upper(NUAT.INPUT_LAST_NM) =  AD1.LAST_NM
                                                      AND NUAT.INSERT_AUDIT_KEY = 986575
                                                      AND UPPER(NUAT.NEW_STATE_CD) = AD1.STATE_CD
--                                                        AND UPPER(NUAT.NEW_CITY_NM) = AD1.CITY_NM
--                                                        AND UPPER(NUAT.NEW_ZIP_CODE5_TX) = AD1.ZIP_CODE5_TX
--                                                        AND UPPER(NUAT.NEW_ZIP_CODE4_TX) = AD1.ZIP_CODE4_TX
                 LEFT JOIN GNRC.RAW_LEADS_TBL RLT ON  upper(RLT.OWNER_NAME) = AD1.FIRST_NM || ' ' || AD1.LAST_NM  and upper(RLT.OWNER_STATE) = UPPER(NUAT.NEW_STATE_CD)
                LEFT join GNRC.SERIALIZED_ITEM_DIM SI on SI.SERIAL_NO = LTRIM(TRIM(RLT.EQUIPMENT),'0')
                join AUDIT_TBL AT2 on AD1.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
          where SOURCE_CD = 'NCOA'
                AND AD1.UPDATE_AUDIT_KEY =    986570
                AND AT2.CREATION_DT < date '2024-08-01'-- To get Existing address key used by NCOA
                AND (upper(RLT.OWNER_CITY) =  upper(NUAT.INPUT_CITY_NM) OR upper(RLT.OWNER_CITY) =  upper(NUAT.NEW_CITY_NM)) ;--




-- To see SI current address
    select   CD.CUSTOMER_KEY, AD.SOURCE_CD,AD.FIRST_NM || AD.LAST_NM,SI.SI_KEY,CD.PRIMARY_ADDRESS_KEY,AD.ADDRESS_LINE1_TX,SI.MODEL_NO
            --COUNT(*),COUNT(distinct CD.CUSTOMER_KEY ),COUNT( distinct  NCOA.SI_KEY)
    from GNRC.SERIALIZED_ITEM_DIM SI
             join GNRC.VISITOR_OWNERSHIP_XREF OX on OX.SI_KEY = SI.SI_KEY  AND OX.PRIMARY_IND = 'Y'
             join GNRC.CUSTOMER_DIM CD on CD.PRIMARY_VISITOR_KEY = OX.VISITOR_KEY
             join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
    where SI.SI_KEY in (796813,1875494)
    ORDER BY  AD.FIRST_NM || AD.LAST_NM;