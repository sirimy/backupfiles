

select  -- s.latest_coverage_type , c.latest_coverage_type
    count(*)
  from serialized_item_dim s
       join bosh.serialized_item_dim c
          on c.si_key = s.si_key
--        left join serialized_item_ext_dim      sx  on sx.si_key = s.si_key
--        left join bosh.serialized_item_ext_dim cx  on cx.si_key = c.si_key
 where (
       1=2
--     or s.purchase_dt_key <> c.purchase_dt_key  --00
--      or nvl(s.product_key, 1) <> nvl(c.product_key, 1)   --00
      --or s.warranty_expiration_dt <> c.warranty_expiration_dt --0
--      or s.registration_dt <> c.registration_dt               --0
--       or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --0
       or s.latest_coverage_type <> c.latest_coverage_type     --0
--      or nvl(sx.duplicate_ind, 'N') <> nvl(cx.duplicate_ind, 'N')  --0
--         or sx.source <> cx.source                                 --0
    )  ;
-- total =127


select  -- s.latest_coverage_type , c.latest_coverage_type
    count(*)
  from serialized_item_dim s;--28045

select  -- s.latest_coverage_type , c.latest_coverage_type
    count(*)
  from bosh.serialized_item_dim s;--3147431


--From existing leads, checking how many are showing up with change in critical columns
--Very few are showing change in imp columns, which is good
select -- sx.registration_dt,cx.registration_dt,cx.registration_dt - sx.registration_dt
    --count(*)
    sx.source , cx.source
  from serialized_item_dim s
       join bosh.serialized_item_dim c
          on c.si_key = s.si_key
       left join serialized_item_ext_dim      sx  on sx.si_key = s.si_key
       left join bosh.serialized_item_ext_dim cx  on cx.si_key = c.si_key
 where (
       1=2
--     or s.purchase_dt_key <> c.purchase_dt_key  --0
  --   or nvl(s.product_key, 1) <> nvl(c.product_key, 1)   --0
 --    or s.warranty_expiration_dt <> c.warranty_expiration_dt --0
  --   or s.registration_dt <> c.registration_dt               --914
 --    or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --65
   --    or s.latest_coverage_type <> c.latest_coverage_type     --247
   or nvl(sx.duplicate_ind, 'N') <> nvl(cx.duplicate_ind, 'N')  --194
        or sx.source <> cx.source                                 --924
    ) and cx.registration_dt - sx.registration_dt > 14 and c.latest_coverage_type in (2,3);
--924 when compared on all the above columns together excluding duplicate_ind
--total 924 including diff in duplicate_ind







--Comparing diff in data between stg and core
--Main diff is in registration_dt but difficult to say, which one is correct.
select s.warranty_expiration_dt, c.warranty_expiration_dt, s.registration_dt, trunc(c.registration_dt)
       ,s.latest_coverage_exp_dt, c.latest_coverage_exp_dt
       ,s.latest_coverage_type, c.latest_coverage_type
  from serialized_item_dim s
       join bosh.serialized_item_dim c
          on c.si_key = s.si_key
 where (1=2
--     or s.purchase_dt_key <> c.purchase_dt_key  --0
--     or s.product_key <> c.product_key   --0
--     or s.warranty_expiration_dt <> c.warranty_expiration_dt --
--     or s.registration_dt <> c.registration_dt               --
--     or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --
    or s.latest_coverage_type <> c.latest_coverage_type     --
    );





-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
    --Updating serial data
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

--set insert_audit_key from core for existing records
merge into serialized_item_dim tgt
using (
       select * from bosh.serialized_item_dim src
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set tgt.insert_audit_key        = src.insert_audit_key
where tgt.insert_audit_key      <> src.insert_audit_key;
--706

--update serialized_item_dim to match with core (for existing records)
merge into serialized_item_dim tgt
using (
       select * from bosh.serialized_item_dim src
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set
    tgt.purchase_dt_key         = src.purchase_dt_key,
    tgt.product_key             = src.product_key,
    tgt.MODEL_NO                = src.MODEL_NO,
    tgt.warranty_expiration_dt  = src.warranty_expiration_dt,
    tgt.registration_dt         = src.registration_dt,
    tgt.latest_coverage_exp_dt  = src.latest_coverage_exp_dt,
    tgt.latest_coverage_type    = src.latest_coverage_type
where (
       1=2
    or src.purchase_dt_key          <> tgt.purchase_dt_key  --0
    or src.product_key              <> tgt.product_key   --0
    or src.warranty_expiration_dt   <> tgt.warranty_expiration_dt --1
    or src.registration_dt          <> tgt.registration_dt               --666
    or src.latest_coverage_exp_dt   <> tgt.latest_coverage_exp_dt --814
    or src.latest_coverage_type     <> tgt.latest_coverage_type     --813
    );
--706 rows
commit;
