--Melissa data NOCA process return extra rows for moved_on adddress so here we merge those
-- rows with input rows
MERGE --+ append
        INTO  NCOA_UPDATED_ADDRESS_TBL tbl1
        USING NCOA_UPDATED_ADDRESS_TBL tbl2
    on (tbl1.ADDRESS_KEY = tbl2.ADDRESS_KEY )
   WHEN MATCHED
   THEN
      UPDATE SET tbl1.NEW_ADDRESS_LINE1_TX = tbl2.NEW_ADDRESS_LINE1_TX,
                 tbl1.NEW_ADDRESS_LINE2_TX = tbl2.NEW_ADDRESS_LINE2_TX,
                 tbl1.NEW_CITY_NM = tbl2.NEW_CITY_NM,
                 tbl1.NEW_STATE_CD = tbl2.NEW_STATE_CD,
                 tbl1.NEW_ZIP_CODE5_TX = tbl2.NEW_ZIP_CODE5_TX,
                 tbl1.NEW_ZIP_CODE4_TX = tbl2.NEW_ZIP_CODE4_TX,
                 tbl1.NEW_DELIVERY_POINT_BAR_CD = tbl2.NEW_DELIVERY_POINT_BAR_CD,
                 tbl1.NEW_CHK_DIGIT_CD = tbl2.NEW_CHK_DIGIT_CD,
                 tbl1.NEW_CARRIER_ROUTE_NO = tbl2.NEW_CARRIER_ROUTE_NO,
                 tbl1.NEW_LINE_OF_TRAVEL = tbl2.NEW_LINE_OF_TRAVEL,
                tbl1.NEW_DPV_STATUS_CD = tbl2.NEW_DPV_STATUS_CD,
                tbl1.NEW_DPV_NOSTAT_CD = tbl2.NEW_DPV_NOSTAT_CD,
                tbl1.NEW_CASS_REC_TYPE_CD = tbl2.NEW_CASS_REC_TYPE_CD,
                tbl1.NEW_RECORD_TYPE_CD = tbl2.NEW_RECORD_TYPE_CD,
                tbl1.PUERTO_RICO_URBANIZATION_NM = tbl2.PUERTO_RICO_URBANIZATION_NM,
                tbl1.MOVE_TYPE_CD = tbl2.MOVE_TYPE_CD,
                tbl1.MOVE_EFFECTIVE_DT = tbl2.MOVE_EFFECTIVE_DT,
                tbl1.NCOA_RETURN_CD = tbl2.NCOA_RETURN_CD,
                tbl1.ANK_RETURN_CD = tbl2.ANK_RETURN_CD,
                tbl1.VISITOR_KEY = tbl2.VISITOR_KEY,
                tbl1.NEW_ADDRESS_KEY = tbl2.NEW_ADDRESS_KEY,
                tbl1.NEW_ADDRESS_IND = tbl2.NEW_ADDRESS_IND,
                tbl1.LOT_ORDER = tbl2.LOT_ORDER,
                tbl1.NEW_LOT_ORDER = tbl2.NEW_LOT_ORDER,
                tbl1.MOVER_DELIVERY_TYPE = tbl2.MOVER_DELIVERY_TYPE
where tbl1.INPUT_ADDRESS_LINE1_TX is not null and tbl1.NEW_ADDRESS_LINE1_TX is null
      and  tbl2.NEW_ADDRESS_LINE1_TX is not null  and tbl2.INPUT_ADDRESS_LINE1_TX is null
;

-- this ser we kept
select * from NCOA_UPDATED_ADDRESS_TBL tbl1
where tbl1.INPUT_ADDRESS_LINE1_TX is not null and tbl1.NEW_ADDRESS_LINE1_TX is not null
;


-- this set we will remove as these merged with upper set
select *  from NCOA_UPDATED_ADDRESS_TBL tbl1
where tbl1.INPUT_ADDRESS_LINE1_TX is null and tbl1.NEW_ADDRESS_LINE1_TX is not null
;

-- Now deleting the new/mover records received from Melissa Data after the merge above
delete  from NCOA_UPDATED_ADDRESS_TBL tbl1
where tbl1.INPUT_ADDRESS_LINE1_TX is null and tbl1.NEW_ADDRESS_LINE1_TX is not null
;

select COUNT(*) from NCOA_UPDATED_ADDRESS_TBL tbl1;--100