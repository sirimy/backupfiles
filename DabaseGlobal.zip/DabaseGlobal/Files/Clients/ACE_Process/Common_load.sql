
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'Populate Data for ACE', p_table_nm => 'COMMON_LOAD_HOLD_TBL');

BEGIN

     DELETE FROM ACE_LOAD_HOLD_TBL;


INSERT INTO ACE_LOAD_HOLD_TBL
      (
         UNIQUE_SEQ_NO
        ,SOURCE_SYSTEM_CD
        ,FIRST_NM
        ,MIDDLE_NM
        ,LAST_NM
        ,FIRM_NM
        ,ADDRESS_LINE1_TX
        ,ADDRESS_LINE2_TX
        ,CITY_NM
        ,STATE_CD
        ,ZIP_CD_TX
        ,COUNTRY_CD
        ,PRIMARY_PHONE_IND
        ,PHONE_NO
        ,EMAIL_ADDRESS_TX
        ,MODEL_NO
        ,SERIAL_NO
        ,SI_UNIQUE_ID
        ,PURCHASE_DT
        --    ,STORE_NO
        ,VISITOR_XID
        --    ,VISITOR_UNIQUE_ID
        --    ,EXTERNAL_VISITOR_TYPE_CD
        ,PRIMARY_ADDRESS_IND
        ,MAIL_PREF_IND
        ,EMAIL_PREF_IND
        ,PHONE_PREF_IND
        ,WARRANTY_EXPIRATION_DT
        --    ,LAST_UPDATED_LEADS_DT
        ,REGISTRATION_DT
        --    ,MODEL_QUALITY
        ,ADDRESS_XID
        ,EMAIL_XID
        --    ,PRIMARY_PHONE_XID
        --,SI_XID
        --    ,SMS_PREF_IND
        ,PURCHASE_AMT
        --    ,SI_TYPE_CD
        ,ADDRESS_UNIQUE_ID
        ,FILE_NM
        ,INSERT_AUDIT_KEY
        ,PRODUCT_UNIQUE_ID
        ,VISITOR_MATCH_IND
        ,SERIAL_MATCH_IND
        ,ADDR_MATCH_IND
        ,FIRM_MATCH_IND
        ,EMAIL_MATCH_IND
        ,PHONE_MATCH_IND
        --these two extra fields loaded in ACE hold table
        ,ADDRESS_KEY
        ,ACE_ERROR_CD
      )
select distinct  0 AS  UNIQUE_SEQ_NO
         ,1 AS  SOURCE_SYSTEM_CD
         ,ad.FIRST_NM AS  FIRST_NM
        ,ad.MIDDLE_NM AS  MIDDLE_NM
        ,ad.LAST_NM AS  LAST_NM
        ,ad.FIRM_NM AS  FIRM_NM
        ,ad.ADDRESS_LINE1_TX AS ADDRESS_LINE1_TX
        ,ad.ADDRESS_LINE2_TX AS  ADDRESS_LINE2_TX
        ,ad.CITY_NM AS CITY_NM
        ,ad.STATE_CD AS STATE_CD
        ,ad.ZIP_CODE5_TX AS  ZIP_CD_TX
        ,'' AS COUNTRY_CD
        ,'Y' PRIMARY_PHONE_IND
        ,pd.PHONE_NO PRIMARY_PHONE_NO
        ,ed.EMAIL_ADDRESS_TX AS EMAIL_ADDRESS_TX
        ,si.MODEL_NO
        ,si.SERIAL_NO
        ,slkp.SI_XID AS SI_UNIQUE_ID
        ,ddPURCHASE_DT.FULL_DT
        ,VL.VISITOR_XID  AS  VISITOR_XID
        ,'' AS  PRIMARY_ADDRESS_IND
        ,'' AS MAIL_PREF_IND
        ,'' AS EMAIL_PREF_IND
        ,'Y' AS PHONE_PREF_IND
        ,SI.WARRANTY_EXPIRATION_DT AS WARRANTY_EXPIRATION_DT
        ,SI.REGISTRATION_DT AS REGISTRATION_DT
     ,'' AS  ADDRESS_XID
     ,'' AS  EMAIL_XID
     ,'' AS  PURCHASE_AMT
     ,'' AS  ADDRESS_UNIQUE_ID
     ,'Manual_data_For_re_Process_ACE-BOSH-1663' AS FILE_NM
     ,v_audit_key AS INSERT_AUDIT_KEY
     ,si.MODEL_NO AS  PRODUCT_UNIQUE_ID
     ,'' AS  VISITOR_MATCH_IND
     ,'' AS  SERIAL_MATCH_IND
     ,'' AS  ADDR_MATCH_IND
     ,'' AS  FIRM_MATCH_IND
     ,'' AS  EMAIL_MATCH_IND
     ,'Y' AS  PHONE_MATCH_IND
    ,ad.ADDRESS_KEY
    ,ad.ACE_ERROR_CD
from bosh.cell_selection_fct cs join p_cell_dim using (cell_key)
       join bosh.bundle_dim bd on bd.BUNDLE_KEY = cs.BUNDLE_KEY
       join bosh.BUNDLE_ITEM_XREF bdx on bdx.BUNDLE_KEY = bd.BUNDLE_KEY
       join p_cell_group_dim using (cell_group_key)
       join fas.date_dim using (date_key)
       join bosh.SUPPRESSION_TBL sup on sup.BUNDLE_KEY = cs.BUNDLE_KEY
       join bosh.CUSTOMER_DIM cs on cs.CUSTOMER_KEY = bd.CUSTOMER_KEY
       join bosh.ADDRESS_DIM ad on ad.ADDRESS_KEY = cs.PRIMARY_ADDRESS_KEY
       left join bosh.PHONE_DIM pd on pd.PHONE_KEY = cs.PRIMARY_PHONE_KEY
       left join bosh.EMAIL_DIM ed on ed.EMAIL_KEY = cs.PRIMARY_EMAIL_KEY
       join bosh.SERIALIZED_ITEM_DIM si on si.SI_KEY = bdx.SI_KEY
       join bosh.SERIALIZED_ITEM_LKP slkp on si.SI_KEY = slkp.SI_KEY and slkp.SOURCE_SYSTEM_CD = 0
       join fas.date_dim ddPURCHASE_DT on ddPURCHASE_DT.date_key = si.PURCHASE_DT_KEY
       join bosh.VISITOR_LKP VL on VL.VISITOR_KEY = cs.PRIMARY_VISITOR_KEY and VL.SOURCE_SYSTEM_CD = 1
where 1=1
  and suppression_reason IN ('Ace error stat')
  and ad.ACE_ERROR_CD like 'E%'
  and bd.DROP_DT > sysdate - 1460 -- 4 years
  and regexp_like(ADDRESS_LINE1_TX, '[[:digit:]]') and regexp_like(ADDRESS_LINE1_TX, '[[:alpha:]]')
order by DBMS_RANDOM.RANDOM();
       COMMIT;


update ACE_LOAD_HOLD_TBL set unique_seq_no = unique_seq.nextval ;
   COMMIT;

    INSERT INTO COMMON_LOAD_HOLD_TBL
          (
             UNIQUE_SEQ_NO
            ,SOURCE_SYSTEM_CD
            ,FIRST_NM
            ,MIDDLE_NM
            ,LAST_NM
            ,FIRM_NM
            ,ADDRESS_LINE1_TX
            ,ADDRESS_LINE2_TX
            ,CITY_NM
            ,STATE_CD
            ,ZIP_CD_TX
            ,COUNTRY_CD
            ,PRIMARY_PHONE_IND
            ,PHONE_NO
            ,EMAIL_ADDRESS_TX
            ,MODEL_NO
            ,SERIAL_NO
            ,SI_UNIQUE_ID
            ,PURCHASE_DT
            --    ,STORE_NO
            ,VISITOR_XID
            --    ,VISITOR_UNIQUE_ID
            --    ,EXTERNAL_VISITOR_TYPE_CD
            ,PRIMARY_ADDRESS_IND
            ,MAIL_PREF_IND
            ,EMAIL_PREF_IND
            ,PHONE_PREF_IND
            ,WARRANTY_EXPIRATION_DT
            --    ,LAST_UPDATED_LEADS_DT
            ,REGISTRATION_DT
            --    ,MODEL_QUALITY
            ,ADDRESS_XID
            ,EMAIL_XID
            --    ,PRIMARY_PHONE_XID
            --,SI_XID
            --    ,SMS_PREF_IND
            ,PURCHASE_AMT
            --    ,SI_TYPE_CD
            ,ADDRESS_UNIQUE_ID
            ,FILE_NM
            ,INSERT_AUDIT_KEY
            ,PRODUCT_UNIQUE_ID
            ,VISITOR_MATCH_IND
            ,SERIAL_MATCH_IND
            ,ADDR_MATCH_IND
            ,FIRM_MATCH_IND
            ,EMAIL_MATCH_IND
            ,PHONE_MATCH_IND
          )
    SELECT

             UNIQUE_SEQ_NO
            ,SOURCE_SYSTEM_CD
            ,FIRST_NM
            ,MIDDLE_NM
            ,LAST_NM
            ,FIRM_NM
            ,ADDRESS_LINE1_TX
            ,ADDRESS_LINE2_TX
            ,CITY_NM
            ,STATE_CD
            ,ZIP_CD_TX
            ,COUNTRY_CD
            ,PRIMARY_PHONE_IND
            ,PHONE_NO
            ,EMAIL_ADDRESS_TX
            ,MODEL_NO
            ,SERIAL_NO
            ,SI_UNIQUE_ID
            ,PURCHASE_DT
            --    ,STORE_NO
            ,VISITOR_XID
            --    ,VISITOR_UNIQUE_ID
            --    ,EXTERNAL_VISITOR_TYPE_CD
            ,PRIMARY_ADDRESS_IND
            ,MAIL_PREF_IND
            ,EMAIL_PREF_IND
            ,PHONE_PREF_IND
            ,WARRANTY_EXPIRATION_DT
            --    ,LAST_UPDATED_LEADS_DT
            ,REGISTRATION_DT
            --    ,MODEL_QUALITY
            ,ADDRESS_XID
            ,EMAIL_XID
            --    ,PRIMARY_PHONE_XID
            --,SI_XID
            --    ,SMS_PREF_IND
            ,PURCHASE_AMT
            --    ,SI_TYPE_CD
            ,ADDRESS_UNIQUE_ID
            ,FILE_NM
            ,INSERT_AUDIT_KEY
            ,PRODUCT_UNIQUE_ID
            ,VISITOR_MATCH_IND
            ,SERIAL_MATCH_IND
            ,ADDR_MATCH_IND
            ,FIRM_MATCH_IND
            ,EMAIL_MATCH_IND
            ,PHONE_MATCH_IND FROM ACE_LOAD_HOLD_TBL;
   COMMIT;
END;