
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'Populate Data for ACE', p_table_nm => 'COMMON_LOAD_HOLD_TBL');

BEGIN

     DELETE FROM ACE_ADDRESS_ERROR_GNRC_1626;


INSERT INTO ACE_ADDRESS_ERROR_GNRC_1626
      (
        UNIQUE_SEQ_NO,
      SERIAL_NO,
      SI_UNIQUE_ID,
      PRODUCT_UNIQUE_ID,
      MODEL_NO,
     FIRST_NM
    ,MIDDLE_NM
    ,LAST_NM
    ,FIRM_NM
    ,ADDRESS_LINE1_TX
    ,ADDRESS_LINE2_TX
    ,CITY_NM
    ,STATE_CD
    ,ZIP_CD_TX,
      PHONE_NO,
      EMAIL_ADDRESS_TX,
      REGISTRATION_DT,
      WARRANTY_EXPIRATION_DT,
      PURCHASE_DT,
      EMAIL_MATCH_IND,
      PHONE_MATCH_IND,
      FILE_NM,
      SOURCE_SYSTEM_CD,
      INSERT_AUDIT_KEY,
      CURRENCY_CD
    ,ADDRESS_KEY
    ,ACE_ERROR_CD
    ,AD_CREATED_TS
    ,SI_KEY
      )
Select UNIQUE_SEQ_NO,
                              SERIAL_NO,
                              SI_UNIQUE_ID,
                              PRODUCT_UNIQUE_ID,
                              MODEL_NO,
                              FIRST_NM
                                ,MIDDLE_NM
                                ,LAST_NM
                                ,FIRM_NM
                                ,ADDRESS_LINE1_TX
                                ,ADDRESS_LINE2_TX
                                ,CITY_NM
                                ,STATE_CD
                                ,ZIP_CD_TX,
                              PHONE_NO,
                              EMAIL_ADDRESS_TX,
                              REGISTRATION_DT,
                              WARRANTY_EXPIRATION_DT,
                              PURCHASE_DT,
                              EMAIL_MATCH_IND,
                              PHONE_MATCH_IND,
                              FILE_NM,
                              SOURCE_SYSTEM_CD,
                              INSERT_AUDIT_KEY,
                              CURRENCY_CD
                                ,ADDRESS_KEY
                                ,ACE_ERROR_CD
                                ,CREATION_DT AS AD_CREATED_TS
                                ,SI_KEY
     From (
            select distinct  0 AS  UNIQUE_SEQ_NO
                 ,1 AS  SOURCE_SYSTEM_CD
                 ,ad.FIRST_NM AS  FIRST_NM
                ,ad.MIDDLE_NM AS  MIDDLE_NM
                ,ad.LAST_NM AS  LAST_NM
                ,ad.FIRM_NM AS  FIRM_NM
                ,ad.ADDRESS_LINE1_TX AS ADDRESS_LINE1_TX
                ,ad.ADDRESS_LINE2_TX AS  ADDRESS_LINE2_TX
                ,ad.CITY_NM AS CITY_NM
                ,ad.STATE_CD AS STATE_CD
                ,coalesce(ad.ZIP_CODE5_TX,'') || '-' || coalesce(ad.ZIP_CODE4_TX,'')  AS  ZIP_CD_TX
                ,'' AS COUNTRY_CD
                ,'Y' PRIMARY_PHONE_IND
                ,pd.PHONE_NO   AS PHONE_NO
                ,ed.EMAIL_ADDRESS_TX AS EMAIL_ADDRESS_TX
                ,si.MODEL_NO
                ,si.SERIAL_NO
                ,slkp.SI_XID AS SI_UNIQUE_ID
                ,ddPURCHASE_DT.FULL_DT AS PURCHASE_DT
                ,VL.VISITOR_XID  AS  VISITOR_XID
                ,'' AS  PRIMARY_ADDRESS_IND
                ,'' AS MAIL_PREF_IND
                ,'' AS EMAIL_PREF_IND
                ,'Y' AS PHONE_PREF_IND
                ,SI.WARRANTY_EXPIRATION_DT AS WARRANTY_EXPIRATION_DT
                ,SI.REGISTRATION_DT AS REGISTRATION_DT
             ,'' AS  ADDRESS_XID
             ,'' AS  EMAIL_XID
             ,'' AS  PURCHASE_AMT
             ,'' AS  ADDRESS_UNIQUE_ID
             ,'Manual_data_For_re_Process_ACE-gnrc-1663' AS FILE_NM
             ,v_audit_key AS INSERT_AUDIT_KEY
             ,si.MODEL_NO AS  PRODUCT_UNIQUE_ID
             ,'' AS  VISITOR_MATCH_IND
             ,'' AS  SERIAL_MATCH_IND
             ,'' AS  ADDR_MATCH_IND
             ,'' AS  FIRM_MATCH_IND
             ,'' AS  EMAIL_MATCH_IND
             ,'Y' AS  PHONE_MATCH_IND
             , ctry.DEFAULT_CURRENCY_CD AS CURRENCY_CD
            ,ad.ADDRESS_KEY
            ,ad.ACE_ERROR_CD
            ,atb.CREATION_DT
            ,si.SI_KEY
        from gnrc.cell_selection_fct cs join p_cell_dim using (cell_key)
               join gnrc.bundle_dim bd on bd.BUNDLE_KEY = cs.BUNDLE_KEY
               join gnrc.BUNDLE_ITEM_XREF bdx on bdx.BUNDLE_KEY = bd.BUNDLE_KEY
               join p_cell_group_dim using (cell_group_key)
               join fas.date_dim using (date_key)
               join gnrc.SUPPRESSION_TBL sup on sup.BUNDLE_KEY = cs.BUNDLE_KEY
               join gnrc.CUSTOMER_DIM cs on cs.CUSTOMER_KEY = bd.CUSTOMER_KEY
               join gnrc.ADDRESS_DIM ad on ad.ADDRESS_KEY = cs.PRIMARY_ADDRESS_KEY
               join AUDIT_TBL atb on atb.AUDIT_KEY = ad.INSERT_AUDIT_KEY
               left join gnrc.PHONE_DIM pd on pd.PHONE_KEY = cs.PRIMARY_PHONE_KEY
               left join gnrc.EMAIL_DIM ed on ed.EMAIL_KEY = cs.PRIMARY_EMAIL_KEY
               join gnrc.SERIALIZED_ITEM_DIM si on si.SI_KEY = bdx.SI_KEY
               left join gnrc.SERIALIZED_ITEM_LKP slkp on si.SI_KEY = slkp.SI_KEY and slkp.SOURCE_SYSTEM_CD = 0
               JOIN GNRC.V_PRODUCT VP ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
               join fas.date_dim ddPURCHASE_DT on ddPURCHASE_DT.date_key = si.PURCHASE_DT_KEY
               left join gnrc.VISITOR_LKP VL on VL.VISITOR_KEY = cs.PRIMARY_VISITOR_KEY
                  LEFT JOIN p_postal_state_dim psd
                            ON UPPER(TRIM(psd.postal_state_cd)) = UPPER(TRIM(ad.STATE_CD))
                         LEFT JOIN p_country_tbl ctry
                           ON ctry.country_key = psd.country_key
        where 1=1
          AND vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'
          AND ad.COUNTRY_CD = 'USA'
          and suppression_reason IN ('Ace error stat')
          and ad.ACE_ERROR_CD like 'E%'
          and ad.SOURCE_CD is NULL
          and bd.DROP_DT > sysdate  - (2*366) -- and bd.DROP_DT < sysdate - (1*366)
          and not ( regexp_like(ADDRESS_LINE1_TX, '[[:digit:]]')  and   regexp_like(ADDRESS_LINE1_TX, '[[:alpha:]]'))
        order by DBMS_RANDOM.RANDOM()

          )
;
       COMMIT;


update ACE_ADDRESS_ERROR_GNRC_1626 set unique_seq_no = unique_seq.nextval ;
   COMMIT;

    INSERT INTO COMMON_LOAD_HOLD_TBL
          (
             UNIQUE_SEQ_NO
            ,SOURCE_SYSTEM_CD
            ,FIRST_NM
            ,MIDDLE_NM
            ,LAST_NM
            ,FIRM_NM
            ,ADDRESS_LINE1_TX
            ,ADDRESS_LINE2_TX
            ,CITY_NM
            ,STATE_CD
            ,ZIP_CD_TX
            ,COUNTRY_CD
            ,PRIMARY_PHONE_IND
            ,PHONE_NO
            ,EMAIL_ADDRESS_TX
            ,MODEL_NO
            ,SERIAL_NO
            ,SI_UNIQUE_ID
            ,PURCHASE_DT
            --    ,STORE_NO
            ,VISITOR_XID
            --    ,VISITOR_UNIQUE_ID
            --    ,EXTERNAL_VISITOR_TYPE_CD
            ,PRIMARY_ADDRESS_IND
            ,MAIL_PREF_IND
            ,EMAIL_PREF_IND
            ,PHONE_PREF_IND
            ,WARRANTY_EXPIRATION_DT
            --    ,LAST_UPDATED_LEADS_DT
            ,REGISTRATION_DT
            --    ,MODEL_QUALITY
            ,ADDRESS_XID
            ,EMAIL_XID
            --    ,PRIMARY_PHONE_XID
            --,SI_XID
            --    ,SMS_PREF_IND
            ,PURCHASE_AMT
            --    ,SI_TYPE_CD
            ,ADDRESS_UNIQUE_ID
            ,FILE_NM
            ,INSERT_AUDIT_KEY
            ,PRODUCT_UNIQUE_ID
            ,VISITOR_MATCH_IND
            ,SERIAL_MATCH_IND
            ,ADDR_MATCH_IND
            ,FIRM_MATCH_IND
            ,EMAIL_MATCH_IND
            ,PHONE_MATCH_IND
          )
    SELECT

             UNIQUE_SEQ_NO
            ,SOURCE_SYSTEM_CD
            ,FIRST_NM
            ,MIDDLE_NM
            ,LAST_NM
            ,FIRM_NM
            ,ADDRESS_LINE1_TX
            ,ADDRESS_LINE2_TX
            ,CITY_NM
            ,STATE_CD
            ,ZIP_CD_TX
            ,COUNTRY_CD
            ,PRIMARY_PHONE_IND
            ,PHONE_NO
            ,EMAIL_ADDRESS_TX
            ,MODEL_NO
            ,SERIAL_NO
            ,SI_UNIQUE_ID
            ,PURCHASE_DT
            --    ,STORE_NO
            ,VISITOR_XID
            --    ,VISITOR_UNIQUE_ID
            --    ,EXTERNAL_VISITOR_TYPE_CD
            ,PRIMARY_ADDRESS_IND
            ,MAIL_PREF_IND
            ,EMAIL_PREF_IND
            ,PHONE_PREF_IND
            ,WARRANTY_EXPIRATION_DT
            --    ,LAST_UPDATED_LEADS_DT
            ,REGISTRATION_DT
            --    ,MODEL_QUALITY
            ,ADDRESS_XID
            ,EMAIL_XID
            --    ,PRIMARY_PHONE_XID
            --,SI_XID
            --    ,SMS_PREF_IND
            ,PURCHASE_AMT
            --    ,SI_TYPE_CD
            ,ADDRESS_UNIQUE_ID
            ,FILE_NM
            ,INSERT_AUDIT_KEY
            ,PRODUCT_UNIQUE_ID
            ,VISITOR_MATCH_IND
            ,SERIAL_MATCH_IND
            ,ADDR_MATCH_IND
            ,FIRM_MATCH_IND
            ,EMAIL_MATCH_IND
            ,PHONE_MATCH_IND FROM ACE_ADDRESS_ERROR_GNRC_1626;
   COMMIT;
END;