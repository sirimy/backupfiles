

select * from bppp.RAW_FINANCIAL_REPORT_REVIEW RF inner join AUDIT_TBL AT
on RF.INSERT_AUDIT_KEY = AT.AUDIT_KEY
where AT.CREATION_DT > date '2023-05-01'
Order by AT.CREATION_DT DESC;

select * from bppp.RAW_FINANCIAL_REPORT_REVIEW where CONTRACT_NO = '8984802';
+-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+--+------------+-----+-----------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+---------+-----------------------------+------------------------------+----------+---------------------+-----------------+-----------+
|UNDERWRITER|SALES_CHANNEL|PAYMENT_MODE|DEALER_NO|CONTRACT_NO|FIRST_NM|FIRM_NM|LAST_NM|CONTRACT_START_DATE|CONTRACT_SALE_DATE|PROCESS_DATE|HP|NEW_USED_IND|MONTH|COVERAGE   |CORRECT_RETAIL_PAID|RETAIL_PRICE|GROSS_WRITTEN_PREMIUM|UNDERWRITER_RESERVE|UNDERWRITER_FEE|UNDERWRITER_TAX|SIC_COST|SIC_RESERVE|DEALER_RESIDES_IN|HULL_SERIAL_NO|MOTOR_SERIAL_NO|ERRORS|INSERT_AUDIT_KEY|FINANCIAL_MONTH|CONTRACT_END_DATE|PRODUCT_TYPE_CD|UNIT_CD|BUCKET_NM|BOAT_WARRANTY_EXPIRATION_DATE|MOTOR_WARRANTY_EXPIRATION_DATE|ERROR_DESC|FILE_NM              |TRAILER_SERIAL_NO|OBLIGOR_FEE|
+-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+--+------------+-----+-----------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+---------+-----------------------------+------------------------------+----------+---------------------+-----------------+-----------+
|STARR      |POS          |FINANCED    |20979    |8984802    |REYNALDO|NULL   |GARCIA |2023-06-09         |2023-06-09        |2023-06-16  |90|Y           |84   |PREMIER PRO|1039.00            |1039.00     |116.92               |108.87             |8.05           |0.00           |116.92  |108.87     |TX               |BUJ47033C323  |3B301162       |NULL  |743270          |202306         |2030-06-09       |90ELPT 4S      |PF     |ALUMINUM |2033-06-09                   |2028-06-09                    |NULL      |QA_Report_6.16.23.csv|7J513NN22PB004135|0.00       |
+-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+--+------------+-----+-----------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+---------+-----------------------------+------------------------------+----------+---------------------+-----------------+-----------+

select * from BPPP.CONTRACT_LKP where CONTRACT_XID = '8984802';
select * from BPPP.CONTRACT_DIM where CONTRACT_KEY = 329188;
+------------+-------------------+----------------+-----------------+---------------+----------+----------+
|CONTRACT_KEY|CONTRACT_STATUS_KEY|CONTRACT_SALE_DT|CONTRACT_START_DT|CONTRACT_END_DT|RETAIL_AMT|POLICY_KEY|
+------------+-------------------+----------------+-----------------+---------------+----------+----------+
|329188      |1                  |2023-06-09      |2023-06-09       |2030-06-09     |1039.00   |10032     |
+------------+-------------------+----------------+-----------------+---------------+----------+----------+

select * from BPPP.POLICY_TBL where POLICY_KEY = 10032;

+----------+-----------+------------------+------------+----------+---------------+--------+
|POLICY_KEY|NAME       |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |POLICY_TYPE_KEY|TERM_KEY|
+----------+-----------+------------------+------------+----------+---------------+--------+
|10032     |PREMIER PRO|9010032           |2023-04-30  |2099-12-31|123            |7       |
+----------+-----------+------------------+------------+----------+---------------+--------+

select * FROM P_POLICY_TBL PL where PL.POLICY_KEY = 10032;


select * from BPPP.POLICY_EXT_TBL where POLICY_KEY = 10032;
+----------+------+------+---------+---------+--------------------+----------------+-----------+--------+
|POLICY_KEY|MIN_HP|MAX_HP|MIN_LITER|MAX_LITER|PRODUCT_CATEGORY_KEY|PRODUCT_CAT_DESC|DEALER_COST|NEW_USED|
+----------+------+------+---------+---------+--------------------+----------------+-----------+--------+
|10032     |70    |139   |70       |139      |7                   |4 STROKE        |768.86     |NEW     |
+----------+------+------+---------+---------+--------------------+----------------+-----------+--------+

select * from BPPP.POLICY_ITEM_TBL where POLICY_KEY = 10032;
+---------------+-------+----------------+----------------+--------------+----------+----------------------------------+
|POLICY_ITEM_KEY|NAME   |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|POLICY_KEY|DESCRIPTION                       |
+---------------+-------+----------------+----------------+--------------+----------+----------------------------------+
|63895          |MOTOR  |740924          |NULL            |741179        |10032     |MOTOR line item for policy 10032  |
|63921          |TRAILER|740924          |NULL            |741179        |10032     |TRAILER line item for policy 10032|
+---------------+-------+----------------+----------------+--------------+----------+----------------------------------+


select COVERED_PLAN_NM,CONTRACT_NO  from bppp.RAW_CONTRACT_COVERAGE_TBL RC where CONTRACT_NO = '8984802';
select *  from bppp.RAW_CONTRACT_HOLDER_TBL RH where CONTRACT_NO = '8984802';
select *  from bppp.RAW_CONTRACT_WATERCRAFT_TBL RW where CONTRACT_NO = '8984802';


Select RC.COVERED_PLAN_NM,RH.PROCESS_DT,RW.ENGINE1_HP_NO ,RC.NEW_BOAT_FACTERM_YR_AMT,RC.NEW_BOAT_EXTTERM_YR_AMT
,RC.USED_BOAT_TERM_MONTHS_AMT,RH.contract_expire_dt,RC.CONTRACT_EFFECTIVE_DT,RC.PRODUCT_TYPE_CD,RW.engine1_model_nm
FROM (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
         JOIN (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
         JOIN (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
   WHERE 1=1
     AND rc.rno = 1
     AND rh.rno = 1
     AND rw.rno = 1
     AND RC.CONTRACT_NO = '8984802'
    ;



 SELECT PL.NAME ,POLICY_PRODUCT_XID,PL.POLICY_KEY,TD.YEAR ,PL.NEW_USED_IND ,PET.MIN_HP , PET.MAX_HP,PET.PRODUCT_CATEGORY_KEY,PL.EFFECTIVE_DT ,PL.EXP_DT
            --  INTO L_SKU_NO
              FROM P_POLICY_TBL PL
                    JOIN P_POLICY_TYPE_TBL PTL ON (PL.POLICY_TYPE_KEY = PTL.POLICY_TYPE_KEY)
                     JOIN P_POLICY_EXT_TBL  PET ON (PL.POLICY_KEY = PET.POLICY_KEY)
                      JOIN P_TERM_DIM         TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
                       LEFT JOIN (SELECT DISTINCT pricing_scheme_key, policy_key  --, new_used
                               FROM bppp.RAW_POLICY_DATA_TBL
                            ) raw_pol
                          ON (PL.POLICY_KEY  = raw_pol.POLICY_KEY)
             WHERE
                   PL.NAME = upper('Premier Pro')
               AND PL.CONTRACT_SALES_CHANNEL_KEY = 3
               AND TO_NUMBER(90.00) BETWEEN MIN_HP AND MAX_HP
               AND TD.YEAR =  ROUND((TO_DATE('20300609', 'YYYYMMDD') - TO_DATE('20230609', 'YYYYMMDD')) / 365)
               AND PL.NEW_USED_IND = 'Y'
               AND PET.PRODUCT_CATEGORY_KEY = 7
               AND TO_DATE('20230616', 'YYYYMMDD')  BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT;

--Premier Pro
--
-- ==>P_POLICY_TBL PL [1] PL.NAME [2] PL.CONTRACT_SALES_CHANNEL_KEY  [3] PL.NEW_USED_IND  [4] CREC.PROCESS_DT    BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT
--
-- ==> P_POLICY_EXT_TBL  PET [1] ENGINE1_HP_NO) BETWEEN MIN_HP AND MAX_HP  [2] PET.PRODUCT_CATEGORY_KEY
--
-- ==> Term year TD.YEAR




   SELECT POLICY_PRODUCT_XID
            --  INTO L_SKU_NO
              FROM P_POLICY_TBL PL
                    JOIN P_POLICY_TYPE_TBL PTL ON (PL.POLICY_TYPE_KEY = PTL.POLICY_TYPE_KEY)
                     JOIN P_POLICY_EXT_TBL  PET ON (PL.POLICY_KEY = PET.POLICY_KEY)
                      JOIN P_TERM_DIM         TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
                       LEFT JOIN (SELECT DISTINCT pricing_scheme_key, policy_key  --, new_used
                               FROM bppp.RAW_POLICY_DATA_TBL
                            ) raw_pol
                          ON (PL.POLICY_KEY  = raw_pol.POLICY_KEY)
             WHERE
                   PL.NAME = L_COVERED_PLAN_NM
           --Older data does not have AFT as part of RATE_EFFECTIVE_YEAR_NO and hence we need some other rule to differentiate AFT vs. POS policies from old data
               --AJ hard code this part to always use 'Dealer' channel (3) for all plans effective with 8/1/2021 pricing
               AND PL.CONTRACT_SALES_CHANNEL_KEY =  case when TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' then
                                                                (CASE WHEN (crec.RATE_EFFECTIVE_YEAR_NO LIKE '%AFT' OR    --Pricing effective from Oct 2012 to Jan 2015
                                                                      UPPER(crec.CONTRACT_PROGRAM_NM) LIKE 'AFTERMARKET%' ) OR  --Pricing effective from Jan 2009 to Oct 2012
                                                                      UPPER(L_COVERED_PLAN_NM) LIKE '%AFTERMARKET%' --2015 aftermarket plans
                                                                    THEN 2
                                                                 WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) > 0
                                                                    THEN 1   --Used policies can be sold through POS only
                                                                 ELSE 1  --default is POS
                                                                END )
                                                            else 3
                                                    end
           ----
           ----Now we know that liter ranges upto max 9.8 only and there are certain models where we have to compare with liter data only
               AND CASE
                   WHEN --TO_DATE(crec.process_dt, 'YYYYMMDD')  >= Date '2015-01-25' AND TO_DATE(crec.contract_effective_dt, 'YYYYMMDD')  >= Date '2015-01-25' AND
                         UPPER(L_COVERED_PLAN_NM) LIKE '%ADVANTAGE%'
                         AND L_Amtrust_Old_Pricing_Ind = 'N'    --Contracts being received through JBoat
                         THEN 1
                   WHEN TO_NUMBER(CREC.ENGINE1_HP_NO) <= 9.8 AND TO_NUMBER(CREC.ENGINE1_HP_NO) BETWEEN MIN_LITER AND MAX_LITER THEN 1
                   WHEN TO_NUMBER(CREC.ENGINE1_HP_NO) >= 9.9 AND TO_NUMBER(CREC.ENGINE1_HP_NO) BETWEEN MIN_HP AND MAX_HP THEN 1
                   WHEN (crec.product_type_cd) LIKE '%4.3%' AND 4.3 BETWEEN MIN_LITER AND MAX_LITER THEN 1
                   WHEN (crec.product_type_cd) LIKE '%5.0%' AND 5.0 BETWEEN MIN_LITER AND MAX_LITER THEN 1
                   END = 1

               AND TD.YEAR = (CASE WHEN ( NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 0) <> 0 OR  NVL(CREC.NEW_BOAT_EXTTERM_YR_AMT, 0) <> 0 ) AND NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0
                                       AND L_COVERED_PLAN_NM NOT LIKE '%USED%'
                                   THEN --new boat
                                      NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 0) + NVL(CREC.NEW_BOAT_EXTTERM_YR_AMT, 0)
                                   WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0
                                   THEN --used boat
                                      (NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0)/12)
                                   ELSE  --This condition is being added to handle data from new contract files from jBoat
                                       ROUND((TO_DATE(CREC.contract_expire_dt, 'YYYYMMDD') - TO_DATE(CREC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD')) / 365)
                            END
                            )
               --AND PET.MFG_WARR_TERM = NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 1) --WE HAVE USED NVL AS 1 IN CASE OF USED
               --This assignment seems wrong? --AJ on 8/18/2021
               AND CASE WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0 OR L_COVERED_PLAN_NM LIKE '%USED%' THEN 'N'
                        WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0 AND L_COVERED_PLAN_NM NOT LIKE '%USED%' THEN 'Y'
                   END = PL.NEW_USED_IND  -- handling used policy
               AND PET.PRODUCT_CATEGORY_KEY =
                     DECODE (UPPER(crec.product_type_cd),
                              'ALUMINUM / PONTOON', 10
                              ,'ALUM/PONTOON', 10
                              ,'FIBERGLASS', 11
                              ,'4-STROKE', 7
                              ,'4 STROKE', 7
                              ,'2-STROKE', 6
                              ,'2 STROKE', 6
                              ,'MERCRUISER', 2
                              ,'STERN', 2         --Sterns are Mercruiser
                              ,'DFI', 5
                              ,'V-6', 3
                              --logic to categorize Outboards was provided by Analytics team
                              ,'OUTBOARD', DECODE(UPPER(crec.engine1_model_nm),
                                     '4-STROKE', 7,
                                     '4 STROKE', 7,
                                     '2-STROKE', 6,
                                     '2 STROKE', 6,
                                     'OPTIMAX', 5,
                                     'DFI', 5
                                     )
                                --Following code is being added to handle new contract files from jBoat system.
                               ,CASE
                        --Change this section to use pricing scheme key for all ADVANTAGE plans for pricing effective 8/1/2021 --AJ
                                     WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)
                                                IN ('PREMIER ADVANTAGE', 'PREMIER ADVANTAGE + GPS','PREMIER ADVANTAGE-FL', 'PREMIER ADVANTAGE GPS-FL', 'PREMIER ADVANTAGE + GPS-FL')
                                          THEN 11   --Filberglass pricing
                                     WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)
                                                IN ('TRACKER PROMISE (ADVANTAGE)', 'TRACKER PROMISE (ADVANTAGE) + GPS', 'TRACKER PROMISE (ADVANTAGE)-FL', 'TRACKER PROMISE (ADVANTAGE) GPS-FL', 'TRACKER PROMISE (ADVANTAGE) + GPS-FL')
                                          THEN 10   --Aluminum pricing
                                     WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)
                                                IN ('AFTERMARKET - ADVANTAGE', 'AFTERMARKET - ADVANTAGE + GPS', 'AFTERMARKET - ADVANTAGE-FL', 'AFTERMARKET - ADVANTAGE GPS-FL', 'AFTERMARKET - ADVANTAGE + GPS-FL')
                                          then 10   --AFTERMARKET Advantage policies will have uniform pricing independent of Aluminum vs. Fiberglass
                                     WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2021-08-01' and upper(L_covered_plan_nm) in (
                                                'ADVANTAGE', 'AFTERMARKET - ADVANTAGE', 'AFTERMARKET - ADVANTAGE-FL', 'PREMIER ADVANTAGE', 'PREMIER ADVANTAGE-FL')
                                          then 10   --All Advantage policies will have uniform pricing independent of Aluminum vs. Fiberglass
                                     ELSE
                                         CASE  bpppStg.fn_get_product_category (p_model_nm => crec.PRODUCT_TYPE_CD, p_product_type => 'MOTOR')
                                           WHEN '4-STROKE' THEN 7
                                           WHEN 'MERCRUISER' THEN 2
                                           WHEN '2-STROKE' THEN 6
                                           WHEN 'DFI' THEN 5
                                         END
                                END
                              )
               --AND TO_DATE(crec.process_dt, 'YYYYMMDD') BETWEEN PL.effective_dt and PL.EXP_DT
               AND CASE WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' THEN DATE '2009-01-01'
                        WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') <= date '2015-01-24' THEN DATE '2012-10-16'
                    --WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25' THEN DATE '2015-01-25'
                        WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25' AND L_Amtrust_Old_Pricing_Ind = 'Y' THEN DATE '2012-10-16'  --migrated contracts
                        WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) <> 'BPS' AND L_Amtrust_Old_Pricing_Ind = 'N'   --AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25'
                           THEN TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')   --DATE '2015-01-25'  --JBoat contracts
                        ELSE TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')
                   END BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT

               --Handling Florida-Non Florida policies for older data
               AND CASE --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2012-10-16' THEN 1
                    --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2012-10-16' AND crec.dealer_state_cd = 'FL' AND raw_pol.pricing_scheme_key IN (12, 13) THEN 1
                    --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2012-10-16' AND crec.dealer_state_cd <> 'FL' AND raw_pol.pricing_scheme_key IN (10, 11) THEN 1
                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' THEN 1   --migrated contracts
                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' AND crec.dealer_state_cd = 'FL' AND raw_pol.pricing_scheme_key IN (12, 13) THEN 1    --migrated contracts
                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' AND crec.dealer_state_cd <> 'FL' AND raw_pol.pricing_scheme_key IN (10, 11) THEN 1   --migrated contracts
                   WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= DATE '2015-01-25' OR L_Amtrust_Old_Pricing_Ind = 'N' THEN 1  --new contracts from JBoat don't have a contract prefix
                   ELSE 0
               END = 1
            ;
