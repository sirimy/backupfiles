
select * from policy_tbl
    WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--164

select MIN(POLICY_KEY) from policy_tbl
    WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--9500

select MAX(POLICY_KEY) from policy_tbl
    WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--9669

select COUNT(DISTINCT POLICY_KEY) from policy_tbl
WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--164

select COUNT(*) from policy_lkp
WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--328

select COUNT(*) from policy_ext_tbl
WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--164

select COUNT(*) from t_and_c_contract_template_xref
WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--8856
--164 X 54 = 8856
--per state one policy

select COUNT( DISTINCT POSTAL_STATE_KEY ) from t_and_c_contract_template_xref
WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--54 STATE

select COUNT(*) from Policy_Plan_Component_Xref
WHERE   PLAN_NM IN (
    select DISTINCT NAME from policy_tbl
WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl)
    ) and EFFECTIVE_DT = TO_DATE('2022-06-01 00:00:00','YYYY-MM-DD HH24:MI:SS') ORDER BY EFFECTIVE_DT DESC;--46

select COMPONENT_NM,COUNT(*) from Policy_Plan_Component_Xref
WHERE   PLAN_NM IN (
    select DISTINCT NAME from policy_tbl
WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl)
    ) and EFFECTIVE_DT = TO_DATE('2022-06-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
group by COMPONENT_NM;--5 COMPONENT_NM


select COUNT(*) from policy_item_tbl
    WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--600

select NAME,COUNT(NAME) from policy_item_tbl
WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl)
group by NAME;----5 COMPONENT_NM

select COUNT(*) from POLICY_COVERAGE_TBL
                WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--1200

select COUNT(*) from policy_fee_xref
                WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--1968

select COUNT(*)  from BPPP.COVERAGE_PARTS_GROUP_XREF
                WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl);--9088

select COUNT(*)  from BPPP.COVERAGE_PARTS_GROUP_XREF    WHERE  INSERT_AUDIT_KEY = 677493;--9088

select PARTS_GROUP_KEY,COUNT(PARTS_GROUP_KEY) from COVERAGE_PARTS_GROUP_XREF
                WHERE  POLICY_KEY IN (select POLICY_KEY from BPPPSTG.raw_policy_data_tbl)
Group by PARTS_GROUP_KEY;--39rows