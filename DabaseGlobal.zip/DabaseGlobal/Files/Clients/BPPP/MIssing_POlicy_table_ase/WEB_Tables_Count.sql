
select * from POLICY_TYPE  where  POLICY_TYPE_ID >= 364 and LAST_UPDATED_BY = 'BASS-1027'; -- 9

select COUNT(*) from policy  where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-05' order BY LAST_UPDATED_TS desc;--402
select * from policy  where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-05' and POLICY_ID =9500
                             order BY LAST_UPDATED_TS desc;--1 min policy id exist
select * from policy  where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-05'  and POLICY_ID =9669
                             order BY LAST_UPDATED_TS desc;--1 max policy id exist

select * from POLICY_EXT
where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-05' order by LAST_UPDATED_TS desc; --164

select COUNT(*) from t_and_c_contract_template_xref
where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-05'  order by LAST_UPDATED_TS desc;--8856

select COUNT(*) from Policy_Plan_Component_Xref; -- No referance table I found

select COUNT(*) from POLICY_ITEM
    where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-05'  order by LAST_UPDATED_TS desc;--600

 select COUNT(*) from POLICY_COVERAGE
      where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-05'  order by LAST_UPDATED_TS desc;--1200

select COUNT(*) from policy_fee_xref
     where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-05'  order by LAST_UPDATED_TS desc;--4348

select COUNT(*) from  BPPPTPPPWEB.COVERAGE_PARTS_GROUP_XREF
    where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19'  order by LAST_UPDATED_TS desc;--0