

select * from bppp.RAW_FINANCIAL_REPORT_REVIEW RF inner join AUDIT_TBL AT
on RF.INSERT_AUDIT_KEY = AT.AUDIT_KEY
where AT.CREATION_DT > date '2023-05-01'
Order by AT.CREATION_DT DESC;

select * from bppp.RAW_FINANCIAL_REPORT_REVIEW where CONTRACT_NO = '8951180';
 +-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+---+------------+-----+--------------------------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+----------+-----------------------------+------------------------------+----------+--------------------------------+-----------------+-----------+
|UNDERWRITER|SALES_CHANNEL|PAYMENT_MODE|DEALER_NO|CONTRACT_NO|FIRST_NM|FIRM_NM|LAST_NM|CONTRACT_START_DATE|CONTRACT_SALE_DATE|PROCESS_DATE|HP |NEW_USED_IND|MONTH|COVERAGE                  |CORRECT_RETAIL_PAID|RETAIL_PRICE|GROSS_WRITTEN_PREMIUM|UNDERWRITER_RESERVE|UNDERWRITER_FEE|UNDERWRITER_TAX|SIC_COST|SIC_RESERVE|DEALER_RESIDES_IN|HULL_SERIAL_NO|MOTOR_SERIAL_NO|ERRORS|INSERT_AUDIT_KEY|FINANCIAL_MONTH|CONTRACT_END_DATE|PRODUCT_TYPE_CD|UNIT_CD|BUCKET_NM |BOAT_WARRANTY_EXPIRATION_DATE|MOTOR_WARRANTY_EXPIRATION_DATE|ERROR_DESC|FILE_NM                         |TRAILER_SERIAL_NO|OBLIGOR_FEE|
+-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+---+------------+-----+--------------------------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+----------+-----------------------------+------------------------------+----------+--------------------------------+-----------------+-----------+
|STARR      |POS          |FINANCED    |42358    |8951180    |JORDAN  |NULL   |MORROW |2023-06-02         |2023-06-02        |2023-06-13  |150|Y           |84   |PREMIER PRO PLUS          |1539.00            |1539.00     |175.44               |163.35             |12.09          |0.00           |175.44  |163.35     |SC               |RGR10898G223  |3B229369       |NULL  |741863          |202306         |2030-06-02       |150XL 4S       |RFG    |FIBERGLASS|2024-06-02                   |2026-06-02                    |NULL      |QA_Report_6.13.23.csv           |7J512DJ26PB001015|0.00       |
|STARR      |POS          |FINANCED    |42358    |8951180    |JORDAN  |NULL   |MORROW |2023-06-02         |2023-06-02        |2023-06-13  |150|Y           |84   |TRACKER PROMISE (PRO PLUS)|1839.00            |1839.00     |210.55               |196.05             |14.50          |0.00           |210.55  |196.05     |SC               |RGR10898G223  |3B229369       |NULL  |743453          |202306         |2030-06-02       |150XL 4S       |RDV    |ALUMINUM  |2028-06-02                   |2028-06-02                    |NULL      |QA_Report_correction_6.13.23.csv|7J512DJ26PB001015|0.00       |
+-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+---+------------+-----+--------------------------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+----------+-----------------------------+------------------------------+----------+--------------------------------+-----------------+-----------+

select * from BPPP.CONTRACT_LKP where CONTRACT_XID = '8951180';
select * from BPPP.CONTRACT_DIM where CONTRACT_KEY = 328940;
+------------+-------------------+----------------+-----------------+---------------+----------+--------------+-----------+------------+----------+-----------+-----------+--------------------+------------------------+---------------------+----------------+----------------+--------------+----------+--------------+---------------+-------------+-------------------------+-------------------+
|CONTRACT_KEY|CONTRACT_STATUS_KEY|CONTRACT_SALE_DT|CONTRACT_START_DT|CONTRACT_END_DT|RETAIL_AMT|RETAIL_TAX_AMT|CURRENCY_CD|DISCOUNT_AMT|POLICY_KEY|VISITOR_KEY|ADDRESS_KEY|PURCHASE_ADDRESS_KEY|TERMS_AND_CONDITIONS_KEY|CONTRACT_TEMPLATE_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|OUTLET_KEY|LIENHOLDER_KEY|OBLIGOR_FEE_AMT|FRONT_FEE_AMT|CONTRACT_PAYMENT_TYPE_KEY|CONTRACT_CREATED_DT|
+------------+-------------------+----------------+-----------------+---------------+----------+--------------+-----------+------------+----------+-----------+-----------+--------------------+------------------------+---------------------+----------------+----------------+--------------+----------+--------------+---------------+-------------+-------------------------+-------------------+
|328940      |1                  |2023-06-02      |2023-06-02       |2030-06-02     |1839.00   |NULL          |NULL       |NULL        |10150     |9816688    |13897320   |13897320            |7                       |1                    |743456          |NULL            |743509        |9066      |276           |NULL           |NULL         |2                        |2023-06-13         |
+------------+-------------------+----------------+-----------------+---------------+----------+--------------+-----------+------------+----------+-----------+-----------+--------------------+------------------------+---------------------+----------------+----------------+--------------+----------+--------------+---------------+-------------+-------------------------+-------------------+


select * from BPPP.POLICY_TBL where POLICY_KEY = 10150;

+----------+--------------------------+-----------+------------------+------------+----------+---------------+--------+--------------------------+----------------------------+
|POLICY_KEY|NAME                      |DESCRIPTION|POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |POLICY_TYPE_KEY|TERM_KEY|CONTRACT_SALES_CHANNEL_KEY|COVERAGE_TIMING_STRATEGY_KEY|
+----------+--------------------------+-----------+------------------+------------+----------+---------------+--------+--------------------------+----------------------------+
|10150     |TRACKER PROMISE (PRO PLUS)|NULL       |9010150           |2023-04-30  |2099-12-31|149            |7       |3                         |1                           |
+----------+--------------------------+-----------+------------------+------------+----------+---------------+--------+--------------------------+----------------------------+




select * from BPPP.POLICY_EXT_TBL where POLICY_KEY = 10150;
+----------+------+------+---------+---------+--------------------+----------------+
|POLICY_KEY|MIN_HP|MAX_HP|MIN_LITER|MAX_LITER|PRODUCT_CATEGORY_KEY|PRODUCT_CAT_DESC|
+----------+------+------+---------+---------+--------------------+----------------+
|10150     |140   |225   |140      |225      |7                   |4 STROKE        |
+----------+------+------+---------+---------+--------------------+----------------+



select * from BPPP.POLICY_ITEM_TBL where POLICY_KEY = 10150;
+---------------+--------------+----------------+----------------+--------------+----------+-----------------------------------------+
|POLICY_ITEM_KEY|NAME          |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|POLICY_KEY|DESCRIPTION                              |
+---------------+--------------+----------------+----------------+--------------+----------+-----------------------------------------+
|64238          |BOAT          |740924          |NULL            |741179        |10150     |BOAT line item for policy 10150          |
|64248          |DEPTH FINDER  |740924          |NULL            |741179        |10150     |DEPTH FINDER line item for policy 10150  |
|64258          |MOTOR         |740924          |NULL            |741179        |10150     |MOTOR line item for policy 10150         |
|64268          |TRAILER       |740924          |NULL            |741179        |10150     |TRAILER line item for policy 10150       |
|64278          |TROLLING MOTOR|740924          |NULL            |741179        |10150     |TROLLING MOTOR line item for policy 10150|
+---------------+--------------+----------------+----------------+--------------+----------+-----------------------------------------+





Select *
FROM (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
         JOIN (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
         JOIN (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
   WHERE 1=1
     AND rc.rno = 1
     AND rh.rno = 1
     AND rw.rno = 1
     AND RC.CONTRACT_NO = '8951180'
    ;

Select RC.COVERED_PLAN_NM,RH.PROCESS_DT,RW.ENGINE1_HP_NO ,RC.NEW_BOAT_FACTERM_YR_AMT,RC.NEW_BOAT_EXTTERM_YR_AMT
,RC.USED_BOAT_TERM_MONTHS_AMT,RH.contract_expire_dt,RC.CONTRACT_EFFECTIVE_DT,RC.PRODUCT_TYPE_CD,RW.engine1_model_nm,bpppStg.fn_get_product_category (p_model_nm => RC.PRODUCT_TYPE_CD, p_product_type => 'MOTOR')
FROM (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY desc) rno from bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
         JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY desc) rno from bppp.RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
         JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY desc) rno from bppp.RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
   WHERE 1=1
     AND rc.rno = 1
     AND rh.rno = 1
     AND rw.rno = 1
     AND RC.CONTRACT_NO = '8951180'
    ;
 +----------------+----------+-------------+-----------------------+-----------------------+-------------------------+------------------+---------------------+---------------+----------------+---------------------------------------------------------------------------------------+
|COVERED_PLAN_NM |PROCESS_DT|ENGINE1_HP_NO|NEW_BOAT_FACTERM_YR_AMT|NEW_BOAT_EXTTERM_YR_AMT|USED_BOAT_TERM_MONTHS_AMT|CONTRACT_EXPIRE_DT|CONTRACT_EFFECTIVE_DT|PRODUCT_TYPE_CD|ENGINE1_MODEL_NM|BPPPSTG.FN_GET_PRODUCT_CATEGORY(P_MODEL_NM=>RC.PRODUCT_TYPE_CD,P_PRODUCT_TYPE=>'MOTOR')|
+----------------+----------+-------------+-----------------------+-----------------------+-------------------------+------------------+---------------------+---------------+----------------+---------------------------------------------------------------------------------------+
|PREMIER PRO PLUS|20230613  |150.00       |NULL                   |NULL                   |NULL                     |20300602          |20230602             |150XL 4S       |150XL PXS4      |4-STROKE                                                                               |
+----------------+----------+-------------+-----------------------+-----------------------+-------------------------+------------------+---------------------+---------------+----------------+---------------------------------------------------------------------------------------+



 SELECT PL.NAME ,POLICY_PRODUCT_XID,PL.POLICY_KEY,TD.YEAR ,PL.NEW_USED_IND ,PET.MIN_HP , PET.MAX_HP,PET.PRODUCT_CATEGORY_KEY,PL.EFFECTIVE_DT ,PL.EXP_DT
            --  INTO L_SKU_NO
              FROM P_POLICY_TBL PL
                    JOIN P_POLICY_TYPE_TBL PTL ON (PL.POLICY_TYPE_KEY = PTL.POLICY_TYPE_KEY)
                     JOIN P_POLICY_EXT_TBL  PET ON (PL.POLICY_KEY = PET.POLICY_KEY)
                      JOIN P_TERM_DIM         TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
                       LEFT JOIN (SELECT DISTINCT pricing_scheme_key, policy_key  --, new_used
                               FROM bppp.RAW_POLICY_DATA_TBL
                            ) raw_pol
                          ON (PL.POLICY_KEY  = raw_pol.POLICY_KEY)
             WHERE
                   PL.NAME = upper('TRACKER PROMISE (PRO PLUS)')
               AND PL.CONTRACT_SALES_CHANNEL_KEY = 3
               AND TO_NUMBER(150.00) BETWEEN MIN_HP AND MAX_HP
               AND TD.YEAR =  ROUND((TO_DATE('20300602', 'YYYYMMDD') - TO_DATE('20230602', 'YYYYMMDD')) / 365)
               AND PL.NEW_USED_IND = 'Y'
               AND PET.PRODUCT_CATEGORY_KEY = 7
               AND TO_DATE('20230613', 'YYYYMMDD')  BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT;

+----------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
|NAME            |POLICY_PRODUCT_XID|POLICY_KEY|YEAR|NEW_USED_IND|MIN_HP|MAX_HP|PRODUCT_CATEGORY_KEY|EFFECTIVE_DT|EXP_DT    |
+----------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
|PREMIER PRO PLUS|9010097           |10097     |7   |Y           |140   |225   |7                   |2023-04-30  |2099-12-31|
+----------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+


 SELECT PL.NAME ,POLICY_PRODUCT_XID,PL.POLICY_KEY,TD.YEAR ,PL.NEW_USED_IND ,PET.MIN_HP , PET.MAX_HP,PET.PRODUCT_CATEGORY_KEY,PL.EFFECTIVE_DT ,PL.EXP_DT
            --  INTO L_SKU_NO
              FROM P_POLICY_TBL PL
                    JOIN P_POLICY_TYPE_TBL PTL ON (PL.POLICY_TYPE_KEY = PTL.POLICY_TYPE_KEY)
                     JOIN P_POLICY_EXT_TBL  PET ON (PL.POLICY_KEY = PET.POLICY_KEY)
                      JOIN P_TERM_DIM         TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
                       LEFT JOIN (SELECT DISTINCT pricing_scheme_key, policy_key  --, new_used
                               FROM bppp.RAW_POLICY_DATA_TBL
                            ) raw_pol
                          ON (PL.POLICY_KEY  = raw_pol.POLICY_KEY)
             WHERE PL.POLICY_KEY = 10150;

+--------------------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
|NAME                      |POLICY_PRODUCT_XID|POLICY_KEY|YEAR|NEW_USED_IND|MIN_HP|MAX_HP|PRODUCT_CATEGORY_KEY|EFFECTIVE_DT|EXP_DT    |
+--------------------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
|TRACKER PROMISE (PRO PLUS)|9010150           |10150     |7   |Y           |140   |225   |7                   |2023-04-30  |2099-12-31|
+--------------------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+

--Premier Pro
--
-- ==>P_POLICY_TBL PL [1] PL.NAME [2] PL.CONTRACT_SALES_CHANNEL_KEY  [3] PL.NEW_USED_IND  [4] CREC.PROCESS_DT    BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT
--
-- ==> P_POLICY_EXT_TBL  PET [1] ENGINE1_HP_NO) BETWEEN MIN_HP AND MAX_HP  [2] PET.PRODUCT_CATEGORY_KEY
--
-- ==> Term year TD.YEAR

