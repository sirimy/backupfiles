
--Duplicate part_groups
select upper(trim(to_char(NAME))) from PARTS_GROUP
group by upper(trim(to_char(NAME)))
having count(upper(trim(to_char(NAME)))) >= 2;
--POWER/MANUAL TRANSOM
--POWER/MANUAL TRANSOM

select NAME from PARTS_GROUP
group by NAME
having count(NAME) >= 2;

select * from PARTS_GROUP where NAME = 'Power/Manual Transom';
+--------------+--------------------+--------------------+---------------------+---------------+--------------------------+
|PARTS_GROUP_ID|NAME                |DESCRIPTION         |PARENT_PARTS_GROUP_ID|LAST_UPDATED_BY|LAST_UPDATED_TS           |
+--------------+--------------------+--------------------+---------------------+---------------+--------------------------+
|21            |Power/Manual Transom|Power/Manual Transom|5                    |DW             |2015-01-13 09:14:28.356068|
|52            |Power/Manual Transom|Power/Manual Transom|16                   |NULL           |2018-11-26 05:58:23.595411|
+--------------+--------------------+--------------------+---------------------+---------------+--------------------------+

-- its exact same name

--Duplicate parts
select upper(trim(to_char(NAME))) from PART_TBL
group by upper(trim(to_char(NAME)))
having count(upper(trim(to_char(NAME)))) >= 2;
--58 dupes :-(

select * from PART_TBL
Where upper(trim(to_char(NAME)))
in (
    select upper(trim(to_char(NAME))) from PART_TBL
group by upper(trim(to_char(NAME)))
having count(upper(trim(to_char(NAME)))) >= 2
          )
Order by upper(trim(to_char(NAME)));


select * from PART_TBL where upper(trim(to_char(NAME))) in (
        select upper(trim(to_char(NAME))) from PART_TBL
        group by upper(trim(to_char(NAME)))
        having count(upper(trim(to_char(NAME)))) >= 2)
order by upper(trim(to_char(NAME))), PART_ID;
--116 rows belonging to 58 parts
+-------+-------------------------+-------------------------+
|PART_ID|PART_XID                 |NAME                     |
+-------+-------------------------+-------------------------+
|903    |Adapter plate            |Adapter plate            |
|1028   |Adapter Plate            |Adapter Plate            |
|1177   |Alternator Belt          |Alternator Belt          |
|1215   |Alternator belt          |Alternator belt          |
|853    |attenuator               |attenuator               |
|875    |Attenuator               |Attenuator               |
|1024   |Backing plate            |Backing plate            |
|1075   |Backing Plate            |Backing Plate            |
|947    |Battery charger/converter|Battery charger/converter|
|1036   |Battery Charger/converter|Battery Charger/converter|
+-------+-------------------------+-------------------------+

    --Max of info
+-------+-------------------------+-------------------------+
--clean_up_duplicate_part_group_and_part_records_bass_1112

CREATE TABLE clean_up_duplicate_part_group_and_part_records_bass_1112
  AS (
        select pgx.PARTS_GROUP_ID,PG.NAME as PG_NAME,PT.PART_ID,PT.NAME as PT_NAME,
               upper(trim(to_char(PT.NAME))) UPPER_NAME,CL.PART_ID as CL_PART_ID,CL.CNT from PART_TBL PT left Join
            (
                select PART_ID,COUNT(PART_ID) CNT from CLAIM_LINE_ITEM Group by PART_ID
            ) CL on PT.PART_ID = CL.PART_ID
            left join PARTS_GROUP_PART_XREF pgx  on PT.part_id = pgx.part_id
            join PARTS_GROUP PG on PG.PARTS_GROUP_ID = pgx.PARTS_GROUP_ID
        where upper(trim(to_char(PT.NAME))) in (
                select upper(trim(to_char(NAME))) from PART_TBL
                group by upper(trim(to_char(NAME)))
                having count(upper(trim(to_char(NAME)))) >= 2)

)
;
--order by upper(trim(to_char(PT.NAME))), PT.PART_ID
+-------+-------------------------+-------------------------+
+--------------+-------+-------------------------+-------+----+
|PARTS_GROUP_ID|PART_ID|NAME                     |PART_ID|CNT |
+--------------+-------+-------------------------+-------+----+
|5             |903    |Adapter plate            |NULL   |NULL|
|5             |1028   |Adapter Plate            |1028   |4   |
|7             |1177   |Alternator Belt          |1177   |1   |
|7             |1215   |Alternator belt          |NULL   |NULL|
|11            |853    |attenuator               |NULL   |NULL|
|11            |875    |Attenuator               |NULL   |NULL|
|9             |1024   |Backing plate            |NULL   |NULL|
|9             |1075   |Backing Plate            |1075   |6   |
|27            |947    |Battery charger/converter|947    |1   |
|28            |947    |Battery charger/converter|947    |1   |
|28            |1036   |Battery Charger/converter|1036   |2   |
|27            |1036   |Battery Charger/converter|1036   |2   |
+--------------+-------+-------------------------+-------+----+


select PART_ID,COUNT(PART_ID) from CLAIM_LINE_ITEM Group by PART_ID;
+-------+-------------+
|PART_ID|PART_XID     |
+-------+-------------+
|903    |Adapter plate|
|1028   |Adapter Plate|
+-------+-------------+
+-------+--------------+
|PART_ID|COUNT(PART_ID)|
+-------+--------------+
|1028   |4             |
+-------+--------------+

select PART_ID,COUNT(PART_ID) from CLAIM_LINE_ITEM
where PART_ID in (1177,1215)
Group by PART_ID;
+-------+--------------+
|PART_ID|COUNT(PART_ID)|
+-------+--------------+
|1177   |1             |
+-------+--------------+



select *
from   PARTS_GROUP_PART_XREF pgx
       join parts_group pg on pg.parts_group_id = pgx.parts_group_id
       join PART_TBL p     on p.part_id = pgx.part_id
where  upper(trim(to_char(p.NAME))) in (
        select upper(trim(to_char(NAME))) from PART_TBL
        group by upper(trim(to_char(NAME)))
        having count(upper(trim(to_char(NAME)))) >= 2)
order by upper(trim(to_char(p.NAME))), pgx.parts_group_id, pgx.part_id;


SELECT * FROM clean_up_duplicate_part_group_and_part_records_bass_1112 Order by UPPER_NAME;--131
SELECT UPPER_NAME,count(UPPER_NAME)
FROM clean_up_duplicate_part_group_and_part_records_bass_1112 GROUP BY UPPER_NAME;--58


select A.PARTS_GROUP_ID,B.PARTS_GROUP_ID,A.PG_NAME,B.PG_NAME,A.PT_NAME,B.PT_NAME, A.PART_ID,B.PART_ID from clean_up_duplicate_part_group_and_part_records_bass_1112 A
    JOIN clean_up_duplicate_part_group_and_part_records_bass_1112  B on A.UPPER_NAME = B.UPPER_NAME AND A.PART_ID <> B.PART_ID
where A.PARTS_GROUP_ID <> B.PARTS_GROUP_ID and A.UPPER_NAME <> 'BATTERY CHARGER/CONVERTER'
Order by A.UPPER_NAME,A.PART_ID ,B.UPPER_NAME,B.PART_ID DESC;
--50 for which group id not same
--25 here can not change

select A.PARTS_GROUP_ID,B.PARTS_GROUP_ID,A.PT_NAME,B.PT_NAME,
       A.PART_ID,B.PART_ID,
    A.CNT,B.CNT
from clean_up_duplicate_part_group_and_part_records_bass_1112 A
    JOIN clean_up_duplicate_part_group_and_part_records_bass_1112
        B on A.UPPER_NAME = B.UPPER_NAME AND A.PART_ID <> B.PART_ID
where A.PARTS_GROUP_ID = B.PARTS_GROUP_ID
AND ((
    A.CNT is null AND B.CNT is not null)
    OR     (A.CNT is not  null AND B.CNT is null)
    )
and A.UPPER_NAME <> 'BATTERY CHARGER/CONVERTER'
Order by A.UPPER_NAME
;--32 rows
--16 here can remove


select A.PARTS_GROUP_ID,B.PARTS_GROUP_ID,A.PT_NAME,B.PT_NAME,
       A.PART_ID,B.PART_ID,
    A.CNT,B.CNT
from clean_up_duplicate_part_group_and_part_records_bass_1112 A
    JOIN clean_up_duplicate_part_group_and_part_records_bass_1112
        B on A.UPPER_NAME = B.UPPER_NAME AND A.PART_ID <> B.PART_ID
where A.PARTS_GROUP_ID = B.PARTS_GROUP_ID
AND A.CNT is null AND B.CNT is  null
and A.UPPER_NAME <> 'BATTERY CHARGER/CONVERTER'
Order by A.UPPER_NAME
;--34 rows
--17 rows here we can remove


select  A.PARTS_GROUP_ID,B.PARTS_GROUP_ID,A.PT_NAME,B.PT_NAME,
       A.PART_ID,B.PART_ID,
    A.CNT,B.CNT
from clean_up_duplicate_part_group_and_part_records_bass_1112 A
    JOIN clean_up_duplicate_part_group_and_part_records_bass_1112
        B on A.UPPER_NAME = B.UPPER_NAME AND A.PART_ID <> B.PART_ID
where A.PARTS_GROUP_ID = B.PARTS_GROUP_ID
AND A.CNT is not null AND B.CNT is not  null
and A.UPPER_NAME <> 'BATTERY CHARGER/CONVERTER'
Order by A.UPPER_NAME
;--44 rows
--22 rows here we can remove


select 25 + 16 + 17 + 22 from DUAL;--80