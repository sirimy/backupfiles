create view V_CONTRACT_FEE_XREF as
SELECT contract_key,
            contract_xid AS contract_no,
            SUM (
               CASE
                  WHEN pft.name = 'RESERVE' THEN CONTRACT_FEE_VALUE
                  ELSE 0
               END)
               AS RESERVE,
            SUM (
               CASE
                  WHEN pft.name = 'POLICY COST' THEN CONTRACT_FEE_VALUE
                  ELSE 0
               END)
               AS POLICY_COST,
            SUM (
               CASE
                  WHEN pft.name = 'UNDERWRITER FEE' THEN CONTRACT_FEE_VALUE
                  ELSE 0
               END)
               AS UNDERWRITER_FEE,
            SUM (CASE WHEN pft.name = 'TAX' THEN CONTRACT_FEE_VALUE ELSE 0 END)
               AS TAX,
            SUM (
               CASE
                  WHEN pft.name = 'DEALER COST' THEN CONTRACT_FEE_VALUE
                  ELSE 0
               END)
               AS DEALER_COST,
            SUM (
               CASE WHEN pft.name = 'MSRP' THEN CONTRACT_FEE_VALUE ELSE 0 END)
               AS MSRP,
            SUM (
               CASE WHEN pft.name = 'SIC_COST' THEN CONTRACT_FEE_VALUE ELSE 0 END)
               AS SIC_COST,
            SUM (
               CASE WHEN pft.name = 'OBLIGOR_FEE' THEN CONTRACT_FEE_VALUE ELSE 0 END)
               AS OBLIGOR_FEE
       FROM bppp.contract_fee_xref cfx
            JOIN bppp.policy_fee_type pft USING (policy_fee_type_key)
            JOIN bppp.contract_lkp c_lkp USING (contract_key)
      WHERE source_system_cd = 0
   GROUP BY contract_key, contract_xid
/

