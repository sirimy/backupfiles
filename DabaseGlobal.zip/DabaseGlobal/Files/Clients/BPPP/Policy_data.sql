
select * from PPP_PRICING_2023_07_JUNE order by SLNO desc;
select count(*) from PPP_PRICING_2023_07_JUNE;--158
---------------------------------------------------------------
insert into raw_pricing
 Select  CHANNEL,NAME,PRODUCT_CAT_DESC,TERM,MIN_HP,MAX_HP,MSRP,
    SIC_COST,UNDERWRITER_RESERVE,UNDERWRITER_FEE,UNDERWRITER_TAX,OBLIGOR_FEE,NULL,
    0,0,0,0,0,NULL,0,0,0,0,'PPP_PRICING_2023_07_JUNE',0, AFTER_POLICY_KEY
from PPP_PRICING_2023_07_JUNE;



--  Select  CHANNEL,NAME,PRODUCT_CAT_DESC,TERM,MIN_HP,MAX_HP,MSRP,
--     SIC_COST,UNDERWRITER_RESERVE,UNDERWRITER_FEE,UNDERWRITER_TAX,OBLIGOR_FEE,NULL,
--     0,0,0,0,0,NULL,0,0,0,0,'PPP_PRICING_2023_07_JUNE',0, AFTER_POLICY_KEY
-- from PPP_PRICING_2023_07_JUNE;

---------------------------------------------------------------
select Count(*) from raw_pricing;--158
select * from raw_pricing;--158
select * from raw_pricing where plan like '%Ad%'
order by plan, PRODUCT_CATEGORY, TERM, TO_NUMBER(min_hp)
;--24
--------------------------------------------------------------
 insert into raw_policy_data_tbl (
                      POLICY_KEY, NAME, sku, EFFECTIVE_DT, EXP_DT,
                      POLICY_TYPE_KEY, TERM_KEY,
                      CONTRACT_SALES_CHANNEL_KEY, PROGRAM_NAME, COVERAGE_TIMING_STRATEGY_KEY,
                      PRODUCT_CAT_DESC, MIN_HP, MAX_HP, MIN_LITER, MAX_LITER,
                      ----
                      current_msrp, sic_cost,
                      RESERVE, AMT_FEE, TAX, OBLIGOR_FEE, premium,
                      policy_cost,
                      margin, tmfs_income, dealer_income, dealer_cost,
                      ----
                      NEW_USED,
                      INSERT_AUDIT_KEY, UNDERWRITER_KEY,
                      FL_AMT_RESERVE, WESCO_FEE_ONLY, AMT_FEE_ONLY
                      ,file_nm, old_policy_key
                      )
              select 0 as new_policy_key
                     , case when gps = 'Y' and UPPER(plan) NOT LIKE '%%GPS%%' then
                                 UPPER(plan) || ' + GPS'
                            else replace (UPPER(plan), 'WGPS', '+ GPS')
                             --else UPPER(plan)
                          end as name
                     , 0 as sku,
                        date '2023-04-30' as effective_dt, date '2099-12-31' as exp_dt,
                     null as policy_type_key, term,
                     case when UPPER(channel) = 'POS' then 1 else 2 end as contract_sales_channel_key,
                     UPPER(channel) as PROGRAM_NAME,   --case when channel = 'POS' then 'POS' when channel = 'AFTERMARKET' then 'AFTERMARKET' else channel end
                     1 as coverage_timing_strategy_key,
                     case when product_category = '2 & 4 Stroke'
                               or product_category = '2 & 4 Stroke & DFI'
                               or product_category = '2/4 Stroke & DFI' then '2 Stroke'
                          when product_category = 'Fiberglass/Aluminum' then 'Fiberglass'
                          when product_category = 'Optimax & DFI' then 'Optimax'
                          else product_category
                      end as product_cat_desc,
                     --regexp_substr(hp, '[^-]+', 1, 1) as min_hp, regexp_substr(hp, '[^-]+', 1, 2) as max_hp,
                     --regexp_substr(hp, '[^-]+', 1, 1) as min_liter, regexp_substr(hp, '[^-]+', 1, 2) as max_liter
                     min_hp, max_hp, min_hp as min_liter, max_hp as max_liter
                     ----
                     --CONSUMER_RETAIL, SIC_COST, AMT_RESERVE, MARGIN, AMT_FEE, AMT_TAX, SIC_RESERVE, TMFS_INCOME, DEALER_INCOME, DEALER_COST
                     ,consumer_retail as msrp,
                     sic_cost,
                     --
                     CASE WHEN UPPER(plan) LIKE '%%-FL' THEN AMT_Reserve    --BASS-715
                          --ELSE AMT_Reserve - AMT_FEE - AMT_TAX            --BASS-630: AMT_RESERVE represents Gross Premium for non-FL states
                          ELSE AMT_Reserve                                  --BASS-820: Pricing sheet had it pre-calculated already.
                      END AS RESERVE,
                     --
                     AMT_FEE + coalesce(OBLIGOR_FEE, 0),
                     amt_tax as TAX,
                     OBLIGOR_FEE, premium,
                     --
                     --CASE WHEN UPPER(plan) LIKE '%%-FL' THEN AMT_Reserve + AMT_FEE + AMT_TAX   --BASS-715. Here AMT_FEE is UW_FEE+AMT_FEE from FL pricing sheet
                       --   ELSE AMT_Reserve   --BASS-630
                      --END AS policy_cost,    --Policy cost has diff data between 2015 pricing (non FL states) and FL pricing (2016)
                      null as policy_cost,             --It was not required for Aug 2021 pricing
                      --
                     margin,
                     tmfs_income,
                     dealer_income,
                     dealer_cost,
                     ----
                     case when UPPER(plan) like '%%USED%%' then 'USED' ELSE 'NEW' end as NEW_USED,
                     null as INSERT_AUDIT_KEY,
                      --case when UPPER(replace(plan, ' ')) LIKE '%%-FL' then 4 else 1 end as underwriter_key
                      1 as underwriter_key
                      ,FL_AMT_RESERVE, WESCO_FEE_ONLY, AMT_FEE_ONLY
                      ,file_nm, old_policy_key
             from
                    raw_pricing;
COMMIT;
------------------------------------------------------
select COUNT(*) from raw_policy_data_tbl;--158
select * from raw_policy_data_tbl;--158
--After copy DFi
-----------------------------------------------------------
insert into raw_policy_data_tbl (
                      POLICY_KEY, NAME, sku, EFFECTIVE_DT, EXP_DT,
                      POLICY_TYPE_KEY, TERM_KEY,
                      CONTRACT_SALES_CHANNEL_KEY, PROGRAM_NAME, COVERAGE_TIMING_STRATEGY_KEY,
                      PRODUCT_CAT_DESC, MIN_HP, MAX_HP, MIN_LITER, MAX_LITER,
                      ----
                      current_msrp, sic_cost,
                      RESERVE, AMT_FEE, TAX,OBLIGOR_FEE, premium,
                      policy_cost,
                      margin, tmfs_income, dealer_income, dealer_cost,
                      ----
                      NEW_USED,
                      INSERT_AUDIT_KEY, UNDERWRITER_KEY
                     ,FL_AMT_RESERVE, WESCO_FEE_ONLY, AMT_FEE_ONLY
                      ,file_nm, old_policy_key
                      )
              select
                      POLICY_KEY, NAME, sku, EFFECTIVE_DT, EXP_DT,
                      POLICY_TYPE_KEY, TERM_KEY,
                      CONTRACT_SALES_CHANNEL_KEY, PROGRAM_NAME, COVERAGE_TIMING_STRATEGY_KEY,
                      'DFI' as PRODUCT_CAT_DESC, MIN_HP, MAX_HP, MIN_LITER, MAX_LITER,
                      ----
                      current_msrp, sic_cost,
                      reserve, amt_fee, tax, OBLIGOR_FEE, premium,
                      policy_cost,
                      margin, tmfs_income, dealer_income, dealer_cost,
                      ----
                      NEW_USED,
                      INSERT_AUDIT_KEY, UNDERWRITER_KEY
                     ,FL_AMT_RESERVE, WESCO_FEE_ONLY, AMT_FEE_ONLY
                      ,file_nm, old_policy_key
                from raw_policy_data_tbl
               where
                UPPER(PRODUCT_CAT_DESC) = '4 STROKE' AND Upper(NAME) like '%ADDER%';--24 rows
-------------------------------------------------------------
select COUNT(*) from raw_policy_data_tbl;--182

select * from raw_policy_data_tbl where NAME like '%ADD%' order by NAME,PRODUCT_CAT_DESC;--182
-------------------------------------

 update raw_policy_data_tbl set name = UPPER(name)
               where name <> UPPER(name);

update raw_policy_data_tbl set name = TRIM(name)
where name <> TRIM(name);

 update raw_policy_data_tbl rpdt
 set program_name = (select UPPER(csct.name)
                     from bppp.contract_sales_channel_tbl csct
                    where csct.contract_sales_channel_key = rpdt.contract_sales_channel_key)
where program_name is null ;

 update raw_policy_data_tbl
 set deductible = 100
where underwriter_key IN (1, 4)
 and deductible is null;

update raw_policy_data_tbl
 set name = replace(name, 'USED - PRO', 'USED PRO')
where effective_dt = date '2023-04-30'
 and name like 'USED - PRO%%';

update raw_policy_data_tbl
 set policy_key = 0
    , sku = 0
where policy_key >= 9000;
-------------------------------------
select MIn(POLICY_KEY),Max(POLICY_KEY) from raw_policy_data_tbl order by POLICY_KEY;
+---------------+---------------+
|MIN(POLICY_KEY)|MAX(POLICY_KEY)|
+---------------+---------------+
|10166          |10347          |
+---------------+---------------+

Select COUNT(*) from policy_type_tbl;--32
Select * from policy_type_tbl;
--After update policy_type--
select policy_type_key,COUNT(policy_type_key) from raw_policy_data_tbl Group by policy_type_key;

 select COUNT(*) FROM policy_lkp;--182
 select COUNT(*) FROM policy_tbl;--182
 select COUNT(*) FROM policy_ext_tbl;--182

select * from  BPPP.CONTRACT_SALES_CHANNEL_TBL;
select * from  BPPP.UNDERWRITER_TBL;
--New row to insert
-->5. STARR Starr
--SELECT * FROM policy_tbl WHERE policy_tbl.UNDERWRITER_KEY = 5

 select * FROM policy_lkp order by POLICY_KEY,SOURCE_SYSTEM_CD;--182
 select * FROM policy_tbl  Order By NAME;--182

 select Distinct UNDERWRITER_KEY FROM policy_tbl;

-- update policy_tbl set UNDERWRITER_KEY = 5;
-- Commit;

select * from Policy_Plan_Component_Xref;
 Commit;
update Policy_Plan_Component_Xref set UNDERWRITER_KEY = 5;


 select * FROM policy_ext_tbl ORDER BY NEW_USED desc;--182

select SOURCE_SYSTEM_CD,COUNT(SOURCE_SYSTEM_CD) from POLICY_LKP group by SOURCE_SYSTEM_CD;--
+----------------+-----------------------+
|SOURCE_SYSTEM_CD|COUNT(SOURCE_SYSTEM_CD)|
+----------------+-----------------------+
|0               |182                    |
|2               |182                    |
+----------------+-----------------------+
select COUNT(*) FROM policy_lkp;--364
SELECT * FROM bppp.TERMS_AND_CONDITIONS_DIM;
select COUNT(*) from t_and_c_contract_template_xref;--9828
select * from t_and_c_contract_template_xref;--9828
select POSTAL_STATE_KEY,COUNT(POSTAL_STATE_KEY) from t_and_c_contract_template_xref group by  POSTAL_STATE_KEY;--54

SELECT 182*54 FROM DUAL;--9828
select PFT.NAME,pfx.* from policy_fee_xref PFX INNER JOIN bppp.POLICY_FEE_TYPE pft ON PFX.POLICY_FEE_TYPE_KEY = PFT.POLICY_FEE_TYPE_KEY
oRDER BY POLICY_KEY;
--> NEED TO ADD DEALER COST IN raw table
--> dEALER COST = 70% OF msrp


;--2184
select COUNT(*) from policy_fee_xref;--2184
select COUNT(*) from Policy_Plan_Component_Xref;--114
select * from Policy_Plan_Component_Xref order by PLAN_NM,COMPONENT_NM;--34
--> need to check in CORE if it have ADDER plans
--> CHeck job how it pick component
select COUNT(*) from policy_item_tbl;--486
select COUNT(*) from policy_item_tbl;--726
select * from policy_item_tbl order by  POLICY_KEY,NAME;--486
select NAME,COUNT(*) from policy_item_tbl group by NAME;--486
+--------------+--------+
|NAME          |COUNT(*)|
+--------------+--------+
|BOAT          |74      |
|TROLLING MOTOR|74      |
|MOTOR         |130     |
|DEPTH FINDER  |74      |
|TRAILER       |134     |
+--------------+--------+

--> Only showing motor and Trailer
--> need to check in core if other component why is not present (check with last set)
select * from POLICY_COVERAGE_TBL;--972
select COUNT(*) from POLICY_COVERAGE_TBL;--972
select COUNT(*) from POLICY_COVERAGE_TBL;--1452
select COUNT(*) from COVERAGE_PARTS_GROUP_XREF;--7348
select COUNT(*) from COVERAGE_PARTS_GROUP_XREF;--7348
select COUNT(*) from policy_item_selection_tbl;--490214
select COUNT(*) from policy_item_selection_tbl;--758964

