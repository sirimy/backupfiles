BPPP> DECLARE
             v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'BASS_1207', p_table_nm => 'CUSTOMER_DIM');

      BEGIN

              merge into   bppp.CUSTOMER_DIM tgt
                      using (

                          select distinct CUSTOMER_KEY,ADDRESS_KEY from (
                              select DISTINCT
                                      cd.CUSTOMER_KEY,
                                      T1.VISITOR_KEY,
                                      T1.ADDRESS_KEY,T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                                      --t1.PRIMARY_IND,t2.PRIMARY_IND,
                                      --t1.END_DT_KEY,t2.END_DT_KEY,
                                      T2.CREATION_DT,
                                      T2.INSERT_AUDIT_KEY,
                                      t1.SYNC_AUDIT_KEY,
                                      t1.UPDATE_AUDIT_KEY,
                                      t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY
                                      --,ATT.CREATION_DT
                                   from (
                                               select * from bppp.visitor_address_xref T0 where
                                               VISITOR_KEY in
                                               (
                                                   select vd2.VISITOR_KEY from bppp.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                       select vd2.CUSTOMER_KEY
                                                           --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                          from bpppstg.bpppstg_p_visitor_address_xref_bash_1207 gvdx
                                                                join bppp.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                          --       join bppp.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                                join bppp.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                                join bppp.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                          group by vd2.CUSTOMER_KEY
                                                          --  having COUNT(cvdx.address_key) <= 2 --509
                                                          -- having COUNT(cvdx.address_key) = 2 --57
                                                          --order by DBMS_RANDOM.RANDOM()

      --
                                               )
                                              )
                                       ) T1
                                       join bpppstg.bpppstg_p_visitor_address_xref_bash_1207 T2 on T2.VISITOR_KEY = t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                       --AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                                       join bppp.CUSTOMER_DIM cd on cd.PRIMARY_ADDRESS_KEY = t2.ADDRESS_KEY and cd.PRIMARY_VISITOR_KEY = t2.VISITOR_KEY
                                       join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.INSERT_AUDIT_KEY
                                   where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
                              )

                  ) src  on  (tgt.CUSTOMER_KEY = src.CUSTOMER_KEY  )
               WHEN MATCHED THEN
                      UPDATE SET
                                 tgt.PRIMARY_ADDRESS_KEY = src.ADDRESS_KEY,tgt.SYNC_AUDIT_KEY = NULL,tgt.UPDATE_AUDIT_KEY = v_audit_key
              ;

              DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
              DBMS_OUTPUT.PUT_LINE(v_audit_key);

             --COMMIT;

      END;
[2025-05-30 21:23:25] completed in 889 ms
15
887018