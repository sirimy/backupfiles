BPPP> DECLARE
             v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'Re-Print Request', p_table_nm => 'PROCESSING_QUEUE_TBL');

      BEGIN

                  Update BPPP.PROCESSING_QUEUE_TBL
                  SET  INSERT_AUDIT_KEY = v_audit_key
                  WHERE  PROCESSING_STATUS_CD = 'ORIGINAL' AND
                    ENTITY_CLASSIFIER_CD ='Contract'
                  AND PROCESSING_TYPE_CD IN ('Print','RePrint') AND
                   ENTITY_IDENTIFIER_KEY in (
                       select CONTRACT_XID from BPPP.CONTRACT_LKP where CONTRACT_KEY in (
                          select CONTRACT_KEY from BPPP.CONTRACT_LKP where    CONTRACT_XID in ('BPS004154', 'BPS004155', 'BPS004167', 'BPS004168', '3382676', '6368922')
                          ) and SOURCE_SYSTEM_CD =2
                       ) and INSERT_AUDIT_KEY >880000
                 ;

              DBMS_OUTPUT.PUT_LINE(v_audit_key);

             COMMIT;

      END;
[2025-06-02 14:26:56] completed in 618 ms
887399