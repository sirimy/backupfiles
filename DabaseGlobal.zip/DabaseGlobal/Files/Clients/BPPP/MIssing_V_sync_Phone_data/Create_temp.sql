

CREATE TABLE bpppstg_p_visitor_address_xref_bash_1207
  AS (
     select distinct pvdx.VISITOR_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,pvdx.END_DT_KEY,pvdx.EFF_DT_KEY,pvdx.INSERT_AUDIT_KEY,ATT3.CREATION_DT,pvdx.UPDATE_AUDIT_KEY,pvdx.SYNC_AUDIT_KEY
     from bppp.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join bppp.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and cl.PHONE_NO IS NOT NULL and cl.PHONE_XID IS NOT NULL and cl.ADDRESS_LINE1_TX IS NULL
                    join bppp.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                    join bppp.ADDRESS_DIM AD on AD.ADDRESS_KEY = aot.ADDRESS_KEY
                    join bppp.CUSTOMER_DIM cd on cd.PRIMARY_ADDRESS_KEY = ad.ADDRESS_KEY
                    join bppp.VISITOR_DIM vd on vd.CUSTOMER_KEY = cd.CUSTOMER_KEY
                    join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = vd.VISITOR_KEY and pvdx.PRIMARY_IND = 'Y'
--                     join bppp.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY AND pvdx.PRIMARY_IND = 'Y'
--                     join bppp.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                    join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                    join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                    join AUDIT_TBL ATT3 on pvdx.INSERT_AUDIT_KEY = ATT3.AUDIT_KEY
--                     join bppp.CONTRACT_COVERAGE_XREF ccx on ccx.SI_KEY = sd.SI_KEY
--                     join bppp.CONTRACT_LKP clk on clk.CONTRACT_KEY = ccx.CONTRACT_KEY and clk.SOURCE_SYSTEM_CD = '0'
                where DSACE.PROCESS_DT >= '20250430' AND
                      DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
                      AND AD.FIRST_NM IS NULL AND AD.LAST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
                      AND ATT.CREATION_DT >= date '2025-04-30'
                      AND ATT2.CREATION_DT >= date '2025-04-30'
     )
;--