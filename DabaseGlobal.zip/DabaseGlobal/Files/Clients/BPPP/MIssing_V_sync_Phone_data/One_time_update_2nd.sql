DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'PRIMARY_IND = N To Y', p_process_nm => 'BASS_1207', p_table_nm => 'VISITOR_ADDRESS_XREF');

BEGIN

      update bppp.visitor_address_xref
        SET PRIMARY_IND = 'X' ,SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key
    where PRIMARY_IND = 'Y' AND VISITOR_KEY in (
    10535826,
                10535824,
                10535820,
                10501010,
                10491836
        );

    update bppp.visitor_address_xref
        SET PRIMARY_IND = 'Y' ,SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key,END_DT_KEY =99999
    where PRIMARY_IND = 'N' AND VISITOR_KEY in (
    10535826,
                10535824,
                10535820,
                10501010,
                10491836
        );

 update bppp.visitor_address_xref
        SET PRIMARY_IND = 'N' ,SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key,END_DT_KEY =EFF_DT_KEY + 1
    where PRIMARY_IND = 'X' AND VISITOR_KEY in (
     10535826,
                10535824,
                10535820,
                10501010,
                10491836
        );


end;

COMMIT;

--     select * from bppp.visitor_address_xref vxref
--     where VISITOR_KEY in (
--     10524042,
--     10524044,
--     10524046,
--     10524048
--         );