SELECT
							'CONTRACT_NO'||','||
							'POLICY_KEY_OF_CONTRACT'||','||
							'NAME'||','||
							'EFFECTIVE_DT'||','||
							'EXP_DT'||','||
							'NEW_USED_IND'||','||
							'PRODUCT_CAT_DESC'||','||
							'MIN_HP'||','||
							'MAX_HP'||','||
							'TERM'
					FROM DUAL
					UNION ALL
					 select     CONTRACT_NO||','||
								POLICY_KEY||','||
								NAME||','||
							   to_char(EFFECTIVE_DT,'mm/dd/yyyy') ||','||
							   to_char(EXP_DT,'mm/dd/yyyy')  ||','||
								NEW_USED_IND ||','||
								PRODUCT_CAT_DESC||','||
								MIN_HP||','||
								MAX_HP||','||
								YEAR
					 from (
									select
											CL.CONTRACT_XID AS CONTRACT_NO,
											PL.POLICY_KEY,
											PL.NAME,
											PL.CONTRACT_SALES_CHANNEL_KEY,
											PL.EFFECTIVE_DT,
											PL.EXP_DT,
											PL.NEW_USED_IND ,
											PLEX.PRODUCT_CAT_DESC,
											PLEX.PRODUCT_CATEGORY_KEY,
											PLEX.MIN_HP,
											PLEX.MAX_HP,
											TD.YEAR
									from BPPP.CONTRACT_DIM CD
										Inner join BPPP.CONTRACT_LKP CL on CD.CONTRACT_KEY = CL.CONTRACT_KEY and CL.SOURCE_SYSTEM_CD = 0
										Inner join BPPP.POLICY_TBL PL on CD.POLICY_KEY = PL.POLICY_KEY
										Inner join BPPP.POLICY_EXT_TBL PLEX on PLEX.POLICY_KEY = PL.POLICY_KEY
										Inner join P_TERM_DIM  TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
									Where CL.CONTRACT_XID in (
										select CONTRACT_NO from bppp.RAW_FINANCIAL_REPORT_REVIEW RF inner join AUDIT_TBL AT
										on RF.INSERT_AUDIT_KEY = AT.AUDIT_KEY
										)
									 AND CD.CONTRACT_CREATED_DT > date '2023-05-01'
									 AND CL.CONTRACT_XID Not like '%%BPS%%'
						MINUS
									Select RC.CONTRACT_NO,
										   PL.POLICY_KEY,
										   Upper(RC.COVERED_PLAN_NM) AS NAME,
											PL.CONTRACT_SALES_CHANNEL_KEY,
											PL.EFFECTIVE_DT,
											PL.EXP_DT,
											PL.NEW_USED_IND ,
										   PLEX.PRODUCT_CAT_DESC,
										   PLEX.PRODUCT_CATEGORY_KEY,
										   PLEX.MIN_HP,
										   PLEX.MAX_HP,
										   TD.YEAR
									FROM (
									   select
											 a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
											 JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
											 JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
											 JOIN P_POLICY_TBL PL ON PL.NAME = Upper(RC.COVERED_PLAN_NM)
											 Inner join BPPP.POLICY_EXT_TBL PLEX on PLEX.POLICY_KEY = PL.POLICY_KEY
											  JOIN P_TERM_DIM  TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
									   WHERE 1=1
										 AND rc.rno = 1
										 AND rh.rno = 1
										 AND rw.rno = 1
										 AND TO_DATE(RC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD') BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT
										 AND CASE WHEN  Upper(RC.COVERED_PLAN_NM) LIKE '%%ADVANTAGE%%' THEN 'TRUE'
												  WHEN Upper(RC.COVERED_PLAN_NM) NOT LIKE '%%ADVANTAGE%%' AND
													   TO_NUMBER(RW.ENGINE1_HP_NO) BETWEEN PLEX.MIN_HP AND PLEX.MAX_HP
													   AND PLEX.PRODUCT_CATEGORY_KEY = DECODE(UPPER(bpppStg.fn_get_product_category (p_model_nm => RC.PRODUCT_TYPE_CD, p_product_type => 'MOTOR')),
																		 '4-STROKE', 7,
																		 '4 STROKE', 7,
																		 '2-STROKE', 6,
																		 '2 STROKE', 6,
																		 'OPTIMAX', 5,
																		 'DFI', 5,
																		 'MERCRUISER',2
																		 )

													  THEN 'TRUE' ELSE 'FALSE'
											 END = 'TRUE'
										 AND TO_DATE(RH.PROCESS_DT, 'YYYYMMDD') > date '2023-05-01'
										 AND TD.YEAR =  ROUND((TO_DATE(RH.contract_expire_dt, 'YYYYMMDD') - TO_DATE(RC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD')) / 365)
										AND CASE WHEN NVL(RC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0 OR Upper(RC.COVERED_PLAN_NM) LIKE '%%USED%%' THEN 'N'
												WHEN NVL(RC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0 AND Upper(RC.COVERED_PLAN_NM) NOT LIKE '%%USED%%' THEN 'Y'
										   END = PL.NEW_USED_IND
										 AND RC.CONTRACT_NO in (
																select RF.CONTRACT_NO from bppp.RAW_FINANCIAL_REPORT_REVIEW RF
																	--inner join AUDIT_TBL AT on RF.INSERT_AUDIT_KEY = AT.AUDIT_KEY
									)
							)
					Where CONTRACT_NO not in (select CONTRACT_NO from bppp.v_contract_sales_errors_report)
							and CONTRACT_NO not in ('8790995','9171468');


select
											CL.CONTRACT_XID AS CONTRACT_NO,
											PL.POLICY_KEY,
											PL.NAME,
											PL.CONTRACT_SALES_CHANNEL_KEY,
											PL.EFFECTIVE_DT,
											PL.EXP_DT,
											PL.NEW_USED_IND ,
											PLEX.PRODUCT_CAT_DESC,
											PLEX.PRODUCT_CATEGORY_KEY,
											PLEX.MIN_HP,
											PLEX.MAX_HP,
											TD.YEAR
									from BPPP.CONTRACT_DIM CD
										Inner join BPPP.CONTRACT_LKP CL on CD.CONTRACT_KEY = CL.CONTRACT_KEY and CL.SOURCE_SYSTEM_CD = 0
										Inner join BPPP.POLICY_TBL PL on CD.POLICY_KEY = PL.POLICY_KEY
										Inner join BPPP.POLICY_EXT_TBL PLEX on PLEX.POLICY_KEY = PL.POLICY_KEY
										Inner join P_TERM_DIM  TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
									Where CL.CONTRACT_XID in (
										select CONTRACT_NO from bppp.RAW_FINANCIAL_REPORT_REVIEW RF inner join AUDIT_TBL AT
										on RF.INSERT_AUDIT_KEY = AT.AUDIT_KEY
										)
									 AND CD.CONTRACT_CREATED_DT > date '2023-05-01'
									 AND CL.CONTRACT_XID Not like '%%BPS%%'
						MINUS
									Select RC.CONTRACT_NO,
										   PL.POLICY_KEY,
										   Upper(RC.COVERED_PLAN_NM) AS NAME,
											PL.CONTRACT_SALES_CHANNEL_KEY,
											PL.EFFECTIVE_DT,
											PL.EXP_DT,
											PL.NEW_USED_IND ,
										   PLEX.PRODUCT_CAT_DESC,
										   PLEX.PRODUCT_CATEGORY_KEY,
										   PLEX.MIN_HP,
										   PLEX.MAX_HP,
										   TD.YEAR
									FROM (
									   select
											 a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
											 JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
											 JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
											 JOIN P_POLICY_TBL PL ON PL.NAME = Upper(RC.COVERED_PLAN_NM)
											 Inner join BPPP.POLICY_EXT_TBL PLEX on PLEX.POLICY_KEY = PL.POLICY_KEY
											  JOIN P_TERM_DIM  TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
									   WHERE 1=1
										 AND rc.rno = 1
										 AND rh.rno = 1
										 AND rw.rno = 1
										 AND TO_DATE(RC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD') BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT
										 AND CASE WHEN  Upper(RC.COVERED_PLAN_NM) LIKE '%%ADVANTAGE%%' THEN 'TRUE'
												  WHEN Upper(RC.COVERED_PLAN_NM) NOT LIKE '%%ADVANTAGE%%' AND
													   TO_NUMBER(RW.ENGINE1_HP_NO) BETWEEN PLEX.MIN_HP AND PLEX.MAX_HP
													   AND PLEX.PRODUCT_CATEGORY_KEY = DECODE(UPPER(bpppStg.fn_get_product_category (p_model_nm => RC.PRODUCT_TYPE_CD, p_product_type => 'MOTOR')),
																		 '4-STROKE', 7,
																		 '4 STROKE', 7,
																		 '2-STROKE', 6,
																		 '2 STROKE', 6,
																		 'OPTIMAX', 5,
																		 'DFI', 5,
																		 'MERCRUISER',2
																		 )

													  THEN 'TRUE' ELSE 'FALSE'
											 END = 'TRUE'
										 AND TO_DATE(RH.PROCESS_DT, 'YYYYMMDD') > date '2023-05-01'
										 AND TD.YEAR =  ROUND((TO_DATE(RH.contract_expire_dt, 'YYYYMMDD') - TO_DATE(RC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD')) / 365)
										AND CASE WHEN NVL(RC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0 OR Upper(RC.COVERED_PLAN_NM) LIKE '%%USED%%' THEN 'N'
												WHEN NVL(RC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0 AND Upper(RC.COVERED_PLAN_NM) NOT LIKE '%%USED%%' THEN 'Y'
										   END = PL.NEW_USED_IND
										 AND RC.CONTRACT_NO in (
																select RF.CONTRACT_NO from bppp.RAW_FINANCIAL_REPORT_REVIEW RF
																	--inner join AUDIT_TBL AT on RF.INSERT_AUDIT_KEY = AT.AUDIT_KEY
									);





Select RC.CONTRACT_NO,
										   PL.POLICY_KEY,
										   CONTRACT_EFFECTIVE_DT,
										   Upper(RC.COVERED_PLAN_NM) AS NAME,
											PL.CONTRACT_SALES_CHANNEL_KEY,
											PL.EFFECTIVE_DT,
											PL.EXP_DT,
											PL.NEW_USED_IND ,
										   PLEX.PRODUCT_CAT_DESC,
										   PLEX.PRODUCT_CATEGORY_KEY,
										   PLEX.MIN_HP,
										   PLEX.MAX_HP,
										   TD.YEAR
									FROM (
									   select
											 a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
											 JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
											 JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY DESC) rno from bppp.RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
											 JOIN P_POLICY_TBL PL ON PL.NAME = Upper(RC.COVERED_PLAN_NM)
											 Inner join BPPP.POLICY_EXT_TBL PLEX on PLEX.POLICY_KEY = PL.POLICY_KEY
											  JOIN P_TERM_DIM  TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
									   WHERE 1=1
										 AND rc.rno = 1
										 AND rh.rno = 1
										 AND rw.rno = 1
									 -- AND TO_DATE(RC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD') BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT
										 AND CASE WHEN  Upper(RC.COVERED_PLAN_NM) LIKE '%%ADVANTAGE%%' THEN 'TRUE'
												  WHEN Upper(RC.COVERED_PLAN_NM) NOT LIKE '%%ADVANTAGE%%' AND
													   TO_NUMBER(RW.ENGINE1_HP_NO) BETWEEN PLEX.MIN_HP AND PLEX.MAX_HP
													   AND PLEX.PRODUCT_CATEGORY_KEY = DECODE(UPPER(bpppStg.fn_get_product_category (p_model_nm => RC.PRODUCT_TYPE_CD, p_product_type => 'MOTOR')),
																		 '4-STROKE', 7,
																		 '4 STROKE', 7,
																		 '2-STROKE', 6,
																		 '2 STROKE', 6,
																		 'OPTIMAX', 5,
																		 'DFI', 5,
																		 'MERCRUISER',2
																		 )

													  THEN 'TRUE' ELSE 'FALSE'
											 END = 'TRUE'
										 AND TO_DATE(RH.PROCESS_DT, 'YYYYMMDD') > date '2023-05-01'
										 AND TD.YEAR =  ROUND((TO_DATE(RH.contract_expire_dt, 'YYYYMMDD') - TO_DATE(RC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD')) / 365)
										AND CASE WHEN NVL(RC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0 OR Upper(RC.COVERED_PLAN_NM) LIKE '%%USED%%' THEN 'N'
												WHEN NVL(RC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0 AND Upper(RC.COVERED_PLAN_NM) NOT LIKE '%%USED%%' THEN 'Y'
										   END = PL.NEW_USED_IND
										 AND RC.CONTRACT_NO in (
																select RF.CONTRACT_NO from bppp.RAW_FINANCIAL_REPORT_REVIEW RF
																	--inner join AUDIT_TBL AT on RF.INSERT_AUDIT_KEY = AT.AUDIT_KEY
									)
                                    AND RC.CONTRACT_NO = '8696654' ;

+-----------+----------+-----------+--------------------------+------------+----------+------------+----------------+--------------------+------+------+----+
|CONTRACT_NO|POLICY_KEY|NAME       |CONTRACT_SALES_CHANNEL_KEY|EFFECTIVE_DT|EXP_DT    |NEW_USED_IND|PRODUCT_CAT_DESC|PRODUCT_CATEGORY_KEY|MIN_HP|MAX_HP|YEAR|
+-----------+----------+-----------+--------------------------+------------+----------+------------+----------------+--------------------+------+------+----+
|8696654    |10032     |PREMIER PRO|3                         |2023-04-30  |2099-12-31|Y           |4 STROKE        |7                   |70    |139   |7   |
+-----------+----------+-----------+--------------------------+------------+----------+------------+----------------+--------------------+------+------+----+
+-----------+----------+-----------+--------------------------+------------+----------+------------+----------------+--------------------+------+------+----+
|CONTRACT_NO|POLICY_KEY|NAME       |CONTRACT_SALES_CHANNEL_KEY|EFFECTIVE_DT|EXP_DT    |NEW_USED_IND|PRODUCT_CAT_DESC|PRODUCT_CATEGORY_KEY|MIN_HP|MAX_HP|YEAR|
+-----------+----------+-----------+--------------------------+------------+----------+------------+----------------+--------------------+------+------+----+
|8696654    |9532      |PREMIER PRO|3                         |2022-06-01  |2023-04-29|Y           |4 STROKE        |7                   |70    |139   |7   |
+-----------+----------+-----------+--------------------------+------------+----------+------------+----------------+--------------------+------+------+----+

