

select * from bppp.RAW_FINANCIAL_REPORT_REVIEW RF inner join AUDIT_TBL AT
on RF.INSERT_AUDIT_KEY = AT.AUDIT_KEY
where AT.CREATION_DT > date '2023-05-01'
Order by AT.CREATION_DT DESC;

select * from bppp.RAW_FINANCIAL_REPORT_REVIEW where CONTRACT_NO = '8910211';
+-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+---+------------+-----+-------------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+----------+-----------------------------+------------------------------+----------+--------------------------------+-----------------+-----------+
|UNDERWRITER|SALES_CHANNEL|PAYMENT_MODE|DEALER_NO|CONTRACT_NO|FIRST_NM|FIRM_NM|LAST_NM|CONTRACT_START_DATE|CONTRACT_SALE_DATE|PROCESS_DATE|HP |NEW_USED_IND|MONTH|COVERAGE     |CORRECT_RETAIL_PAID|RETAIL_PRICE|GROSS_WRITTEN_PREMIUM|UNDERWRITER_RESERVE|UNDERWRITER_FEE|UNDERWRITER_TAX|SIC_COST|SIC_RESERVE|DEALER_RESIDES_IN|HULL_SERIAL_NO|MOTOR_SERIAL_NO|ERRORS|INSERT_AUDIT_KEY|FINANCIAL_MONTH|CONTRACT_END_DATE|PRODUCT_TYPE_CD|UNIT_CD|BUCKET_NM |BOAT_WARRANTY_EXPIRATION_DATE|MOTOR_WARRANTY_EXPIRATION_DATE|ERROR_DESC|FILE_NM                         |TRAILER_SERIAL_NO|OBLIGOR_FEE|
+-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+---+------------+-----+-------------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+----------+-----------------------------+------------------------------+----------+--------------------------------+-----------------+-----------+
|STARR      |POS          |FINANCED    |42362    |8910211    |MARGARET|NULL   |TURNER |2023-05-26         |2023-05-26        |2023-06-14  |250|N           |36   |USED PRO PLUS|2839.00            |2839.00     |327.51               |250.53             |18.54          |0.00           |327.59  |250.53     |AL               |CAY0P158G122  |3B099956       |NULL  |742320          |202306         |2026-05-26       |250 PRO XS     |FG     |FIBERGLASS|2023-05-26                   |2025-05-26                    |NULL      |QA_Report_6.14.23.csv           |7M2AA2023NM000694|0.00       |
|STARR      |POS          |FINANCED    |42362    |8910211    |MARGARET|NULL   |TURNER |2023-05-26         |2023-05-26        |2023-06-14  |250|N           |36   |USED PRO PLUS|2839.00            |2839.00     |327.51               |250.53             |18.54          |0.00           |327.59  |250.53     |AL               |CAY0P158G122  |3B099956       |NULL  |743454          |202306         |2026-05-26       |250 XL 4S      |FG     |FIBERGLASS|2023-05-26                   |2025-05-26                    |NULL      |QA_Report_correction_6.14.23.csv|7M2AA2023NM000694|0.00       |
+-----------+-------------+------------+---------+-----------+--------+-------+-------+-------------------+------------------+------------+---+------------+-----+-------------+-------------------+------------+---------------------+-------------------+---------------+---------------+--------+-----------+-----------------+--------------+---------------+------+----------------+---------------+-----------------+---------------+-------+----------+-----------------------------+------------------------------+----------+--------------------------------+-----------------+-----------+

select * from BPPP.CONTRACT_LKP where CONTRACT_XID = '8910211';
select * from BPPP.CONTRACT_DIM where CONTRACT_KEY = 329012;
 +------------+-------------------+----------------+-----------------+---------------+----------+--------------+-----------+------------+----------+-----------+-----------+--------------------+------------------------+---------------------+----------------+----------------+--------------+----------+--------------+---------------+-------------+-------------------------+-------------------+
|CONTRACT_KEY|CONTRACT_STATUS_KEY|CONTRACT_SALE_DT|CONTRACT_START_DT|CONTRACT_END_DT|RETAIL_AMT|RETAIL_TAX_AMT|CURRENCY_CD|DISCOUNT_AMT|POLICY_KEY|VISITOR_KEY|ADDRESS_KEY|PURCHASE_ADDRESS_KEY|TERMS_AND_CONDITIONS_KEY|CONTRACT_TEMPLATE_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|OUTLET_KEY|LIENHOLDER_KEY|OBLIGOR_FEE_AMT|FRONT_FEE_AMT|CONTRACT_PAYMENT_TYPE_KEY|CONTRACT_CREATED_DT|
+------------+-------------------+----------------+-----------------+---------------+----------+--------------+-----------+------------+----------+-----------+-----------+--------------------+------------------------+---------------------+----------------+----------------+--------------+----------+--------------+---------------+-------------+-------------------------+-------------------+
|329012      |1                  |2023-05-26      |2023-05-26       |2026-05-26     |2839.00   |NULL          |NULL       |NULL        |10176     |9783852    |13887798   |13887798            |7                       |1                    |743456          |NULL            |743509        |9102      |276           |NULL           |NULL         |2                        |2023-06-14         |
+------------+-------------------+----------------+-----------------+---------------+----------+--------------+-----------+------------+----------+-----------+-----------+--------------------+------------------------+---------------------+----------------+----------------+--------------+----------+--------------+---------------+-------------+-------------------------+-------------------+


select * from BPPP.POLICY_TBL where POLICY_KEY = 10176;

 +----------+-------------+-----------+------------------+------------+----------+---------------+--------+--------------------------+
|POLICY_KEY|NAME         |DESCRIPTION|POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |POLICY_TYPE_KEY|TERM_KEY|CONTRACT_SALES_CHANNEL_KEY|
+----------+-------------+-----------+------------------+------------+----------+---------------+--------+--------------------------+
|10176     |USED PRO PLUS|NULL       |9010176           |2023-04-30  |2099-12-31|157            |3       |3                         |
+----------+-------------+-----------+------------------+------------+----------+---------------+--------+--------------------------+


select * FROM P_POLICY_TBL PL where PL.POLICY_KEY = 10176;


select * from BPPP.POLICY_EXT_TBL where POLICY_KEY = 10176;
+----------+------+------+---------+---------+--------------------+--------+----------------+
|POLICY_KEY|MIN_HP|MAX_HP|MIN_LITER|MAX_LITER|PRODUCT_CATEGORY_KEY|NEW_USED|PRODUCT_CAT_DESC|
+----------+------+------+---------+---------+--------------------+--------+----------------+
|10176     |140   |300   |140      |300      |7                   |USED    |4 STROKE        |
+----------+------+------+---------+---------+--------------------+--------+----------------+


select * from BPPP.POLICY_ITEM_TBL where POLICY_KEY = 10176;
+---------------+--------------+----------------+----------------+--------------+----------+-----------------------------------------+
|POLICY_ITEM_KEY|NAME          |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|POLICY_KEY|DESCRIPTION                              |
+---------------+--------------+----------------+----------------+--------------+----------+-----------------------------------------+
|64381          |BOAT          |740924          |NULL            |741179        |10176     |BOAT line item for policy 10176          |
|64389          |DEPTH FINDER  |740924          |NULL            |741179        |10176     |DEPTH FINDER line item for policy 10176  |
|64397          |MOTOR         |740924          |NULL            |741179        |10176     |MOTOR line item for policy 10176         |
|64405          |TRAILER       |740924          |NULL            |741179        |10176     |TRAILER line item for policy 10176       |
|64413          |TROLLING MOTOR|740924          |NULL            |741179        |10176     |TROLLING MOTOR line item for policy 10176|
+---------------+--------------+----------------+----------------+--------------+----------+-----------------------------------------+



select COVERED_PLAN_NM,CONTRACT_NO  from bppp.RAW_CONTRACT_COVERAGE_TBL RC where CONTRACT_NO = '8910211';
select *  from bppp.RAW_CONTRACT_HOLDER_TBL RH where CONTRACT_NO = '8910211';
select *  from bppp.RAW_CONTRACT_WATERCRAFT_TBL RW where CONTRACT_NO = '8910211';


Select *
FROM (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
         JOIN (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
         JOIN (select a.*,row_number() over(partition by a.contract_no order by 1) rno from bppp.RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
   WHERE 1=1
     AND rc.rno = 1
     AND rh.rno = 1
     AND rw.rno = 1
     AND RC.CONTRACT_NO = '8910211'
    ;

Select RC.COVERED_PLAN_NM,RH.PROCESS_DT,RW.ENGINE1_HP_NO ,RC.NEW_BOAT_FACTERM_YR_AMT,RC.NEW_BOAT_EXTTERM_YR_AMT
,RC.USED_BOAT_TERM_MONTHS_AMT,RH.contract_expire_dt,RC.CONTRACT_EFFECTIVE_DT,RC.PRODUCT_TYPE_CD,RW.engine1_model_nm,bpppStg.fn_get_product_category (p_model_nm => RC.PRODUCT_TYPE_CD, p_product_type => 'MOTOR')
FROM (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY desc) rno from bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
         JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY desc) rno from bppp.RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
         JOIN (select a.*,row_number() over(partition by a.contract_no order by a.INSERT_AUDIT_KEY desc) rno from bppp.RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
   WHERE 1=1
     AND rc.rno = 1
     AND rh.rno = 1
     AND rw.rno = 1
     AND RC.CONTRACT_NO = '8910211'
    ;
+---------------+----------+-------------+-----------------------+-----------------------+-------------------------+------------------+---------------------+---------------+----------------+---------------------------------------------------------------------------------------+
|COVERED_PLAN_NM|PROCESS_DT|ENGINE1_HP_NO|NEW_BOAT_FACTERM_YR_AMT|NEW_BOAT_EXTTERM_YR_AMT|USED_BOAT_TERM_MONTHS_AMT|CONTRACT_EXPIRE_DT|CONTRACT_EFFECTIVE_DT|PRODUCT_TYPE_CD|ENGINE1_MODEL_NM|BPPPSTG.FN_GET_PRODUCT_CATEGORY(P_MODEL_NM=>RC.PRODUCT_TYPE_CD,P_PRODUCT_TYPE=>'MOTOR')|
+---------------+----------+-------------+-----------------------+-----------------------+-------------------------+------------------+---------------------+---------------+----------------+---------------------------------------------------------------------------------------+
|Used Pro Plus  |20230614  |250.00       |NULL                   |NULL                   |NULL                     |20260526          |20230526             |250 PRO XS     |250 PRO XS      |DFI                                                                                    |
+---------------+----------+-------------+-----------------------+-----------------------+-------------------------+------------------+---------------------+---------------+----------------+---------------------------------------------------------------------------------------+
-+


 SELECT PL.NAME ,POLICY_PRODUCT_XID,PL.POLICY_KEY,TD.YEAR ,PL.NEW_USED_IND ,PET.MIN_HP , PET.MAX_HP,PET.PRODUCT_CATEGORY_KEY,PL.EFFECTIVE_DT ,PL.EXP_DT
            --  INTO L_SKU_NO
              FROM P_POLICY_TBL PL
                    JOIN P_POLICY_TYPE_TBL PTL ON (PL.POLICY_TYPE_KEY = PTL.POLICY_TYPE_KEY)
                     JOIN P_POLICY_EXT_TBL  PET ON (PL.POLICY_KEY = PET.POLICY_KEY)
                      JOIN P_TERM_DIM         TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
                       LEFT JOIN (SELECT DISTINCT pricing_scheme_key, policy_key  --, new_used
                               FROM bppp.RAW_POLICY_DATA_TBL
                            ) raw_pol
                          ON (PL.POLICY_KEY  = raw_pol.POLICY_KEY)
             WHERE
                   PL.NAME = upper('Used Pro Plus')
               AND PL.CONTRACT_SALES_CHANNEL_KEY = 3
               AND TO_NUMBER(250.00) BETWEEN MIN_HP AND MAX_HP
               AND TD.YEAR =  ROUND((TO_DATE('20260526', 'YYYYMMDD') - TO_DATE('20230526', 'YYYYMMDD')) / 365)
               AND PL.NEW_USED_IND = 'N'
               AND PET.PRODUCT_CATEGORY_KEY = 5
               AND TO_DATE('20230614', 'YYYYMMDD')  BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT;

+-------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
|NAME         |POLICY_PRODUCT_XID|POLICY_KEY|YEAR|NEW_USED_IND|MIN_HP|MAX_HP|PRODUCT_CATEGORY_KEY|EFFECTIVE_DT|EXP_DT    |
+-------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
|USED PRO PLUS|9010181           |10181     |3   |N           |140   |300   |5                   |2023-04-30  |2099-12-31|
+-------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
 SELECT PL.NAME ,POLICY_PRODUCT_XID,PL.POLICY_KEY,TD.YEAR ,PL.NEW_USED_IND ,PET.MIN_HP , PET.MAX_HP,PET.PRODUCT_CATEGORY_KEY,PL.EFFECTIVE_DT ,PL.EXP_DT
            --  INTO L_SKU_NO
              FROM P_POLICY_TBL PL
                    JOIN P_POLICY_TYPE_TBL PTL ON (PL.POLICY_TYPE_KEY = PTL.POLICY_TYPE_KEY)
                     JOIN P_POLICY_EXT_TBL  PET ON (PL.POLICY_KEY = PET.POLICY_KEY)
                      JOIN P_TERM_DIM         TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
                       LEFT JOIN (SELECT DISTINCT pricing_scheme_key, policy_key  --, new_used
                               FROM bppp.RAW_POLICY_DATA_TBL
                            ) raw_pol
                          ON (PL.POLICY_KEY  = raw_pol.POLICY_KEY)
             WHERE PL.POLICY_KEY = 10176;
+-------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
|NAME         |POLICY_PRODUCT_XID|POLICY_KEY|YEAR|NEW_USED_IND|MIN_HP|MAX_HP|PRODUCT_CATEGORY_KEY|EFFECTIVE_DT|EXP_DT    |
+-------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+
|USED PRO PLUS|9010176           |10176     |3   |N           |140   |300   |7                   |2023-04-30  |2099-12-31|
+-------------+------------------+----------+----+------------+------+------+--------------------+------------+----------+

--Premier Pro
--
-- ==>P_POLICY_TBL PL [1] PL.NAME [2] PL.CONTRACT_SALES_CHANNEL_KEY  [3] PL.NEW_USED_IND  [4] CREC.PROCESS_DT    BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT
--
-- ==> P_POLICY_EXT_TBL  PET [1] ENGINE1_HP_NO) BETWEEN MIN_HP AND MAX_HP  [2] PET.PRODUCT_CATEGORY_KEY
--
-- ==> Term year TD.YEAR


