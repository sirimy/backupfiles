--Total 46 component rows for existing pricing in prod...out of these 34 are base plan names. Rest 12 are Adders
select * from bppp.Policy_Plan_Component_Xref where END_DT >= sysdate --and PLAN_NM not like '%ADDER%'
 order by EFFECTIVE_DT desc, PLAN_NM;

select * from Policy_Plan_Component_Xref order by EFFECTIVE_DT desc, PLAN_NM, COMPONENT_NM;

select distinct PLAN_NM from Policy_Plan_Component_Xref order by PLAN_NM;


--populate_policy_plan_component_xref.job was used to populate plan names, which exist in bppp.Policy_Plan_Component_Xref
--however, we would need to handle the newer plans manually here:
select distinct name from policy_tbl
MINUS
select distinct PLAN_NM from Policy_Plan_Component_Xref
minus
select distinct PLAN_NM from bppp.Policy_Plan_Component_Xref where END_DT > sysdate  --EFFECTIVE_DT < date '2022-07-01' and
order by 1;
--16 rows

select * from (
select distinct name from policy_tbl
MINUS
select distinct PLAN_NM from Policy_Plan_Component_Xref
minus
select distinct PLAN_NM from bppp.Policy_Plan_Component_Xref where END_DT > sysdate  --EFFECTIVE_DT < date '2022-07-01' and
              ) t
         cross join (select distinct COMPONENT_NM from bppp.Policy_Plan_Component_Xref where END_DT >= sysdate ) c
order by name, COMPONENT_NM;


--created a csv of newer plans with their components and loaded that into this table
create table raw_Policy_Plan_Component_Xref (
    PLAN_NM          VARCHAR2(100) not null,
    COMPONENT_NM     VARCHAR2(100) not null,
    COMPONENT_SEQ    NUMBER
);

-- delete from raw_Policy_Plan_Component_Xref;
-- commit;

-- delete from raw_Policy_Plan_Component_Xref where trim(PLAN_NM) is null;
-- delete from Policy_Plan_Component_Xref;
-- commit;

select * from raw_Policy_Plan_Component_Xref order by PLAN_NM, COMPONENT_NM;

--Plan names which were there in RAW_POLICY_DATA_TBL already were not loaded into raw_Policy_Plan_Component_Xref
select name from RAW_POLICY_DATA_TBL
minus
select PLAN_NM from raw_Policy_Plan_Component_Xref
order by 1;

--Every plan should have exactly  1 COMPONENT_SEQ populated and the value should be 1 only
select PLAN_NM, max(COMPONENT_SEQ), count(distinct COMPONENT_SEQ) from raw_Policy_Plan_Component_Xref
group by PLAN_NM
--having max(COMPONENT_SEQ) is null or count(distinct COMPONENT_SEQ) > 1 --this is for debugging
order by PLAN_NM;

--all plans from policy_tbl must exist in raw_Policy_Plan_Component_Xref else reload raw_Policy_Plan_Component_Xref
select distinct name from policy_tbl
MINUS
select distinct PLAN_NM from raw_Policy_Plan_Component_Xref;
--no rows

select distinct PLAN_NM from POLICY_PLAN_COMPONENT_XREF;

-- rollback;
--finally populating Policy_Plan_Component_Xref
--We need to populate this against all the plan names (new or existing) as we maintain EFFECTIVE_DT, END_DT in this table
insert into Policy_Plan_Component_Xref (UNDERWRITER_KEY, PLAN_NM, EFFECTIVE_DT, END_DT, COMPONENT_NM, COMPONENT_SEQ)
select 5, PLAN_NM, EFFECTIVE_DT, EXP_DT, COMPONENT_NM, COMPONENT_SEQ
 from  (
        select distinct rpx.*, pol.EFFECTIVE_DT, pol.EXP_DT from POLICY_TBL pol join raw_Policy_Plan_Component_Xref rpx on rpx.PLAN_NM = pol.NAME
        where  pol.NAME not in (select x.plan_nm from Policy_Plan_Component_Xref x)
        order by rpx.PLAN_NM, rpx.COMPONENT_NM
        );
--80 rows
commit;

select * from Policy_Plan_Component_Xref order by EFFECTIVE_DT desc, PLAN_NM, COMPONENT_NM;

select distinct name from policy_tbl
MINUS
select distinct PLAN_NM from Policy_Plan_Component_Xref;
--no rows --good

select distinct name from POLICY_TBL order by NAME;
--25 rows

--every PLAN_NM must have one and only one COMPONENT_SEQ
select PLAN_NM, max(COMPONENT_SEQ), count(distinct COMPONENT_SEQ) from Policy_Plan_Component_Xref
group by PLAN_NM
-- having max(COMPONENT_SEQ) is null or count(distinct COMPONENT_SEQ) > 1 --this is for debugging
order by PLAN_NM;

select PLAN_NM, COMPONENT_NM from Policy_Plan_Component_Xref where COMPONENT_SEQ is not null order by PLAN_NM;