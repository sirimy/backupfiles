-- delete FROM Parent_POLICY_TYPE;
-- commit;

INSERT INTO Parent_POLICY_TYPE
   (Parent_POLICY_TYPE_ID, Parent_POLICY_TYPE_Name, last_updated_by, last_updated_ts)
 SELECT Parent_POLICY_TYPE_KEY, Parent_POLICY_TYPE_Name, 'BASS-1080', systimestamp
   FROM bppp.Parent_POLICY_TYPE_tbl
  WHERE Parent_POLICY_TYPE_KEY NOT IN (
           SELECT PT2.Parent_POLICY_TYPE_ID FROM Parent_POLICY_TYPE PT2
           );
 --no rows
COMMIT;

/*DELETE FROM Parent_POLICY_TYPE  PTT 
 WHERE PTT.Parent_POLICY_TYPE_ID NOT IN (
        SELECT POL.Parent_POLICY_TYPE_ID FROM POLICY POL
       );
       
COMMIT; 
*/


select * from Parent_POLICY_TYPE;