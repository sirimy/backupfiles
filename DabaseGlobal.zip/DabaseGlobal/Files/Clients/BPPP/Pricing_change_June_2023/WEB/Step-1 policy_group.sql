 SELECT * FROM bppp.POLICY_GROUP WHERE policy_group_key NOT IN (
           SELECT PT2.policy_group_id FROM POLICY_GROUP PT2
           );

INSERT INTO POLICY_GROUP
   (policy_group_id, NAME, DESCRIPTION, active_ind)
 SELECT policy_group_key, NAME, DESCRIPTION, active_ind
   FROM bppp.POLICY_GROUP
  WHERE policy_group_key NOT IN (
           SELECT PT2.policy_group_id FROM POLICY_GROUP PT2
           );
 --1 rows
COMMIT;

update POLICY_GROUP set ACTIVE_IND = 'N' where POLICY_GROUP_ID = 7;
update POLICY_GROUP set LAST_UPDATED_BY = 'BASS-1080' where POLICY_GROUP_ID = 8;
COMMIT;

SELECT * FROM POLICY_GROUP;