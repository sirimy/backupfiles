select * from t_and_c_contract_template_xref order by POLICY_ID desc;

select effective_dt, END_DT, count(*), min(POLICY_ID), max(POLICY_ID) from t_and_c_contract_template_xref
group by effective_dt, END_DT order by effective_dt, END_DT;

--We should create a sync view for t_and_c_contract_template_xref also


--This step should be run after master policy tables have been synced to web
INSERT INTO BPPPTPPPWEB.t_and_c_contract_template_xref (
       TC_CONT_TEMP_XREF_ID,
       TERMS_AND_CONDITIONS_ID,
       CONTRACT_TEMPLATE_ID,
       POLICY_ID,
       STATE_ID,
       COUNTRY_ID,
       CHANNEL_PARTNER_ID,
       ACTIVE_IND,
       EFFECTIVE_DT,
       END_DT,
       LAST_UPDATED_BY,
       LAST_UPDATED_TS)
SELECT TC_CONT_TEMP_XREF_KEY,
       TERMS_AND_CONDITIONS_KEY,
       CONTRACT_TEMPLATE_KEY,
       POLICY_KEY,
       POSTAL_STATE_KEY,
       COUNTRY_KEY,
       CHANNEL_PARTNER_KEY,
       ACTIVE_IND,
       EFFECTIVE_DT,
       END_DT,
       'BASS-1080', current_date
  FROM BPPP.t_and_c_contract_template_xref
 WHERE (CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY)
        NOT IN
        (SELECT CONTRACT_TEMPLATE_id, TERMS_AND_CONDITIONS_ID, POLICY_id, STATE_ID
         FROM BPPPTPPPWEB.t_and_c_contract_template_xref
         );
--9180
--[2023-06-09 01:04:02] 9,828 rows affected in 1 s 20 ms
COMMIT;


select * from t_and_c_contract_template_xref order by last_updated_ts desc;

