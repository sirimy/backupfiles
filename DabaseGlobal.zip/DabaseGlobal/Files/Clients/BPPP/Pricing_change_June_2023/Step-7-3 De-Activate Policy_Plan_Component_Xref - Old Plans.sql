--conn to bppp

select * from bppp.Policy_Plan_Component_Xref order by EFFECTIVE_DT desc, PLAN_NM;

select x.*, au.* from bppp.Policy_Plan_Component_Xref x left join AUDIT_TBL au on au.AUDIT_KEY = x.UPDATE_AUDIT_KEY
where END_DT > sysdate;    --EFFECTIVE_DT < date '2022-07-01' and

select EFFECTIVE_DT, END_DT, count(*) from bppp.Policy_Plan_Component_Xref where END_DT > sysdate
group by EFFECTIVE_DT, END_DT order by EFFECTIVE_DT, END_DT;
/*
+------------+----------+--------+
|EFFECTIVE_DT|END_DT    |COUNT(*)|
+------------+----------+--------+
|2022-06-01  |2099-12-31|46      |
+------------+----------+--------+
 */

DECLARE
   v_audit_key NUMBER;
BEGIN
   v_audit_key := bppp.get_audit_key (p_program_nm => 'POLICY', p_process_nm => 'May 2023 pricing', p_descriptive_tx => 'De-activate old Policy_Plan_Component_Xref ', p_table_nm => 'POLICY_PLAN_COMPONENT_XREF');
   COMMIT;
   DBMS_OUTPUT.PUT_LINE(v_audit_key);
END;

select * from AUDIT_TBL order by AUDIT_KEY desc;
--677860


update bppp.Policy_Plan_Component_Xref set END_DT = date '2023-04-29', UPDATE_AUDIT_KEY = 677860
where END_DT > sysdate;
--116
commit;
