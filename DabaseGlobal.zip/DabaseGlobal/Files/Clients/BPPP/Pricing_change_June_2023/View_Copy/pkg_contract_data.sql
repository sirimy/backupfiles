create PACKAGE BODY         pkg_contract_data AS
/******************************************************************************/

  PROCEDURE proc_client_contract_data IS

  C_DB_NAME              CONSTANT VARCHAR2(30)  := SYS_CONTEXT ('USERENV', 'DB_NAME');
  C_CORE_SCHEMA          CONSTANT VARCHAR2(30)  := 'bppp';
  C_CRLF                 CONSTANT CHAR(2)       := CHR(13) || CHR(10);


  CURSOR C1 IS
  SELECT RC.CONTRACT_NO
        ,RC.CONTRACT_EFFECTIVE_DT
        ,RC.RATE_EFFECTIVE_YEAR_NO
        ,RC.CONTRACT_PURCHASE_PRICE_AMT
        ,RC.BOAT_SELLING_PRICE_AMT
        ,RC.NEW_BOAT_FACTERM_YR_AMT
        ,RC.NEW_BOAT_EXTTERM_YR_AMT
        ,RC.USED_BOAT_TERM_MONTHS_AMT
        ,RC.PRODUCT_TYPE_CD
        ,RC.COVERED_PLAN_NM
        ,RC.CONTRACT_BASIC_COST_AMT
        ,RC.CONTRACT_OPTION_COST_AMT
        ,RC.CONTRACT_SURCHARGE_AMT
        ,RC.OVER_UNDER_AMT
        ,RC.DEDUCTIBLE_AMT
        ,RC.CONTRACT_LEINHOLDER_NM
        ,RC.GROSS_FINANCED_AMT
        ,RC.DOWN_PAY_AMT
        ,RC.FINANCE_FEE_AMT
        ,RC.NUMBER_OF_PAYMENTS_AMT
        ,RC.INSERT_AUDIT_KEY AS RC_INSERT_AUDIT_KEY
        ,RC.FILE_NM  AS RC_FILE_NM
        ----------------
        ,RH.PROCESS_DT
        ,RH.LAST_NM
        ,RH.FIRST_NM
        ,RH.MIDDLE_INIT
        ,RH.STREET_ADDRESS_TX
        ,RH.CITY_NM
        ,RH.STATE_CD AS Customer_STATE_CD
        ,RH.ZIP_CD
        ,RH.PHONE_NO
        ,RH.CONTRACT_STATUS_CD
        ,RH.CONTRACT_EXPIRE_DT
        ,RH.CONTRACT_NOTES_TX
        ,RH.CONTRACT_DEALER_NO
        ,RH.CONTRACT_PROGRAM_NM
        ,RH.INSERT_AUDIT_KEY   AS RH_INSERT_AUDIT_KEY
        ,RH.FILE_NM AS RH_FILE_NM
        ----------------
        ,RW.HULL_YEAR_NO
        ,REGEXP_REPLACE(TRIM(RW.HULL_MAKE_NM), '( ){2,}', ' ')   AS HULL_MAKE_NM
        ,REGEXP_REPLACE(TRIM(RW.HULL_MODEL_NM), '( ){2,}', ' ')  AS HULL_MODEL_NM
        ,TRIM(RW.HULL_SERIAL_NO)       AS HULL_SERIAL_NO
        ,RW.HULL_FACWAR_EXPIRE_DT
         --
        ,REGEXP_REPLACE(TRIM(RW.ENGINE1_MAKE_NM), '( ){2,}', ' ')   AS ENGINE1_MAKE_NM
        ,NVL(REGEXP_REPLACE(TRIM(RW.ENGINE1_MODEL_NM), '( ){2,}', ' '), RC.PRODUCT_TYPE_CD)  AS ENGINE1_MODEL_NM
        ,TRIM(RW.ENGINE1_HP_NO)        AS ENGINE1_HP_NO
        ,TRIM(RW.ENGINE1_SERIAL_NO)    AS ENGINE1_SERIAL_NO
        ,RW.ENGINE1_FACWRNTY_EXPIRE_DT
        --
        ,REGEXP_REPLACE(TRIM(RW.ENGINE2_MAKE_NM), '( ){2,}', ' ')  AS ENGINE2_MAKE_NM
        ,REGEXP_REPLACE(TRIM(ENGINE2_MODEL_NM), '( ){2,}', ' ')    AS ENGINE2_MODEL_NM
        ,RW.ENGINE2_HP_NO
        ,TRIM(RW.ENGINE2_SERIAL_NO)           AS ENGINE2_SERIAL_NO
        ,RW.ENGINE2_FACWRNTY_EXPIRE_DT
        ,TRIM(RW.ENGINE2_KICKER_MOTOR_IND)    AS ENGINE2_KICKER_MOTOR_IND
        --
        ,TRIM(RW.SALT_WATER_KICKER_MOTOR_IND) AS SALT_WATER_KICKER_MOTOR_IND
        ,TRIM(RW.KICKER_MOTOR_EFI_IND)     AS KICKER_MOTOR_EFI_IND
        ,TRIM(RW.TROLLING_MOTOR_SERIAL_NO) AS TROLLING_MOTOR_SERIAL_NO
        --
        ,RW.TRAILER_YEAR_NO
        ,REGEXP_REPLACE(TRIM(RW.TRAILER_MAKE_NM), '( ){2,}', ' ')  AS TRAILER_MAKE_NM
        ,TRIM(RW.TRAILER_SERIAL_NO)          AS TRAILER_SERIAL_NO
        ,REGEXP_REPLACE(TRIM(RW.DEPTH_FINDER_MAKE_NM), '( ){2,}', ' ')  AS DEPTH_FINDER_MAKE_NM
        ,REGEXP_REPLACE(TRIM(RW.DEPTH_FINDER_MODEL_NM), '( ){2,}', ' ')  AS DEPTH_FINDER_MODEL_NM
        --
        ,TRIM(RW.DEPTH_FINDER_ID_NO)        AS DEPTH_FINDER_ID_NO
        ,RW.INSERT_AUDIT_KEY                AS RW_INSERT_AUDIT_KEY
        ,RW.FILE_NM                         AS RW_FILE_NM
        ,RW.UNIT_CD
        ,RW.BUCKET_NM
        ----------------
        ,RW.BILLING_HULL_UNIQUE_SEQ_NO
        ,RW.BILLING_ENGINE1_UNIQUE_SEQ_NO
        ,RW.BILLING_ENGINE2_UNIQUE_SEQ_NO
        ,RW.BILLING_TRAILER_UNIQUE_SEQ_NO
        ,RW.SHIPPING_HULL_UNIQUE_SEQ_NO
        ,RW.SHIPPING_ENGINE1_UNIQUE_SEQ_NO
        ,RW.SHIPPING_ENGINE2_UNIQUE_SEQ_NO
        ,RW.SHIPPING_TRAILER_UNIQUE_SEQ_NO
        ,RW.Bill_Troller_Unique_Seq_No
        ,RW.Ship_Troller_Unique_Seq_No
        ,RW.Bill_DepthFinder_Unique_Seq_No
        ,RW.Ship_DepthFinder_Unique_Seq_No
        ,RW.Bill_GPS_Unique_Seq_No
        ,RW.Ship_GPS_Unique_Seq_No
        ------------------------------
        ,csd.NAME as contract_status_name
        ,slkp.code as dealer_state_cd
    FROM (select a.*,row_number() over(partition by a.contract_no order by 1) rno from RAW_CONTRACT_COVERAGE_TBL a) RC
         JOIN (select a.*,row_number() over(partition by a.contract_no order by 1) rno from RAW_CONTRACT_HOLDER_TBL a) RH ON RC.CONTRACT_NO = RH.CONTRACT_NO
         JOIN (select a.*,row_number() over(partition by a.contract_no order by 1) rno from RAW_CONTRACT_WATERCRAFT_TBL a) RW ON RC.CONTRACT_NO = RW.CONTRACT_NO
         LEFT JOIN p_contract_status_dim csd
         ON (
            (CASE WHEN UPPER(RH.CONTRACT_STATUS_CD) ='FINANCED' THEN 'ACTIVE'
                   WHEN UPPER(RH.CONTRACT_STATUS_CD) ='PENDING' THEN 'CANCELPENDING'
                   ELSE UPPER(RH.CONTRACT_STATUS_CD)
                    END)  = UPPER(csd.description)
              )
          LEFT JOIN bppp.outlet_lkp olkp ON (olkp.source_system_cd = (CASE WHEN TO_NUMBER(RH.PROCESS_DT) <= '20150124' THEN 1 ELSE 3 END) and olkp.outlet_xid = RH.contract_dealer_no)
          LEFT JOIN bppp.outlet_dim odim ON (olkp.outlet_key = odim.outlet_key)
          LEFT JOIN bppp.state_lkp slkp using (state_key)
   WHERE 1=1
     AND rc.rno = 1
     AND rh.rno = 1
     AND rw.rno = 1
     --AND rh.contract_no = '948573'  --debug
   ORDER BY RC.file_nm, RC.CONTRACT_NO;

        CREC C1%ROWTYPE;
        L_SOURCE_SYSTEM_CD  NUMBER;
        L_SKU_NO        NUMBER;
        L_COVERED_PLAN_NM VARCHAR2(255);
        v_audit_key number;
      --  L_TRAILER_MODEL_NO      VARCHAR2(50);

        L_err_num  VARCHAR2(20);
        L_err_msg   VARCHAR2(2000);
        L_GPS_SERIAL_NO VARCHAR2(70);
        L_GPS_PLAN  CHARACTER(1);
        L_PACKAGE_XID  NUMBER;
        L_PACKAGE_TYPE VARCHAR2(50);
        L_PACKAGE_TYPE_DESCRIPTION VARCHAR2(256);

       --=====added variable
       TYPE comp_table IS TABLE OF VARCHAR2(100)   INDEX BY BINARY_INTEGER;

        v_comp_table  comp_table;
        v_comp_table_empty  comp_table;
        v_idx         INTEGER;
        -- variable to store serail no
        L_HULL_SERIAL_NO        BPPP.SERIALIZED_ITEM_DIM.SERIAL_NO%TYPE;
        L_ENGINE1_SERIAL_NO     BPPP.SERIALIZED_ITEM_DIM.SERIAL_NO%TYPE;
        L_ENGINE2_SERIAL_NO     BPPP.SERIALIZED_ITEM_DIM.SERIAL_NO%TYPE;
        L_TRAILER_SERIAL_NO     BPPP.SERIALIZED_ITEM_DIM.SERIAL_NO%TYPE;
        L_TROLLING_MOTOR_SERIAL_NO   BPPP.SERIALIZED_ITEM_DIM.SERIAL_NO%TYPE;
        L_DEPTH_FINDER_ID_NO         BPPP.SERIALIZED_ITEM_DIM.SERIAL_NO%TYPE;

        L_HULL_MODEL_NO              BPPP.PRODUCT_DIM.MODEL_NO%TYPE;
        L_HULL_MAKE_NM  VARCHAR2(40);
        L_ENGINE1_MODEL_NO           BPPP.PRODUCT_DIM.MODEL_NO%TYPE;
        L_ENGINE1_MAKE_NM  VARCHAR2(40);
        L_TRAILER_MODEL_NO           BPPP.PRODUCT_DIM.MODEL_NO%TYPE;
        L_TRAILER_MAKE_NM  VARCHAR2(40);
        L_TROLLING_MOTOR_MODEL_NO    BPPP.PRODUCT_DIM.MODEL_NO%TYPE;
        L_TROLLING_MOTOR_MAKE_NM VARCHAR2(40);
        L_DEPTH_FINDER_MODEL_NO      BPPP.PRODUCT_DIM.MODEL_NO%TYPE;
        L_DEPTH_FINDER_MAKE_NM VARCHAR2(40);
        L_GPS_MODEL_NO               BPPP.PRODUCT_DIM.MODEL_NO%TYPE;
        L_GPS_MAKE_NM  VARCHAR2(40);

        -- variable to set component if exists in plan
        L_HULL_PLAN CHARACTER(1);
        L_MOTOR_PLAN CHARACTER(1);
        L_TRAILER_PLAN CHARACTER(1);
        L_TROLLING_MOTOR_PLAN CHARACTER(1);
        L_DEPTH_FINDER_PLAN  CHARACTER(1);


        L_HULL_FACWAR_EXPIRE_DT        DATE;
        L_ENGINE1_FACWRNTY_EXPIRE_DT   DATE;
        L_TRAILER_FACWAR_EXPIRE_DT     DATE;
        L_NEW_BOAT_FACTERM_YR_AMT      NUMBER;
        L_NEW_ENGINE1_FACTERM_YR_AMT   NUMBER;
        L_NEW_TRAILER_FACTERM_YR_AMT   NUMBER;

        L_Amtrust_Old_Pricing_Ind      VARCHAR2(1) := NULL;
        L_Debug_Message                VARCHAR2(2048) := NULL;
        L_Motor_product_category_key   NUMBER(19);
        l_count                        NUMBER;

        L_TERMS_AND_CONDITIONS_KEY     NUMBER;
        L_CONTRACT_TEMPLATE_XID        NUMBER;

        L_temp_message                 VARCHAR2(512) := NULL;
        total_rows number(2);
   BEGIN

        v_audit_key := p_get_audit_key (p_program_nm => 'pkg_contract_data.proc_client_contract_data', p_table_nm => 'CONTRACT_COMMON_LOAD_HOLD_TBL');


        update RAW_CONTRACT_WATERCRAFT_TBL set
        BILLING_HULL_UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE BILLING_HULL_UNIQUE_SEQ_NO IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        BILLING_ENGINE1_UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE BILLING_ENGINE1_UNIQUE_SEQ_NO IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        BILLING_ENGINE2_UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE BILLING_ENGINE2_UNIQUE_SEQ_NO IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        BILLING_TRAILER_UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE BILLING_TRAILER_UNIQUE_SEQ_NO IS NULL;


        update RAW_CONTRACT_WATERCRAFT_TBL set
        SHIPPING_HULL_UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE SHIPPING_HULL_UNIQUE_SEQ_NO IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        SHIPPING_ENGINE1_UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE SHIPPING_ENGINE1_UNIQUE_SEQ_NO IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        SHIPPING_ENGINE2_UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE SHIPPING_ENGINE2_UNIQUE_SEQ_NO IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        SHIPPING_TRAILER_UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE SHIPPING_TRAILER_UNIQUE_SEQ_NO IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        Bill_Troller_Unique_Seq_No=common_load_seq.NEXTVAL
        WHERE Bill_Troller_Unique_Seq_No IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        Ship_Troller_Unique_Seq_No=common_load_seq.NEXTVAL
        WHERE Ship_Troller_Unique_Seq_No IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        Bill_DepthFinder_Unique_Seq_No=common_load_seq.NEXTVAL
        WHERE Bill_DepthFinder_Unique_Seq_No IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        Ship_DepthFinder_Unique_Seq_No=common_load_seq.NEXTVAL
        WHERE Ship_DepthFinder_Unique_Seq_No IS NULL;


        UPDATE RAW_CONTRACT_CANCEL_TBL SET
        UNIQUE_SEQ_NO=common_load_seq.NEXTVAL
        WHERE UNIQUE_SEQ_NO IS NULL;

        -- added by DS
        update RAW_CONTRACT_WATERCRAFT_TBL set
        Bill_GPS_Unique_Seq_No=common_load_seq.NEXTVAL
        WHERE Bill_GPS_Unique_Seq_No IS NULL;

        update RAW_CONTRACT_WATERCRAFT_TBL set
        Ship_GPS_Unique_Seq_No=common_load_seq.NEXTVAL
        WHERE Ship_GPS_Unique_Seq_No IS NULL;


        --Update correct wording for ALUMINIUM to ALUMINUM
        UPDATE RAW_CONTRACT_WATERCRAFT_TBL
        SET BUCKET_NM = 'ALUMINUM'
        WHERE upper(BUCKET_NM) = 'ALUMINIUM';
        IF sql%notfound THEN
          dbms_output.put_line('NO ALUMINIUM UPDATED');
        ELSIF sql%found THEN
          total_rows := sql%rowcount;
          dbms_output.put_line( total_rows || ' ALUMINIUM UPDATED ');
        END IF;


      FOR CREC IN C1 LOOP
      BEGIN
         EXIT WHEN C1%NOTFOUND;

         -- set the sequence for package handling.This sequence will be used to Group the serialized items belonging
         -- to same package(Stock).

         SELECT RAW_PACKAGE_SEQ.NEXTVAL
           INTO L_PACKAGE_XID
           FROM DUAL;
        -- set the source_system_code  based on the process_dt of the contract as for migration contract source_system_cd = 1
          -- is useed while for JBOAt contrcats we are using source_system_cd = 3.

          IF TO_NUMBER(CREC.PROCESS_DT) <= '20150124' THEN
           L_SOURCE_SYSTEM_CD := 1; -- old system contracts
          ELSE
           L_SOURCE_SYSTEM_CD  := 3; -- JBOAt contracts
          END IF;


          --We create product lkp/dim record for every brand/model cobination from raw file,
          --however,this step to fetchmodel_no for some of the records this way would mean
          --that such models-brand combination may not be there in product tables --AJ, 11/13/2013
          -- DS - Commenting this part -- need to discuss Abhay
          /*
         SELECT TRIM(MAX(MODEL_NO))
           INTO L_TRAILER_MODEL_NO
           FROM P_SERIALIZED_ITEM_DIM
          WHERE SERIAL_NO = CREC.TRAILER_SERIAL_NO;
          */

         L_COVERED_PLAN_NM := UPPER(crec.COVERED_PLAN_NM);
         L_Amtrust_Old_Pricing_Ind := NULL;


         --So far word 'USED' was at the end of used plan names and with 8/1/2021 pricing,it will be at the begining
         --this change will need to be handled in this section --AJ
         IF SUBSTR(CREC.CONTRACT_NO, 1, 3) IN ('TMF', 'BPS') --TO_DATE(crec.process_dt, 'YYYYMMDD') <= DATE '2015-01-24'  -- old pricing
         THEN
             IF UPPER (crec.COVERED_PLAN_NM) LIKE '%ADVANTAGE%' AND UPPER(CREC.COVERED_PLAN_NM) like '%GPS%'  THEN
                    L_COVERED_PLAN_NM :='ADVANTAGE + GPS';
             ELSIF UPPER (crec.COVERED_PLAN_NM) LIKE '%ADVANTAGE%' AND UPPER(CREC.COVERED_PLAN_NM) NOT like '%GPS%'  THEN
                    L_COVERED_PLAN_NM :='ADVANTAGE';
             ELSIF UPPER (crec.COVERED_PLAN_NM) LIKE  '%PRO PLUS%' AND UPPER(CREC.COVERED_PLAN_NM) like '%GPS%'   THEN
                     SELECT case when TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' then
                                    'PRO PLUS + GPS' || DECODE(CREC.USED_BOAT_TERM_MONTHS_AMT,NULL,'',0,'',' USED')
                                 else DECODE(CREC.USED_BOAT_TERM_MONTHS_AMT,NULL,'',0,'','USED ' || 'PRO PLUS + GPS')
                            end
                     INTO L_COVERED_PLAN_NM
                     FROM DUAL;
             ELSIF UPPER (crec.COVERED_PLAN_NM) LIKE  '%PRO PLUS%' AND UPPER(CREC.COVERED_PLAN_NM) NOT like '%GPS%'  THEN
                    SELECT case when TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' then
                                    'PRO PLUS'  || DECODE(CREC.USED_BOAT_TERM_MONTHS_AMT,NULL,'',0,'',' USED')
                                else DECODE(CREC.USED_BOAT_TERM_MONTHS_AMT,NULL,'',0,'','USED ' || 'PRO PLUS')
                            end
                    INTO L_COVERED_PLAN_NM
                    FROM DUAL;
             ELSIF UPPER(CREC.COVERED_PLAN_NM) like '%PRO%'  and  UPPER(CREC.COVERED_PLAN_NM) NOT like '%PRO NAV%'   and  UPPER(CREC.COVERED_PLAN_NM) NOT like '%PRO CRUISER PLUS%' THEN
                    SELECT case when TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' then
                                        'PRO'  || DECODE(CREC.USED_BOAT_TERM_MONTHS_AMT,NULL,'',0,'',' USED')
                                else DECODE(CREC.USED_BOAT_TERM_MONTHS_AMT,NULL,'',0,'','USED ' || 'PRO')
                            end
                    INTO L_COVERED_PLAN_NM
                    FROM DUAL;
             ELSIF UPPER(CREC.COVERED_PLAN_NM) like '%PRO%NAV%' THEN
                    SELECT 'PRO NAV'  || DECODE(CREC.USED_BOAT_TERM_MONTHS_AMT,NULL,'',0,'',' USED') INTO L_COVERED_PLAN_NM
                    FROM DUAL;
             ELSIF UPPER(CREC.COVERED_PLAN_NM) like '%PRO CRUISER PLUS%'  THEN
                    SELECT 'PRO CRUISER PLUS'  || DECODE(CREC.USED_BOAT_TERM_MONTHS_AMT,NULL,'',0,'',' USED') INTO L_COVERED_PLAN_NM
                    FROM DUAL;
             END IF;

             L_Amtrust_Old_Pricing_Ind := 'Y';

         ELSIF SUBSTR(CREC.CONTRACT_NO, 1, 3) NOT IN ('TMF', 'BPS') --new contracts from JBoat
               --AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= DATE '2015-01-25'   --It can be either of old or new
         THEN
            --checking for new pricing plans
            L_COVERED_PLAN_NM := UPPER(crec.COVERED_PLAN_NM);
            --L_COVERED_PLAN_NM := REPLACE(L_COVERED_PLAN_NM, 'W/ ', '');
            L_COVERED_PLAN_NM := REPLACE(L_COVERED_PLAN_NM, ' - OUTBOARD', '');
            L_COVERED_PLAN_NM := REPLACE(L_COVERED_PLAN_NM, ' - ALUMINIUM/PONTOON HULL', '');
            L_COVERED_PLAN_NM := REPLACE(L_COVERED_PLAN_NM, ' - ALUMINIUM/PONTOON HULL GPS', '');
            L_COVERED_PLAN_NM := REPLACE(L_COVERED_PLAN_NM, ' - FIBERGLASS HULL', '');
            L_COVERED_PLAN_NM := REPLACE(L_COVERED_PLAN_NM, ' - FIBERGLASS HULL GPS', '');
            L_COVERED_PLAN_NM := REPLACE(L_COVERED_PLAN_NM, ' - INBOARD', '');
            --L_COVERED_PLAN_NM := REPLACE(L_COVERED_PLAN_NM, ' - PREMIER PRO PLUS - INBOARD', '');


            IF REPLACE(REPLACE(UPPER (L_COVERED_PLAN_NM), 'W/ ', ''), '+', '') IN (
                'PREMIER ADVANTAGE',            'PREMIER ADVANTAGE-FL',
                'PREMIER ADVANTAGE GPS',        'PREMIER ADVANTAGE GPS-FL',
                'PREMIER PRO',                  'PREMIER PRO-FL',
                'PREMIER PRO PLUS',             'PREMIER PRO PLUS-FL',
                'PREMIER PRO PLUS GPS',         'PREMIER PRO PLUS GPS-FL',
                'USED PRO',                     'USED PRO-FL',
                'USED PRO PLUS',                'USED PRO PLUS-FL',
                'USED PRO PLUS GPS',            'USED PRO PLUS GPS-FL',
                'TRACKER PROMISE (ADVANTAGE)',  'TRACKER PROMISE (ADVANTAGE)-FL',
                'TRACKER PROMISE (ADVANTAGE) GPS',        'TRACKER PROMISE (ADVANTAGE) GPS-FL',
                '10 PLUS LIFE (PRO)',           '10 PLUS LIFE (PRO)-FL',
                'TRACKER PROMISE (PRO PLUS)',   'TRACKER PROMISE (PRO PLUS)-FL',
                'TRACKER PROMISE (PRO PLUS) GPS',        'TRACKER PROMISE (PRO PLUS) GPS-FL',
                'AFTERMARKET - ADVANTAGE',      'AFTERMARKET - ADVANTAGE-FL',
                'AFTERMARKET - ADVANTAGE GPS',  'AFTERMARKET - ADVANTAGE GPS-FL',
                'AFTERMARKET - PRO',            'AFTERMARKET - PRO-FL',
                'AFTERMARKET - PRO PLUS',       'AFTERMARKET - PRO PLUS-FL',
                'AFTERMARKET - PRO PLUS GPS',   'AFTERMARKET - PRO PLUS GPS-FL',
                 --new plans added with Aug 2021 pricing:
                'PREMIER PRO - ADDER 0_139HP',  'PREMIER PRO - ADDER 0_139HP-FL',
                'PREMIER PRO - ADDER DUAL HP',  'PREMIER PRO - ADDER DUAL HP-FL',
                'PREMIER PRO PLUS - ADDER 0_139HP', 'PREMIER PRO PLUS - ADDER 0_139HP-FL',
                'PREMIER PRO PLUS - ADDER DUAL HP', 'PREMIER PRO PLUS - ADDER DUAL HP-FL',
                'TRACKER PROMISE (PRO PLUS) - ADDER 0_139HP', 'TRACKER PROMISE (PRO PLUS) - ADDER 0_139HP-FL',
                'TRACKER PROMISE (PRO PLUS) - ADDER DUAL HP', 'TRACKER PROMISE (PRO PLUS) - ADDER DUAL HP-FL',

                'AFTERMARKET - PRO - ADDER', 'AFTERMARKET - PRO PLUS - ADDER'      --Added by Aug 2022 pricing
                )
            THEN
               L_COVERED_PLAN_NM := REPLACE(UPPER (L_COVERED_PLAN_NM), 'W/ ', '+ ');
               --dbms_output.put_line('L_COVERED_PLAN_NM: ' || L_COVERED_PLAN_NM);

               L_Amtrust_Old_Pricing_Ind := 'N';

            ELSIF UPPER (crec.COVERED_PLAN_NM) IN (  --Oct 2014 - Jan 2015 pricing --overlapping time period ...to be used for migration of contracts with old pricing
               'ADVANTAGE',
               'PRO PLUS',
               'PRO',
               'ADVANTAGE GPS',
               'PRO PLUS GPS')
            THEN
               --checking for old pricing plans
               L_COVERED_PLAN_NM := CASE UPPER (crec.COVERED_PLAN_NM)
                                    WHEN 'ADVANTAGE' THEN 'ADVANTAGE'
                                    WHEN 'ADVANTAGE GPS' THEN 'ADVANTAGE + GPS'
                                    WHEN 'PRO PLUS' THEN 'PRO PLUS'
                                    WHEN 'PRO PLUS GPS' THEN 'PRO PLUS + GPS'
                                    WHEN 'PRO' THEN 'PRO'
                                    ELSE  UPPER (crec.COVERED_PLAN_NM)
                                    END;

               L_Amtrust_Old_Pricing_Ind := 'Y';
            END IF;
         END IF;

         --dbms_output.put_line( 'L_COVERED_PLAN_NM:' || L_COVERED_PLAN_NM || ', L_Amtrust_Old_Pricing_Ind: ' || L_Amtrust_Old_Pricing_Ind);




         --Added by DS
         BEGIN

            L_PACKAGE_TYPE := NULL;
            L_PACKAGE_TYPE_DESCRIPTION := NULL;


            BEGIN
               SELECT LISTAGG(COMPONENT_NM,'~') WITHIN GROUP (ORDER BY COMPONENT_NM)
                 INTO L_PACKAGE_TYPE
                 FROM (
                       SELECT PPXREF.*
                              ,ROW_NUMBER() OVER(PARTITION BY plan_nm, component_nm order by PPXREF.effective_dt desc ) rn
                         FROM BPPP.Policy_Plan_Component_Xref PPXREF
                        WHERE PPXREF.PLAN_NM = L_COVERED_PLAN_NM
                         --AND TO_DATE(CREC.PROCESS_DT,'YYYYMMDD') between PPXREF.EFFECTIVE_DT AND PPXREF.END_DT
                          AND CASE WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' THEN DATE '2009-01-01'
                                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') <= date '2015-01-24' THEN DATE '2012-10-16'
                                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25' AND L_Amtrust_Old_Pricing_Ind = 'Y' THEN DATE '2012-10-16'  --migrated contracts
                                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) <> 'BPS' AND L_Amtrust_Old_Pricing_Ind = 'N'  AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25'
                                        THEN TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')    --DATE '2015-01-25'  --JBoat contracts
                                   ELSE TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')
                              END BETWEEN PPXREF.EFFECTIVE_DT AND PPXREF.END_DT
                       )
                WHERE rn = 1;

                IF TRIM(L_PACKAGE_TYPE) IS NULL THEN
                   dbms_output.put_line ('PACKAGE_TYPE IS NULL');
                   dbms_output.put_line(L_COVERED_PLAN_NM || ' not found in BPPP.Policy_Plan_Component_Xref' );

                   UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                     SET ERROR_DESC = L_COVERED_PLAN_NM || ' not found in BPPP.Policy_Plan_Component_Xref'
                          ,update_audit_key = v_audit_key
                   WHERE CONTRACT_NO = CREC.CONTRACT_NO
                     AND ERROR_DESC IS NULL;
                END IF;


            EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  dbms_output.put_line ('NO_DATA_FOUND error');
                  UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                     SET ERROR_DESC = L_COVERED_PLAN_NM || ' not found in BPPP.Policy_Plan_Component_Xref'
                          ,update_audit_key = v_audit_key
                   WHERE CONTRACT_NO = CREC.CONTRACT_NO
                     AND ERROR_DESC IS NULL;

                GOTO LABEL1;
            END;


           -- added by DS to set the package description
           BEGIN
               SELECT DESCRIPTION
                 INTO L_PACKAGE_TYPE_DESCRIPTION
                 FROM BPPP.PACKAGE_TYPE_DIM
                WHERE NAME = L_PACKAGE_TYPE;

           --dbms_output.put_line( 'L_PACKAGE_TYPE_DESCRIPTION: ' || L_PACKAGE_TYPE_DESCRIPTION);
           EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                     SET ERROR_DESC = 'L_PACKAGE_TYPE_DESCRIPTION: ' || L_PACKAGE_TYPE_DESCRIPTION || ' not found in BPPP.PACKAGE_TYPE_DIM for PACKAGE_TYPE: ' || L_PACKAGE_TYPE
                          ,update_audit_key = v_audit_key
                   WHERE CONTRACT_NO = CREC.CONTRACT_NO
                     AND ERROR_DESC IS NULL;

                GOTO LABEL1;
            END;



           BEGIN
              SELECT UPPER(PPXREF.COMPONENT_NM)
                BULK COLLECT INTO v_comp_table
                FROM (
                      SELECT PPXREF.*
                              ,ROW_NUMBER() OVER(PARTITION BY plan_nm, component_nm ORDER BY PPXREF.effective_dt DESC ) rn
                        FROM BPPP.Policy_Plan_Component_Xref PPXREF
                       WHERE PPXREF.PLAN_NM = L_COVERED_PLAN_NM
                          --AND TO_DATE(CREC.PROCESS_DT,'YYYYMMDD') between PPXREF.EFFECTIVE_DT AND PPXREF.END_DT
                         AND CASE WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' THEN DATE '2009-01-01'
                                  WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') <= date '2015-01-24' THEN DATE '2012-10-16'
                                  WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25' AND L_Amtrust_Old_Pricing_Ind = 'Y' THEN DATE '2012-10-16'  --migrated contracts
                                  WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) <> 'BPS' AND L_Amtrust_Old_Pricing_Ind = 'N'   --AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25'
                                       THEN TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')  --DATE '2015-01-25'  --JBoat contracts
                                  ELSE TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')
                             END BETWEEN PPXREF.EFFECTIVE_DT AND PPXREF.END_DT
                      ) PPXREF
               WHERE rn = 1;


              IF v_comp_table.count = 0 THEN
                 dbms_output.put_line( 'L_COVERED_PLAN_NM:' || L_COVERED_PLAN_NM || ', L_Amtrust_Old_Pricing_Ind: ' || L_Amtrust_Old_Pricing_Ind);
                 UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                    SET ERROR_DESC = 'NO VALID PLAN AVAILABLE IN Policy_Plan_Component_Xref for L_COVERED_PLAN_NM:' || L_COVERED_PLAN_NM
                        ,update_audit_key = v_audit_key
                  WHERE CONTRACT_NO = CREC.CONTRACT_NO
                    AND ERROR_DESC IS NULL;

                 GOTO LABEL1;
              END IF;

           EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                     SET ERROR_DESC = L_COVERED_PLAN_NM || ' not found in BPPP.Policy_Plan_Component_Xref'
                          ,update_audit_key = v_audit_key
                   WHERE CONTRACT_NO = CREC.CONTRACT_NO
                     AND ERROR_DESC IS NULL;

                GOTO LABEL1;
           END;

         END;


           L_HULL_SERIAL_NO     := CREC.HULL_SERIAL_NO;
           L_ENGINE1_SERIAL_NO  := CREC.ENGINE1_SERIAL_NO;
           L_ENGINE2_SERIAL_NO  := CREC.ENGINE2_SERIAL_NO;
           L_TRAILER_SERIAL_NO  := CREC.TRAILER_SERIAL_NO;
           L_TROLLING_MOTOR_SERIAL_NO  := CREC.TROLLING_MOTOR_SERIAL_NO;
           L_DEPTH_FINDER_ID_NO        := CREC.DEPTH_FINDER_ID_NO;
           L_GPS_SERIAL_NO             := NULL;

           L_HULL_MODEL_NO    := CREC.HULL_MODEL_NM;
           L_HULL_MAKE_NM     := CREC.HULL_MAKE_NM;
           L_ENGINE1_MODEL_NO := CREC.ENGINE1_MODEL_NM;
           L_ENGINE1_MAKE_NM  := CREC.ENGINE1_MAKE_NM;
           L_TRAILER_MODEL_NO        := 'TRAILER';
           L_TRAILER_MAKE_NM         := CREC.TRAILER_MAKE_NM;
           L_TROLLING_MOTOR_MODEL_NO := 'TROLLING MOTOR';
           L_TROLLING_MOTOR_MAKE_NM  := 'OTHER';
           L_DEPTH_FINDER_MODEL_NO   := CREC.DEPTH_FINDER_MODEL_NM;
           L_DEPTH_FINDER_MAKE_NM    := CREC.DEPTH_FINDER_MAKE_NM;
           L_GPS_MODEL_NO            := 'GPS';
           L_GPS_MAKE_NM             := 'OTHER';

           L_HULL_PLAN := NULL;
           L_GPS_PLAN := NULL;
           L_MOTOR_PLAN := NULL;
           L_TRAILER_PLAN := NULL;
           L_TROLLING_MOTOR_PLAN := NULL;
           L_DEPTH_FINDER_PLAN := NULL;



         FOR i IN v_comp_table.FIRST .. v_comp_table.LAST LOOP

               IF  UPPER(v_comp_table(i)) = 'BOAT' THEN
                   L_HULL_SERIAL_NO := NVL(CREC.HULL_SERIAL_NO, 'B' || TO_CHAR(crec.CONTRACT_NO));
                   L_HULL_MODEL_NO  := NVL(CREC.HULL_MODEL_NM, 'FIBERGLASS');
                   L_HULL_MAKE_NM   := NVL(CREC.HULL_MAKE_NM, 'OTHER');
                   -- fiberclass.other for model
                   L_HULL_PLAN      := 'Y';
               END IF;


               IF  UPPER(v_comp_table(i)) = 'MOTOR' THEN
                   L_ENGINE1_SERIAL_NO := NVL(CREC.ENGINE1_SERIAL_NO, 'M1' || TO_CHAR(crec.CONTRACT_NO));
                   L_ENGINE1_MODEL_NO  := NVL(CREC.ENGINE1_MODEL_NM , 'MOTOR');
                   L_ENGINE1_MAKE_NM   := NVL(CREC.ENGINE1_MAKE_NM , 'OTHER');
                   L_MOTOR_PLAN        := 'Y';
               END IF;


               IF  UPPER(v_comp_table(i)) = 'TRAILER' THEN
                   L_TRAILER_SERIAL_NO := NVL(CREC.TRAILER_SERIAL_NO, 'T' || TO_CHAR(crec.CONTRACT_NO));
                   L_TRAILER_MODEL_NO  := 'TRAILER';
                   L_TRAILER_MAKE_NM   := NVL(CREC.TRAILER_MAKE_NM ,'OTHER');
                   L_TRAILER_PLAN      := 'Y';
               END IF;


               IF  UPPER(v_comp_table(i)) = 'TROLLING MOTOR' THEN
                   L_TROLLING_MOTOR_SERIAL_NO := NVL(CREC.TROLLING_MOTOR_SERIAL_NO, 'TM' || TRIM(TO_CHAR(crec.CONTRACT_NO)));
                   L_TROLLING_MOTOR_MODEL_NO  := 'TROLLING MOTOR';
                   L_TROLLING_MOTOR_MAKE_NM   := 'OTHER';
                   L_TROLLING_MOTOR_PLAN      := 'Y';
               END IF;


               IF  UPPER(v_comp_table(i)) = 'DEPTH FINDER' THEN

                   L_DEPTH_FINDER_ID_NO    := NVL(CREC.DEPTH_FINDER_ID_NO, 'DF' || TO_CHAR(crec.CONTRACT_NO));
                   L_DEPTH_FINDER_MODEL_NO := NVL(CREC.DEPTH_FINDER_MODEL_NM , 'DEPTH FINDER');
                   L_DEPTH_FINDER_MAKE_NM  := NVL(CREC.DEPTH_FINDER_MAKE_NM, 'OTHER');
                   L_DEPTH_FINDER_PLAN     := 'Y';
               END IF;

               IF  UPPER(v_comp_table(i)) = 'GPS' THEN

                  L_GPS_SERIAL_NO := 'GPS' || TRIM(TO_CHAR(crec.CONTRACT_NO));
                  L_GPS_MODEL_NO  := 'GPS';
                  L_GPS_MAKE_NM   := 'OTHER';
                  L_GPS_PLAN      := 'Y';
               END IF;

         END LOOP;

         --  reinitialize the plsql table v_comp_table_empty

         v_comp_table:= v_comp_table_empty;


         L_Motor_product_category_key := NULL;
         select MAX(product_category_key)
           into L_Motor_product_category_key
           from bppp.product_category_dim pc
          where product_category_nm = bpppStg.fn_get_product_category (P_model_nm => crec.PRODUCT_TYPE_CD, P_Product_Type => 'MOTOR');


         BEGIN
            L_SKU_NO := NULL;
            L_Debug_Message := L_COVERED_PLAN_NM || '*, *' || UPPER(crec.product_type_cd) || '*, *' || L_Amtrust_Old_Pricing_Ind || '*, *' ||
                                 TO_CHAR(ROUND((TO_DATE(CREC.contract_expire_dt, 'YYYYMMDD') - TO_DATE(CREC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD')) / 365) || '*, *' ||
                                 NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 0) || '+' || NVL(CREC.NEW_BOAT_EXTTERM_YR_AMT, 0)  || '+' || NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) || '*, *' ||
                                 crec.CONTRACT_BASIC_COST_AMT || '*, *' || CREC.ENGINE1_HP_NO ||'*, *' ||crec.RATE_EFFECTIVE_YEAR_NO || '*, *' || crec.dealer_state_cd || '*');

            SELECT POLICY_PRODUCT_XID
              INTO L_SKU_NO
              FROM P_POLICY_TBL PL
                    JOIN P_POLICY_TYPE_TBL PTL ON (PL.POLICY_TYPE_KEY = PTL.POLICY_TYPE_KEY)
                     JOIN P_POLICY_EXT_TBL  PET ON (PL.POLICY_KEY = PET.POLICY_KEY)
                      JOIN P_TERM_DIM         TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
                       LEFT JOIN (SELECT DISTINCT pricing_scheme_key, policy_key  --, new_used
                               FROM bppp.RAW_POLICY_DATA_TBL
                            ) raw_pol
                          ON (PL.POLICY_KEY  = raw_pol.POLICY_KEY)
             WHERE
                   PL.NAME = L_COVERED_PLAN_NM
           --Older data does not have AFT as part of RATE_EFFECTIVE_YEAR_NO and hence we need some other rule to differentiate AFT vs. POS policies from old data
               --AJ hard code this part to always use 'Dealer' channel (3) for all plans effective with 8/1/2021 pricing
               AND PL.CONTRACT_SALES_CHANNEL_KEY =  case when TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' then
                                                                (CASE WHEN (crec.RATE_EFFECTIVE_YEAR_NO LIKE '%AFT' OR    --Pricing effective from Oct 2012 to Jan 2015
                                                                      UPPER(crec.CONTRACT_PROGRAM_NM) LIKE 'AFTERMARKET%' ) OR  --Pricing effective from Jan 2009 to Oct 2012
                                                                      UPPER(L_COVERED_PLAN_NM) LIKE '%AFTERMARKET%' --2015 aftermarket plans
                                                                    THEN 2
                                                                 WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) > 0
                                                                    THEN 1   --Used policies can be sold through POS only
                                                                 ELSE 1  --default is POS
                                                                END )
                                                            else 3
                                                    end
           ----
           ----Now we know that liter ranges upto max 9.8 only and there are certain models where we have to compare with liter data only
               AND CASE
                   WHEN --TO_DATE(crec.process_dt, 'YYYYMMDD')  >= Date '2015-01-25' AND TO_DATE(crec.contract_effective_dt, 'YYYYMMDD')  >= Date '2015-01-25' AND
                         UPPER(L_COVERED_PLAN_NM) LIKE '%ADVANTAGE%'
                         AND L_Amtrust_Old_Pricing_Ind = 'N'    --Contracts being received through JBoat
                         THEN 1
                   WHEN TO_NUMBER(CREC.ENGINE1_HP_NO) <= 9.8 AND TO_NUMBER(CREC.ENGINE1_HP_NO) BETWEEN MIN_LITER AND MAX_LITER THEN 1
                   WHEN TO_NUMBER(CREC.ENGINE1_HP_NO) >= 9.9 AND TO_NUMBER(CREC.ENGINE1_HP_NO) BETWEEN MIN_HP AND MAX_HP THEN 1
                   WHEN (crec.product_type_cd) LIKE '%4.3%' AND 4.3 BETWEEN MIN_LITER AND MAX_LITER THEN 1
                   WHEN (crec.product_type_cd) LIKE '%5.0%' AND 5.0 BETWEEN MIN_LITER AND MAX_LITER THEN 1
                   END = 1

               AND TD.YEAR = (CASE WHEN ( NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 0) <> 0 OR  NVL(CREC.NEW_BOAT_EXTTERM_YR_AMT, 0) <> 0 ) AND NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0
                                       AND L_COVERED_PLAN_NM NOT LIKE '%USED%'
                                   THEN --new boat
                                      NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 0) + NVL(CREC.NEW_BOAT_EXTTERM_YR_AMT, 0)
                                   WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0
                                   THEN --used boat
                                      (NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0)/12)
                                   ELSE  --This condition is being added to handle data from new contract files from jBoat
                                       ROUND((TO_DATE(CREC.contract_expire_dt, 'YYYYMMDD') - TO_DATE(CREC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD')) / 365)
                            END
                            )
               --AND PET.MFG_WARR_TERM = NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 1) --WE HAVE USED NVL AS 1 IN CASE OF USED
               --This assignment seems wrong? --AJ on 8/18/2021
               AND CASE WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0 OR L_COVERED_PLAN_NM LIKE '%USED%' THEN 'N'
                        WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0 AND L_COVERED_PLAN_NM NOT LIKE '%USED%' THEN 'Y'
                   END = PL.NEW_USED_IND  -- handling used policy
               AND PET.PRODUCT_CATEGORY_KEY =
                     DECODE (UPPER(crec.product_type_cd),
                              'ALUMINUM / PONTOON', 10
                              ,'ALUM/PONTOON', 10
                              ,'FIBERGLASS', 11
                              ,'4-STROKE', 7
                              ,'4 STROKE', 7
                              ,'2-STROKE', 6
                              ,'2 STROKE', 6
                              ,'MERCRUISER', 2
                              ,'STERN', 2         --Sterns are Mercruiser
                              ,'DFI', 5
                              ,'V-6', 3
                              --logic to categorize Outboards was provided by Analytics team
                              ,'OUTBOARD', DECODE(UPPER(crec.engine1_model_nm),
                                     '4-STROKE', 7,
                                     '4 STROKE', 7,
                                     '2-STROKE', 6,
                                     '2 STROKE', 6,
                                     'OPTIMAX', 5,
                                     'DFI', 5
                                     )
                                --Following code is being added to handle new contract files from jBoat system.
                               ,CASE
                        --Change this section to use pricing scheme key for all ADVANTAGE plans for pricing effective 8/1/2021 --AJ
                                     WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)
                                                IN ('PREMIER ADVANTAGE', 'PREMIER ADVANTAGE + GPS','PREMIER ADVANTAGE-FL', 'PREMIER ADVANTAGE GPS-FL', 'PREMIER ADVANTAGE + GPS-FL')
                                          THEN 11   --Filberglass pricing
                                     WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)
                                                IN ('TRACKER PROMISE (ADVANTAGE)', 'TRACKER PROMISE (ADVANTAGE) + GPS', 'TRACKER PROMISE (ADVANTAGE)-FL', 'TRACKER PROMISE (ADVANTAGE) GPS-FL', 'TRACKER PROMISE (ADVANTAGE) + GPS-FL')
                                          THEN 10   --Aluminum pricing
                                     WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)
                                                IN ('AFTERMARKET - ADVANTAGE', 'AFTERMARKET - ADVANTAGE + GPS', 'AFTERMARKET - ADVANTAGE-FL', 'AFTERMARKET - ADVANTAGE GPS-FL', 'AFTERMARKET - ADVANTAGE + GPS-FL')
                                          then 10   --AFTERMARKET Advantage policies will have uniform pricing independent of Aluminum vs. Fiberglass
                                     WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2021-08-01' and upper(L_covered_plan_nm) in (
                                                'ADVANTAGE', 'AFTERMARKET - ADVANTAGE', 'AFTERMARKET - ADVANTAGE-FL', 'PREMIER ADVANTAGE', 'PREMIER ADVANTAGE-FL')
                                          then 10   --All Advantage policies will have uniform pricing independent of Aluminum vs. Fiberglass
                                     ELSE
                                         CASE  bpppStg.fn_get_product_category (p_model_nm => crec.PRODUCT_TYPE_CD, p_product_type => 'MOTOR')
                                           WHEN '4-STROKE' THEN 7
                                           WHEN 'MERCRUISER' THEN 2
                                           WHEN '2-STROKE' THEN 6
                                           WHEN 'DFI' THEN 5
                                         END
                                END
                              )
               --AND TO_DATE(crec.process_dt, 'YYYYMMDD') BETWEEN PL.effective_dt and PL.EXP_DT
               AND CASE WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' THEN DATE '2009-01-01'
                        WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') <= date '2015-01-24' THEN DATE '2012-10-16'
                    --WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25' THEN DATE '2015-01-25'
                        WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25' AND L_Amtrust_Old_Pricing_Ind = 'Y' THEN DATE '2012-10-16'  --migrated contracts
                        WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) <> 'BPS' AND L_Amtrust_Old_Pricing_Ind = 'N'   --AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25'
                           THEN TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')   --DATE '2015-01-25'  --JBoat contracts
                        ELSE TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')
                   END BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT

               --Handling Florida-Non Florida policies for older data
               AND CASE --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2012-10-16' THEN 1
                    --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2012-10-16' AND crec.dealer_state_cd = 'FL' AND raw_pol.pricing_scheme_key IN (12, 13) THEN 1
                    --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2012-10-16' AND crec.dealer_state_cd <> 'FL' AND raw_pol.pricing_scheme_key IN (10, 11) THEN 1
                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' THEN 1   --migrated contracts
                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' AND crec.dealer_state_cd = 'FL' AND raw_pol.pricing_scheme_key IN (12, 13) THEN 1    --migrated contracts
                   WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' AND crec.dealer_state_cd <> 'FL' AND raw_pol.pricing_scheme_key IN (10, 11) THEN 1   --migrated contracts
                   WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= DATE '2015-01-25' OR L_Amtrust_Old_Pricing_Ind = 'N' THEN 1  --new contracts from JBoat don't have a contract prefix
                   ELSE 0
               END = 1
            ;

         EXCEPTION
           WHEN NO_DATA_FOUND THEN
               --Following section was added to handle old contracts
               BEGIN
                  SELECT POLICY_PRODUCT_XID
                  INTO L_SKU_NO
                  FROM P_POLICY_TBL PL
                        JOIN P_POLICY_TYPE_TBL PTL ON (PL.POLICY_TYPE_KEY = PTL.POLICY_TYPE_KEY)
                         JOIN P_POLICY_EXT_TBL  PET ON (PL.POLICY_KEY = PET.POLICY_KEY)
                          JOIN P_TERM_DIM         TD ON (PL.TERM_KEY = TD.TERM_KEY AND TERM_MEASURE = 'MONTH')
                           JOIN (SELECT DISTINCT pricing_scheme_key, policy_key, new_used
                                   FROM bppp.RAW_POLICY_DATA_TBL
                                ) raw_pol
                              ON (PL.POLICY_KEY  = raw_pol.POLICY_KEY)
                  WHERE
                       PL.NAME = L_COVERED_PLAN_NM
               --Older data does not have AFT as part of RATE_EFFECTIVE_YEAR_NO and hence we need some othe rule to differentiate AFT vs. POS policies from old data
                   AND PL.CONTRACT_SALES_CHANNEL_KEY =  case when TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2021-08-01' then 3
                                                        else
                                                            (CASE WHEN (crec.RATE_EFFECTIVE_YEAR_NO LIKE '%AFT' OR    --Pricing effective from Oct 2012 to Jan 2015
                                                                  UPPER(crec.CONTRACT_PROGRAM_NM) LIKE 'AFTERMARKET%' ) OR  --Pricing effective from Jan 2009 to Oct 2012
                                                                  UPPER(L_COVERED_PLAN_NM) LIKE '%AFTERMARKET%' --2015 aftermarket plans
                                                            THEN 2
                                                                 WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) > 0
                                                            THEN 1   --Used policies can be sold through POS only
                                                            ELSE 1  --default is POS
                                                            END )
                                                        end
               ----
               ----Now we know that liter ranges upto max 9.8 only and there are certain models where we have to compare with liter data only
                   AND CASE
                       WHEN --TO_DATE(crec.process_dt, 'YYYYMMDD')  >= Date '2015-01-25' AND TO_DATE(crec.contract_effective_dt, 'YYYYMMDD')  >= Date '2015-01-25' AND
                             UPPER(L_COVERED_PLAN_NM) LIKE '%ADVANTAGE%'
                             AND L_Amtrust_Old_Pricing_Ind = 'N'    --Contracts being received through JBoat
                             THEN 1
                       WHEN TO_NUMBER(CREC.ENGINE1_HP_NO) <= 9.8 AND TO_NUMBER(CREC.ENGINE1_HP_NO) BETWEEN MIN_LITER AND MAX_LITER THEN 1
                       WHEN TO_NUMBER(CREC.ENGINE1_HP_NO) >= 9.9 AND TO_NUMBER(CREC.ENGINE1_HP_NO) BETWEEN MIN_HP AND MAX_HP THEN 1
                       WHEN (crec.product_type_cd) LIKE '%4.3%' AND 4.3 BETWEEN MIN_LITER AND MAX_LITER THEN 1
                       WHEN (crec.product_type_cd) LIKE '%5.0%' AND 5.0 BETWEEN MIN_LITER AND MAX_LITER THEN 1
                       ----------------------------------------------------------------------------------------------------------------------
                            --Next condiiton was added to handle Advantage plan from Viginia Surety where HP is missing
                            --Here we are trying to see, if we can map contract with policy using dealer_cost
                       ----------------------------------------------------------------------------------------------------------------------
                       WHEN UPPER(L_COVERED_PLAN_NM) LIKE '%ADVANTAGE%' AND L_Amtrust_Old_Pricing_Ind = 'Y' AND SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF'
                            AND CREC.ENGINE1_HP_NO IS NULL
                            AND TO_NUMBER(crec.CONTRACT_BASIC_COST_AMT) = TO_NUMBER(PET.dealer_cost)  THEN 1
                       END = 1

                   AND TD.YEAR = (CASE WHEN ( NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 0) <> 0 OR  NVL(CREC.NEW_BOAT_EXTTERM_YR_AMT, 0) <> 0 ) AND NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0
                                           AND L_COVERED_PLAN_NM NOT LIKE '%USED%'
                                       THEN --new boat
                                          NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 0) + NVL(CREC.NEW_BOAT_EXTTERM_YR_AMT, 0)
                                       WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0
                                       THEN --used boat
                                          (NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0)/12)
                                       ELSE  --This condition is being added to handle data from new contract files from jBoat
                                           ROUND((TO_DATE(CREC.contract_expire_dt, 'YYYYMMDD') - TO_DATE(CREC.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD')) / 365)
                                  END
                                 )
                   --AND PET.MFG_WARR_TERM = NVL(CREC.NEW_BOAT_FACTERM_YR_AMT, 1) --WE HAVE USED NVL AS 1 IN CASE OF USED
                   AND CASE WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) <> 0 OR L_COVERED_PLAN_NM LIKE '%USED%' THEN 'N'
                            WHEN NVL(CREC.USED_BOAT_TERM_MONTHS_AMT, 0) = 0 AND L_COVERED_PLAN_NM NOT LIKE '%USED%' THEN 'Y'
                       END = PL.NEW_USED_IND  -- handling used policy
                   AND PET.PRODUCT_CATEGORY_KEY =
                         DECODE (UPPER(crec.product_type_cd),
                                  'ALUMINUM / PONTOON', 10
                                  ,'ALUM/PONTOON', 10
                                  ,'FIBERGLASS', 11
                                  ,'4-STROKE', 7
                                  ,'4 STROKE', 7
                                  ,'2-STROKE', 6
                                  ,'2 STROKE', 6
                                  ,'MERCRUISER', 2
                                  ,'STERN', 2         --Sterns are Mercruiser
                                  ,'DFI', 5
                                  ,'V-6', 3
                                  --logic to categorize Outboards was provided by Analytics team
                                  ,'OUTBOARD', DECODE(UPPER(crec.engine1_model_nm),
                                         '4-STROKE', 7,
                                         '4 STROKE', 7,
                                         '2-STROKE', 6,
                                         '2 STROKE', 6,
                                         'OPTIMAX', 5,
                                         'DFI', 5
                                         )
                                    --Following code is being added to handle new contract files from jBoat system.
                                   ,CASE
                        --Change this section to use pricing scheme key for all ADVANTAGE plans for pricing effective 8/1/2021 --AJ
                                        WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)  IN ('PREMIER ADVANTAGE', 'PREMIER ADVANTAGE + GPS')
                                        THEN 11   --Filberglass pricing
                                        WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)  IN ('TRACKER PROMISE (ADVANTAGE)', 'TRACKER PROMISE (ADVANTAGE) + GPS')
                                        THEN 10   --Aluminum pricing
                                        WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2021-08-01' and upper(L_covered_plan_nm)  IN ('AFTERMARKET - ADVANTAGE', 'AFTERMARKET - ADVANTAGE + GPS')
                                        THEN 10   --AFTERMARKET Advantage policies will have uniform pricing independent of Aluminum vs. Fiberglass
                                        WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2021-08-01' and upper(L_covered_plan_nm)  IN ('ADVANTAGE', 'AFTERMARKET - ADVANTAGE', 'AFTERMARKET - ADVANTAGE-FL', 'PREMIER ADVANTAGE', 'PREMIER ADVANTAGE-FL')
                                        THEN 10   --All Advantage policies will have uniform pricing independent of Aluminum vs. Fiberglass  --effective 8/01/2021
                                        ELSE
                                             CASE  bpppStg.fn_get_product_category (p_model_nm => crec.PRODUCT_TYPE_CD, p_product_type => 'MOTOR')
                                               WHEN '4-STROKE' THEN 7
                                               WHEN 'MERCRUISER' THEN 2
                                               WHEN '2-STROKE' THEN 6
                                               WHEN 'DFI' THEN 5
                                             END
                                    END
                                  )
                   --AND TO_DATE(crec.process_dt, 'YYYYMMDD') BETWEEN PL.effective_dt and PL.EXP_DT
                   AND CASE WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' THEN DATE '2009-01-01'
                            WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') <= date '2015-01-24' THEN DATE '2012-10-16'
                        --WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25' THEN DATE '2015-01-25'
                            WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25' AND L_Amtrust_Old_Pricing_Ind = 'Y' THEN DATE '2012-10-16'  --migrated contracts
                            WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) <> 'BPS' AND L_Amtrust_Old_Pricing_Ind = 'N'   --AND TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2015-01-25'
                               THEN TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')  --DATE '2015-01-25'  --JBoat contracts
                            ELSE TO_DATE(CREC.PROCESS_DT, 'YYYYMMDD')
                       END BETWEEN PL.EFFECTIVE_DT AND PL.EXP_DT

                   --Handling Florida-Non Florida policies for older data
                   AND CASE --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= date '2012-10-16' THEN 1
                        --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2012-10-16' AND crec.dealer_state_cd = 'FL' AND raw_pol.pricing_scheme_key IN (12, 13) THEN 1
                        --WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') < date '2012-10-16' AND crec.dealer_state_cd <> 'FL' AND raw_pol.pricing_scheme_key IN (10, 11) THEN 1
                       WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'BPS' THEN 1   --migrated contracts
                       WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' AND crec.RATE_EFFECTIVE_YEAR_NO LIKE '%FL' AND raw_pol.pricing_scheme_key IN (12, 13) THEN 1    --migrated contracts
                       WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' AND crec.RATE_EFFECTIVE_YEAR_NO NOT LIKE '%FL' AND raw_pol.pricing_scheme_key IN (10, 11) THEN 1   --migrated contracts
                       WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' AND crec.dealer_state_cd = 'FL' AND raw_pol.pricing_scheme_key IN (12, 13) THEN 1    --migrated contracts
                       WHEN SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF' AND crec.dealer_state_cd <> 'FL' AND raw_pol.pricing_scheme_key IN (10, 11) THEN 1   --migrated contracts

                       WHEN TO_DATE(crec.process_dt, 'YYYYMMDD') >= DATE '2015-01-25' OR L_Amtrust_Old_Pricing_Ind = 'N' THEN 1  --new contracts from JBoat don't have a contract prefix
                       ELSE 0
                   END = 1
                ;
               EXCEPTION
                WHEN NO_DATA_FOUND THEN
                   BEGIN
                       ----------------------------------------------------------------------------------------------------------------------
                            --This condiiton was added to handle Advantage plan from Viginia Surety where HP is missing
                            --Here we are are using a dummy policy, which means that match on dealer_cost in the code above didn't work
                       ----------------------------------------------------------------------------------------------------------------------
                       IF UPPER(L_COVERED_PLAN_NM) LIKE '%ADVANTAGE%' AND L_Amtrust_Old_Pricing_Ind = 'Y' AND SUBSTR(CREC.CONTRACT_NO, 1, 3) = 'TMF'
                          AND CREC.ENGINE1_HP_NO IS NULL --AND TO_NUMBER(crec.CONTRACT_BASIC_COST_AMT) <> TO_NUMBER(PET.dealer_cost)
                          THEN

                          BEGIN
                          SELECT POLICY_PRODUCT_XID
                            INTO L_SKU_NO
                            FROM P_POLICY_TBL PL
                           WHERE effective_dt = date '2009-01-01'
                             AND PL.name = 'ADVANTAGE'
                             AND UPPER(PL.Description) LIKE '%DUMMY%';

                         EXCEPTION
                           WHEN NO_DATA_FOUND THEN
                           dbms_output.put_line( L_Debug_Message);
                           UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                              SET ERROR_DESC = 'NO VALID SKU AVAILABLE FOR THIS CONTRACT'
                                  ,update_audit_key = v_audit_key
                            WHERE CONTRACT_NO=CREC.CONTRACT_NO
                              AND ERROR_DESC IS NULL;

                           GOTO LABEL1;
                         END;

                       ELSE
                           dbms_output.put_line( L_Debug_Message);
                           UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                              SET ERROR_DESC = 'NO VALID SKU AVAILABLE FOR THIS CONTRACT'
                                  ,update_audit_key = v_audit_key
                            WHERE CONTRACT_NO=CREC.CONTRACT_NO
                              AND ERROR_DESC IS NULL;

                           GOTO LABEL1;
                       END IF;
                   END;

               END;

            WHEN TOO_MANY_ROWS THEN
               UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                  SET ERROR_DESC = 'MULTIPLE SKUs FOUND FOR THIS CONTRACT'
                      ,update_audit_key = v_audit_key
                WHERE CONTRACT_NO=CREC.CONTRACT_NO
                  AND ERROR_DESC IS NULL;

               GOTO LABEL1;

            WHEN OTHERS THEN
               UPDATE RAW_CONTRACT_WATERCRAFT_TBL
                  SET ERROR_DESC = 'ERROR FINDING VALID SKU FOR THIS CONTRACT'
                      ,update_audit_key = v_audit_key
                WHERE CONTRACT_NO=CREC.CONTRACT_NO
                  AND ERROR_DESC IS NULL;

               GOTO LABEL1;
         END;

         --dbms_output.put_line( 'Done finding policy SKU');


         --Ticket BASS-438
         L_HULL_FACWAR_EXPIRE_DT      := TO_DATE(crec.HULL_FACWAR_EXPIRE_DT, 'YYYYMMDD');      --migrated contracts will use crec.HULL_FACWAR_EXPIRE_DT
         L_TRAILER_FACWAR_EXPIRE_DT   := TO_DATE(crec.HULL_FACWAR_EXPIRE_DT, 'YYYYMMDD');      --Historical data had no explicit expiration date for Trailers
         L_ENGINE1_FACWRNTY_EXPIRE_DT := TO_DATE(crec.ENGINE1_FACWRNTY_EXPIRE_DT ,'YYYYMMDD'); --migrated contracts will use crec.ENGINE1_FACWRNTY_EXPIRE_DT

         L_NEW_BOAT_FACTERM_YR_AMT      := crec.NEW_BOAT_FACTERM_YR_AMT;        --migrated contracts will use crec.NEW_BOAT_FACTERM_YR_AMT
         L_NEW_ENGINE1_FACTERM_YR_AMT   := crec.NEW_BOAT_FACTERM_YR_AMT;        --migrated contracts will use crec.NEW_BOAT_FACTERM_YR_AMT
         L_NEW_TRAILER_FACTERM_YR_AMT   := crec.NEW_BOAT_FACTERM_YR_AMT;        --migrated contracts will use crec.NEW_BOAT_FACTERM_YR_AMT

         BEGIN
             --this section is applicable to JBoat specific contracts
             IF NVL(CREC.BUCKET_NM, 'ZZZ') <> 'OUTBOARD' AND L_Amtrust_Old_Pricing_Ind = 'N' --AND crec.process_dt >= 20150125
             THEN
                --dbms_output.put_line(crec.contract_no || ', BUCKET_NM: ' || CREC.BUCKET_NM || ', UNIT_CD: ' || CREC.UNIT_CD );
                 SELECT ADD_MONTHS(TO_DATE(crec.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD'), (Year_No * 12) )
                       , Year_No
                   INTO L_HULL_FACWAR_EXPIRE_DT
                       , L_NEW_BOAT_FACTERM_YR_AMT
                   FROM bppp.PRODUCT_BUCKET_REF pbx
                         JOIN bppp.product_category_dim pc USING (product_category_key)
                  WHERE
                       --Rule 2 is taking precedence over rule 1 as Tracker Promise will always be 5 year warranty irrespective of bucket_nm
                          --(based upon Mar 2015 financial report's  feedback)
                       --Rule 2 to handle records where unit_cd and bucket_nm is missing in incoming raw data
--                        (upper(L_covered_plan_nm) LIKE '%TRACKER PROMISE%' AND UPPER(pbx.description) LIKE '%TRACKER PROMISE%' AND pbx.UNIT_CD = 'XXX')
--                        OR
                       --Rule 1
                        (
                         (CREC.BUCKET_NM IS NOT NULL AND UPPER(product_category_nm) = UPPER(CREC.BUCKET_NM) )
                          AND
                         (pbx.UNIT_CD IS NULL OR UPPER(pbx.UNIT_CD) = NVL(UPPER(CREC.UNIT_CD), 'ZZZ') )
                        )
                        OR --Rule 2 to handle records where unit_cd and bucket_nm is missing in incoming raw data
                        (CREC.BUCKET_NM IS NULL AND CREC.UNIT_CD IS NULL
                         AND upper(L_covered_plan_nm) LIKE '%PROMISE%' AND UPPER(pbx.description) LIKE '%PROMISE%' AND pbx.UNIT_CD = 'XXX'
                        )
                  ;

             END IF;

--             dbms_output.put_line(crec.contract_no || ', BUCKET_NM: ' || CREC.BUCKET_NM || ', UNIT_CD: ' || CREC.UNIT_CD ||
--                                        ', L_HULL_FACWAR_EXPIRE_DT: ' || TO_CHAR(L_HULL_FACWAR_EXPIRE_DT, 'YYYYMMDD'));

         EXCEPTION
         WHEN NO_DATA_FOUND THEN
             NULL;
--            dbms_output.put_line(crec.contract_no || ': Error: BUCKET_NM: ' || CREC.BUCKET_NM || ', UNIT_CD: ' || CREC.UNIT_CD ||
--                                        ', L_HULL_FACWAR_EXPIRE_DT: ' || TO_CHAR(L_HULL_FACWAR_EXPIRE_DT, 'YYYYMMDD'));
         END;

         BEGIN
             --this section is applicable to JBoat specific contracts
             IF CREC.TRAILER_SERIAL_NO IS NOT NULL AND L_Amtrust_Old_Pricing_Ind = 'N' --AND crec.process_dt >= 20150125
             THEN

                 SELECT ADD_MONTHS(TO_DATE(crec.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD'), (Year_No * 12) )
                        ,Year_no
                   INTO L_TRAILER_FACWAR_EXPIRE_DT
                        , L_NEW_TRAILER_FACTERM_YR_AMT
                   FROM bppp.PRODUCT_BUCKET_REF pbx
                         JOIN bppp.product_category_dim pc USING (product_category_key)
                  WHERE UPPER(product_category_nm) = 'TRAILER' ;

             END IF;
--             dbms_output.put_line(crec.contract_no || ', BUCKET_NM: ' || CREC.BUCKET_NM || ', UNIT_CD: ' || CREC.UNIT_CD ||
--                                        ', L_TRAILER_FACWAR_EXPIRE_DT: ' || TO_CHAR(L_TRAILER_FACWAR_EXPIRE_DT, 'YYYYMMDD') ||
--                                        ', L_Amtrust_Old_Pricing_Ind: ' || L_Amtrust_Old_Pricing_Ind);


         EXCEPTION
         WHEN NO_DATA_FOUND THEN
            NULL;
--            dbms_output.put_line(crec.contract_no || ': Error: BUCKET_NM: ' || CREC.BUCKET_NM || ', UNIT_CD: ' || CREC.UNIT_CD ||
--                                        ', L_TRAILER_FACWAR_EXPIRE_DT: ' || TO_CHAR(L_TRAILER_FACWAR_EXPIRE_DT, 'YYYYMMDD') ||
--                                        ', L_Amtrust_Old_Pricing_Ind: ' || L_Amtrust_Old_Pricing_Ind);
         END;

         BEGIN
            --this section is applicable to JBoat specific contracts
             IF CREC.ENGINE1_SERIAL_NO IS NOT NULL AND L_Amtrust_Old_Pricing_Ind = 'N' --AND crec.process_dt >= 20150125
             THEN

                 SELECT ADD_MONTHS(TO_DATE(crec.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD'), (Year_No * 12) )
                       , Year_No
                   INTO L_ENGINE1_FACWRNTY_EXPIRE_DT
                       , L_NEW_ENGINE1_FACTERM_YR_AMT
                   FROM bppp.PRODUCT_BUCKET_REF pbx
                         JOIN bppp.product_category_dim pc USING (product_category_key)
                          JOIN bppp.policy_ext_tbl p_ex USING (product_category_key)
                           JOIN bppp.policy_tbl pol USING (policy_key)
                  WHERE pol.POLICY_PRODUCT_XID = L_SKU_NO
                    AND parent_category_key = 9   --we are checking only for Motor related policies/products
                  ;


             END IF;
--             dbms_output.put_line(crec.contract_no || ', BUCKET_NM: ' || CREC.BUCKET_NM || ', UNIT_CD: ' || CREC.UNIT_CD ||
--                                    ', L_ENGINE1_FACWRNTY_EXPIRE_DT: ' || TO_CHAR(L_ENGINE1_FACWRNTY_EXPIRE_DT, 'YYYYMMDD') ||
--                                    ', L_Amtrust_Old_Pricing_Ind: ' || L_Amtrust_Old_Pricing_Ind);

         EXCEPTION
         WHEN NO_DATA_FOUND THEN
--            dbms_output.put_line(crec.contract_no || ': Warr Date Error: '||
--                                    ', L_ENGINE1_FACWRNTY_EXPIRE_DT: ' || TO_CHAR(L_ENGINE1_FACWRNTY_EXPIRE_DT, 'YYYYMMDD') ||
--                                    ', L_Amtrust_Old_Pricing_Ind: ' || L_Amtrust_Old_Pricing_Ind);

            BEGIN
            --The SQL above will not work for Advantage plans as that will not tell us Motor product type
            --Not using this sql above as that would need to be tested..will handle in future
            SELECT ADD_MONTHS(TO_DATE(crec.CONTRACT_EFFECTIVE_DT, 'YYYYMMDD'), (Year_No * 12) )
                  , Year_No
              INTO L_ENGINE1_FACWRNTY_EXPIRE_DT
                  , L_NEW_ENGINE1_FACTERM_YR_AMT
              FROM bppp.PRODUCT_BUCKET_REF pbx
                    JOIN bppp.product_category_dim pc USING (product_category_key)
             WHERE product_category_key = L_Motor_product_category_key
               AND parent_category_key = 9   --we are checking only for Motor related policies/products
              ;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                 NULL;
                 dbms_output.put_line( 'Error calculating factory warranty term for Motor for contract_no: ' || crec.contract_no);
            END;
         END;


         L_TERMS_AND_CONDITIONS_KEY := NULL;
         L_CONTRACT_TEMPLATE_XID := NULL;
         -- do not resolve terms_and_conditions_key from cancelled contracts.
         IF UPPER(CREC.CONTRACT_STATUS_CD) NOT LIKE '%CANCEL%' THEN
            BEGIN

                SELECT terms_and_conditions_key,
                       contract_template_key
                  INTO L_TERMS_AND_CONDITIONS_KEY,
                       L_CONTRACT_TEMPLATE_XID
                  FROM p_t_and_c_xref TCX
                         JOIN bppp.policy_tbl pol
                            ON pol.POLICY_KEY = TCX.policy_key
                          JOIN bppp.postal_state_dim psd
                             ON psd.POSTAL_STATE_KEY = TCX.POSTAL_STATE_KEY
                 WHERE
                        pol.POLICY_PRODUCT_XID = L_SKU_NO
                   AND  psd.postal_state_cd = crec.dealer_state_cd
                   AND  TO_DATE(crec.process_dt, 'YYYYMMDD')  BETWEEN TCX.EFFECTIVE_DT AND TCX.END_DT
                   --AND NVL (t2.channel_partner_key, -1) = DECODE (t2.channel_partner_key, NULL, -1, tcx.channel_partner_key)
                   ;
            EXCEPTION
              WHEN OTHERS THEN
                 dbms_output.put_line(crec.contract_no || ': Error finding terms_and_conditions_key');
                  L_err_num := SQLCODE;
                  L_err_msg := SUBSTR(SQLERRM, 1, 2000);

                 UPDATE raw_contract_watercraft_tbl
                    SET ERROR_DESC = 'ERROR FINDING TERMS_AND_CONDITIONS_KEY: ' || TO_CHAR(L_err_num) || ': ' || L_err_msg
                        ,update_audit_key = v_audit_key
                  WHERE contract_no = crec.contract_no
                    AND ERROR_DESC IS NULL;  --do not overwrite original error_desc, if there is any
            END;
         END IF;

         ------------------------------------------------------------------------
         --Populating contract_common_load_tbl_hold
         --There are two entries for every item, one for billing address and another for shipping address
         ------------------------------------------------------------------------
         IF L_HULL_PLAN ='Y' THEN
                --hull model and serial billing
                INSERT INTO contract_common_load_tbl_hold
                (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,contract_status_xid,
                    contract_sale_dt,contract_start_dt,contract_end_dt,retail_amt, order_xid,sku_no,
                    si_unique_id,register_by,register_dt,outlet_xid,process_status_tx,
                    order_line_id,insert_audit_key,insert_dt,effective_dt, address_type,lienholder_unique_id,
                    contract_payment_unique_id,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID

                )
                VALUES (
                    crec.BILLING_HULL_UNIQUE_SEQ_NO --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,DECODE(crec.contract_status_cd, 'ACTIVE', 'ACTV', crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,TO_DATE(crec.contract_effective_dt, 'YYYYMMDD') --contract_sale_dt
                    ,TO_DATE(crec.contract_effective_dt, 'YYYYMMDD') --contract_start_dt
                    ,TO_DATE(crec.contract_expire_dt, 'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_HULL_SERIAL_NO --si_xid  ,crec.HULL_SERIAL_NO || '.' || crec.HULL_MODEL_NM
                    ,crec.first_nm || ' '|| crec.last_nm --register_by
                    ,SYSDATE --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'PURCHASE' --address_type
                    ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0)
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END
                    ,TO_DATE(crec.process_dt, 'YYYYMMDD')
                    ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );


               --hull model and serial  shipping
               insert into contract_common_load_tbl_hold
                (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,contract_status_xid,
                    contract_sale_dt,contract_start_dt,contract_end_dt,retail_amt, order_xid, sku_no,
                    si_unique_id,register_by,register_dt,outlet_xid,process_status_tx,
                    order_line_id,insert_audit_key,insert_dt,effective_dt, address_type,lienholder_unique_id,
                    contract_payment_unique_id,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID, CONTRACT_TEMPLATE_XID
                )
                values (
                    crec.SHIPPING_HULL_UNIQUE_SEQ_NO --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_HULL_SERIAL_NO  --si_xid  ,crec.HULL_SERIAL_NO ||'.'|| crec.HULL_MODEL_NM
                    ,crec.first_nm || ' '||crec.last_nm --register_by
                    ,sysdate --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'CURRENT' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0)
                          THEN 'FINANCED'
                          ELSE 'CASH'
                     END
                     ,TO_DATE(crec.process_dt,'YYYYMMDD')
                     ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );
         END IF;


         IF L_MOTOR_PLAN = 'Y' THEN
               --engine 1 model and serial billing
               insert into contract_common_load_tbl_hold
                (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,retail_amt
                    ,order_xid,sku_no,si_unique_id,register_by,register_dt,outlet_xid,process_status_tx,order_line_id,insert_audit_key,insert_dt,effective_dt
                    ,address_type,lienholder_unique_id,
                    contract_payment_unique_id,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
                )
                values (
                        crec.BILLING_ENGINE1_UNIQUE_SEQ_NO --unique_seq_no
                        ,L_SOURCE_SYSTEM_CD --source_system_cd
                        ,crec.contract_no --contract_xid
                        ,crec.contract_no --client_contract_no
                        --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                        ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                        ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                        ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                        ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                        ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                        ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                        ,l_sku_no --sku
                        ,L_ENGINE1_SERIAL_NO --si_xid  ,crec.ENGINE1_SERIAL_NO ||'.'|| crec.ENGINE1_MODEL_NM
                        ,crec.first_nm || ' '||crec.last_nm --register_by
                        ,sysdate --register_dt
                        ,crec.CONTRACT_DEALER_NO --outlet_xid
                        ,'AWAITING UPDATES' --process_status_tx
                        ,1 --order_line_id
                        ,v_audit_key --insert_audit_key
                        ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                        ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                        ,'PURCHASE' --address_type
                        ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                        ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                                  THEN 'FINANCED'
                                  ELSE 'CASH'
                               END
                        ,to_date(crec.process_dt,'YYYYMMDD')
                        ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                        );


               --engine 1 model and serial shipping
               insert into contract_common_load_tbl_hold
                (
                        unique_Seq_no,source_system_cd,contract_xid,client_contract_no,contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,retail_amt
                        ,order_xid,sku_no,si_unique_id,register_by,register_dt,outlet_xid,process_status_tx,order_line_id,insert_audit_key,insert_dt,effective_dt
                        ,address_type,lienholder_unique_id,
                    contract_payment_unique_id,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
                )
                values (
                        crec.SHIPPING_ENGINE1_UNIQUE_SEQ_NO --unique_seq_no
                        ,L_SOURCE_SYSTEM_CD --source_system_cd
                        ,crec.contract_no --contract_xid
                        ,crec.contract_no --client_contract_no
                        --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                        ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                        ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                        ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                        ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                        ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                        ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                        ,l_sku_no --sku
                        ,L_ENGINE1_SERIAL_NO --si_xid  ,crec.ENGINE1_SERIAL_NO ||'.'|| crec.ENGINE1_MODEL_NM
                        ,crec.first_nm || ' '||crec.last_nm --register_by
                        ,sysdate --register_dt
                        ,crec.CONTRACT_DEALER_NO --outlet_xid
                        ,'AWAITING UPDATES' --process_status_tx
                        ,1 --order_line_id
                        ,v_audit_key --insert_audit_key
                        ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                        ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                        ,'CURRENT' --address_type
                        ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                        ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0)
                         THEN 'FINANCED'
                              ELSE 'CASH'
                         END
                        ,to_date(crec.process_dt,'YYYYMMDD')
                        ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                        );
         END IF;


         IF crec.ENGINE2_SERIAL_NO IS NOT NULL then
                        --engine 2 model and serial billing
            insert into contract_common_load_tbl_hold
                (
                        unique_Seq_no,source_system_cd,contract_xid,client_contract_no,contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,retail_amt
                        ,order_xid,sku_no,si_unique_id,register_by,register_dt,outlet_xid,process_status_tx,order_line_id,insert_audit_key,insert_dt,effective_dt
                        ,address_type,lienholder_unique_id,
                    contract_payment_unique_id,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
                )
            values (
                crec.BILLING_ENGINE2_UNIQUE_SEQ_NO --unique_seq_no
                ,L_SOURCE_SYSTEM_CD --source_system_cd
                ,crec.contract_no --contract_xid
                ,crec.contract_no --client_contract_no
                --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                ,l_sku_no --sku
                ,crec.ENGINE2_SERIAL_NO --si_xid  ,crec.ENGINE2_SERIAL_NO ||'.'|| crec.ENGINE2_MODEL_NM
                ,crec.first_nm || ' '||crec.last_nm --register_by
                ,sysdate --register_dt
                ,crec.CONTRACT_DEALER_NO --outlet_xid
                ,'AWAITING UPDATES' --process_status_tx
                 ,1 --order_line_id
                ,v_audit_key --insert_audit_key
                ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                ,'PURCHASE' --address_type
                ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END ,
                       to_date(crec.process_dt,'YYYYMMDD')
                ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                );


            --engine 2 model and serial shipping
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,retail_amt
                    ,order_xid,sku_no,si_unique_id,register_by,register_dt,outlet_xid,process_status_tx,order_line_id,insert_audit_key,insert_dt,effective_dt
                    ,address_type,lienholder_unique_id,
                    contract_payment_unique_id,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.SHIPPING_ENGINE2_UNIQUE_SEQ_NO --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,crec.ENGINE2_SERIAL_NO  --si_xid  ,crec.ENGINE2_SERIAL_NO ||'.'|| crec.ENGINE2_MODEL_NM
                    ,crec.first_nm || ' '||crec.last_nm --register_by
                    ,sysdate --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'CURRENT' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0)
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END ,
                       to_date(crec.process_dt,'YYYYMMDD')
                    ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );
         END IF;


         IF L_TRAILER_PLAN = 'Y' THEN
            --trailer model and serial billing
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,retail_amt
                    ,order_xid,sku_no,si_unique_id,register_by,register_dt,outlet_xid,process_status_tx,order_line_id,insert_audit_key,insert_dt,effective_dt
                    ,address_type,lienholder_unique_id,
                    contract_payment_unique_id ,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.BILLING_TRAILER_UNIQUE_SEQ_NO --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_TRAILER_SERIAL_NO  --si_xid  ,crec.TRAILER_SERIAL_NO ||'.'|| L_TRAILER_MODEL_NO
                    ,crec.first_nm || ' '||crec.last_nm --register_by
                    ,sysdate --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'PURCHASE' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END,
                       to_date(crec.process_dt,'YYYYMMDD')
                    ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );

            --trailer model and serial shipping
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,retail_amt
                    ,order_xid,sku_no,si_unique_id,register_by,register_dt,outlet_xid,process_status_tx,order_line_id,insert_audit_key,insert_dt,effective_dt
                    ,address_type,lienholder_unique_id,
                    contract_payment_unique_id ,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.SHIPPING_TRAILER_UNIQUE_SEQ_NO --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_TRAILER_SERIAL_NO --si_xid  ,crec.TRAILER_SERIAL_NO ||'.'|| L_TRAILER_MODEL_NO
                    ,crec.first_nm || ' '||crec.last_nm --register_by
                    ,sysdate --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'CURRENT' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END,
                       to_date(crec.process_dt,'YYYYMMDD')
                     ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );
         END IF;


         --Coded added by AJ
         IF L_TROLLING_MOTOR_PLAN = 'Y' THEN
            --TROLLER serial billing
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,
                    contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,
                    retail_amt,order_xid,sku_no,si_unique_id,register_by,register_dt,
                    outlet_xid,process_status_tx,order_line_id,
                    insert_audit_key,insert_dt,effective_dt,address_type,lienholder_unique_id,
                    contract_payment_unique_id ,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.Bill_Troller_Unique_Seq_No --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_TROLLING_MOTOR_SERIAL_NO   --si_xid ,crec.TROLLING_MOTOR_SERIAL_NO ||'.'|| NULL
                    ,crec.first_nm || ' ' || crec.last_nm --register_by
                    ,SYSDATE --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'PURCHASE' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END ,
                       to_date(crec.process_dt,'YYYYMMDD')
                    ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );

            --TROLLER serial shipping
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,
                    contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,
                    retail_amt,order_xid,sku_no,si_unique_id,register_by,register_dt,
                    outlet_xid,process_status_tx,order_line_id,
                    insert_audit_key,insert_dt,effective_dt,address_type,lienholder_unique_id,
                    contract_payment_unique_id ,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.Ship_Troller_Unique_Seq_No --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_TROLLING_MOTOR_SERIAL_NO --si_xid  ,crec.TROLLING_MOTOR_SERIAL_NO || '.' || NULL
                    ,crec.first_nm || ' '||crec.last_nm --register_by
                    ,sysdate --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'CURRENT' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END,
                       to_date(crec.process_dt,'YYYYMMDD')
                     ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID

                    );
         END IF;


         IF L_DEPTH_FINDER_PLAN = 'Y' THEN
            --Depth Finder serial billing
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,
                    contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,
                    retail_amt,order_xid,sku_no,si_unique_id,register_by,register_dt,
                    outlet_xid,process_status_tx,order_line_id,
                    insert_audit_key,insert_dt,effective_dt,address_type,lienholder_unique_id,
                    contract_payment_unique_id ,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID,CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.Bill_DepthFinder_Unique_Seq_No --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_DEPTH_FINDER_ID_NO   --si_xid   ,crec.DEPTH_FINDER_ID_NO ||'.'|| crec.DEPTH_FINDER_MODEL_NM
                    ,crec.first_nm || ' ' || crec.last_nm --register_by
                    ,SYSDATE --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'PURCHASE' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END ,
                       to_date(crec.process_dt,'YYYYMMDD')
                     ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );

            --Depth Finder serial shipping
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,
                    contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,
                    retail_amt,order_xid,sku_no,si_unique_id,register_by,register_dt,
                    outlet_xid,process_status_tx,order_line_id,
                    insert_audit_key,insert_dt,effective_dt,address_type,lienholder_unique_id,
                    contract_payment_unique_id ,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID, CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.Ship_DepthFinder_Unique_Seq_No --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_DEPTH_FINDER_ID_NO  --si_xid ,crec.DEPTH_FINDER_ID_NO || '.' || crec.DEPTH_FINDER_MODEL_NM
                    ,crec.first_nm || ' '||crec.last_nm --register_by
                    ,sysdate --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'CURRENT' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END ,
                       to_date(crec.process_dt,'YYYYMMDD')
                     ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );
         END IF;


         -- ADDED BY DS

          IF L_GPS_PLAN = 'Y' THEN
            --GPS serial billing
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,
                    contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,
                    retail_amt,order_xid,sku_no,si_unique_id,register_by,register_dt,
                    outlet_xid,process_status_tx,order_line_id,
                    insert_audit_key,insert_dt,effective_dt,address_type,lienholder_unique_id,
                    contract_payment_unique_id ,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID, CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.Bill_GPS_Unique_Seq_No --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_GPS_SERIAL_NO  --si_xid
                    ,crec.first_nm || ' ' || crec.last_nm --register_by
                    ,SYSDATE --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'PURCHASE' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END,
                       to_date(crec.process_dt,'YYYYMMDD')
                     ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );

            --GPS serial shipping
            insert into contract_common_load_tbl_hold
            (
                    unique_Seq_no,source_system_cd,contract_xid,client_contract_no,
                    contract_status_xid,contract_sale_dt,contract_start_dt,contract_end_dt,
                    retail_amt,order_xid,sku_no,si_unique_id,register_by,register_dt,
                    outlet_xid,process_status_tx,order_line_id,
                    insert_audit_key,insert_dt,effective_dt,address_type,lienholder_unique_id,
                    contract_payment_unique_id ,contract_created_dt
                    ,TERMS_AND_CONDTIONS_XID, CONTRACT_TEMPLATE_XID
            )
            values (
                    crec.Ship_GPS_Unique_Seq_No --unique_seq_no
                    ,L_SOURCE_SYSTEM_CD --source_system_cd
                    ,crec.contract_no --contract_xid
                    ,crec.contract_no --client_contract_no
                    --,decode(crec.contract_status_cd,'ACTIVE','ACTV',crec.contract_status_cd) --contract_status_xid
                    ,NVL(crec.contract_status_name, crec.contract_status_cd)  --contract_status_xid
                    ,to_date(crec.contract_effective_dt,'YYYYMMDD') --contract_sale_dt
                    ,to_date(crec.contract_effective_dt ,'YYYYMMDD') --contract_start_dt
                    ,to_date(crec.contract_expire_dt,'YYYYMMDD') --contract_end_dt
                    ,crec.CONTRACT_PURCHASE_PRICE_AMT --retail_amt
                    ,NULL  --  AS now we are not loding orders crec.contract_no --order_xid
                    ,l_sku_no --sku
                    ,L_GPS_SERIAL_NO  --si_xid
                    ,crec.first_nm || ' '||crec.last_nm --register_by
                    ,sysdate --register_dt
                    ,crec.CONTRACT_DEALER_NO --outlet_xid
                    ,'AWAITING UPDATES' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --insert_dt --AS told on 7/22/2015 that this date is not used anymore
                    ,TRUNC(SYSDATE)  --TO_DATE(crec.process_dt, 'YYYYMMDD') --effective_dt --AS told on 7/22/2015 that this date is used to find latest record
                    ,'CURRENT' --address_type
                     ,UPPER(crec.CONTRACT_LEINHOLDER_NM)
                    ,CASE WHEN  (NVL(crec.GROSS_FINANCED_AMT,0) > 0 )
                          THEN 'FINANCED'
                          ELSE 'CASH'
                       END ,
                       to_date(crec.process_dt,'YYYYMMDD')
                     ,L_TERMS_AND_CONDITIONS_KEY, L_CONTRACT_TEMPLATE_XID
                    );
         END IF;



         -----------------------------------------------------------------------
         --End of code for contract_common_load_tbl_hold
         -----------------------------------------------------------------------


         ------------------------------------------------------------------------
         --Populating common_load_hold_tbl (aka item common load hold table)
         --There are two entries for every item, one for billing address and another for shipping address
         ------------------------------------------------------------------------

         --if L_HULL_PLAN = 'Y' then
         IF L_hull_serial_no IS NOT NULL THEN
                --Hull billing
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key,warranty_expiration_dt,
                product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.BILLING_HULL_UNIQUE_SEQ_NO --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,L_hull_model_no --model_no
                ,L_hull_serial_no --serial_no
                ,L_hull_serial_no  --si_unique_id  ,crec.hull_serial_no || '.' || crec.hull_model_nm
                --,ADD_MONTHS(L_HULL_FACWAR_EXPIRE_DT,  - (L_NEW_BOAT_FACTERM_YR_AMT * 12 ) )  --purchase_dt
                ,LEAST(to_date(crec.contract_effective_dt, 'YYYYMMDD'), L_HULL_FACWAR_EXPIRE_DT )   --purchase_dt  --warr exp dt may be in the past in case of Used products
                ,crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
                --,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm         --file_nm
                ,v_audit_key             --insert_audit_key
                ,L_HULL_FACWAR_EXPIRE_DT --warranty expiration dt
                ,UPPER(L_hull_model_no || '.' || L_hull_make_nm),   --product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL, L_PACKAGE_TYPE_DESCRIPTION
                );

                --hull shipping
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key,warranty_expiration_dt
                ,product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.SHIPPING_HULL_UNIQUE_SEQ_NO --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,L_hull_model_no --model_no
                ,L_hull_serial_no --serial_no
                ,L_hull_serial_no --si_unique_id ,crec.hull_serial_no ||'.'|| crec.hull_model_nm
                --,ADD_MONTHS(L_HULL_FACWAR_EXPIRE_DT, - (L_NEW_BOAT_FACTERM_YR_AMT * 12) )--purchase_dt
                ,LEAST(to_date(crec.contract_effective_dt, 'YYYYMMDD'), L_HULL_FACWAR_EXPIRE_DT )   --purchase_dt
                ,crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
               -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,L_HULL_FACWAR_EXPIRE_DT --warranty_expiration_dt
                ,UPPER(L_hull_model_no || '.' || L_hull_make_nm), --product_unique_id
                L_package_xid,L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );

         end if;

         --if L_MOTOR_PLAN = 'Y'  then
         IF L_engine1_serial_no IS NOT NULL THEN
                --engine1 billing
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key,warranty_expiration_dt
                ,product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.BILLING_ENGINE1_UNIQUE_SEQ_NO --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,L_engine1_model_no --model_no
                ,L_engine1_serial_no --serial_no
                ,L_engine1_serial_no --si_unique_id  ,crec.engine1_serial_no ||'.'|| crec.engine1_model_nm
                --,ADD_MONTHS(L_ENGINE1_FACWRNTY_EXPIRE_DT, - (L_NEW_ENGINE1_FACTERM_YR_AMT * 12 ) )--purchase_dt
                ,LEAST(to_date(crec.contract_effective_dt, 'YYYYMMDD'), L_ENGINE1_FACWRNTY_EXPIRE_DT )   --purchase_dt
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
               -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,L_ENGINE1_FACWRNTY_EXPIRE_DT    --warranty_expiration_dt
                ,UPPER(L_engine1_model_no || '.' || L_engine1_make_nm),      --product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );

                --engine1 shipping
                insert into common_load_hold_tbl
                (unique_seq_no, source_system_cd, first_nm, middle_nm, last_nm, address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key,warranty_expiration_dt
                ,product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.SHIPPING_ENGINE1_UNIQUE_SEQ_NO --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,L_engine1_model_no --model_no
                ,L_engine1_serial_no --serial_no
                ,L_engine1_serial_no --si_unique_id  ,crec.engine1_serial_no ||'.'|| crec.engine1_model_nm
                --,ADD_MONTHS(L_ENGINE1_FACWRNTY_EXPIRE_DT, -(L_NEW_ENGINE1_FACTERM_YR_AMT * 12) )  --purchase_dt
                ,LEAST(to_date(crec.contract_effective_dt, 'YYYYMMDD'), L_ENGINE1_FACWRNTY_EXPIRE_DT )   --purchase_dt  --warr exp dt will be in the past in case of used products
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
               -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,L_ENGINE1_FACWRNTY_EXPIRE_DT     --warranty_expiration_dt
                ,UPPER(L_engine1_model_no || '.' || L_engine1_make_nm) ,     --product_unique_id
                L_package_xid,L_PACKAGE_TYPE, NULL ,L_PACKAGE_TYPE_DESCRIPTION
                );

         END IF;

         if crec.engine2_serial_no IS NOT NULL then
                --engine2 billing
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key,warranty_expiration_dt
                ,product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.BILLING_ENGINE2_UNIQUE_SEQ_NO --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,crec.engine2_model_nm --model_no
                ,crec.engine2_serial_no --serial_no
                ,crec.engine2_serial_no  --si_unique_id  ,crec.engine2_serial_no ||'.'|| crec.engine2_model_nm
                ,ADD_MONTHS(TO_DATE(crec.ENGINE2_FACWRNTY_EXPIRE_DT, 'YYYYMMDD'), - (crec.NEW_BOAT_FACTERM_YR_AMT * 12 ) )--purchase_dt
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
              -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,to_date(crec.ENGINE2_FACWRNTY_EXPIRE_DT, 'YYYYMMDD') --warranty_expiration_dt
                ,UPPER(crec.engine2_model_nm || '.' || crec.engine2_make_nm) ,   --product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );

                --engine2 shipping
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key,warranty_expiration_dt
                ,product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.SHIPPING_ENGINE2_UNIQUE_SEQ_NO --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,crec.engine2_model_nm --model_no
                ,crec.engine2_serial_no --serial_no
                ,crec.engine2_serial_no  --si_unique_id ,crec.engine2_serial_no || '.' || crec.engine2_model_nm
                ,ADD_MONTHS(TO_DATE(crec.ENGINE2_FACWRNTY_EXPIRE_DT, 'YYYYMMDD'), - (crec.NEW_BOAT_FACTERM_YR_AMT * 12 ) )--purchase_dt
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
               -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,to_date(crec.ENGINE2_FACWRNTY_EXPIRE_DT , 'YYYYMMDD') --warranty_expiration_dt
                ,UPPER(crec.engine2_model_nm || '.' || crec.engine2_make_nm),    --product_unique_id
                L_package_xid,L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );

         end if;

         --if L_TRAILER_PLAN ='Y' then
         IF L_trailer_serial_no IS NOT NULL THEN
                --trailer billing
                insert into common_load_hold_tbl
                (unique_seq_no, source_system_cd, first_nm, middle_nm, last_nm
                ,address_line1_tx, address_line2_tx, city_nm, state_cd, zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key, product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description
                , warranty_expiration_dt)
                values
                (
                 crec.BILLING_TRAILER_UNIQUE_SEQ_NO --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,l_trailer_model_no --model_no
                ,L_trailer_serial_no --serial_no
                ,L_trailer_serial_no  --si_unique_id  ,crec.trailer_serial_no || '.' || l_trailer_model_no
                --,TO_DATE(crec.process_dt, 'YYYYMMDD') --purchase_dt
                --,ADD_MONTHS(L_TRAILER_FACWAR_EXPIRE_DT,  - (L_NEW_TRAILER_FACTERM_YR_AMT * 12 ) )  --purchase_dt
                ,to_date(crec.contract_effective_dt, 'YYYYMMDD')   --purchase_dt
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
                --,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,UPPER(L_trailer_model_no || '.' || L_trailer_make_nm),  --product_unique_id
                L_package_xid, L_PACKAGE_TYPE,NULL,L_PACKAGE_TYPE_DESCRIPTION
                ,L_TRAILER_FACWAR_EXPIRE_DT
                );

                --trailer shipping
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm
                ,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key, product_unique_id,
                package_xid, package_type_unique_id, package_created_ts, package_type_description
                , warranty_expiration_dt)
                values
                (
                 crec.SHIPPING_TRAILER_UNIQUE_SEQ_NO --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,l_trailer_model_no --model_no
                ,L_trailer_serial_no --serial_no
                ,L_trailer_serial_no  --si_unique_id  ,crec.trailer_serial_no ||'.'||l_trailer_model_no
                --,to_date(crec.process_dt,'YYYYMMDD') --purchase_dt
                --,ADD_MONTHS(L_TRAILER_FACWAR_EXPIRE_DT,  - (L_NEW_TRAILER_FACTERM_YR_AMT * 12 ) )  --purchase_dt
                ,to_date(crec.contract_effective_dt, 'YYYYMMDD')   --purchase_dt
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
                --,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,UPPER(l_trailer_model_no || '.' || L_trailer_make_nm),   --product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                ,L_TRAILER_FACWAR_EXPIRE_DT
                );

         end if;


         --Code added by AJ --common_load_hold_tbl
         --IF L_TROLLING_MOTOR_PLAN ='Y'  THEN
         IF L_TROLLING_MOTOR_SERIAL_NO IS NOT NULL THEN
                --comon_load_hold_tbl
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,
                 address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx,
                 phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                -- store_no,
                file_nm,insert_audit_key, product_unique_id,
                package_xid, package_type_unique_id, package_created_ts, package_type_description)
                values
                (
                 crec.Bill_Troller_Unique_Seq_No --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,l_trolling_motor_model_no          --model_no
                ,L_TROLLING_MOTOR_SERIAL_NO --serial_no
                ,L_TROLLING_MOTOR_SERIAL_NO --si_unique_id  ,crec.TROLLING_MOTOR_SERIAL_NO || '.' || NULL
                --,TO_DATE(crec.process_dt, 'YYYYMMDD') --purchase_dt
                ,to_date(crec.contract_effective_dt, 'YYYYMMDD')   --purchase_dt  --since we are using contract_effective_dt as purchase_dt so lets use it for trolling motor/depth finder etc also
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
                --,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,l_trolling_motor_model_no || '.'  || l_trolling_motor_make_nm , --product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );


                --comon_load_hold_tbl
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                 --store_no,
                 file_nm,insert_audit_key, product_unique_id,
                 package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.Ship_Troller_Unique_Seq_No --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,l_trolling_motor_model_no --model_no
                ,L_TROLLING_MOTOR_SERIAL_NO --serial_no
                ,L_TROLLING_MOTOR_SERIAL_NO  --si_unique_id  ,crec.TROLLING_MOTOR_SERIAL_NO ||'.'|| NULL
                --,to_date(crec.process_dt,'YYYYMMDD') --purchase_dt
                ,to_date(crec.contract_effective_dt, 'YYYYMMDD')   --purchase_dt  --since we are using contract_effective_dt as purchase_dt so lets use it for trolling motor/depth finder etc also
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
               -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,l_trolling_motor_model_no || '.' ||l_trolling_motor_make_nm,   --product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );

         end if;

         --IF L_DEPTH_FINDER_PLAN ='Y'  THEN
         IF L_DEPTH_FINDER_ID_NO IS NOT NULL THEN
                --comon_load_hold_tbl
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,
                 address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx,
                 phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                -- store_no,
                file_nm,insert_audit_key,product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.Bill_DepthFinder_Unique_Seq_No --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,L_DEPTH_FINDER_MODEL_NO          --model_no
                ,L_DEPTH_FINDER_ID_NO --serial_no
                ,L_DEPTH_FINDER_ID_NO --si_unique_id   ,crec.DEPTH_FINDER_ID_NO || '.' || crec.DEPTH_FINDER_MODEL_NM
                --,TO_DATE(crec.process_dt, 'YYYYMMDD') --purchase_dt
                ,to_date(crec.contract_effective_dt, 'YYYYMMDD')   --purchase_dt  --since we are using contract_effective_dt as purchase_dt so lets use it for trolling motor/depth finder etc also
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
                --,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,UPPER(L_DEPTH_FINDER_MODEL_NO || '.' || L_depth_finder_make_nm), --product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );


                --comon_load_hold_tbl
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                -- store_no,
                 file_nm,insert_audit_key,product_unique_id,
                 package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.Ship_DepthFinder_Unique_Seq_No --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,L_DEPTH_FINDER_MODEL_NO --model_no
                ,L_DEPTH_FINDER_ID_NO --serial_no
                ,L_DEPTH_FINDER_ID_NO  --si_unique_id  ,(crec.DEPTH_FINDER_ID_NO) ||'.'|| crec.DEPTH_FINDER_MODEL_NM
                --,to_date(crec.process_dt,'YYYYMMDD') --purchase_dt
                ,to_date(crec.contract_effective_dt, 'YYYYMMDD')   --purchase_dt  --since we are using contract_effective_dt as purchase_dt so lets use it for trolling motor/depth finder etc also
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
               -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,UPPER(L_DEPTH_FINDER_MODEL_NO || '.' || L_depth_finder_make_nm),--product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );

         end if;


         -- Added by DS
         --IF  L_GPS_PLAN = 'Y' THEN
         IF L_GPS_SERIAL_NO IS NOT NULL THEN
                --comon_load_hold_tbl
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,
                 address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx,
                 phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                -- store_no,
                file_nm,insert_audit_key,product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.Bill_GPS_Unique_Seq_No --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,L_GPS_MODEL_NO          --model_no
                ,L_GPS_SERIAL_NO --serial_no
                ,L_GPS_SERIAL_NO -- || '.' || 'GPS' --si_unique_id
                --,TO_DATE(crec.process_dt, 'YYYYMMDD') --purchase_dt
                ,to_date(crec.contract_effective_dt, 'YYYYMMDD')   --purchase_dt  --since we are using contract_effective_dt as purchase_dt so lets use it for trolling motor/depth finder etc also
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
               -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,L_GPS_MODEL_NO || '.' || L_GPS_MAKE_NM, --product_unique_id
                L_package_xid, L_PACKAGE_TYPE, NULL,L_PACKAGE_TYPE_DESCRIPTION
                );


                --comon_load_hold_tbl
                insert into common_load_hold_tbl
                (unique_seq_no,source_system_cd,first_nm,middle_nm,last_nm,address_line1_tx,address_line2_tx,city_nm,state_cd,zip_cd_tx
                ,phone_no,model_no,serial_no,si_unique_id,purchase_dt,purchase_amt,
                --store_no,
                file_nm,insert_audit_key,product_unique_id,
                package_xid, package_type_unique_id, package_created_ts,package_type_description)
                values
                (
                 crec.Ship_GPS_Unique_Seq_No --unique_seq_no
                 ,L_SOURCE_SYSTEM_CD --source_system_cd
                 ,crec.first_nm
                 ,crec.middle_init --middle_nm
                 ,crec.last_nm
                 ,crec.street_address_tx --address_line1_tx
                 ,'' --address_line2_tx
                 ,crec.city_nm
                 ,crec.Customer_STATE_CD
                 ,crec.zip_cd --zip_cd_tx
                ,crec.phone_no --primary_phone_no
                ,L_GPS_MODEL_NO --model_no
                ,L_GPS_SERIAL_NO --serial_no
                ,L_GPS_SERIAL_NO -- ||'.'|| 'GPS' --si_unique_id
                --,to_date(crec.process_dt,'YYYYMMDD') --purchase_dt
                ,to_date(crec.contract_effective_dt, 'YYYYMMDD')   --purchase_dt  --since we are using contract_effective_dt as purchase_dt so lets use it for trolling motor/depth finder etc also
                ,NULL    -- crec.BOAT_SELLING_PRICE_AMT  -- purchase_amt
               -- ,crec.contract_dealer_no --store_no
                ,crec.rh_file_nm --file_nm
                ,v_audit_key --insert_audit_key
                ,L_GPS_MODEL_NO || '.' || L_GPS_MAKE_NM, --product_unique_id
                L_package_xid, L_PACKAGE_TYPE,NULL,L_PACKAGE_TYPE_DESCRIPTION
                );

         end if;



         ------------------------------------------------------------------------
         --End of code for common_load_hold_tbl
         ------------------------------------------------------------------------


         <<LABEL1>>
         NULL;
      EXCEPTION
         WHEN OTHERS THEN

            dbms_output.put_line(crec.contract_no || ':' || L_COVERED_PLAN_NM || ':' ||
                                    ', CREC.PROCESS_DT: ' || TO_CHAR(CREC.PROCESS_DT) ||
                                    ', L_Amtrust_Old_Pricing_Ind: ' || L_Amtrust_Old_Pricing_Ind );

            L_err_num := SQLCODE;
            L_err_msg := SUBSTR(SQLERRM, 1, 2000);

            UPDATE RAW_CONTRACT_WATERCRAFT_TBL
               SET ERROR_DESC = TO_CHAR(L_err_num) || ': '|| L_err_msg
             WHERE contract_no = crec.contract_no
               AND ERROR_DESC IS NULL;

      END;

      COMMIT;  --for debugging only
      END LOOP;


      /* This code is commented as we have handled package_type with the plan based component*/

      /*
      -- Added by DS to handle Package type
     MERGE INTO common_load_hold_tbl p
      USING ( SELECT package_xid,
                      SUM (
                           DISTINCT DECODE (C.package_type,
                                      'BOAT', 1,
                                      'TRAILER', 2,
                                      'MOTOR', 4))
                       AS ptype
                FROM common_load_hold_tbl C
               GROUP BY package_xid
             ) r
         ON (p.package_xid = r.package_xid)
       WHEN MATCHED THEN
            UPDATE
               SET p.package_type =  DECODE (ptype,
                                    1, 'BOAT ONLY',
                                    2, 'TRAILER ONLY',
                                    3, 'BOAT & TRAILER ONLY',
                                    4, 'MOTOR ONLY',
                                    5, 'BOAT & MOTOR',
                                    6, 'TRAILER & MOTOR',
                                    7, 'BOAT,TRAILER & MOTOR');
      */
      COMMIT;

      select count(*)
        into l_count
        from (
              select product_unique_id from common_load_hold_tbl
              minus
              select product_unique_id from bppp.product_dim
              );

      IF l_count <> 0
      THEN
         --No need to send an email or QA report for this situation as this doesn't require any action
         L_temp_message := 'Pkg_Raw_Contract: There are ' || l_count || ' models in common_load_hold_tbl, which are missing from ' || C_CORE_SCHEMA || '.Product_Dim@' || C_DB_NAME;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_CONTRACT_DATA.PROC_CLIENT_CONTRACT_DATA', 'Contracts', L_temp_message, l_count, SYSTIMESTAMP, 'COMMON_LOAD_HOLD_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

         COMMIT;

      END IF;


   END;



  PROCEDURE proc_contract_cancel_data IS


     CURSOR C2 IS
     SELECT
         CONTRACT_NO
        ,CANCEL_PROCESS_DT
        ,CANCEL_EFFECTIVE_DT
        ,NUMBER_DAYS_USED
        ,CANCEL_TYPE_CD
        ,REFUND_PCT
        ,CANCEL_FEE_AMT
        ,PREMIUM_REFUND
        ,CUSTOMER_REFUND
        ,INSERT_AUDIT_KEY
        ,FILE_NM
        ,UNIQUE_SEQ_NO
        FROM (select a.*,row_number() over(partition by a.contract_no order by 1) rno from RAW_CONTRACT_CANCEL_TBL a) where rno=1;

        CREC2 C2%ROWTYPE;

        v_audit_key number;

   BEGIN


        v_audit_key := p_get_audit_key (p_program_nm => 'pkg_contract_data.proc_contract_cancel_data', p_table_nm => 'contract_common_load_hold_tbl');



        UPDATE RAW_CONTRACT_CANCEL_TBL
           SET UNIQUE_SEQ_NO = common_load_seq.NEXTVAL
         WHERE UNIQUE_SEQ_NO IS NULL;

       INSERT
         INTO  RAW_CONTRACT_CANCEL_ERROR_TBL
        (
         CONTRACT_NO
        ,CANCEL_PROCESS_DT
        ,CANCEL_EFFECTIVE_DT
        ,NUMBER_DAYS_USED
        ,CANCEL_TYPE_CD
        ,REFUND_PCT
        ,CANCEL_FEE_AMT
        ,PREMIUM_REFUND
        ,CUSTOMER_REFUND
        ,INSERT_AUDIT_KEY
        ,FILE_NM
        ,UNIQUE_SEQ_NO
        ,UPDATE_AUDIT_KEY
        ,ERROR_DESC
        )
       SELECT CONTRACT_NO
             ,CANCEL_PROCESS_DT
             ,CANCEL_EFFECTIVE_DT
             ,NUMBER_DAYS_USED
             ,CANCEL_TYPE_CD
             ,REFUND_PCT
             ,CANCEL_FEE_AMT
             ,PREMIUM_REFUND
             ,CUSTOMER_REFUND
             ,INSERT_AUDIT_KEY
             ,FILE_NM
             ,UNIQUE_SEQ_NO
             ,UPDATE_AUDIT_KEY
             ,'CONTRACT NUMBER DOES NOT EXIST' AS ERROR_DESC
        FROM RAW_CONTRACT_CANCEL_TBL A
       WHERE NOT EXISTS ( SELECT 1 FROM V_CONTRACT_LKP B WHERE B.CONTRACT_XID=A.CONTRACT_NO
                          UNION
                          SELECT 1 FROM P_RAW_CONTRACT_HOLDER_TBL B WHERE B.CONTRACT_NO=A.CONTRACT_NO
                        );

        DELETE FROM RAW_CONTRACT_CANCEL_TBL
         WHERE CONTRACT_NO IN ( SELECT CONTRACT_NO FROM RAW_CONTRACT_CANCEL_ERROR_TBL);

        --inserting into contract cancel records
        FOR crec2 IN c2 LOOP
           EXIT WHEN c2%NOTFOUND;


           INSERT
             INTO contract_common_load_tbl_hold (
                  unique_Seq_no, source_system_cd, contract_xid, client_contract_no,
                  contract_status_xid, contract_sale_dt, contract_start_dt, contract_end_dt,
                  retail_amt, order_xid, sku_no, si_xid, register_by, register_dt,
                  outlet_xid, process_status_tx, order_line_id,
                  insert_audit_key,insert_dt,effective_dt
                  ,address_type,CANCEL_BY
                  ,CANCEL_DT
                  --,CANCEL_REFUND_QUOTED_AMT
                  ,CANCEL_REFUND_RETAIL_AMT
                  ,CANCEL_REFUND_RETAIL_TAX_AMT
                  --,CANCEL_TOTAL_CLAIMS_AMT
                  --,CANCEL_NOTE_TXT
                  --,CANCEL_STATUS_TXT
                  --,CANCEL_REASON_TXT
                  --,CANCEL_FEE_AMT
                  ,CANCEL_EFFECTIVE_DT
                  ,CANCEL_REF_NO
                  --,CANCEL_REFUND_PERCENT
                  ,CANCEL_REFUND_METHOD_CD
                  )
           VALUES (
                    crec2.UNIQUE_SEQ_NO --unique_seq_no
                    ,1 --source_system_cd
                    ,crec2.contract_no --contract_xid
                    ,crec2.contract_no --client_contract_no
                    ,'CNCL' --contract_status_xid
                    ,''--contract_sale_dt
                    ,'' --contract_start_dt
                    ,'' --contract_end_dt
                    ,'' --retail_amt
                    ,crec2.contract_no --order_xid
                    ,'' --sku
                    ,'' --si_xid
                    ,'' --register_by
                    ,'' --register_dt
                    ,'' --outlet_xid
                    ,'READY' --process_status_tx
                    ,1 --order_line_id
                    ,v_audit_key --insert_audit_key
                    ,to_date(crec2.cancel_process_dt,'YYYYMMDD') --insert_dt
                    ,to_date(crec2.cancel_process_dt,'YYYYMMDD') --effective_dt
                    ,'' --address_type
                    ,'' --CANCEL_BY
                    ,to_date(crec2.cancel_process_dt,'YYYYMMDD') --CANCEL_DT
                  --,crec2.customer_refund --CANCEL_REFUND_QUOTED_AMT
                  ,'' --CANCEL_REFUND_RETAIL_AMT
                  ,''--CANCEL_REFUND_RETAIL_TAX_AMT
                  --,''--CANCEL_TOTAL_CLAIMS_AMT
                  --,crec2.cancel_type_cd --CANCEL_NOTE_TXT
                  --,'CNCL'--CANCEL_STATUS_TXT
                  --,crec2.cancel_type_cd --CANCEL_REASON_TXT
                  --,crec2.CANCEL_FEE_AMT
                  ,to_date(crec2.CANCEL_EFFECTIVE_DT,'YYYYMMDD')
                  ,crec2.contract_no --CANCEL_REF_NO
                  --,crec2.refund_pct --CANCEL_REFUND_PERCENT
                  ,'' --CANCEL_REFUND_METHOD_CD
                  );

        END LOOP;

        COMMIT;

   END;

END pkg_contract_data;
/

