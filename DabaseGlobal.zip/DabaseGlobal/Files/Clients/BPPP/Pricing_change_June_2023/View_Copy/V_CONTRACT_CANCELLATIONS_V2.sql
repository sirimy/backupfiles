create view V_CONTRACT_CANCELLATIONS_V2 as
SELECT UNDERWRITER,
          SALES_CHANNEL,
          PAYMENT_MODE,
          DEALER_NO,
          CONTRACT_NO,
          FIRST_NM,
          FIRM_NM,
          LAST_NM,
          CONTRACT_SALE_DT,
          CANCEL_PROCESS_DATE,
          CANCEL_EFFECTIVE_DT,
          REFUND_PERCENT,
          CANCEL_TYPE,
          MSRP,
          RETAIL_PRICE,
          Dealer_Cost,                                     --Abhay to populate
          Dealer_Refund,
          SIC_Cost,                                        --Abhay to populate
          --calculation equals
          CASE
             WHEN contract_created_dt <= DATE '2015-01-24' THEN dealer_refund
             ELSE ROUND (SIC_Cost * refund_percent, 3) --contract sale date >01/25/15
          END
             AS SIC_Refund,
          --
          Underwriter_Reserve,
          AMT_Premium,
          Amount_Received,
          Payments_Allocated_To_Premier,
          TOTAL_CLAIM_PAID,
          CANCEL_FEE,
          REFUND_ADVANCED,
          UNDERWRITER_FEE,
          UNDERWRITER_Tax,
          DEALER_RESIDES_IN,
          HULL_SERIAL_NO,
          MOTOR_SERIAL_NO,
          trailer_serial_no,
          financial_month,
          Coverage,
          month,
          OBLIGOR_FEE
     --
     --,contract_created_dt AS process_dt
     --
     FROM (SELECT uw.name AS Underwriter,
                  --csct.name AS Sales_Channel,
                  CASE
                     WHEN olkp.outlet_xid = '28106' THEN 'AFTERMARKET'
                     WHEN pol.EFFECTIVE_DT < date '2021-08-01' then csct.name
                     WHEN pol.EFFECTIVE_DT >= date '2021-08-01' and upper(pol.NAME) like '%AFTERMARKET%' THEN 'AFTERMARKET'    --BASSAPP-686
                     WHEN pol.EFFECTIVE_DT >= date '2021-08-01' and upper(pol.NAME) not like '%AFTERMARKET%' THEN 'POS'        --BASSAPP-686
                     ELSE csct.name
                  END
                     AS Sales_Channel,
                  cptd.name AS Payment_Mode,
                  olkp.outlet_xid AS dealer_no,
                  clkp.contract_xid AS contract_no,
                  adr.first_nm,
                  adr.firm_nm,
                  adr.last_nm,
                  con.contract_sale_dt,
                  can.Cancel_Dt AS Cancel_Process_Date,
                  can.Cancel_Effective_Dt,
                  ---
                  can_obj.Refund_Percent AS Refund_Percent,
                  ---
                  can_obj.CANCEL_BY AS Cancel_Type,
                  con_fee.msrp,
                  con.retail_amt AS Retail_Price,
                  ---
                  con_fee.dealer_cost AS Dealer_Cost,      --Abhay to populate
                  ---
                  ROUND (con_fee.dealer_cost * can_obj.Refund_Percent, 3)
                     AS Dealer_Refund, --Victor is calculating Dealer Refund in report as well
                  ---
                  con_fee.sic_cost AS SIC_Cost,            --Abhay to populate
                  con_fee.RESERVE AS Underwriter_Reserve,
                  ---
                  CASE
                     WHEN pol.effective_dt = DATE '2009-01-01'
                     THEN
                        con_fee.dealer_cost
                     WHEN     pol.effective_dt = DATE '2012-10-16'
                          AND csct.name = 'POS'
                     THEN
                        con_fee.dealer_cost
                     WHEN     pol.effective_dt = DATE '2012-10-16'
                          AND csct.name = 'AFTERMARKET'
                     THEN
                        ROUND (
                           (con_fee.RESERVE + con_fee.TAX + con_fee.UNDERWRITER_FEE),
                           3)
                      WHEN     pol.effective_dt > DATE '2012-10-16' and pol.effective_dt <= date '2022-05-31'
                     THEN
                        ROUND (
                           (con_fee.RESERVE + con_fee.TAX + con_fee.UNDERWRITER_FEE),
                           3)
                     WHEN     pol.effective_dt >= date '2022-06-01'
                     THEN
                        ROUND (
                           (con_fee.RESERVE + con_fee.TAX + con_fee.UNDERWRITER_FEE + con_fee.OBLIGOR_FEE),
                           3)
                     ELSE
                        ROUND (
                           (con_fee.RESERVE + con_fee.TAX + con_fee.UNDERWRITER_FEE),
                           3)
                  END
                     AS AMT_Premium,                        --Grosss Premium
                  ---
                  0 AS Amount_Received,   --NULL
                  0 AS Payments_Allocated_To_Premier,  --NULL
                  ---
                  --can.CONTRACT_REFUND_AMT AS "Gross Refund", --AMT Premium * refund %
                  ---
                  NVL (cl.claim_paid_amt, 0) AS TOTAL_CLAIM_PAID, --can_obj.TOTAL_CLAIMs_Amt
                  can_obj.Cancel_Fee_Amt AS Cancel_Fee,
                    ---
                    can.CONTRACT_REFUND_AMT
                  - NVL (cl.claim_paid_amt, 0) --NVL (can_obj.TOTAL_CLAIMs_Amt, 0)
                  - NVL (can_obj.Cancel_Fee_Amt, 0)
                     AS Refund_Advanced,
                  ---
                  con_fee.UNDERWRITER_FEE,
                  --ROUND (UNDERWRITER_FEE * can_obj.Refund_Percent, 2) AS "FEE_RREFUND%",  --Commented out by AJ on 10/19/2015
                  con_fee.Tax AS UNDERWRITER_TAX,
                  con.retail_tax_amt AS contract_Sales_tax,
                  --ROUND (con.retail_tax_amt * can_obj.Refund_Percent, 2) AS "TAX_REFUND%",   --Commented out by AJ on 10/19/2015
                  NULL AS Loss_Reserves, --Nikki asked to remove Loss_Reserves          --SIC Reserve = (consumer retail * 60%) minus AMT fee
                  NULL AS Loss_Reserves_Chargeback, --Nikki asked to remove Loss_Reserves_Chargeback    --SIC Reserve * refund %
                  ---
                  slkp.code AS Dealer_Resides_In,
                  boat.hull_serial_no,
                  motor.motor_serial_no,
                  trailer.trailer_serial_no,
                  ---
                  con.contract_created_dt,
                  cal.fin_calendar_month AS financial_month,
                  pol.name AS Coverage,
                  tr.month,
                  con_fee.OBLIGOR_FEE AS OBLIGOR_FEE
             --
             FROM BPPP.CONTRACT_DIM con
                  JOIN BPPP.CONTRACT_cancellation_DIM can
                     ON (can.contract_key = con.contract_key)
                  JOIN BPPP.POLICY_TBL pol USING (POLICY_KEY)
                  JOIN BPPP.UNDERWRITER_TBL UW USING (UNDERWRITER_KEY)
                  JOIN BPPP.CONTRACT_SALES_CHANNEL_TBL CSCT
                     USING (CONTRACT_SALES_CHANNEL_KEY)
                  LEFT JOIN
                  BPPP.OUTLET_LKP olkp
                     ON (    olkp.OUTLET_KEY = CON.OUTLET_KEY
                         AND olkp.source_system_cd = 1)
                  JOIN
                  BPPP.CONTRACT_LKP clkp
                     ON (    clkp.CONTRACT_KEY = con.CONTRACT_KEY
                         AND clkp.source_system_cd = 0)
                  LEFT JOIN BPPP.ADDRESS_DIM adr USING (ADDRESS_KEY)
                  JOIN bppp.TERM_DIM tr USING (TERM_KEY)
                  ---
                  JOIN bppp.V_CONTRACT_FEE_XREF con_fee
                     ON (con_fee.contract_key = con.contract_key)
                  ---
                  LEFT JOIN BPPP.OUTLET_DIM od
                     ON (od.outlet_key = con.outlet_key)
                  LEFT JOIN BPPP.STATE_LKP slkp
                     ON (slkp.STATE_KEY = od.state_key)
                  JOIN BPPP.CONTRACT_PAYMENT_TYPE_DIM CPTD
                     USING (CONTRACT_PAYMENT_TYPE_KEY)
                  LEFT JOIN
                  (SELECT SI.SERIAL_NO AS hull_serial_no, contract_key
                     FROM BPPP.CONTRACT_COVERAGE_XREF CCX
                          JOIN BPPP.SERIALIZED_ITEM_DIM SI USING (SI_KEY)
                          JOIN BPPP.V_PRODUCT VPR USING (PRODUCT_KEY)
                    WHERE     NVL (PARENT_CATEGORY_NM, PRODUCT_CATEGORY_NM) =
                                 'BOAT'
                          AND coverage_type_key = 2) boat
                     ON (boat.contract_key = con.contract_key)
                  LEFT JOIN
                  (SELECT SI.SERIAL_NO motor_serial_no, contract_key, hp
                     FROM BPPP.CONTRACT_COVERAGE_XREF CCX
                          JOIN BPPP.SERIALIZED_ITEM_DIM SI USING (SI_KEY)
                          JOIN BPPP.V_PRODUCT VPR USING (PRODUCT_KEY)
                    WHERE     NVL (PARENT_CATEGORY_NM, PRODUCT_CATEGORY_NM) =
                                 'MOTOR'
                          AND coverage_type_key = 2) motor
                     ON (motor.contract_key = con.contract_key)
                  LEFT JOIN
                  (SELECT SI.SERIAL_NO AS trailer_serial_no, contract_key
                     FROM BPPP.CONTRACT_COVERAGE_XREF CCX
                          JOIN BPPP.SERIALIZED_ITEM_DIM SI USING (SI_KEY)
                          JOIN BPPP.V_PRODUCT VPR USING (PRODUCT_KEY)
                    WHERE     NVL (PARENT_CATEGORY_NM, PRODUCT_CATEGORY_NM) =
                                 'TRAILER'
                          AND coverage_type_key = 2) trailer
                     ON (trailer.contract_key = con.contract_key)
                  ---
                  LEFT JOIN
                  (SELECT can_obj.contract_key,
                          CASE
                             WHEN         --can_obj.QUOTE_DAY_OF_OWNERSHIP = 1
                                 LOWER (can_obj.quote_is_full_fund) = 'true'
                             THEN
                                1
                             ELSE
                                ROUND (can_obj.Refund_Percent, 3)
                          END
                             AS Refund_Percent,
                          can_obj.CANCEL_BY,
                          ----
                          CASE
                             WHEN LOWER (
                                     can_obj.QUOTE_WAIVE_CANCELLATION_FEE) =
                                     'true'
                             THEN
                                0
                             ELSE
                                can_obj.Cancel_Fee_Amt
                          END
                             AS Cancel_Fee_Amt,
                          can_obj.QUOTE_WAIVE_CANCELLATION_FEE
                     ----
                     FROM bppp.v_cancellation_quote_obj can_obj) can_obj
                     ON (can_obj.contract_key = can.contract_key)
                  ---
                  LEFT JOIN
                  (  SELECT cl.contract_key,
                            SUM (cod.paid_amt) AS claim_paid_amt
                       FROM bppp.claim_order_dim cod
                            JOIN bppp.claim_dim cl USING (claim_key)
                   GROUP BY cl.contract_key) cl
                     ON (can_obj.contract_key = cl.contract_key)
                  ---
                  LEFT JOIN
                  bppp.financial_accounting_calendar CAL
                     ON (can.CANCEL_DT BETWEEN cal.MONTH_START_DATE
                                           AND cal.MONTH_END_DATE))
/

