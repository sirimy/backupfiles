create view V_CONTRACT_ANA as
SELECT con.CONTRACT_KEY,
          clkp.contract_xid AS contract_no,
          ---
          CASE
             WHEN pol.effective_dt = DATE '2009-01-01'
             THEN                                            --All VG policies
                pol_fee.dealer_cost

             WHEN     pol.effective_dt = DATE '2012-10-16'
                  AND CSCT.name = 'POS'
                  AND pol.New_Used_Ind = 'Y'
             THEN                                               --New policies
                pol_fee.dealer_cost

             WHEN     pol.effective_dt = DATE '2012-10-16'
                  AND CSCT.name = 'POS'
                  AND pol.New_Used_Ind = 'N'
             THEN                                              --Used policies
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE

             WHEN     pol.effective_dt = DATE '2012-10-16'
                  AND CSCT.name = 'AFTERMARKET'
             THEN
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE

             WHEN pol.effective_dt >= DATE '2015-01-25' and pol.effective_dt <= DATE '2022-05-31'
             THEN
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE

             WHEN pol.effective_dt >= DATE '2022-06-01'
             THEN
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE
                + coalesce(pol_fee.OBLIGOR_FEE, 0)
          END
             --UNDERWRITER_RESERVE + UNDERWRITER_FEE + UNDERWRITER_TAX
             AS GROSS_WRITTEN_PREMIUM,
          ---
          underwriter_reserve,
          pol_fee.dealer_cost,
          ---
          CASE
             WHEN --NVL (TO_DATE (RH.process_Dt, 'YYYYMMDD'), a.creation_dt) >=
                 con.contract_created_dt >= DATE '2015-01-25' and con.contract_created_dt  <= DATE '2022-05-31'
             THEN
                --pol_fee.SIC_RESERVE   --we don't have SIC_RESERVE loaded in DB
                pol_fee.SIC_COST - UNDERWRITER_FEE - UNDERWRITER_TAX --pol_fee.msrp * .6    Change requested by Nikki on 10/20/2015

             WHEN con.contract_created_dt >= DATE '2022-06-01'
             THEN
              pol_fee.UNDERWRITER_RESERVE
             ELSE
                NULL
          END
             AS SIC_RESERVE,
          ---
          CASE
             WHEN --NVL (TO_DATE (RH.process_Dt, 'YYYYMMDD'), a.creation_dt) >= DATE '2015-01-25'
                 con.contract_created_dt >= DATE '2015-01-25' and con.contract_created_dt  <= DATE '2022-05-31'
             THEN
                pol_fee.SIC_COST --Change requested by Nikki on 10/20/2015   --msrp * .6

             WHEN con.contract_created_dt >= DATE '2022-06-01'
             THEN
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE
                + coalesce(pol_fee.OBLIGOR_FEE, 0)
             ELSE
                NULL
          END
             AS SIC_COST,                              --Changed on 10/19/2015
          ---
          con.contract_start_dt,
          con.CONTRACT_END_DT,
          con.contract_sale_dt,
          ---
          pol.name AS Coverage,
          tr.month AS Term,
          CASE WHEN csd.name = 'CNCL' THEN 'Y' END AS contract_cancel_ind,
          TRUNC (can.cancel_dt) AS Contract_cancel_dt,
          ---
          CASE
             WHEN UPPER (TRIM (rc.product_type_cd)) IN
                     ('FIBERGLASS', 'ALUMINUM / PONTOON', 'ALUMINUM')
             THEN
                rc.product_type_cd
             WHEN UPPER (TRIM (RW.BUCKET_NM)) IN
                     ('FIBERGLASS', 'ALUMINUM / PONTOON', 'ALUMINUM')
             THEN
                RW.BUCKET_NM
             WHEN UPPER (boat.boat_product) IN
                     ('FIBERGLASS', 'ALUMINUM / PONTOON', 'ALUMINUM')
             THEN
                boat.boat_product
          END
             AS Boat_Material_Type,
          ---
          TRUNC (boat.WARRANTY_EXPIRATION_DT) AS boat_WARRANTY_EXPIRATION_DT, --QA columns
          ---
          ---
          CASE
             WHEN UPPER (TRIM (rc.product_type_cd)) IN
                     ('2-STROKE', '4-STROKE', 'DFI', 'MERCRUISER', 'V-6')
             THEN
                UPPER (TRIM (rc.product_type_cd))
             WHEN UPPER (RW.BUCKET_NM) IN
                     ('2-STROKE', '4-STROKE', 'DFI', 'MERCRUISER', 'V-6')
             THEN
                UPPER (RW.BUCKET_NM)
             WHEN UPPER (motor.motor_product) IN
                     ('2-STROKE', '4-STROKE', 'DFI', 'MERCRUISER', 'V-6')
             THEN
                UPPER (motor.motor_product)
             WHEN NVL (
                     BPPPSTG.fn_get_product_category (
                        p_model_nm => NVL (RW.engine1_model_nm,
                                           motor.engine_model_no)),
                     'XYZ') IN
                     ('2-STROKE', '4-STROKE', 'DFI', 'MERCRUISER', 'V-6')
             THEN
                BPPPSTG.fn_get_product_category (
                   p_model_nm => NVL (TRIM (RW.engine1_model_nm),
                                      motor.engine_model_no))
             WHEN NVL (
                     BPPPSTG.fn_get_product_category (
                        p_model_nm => rc.product_type_cd),
                     'XYZ') IN
                     ('2-STROKE', '4-STROKE', 'DFI', 'MERCRUISER', 'V-6')
             THEN
                BPPPSTG.fn_get_product_category (
                   p_model_nm => rc.product_type_cd)
          END
             AS Engine_Type,
          ---
          UPPER (NVL (TRIM (RW.engine1_model_nm), motor.engine_model_no))
             AS engine_model_no,
          motor.hp,
          TRUNC (motor.WARRANTY_EXPIRATION_DT)
             AS motor_WARRANTY_EXPIRATION_DT,                     --QA columns
          pol.new_used_ind,
          con.contract_created_dt AS process_Dt,
          con.retail_amt AS Customer_Pay_Amt,
          pol_fee.MSRP,
          OUT_STATE.POSTAL_STATE_CD AS DEALER_STATE,
          motor.engine_brand_nm,
          con.outlet_key, out_state.Outlet_Nm
     ---
     --underwriter_fee,
     --underwriter_tax
     ---
     FROM BPPP.CONTRACT_DIM con
          LEFT JOIN BPPP.CONTRACT_cancellation_DIM can
             ON (can.contract_key = con.contract_key)
          JOIN BPPP.POLICY_TBL pol USING (POLICY_KEY)
          JOIN BPPP.CONTRACT_SALES_CHANNEL_TBL CSCT
             USING (CONTRACT_SALES_CHANNEL_KEY)
          LEFT JOIN bppp.CONTRACT_STATUS_DIM csd USING (CONTRACT_STATUS_KEY)
          ---
          LEFT JOIN
          (SELECT OD.OUTLET_KEY, SL.POSTAL_STATE_KEY, SL.POSTAL_STATE_CD, OD.Outlet_Nm
             FROM BPPP.OUTLET_DIM OD
                  JOIN BPPP.POSTAL_STATE_DIM SL
                     ON (OD.STATE_KEY = SL.POSTAL_STATE_KEY)) OUT_STATE
             ON (OUT_STATE.OUTLET_KEY = CON.OUTLET_KEY)
          --
          JOIN
          BPPP.CONTRACT_LKP clkp
             ON (    clkp.CONTRACT_KEY = con.CONTRACT_KEY
                 AND clkp.source_system_cd = 0)
          ---
          LEFT JOIN bppp.TERM_DIM tr USING (TERM_KEY)
          --
          LEFT JOIN bppp.v_policy_fee pol_fee USING (policy_key)
          --
          LEFT JOIN
          (SELECT *
             FROM (SELECT a.*,
                          ROW_NUMBER ()
                          OVER (
                             PARTITION BY a.contract_no
                             ORDER BY
                                GREATEST (insert_audit_key,
                                          NVL (update_audit_key, -1)) DESC,
                                file_nm DESC)
                             rc_rno
                     FROM bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
            WHERE rc_rno = 1) RC
             ON (RC.CONTRACT_NO = clkp.contract_xid)
          LEFT JOIN
          (SELECT *
             FROM (SELECT a.*,
                          ROW_NUMBER ()
                          OVER (
                             PARTITION BY a.contract_no
                             ORDER BY
                                GREATEST (insert_audit_key,
                                          NVL (update_audit_key, -1)) DESC,
                                billing_hull_unique_seq_no DESC,
                                billing_engine1_unique_seq_no DESC,
                                file_nm DESC)
                             rw_rno
                     FROM bppp.RAW_CONTRACT_watercraft_TBL a)
            WHERE rw_rno = 1) RW
             ON (RW.CONTRACT_NO = clkp.contract_xid)
          ----
          LEFT JOIN
          (SELECT SI.SERIAL_NO AS hull_serial_no,
                  contract_key,
                  si.WARRANTY_EXPIRATION_DT,
                  NVL (vpr.PRODUCT_CATEGORY_NM, vpr.product_nm)
                     AS boat_product
             FROM BPPP.CONTRACT_COVERAGE_XREF CCX
                  JOIN BPPP.SERIALIZED_ITEM_DIM SI USING (SI_KEY)
                  JOIN BPPP.V_PRODUCT VPR USING (PRODUCT_KEY)
            WHERE     NVL (PARENT_CATEGORY_NM, PRODUCT_CATEGORY_NM) = 'BOAT'
                  AND coverage_type_key = 2) boat
             ON (boat.contract_key = con.contract_key)
          ----
          LEFT JOIN
          (SELECT SI.SERIAL_NO motor_serial_no,
                  contract_key,
                  hp,
                  si.WARRANTY_EXPIRATION_DT,
                  NVL (vpr.PRODUCT_CATEGORY_NM, vpr.product_nm)
                     AS motor_product,
                  vpr.model_no AS engine_model_no,
                  vpr.brand_nm AS engine_brand_nm
             FROM BPPP.CONTRACT_COVERAGE_XREF CCX
                  JOIN BPPP.SERIALIZED_ITEM_DIM SI USING (SI_KEY)
                  JOIN BPPP.V_PRODUCT VPR USING (PRODUCT_KEY)
            WHERE     NVL (PARENT_CATEGORY_NM, PRODUCT_CATEGORY_NM) = 'MOTOR'
                  AND coverage_type_key = 2
                  AND si.serial_no NOT IN
                         (SELECT TRIM (rw2.engine2_serial_no)
                            FROM bppp.RAW_CONTRACT_watercraft_TBL RW2
                           WHERE TRIM (rw2.engine2_serial_no) IS NOT NULL)) motor
             ON (motor.contract_key = con.contract_key)
    WHERE 1 = 1
/

