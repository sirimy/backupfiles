create view V_CONTRACT_SALES_DETAILS as
SELECT DISTINCT
          uw.name AS Underwriter,
          CASE
             WHEN olkp.outlet_xid = '28106' THEN 'AFTERMARKET'
             WHEN pol.EFFECTIVE_DT < date '2021-08-01' then csct.name
             WHEN pol.EFFECTIVE_DT >= date '2021-08-01' and upper(pol.NAME) like '%AFTERMARKET%' THEN 'AFTERMARKET'    --BASSAPP-686
             WHEN pol.EFFECTIVE_DT >= date '2021-08-01' and upper(pol.NAME) not like '%AFTERMARKET%' THEN 'POS'        --BASSAPP-686
             ELSE csct.name
          END
             AS Sales_Channel,
          cptd.name AS Payment_Mode,
          olkp.outlet_xid AS dealer_no,
          clkp.contract_xid AS contract_no,
          adr.first_nm,
          adr.firm_nm,
          adr.last_nm,
          con.contract_start_dt,
          con.contract_sale_dt,
          --TO_DATE (RH.process_Dt, 'YYYYMMDD') AS process_Dt,
          con.contract_created_dt AS process_Dt,
          motor.hp,
          pol.new_used_ind,
          tr.month,
          pol.name AS Coverage,
          pol_fee.msrp,
          con.retail_amt AS Retail_Price,
          ---
          CASE
             WHEN pol.effective_dt = DATE '2009-01-01'
             THEN                                              --All VG policies
                pol_fee.dealer_cost
             WHEN     pol.effective_dt = DATE '2012-10-16'
                  AND CSCT.name = 'POS'
                  AND pol.New_Used_Ind = 'Y'
             THEN                                              --New policies
                pol_fee.dealer_cost
             WHEN     pol.effective_dt = DATE '2012-10-16'
                  AND CSCT.name = 'POS'
                  AND pol.New_Used_Ind = 'N'
             THEN                                              --Used policies
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE
             WHEN     pol.effective_dt = DATE '2012-10-16'
                  AND CSCT.name = 'AFTERMARKET'
             THEN
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE
             WHEN pol.effective_dt >= DATE '2015-01-25' and pol.effective_dt <= DATE '2022-05-31'
             THEN
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE
             WHEN pol.effective_dt >= DATE '2022-06-01'
             THEN
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE
                + coalesce(pol_fee.OBLIGOR_FEE, 0)
          END
             --UNDERWRITER_RESERVE + UNDERWRITER_FEE + UNDERWRITER_TAX
             AS GROSS_WRITTEN_PREMIUM,
          ---
          underwriter_reserve,
          underwriter_fee,
          underwriter_tax,
          ---
          CASE
             WHEN --NVL (TO_DATE (RH.process_Dt, 'YYYYMMDD'), a.creation_dt) >= DATE '2015-01-25'
                 con.contract_created_dt >= DATE '2015-01-25' and con.contract_created_dt  <= DATE '2022-05-31'
             THEN
                pol_fee.SIC_COST --Change requested by Nikki on 10/20/2015   --msrp * .6
             WHEN con.contract_created_dt >= DATE '2022-06-01'
             THEN
                  pol_fee.UNDERWRITER_RESERVE
                + pol_fee.UNDERWRITER_TAX
                + pol_fee.UNDERWRITER_FEE
                + coalesce(pol_fee.OBLIGOR_FEE, 0)         --8/5/2022 --BASS-1007: SIC_COST = UNDERWRITER PREMIUM
             ELSE
                NULL
          END
             AS SIC_COST,                              --Changed on 10/19/2015
          ---
          CASE
             WHEN
                 con.contract_created_dt >= DATE '2015-01-25' and con.contract_created_dt  <= DATE '2022-05-31'
             THEN
                --pol_fee.SIC_RESERVE   --we don't have SIC_RESERVE loaded in DB
                pol_fee.SIC_COST - UNDERWRITER_FEE - UNDERWRITER_TAX --pol_fee.msrp * .6    Change requested by Nikki on 10/20/2015
             WHEN con.contract_created_dt >= DATE '2022-06-01'
             THEN
              pol_fee.UNDERWRITER_RESERVE                 --8/5/2022  --BASS-1027: SIC_reserve  = underwriter reserve
             ELSE
                NULL
          END
             AS SIC_RESERVE,
          ---
          slkp.code AS Dealer_Resides_In,
          boat.hull_serial_no,
          motor.motor_serial_no,
          trailer.Trailer_serial_no,
          NVL (rc.product_type_cd, motor.motor_product) AS product_type_cd --QA columns
                                                                          ,
          TRUNC (boat.WARRANTY_EXPIRATION_DT) AS boat_WARRANTY_EXPIRATION_DT, --QA columns
          TRUNC (motor.WARRANTY_EXPIRATION_DT)
             AS motor_WARRANTY_EXPIRATION_DT,                     --QA columns
          TRUNC (Trailer.WARRANTY_EXPIRATION_DT)
             AS trailer_WARRANTY_EXPIRATION_DT,
          RW.UNIT_CD,
          RW.BUCKET_NM,                                           --QA columns
          con.CONTRACT_END_DT,
          --a.creation_dt,
          csd.name AS Contract_Status,
          pol_fee.policy_cost AS Total_Cost,
          cal.Sale_financial_month as financial_month,
          pol_fee.obligor_fee
     ----
     FROM BPPP.CONTRACT_DIM con
          JOIN BPPP.POLICY_TBL pol USING (POLICY_KEY)
          JOIN BPPP.UNDERWRITER_TBL UW USING (UNDERWRITER_KEY)
          JOIN BPPP.CONTRACT_SALES_CHANNEL_TBL CSCT
             USING (CONTRACT_SALES_CHANNEL_KEY)
          LEFT JOIN bppp.CONTRACT_STATUS_DIM csd USING (CONTRACT_STATUS_KEY)
          ---
          LEFT JOIN
          BPPP.OUTLET_LKP olkp
             ON (    olkp.OUTLET_KEY = CON.OUTLET_KEY
                 AND olkp.source_system_cd = 0)             --AppOne dealer no
          ---
          JOIN
          BPPP.CONTRACT_LKP clkp
             ON (    clkp.CONTRACT_KEY = con.CONTRACT_KEY
                 AND clkp.source_system_cd = 0)
          ---
          LEFT JOIN BPPP.ADDRESS_DIM adr USING (ADDRESS_KEY)
          LEFT JOIN bppp.TERM_DIM tr USING (TERM_KEY)
          --
          LEFT JOIN bppp.v_policy_fee pol_fee USING (policy_key)
          --
          LEFT JOIN BPPP.OUTLET_DIM od ON (od.outlet_key = con.outlet_key)
          LEFT JOIN BPPP.STATE_LKP slkp ON (slkp.STATE_KEY = od.state_key)
          LEFT JOIN BPPP.CONTRACT_PAYMENT_TYPE_DIM CPTD
             USING (CONTRACT_PAYMENT_TYPE_KEY)
          LEFT JOIN
          (SELECT *
             FROM (SELECT a.*,
                          ROW_NUMBER ()
                          OVER (
                             PARTITION BY a.contract_no
                             ORDER BY
                                GREATEST (insert_audit_key,
                                          NVL (update_audit_key, -1)) DESC,
                                file_nm DESC)
                             rc_rno
                     FROM bppp.RAW_CONTRACT_COVERAGE_TBL a) RC
            WHERE rc_rno = 1) RC
             ON (RC.CONTRACT_NO = clkp.contract_xid)
          LEFT JOIN
          (SELECT *
             FROM (SELECT a.*,
                          ROW_NUMBER ()
                          OVER (
                             PARTITION BY a.contract_no
                             ORDER BY
                                GREATEST (insert_audit_key,
                                          NVL (update_audit_key, -1)) DESC,
                                billing_hull_unique_seq_no DESC,
                                billing_engine1_unique_seq_no DESC,
                                file_nm DESC)
                             rw_rno
                     FROM bppp.RAW_CONTRACT_watercraft_TBL a)
            WHERE rw_rno = 1) RW
             ON (RW.CONTRACT_NO = clkp.contract_xid)
          ----
          LEFT JOIN
          (SELECT SI.SERIAL_NO AS hull_serial_no,
                  contract_key,
                  si.WARRANTY_EXPIRATION_DT
             FROM BPPP.CONTRACT_COVERAGE_XREF CCX
                  JOIN BPPP.SERIALIZED_ITEM_DIM SI USING (SI_KEY)
                  JOIN BPPP.V_PRODUCT VPR USING (PRODUCT_KEY)
            WHERE     NVL (PARENT_CATEGORY_NM, PRODUCT_CATEGORY_NM) = 'BOAT'
                  AND coverage_type_key = 2) boat
             ON (boat.contract_key = con.contract_key)
          ----
          LEFT JOIN
          (SELECT SI.SERIAL_NO motor_serial_no,
                  contract_key,
                  hp,
                  si.WARRANTY_EXPIRATION_DT,
                  NVL (vpr.PRODUCT_CATEGORY_NM, vpr.product_nm)
                     AS motor_product
             FROM BPPP.CONTRACT_COVERAGE_XREF CCX
                  JOIN BPPP.SERIALIZED_ITEM_DIM SI USING (SI_KEY)
                  JOIN BPPP.V_PRODUCT VPR USING (PRODUCT_KEY)
            WHERE     NVL (PARENT_CATEGORY_NM, PRODUCT_CATEGORY_NM) = 'MOTOR'
                  AND coverage_type_key = 2
                  AND si.serial_no NOT IN
                         (SELECT TRIM (rw2.engine2_serial_no)
                            FROM bppp.RAW_CONTRACT_watercraft_TBL RW2
                           WHERE TRIM (rw2.engine2_serial_no) IS NOT NULL)) motor
             ON (motor.contract_key = con.contract_key)
          ----
          LEFT JOIN
          (SELECT SI.SERIAL_NO AS Trailer_serial_no,
                  contract_key,
                  si.WARRANTY_EXPIRATION_DT
             FROM BPPP.CONTRACT_COVERAGE_XREF CCX
                  JOIN BPPP.SERIALIZED_ITEM_DIM SI USING (SI_KEY)
                  JOIN BPPP.V_PRODUCT VPR USING (PRODUCT_KEY)
            WHERE     NVL (PARENT_CATEGORY_NM, PRODUCT_CATEGORY_NM) =
                         'TRAILER'
                  AND coverage_type_key = 2) trailer
             ON (trailer.contract_key = con.contract_key)

          LEFT JOIN
               bppp.MV_CONTRACT_FINANCIAL_MONTH CAL
             ON (con.contract_key = cal.contract_key)
    WHERE 1 = 1
/

