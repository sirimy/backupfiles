
select * from PPP_PRICING_2023_07_JUNE order by SLNO desc;

select count(*) from PPP_PRICING_2023_07_JUNE;--158
select count(*) from raw_pricing;
-- insert into raw_pricing
--  Select  CHANNEL,NAME,PRODUCT_CAT_DESC,TERM,MIN_HP,MAX_HP,MSRP,
--     SIC_COST,UNDERWRITER_RESERVE,UNDERWRITER_FEE,UNDERWRITER_TAX,OBLIGOR_FEE,NULL,
--     0,0,0,0,(MSRP * 0.74) AS Dealer_Cost,NULL,0,0,0,0,'PPP_PRICING_2023_07_JUNE',0, AFTER_POLICY_KEY
-- from PPP_PRICING_2023_07_JUNE;
select * from raw_pricing;
select SIC_COST,AMT_FEE,AMT_RESERVE,CONSUMER_RETAIL,DEALER_COST from raw_pricing;
-- delete from raw_policy_data_tbl;
select COUNT(*) from raw_policy_data_tbl;--182
Select COUNT(*) from policy_type_tbl;--32
select COUNT(*) FROM policy_lkp;--182
select COUNT(*) FROM policy_tbl;--182
select COUNT(*) FROM policy_ext_tbl;--182
select COUNT(*) FROM policy_lkp;--364
-- DELETE FROM Policy_Plan_Component_Xref;
select COUNT(*) FROM Policy_Plan_Component_Xref;--114
select distinct UNDERWRITER_KEY FROM Policy_Plan_Component_Xref;--114
select COUNT(*) from t_and_c_contract_template_xref;--9828
select COUNT(*) from   policy_fee_xref;--2184
-- select COUNT(*) FROM POLICY_ITEM_TBL;--240
-- select COUNT(*) FROM POLICY_COVERAGE_TBL;--480
-- select COUNT(*) FROM COVERAGE_PARTS_GROUP_XREF;--3744
select COUNT(*) FROM POLICY_ITEM_TBL;--726
select COUNT(*) FROM POLICY_COVERAGE_TBL;--1452
select COUNT(*) FROM COVERAGE_PARTS_GROUP_XREF;--11092
select COUNT(*) FROM POLICY_ITEM_SELECTION_TBL;--757452

select effective_dt, exp_dt, count(*) from bppp.policy_tbl where exp_dt >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, exp_dt order by effective_dt, exp_dt;
+------------+----------+--------+
|EFFECTIVE_DT|EXP_DT    |COUNT(*)|
+------------+----------+--------+
|2022-06-01  |2099-12-31|170     |
+------------+----------+--------+

select effective_dt, END_DT, count(*) from bppp.t_and_c_contract_template_xref where END_DT >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, END_DT order by effective_dt, END_DT;
+------------+----------+--------+
|EFFECTIVE_DT|END_DT    |COUNT(*)|
+------------+----------+--------+
|2015-01-25  |2099-12-31|15423   |
|2016-05-01  |2099-12-31|318     |
|2016-06-01  |2099-12-31|1402    |
|2018-07-01  |2099-12-31|15712   |
|2021-08-01  |2099-12-31|12852   |
|2022-06-01  |2099-12-31|9180    |
+------------+----------+--------+

select effective_dt, END_DT, count(*) from bppp.policy_fee_xref where END_DT >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, END_DT order by effective_dt, END_DT;

+--------------------------+--------------------------+--------+
|EFFECTIVE_DT              |END_DT                    |COUNT(*)|
+--------------------------+--------------------------+--------+
|2022-06-01 00:00:00.000000|2099-12-31 00:00:00.000000|2040    |
+--------------------------+--------------------------+--------+

select count(*), count(distinct POLICY_KEY), count(distinct substr(DESCRIPTION, instr(DESCRIPTION, '1'))) from POLICY_ITEM_TBL ;
+--------+-------------------------+---------------------------------------------------------+
|COUNT(*)|COUNT(DISTINCTPOLICY_KEY)|COUNT(DISTINCTSUBSTR(DESCRIPTION,INSTR(DESCRIPTION,'1')))|
+--------+-------------------------+---------------------------------------------------------+
|726     |182                      |182                                                      |
+--------+-------------------------+---------------------------------------------------------+

select count(*), count(distinct POLICY_KEY), count(distinct POLICY_ITEM_KEY) from POLICY_COVERAGE_TBL ;
+--------+-------------------------+------------------------------+
|COUNT(*)|COUNT(DISTINCTPOLICY_KEY)|COUNT(DISTINCTPOLICY_ITEM_KEY)|
+--------+-------------------------+------------------------------+
|1452    |182                      |726                           |
+--------+-------------------------+------------------------------+

select count(*), count(distinct POLICY_KEY), count(distinct POLICY_ITEM_KEY), count(distinct PARTS_GROUP_KEY) from COVERAGE_PARTS_GROUP_XREF;

+--------+-------------------------+------------------------------+------------------------------+
|COUNT(*)|COUNT(DISTINCTPOLICY_KEY)|COUNT(DISTINCTPOLICY_ITEM_KEY)|COUNT(DISTINCTPARTS_GROUP_KEY)|
+--------+-------------------------+------------------------------+------------------------------+
|11092   |182                      |726                           |39                            |
+--------+-------------------------+------------------------------+------------------------------+

select count(*), count(distinct POLICY_ITEM_SELECTION_VALUE), count(distinct pis.POLICY_ITEM_KEY), count(distinct pit.POLICY_KEY) from policy_item_selection_tbl pis
left join POLICY_ITEM_TBL pit on pit.POLICY_ITEM_KEY = pis.POLICY_ITEM_KEY;

--
--
-- POLICY_FEE_TYPE
-- POLICY_GROUP
-- PARRENT_POLICY_TYPE
-- POLICY_TYPE
-- UNDERWRITER_tbl
--
-- select Distinct MODULE_NAME from SYNC_PROCESS_MAPPING_TBL where TARGET_TABLE_NAME like '%POL%'
-- +---------------------+
-- |TARGET_TABLE_NAME    |
-- +---------------------+
-- |POLICY_ITEM_SELECTION|
-- |POLICY_ITEM          |
-- |POLICY_EXT           |
-- |POLICY               |
-- |POLICY_COVERAGE      |
-- |POLICY_FEE_XREF      |
-- +---------------------+
--
-- COVERAGE_PARTS_GROUP_XREF
-- t_and_c_contract_template_xref


