select * from bppp.policy_tbl where exp_dt >= sysdate ;
--238
select effective_dt, exp_dt, count(*) from bppp.policy_tbl where exp_dt >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, exp_dt order by effective_dt, exp_dt;
/*
+------------+----------+--------+
|EFFECTIVE_DT|EXP_DT    |COUNT(*)|
+------------+----------+--------+
|2022-06-01  |2099-12-31|170     |
+------------+----------+--------+
 */

--DO NOT  de-activate t_and_c_contract_template_xref data
select * from bppp.t_and_c_contract_template_xref where end_dt >= sysdate ;
--
select effective_dt, END_DT, count(*) from bppp.t_and_c_contract_template_xref where END_DT >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, END_DT order by effective_dt, END_DT;
/*
+------------+----------+--------+
|EFFECTIVE_DT|END_DT    |COUNT(*)|
+------------+----------+--------+
|2015-01-25  |2099-12-31|15423   |
|2016-05-01  |2099-12-31|318     |
|2016-06-01  |2099-12-31|1402    |
|2018-07-01  |2099-12-31|15712   |
|2021-08-01  |2099-12-31|12852   |
|2022-06-01  |2099-12-31|9180    |
+------------+----------+--------+
 */

select * from bppp.policy_plan_component_xref where end_dt >= sysdate;
--46
select effective_dt, END_DT, count(*) from bppp.policy_plan_component_xref where END_DT >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, END_DT order by effective_dt, END_DT;

select count(*) from bppp.policy_fee_xref where end_dt >= sysdate ;
--2040
select effective_dt, END_DT, count(*) from bppp.policy_fee_xref where END_DT >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, END_DT order by effective_dt, END_DT;
/*+--------------------------+--------------------------+--------+
|EFFECTIVE_DT              |END_DT                    |COUNT(*)|
+--------------------------+--------------------------+--------+
|2022-06-01 00:00:00.000000|2099-12-31 00:00:00.000000|2040    |
+--------------------------+--------------------------+--------+
 */


declare
  v_audit_key number;
begin
  v_audit_key := bppp.get_audit_key (p_program_nm => 'Pricing', p_process_nm => 'Pricing - May 2023', p_descriptive_tx => 'DeActivating existing pricing', p_table_nm => 'Misc tables');
  DBMS_OUTPUT.put_line(v_audit_key);
  COMMIT;
end;
select * from AUDIT_TBL order by AUDIT_KEY desc;
--677861

--In prod, we would need to use 2021-07-31 instead of 2022-07-01
update bppp.policy_tbl set exp_dt = date '2023-04-29', update_audit_key = 677861
 where exp_dt >= sysdate ;  --and effective_dt <= date '2022-07-01'
-- rows

--DO NOT  deactivate t n c data as exp_t/end_dt here is used by contract_end_dt
----update bppp.t_and_c_contract_template_xref set end_dt = date '2022-07-01', update_audit_key =
---- where end_dt >= sysdate and effective_dt <= date '2022-07-01';

--this has been updated using sql "Step-7-3 De-Activate Policy_Plan_Component_Xref - Old Plans"
-- update bppp.policy_plan_component_xref set end_dt = date '2023-04-29', update_audit_key = 677861
--  where end_dt >= sysdate ;
--

update bppp.policy_fee_xref set end_dt = date '2023-04-29', update_audit_key = 677861
 where end_dt >= sysdate ;
--2380
commit;

select * from user_tab_cols where column_name like 'EFF%';
