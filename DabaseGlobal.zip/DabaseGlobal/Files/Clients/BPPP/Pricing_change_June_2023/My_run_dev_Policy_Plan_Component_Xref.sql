

--Total 46 component rows for existing pricing in prod...out of these 34 are base plan names. Rest 12 are Adders
select * from bppp.Policy_Plan_Component_Xref where END_DT >= sysdate --and PLAN_NM not like '%ADDER%'
 order by EFFECTIVE_DT desc, PLAN_NM;

--after job run 34 rows comes
select * from Policy_Plan_Component_Xref order by EFFECTIVE_DT desc, PLAN_NM, COMPONENT_NM;

select distinct PLAN_NM from Policy_Plan_Component_Xref order by PLAN_NM;--9
+--------------------------+
|PLAN_NM                   |
+--------------------------+
|AFTERMARKET - ADVANTAGE   |
|AFTERMARKET - PRO         |
|AFTERMARKET - PRO PLUS    |
|PREMIER ADVANTAGE         |
|PREMIER PRO               |
|PREMIER PRO PLUS          |
|TRACKER PROMISE (PRO PLUS)|
|USED PRO                  |
|USED PRO PLUS             |
+--------------------------+
--populate_policy_plan_component_xref.job was used to populate plan names, which exist in bppp.Policy_Plan_Component_Xref
--however, we would need to handle the newer plans manually here:
select distinct name from policy_tbl
MINUS
select distinct PLAN_NM from Policy_Plan_Component_Xref
minus
select distinct PLAN_NM from bppp.Policy_Plan_Component_Xref where END_DT > sysdate  --EFFECTIVE_DT < date '2022-07-01' and
order by 1;
--16 rows
+------------------------------------------------------+
|NAME                                                  |
+------------------------------------------------------+
|PREMIER PRO PLUS - 0_69HP - ADDER 0_139               |
|PREMIER PRO PLUS - 140_225HP - ADDER 0_139            |
|PREMIER PRO PLUS - 140_225HP - ADDER 140_225          |
|PREMIER PRO PLUS - 226_300HP - ADDER 0_139            |
|PREMIER PRO PLUS - 226_300HP - ADDER 226_300          |
|PREMIER PRO PLUS - 301_400HP - ADDER 0_139            |
|PREMIER PRO PLUS - 301_400HP - ADDER 301_400          |
|PREMIER PRO PLUS - 70_139HP - ADDER 0_139             |
|TRACKER PROMISE (PRO PLUS) - 0_69HP - ADDER 0_139     |
|TRACKER PROMISE (PRO PLUS) - 140_225HP - ADDER 0_139  |
|TRACKER PROMISE (PRO PLUS) - 140_225HP - ADDER 140_225|
|TRACKER PROMISE (PRO PLUS) - 226_300HP - ADDER 0_139  |
|TRACKER PROMISE (PRO PLUS) - 226_300HP - ADDER 226_300|
|TRACKER PROMISE (PRO PLUS) - 301_400HP - ADDER 0_139  |
|TRACKER PROMISE (PRO PLUS) - 301_400HP - ADDER 301_400|
|TRACKER PROMISE (PRO PLUS) - 70_139HP - ADDER 0_139   |
+------------------------------------------------------+
select distinct COMPONENT_NM from bppp.Policy_Plan_Component_Xref where END_DT  = date '2023-04-29';--5
+--------------+
|COMPONENT_NM  |
+--------------+
|BOAT          |
|MOTOR         |
|TROLLING MOTOR|
|TRAILER       |
|DEPTH FINDER  |
+--------------+
--16 X 5 = 80
select * from (
select distinct name from policy_tbl
MINUS
select distinct PLAN_NM from Policy_Plan_Component_Xref
minus
select distinct PLAN_NM from bppp.Policy_Plan_Component_Xref where END_DT > sysdate  --EFFECTIVE_DT < date '2022-07-01' and
              ) t
         cross join (select distinct COMPONENT_NM from bppp.Policy_Plan_Component_Xref where END_DT  = date '2023-04-29') c
order by name, COMPONENT_NM;

select * from raw_Policy_Plan_Component_Xref order by PLAN_NM, COMPONENT_NM;

--Plan names which were there in RAW_POLICY_DATA_TBL already were not loaded into raw_Policy_Plan_Component_Xref
select name from RAW_POLICY_DATA_TBL
minus
select PLAN_NM from raw_Policy_Plan_Component_Xref
order by 1;

--Every plan should have exactly  1 COMPONENT_SEQ populated and the value should be 1 only
select PLAN_NM, max(COMPONENT_SEQ), count(distinct COMPONENT_SEQ) from raw_Policy_Plan_Component_Xref
group by PLAN_NM
--having max(COMPONENT_SEQ) is null or count(distinct COMPONENT_SEQ) > 1 --this is for debugging
order by PLAN_NM;


--all plans from policy_tbl must exist in raw_Policy_Plan_Component_Xref else reload raw_Policy_Plan_Component_Xref
select distinct name from policy_tbl
MINUS
select distinct PLAN_NM from raw_Policy_Plan_Component_Xref;
--9 rows

select distinct PLAN_NM from POLICY_PLAN_COMPONENT_XREF;--9 names present in main table

insert into Policy_Plan_Component_Xref (UNDERWRITER_KEY, PLAN_NM, EFFECTIVE_DT, END_DT, COMPONENT_NM, COMPONENT_SEQ)
select 5, PLAN_NM, EFFECTIVE_DT, EXP_DT, COMPONENT_NM, COMPONENT_SEQ
 from  (
        select distinct rpx.*, pol.EFFECTIVE_DT, pol.EXP_DT from POLICY_TBL pol join raw_Policy_Plan_Component_Xref rpx on rpx.PLAN_NM = pol.NAME
        where  pol.NAME not in (select x.plan_nm from Policy_Plan_Component_Xref x)
        order by rpx.PLAN_NM, rpx.COMPONENT_NM
        );

select distinct PLAN_NM from POLICY_PLAN_COMPONENT_XREF order by PLAN_NM;--25 names present in main table
+------------------------------------------------------+
|PLAN_NM                                               |
+------------------------------------------------------+
|AFTERMARKET - ADVANTAGE                               |
|AFTERMARKET - PRO                                     |
|AFTERMARKET - PRO PLUS                                |
|PREMIER ADVANTAGE                                     |
|PREMIER PRO                                           |
|PREMIER PRO PLUS                                      |
|PREMIER PRO PLUS - 0_69HP - ADDER 0_139               |
|PREMIER PRO PLUS - 140_225HP - ADDER 0_139            |
|PREMIER PRO PLUS - 140_225HP - ADDER 140_225          |
|PREMIER PRO PLUS - 226_300HP - ADDER 0_139            |
|PREMIER PRO PLUS - 226_300HP - ADDER 226_300          |
|PREMIER PRO PLUS - 301_400HP - ADDER 0_139            |
|PREMIER PRO PLUS - 301_400HP - ADDER 301_400          |
|PREMIER PRO PLUS - 70_139HP - ADDER 0_139             |
|TRACKER PROMISE (PRO PLUS)                            |
|TRACKER PROMISE (PRO PLUS) - 0_69HP - ADDER 0_139     |
|TRACKER PROMISE (PRO PLUS) - 140_225HP - ADDER 0_139  |
|TRACKER PROMISE (PRO PLUS) - 140_225HP - ADDER 140_225|
|TRACKER PROMISE (PRO PLUS) - 226_300HP - ADDER 0_139  |
|TRACKER PROMISE (PRO PLUS) - 226_300HP - ADDER 226_300|
|TRACKER PROMISE (PRO PLUS) - 301_400HP - ADDER 0_139  |
|TRACKER PROMISE (PRO PLUS) - 301_400HP - ADDER 301_400|
|TRACKER PROMISE (PRO PLUS) - 70_139HP - ADDER 0_139   |
|USED PRO                                              |
|USED PRO PLUS                                         |
+------------------------------------------------------+

select distinct name from policy_tbl
MINUS
select distinct PLAN_NM from Policy_Plan_Component_Xref;
--no rows --good

--every PLAN_NM must have one and only one COMPONENT_SEQ
select PLAN_NM, max(COMPONENT_SEQ), count(distinct COMPONENT_SEQ) from Policy_Plan_Component_Xref
group by PLAN_NM
-- having max(COMPONENT_SEQ) is null or count(distinct COMPONENT_SEQ) > 1 --this is for debugging
order by PLAN_NM;--25

select PLAN_NM, COMPONENT_NM from Policy_Plan_Component_Xref where COMPONENT_SEQ is not null order by PLAN_NM;

-------======Step 3 rd start from here ========-----------------------------
select x.*, au.* from bppp.Policy_Plan_Component_Xref x left join AUDIT_TBL au on au.AUDIT_KEY = x.UPDATE_AUDIT_KEY
where END_DT > sysdate;--46 rows    --EFFECTIVE_DT < date '2022-07-01' and
select x.*, au.* from bppp.Policy_Plan_Component_Xref x left join AUDIT_TBL au on au.AUDIT_KEY = x.UPDATE_AUDIT_KEY
where END_DT = date '2023-04-29';--46

-------======Step 4 rd start from here ========-----------------------------

