
------- Points need to check----------------
--[1] --Dealer_Cost = 74% MSRP

 Select  CHANNEL,NAME,PRODUCT_CAT_DESC,TERM,MIN_HP,MAX_HP,MSRP,
    SIC_COST,UNDERWRITER_RESERVE,UNDERWRITER_FEE,UNDERWRITER_TAX,OBLIGOR_FEE,NULL,
    0,0,0,0,(MSRP * 0.74) AS Dealer_Cost,NULL,0,0,0,0,'PPP_PRICING_2023_07_JUNE',0, AFTER_POLICY_KEY
from PPP_PRICING_2023_07_JUNE;
--[2] --SIC_COST = Underwriter_Reserve + Underwriter_Fee
    Select  SIC_COST,UNDERWRITER_RESERVE,(SIC_COST-Underwriter_Reserve) AS UNDERWRITER_FEE_1 , UNDERWRITER_FEE
    from PPP_PRICING_2023_07_JUNE where (SIC_COST-Underwriter_Reserve) <> UNDERWRITER_FEE;--13

    Select  SIC_COST,UNDERWRITER_RESERVE,(SIC_COST-Underwriter_Reserve) AS UNDERWRITER_FEE_1 , UNDERWRITER_FEE
            ,UNDERWRITER_RESERVE + UNDERWRITER_FEE
    from PPP_PRICING_2023_07_JUNE where (SIC_COST-Underwriter_Reserve) <> UNDERWRITER_FEE;--13

  select POLICY_KEY,SIC_COST,UNDERWRITER_RESERVE,(SIC_COST-Underwriter_Reserve) AS UNDERWRITER_FEE_1 , UNDERWRITER_FEE
  from V_POLICY_FEE_STG Where (SIC_COST-Underwriter_Reserve) <> UNDERWRITER_FEE;--18

 --[3] -- MAX (Dealer_Cost) AS Dealer_Cost,
-- MAX (Underwriter_Reserve) AS Underwriter_Reserve,
-- MAX (Underwriter_Fee) AS Underwriter_Fee                      ----
-- MAX (MSRP) AS MSRP,
-- MAX (SIC_COST) AS SIC_COST,
    select * from V_POLICY_FEE_STG
    where
        Dealer_Cost is null  or
        Underwriter_Reserve is null  or
        Underwriter_Fee is null  or
        MSRP is null  or
        SIC_COST is null ;--0 records

--[4] POLICY_GROUP new entry
Insert into BPPP.POLICY_GROUP
(POLICY_GROUP_KEY,NAME,DESCRIPTION,ACTIVE_IND )
Values(8,'0523','Pricing effective from 30 April 2023','Y');

--New line to add in job populate_policy_tbl
-- , case when effective_dt between date '2009-01-01' and date '2012-10-15' then 2
--       when effective_dt between date '2012-10-16' and date '2015-01-24' then 1
--       when effective_dt = date '2015-01-25' then 3
--       when effective_dt = date '2016-06-01' then 4
--       when effective_dt = date '2018-05-27' then 5
--       when effective_dt between date '2021-07-01' and date '2021-08-01' then 6
--       when effective_dt between date '2022-06-01' and date '2022-08-31' then 7
      when effective_dt between date '2023-04-30' and date '2023-05-31' then 8
--   end as policy_group_key

select Distinct policy_type_key from raw_policy_data_tbl


--[5] select * from  BPPP.UNDERWRITER_TBL;
select * from  BPPP.UNDERWRITER_TBL;
insert into UNDERWRITER_TBL
(UNDERWRITER_KEY, UNDERWRITER_NO, NAME, DESCRIPTION)
Values(5,5,'STARR','Starr');
--New row to insert
-->5. STARR Starr
--SELECT * FROM policy_tbl WHERE policy_tbl.UNDERWRITER_KEY = 5
select  distinct pol.UNDERWRITER_KEY   FROM  raw_policy_data_tbl pol
--JOB changes
-- update policy_tbl set UNDERWRITER_KEY = 5;
--update Policy_Plan_Component_Xref set UNDERWRITER_KEY = 5;

--update in this job populate_raw_policy_data_tbl
--************ update in process of create  raw_policy_data_tbl ************--
--insert into raw_policy_data_tbl (
--      1 as underwriter_key
--                       ,FL_AMT_RESERVE, WESCO_FEE_ONLY, AMT_FEE_ONLY
--                       ,file_nm, old_policy_key
--              from
--                     raw_pricing;
