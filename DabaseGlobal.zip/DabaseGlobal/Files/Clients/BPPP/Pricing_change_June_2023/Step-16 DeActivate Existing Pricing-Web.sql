
--Question here are we going to change it after sync process or before sync process?


select * from policy where exp_dt >= sysdate ;   --and effective_dt <= date '2022-07-01'
--
select effective_dt, exp_dt, count(*) from policy where exp_dt >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, exp_dt order by effective_dt, exp_dt;
-- +--------------------------+--------------------------+--------+
-- |EFFECTIVE_DT              |EXP_DT                    |COUNT(*)|
-- +--------------------------+--------------------------+--------+
-- |2022-06-01 00:00:00.000000|2099-12-31 00:00:00.000000|170     |
-- +--------------------------+--------------------------+--------+

--DO NOT de-activate t_and_c_contract_template_xref data
select * from t_and_c_contract_template_xref where end_dt >= sysdate and effective_dt <= date '2022-07-01';
--
select effective_dt, END_DT, count(*) from t_and_c_contract_template_xref where END_DT >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, END_DT order by effective_dt, END_DT;
-- +--------------------------+--------------------------+--------+
-- |EFFECTIVE_DT              |END_DT                    |COUNT(*)|
-- +--------------------------+--------------------------+--------+
-- |2015-01-25 00:00:00.000000|2099-12-31 00:00:00.000000|15714   |
-- |2016-06-01 00:00:00.000000|2099-12-31 00:00:00.000000|1720    |
-- |2018-07-01 00:00:00.000000|2099-12-31 00:00:00.000000|15712   |
-- |2021-08-01 00:00:00.000000|2099-12-31 00:00:00.000000|12852   |
-- |2022-06-01 00:00:00.000000|2099-12-31 00:00:00.000000|9180    |
-- +--------------------------+--------------------------+--------+


--policy_plan_component_xref does not exist in web


--
select effective_dt, END_DT, count(*) from policy_fee_xref where END_DT >= sysdate --and effective_dt <= date '2022-07-01'
group by effective_dt, END_DT order by effective_dt, END_DT;
-- +--------------------------+--------------------------+--------+
-- |EFFECTIVE_DT              |END_DT                    |COUNT(*)|
-- +--------------------------+--------------------------+--------+
-- |2022-06-01 00:00:00.000000|2099-12-31 00:00:00.000000|2040    |
-- +--------------------------+--------------------------+--------+




--
update policy set exp_dt = date '2023-04-29', LAST_UPDATED_BY = 'BASS-1078', LAST_UPDATED_TS = current_date
--  where exp_dt >= sysdate and effective_dt <= date '2022-07-01';
where exp_dt >= sysdate;
-- rows

select effective_dt, exp_dt, count(*) from policy
group by effective_dt, exp_dt order by effective_dt, exp_dt;

--Do not deactivate t n c data as exp_t/end_dt here is used by contract_end_dt
--update t_and_c_contract_template_xref set end_dt = date '2022-07-01', update_audit_key =
-- where end_dt >= sysdate and effective_dt <= date '2022-07-01';


-- rollback ;
update policy_fee_xref set end_dt = date '2023-04-29', LAST_UPDATED_BY = 'BASS-1078', LAST_UPDATED_TS = current_date
 where end_dt >= sysdate;
-- rows
commit;

select * from user_tab_cols where column_name like 'EFF%';

select effective_dt, END_DT, count(*) from policy_fee_xref
group by effective_dt, END_DT order by effective_dt, END_DT;