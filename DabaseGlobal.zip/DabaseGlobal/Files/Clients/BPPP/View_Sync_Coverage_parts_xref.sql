create view V_SYNC_COVERAGE_PARTS_GROUP_XREF as
SELECT t2.POLICY_XID AS POLICY_ID,
          POLICY_ITEM_KEY,
          COVERAGE_TYPE_KEY,
          COVERED_COMPONENT_KEY,
          PARTS_GROUP_KEY,
          a.CREATION_DT AS LAST_UPDATED_TS
     FROM COVERAGE_PARTS_GROUP_XREF t1
          LEFT JOIN (SELECT *
                       FROM policy_lkp
                      WHERE ext_id_type_cd = '1') t2
             ON (t1.POLICY_KEY = t2.POLICY_KEY)
          JOIN audit_tbl a
             ON (t1.insert_audit_key = a.audit_key)
WHERE t1.POLICY_KEY in (select pol.POLICY_KEY from POLICY_TBL pol where pol.EFFECTIVE_DT >= date '2021-07-01')
/

