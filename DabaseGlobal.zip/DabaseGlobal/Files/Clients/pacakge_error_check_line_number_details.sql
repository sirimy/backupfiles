
SELECT line, position, text
FROM all_errors
WHERE owner = 'BOSHSTG'
  AND name = 'PK_RAW_LEADS'
  AND type = 'PACKAGE BODY'
ORDER BY sequence;


SELECT line, position, text
FROM USER_ERRORS
WHERE   name = 'PK_RAW_LEADS'
  AND type = 'PACKAGE BODY'
ORDER BY sequence;


-- 2. Common Culprits to InvestigateOnce you pull the error log using the queries above, look out for these typical PL/SQL issues:
-- Signature Mismatches
-- (PLS-00323): A procedure or function defined in your package specification does not match the signature implemented in the package body (e.g., parameter names, data types, or counts are different).
-- Missing Objects
-- (PLS-00201 / ORA-00942): The body refers to a table, view, sequence, or another package that does not exist or has been dropped.
-- Privilege Issues: If the object belongs to another schema, ensure BOSHSTG has been given direct privileges (like SELECT or EXECUTE) on it. Remember that roles granted to BOSHSTG are ignored inside defined PL/SQL packages.
--
-- Syntax Errors: Missing semicolons (;), unclosed quotes, or misaligned BEGIN/END blocks.