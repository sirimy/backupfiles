
-- Three QC check Select prepared

--[1]
-- first check before check all records
--or s.OWNERSHIP_INTENTION <> c.OWNERSHIP_INTENTION  -- Are we check here this column or we commented out

select  COUNT(s.UNIQUE_IDENTIFIER)
  from ORDER_EXTRACT_TBL s
       join  ( select * from (
                     select p.*, row_number() over (partition by p.UNIQUE_IDENTIFIER order by p.insert_audit_key desc) as rno
                     from BOSH.ORDER_EXTRACT_TBL p
                     where p.LEAD_SOURCE = 'BSH BD'
                    ) x
                where rno = 1) c on c.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER

 where s.LEAD_SOURCE = 'BSH BD' and nvl(s.OWNERSHIP_INTENTION,'') <> nvl(c.OWNERSHIP_INTENTION,'')  -- This check is common for all
     ;

--Raise QC error that OWNERSHIP_INTENTION is changed from last set of values sent for UNIQUE_IDENTIFIER

--[2]
-- Last one in core is I and next one is U
-- Name and All Adddress colloumn , Purchase date , Phone and Email
select  COUNT(s.UNIQUE_IDENTIFIER)
  from ORDER_EXTRACT_TBL s
       join  ( select * from (
                     select p.*, row_number() over (partition by p.UNIQUE_IDENTIFIER order by p.insert_audit_key desc) as rno
                     from BOSH.ORDER_EXTRACT_TBL p
                     where p.LEAD_SOURCE = 'BSH BD'
                    ) x
                where rno = 1) c on c.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U' and  c.TRANSACTION_TYPE = 'I' and s.LEAD_SOURCE = 'BSH BD' and s.INSTALL_DT is not null and c.INSTALL_DT is null AND
       (1=2
    or nvl(s.PLAN_PURCHASE_DT,'') <> nvl(c.PLAN_PURCHASE_DT,'')  --
    or nvl(s.PURCHASE_DT,'') <> nvl(c.PURCHASE_DT,'')
    or nvl(s.EXTERNAL_CUSTOMER_NO,'') <> nvl(c.EXTERNAL_CUSTOMER_NO,'')
    or nvl(s.FIRM_NM,'') <> nvl(c.FIRM_NM,'')
    or nvl(s.FIRST_NM,'') <> nvl(c.FIRST_NM,'')
    or nvl(s.MIDDLE_NM,'') <> nvl(c.MIDDLE_NM,'')
    or nvl(s.LAST_NM,'') <> nvl(c.LAST_NM,'')
    or nvl(s.EMAIL_ADDRESS_TX,'') <> nvl(c.EMAIL_ADDRESS_TX,'')
    or nvl(s.PHONE_NO,'') <> nvl(c.PHONE_NO,'')
    or nvl(s.BILLING_ADDRESS_LINE1_TX,'') <> nvl(c.BILLING_ADDRESS_LINE1_TX,'')
    or nvl(s.BILLING_ADDRESS_LINE2_TX,'') <> nvl(c.BILLING_ADDRESS_LINE2_TX,'')
    or nvl(s.BILLING_CITY_NM,'') <> nvl(c.BILLING_CITY_NM,'')
    or nvl(s.BILLING_STATE_CD,'') <> nvl(c.BILLING_STATE_CD,'')
    or nvl(s.BILLING_ZIP,'') <> nvl(c.BILLING_ZIP,'')
    or nvl(s.BILLING_COUNTRY_NM,'') <> nvl(c.BILLING_COUNTRY_NM,'')
    or nvl(s.SHIPPING_ADDRESS_LINE1_TX,'') <> nvl(c.SHIPPING_ADDRESS_LINE1_TX,'')
    or nvl(s.SHIPPING_ADDRESS_LINE2_TX,'') <> nvl(c.SHIPPING_ADDRESS_LINE2_TX,'')
    or nvl(s.SHIPPING_CITY_NM,'') <> nvl(c.SHIPPING_CITY_NM,'')
    or nvl(s.SHIPPING_STATE_CD,'') <> nvl(c.SHIPPING_STATE_CD,'')
    or nvl(s.SHIPPING_ZIP,'') <> nvl(c.SHIPPING_ZIP,'')
    or nvl(s.SHIPPING_COUNTRY_NM,'') <> nvl(c.SHIPPING_COUNTRY_NM,'')

    );


--[3] Rest all
select  COUNT(s.UNIQUE_IDENTIFIER)
  from ORDER_EXTRACT_TBL s
       join  ( select * from (
                     select p.*, row_number() over (partition by p.UNIQUE_IDENTIFIER order by p.insert_audit_key desc) as rno
                     from BOSH.ORDER_EXTRACT_TBL p
                     where p.LEAD_SOURCE = 'BSH BD'
                    ) x
                where rno = 1) c on c.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.LEAD_SOURCE = 'BSH BD'   AND
       (1=2
        or nvl(s.WARRANTY_PURCHASE_PRICE_AMT,'') <> nvl(c.WARRANTY_PURCHASE_PRICE_AMT,'')
        or nvl(s.WARRANTY_PURCHASE_TAX_AMT,'') <> nvl(c.WARRANTY_PURCHASE_TAX_AMT,'')
        or nvl(s.PAYMENT_SCHEDULE,'') <> nvl(c.PAYMENT_SCHEDULE,'')
        or nvl(s.PAYMENT_PLAN_CD,'') <> nvl(c.PAYMENT_PLAN_CD,'')
        or nvl(s.SKU_CD,'') <> nvl(c.SKU_CD,'')
        or nvl(s.LEAD_SOURCE,'') <> nvl(c.LEAD_SOURCE,'')
        or nvl(s.CURRENCY_CD,'') <> nvl(c.CURRENCY_CD,'')
        or nvl(s.MODEL_NO,'') <> nvl(c.MODEL_NO,'')
        or nvl(s.MAKE,'') <> nvl(c.MAKE,'')
        or nvl(s.SERIAL_NO,'') <> nvl(c.SERIAL_NO,'')
        or nvl(s.PAID_TO_DATE,'') <> nvl(c.PAID_TO_DATE,'')
        or nvl(s.PRODUCT_PURCHASE_PRICE,'') <> nvl(c.PRODUCT_PURCHASE_PRICE,'')
        or nvl(s.DNS_EMAIL,'') <> nvl(c.DNS_EMAIL,'')
        or nvl(s.NO_THIRD_PARTY_DATA,'') <> nvl(c.NO_THIRD_PARTY_DATA,'')
        or nvl(s.CUSTOMER_APPLIANCE_ID,'') <> nvl(c.CUSTOMER_APPLIANCE_ID,'')
        or nvl(s.COSMO_ID,'') <> nvl(c.COSMO_ID ,'')   );--