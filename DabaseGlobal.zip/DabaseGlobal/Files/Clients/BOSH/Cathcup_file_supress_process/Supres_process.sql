[2026-09-07 16:56:44:782] Connected
[2026-09-07 16:56:44:971] BOSHSTG> alter session set current_schema = BOSHSTG
[2026-09-07 16:56:45:158] completed in 187 ms
[2026-09-07 16:56:45:353] BOSHSTG> select * from BOSH.SERIALIZED_ITEM_DIM
[2026-09-07 16:56:45:907] 100 rows retrieved starting from 1 in 554 ms (execution: 196 ms, fetching: 358 ms)
[2026-09-07 16:57:35:013] BOSHSTG> select * from BOSH.SERIALIZED_ITEM_DIM where MODEL_NO in (
                                       select  MATERIAL from RAW_MODEL_MASTER_TBL
                                                where MATERIAL not in (select  PD.MODEL_NO from BOSH.PRODUCT_DIM PD)
                                               and ERROR_DESC is null
                                       --and MAP_UMRP IS NOT NULL
                                       and MATERIAL_GROUP <> 'Accessory')
[2026-09-07 16:57:39:719] 2 rows retrieved starting from 1 in 4 s 707 ms (execution: 4 s 377 ms, fetching: 330 ms)
[2026-09-07 19:14:56:681] BOSHSTG> select FILE_NM,COUNT(*) from COMMON_LOAD_HOLD_TBL group by FILE_NM
[2026-09-07 19:14:57:210] 4 rows retrieved starting from 1 in 528 ms (execution: 210 ms, fetching: 318 ms)
[2026-09-07 19:15:46:871] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY

                               group by FILE_NM,CREATION_DT
[2026-09-07 19:15:47:408] 4 rows retrieved starting from 1 in 537 ms (execution: 219 ms, fetching: 318 ms)
[2026-09-13 23:10:24:777] Connected
[2026-09-13 23:10:25:024] BOSHSTG> alter session set current_schema = BOSHSTG
[2026-09-13 23:10:25:216] completed in 192 ms
[2026-09-13 23:10:25:536] BOSHSTG> select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from BOSH.RAW_LEADS_TBL group by FILE_NM,INSERT_AUDIT_KEY
                               order by INSERT_AUDIT_KEY desc
[2026-09-13 23:10:29:274] 100 rows retrieved starting from 1 in 3 s 738 ms (execution: 3 s 381 ms, fetching: 357 ms)
[2026-09-13 23:17:37:025] BOSHSTG> select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from BOSH.RAW_LEADS_TBL
                               where FILE_NM like '%_catchup_%'
                               group by FILE_NM,INSERT_AUDIT_KEY
                               order by INSERT_AUDIT_KEY desc
[2026-09-13 23:17:40:431] 17 rows retrieved starting from 1 in 3 s 406 ms (execution: 3 s 368 ms, fetching: 38 ms)
[2026-09-14 02:13:22:781] transaction committed: @console_45 [BOSH-STg-Prod]
[2026-09-15 06:22:37:705] Connected
[2026-09-15 06:22:37:896] BOSHSTG> alter session set current_schema = BOSHSTG
[2026-09-15 06:22:38:082] completed in 187 ms
[2026-09-15 06:22:38:282] BOSHSTG> select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from BOSH.RAW_LEADS_TBL
                               where FILE_NM like '%_catchup_%'
                               group by FILE_NM,INSERT_AUDIT_KEY
                               order by INSERT_AUDIT_KEY desc
[2026-09-15 06:22:42:849] 20 rows retrieved starting from 1 in 4 s 567 ms (execution: 4 s 240 ms, fetching: 327 ms)
[2026-09-15 14:40:00:480] BOSHSTG> SELECT count(*) FROM ORDER_TBL
[2026-09-15 14:40:01:523] 1 row retrieved starting from 1 in 1 s 43 ms (execution: 730 ms, fetching: 313 ms)
[2026-09-15 14:41:38:026] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_OUTPUT_TBL
[2026-09-15 14:41:38:593] 1 row retrieved starting from 1 in 567 ms (execution: 248 ms, fetching: 319 ms)
[2026-09-15 14:41:41:658] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_HOLD_TBL
[2026-09-15 14:41:42:192] 1 row retrieved starting from 1 in 534 ms (execution: 218 ms, fetching: 316 ms)
[2026-09-15 14:41:47:455] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_TBL
[2026-09-15 14:41:48:090] 1 row retrieved starting from 1 in 635 ms (execution: 323 ms, fetching: 312 ms)
[2026-09-15 14:41:51:628] BOSHSTG> SELECT count(*) FROM ADDRESS_OUTPUT_TBL
[2026-09-15 14:41:52:216] 1 row retrieved starting from 1 in 588 ms (execution: 274 ms, fetching: 314 ms)
[2026-09-15 14:41:54:330] BOSHSTG> SELECT count(*) FROM SI_OUTPUT_TBL
[2026-09-15 14:41:54:861] 1 row retrieved starting from 1 in 531 ms (execution: 219 ms, fetching: 312 ms)
[2026-09-15 14:41:56:716] BOSHSTG> SELECT count(*) FROM SERIALIZED_ITEM_EXT_DIM
[2026-09-15 14:41:57:241] 1 row retrieved starting from 1 in 525 ms (execution: 215 ms, fetching: 310 ms)
[2026-09-15 14:41:59:755] BOSHSTG> SELECT count(*) FROM DS_ACE_OUTPUT_TBL
[2026-09-15 14:42:00:289] 1 row retrieved starting from 1 in 534 ms (execution: 218 ms, fetching: 316 ms)
[2026-09-15 14:42:03:482] BOSHSTG> SELECT count(*) FROM SERIALIZED_ITEM_EXT_DIM
[2026-09-15 14:42:04:004] 1 row retrieved starting from 1 in 522 ms (execution: 205 ms, fetching: 317 ms)
[2026-09-15 14:42:08:652] BOSHSTG> SELECT count(*) FROM CUSTOMER_OUTPUT_TBL
[2026-09-15 14:42:09:243] 1 row retrieved starting from 1 in 591 ms (execution: 276 ms, fetching: 315 ms)
[2026-09-15 14:42:55:414] BOSHSTG> truncate table  COMMON_LOAD_OUTPUT_TBL
[2026-09-15 14:42:55:682] completed in 268 ms
[2026-09-15 14:42:55:892] BOSHSTG> truncate table  COMMON_LOAD_HOLD_TBL
[2026-09-15 14:42:56:339] completed in 447 ms
[2026-09-15 14:42:56:546] BOSHSTG> truncate table  COMMON_LOAD_TBL
[2026-09-15 14:42:56:850] completed in 304 ms
[2026-09-15 14:42:57:056] BOSHSTG> truncate table  ADDRESS_OUTPUT_TBL
[2026-09-15 14:42:57:351] completed in 295 ms
[2026-09-15 14:42:57:566] BOSHSTG> truncate table  SI_OUTPUT_TBL
[2026-09-15 14:42:57:847] completed in 281 ms
[2026-09-15 14:42:58:055] BOSHSTG> truncate table  SERIALIZED_ITEM_EXT_DIM
[2026-09-15 14:42:58:323] completed in 268 ms
[2026-09-15 14:42:58:532] BOSHSTG> truncate table  DS_ACE_OUTPUT_TBL
[2026-09-15 14:42:58:798] completed in 266 ms
[2026-09-15 14:42:59:004] BOSHSTG> truncate table  CUSTOMER_OUTPUT_TBL
[2026-09-15 14:42:59:267] completed in 263 ms
[2026-09-15 14:42:59:472] BOSHSTG> truncate table visitor_dim
[2026-09-15 14:42:59:752] completed in 280 ms
[2026-09-15 14:42:59:958] BOSHSTG> truncate table visitor_lkp
[2026-09-15 14:43:00:434] completed in 476 ms
[2026-09-15 14:43:00:642] BOSHSTG> truncate table visitor_history_tbl
[2026-09-15 14:43:00:867] completed in 225 ms
[2026-09-15 14:43:01:075] BOSHSTG> truncate table address_dim
[2026-09-15 14:43:01:327] completed in 252 ms
[2026-09-15 14:43:01:534] BOSHSTG> truncate table address_lkp
[2026-09-15 14:43:01:806] completed in 272 ms
[2026-09-15 14:43:02:012] BOSHSTG> truncate table visitor_address_xref
[2026-09-15 14:43:02:278] completed in 266 ms
[2026-09-15 14:43:02:486] BOSHSTG> truncate table visitor_address_lkp
[2026-09-15 14:43:02:746] completed in 260 ms
[2026-09-15 14:43:02:954] BOSHSTG> truncate table serialized_item_dim
[2026-09-15 14:43:03:256] completed in 302 ms
[2026-09-15 14:43:03:463] BOSHSTG> truncate table serialized_item_lkp
[2026-09-15 14:43:03:826] completed in 363 ms
[2026-09-15 14:43:04:033] BOSHSTG> truncate table visitor_ownership_xref
[2026-09-15 14:43:04:300] completed in 267 ms
[2026-09-15 14:43:04:511] BOSHSTG> truncate table email_lkp
[2026-09-15 14:43:04:771] completed in 260 ms
[2026-09-15 14:43:04:978] BOSHSTG> truncate table email_dim
[2026-09-15 14:43:05:228] completed in 249 ms
[2026-09-15 14:43:05:455] BOSHSTG> truncate table visitor_email_xref
[2026-09-15 14:43:05:709] completed in 254 ms
[2026-09-15 14:43:05:916] BOSHSTG> truncate table visitor_email_lkp
[2026-09-15 14:43:06:169] completed in 253 ms
[2026-09-15 14:43:06:376] BOSHSTG> truncate table phone_dim
[2026-09-15 14:43:06:633] completed in 258 ms
[2026-09-15 14:43:06:839] BOSHSTG> truncate table phone_lkp
[2026-09-15 14:43:07:104] completed in 265 ms
[2026-09-15 14:43:07:327] BOSHSTG> truncate table visitor_phone_xref
[2026-09-15 14:43:07:588] completed in 261 ms
[2026-09-15 14:43:07:800] BOSHSTG> truncate table visitor_phone_lkp
[2026-09-15 14:43:08:059] completed in 259 ms
[2026-09-15 14:43:08:270] BOSHSTG> truncate table VISITOR_PREFERENCE_TBL
[2026-09-15 14:43:08:532] completed in 262 ms
[2026-09-15 14:43:08:748] BOSHSTG> truncate table purl_dim
[2026-09-15 14:43:09:045] completed in 296 ms
[2026-09-15 14:43:09:262] BOSHSTG> truncate table VISITOR_PURL_XREF
[2026-09-15 14:43:09:518] completed in 256 ms
[2026-09-15 14:43:09:734] BOSHSTG> truncate table CUSTOMER_DIM
[2026-09-15 14:43:09:990] completed in 256 ms
[2026-09-15 14:43:10:196] BOSHSTG> truncate table HOUSEHOLD_LKP
[2026-09-15 14:43:10:400] completed in 204 ms
[2026-09-15 14:43:10:606] BOSHSTG> truncate table CUSTOMER_LKP
[2026-09-15 14:43:10:881] completed in 275 ms
[2026-09-15 14:43:14:385] transaction committed: @console_45 [BOSH-STg-Prod]
[2026-09-15 14:43:21:649] BOSHSTG> COMMIT
[2026-09-15 14:43:21:848] completed in 199 ms
[2026-09-15 14:43:42:003] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_OUTPUT_TBL
[2026-09-15 14:43:42:541] 1 row retrieved starting from 1 in 538 ms (execution: 203 ms, fetching: 335 ms)
[2026-09-15 14:43:45:037] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_HOLD_TBL
[2026-09-15 14:43:45:551] 1 row retrieved starting from 1 in 513 ms (execution: 201 ms, fetching: 312 ms)
[2026-09-15 14:43:47:879] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_TBL
[2026-09-15 14:43:48:396] 1 row retrieved starting from 1 in 516 ms (execution: 202 ms, fetching: 314 ms)
[2026-09-15 14:43:50:584] BOSHSTG> SELECT count(*) FROM ADDRESS_OUTPUT_TBL
[2026-09-15 14:43:51:108] 1 row retrieved starting from 1 in 524 ms (execution: 205 ms, fetching: 319 ms)
[2026-09-15 14:44:10:147] BOSHSTG> SELECT count(*) FROM SERIALIZED_ITEM_EXT_DIM
[2026-09-15 14:44:10:689] 1 row retrieved starting from 1 in 542 ms (execution: 203 ms, fetching: 339 ms)
[2026-09-15 14:51:37:987] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 14:51:38:521] 0 rows retrieved in 534 ms (execution: 220 ms, fetching: 314 ms)
[2026-09-15 14:51:40:874] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 14:51:41:401] 1 row retrieved starting from 1 in 527 ms (execution: 201 ms, fetching: 326 ms)
[2026-09-15 14:51:43:837] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 14:51:44:354] 1 row retrieved starting from 1 in 517 ms (execution: 201 ms, fetching: 316 ms)
[2026-09-15 14:51:46:669] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 14:51:47:181] 1 row retrieved starting from 1 in 512 ms (execution: 201 ms, fetching: 311 ms)
[2026-09-15 14:51:51:618] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 14:51:52:127] 1 row retrieved starting from 1 in 509 ms (execution: 201 ms, fetching: 308 ms)
[2026-09-15 14:51:55:400] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 14:51:55:912] 1 row retrieved starting from 1 in 512 ms (execution: 203 ms, fetching: 309 ms)
[2026-09-15 15:12:36:395] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 15:12:36:936] 4 rows retrieved starting from 1 in 542 ms (execution: 203 ms, fetching: 339 ms)
[2026-09-15 15:13:42:667] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_ORDER_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 15:13:43:196] 1 row retrieved starting from 1 in 529 ms (execution: 212 ms, fetching: 317 ms)
[2026-09-15 15:13:52:384] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from COMMON_LOAD_HOLD_TBL CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 15:13:52:905] 4 rows retrieved starting from 1 in 521 ms (execution: 203 ms, fetching: 318 ms)
[2026-09-15 15:14:23:919] BOSHSTG> select FILE_NM,CREATION_DT,COUNT(*)
                               from CONTRACT_COMMON_LOAD_TBL_HOLD CLHT
                               JOIN AUDIT_TBL ATB on CLHT.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                               group by FILE_NM,CREATION_DT
[2026-09-15 15:14:24:453] 4 rows retrieved starting from 1 in 534 ms (execution: 215 ms, fetching: 319 ms)
[2026-09-15 16:12:10:832] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_OUTPUT_TBL
[2026-09-15 16:12:11:341] 1 row retrieved starting from 1 in 508 ms (execution: 193 ms, fetching: 315 ms)
[2026-09-15 16:12:18:227] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_HOLD_TBL
[2026-09-15 16:12:18:732] 1 row retrieved starting from 1 in 506 ms (execution: 191 ms, fetching: 315 ms)
[2026-09-15 16:12:26:141] BOSHSTG> SELECT count(*) FROM COMMON_LOAD_TBL
[2026-09-15 16:12:26:647] 1 row retrieved starting from 1 in 506 ms (execution: 190 ms, fetching: 316 ms)
[2026-09-15 16:16:45:775] BOSHSTG> select count(*) unique_leads, sum(leads) total_leads
                                 from (
                                       select NAME_ADDRESS_HASH || E_NUMBER || PURCHASE_DT, count(*) as leads
                                       from bosh.RAW_LEADS_TBL r join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY where CREATION_DT >= date '2026-09-15'
                                        and ERROR_DESC is null
                                       group by NAME_ADDRESS_HASH || E_NUMBER || PURCHASE_DT having count(*) >= 2)
[2026-09-15 16:16:51:490] 1 row retrieved starting from 1 in 5 s 715 ms (execution: 5 s 396 ms, fetching: 319 ms)
[2026-09-15 16:28:49:761] BOSHSTG> SELECT COUNT(*) AS duplicate_rows_to_update
                               FROM
                               (
                                   SELECT ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           r.E_NUMBER,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM bosh.RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn > 1
[2026-09-15 16:28:56:175] 1 row retrieved starting from 1 in 6 s 414 ms (execution: 6 s 97 ms, fetching: 317 ms)
[2026-09-15 16:29:59:444] BOSHSTG> SELECT COUNT(*) AS uniqe_rows_to_left
                               FROM
                               (
                                   SELECT ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           r.E_NUMBER,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM bosh.RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn = 1
[2026-09-15 16:30:08:524] 1 row retrieved starting from 1 in 9 s 80 ms (execution: 8 s 768 ms, fetching: 312 ms)
[2026-09-15 16:37:40:490] BOSHSTG> SELECT *
                               FROM
                               (
                                   SELECT ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           r.E_NUMBER,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM bosh.RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15' AND EMAIL_ADDRESS_TX = 'RNH255@GMAIL.COM'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn = 1
[2026-09-15 16:37:46:312] 8 rows retrieved starting from 1 in 5 s 822 ms (execution: 5 s 512 ms, fetching: 310 ms)
[2026-09-15 16:38:10:380] BOSHSTG> SELECT *
                               FROM
                               (
                                   SELECT *,ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           r.E_NUMBER,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM bosh.RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15' AND EMAIL_ADDRESS_TX = 'RNH255@GMAIL.COM'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn = 1
[2026-09-15 16:38:10:754] [42000][923]
[2026-09-15 16:38:10:754] 	ORA-00923: FROM keyword not found where expected
[2026-09-15 16:38:10:754] 	https://docs.oracle.com/error-help/db/ora-00923/
[2026-09-15 16:38:10:754] Position: 28
[2026-09-15 16:38:27:402] BOSHSTG> SELECT *
                               FROM
                               (
                                   SELECT r.*,ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           r.E_NUMBER,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM bosh.RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15' AND EMAIL_ADDRESS_TX = 'RNH255@GMAIL.COM'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn = 1
[2026-09-15 16:38:33:764] 8 rows retrieved starting from 1 in 6 s 362 ms (execution: 6 s 33 ms, fetching: 329 ms)
[2026-09-15 16:40:28:781] BOSHSTG> SELECT *
                               FROM
                               (
                                   SELECT r.*,ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           r.E_NUMBER,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM bosh.RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15' AND EMAIL_ADDRESS_TX = 'RNH255@GMAIL.COM'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn > 1
[2026-09-15 16:40:35:083] 35 rows retrieved starting from 1 in 6 s 302 ms (execution: 5 s 955 ms, fetching: 347 ms)
[2026-09-15 17:34:10:501] BOSHSTG> insert into RAW_LEADS_TBL
                                   select *
                                   from   BOSH.RAW_LEADS_TBL RLIN
                                   where  RLIN.FILE_NM   in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
[2026-09-15 17:34:20:498] 1,720,610 rows affected in 9 s 997 ms
[2026-09-15 17:34:34:854] transaction committed: @console_45 [BOSH-STg-Prod]
[2026-09-15 17:38:25:853] BOSHSTG> SELECT COUNT(*) AS uniqe_rows_to_left
                               FROM
                               (
                                   SELECT ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           case when instr( r.E_NUMBER,'/') > 0 then  r.E_NUMBER else  r.E_NUMBER||'/xx' end ,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn = 1
[2026-09-15 17:38:28:208] 1 row retrieved starting from 1 in 2 s 356 ms (execution: 2 s 40 ms, fetching: 316 ms)
[2026-09-15 17:38:37:842] BOSHSTG> SELECT COUNT(*) AS duplicate_rows_to_update
                               FROM
                               (
                                   SELECT ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           case when instr( r.E_NUMBER,'/') > 0 then  r.E_NUMBER else  r.E_NUMBER||'/xx' end ,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn > 1
[2026-09-15 17:38:39:322] 1 row retrieved starting from 1 in 1 s 480 ms (execution: 1 s 161 ms, fetching: 319 ms)
[2026-09-15 17:39:12:916] BOSHSTG> select ERROR_DESC,COUNT(*) from RAW_LEADS_TBL
                               group by ERROR_DESC
                               order by ERROR_DESC desc
[2026-09-15 17:39:13:790] 7 rows retrieved starting from 1 in 874 ms (execution: 555 ms, fetching: 319 ms)
[2026-09-15 17:40:04:351] transaction committed: @console_45 [BOSH-STg-Prod]
[2026-09-15 17:40:09:536] BOSHSTG> UPDATE RAW_LEADS_TBL
                               SET ERROR_DESC = 'DUPLICATE RECORD on NAME_ADDRESS_HASH, E_NUMBER, PURCHASE_DT'
                               WHERE ROWID IN
                               (
                                   SELECT rid
                                   FROM
                                   (
                                       SELECT r.ROWID AS rid,
                                              ROW_NUMBER() OVER
                                              (
                                                  PARTITION BY r.NAME_ADDRESS_HASH,
                                                               case when instr( r.E_NUMBER,'/') > 0 then  r.E_NUMBER else  r.E_NUMBER||'/xx' end ,
                                                               r.PURCHASE_DT
                                                  ORDER BY r.ROWID
                                              ) AS rn
                                       FROM RAW_LEADS_TBL r
                                       JOIN AUDIT_TBL ai
                                         ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                       WHERE ai.CREATION_DT >= DATE '2026-09-15'
                                         AND r.ERROR_DESC IS NULL
                                   )
                                   WHERE rn > 1
                               )
[2026-09-15 17:40:18:277] 464,953 rows affected in 8 s 741 ms
[2026-09-15 17:40:46:385] BOSHSTG> with email having word “REGISTRIA”               |62      |
                               |BRAND  in -BALAY-CONSTRUCTA-NEFF-PROFILO-SIEMENS-      |665     |
                               |Leads with email ending with .ru or .ua domain         |2305    |
                               |count(distinct E_NUMBER||PURCHASE_DT) >= 10            |98750   |
                               |BOSH-406- Both Purchase_dt and Registration_dt are NULL|285094  |
                               |null                                                   |538059  |
                               |Address is missing                                     |795675  |
                               +-------------------------------------------------------+--------+


                               select ERROR_DESC,COUNT(*) from RAW_LEADS_TBL
                               group by ERROR_DESC
                               order by ERROR_DESC desc
[2026-09-15 17:40:46:794] [42000][905]
[2026-09-15 17:40:46:794] 	ORA-00905: missing keyword
[2026-09-15 17:40:46:794] 	https://docs.oracle.com/error-help/db/ora-00905/
[2026-09-15 17:40:46:794] Position: 11
[2026-09-15 17:40:51:146] transaction committed: @console_45 [BOSH-STg-Prod]
[2026-09-15 17:40:54:711] BOSHSTG> select ERROR_DESC,COUNT(*) from RAW_LEADS_TBL
                               group by ERROR_DESC
                               order by ERROR_DESC desc
[2026-09-15 17:40:55:809] 8 rows retrieved starting from 1 in 1 s 98 ms (execution: 780 ms, fetching: 318 ms)
[2026-09-15 17:43:20:471] BOSHSTG> SELECT *
                               FROM
                               (
                                   SELECT r.*,ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           case when instr( r.E_NUMBER,'/') > 0 then  r.E_NUMBER else  r.E_NUMBER||'/xx' end ,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM bosh.RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15' AND EMAIL_ADDRESS_TX = 'RNH255@GMAIL.COM'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn > 1
[2026-09-15 17:43:22:224] 35 rows retrieved starting from 1 in 1 s 753 ms (execution: 1 s 423 ms, fetching: 330 ms)
[2026-09-15 17:43:55:410] BOSHSTG> SELECT *
                               FROM
                               (
                                   SELECT r.*,ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           case when instr( r.E_NUMBER,'/') > 0 then  r.E_NUMBER else  r.E_NUMBER||'/xx' end ,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15' AND EMAIL_ADDRESS_TX = 'RNH255@GMAIL.COM'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn > 1
[2026-09-15 17:43:56:164] 0 rows retrieved in 755 ms (execution: 434 ms, fetching: 321 ms)
[2026-09-15 17:44:05:678] BOSHSTG> SELECT *
                               FROM
                               (
                                   SELECT r.*,ROW_NUMBER() OVER
                                          (
                                              PARTITION BY r.NAME_ADDRESS_HASH,
                                                           case when instr( r.E_NUMBER,'/') > 0 then  r.E_NUMBER else  r.E_NUMBER||'/xx' end ,
                                                           r.PURCHASE_DT
                                              ORDER BY r.ROWID
                                          ) AS rn
                                   FROM RAW_LEADS_TBL r
                                   JOIN AUDIT_TBL ai
                                     ON ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
                                   WHERE ai.CREATION_DT >= DATE '2026-09-15' AND EMAIL_ADDRESS_TX = 'RNH255@GMAIL.COM'
                                     AND r.ERROR_DESC IS NULL
                               )
                               WHERE rn = 1
[2026-09-15 17:44:06:438] 8 rows retrieved starting from 1 in 760 ms (execution: 427 ms, fetching: 333 ms)
[2026-09-15 17:45:37:377] BOSHSTG> select FILE_NM,COUNT(*),COUNT(distinct POSTED_SERIAL_ITEM_KEY)
                               from   RAW_LEADS_TBL RL
                                       JOIN SI_OUTPUT_TBL SIOT ON SIOT.UNIQUE_SEQ_NO = RL.UNIQUE_SEQ_NO
                               where   ERROR_DESC IS NULL
                                   and (FIRST_NM,LAST_NM,COALESCE(EMAIL_ADDRESS_TX,'X'),COALESCE(TELEPHONE_NO,'0'),E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,'y'))
                                   in (
                                         select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                                               from   BOSH.RAW_LEADS_TBL RLIN
                                          where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                                                    and RLIN.ERROR_DESC IS NULL
                                   )
                               group by RL.FILE_NM
[2026-09-15 17:45:37:943] 0 rows retrieved in 566 ms (execution: 254 ms, fetching: 312 ms)
[2026-09-15 17:46:07:965] BOSHSTG> select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                                               from   BOSH.RAW_LEADS_TBL RLIN
                                          where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                                                    and RLIN.ERROR_DESC IS NULL
[2026-09-15 17:46:08:499] 100 rows retrieved starting from 1 in 534 ms (execution: 211 ms, fetching: 323 ms)
[2026-09-15 17:46:36:635] BOSHSTG> select FILE_NM,COUNT(*),COUNT(distinct POSTED_SERIAL_ITEM_KEY)
                               from   RAW_LEADS_TBL RL
                                       JOIN SI_OUTPUT_TBL SIOT ON SIOT.UNIQUE_SEQ_NO = RL.UNIQUE_SEQ_NO
                               where   ERROR_DESC IS NULL
                               --     and (FIRST_NM,LAST_NM,COALESCE(EMAIL_ADDRESS_TX,'X'),COALESCE(TELEPHONE_NO,'0'),E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,'y'))
                               --     in (
                               --           select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                               --                 from   BOSH.RAW_LEADS_TBL RLIN
                               --            where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                               --                      and RLIN.ERROR_DESC IS NULL
                               --     )
                               group by RL.FILE_NM
[2026-09-15 17:46:37:174] 0 rows retrieved in 538 ms (execution: 224 ms, fetching: 314 ms)
[2026-09-15 17:46:57:199] BOSHSTG> select FILE_NM,COUNT(*)
                               from   RAW_LEADS_TBL
                               where   ERROR_DESC IS NULL
                               --     and (FIRST_NM,LAST_NM,COALESCE(EMAIL_ADDRESS_TX,'X'),COALESCE(TELEPHONE_NO,'0'),E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,'y'))
                               --     in (
                               --           select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                               --                 from   BOSH.RAW_LEADS_TBL RLIN
                               --            where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                               --                      and RLIN.ERROR_DESC IS NULL
                               --     )
                               group by RL.FILE_NM
[2026-09-15 17:46:57:605] [42000][904]
[2026-09-15 17:46:57:605] 	ORA-00904: "RL"."FILE_NM": invalid identifier
[2026-09-15 17:46:57:605] 	https://docs.oracle.com/error-help/db/ora-00904/
[2026-09-15 17:46:57:605] Position: 808
[2026-09-15 17:47:10:746] BOSHSTG> select FILE_NM,COUNT(*)
                               from   RAW_LEADS_TBL RL
                               where   ERROR_DESC IS NULL
                               --     and (FIRST_NM,LAST_NM,COALESCE(EMAIL_ADDRESS_TX,'X'),COALESCE(TELEPHONE_NO,'0'),E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,'y'))
                               --     in (
                               --           select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                               --                 from   BOSH.RAW_LEADS_TBL RLIN
                               --            where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                               --                      and RLIN.ERROR_DESC IS NULL
                               --     )
                               group by RL.FILE_NM
[2026-09-15 17:47:11:213] 3 rows retrieved starting from 1 in 467 ms (execution: 445 ms, fetching: 22 ms)
[2026-09-15 17:47:36:687] BOSHSTG> select FILE_NM,COUNT(*)
                               from   RAW_LEADS_TBL RL
                               where   ERROR_DESC IS NULL
                                   and (FIRST_NM,LAST_NM,COALESCE(EMAIL_ADDRESS_TX,'X'),COALESCE(TELEPHONE_NO,'0'),E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,'y'))
                                   in (
                                         select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                                               from   BOSH.RAW_LEADS_TBL RLIN
                                          where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                                                    and RLIN.ERROR_DESC IS NULL
                                   )
                               group by RL.FILE_NM
[2026-09-15 17:47:41:011] 3 rows retrieved starting from 1 in 4 s 324 ms (execution: 4 s 7 ms, fetching: 317 ms)
[2026-09-15 17:51:22:462] BOSHSTG> select RL.ROWID
                               from   RAW_LEADS_TBL RL
                               where   ERROR_DESC IS NULL
                                   and (FIRST_NM,LAST_NM,COALESCE(EMAIL_ADDRESS_TX,'X'),COALESCE(TELEPHONE_NO,'0'),E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,'y'))
                                   in (
                                         select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                                               from   BOSH.RAW_LEADS_TBL RLIN
                                          where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                                                    and RLIN.ERROR_DESC IS NULL
                                   )
[2026-09-15 17:51:24:868] 100 rows retrieved starting from 1 in 2 s 406 ms (execution: 2 s 91 ms, fetching: 315 ms)
[2026-09-15 17:52:30:216] BOSHSTG> select COUNT(RL.ROWID)
                                       from   RAW_LEADS_TBL RL
                                       where   ERROR_DESC IS NULL
                                           and (FIRST_NM,LAST_NM,COALESCE(EMAIL_ADDRESS_TX,'X'),COALESCE(TELEPHONE_NO,'0'),E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,'y'))
                                           in (
                                                 select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                                                       from   BOSH.RAW_LEADS_TBL RLIN
                                                  where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                                                            and RLIN.ERROR_DESC IS NULL
                                           )
[2026-09-15 17:52:34:504] 1 row retrieved starting from 1 in 4 s 288 ms (execution: 3 s 970 ms, fetching: 318 ms)
[2026-09-15 17:56:50:583] BOSHSTG> UPDATE RAW_LEADS_TBL
                               SET ERROR_DESC = 'Already Exist in Core for FIRST_NM,LAST_NM,EMAIL_ADDRESS_TX,TELEPHONE_NO,E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,y)'
                               WHERE ROWID IN
                               (
                                    select RL.ROWID
                                       from   RAW_LEADS_TBL RL
                                       where   ERROR_DESC IS NULL
                                           and (FIRST_NM,LAST_NM,COALESCE(EMAIL_ADDRESS_TX,'X'),COALESCE(TELEPHONE_NO,'0'),E_NUMBER,COALESCE(PURCHASE_DT,REGISTRATION_DT),STREET_ADDR1,CITY_NM,STATE_CD,COALESCE(HOUSE_NO,'y'))
                                           in (
                                                 select RLIN.FIRST_NM,RLIN.LAST_NM,RLIN.EMAIL_ADDRESS_TX,RLIN.TELEPHONE_NO,RLIN.E_NUMBER,COALESCE(RLIN.PURCHASE_DT,RLIN.REGISTRATION_DT),RLIN.STREET_ADDR1,RLIN.CITY_NM,RLIN.STATE_CD,COALESCE(RLIN.HOUSE_NO,'y')
                                                       from   BOSH.RAW_LEADS_TBL RLIN
                                                  where  RLIN.FILE_NM  not in ('bsh_after_cdb_hc_catchup_2026_feb_2026_april.csv','bsh_after_cdb_re_catchup_2026_feb_2026_april.csv','bsh_after_cdb_catchup_2026_feb_2026_april.csv')
                                                            and RLIN.ERROR_DESC IS NULL
                                           )
                               )
[2026-09-15 17:56:54:637] 18,279 rows affected in 4 s 54 ms
[2026-09-15 17:56:57:430] transaction committed: @console_45 [BOSH-STg-Prod]
[2026-09-15 17:57:21:528] BOSHSTG> select ERROR_DESC,COUNT(*) from RAW_LEADS_TBL
                               group by ERROR_DESC
                               order by ERROR_DESC desc
[2026-09-15 17:57:22:474] 9 rows retrieved starting from 1 in 946 ms (execution: 630 ms, fetching: 316 ms)
[2026-09-16 14:48:14:975] Connected
[2026-09-16 14:48:15:163] BOSHSTG> alter session set current_schema = BOSHSTG
[2026-09-16 14:48:15:350] completed in 187 ms
[2026-09-16 14:48:15:354] BOSHSTG> update RAW_LEADS_TBL set unique_seq_no = null
                                     where unique_seq_no is not null
[2026-09-16 14:48:42:003] 1,720,610 rows affected in 26 s 649 ms
[2026-09-16 14:48:46:355] transaction committed: @console_45 [BOSH-STg-Prod]
[2026-09-16 14:48:51:905] BOSHSTG> commit
[2026-09-16 14:48:52:092] completed in 187 ms

select ORA_HASH(FIRST_NM || LAST_NM || STREET_ADDR1 || CITY_NM || STATE_CD || coalesce(HOUSE_NO, '')),FIRST_NM,LAST_NM,STREET_ADDR1,CITY_NM,STATE_CD,HOUSE_NO from RAW_LEADS_TBL
where  trim(STREET_ADDR1) IS NOT NULL;

 UPDATE RAW_LEADS_TBL SET NAME_ADDRESS_HASH = ORA_HASH(FIRST_NM || LAST_NM || STREET_ADDR1 || CITY_NM || STATE_CD || coalesce(HOUSE_NO, ''))
      where  trim(STREET_ADDR1) IS NOT NULL;


 UPDATE RAW_LEADS_TBL SET ERROR_DESC = NULL
      where ERROR_DESC IS NOT NULL;

  UPDATE raw_leads_tbl
         SET ERROR_DESC = 'BOSH-406- Both Purchase_dt and Registration_dt are NULL'
       WHERE TRIM(purchase_dt) IS NULL AND TRIM(Registration_dt) IS NULL
        AND ERROR_DESC IS NULL;
--[2026-09-14 18:22:41:296] 285,094 rows affected in 7 s 938 ms
      COMMIT;


      --BOSH-1611
      UPDATE raw_leads_tbl
         SET ERROR_DESC = 'Leads with email ending with .ru or .ua domain'
        where EMAIL_ADDRESS_TX is not null
            and (upper(email_address_tx) like '%.RU' OR upper(email_address_tx) like '%.UA')
            and (LOWER(file_nm) LIKE '%%hc%%catchup%%'OR LOWER(file_nm) LIKE '%%hc%%')
            AND ERROR_DESC IS NULL;
--[2026-09-14 18:22:57:262] 2,305 rows affected in 913 ms

   --BOSH-2033
      UPDATE raw_leads_tbl
         SET ERROR_DESC = 'Leads with email having word “REGISTRIA”'
        where EMAIL_ADDRESS_TX is not null
            and (upper(email_address_tx) like '%REGISTRIA%'  )
            AND ERROR_DESC IS NULL;
-- [2026-09-14 18:23:10:353] 62 rows affected in 663 ms
      COMMIT;

      UPDATE raw_leads_tbl
         SET ERROR_DESC = 'Address is missing'
       WHERE TRIM(street_addr1) IS NULL AND TRIM(STREET_ADDR2) IS NULL
        AND ERROR_DESC IS NULL;
-- [2026-09-14 18:23:30:180] 795,675 rows affected in 10 s 114 ms


     -- BOSH-2170
      UPDATE raw_leads_tbl
         SET ERROR_DESC = 'count(distinct E_NUMBER||PURCHASE_DT) >= 10'
       WHERE  NAME_ADDRESS_HASH in (
               select NAME_ADDRESS_HASH
                from RAW_LEADS_TBL
                where STREET_ADDR1 is not null   and NAME_ADDRESS_HASH is not null
                group by NAME_ADDRESS_HASH
                having count(distinct E_NUMBER||coalesce(PURCHASE_DT, REGISTRATION_DT)) >= 10
           )
        AND ERROR_DESC IS NULL;
-- [2026-09-14 18:23:47:145] 98,750 rows affected in 2 s 338 ms
    -- BOSH-2170
    UPDATE raw_leads_tbl
        SET ERROR_DESC = 'BRAND  in -BALAY-CONSTRUCTA-NEFF-PROFILO-SIEMENS-'
    WHERE BRAND in ('BALAY','CONSTRUCTA','NEFF','PROFILO','SIEMENS')
    AND ERROR_DESC IS NULL;
-- [2026-09-14 18:24:02:169] 665 rows affected in 605 ms
    -- BOSH-2170
    UPDATE raw_leads_tbl
    SET ERROR_DESC = 'test Address'
    WHERE lower(STREET_ADDR1) like 'test%'
    AND ERROR_DESC IS NULL;
-- [2026-09-14 18:24:14:920] completed in 584 ms
    COMMIT;

      UPDATE raw_leads_tbl
                 SET ERROR_DESC = 'Invalid length of MANUFACTURING_DATE_FD'
               WHERE length(MANUFACTURING_DATE_FD) > 4 and  length(ltrim(MANUFACTURING_DATE_FD, '0')) > 4
                 AND ERROR_DESC IS NULL;
[2026-09-14 18:24:35:732] completed in 587 ms

select ERROR_DESC,COUNT(*) from RAW_LEADS_TBL
group by ERROR_DESC
order by ERROR_DESC desc
;

+-------------------------------------------------------+--------+
|ERROR_DESC                                             |COUNT(*)|
+-------------------------------------------------------+--------+
|null                                                   |538059  |New_counts
|null                                                   |538059  |Old_counts
|Address is missing                                     |795675  |New_counts
|Address is missing                                     |795675  |Old_counts
|BOSH-406- Both Purchase_dt and Registration_dt are NULL|285094  |New_counts
|BOSH-406- Both Purchase_dt and Registration_dt are NULL|285094  |Old_counts
|BRAND  in -BALAY-CONSTRUCTA-NEFF-PROFILO-SIEMENS-      |665     |New_counts
|BRAND  in -BALAY-CONSTRUCTA-NEFF-PROFILO-SIEMENS-      |7241    |Old_counts
|Leads with email ending with .ru or .ua domain         |2305    |New_counts
|Leads with email ending with .ru or .ua domain         |2305    |Old_counts
|Leads with email having word “REGISTRIA”               |62      |New_counts
|Leads with email having word “REGISTRIA”               |62      |Old_counts
|count(distinct E_NUMBER||PURCHASE_DT) >= 10            |98750   |New_counts
|count(distinct E_NUMBER||PURCHASE_DT) >= 10            |84507   |Old_counts
+-------------------------------------------------------+--------+
|count(distinct E_NUMBER||PURCHASE_DT) > 10             |2879    |OLD_ONLY_COUNT



select CLHT.FIRST_NM || CLHT.LAST_NM || ADDRESS_LINE1_TX || CLHT.CITY_NM || CLHT.STATE_CD as Name_Address, CLHT.FIRST_NM, CLHT.LAST_NM, ADDRESS_LINE1_TX, CLHT.CITY_NM, CLHT.STATE_CD,
       count(*), count(distinct VISITOR_XID), count(distinct CLHT.EMAIL_ADDRESS_TX), count(distinct PHONE_NO),
       count(distinct MODEL_NO || CLHT.PURCHASE_DT) from COMMON_LOAD_HOLD_TBL CLHT
            join RAW_LEADS_TBL RLT on RLT.UNIQUE_SEQ_NO = CLHT.UNIQUE_SEQ_NO
where RLT.ERROR_DESC = 'count(distinct E_NUMBER||PURCHASE_DT) >= 10' --and RLT.ERROR_DESC <> 'count(distinct E_NUMBER||PURCHASE_DT) > 10'
 group by CLHT.FIRST_NM || CLHT.LAST_NM || ADDRESS_LINE1_TX || CLHT.CITY_NM || CLHT.STATE_CD, CLHT.FIRST_NM, CLHT.LAST_NM, ADDRESS_LINE1_TX, CLHT.CITY_NM, CLHT.STATE_CD
 --having count(distinct MODEL_NO || PURCHASE_DT) > 6 --and count(distinct MODEL_NO) > 5
 order by count(distinct MODEL_NO || CLHT.PURCHASE_DT) desc;

+------------------------------+--------+-------+----------------+--------+--------+--------+--------------------------+------------------------------------+-----------------------+-----------------------------------------+
|NAME_ADDRESS                  |FIRST_NM|LAST_NM|ADDRESS_LINE1_TX|CITY_NM |STATE_CD|COUNT(*)|COUNT(DISTINCTVISITOR_XID)|COUNT(DISTINCTCLHT.EMAIL_ADDRESS_TX)|COUNT(DISTINCTPHONE_NO)|COUNT(DISTINCTMODEL_NO||CLHT.PURCHASE_DT)|
+------------------------------+--------+-------+----------------+--------+--------+--------+--------------------------+------------------------------------+-----------------------+-----------------------------------------+
|AB163 E 81ST STNEW YORKNY     |A       |B      |163 E 81ST ST   |NEW YORK|NY      |150     |1                         |0                                   |1                      |13                                       |
|ADAMKEREN6 RICHARD LNSYOSSETNY|ADAM    |KEREN  |6 RICHARD LN    |SYOSSET |NY      |140     |1                         |0                                   |1                      |13                                       |
+------------------------------+--------+-------+----------------+--------+--------+--------+--------------------------+------------------------------------+-----------------------+-----------------------------------------+

select STREET_ADDR1,EMAIL_ADDRESS_TX,TELEPHONE_NO,HOUSE_NO,COUNT(*)
from RAW_LEADS_TBL where FIRST_NM = 'ADAM' and LAST_NM = 'KEREN' AND CITY_NM = 'SYOSSET' and STATE_CD = 'NY'
group by STREET_ADDR1,EMAIL_ADDRESS_TX,TELEPHONE_NO,HOUSE_NO,ERROR_DESC
;
--and ERROR_DESC = 'count(distinct E_NUMBER||PURCHASE_DT) >= 10'
;