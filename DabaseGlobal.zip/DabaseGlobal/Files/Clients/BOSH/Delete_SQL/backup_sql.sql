--
-- create table CAMPAIGN_SPOOL_FILE_TBL_MAIL_AS_16_DEC_TO_15_JAN_BACKUP AS (
--     select * FROM bosh.CAMPAIGN_SPOOL_FILE_TBL a
--      where 1=1
--        and CHANNEL_NM = 'MAIL'
--        and GUARANTEE_ID like '%AS%'
--        and MAIL_DROP_DATE between date '2025-12-16' and date '2026-01-15');
-- [2025-12-17 15:54:22] 137,024 rows affected in 1 m 4 s 349 ms


SELECT MAIL_DROP_DATE, count(*),count(distinct REFERENCE_ID)*2 , count(distinct REFERENCE_ID) as REFERENCE_IDs, count(distinct QUICKREG_CODE) as QUICKREG_CODEs
  FROM bosh.CAMPAIGN_SPOOL_FILE_TBL a
 where 1=1
   and CHANNEL_NM = 'MAIL'
   and GUARANTEE_ID like '%AS%'
   and MAIL_DROP_DATE between date '2025-12-16' and date '2026-01-15'
   and  a.rowid IN (
            SELECT MIN(b.rowid)
            FROM bosh.CAMPAIGN_SPOOL_FILE_TBL b
                where 1=1
                   and b.CHANNEL_NM = 'MAIL'
                   and b.GUARANTEE_ID like '%AS%'
                   and b.MAIL_DROP_DATE between date '2025-12-16' and date '2026-01-15'
                GROUP BY b.REFERENCE_ID-- List all columns that define a duplicate
        )
    and  a.rowid NOT IN (
            SELECT MIN(b.rowid)
            FROM bosh.CAMPAIGN_SPOOL_FILE_TBL b
                where 1=1
                   and b.CHANNEL_NM = 'MAIL'
                   and b.GUARANTEE_ID like '%AS%'
                   and b.MAIL_DROP_DATE between date '2025-12-16' and date '2026-01-15'
                GROUP BY b.REFERENCE_ID-- List all columns that define a duplicate
                having COUNT(b.REFERENCE_ID) = 1
        )
group by MAIL_DROP_DATE order by MAIL_DROP_DATE;

-- +--------------+--------+-----------------------------+-------------+--------------+
-- |MAIL_DROP_DATE|COUNT(*)|COUNT(DISTINCTREFERENCE_ID)*2|REFERENCE_IDS|QUICKREG_CODES|
-- +--------------+--------+-----------------------------+-------------+--------------+
-- |2025-12-16    |13679   |27358                        |13679        |13679         |
-- |2025-12-23    |13679   |27358                        |13679        |13679         |
-- |2025-12-30    |13679   |27358                        |13679        |13679         |
-- |2026-01-06    |13677   |27354                        |13677        |13677         |
-- |2026-01-13    |13668   |27336                        |13668        |13668         |
-- +--------------+--------+-----------------------------+-------------+--------------+
--[2025-12-17 16:06:51] 68,382 rows affected in 3 m 11 s 763 ms
select 13679 + 13679 + 13679 + 13677 + 13668 from DUAL;--68382
select 68382*2 from dual;--136764


SELECT MAIL_DROP_DATE, count(*),count(distinct REFERENCE_ID)*2 , count(distinct REFERENCE_ID) as REFERENCE_IDs, count(distinct QUICKREG_CODE) as QUICKREG_CODEs
  FROM bosh.CAMPAIGN_SPOOL_FILE_TBL a
 where 1=1
   and CHANNEL_NM = 'MAIL'
   and GUARANTEE_ID like '%AS%'
   and MAIL_DROP_DATE between date '2025-12-16' and date '2026-01-15'
group by MAIL_DROP_DATE order by MAIL_DROP_DATE;
-- +--------------+--------+-----------------------------+-------------+--------------+
-- |MAIL_DROP_DATE|COUNT(*)|COUNT(DISTINCTREFERENCE_ID)*2|REFERENCE_IDS|QUICKREG_CODES|
-- +--------------+--------+-----------------------------+-------------+--------------+
-- |2025-12-16    |13729   |27458                        |13729        |13729         |
-- |2025-12-23    |13729   |27458                        |13729        |13729         |
-- |2025-12-30    |13728   |27456                        |13728        |13728         |
-- |2026-01-06    |13728   |27456                        |13728        |13728         |
-- |2026-01-13    |13728   |27456                        |13728        |13728         |
-- +--------------+--------+-----------------------------+-------------+--------------+