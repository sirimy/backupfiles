
[2025-12-17 16:03:38] Connected
BOSH> alter session set current_schema = BOSH
[2025-12-17 16:03:39] completed in 212 ms
BOSH> delete
        FROM bosh.CAMPAIGN_SPOOL_FILE_TBL a
       where 1=1
         and CHANNEL_NM = 'MAIL'
         and GUARANTEE_ID like '%AS%'
         and MAIL_DROP_DATE between date '2025-12-16' and date '2026-01-15'
         and  a.rowid IN (
                  SELECT MIN(b.rowid)
                  FROM bosh.CAMPAIGN_SPOOL_FILE_TBL b
                      where 1=1
                         and b.CHANNEL_NM = 'MAIL'
                         and b.GUARANTEE_ID like '%AS%'
                         and b.MAIL_DROP_DATE between date '2025-12-16' and date '2026-01-15'
                      GROUP BY b.REFERENCE_ID-- List all columns that define a duplicate
              )
          and  a.rowid NOT IN (
                  SELECT MIN(b.rowid)
                  FROM bosh.CAMPAIGN_SPOOL_FILE_TBL b
                      where 1=1
                         and b.CHANNEL_NM = 'MAIL'
                         and b.GUARANTEE_ID like '%AS%'
                         and b.MAIL_DROP_DATE between date '2025-12-16' and date '2026-01-15'
                      GROUP BY b.REFERENCE_ID-- List all columns that define a duplicate
                      having COUNT(b.REFERENCE_ID) = 1
              )
[2025-12-17 16:06:51] 68,382 rows affected in 3 m 11 s 763 ms
[2025-12-17 16:08:11] transaction committed: @console_128 [BOSH-Core-Prod]
BOSH> COMMIT
[2025-12-17 16:08:18] completed in 204 ms
[2025-12-17 16:09:00] transaction committed: @console_128 [BOSH-Core-Prod]
