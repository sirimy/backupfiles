create PROCEDURE         ORDER_EXTRACT_BUILDER
IS
    v_count                 NUMBER;
    v_validate_record_count  NUMBER;
    v_audit_key             NUMBER;

BEGIN

   v_audit_key := p_get_audit_key (p_program_nm => 'ORDER_EXTRACT', p_table_nm => 'ORDER_EXTRACT_TBL');

--     EXECUTE IMMEDIATE 'TRUNCATE TABLE ORDER_EXTRACT_HIST_TBL';
--     EXECUTE IMMEDIATE 'TRUNCATE TABLE ORDER_EXTRACT_TBL';
      DELETE FROM ORDER_EXTRACT_TBL WHERE  LEAD_SOURCE ='BSH BD';
      --DELETE FROM ORDER_EXTRACT_HIST_TBL;
     commit;

    INSERT ALL INTO ORDER_EXTRACT_TBL
    (    UNIQUE_IDENTIFIER
        ,TRANSACTION_TYPE
        ,WARRANTY_PURCHASE_PRICE_AMT
        ,WARRANTY_PURCHASE_TAX_AMT
        ,PAYMENT_SCHEDULE
        ,PAYMENT_PLAN_CD
        ,SKU_CD
        ,LEAD_SOURCE
        ,CURRENCY_CD
        ,PLAN_PURCHASE_DT
        ,PURCHASE_DT
        ,MODEL_NO
        ,MAKE
        ,SERIAL_NO
        ,EXTERNAL_CUSTOMER_NO
        ,FIRM_NM
        ,FIRST_NM
        ,MIDDLE_NM
        ,LAST_NM
        ,EMAIL_ADDRESS_TX
        ,PHONE_NO
        ,BILLING_ADDRESS_LINE1_TX
        ,BILLING_ADDRESS_LINE2_TX
        ,BILLING_CITY_NM
        ,BILLING_STATE_CD
        ,BILLING_ZIP
        ,BILLING_COUNTRY_NM
        ,SHIPPING_ADDRESS_LINE1_TX
        ,SHIPPING_ADDRESS_LINE2_TX
        ,SHIPPING_CITY_NM
        ,SHIPPING_STATE_CD
        ,SHIPPING_ZIP
        ,SHIPPING_COUNTRY_NM
        ,INSERT_AUDIT_KEY
        ,PROCESS_DT --
        ,PAID_TO_DATE --
        ,PRODUCT_PURCHASE_PRICE
        ,DNS_EMAIL
        ,NO_THIRD_PARTY_DATA
        ,CUSTOMER_APPLIANCE_ID
        ,COSMO_ID
        ,INSTALL_DT
        ,OWNERSHIP_INTENTION
        )
    VALUES
        (
         UNIQUE_IDENTIFIER
        ,TRANSACTION_TYPE
        ,WARRANTY_PURCHASE_PRICE_AMT
        ,WARRANTY_PURCHASE_TAX_AMT
        ,PAYMENT_SCHEDULE
        ,PAYMENT_PLAN_CD
        ,SKU_CD
        ,LEAD_SOURCE
        ,CURRENCY_CD
        ,PLAN_PURCHASE_DT
        ,PURCHASE_DT
        ,MODEL_NO
        ,MAKE
        ,SERIAL_NO
        ,EXTERNAL_CUSTOMER_NO
        ,FIRM_NM
        ,FIRST_NM
        ,MIDDLE_NM
        ,LAST_NM
        ,EMAIL_ADDRESS_TX
        ,PHONE_NO
        ,BILLING_ADDRESS_LINE1_TX
        ,BILLING_ADDRESS_LINE2_TX
        ,BILLING_CITY_NM
        ,BILLING_STATE_CD
        ,BILLING_ZIP
        ,BILLING_COUNTRY_NM
        ,SHIPPING_ADDRESS_LINE1_TX
        ,SHIPPING_ADDRESS_LINE2_TX
        ,SHIPPING_CITY_NM
        ,SHIPPING_STATE_CD
        ,SHIPPING_ZIP
        ,SHIPPING_COUNTRY_NM
        ,INSERT_AUDIT_KEY
        ,PROCESS_DT
        ,PAID_TO_DATE
        ,PRODUCT_PURCHASE_PRICE
        ,DNS_EMAIL
        ,NO_THIRD_PARTY_DATA
        ,CUSTOMER_APPLIANCE_ID
        ,COSMO_ID
        ,INSTALL_DT
        ,OWNERSHIP_INTENTION
        )
    SELECT  DISTINCT
            ORDER_KEY||'-'||ORDER_LINE_KEY AS UNIQUE_IDENTIFIER
           ,TRANSACTION_TYPE AS TRANSACTION_TYPE
           , RETAIL_PRICE - DISCOUNT_AMT AS WARRANTY_PURCHASE_PRICE_AMT
           , TAX_AMOUNT AS WARRANTY_PURCHASE_TAX_AMT
           ,'Single' AS PAYMENT_SCHEDULE
           , PAYMENT_PLAN_CD AS PAYMENT_PLAN_CD
           , SKU_CD
           ,'BSH BD' AS LEAD_SOURCE
           , CURRENCY_CD
           , CASE WHEN pricing_scheme_type = 'RN' THEN CONTRACT_EFFECTIVE_DT
                  ELSE  CONTRACT_PURCHASE_DATE
             END   AS PLAN_PURCHASE_DT
           , SI_PURCHASE_DT AS PURCHASE_DT --- PRODUCT_REGISTRATION_DT
            ,MODEL_NO
            ,brand_dsc AS MAKE
            ,SERIAL_NO
            ,EXTERNAL_CUSTOMER_NO
             ,CASE WHEN OWNERSHIP_INTENTION = 'RENTAL' OR OWNERSHIP_INTENTION =  'UNKNOWN' THEN FIRM_NAME --POINT [3][4][5][6]
                  --WHEN OWNERSHIP_INTENTION = 'HOMEOWNER' THEN ''
                  ELSE ''
                  END AS FIRM_NM
            --,FIRM_NAME AS  FIRM_NM
            ,CASE WHEN TRANSACTION_TYPE = 'I' THEN ''
                  WHEN OWNERSHIP_INTENTION = 'HOMEOWNER' THEN FIRST_NAME --POINT [3][4][5][6]
                  ELSE  ''
                 END AS FIRST_NM
            ,CASE WHEN TRANSACTION_TYPE = 'I' THEN ''
                  WHEN OWNERSHIP_INTENTION = 'HOMEOWNER' THEN MIDDLE_NM  --POINT [3][4][5][6]
                  END AS MIDDLE_NM
            --,MIDDLE_NM
            ,CASE WHEN TRANSACTION_TYPE = 'I' THEN ''
                  WHEN OWNERSHIP_INTENTION = 'HOMEOWNER' THEN LAST_NAME  --POINT [3][4][5][6]
                  END AS LAST_NM
            --,LAST_NAME AS  LAST_NM
            ,EMAIL_ADDRESS AS EMAIL_ADDRESS_TX
            ,TELEPHONE_NUMBER AS PHONE_NO
            ,BILLING_ADDRESS AS BILLING_ADDRESS_LINE1_TX
            ,BILLING_ADDRESS2 AS BILLING_ADDRESS_LINE2_TX
            ,BILLING_LOCALITY AS BILLING_CITY_NM
            ,BILLING_province AS BILLING_STATE_CD
            ,BILLING_POSTAL_CD AS BILLING_ZIP
            ,BILLING_COUNTRY_NM
            ,SHIPPING_ADDRESS AS SHIPPING_ADDRESS_LINE1_TX
            ,SHIPPING_ADDRESS2 AS SHIPPING_ADDRESS_LINE2_TX
            ,SHIPPING_LOCALITY AS SHIPPING_CITY_NM
            ,SHIPPING_province AS SHIPPING_STATE_CD
            ,SHIPPING_POSTAL_CD AS SHIPPING_ZIP
            ,SHIPPING_COUNTRY_NM
            ,V_AUDIT_KEY AS INSERT_AUDIT_KEY
            ,TRUNC(SYSDATE) AS PROCESS_DT
            ,TOTAL_PAID_TO_DATE AS PAID_TO_DATE
            ,PRODUCT_PURCHASE_PRICE
            ,DNS_EMAIL
            ,NO_THIRD_PARTY_DATA
            ,CUSTOMER_APPLIANCE_ID
            ,COSMO_ID --AS cosmoCustomerID
            ,INSTALL_DT
            ,OWNERSHIP_INTENTION
       FROM (
              SELECT
                      CASE WHEN BOET.UNIQUE_IDENTIFIER IS NULL THEN 'I'
                          ELSE  'U'
                     END AS TRANSACTION_TYPE,--POINT [1]
                      OT.ORDER_KEY
                     ,NULL  CONTRACT_XID,
                     CONTRACT_STATUS_KEY contract_status_cd,
                     ot.purchase_dt,
                     TO_CHAR (ot.purchase_dt, 'YYYYMMDD') contract_purchase_date,
                     TO_CHAR (oit.COVERAGE_start_DT, 'YYYYMMDD') CONTRACT_EFFECTIVE_DT,  ----TO_CHAR (cd.contract_start_dt, 'YYYYMMDD') contract_START_date,
                     TO_CHAR(oit.COVERAGE_EXP_DT,'YYYYMMDD')  CONTRACT_END_DATE, ----TO_CHAR (cd.contract_end_dt, 'YYYYMMDD') contract_end_date,
                     pr_scheme.pricing_scheme_type AS PRICING_SCHEME_TYPE, -- added by DS --BOSH-321
                     ot.currency_cd CURRENCY_CD,
                     vl.visitor_xid external_customer_no,
                     ad1.firm_nm  firm_name,
                     ad1.last_nm  last_name,
                     ad1.MIDDLE_NM  middle_nm,
                     ad1.first_nm  first_name,
                     ad1.address_line1_tx billing_address,
                     ad1.address_line2_tx billing_address2,
                     NULL address3,
                     ad1.city_nm billing_locality,
                     ad1.state_cd billing_province,
                     ad1.ZIP_CODE5_TX || ad1.ZIP_CODE4_TX as billing_POSTAL_CD,
                     decode(ad1.country_cd,'USA','US',ad1.country_cd) as billing_COUNTRY_NM,
                     ad2.address_line1_tx shipping_address,
                     ad2.address_line2_tx shipping_address2,
                     NULL address3,
                     ad2.city_nm shipping_locality,
                     ad2.state_cd shipping_province,
                     ad2.ZIP_CODE5_TX || ad2.ZIP_CODE4_TX as shipping_POSTAL_CD,
                     decode(ad2.country_cd,'USA','US',ad2.country_cd) as shipping_COUNTRY_NM,
                     ph.phone_no TELEPHONE_NUMBER,
                     em.EMAIL_ADDRESS_TX EMAIL_ADDRESS,
                     si.serial_no as serial_no,   --si.serial_no
                     NVL(sil.e_number, si.model_no) MODEL_NO,
                     bd.brand_nm as  MANUFACTURER_NAME,
                     decode(ol2.outlet_nm,null,ol1.outlet_nm,ol2.outlet_nm) as dealer_nm  --- ?
                     ,OiT.TAX_AMT TAX_AMOUNT
                     ,oit.PRICE_AMT + oit.tax_amt  TOTAL_PURCHASE_PRICE,
                     oit.PRICE_AMT RETAIL_PRICE,
                     NVL(ADJUSTED_AMT,oit.PRICE_AMT + oit.tax_amt) PAID_AMOUNT
                     ,NVL(os.SURCHARGE_AMT,0) * 4 SURCHARGE_AMOUNT
                     ,NVL(ADJUSTED_AMT,oit.PRICE_AMT + oit.tax_amt)  TOTAL_PAID_TO_DATE
                     ,NVL(sum_adjusted_amt,oit.PRICE_AMT + oit.tax_amt)  NEW_TOTAL_PAID_TO_DATE
                     ,OT.ORDER_DISCOUNT_AMT DISCOUNT_AMOUNT
                      ,ROUND(MONTHS_BETWEEN(TRUNC(COVERAGE_EXP_dT) , TRUNC(COVERAGE_START_DT))) TERM
                     ,NULL CONTRACT_KEY
                     ,CASE WHEN os.ORDER_KEY IS NOT NULL THEN 'FLEXPAY' ELSE NULL END PAYMENT_PLAN_CD
                     ,PAYMENT_TYPE
                     ,SALES_SOURCE_CD CHANNEL_CD
                     ,NULL REGISTRATION_ID
                     ,TRIM(SEQ_NO) AS SEQ_NO
                     ,DECODE(UPPER(PREFERENCE_VALUE),'Y','N','N','Y') OPT_OUT_IND
                     ,OIT.ORDER_LINE_KEY
                     ,bd.brand_dsc
                     ,pd.price_amt AS PRODUCT_PURCHASE_PRICE
                     ,TO_CHAR ((si.purchase_dt_key + date '1989-12-31'),'YYYYMMDD') SI_PURCHASE_DT
                     ,PL.POLICY_PRODUCT_XID as SKU_CD
                     ,nvl(dis.discount_amt,0) discount_amt
                    ,EMAIL_SUPPRESSION_CD DNS_EMAIL   -- BOSH-257
                    ,NULL NO_THIRD_PARTY_DATA         -- NULL FOR NOW BOSH-257
                    ,IOBJECT CUSTOMER_APPLIANCE_ID    -- BOSH-257
                    ,SIE.COSMO_ID
                    ,SIE.INSTALL_DT
                    ,SIE.OWNERSHIP_INTENTION
                     --BOSH-1117: join on product can return 2 rows, if both the old and new MSRP fall within the policy SKU range
                    ,row_number() over (partition by oit.ORDER_KEY, oit.ORDER_LINE_KEY  order by pd.PRICE_AMT desc) as product_rn
                from
                     p_order_tbl ot
                     join p_order_item_tbl oit on(ot.order_key=oit.order_key)
                     left join p_contract_order_tbl cot on(cot.order_key=ot.order_key)
                     left join p_contract_dim cd on(cd.contract_key=cot.contract_key)
                     --left join p_contract_lkp cl on(cd.contract_key=cl.contract_key and cl.source_system_cd=0)
                     --left join p_contract_registration_dim crd on(cd.contract_key=crd.contract_key)
                     join p_serialized_item_dim si on(oit.serialized_item_key=si.si_key)
                     left join p_serialized_item_ext_dim siE on(sie.si_key=si.si_key)
                     left join (select sil.si_key, --si_xid, substr(si_xid,1,instr(sil.si_xid,'/',1)-1), substr(si_xid,1,instr(sil.si_xid,'-',1)-1),
                                        min(
                                        case when sil.si_xid like '%xx%' then substr(si_xid,1,instr(sil.si_xid,'/',1)-1)
                                                                       else substr(si_xid,1,instr(sil.si_xid,'-',1)-1)
                                        end) as e_number from p_serialized_item_lkp sil
                                 where source_system_cd = 0
                                    --and si_key in (188640,207698)
                                 group by sil.si_key ) sil on ( si.si_key = sil.si_key)
                     ---
                     join p_policy_tbl pl on (oit.policy_key = pl.policy_key )
                     ---
--                      left join
--                                (select pd.PRODUCT_KEY, pd.MODEL_NO, pd.BRAND_KEY, pd.PRICE_AMT from p_product_dim pd ) pd
--                                on (si.product_key = pd.product_key and pd.price_amt between pl.MIN_PRODUCT_PRICE and pl.MAX_PRODUCT_PRICE )  --BOSH-475
                     ---
                     --the join above was replaced with this one as model MSRP has changed and for some of the models it isn't within the sold SKU price range now
                     --this join takes care of that and reads, whichever model is within SKU's pricing range...if both the old and new MSRPs are within SKUs price range
                     --then it is reading the one with the higher price...we will change this sql to read the latest/modified record in such cases
                     left join (
                               select pd.*, row_number() over (partition by pd.PRODUCT_KEY order by pd.PRICE_AMT desc) as rno
                                 from
                                       (select pdb.PRODUCT_KEY, pdb.MODEL_NO, pdb.BRAND_KEY, pdb.PRICE_AMT from bosh.PRODUCT_DIM_20230124 pdb   --BOSH-1117
                                        union
                                        select pd.PRODUCT_KEY, pd.MODEL_NO, pd.BRAND_KEY, pd.PRICE_AMT from p_product_dim pd
                                       ) pd
                              ) pd
                        on (si.product_key = pd.product_key and pd.price_amt between pl.MIN_PRODUCT_PRICE and pl.MAX_PRODUCT_PRICE )  --BOSH-475
                     ---
                     left join p_brand_dim bd on ( pd.brand_key = bd.brand_key)
                     --left join v_sku_lkp vsl on ( vsl.unique_identifier = oit.ORDER_KEY || '-' || oit.ORDER_LINE_KEY)
                     left join (
                                select vl.visitor_key, vl.visitor_xid from (
                                     select vl.visitor_key, vl.visitor_xid, row_number() over (partition by vl.visitor_key order by vl.insert_audit_key) as rno
                                      from p_visitor_lkp vl
                                     where vl.source_system_cd = 1
                                    ) vl
                                where rno = 1
                               ) vl on (ot.visitor_key = vl.visitor_key)
                     left join p_order_item_disc_info_lkp dis on (dis.order_key = oit.order_key and dis.order_line_key = oit.order_line_key)
                     join p_visitor_dim vd on(ot.visitor_key=vd.visitor_key)
                     left join p_visitor_preference_tbl pf on ( vd.visitor_key = pf.visitor_key and preference_type_key = 2)
                     join p_customer_dim cust on (vd.customer_key=cust.customer_key)
                     left join p_phone_dim ph on (cust.primary_phone_key=ph.phone_key and coalesce(ph.BAD_PHONE_IND, 'N') = 'N')
                     left join p_email_dim em on (cust.primary_email_key=em.email_key and coalesce(em.BAD_EMAIL_IND, 'N') = 'N')
                     ---
                     join p_shipping_info_tbl sit on ( ot.order_key = sit.order_key)
                     join p_address_dim ad2 on(sit.address_key=ad2.address_key)      --shipping info
                     ---
                     join p_billing_info_Tbl bit on (ot.order_key = bit.order_key)
                     join p_address_dim ad1 on(bit.address_key=ad1.address_key)      --billing info
                     ---
                     left join p_outlet_dim ol1 on(ot.outlet_key=ol1.outlet_key)
                     left join p_outlet_dim ol2 on(ol1.parent_outlet_key=ol2.outlet_key)
                     left join (select nvl(max(end_audit_key),0) end_audit_key from ORDER_extract_status_tbl where status='C') cest on (1=1)
                     left join v_ORDER_EXTRACT_SURCHARGE os on (oit.order_key = os.order_key and oit.order_line_key = os.order_line_key)
                     left join ( select order_key, sum(payment_amt), payment_type from p_payment_tx_tbl group by order_key, payment_type) pt on ( ot.order_key = pt.order_key)
                     ------ Cancellation Records
                     left join (select distinct s.order_key
                                  from p_scheduled_billing_fct s
                                       join p_order_tbl o on ( o.order_key = s.order_key)
                                 where s.order_key in (select distinct order_key from p_scheduled_billing_fct s where trim(payment_status_cd) = 'FLEXPAY_TERMINATED' )
                                   and trim(payment_status_cd) = 'PAID'
                               ) cncl on ( cncl.order_key = ot.order_key)
                     join (select start_audit_key, end_audit_key
                             from ORDER_extract_status_tbl
                            where status = 'I'
                          ) cest2
                          on (
                                 (coalesce(ot.sync_audit_key,ot.update_audit_key,ot.insert_audit_key) between cest2.start_audit_key and cest2.end_audit_key)
                              or (coalesce(oit.sync_audit_key,oit.update_audit_key,oit.insert_audit_key) between cest2.start_audit_key and cest2.end_audit_key)
                              or (coalesce(os.update_audit_key,os.insert_audit_key) between cest2.start_audit_key and cest2.end_audit_key)
                             )
                     left join  (select distinct ppd.policy_key,
                                        case when pricing_scheme_type IN ('AF', 'AM', 'EB') then 'AM' else pricing_scheme_type end as pricing_scheme_type
                                   from P_product_price_dim ppd
                                        join P_pricing_scheme_dim psd using (pricing_scheme_key)
                                        join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
                                  where psd.load_dt >= date '2017-11-01'   --to avoid dupes from older pricing_scheme_keys
                                ) pr_scheme  -- BOSH-321
                                on (pr_scheme.policy_key = pl.policy_key)
                     left join (-- left join for decide type I or type U
                                select BOET.UNIQUE_IDENTIFIER from (
                                     select p.UNIQUE_IDENTIFIER, row_number() over (partition by p.UNIQUE_IDENTIFIER order by p.insert_audit_key desc) as rno
                                     from BOSH.ORDER_EXTRACT_TBL p
                                     --where
                                    ) BOET
                                where rno = 1
                                MINUS
                                --BOSH-475: Added this to take care of situation when we have to re-submit a sale to Assurant
                                SELECT vrs.ORDER_KEY  || '-' || vrs.ORDER_LINE_KEY AS UNIQUE_IDENTIFIER
                                  FROM V_REJECTED_SALES vrs
                                MINUS
                                SELECT ORDER_KEY  || '-' || ORDER_LINE_KEY AS UNIQUE_IDENTIFIER
                                  FROM V_UNCONFIRMED_SALES
                               ) BOET on (BOET.UNIQUE_IDENTIFIER = OT.ORDER_KEY||'-'|| oit.ORDER_LINE_KEY)
                WHERE 1=1
                AND ot.SALES_SOURCE_CD = 'BUILDER_SALES'
            ) a

      WHERE 1 = 1
       and product_rn = 1

        /*   --BOSH-475
        AND NOT EXISTS ( SELECT 1 FROM P_ORDER_EXTRACT_HIST_TBL o
                          WHERE ORDER_KEY || '-' || ORDER_LINE_KEY = O.UNIQUE_IDENTIFIER
                         --AND CASE WHEN A.PAYMENT_PLAN_CD IS NULL THEN 'N' ELSE 'Y' END = o.flexpay_ind --- no need to send any updates even if flexpay
                         --AND TRIM(O.SEQ_NO) = NVL(A.SEQ_NO,1)  -- we dont want to send updates for flexpay
                         --AND TRANSACTION_TYPE = O.STATUS_CD  -- we will handle cancels with a different proc.
                       )
       */
    ;

    COMMIT;


    ---- Verify that the OWNERSHIP_INTENTION SHOULD NOT CHANGE FROM LAST SET
    --[1] This is first check for all

     select  COUNT(s.UNIQUE_IDENTIFIER) INTO v_validate_record_count
          from ORDER_EXTRACT_TBL s
               join  ( select * from (
                             select p.*, row_number() over (partition by p.UNIQUE_IDENTIFIER order by p.insert_audit_key desc) as rno
                             from BOSH.ORDER_EXTRACT_TBL p
                             where p.LEAD_SOURCE = 'BSH BD'
                            ) x
                        where rno = 1) c on c.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER

         where s.LEAD_SOURCE = 'BSH BD' and coalesce(s.OWNERSHIP_INTENTION,'XYZ') <> coalesce(c.OWNERSHIP_INTENTION,'XYZ')  -- This check is common for all
             ;
    IF v_validate_record_count > 0 THEN
        raise_application_error (-20001, 'OWNERSHIP_INTENTION CHANGED FROM LAST SENT IN THE PAST');
    END IF;

 ---- --[2]
    -- Last one in core is I and next one is U
    -- Name and All Adddress colloumn , Purchase date , Phone and Email

     select  COUNT(s.UNIQUE_IDENTIFIER)
      from ORDER_EXTRACT_TBL s
           join  ( select * from (
                         select p.*, row_number() over (partition by p.UNIQUE_IDENTIFIER order by p.insert_audit_key desc) as rno
                         from BOSH.ORDER_EXTRACT_TBL p
                         where p.LEAD_SOURCE = 'BSH BD'
                        ) x
                    where rno = 1) c on c.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
     where s.TRANSACTION_TYPE = 'U' and  c.TRANSACTION_TYPE = 'I' and s.LEAD_SOURCE = 'BSH BD' and s.INSTALL_DT is not null and c.INSTALL_DT is null AND
           (1=2
        or coalesce(s.PLAN_PURCHASE_DT,'XYZ') <> coalesce(c.PLAN_PURCHASE_DT,'XYZ')  --
        or coalesce(s.PURCHASE_DT,'XYZ') <> coalesce(c.PURCHASE_DT,'XYZ')
        or coalesce(s.EXTERNAL_CUSTOMER_NO,'XYZ') <> coalesce(c.EXTERNAL_CUSTOMER_NO,'XYZ')
        or coalesce(s.FIRM_NM,'XYZ') <> coalesce(c.FIRM_NM,'XYZ')
        or coalesce(s.FIRST_NM,'XYZ') <> coalesce(c.FIRST_NM,'XYZ')
        or coalesce(s.MIDDLE_NM,'XYZ') <> coalesce(c.MIDDLE_NM,'XYZ')
        or coalesce(s.LAST_NM,'XYZ') <> coalesce(c.LAST_NM,'XYZ')
        or coalesce(s.EMAIL_ADDRESS_TX,'XYZ') <> coalesce(c.EMAIL_ADDRESS_TX,'XYZ')
        or coalesce(s.PHONE_NO,'XYZ') <> coalesce(c.PHONE_NO,'XYZ')
        or coalesce(s.BILLING_ADDRESS_LINE1_TX,'XYZ') <> coalesce(c.BILLING_ADDRESS_LINE1_TX,'XYZ')
        or coalesce(s.BILLING_ADDRESS_LINE2_TX,'XYZ') <> coalesce(c.BILLING_ADDRESS_LINE2_TX,'XYZ')
        or coalesce(s.BILLING_CITY_NM,'XYZ') <> coalesce(c.BILLING_CITY_NM,'XYZ')
        or coalesce(s.BILLING_STATE_CD,'XYZ') <> coalesce(c.BILLING_STATE_CD,'XYZ')
        or coalesce(s.BILLING_ZIP,'XYZ') <> coalesce(c.BILLING_ZIP,'XYZ')
        or coalesce(s.BILLING_COUNTRY_NM,'XYZ') <> coalesce(c.BILLING_COUNTRY_NM,'XYZ')
        or coalesce(s.SHIPPING_ADDRESS_LINE1_TX,'XYZ') <> coalesce(c.SHIPPING_ADDRESS_LINE1_TX,'XYZ')
        or coalesce(s.SHIPPING_ADDRESS_LINE2_TX,'XYZ') <> coalesce(c.SHIPPING_ADDRESS_LINE2_TX,'XYZ')
        or coalesce(s.SHIPPING_CITY_NM,'XYZ') <> coalesce(c.SHIPPING_CITY_NM,'XYZ')
        or coalesce(s.SHIPPING_STATE_CD,'XYZ') <> coalesce(c.SHIPPING_STATE_CD,'XYZ')
        or coalesce(s.SHIPPING_ZIP,'XYZ') <> coalesce(c.SHIPPING_ZIP,'XYZ')
        or coalesce(s.SHIPPING_COUNTRY_NM,'XYZ') <> coalesce(c.SHIPPING_COUNTRY_NM,'XYZ')

        );
    IF v_validate_record_count > 0 THEN
        raise_application_error (-20001, 'Second QC Test Failed Last one in core is I and next one is U');
    END IF;


---- --[3]
    -- Check if any new value changed after 2 QC check

     select  COUNT(s.UNIQUE_IDENTIFIER)
      from ORDER_EXTRACT_TBL s
           join  ( select * from (
                         select p.*, row_number() over (partition by p.UNIQUE_IDENTIFIER order by p.insert_audit_key desc) as rno
                         from BOSH.ORDER_EXTRACT_TBL p
                         where p.LEAD_SOURCE = 'BSH BD'
                        ) x
                    where rno = 1) c on c.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
     where s.TRANSACTION_TYPE = 'U' and  c.TRANSACTION_TYPE = 'I' and s.LEAD_SOURCE = 'BSH BD' and s.INSTALL_DT is not null and c.INSTALL_DT is null AND
           (1=2
        or coalesce(s.WARRANTY_PURCHASE_PRICE_AMT,0) <> coalesce(c.WARRANTY_PURCHASE_PRICE_AMT,0)  --
        or coalesce(s.WARRANTY_PURCHASE_TAX_AMT,0) <> coalesce(c.WARRANTY_PURCHASE_TAX_AMT,0)  --
        or coalesce(s.PRODUCT_PURCHASE_PRICE,0) <> coalesce(c.PRODUCT_PURCHASE_PRICE,0)  --
        or coalesce(s.EXTERNAL_CUSTOMER_NO,'XYZ') <> coalesce(c.EXTERNAL_CUSTOMER_NO,'XYZ')
        or coalesce(s.FIRM_NM,'XYZ') <> coalesce(c.FIRM_NM,'XYZ')
        or coalesce(s.FIRST_NM,'XYZ') <> coalesce(c.FIRST_NM,'XYZ')
        or coalesce(s.MIDDLE_NM,'XYZ') <> coalesce(c.MIDDLE_NM,'XYZ')
        or coalesce(s.LAST_NM,'XYZ') <> coalesce(c.LAST_NM,'XYZ')
        or coalesce(s.EMAIL_ADDRESS_TX,'XYZ') <> coalesce(c.EMAIL_ADDRESS_TX,'XYZ')
        or coalesce(s.PHONE_NO,'XYZ') <> coalesce(c.PHONE_NO,'XYZ')
        or coalesce(s.BILLING_ADDRESS_LINE1_TX,'XYZ') <> coalesce(c.BILLING_ADDRESS_LINE1_TX,'XYZ')
        or coalesce(s.BILLING_ADDRESS_LINE2_TX,'XYZ') <> coalesce(c.BILLING_ADDRESS_LINE2_TX,'XYZ')
        or coalesce(s.BILLING_CITY_NM,'XYZ') <> coalesce(c.BILLING_CITY_NM,'XYZ')
        or coalesce(s.BILLING_STATE_CD,'XYZ') <> coalesce(c.BILLING_STATE_CD,'XYZ')
        or coalesce(s.BILLING_ZIP,'XYZ') <> coalesce(c.BILLING_ZIP,'XYZ')
        or coalesce(s.BILLING_COUNTRY_NM,'XYZ') <> coalesce(c.BILLING_COUNTRY_NM,'XYZ')
        or coalesce(s.SHIPPING_ADDRESS_LINE1_TX,'XYZ') <> coalesce(c.SHIPPING_ADDRESS_LINE1_TX,'XYZ')
        or coalesce(s.SHIPPING_ADDRESS_LINE2_TX,'XYZ') <> coalesce(c.SHIPPING_ADDRESS_LINE2_TX,'XYZ')
        or coalesce(s.SHIPPING_CITY_NM,'XYZ') <> coalesce(c.SHIPPING_CITY_NM,'XYZ')
        or coalesce(s.SHIPPING_STATE_CD,'XYZ') <> coalesce(c.SHIPPING_STATE_CD,'XYZ')
        or coalesce(s.SHIPPING_ZIP,'XYZ') <> coalesce(c.SHIPPING_ZIP,'XYZ')
        or coalesce(s.SHIPPING_COUNTRY_NM,'XYZ') <> coalesce(c.SHIPPING_COUNTRY_NM,'XYZ')

        );
    IF v_validate_record_count > 0 THEN
        raise_application_error (-20001, 'Third QC Test Failed : Some new value changed fromlast set');
    END IF;

    --delete records, which have been extracted in the past already
    DELETE FROM ORDER_EXTRACT_TBL
     WHERE UNIQUE_IDENTIFIER IN
               (
                SELECT s.UNIQUE_IDENTIFIER
                  FROM ORDER_EXTRACT_TBL s
                 WHERE s.LEAD_SOURCE ='BSH BD' AND EXISTS (
                          SELECT 1 FROM BOSH.ORDER_EXTRACT_TBL p
                           WHERE  p.LEAD_SOURCE ='BSH BD' AND p.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER and p.TRANSACTION_TYPE = s.TRANSACTION_TYPE)
                MINUS
                --BOSH-475: Added this to take care of situation when we have to re-submit a sale to Assurant
                SELECT vrs.ORDER_KEY  || '-' || vrs.ORDER_LINE_KEY AS UNIQUE_IDENTIFIER
                  FROM V_REJECTED_SALES vrs
                MINUS
                SELECT ORDER_KEY  || '-' || ORDER_LINE_KEY AS UNIQUE_IDENTIFIER
                  FROM V_UNCONFIRMED_SALES
                )
        AND LEAD_SOURCE ='BSH BD';

    COMMIT;

    /*
    ---- Verify that the order_key doesn't have two record types
    --Seems now this scenario will never arise after having added the Delete stmt above
    SELECT COUNT(*) INTO v_validate_record_type
      FROM (
            SELECT UNIQUE_IDENTIFIER
              FROM ORDER_EXTRACT_TBL s
             WHERE EXISTS (
                      SELECT 1 FROM BOSH.ORDER_EXTRACT_TBL p
                       WHERE p.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER)
            MINUS
            --BOSH-475: Added this to take care of situation when we have to re-submit a sale to Assurant
            SELECT ORDER_KEY  || '-' || ORDER_LINE_KEY AS UNIQUE_IDENTIFIER
              FROM V_REJECTED_SALES
            MINUS
            SELECT ORDER_KEY  || '-' || ORDER_LINE_KEY AS UNIQUE_IDENTIFIER
              FROM V_UNCONFIRMED_SALES
            );

    IF v_validate_record_type > 0 THEN
        raise_application_error (-20001, 'UNIQUE_IDENTIFIER ALREADY SENT IN THE PAST');
    END IF;
    */

    --since we are using a UNION on 2 instances of product table so sometimes it will result in dupes. Cleaning up those dupes.
    --This check is not reqd anymore --AJ on 12/28/2020
     /*DELETE FROM ORDER_EXTRACT_TBL
     WHERE UNIQUE_IDENTIFIER IN (
                SELECT UNIQUE_IDENTIFIER
                  FROM ORDER_EXTRACT_TBL
                 GROUP BY UNIQUE_IDENTIFIER
                 HAVING COUNT(DISTINCT PRODUCT_PURCHASE_PRICE) > 1 AND COUNT(DISTINCT SKU_CD) = 1
                )
       AND ROWID NOT IN (
                SELECT   MIN(ROWID)
                FROM     ORDER_EXTRACT_TBL
                GROUP BY UNIQUE_IDENTIFIER
                HAVING   COUNT(DISTINCT PRODUCT_PURCHASE_PRICE) > 1 AND COUNT(DISTINCT SKU_CD) = 1
                );

    COMMIT;
      */

    /*
    --Verify that there is no mismatch between model master and pricing
    SELECT count(distinct UNIQUE_IDENTIFIER) into v_count
    FROM   order_extract_tbl oet
           JOIN bosh.order_item_tbl oit on oit.order_key || '-' || oit.order_line_key = oet.UNIQUE_IDENTIFIER
           join bosh.product_dim pr on pr.MODEL_NO =  case when oet.MODEL_NO like '%/%' then substr(oet.MODEL_NO, 1, instr(oet.MODEL_NO,'/') -1) else oet.MODEL_NO end
           join bosh.policy_tbl pol on pol.POLICY_PRODUCT_XID = oet.SKU_CD
    where 1=1
    --and   oet.PRODUCT_PURCHASE_PRICE <> pr.PRICE_AMT
    and   pr.PRICE_AMT not between pol.MIN_PRODUCT_PRICE and pol.MAX_PRODUCT_PRICE;
    */

    --BOSH-1117: Replaced sql above with this one    --AJ on 1/25/2023
    --Verify that there is no mismatch between model master and pricing
    v_count := 0;
    SELECT count(distinct UNIQUE_IDENTIFIER) into v_count
    FROM   ORDER_EXTRACT_TBL oet
           JOIN bosh.order_item_tbl oit on oit.order_key || '-' || oit.order_line_key = oet.UNIQUE_IDENTIFIER
           join bosh.policy_tbl pol on pol.POLICY_KEY = oit.policy_key
    where 1=1 AND oet.LEAD_SOURCE ='BSH BD'
      and not exists (
                     select 1 from
                             (select pdb.PRODUCT_KEY, pdb.MODEL_NO, pdb.BRAND_KEY, pdb.PRICE_AMT from bosh.PRODUCT_DIM_20230124 pdb
                                 union
                              select pd.PRODUCT_KEY, pd.MODEL_NO, pd.BRAND_KEY, pd.PRICE_AMT from p_product_dim pd
                             ) pd
                      where case when oet.MODEL_NO like '%/%' then substr(oet.MODEL_NO, 1, instr(oet.MODEL_NO,'/') -1) else oet.MODEL_NO end = pd.MODEL_NO
                        and PRICE_AMT between pol.MIN_PRODUCT_PRICE and pol.MAX_PRODUCT_PRICE
                    );


    IF v_count > 0 THEN
        raise_application_error (-20002, 'pr.PRICE_AMT not between pol.MIN_PRODUCT_PRICE and pol.MAX_PRODUCT_PRICE IN BSH-BD: ' || to_char(v_count));
    END IF;



    ---- Verify that there are no dupes on sku_no per unique_identifier
    v_count := 0;
    select count(1) into v_count
    from ( select UNIQUE_IDENTIFIER from order_Extract_Tbl s where s.LEAD_SOURCE ='BSH BD' group by UNIQUE_IDENTIFIER having count(sku_cd) > 1 );

    IF v_count > 0 THEN
        raise_application_error (-20003, 'MULTIPLE SKU_CD PER UNIQUE_IDENTIFIER EXISTS IN BSH-BD: ' || to_char(v_count));
    END IF;



    ---- Verify that all eligible sales have been accounted for
    v_count := 0;
    SELECT count( UNIQUE_IDENTIFIER) into v_count
    from (
            select oit.ORDER_KEY || '-' || ORDER_LINE_KEY AS UNIQUE_IDENTIFIER
              from Bosh.order_tbl ot join Bosh.ORDER_ITEM_TBL oit ON ( ot.order_key = oit.order_key )
             where 1 = 1
               and sub_total_amt > 1 and PRICE_AMT > 1
               and SALES_SOURCE_CD = 'BUILDER_SALES'
            --   and trunc(ot.purchase_dt) >= date '2022-01-01'
            minus
            (select UNIQUE_IDENTIFIER from ORDER_EXTRACT_TBL where LEAD_SOURCE ='BSH BD'
            union all
            select UNIQUE_IDENTIFIER from bosh.ORDER_EXTRACT_TBL where LEAD_SOURCE ='BSH BD'
            )
        );
    --no rows


    IF v_count > 0 THEN
        raise_application_error (-20003, 'There are sales, which have not been extracted IN BSH-BD: ' || to_char(v_count));
    END IF;



    INSERT  INTO ORDER_EXTRACT_HIST_TBL
    SELECT  UNIQUE_IDENTIFIER, TRANSACTION_TYPE, nvl(TRIM(seq_no), 1), CASE WHEN PAYMENT_PLAN_CD IS NULL THEN 'N' ELSE 'Y' END, PROCESS_DT, INSERT_AUDIT_KEY
      FROM  order_extract_tbl
     WHERE  TRUNC(PROCESS_DT) = TRUNC(SYSDATE) and LEAD_SOURCE ='BSH BD';

    COMMIT;


END;
/

