SELECT ox.customer_id,ad.first_nm,ad.last_nm,ad.locality_nm,pt.phone_no,t.*
 FROM ( SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
 			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'
 				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP)
 			          ELSE
 				       date_trunc('day', LOCALTIMESTAMP)+interval '1 days'
 			     END AS coverage_start_dt,
 			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
 			          THEN
 			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
 			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
                ELSE
 				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
 			     END AS coverage_end_dt,
 			     ppt.BASE_PRICE_AMT,
 			     ppt.TERM_MONTHS,
 			     si.purchase_dt,
 			     pol.age,
 			     round(DATE_PART('day', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
 			     pol.description as policy_description
 			FROM
 			(SELECT * from serialized_item where LATEST_COVERAGE_EXP_DT   < LOCALTIMESTAMP and last_updated_ts > '2015-12-19 00:00:00.000000'
 			                                 and latest_coverage_type_id = 1
 			                                  and EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400::int > 22
 			                                 and EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400::int < 220
 			                               order by random()  LIMIT 50) si
 			JOIN pricing_scheme_lkp psl
 			ON(si.latest_coverage_type_id=psl.latest_coverage_type_id and
 			(EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
 			between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
 			JOIN product_price_tbl ppt ON
 			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') -- BOSH-361
 			JOIN policy pol ON
 			(ppt.POLICY_ID=pol.POLICY_ID
 			)
 			JOIN policy_ext pex on
 			    (pex.POLICY_ID=pol.POLICY_ID and channels = 'OOW' )
 			JOIN product_ext PE ON
 			(PE.product_id = ppt.product_id)
 			join pricing_scheme_tbl pst
 	                on pst.pricing_scheme_id = ppt.pricing_scheme_id
 			WHERE  si.LATEST_COVERAGE_EXP_DT   < LOCALTIMESTAMP   AND --BOSH-1733
 			PE.PRODUCT_COVERAGE_END_DT  >= CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
 			          THEN
 			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
 			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
 ELSE
 				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
 			        END
 			        ---
 			    and case when substr(pst.description, 1, 2) = 'RN' then
 					  round(DATE_PART('day', si.latest_coverage_exp_dt - si.purchase_dt)/365)
 				     else 0
 				end = coalesce (pol.age, 0)
 			) t
 LEFT join ownership_xref ox on ox.serialized_item_id = t.serialized_item_id
 LEFT join customer_tbl ct on ct.customer_id = ox.customer_id
 LEFT join address_tbl ad on ad.address_id = ct.primary_address_id
 LEFT join phone_tbl pt on pt.phone_id = ct.primary_phone_id
 where (coverage_end_dt - purchase_dt)  <= interval '3650 day'    --total coverage must be less than 10 years for all brands
 ORDER BY TERM_MONTHS ASC;
