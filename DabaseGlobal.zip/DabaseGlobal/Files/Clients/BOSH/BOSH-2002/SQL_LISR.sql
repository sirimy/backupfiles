

select * from order_tbl where last_updated_ts > '2025-12-02 15:42:34.000000';
select * from contract_order where last_updated_ts > '2025-12-02 15:42:34.000000';
select * from contract where last_updated_ts > '2025-12-02 15:42:34.000000';


select * from BUNDLE_OFFER_LOG_TBL where log_date > '2025-12-02 05:38:45.306394' order by log_date desc;

select oft.*, p.description, t.day
from offer_item_tbl oft join policy p on oft.policy_id = p.policy_id join term t on p.term_id = t.term_id
where offer_id IN (
         select ot.offer_id from offer_tbl ot where customer_id = 5103536
                                        and offer_start_utc_ts >= current_date - interval '1' day
    )
and offer_id < 500000
and active_ind = 'Y'
order by offer_id, t.day, policy_id;

select * from OFFER_LOG_TBL where log_date > '2025-12-04 05:38:45.306394' order by log_date desc;
-- +--------+------------------+-----------+---------+--------------------+--------------------------+------+----------+
-- |offer_id|serialized_item_id|customer_id|status_cd|status_msg          |log_date                  |job_id|created_by|
-- +--------+------------------+-----------+---------+--------------------+--------------------------+------+----------+
-- |NULL    |2221102           |320436     |E        |Product Not Eligible|2025-12-04 09:48:05.749594|164315|SYSTEM    |-- last status
-- +--------+------------------+-----------+---------+--------------------+--------------------------+------+----------+
-- +--------+------------------+-----------+---------+-------------------------+--------------------------+------+----------+
-- |offer_id|serialized_item_id|customer_id|status_cd|status_msg               |log_date                  |job_id|created_by|-- from here new
-- +--------+------------------+-----------+---------+-------------------------+--------------------------+------+----------+
-- |NULL    |19653160          |4584116    |E        |Product Not Eligible     |2025-12-05 06:54:52.272742|164320|SYSTEM    |
-- |NULL    |19653160          |4584116    |S        |Job Started              |2025-12-05 06:54:52.214136|164320|SYSTEM    |
-- |NULL    |20054822          |4584116    |E        |Product Not Eligible     |2025-12-05 06:54:52.195836|164319|SYSTEM    |
-- |NULL    |20054822          |4584116    |S        |Job Started              |2025-12-05 06:54:52.138632|164319|SYSTEM    |
-- |NULL    |25598810          |4584116    |S        |Job Started              |2025-12-05 06:54:52.033593|164318|SYSTEM    |
-- |65512   |25598810          |4584116    |F        |Offer Sucessfully Created|2025-12-05 06:54:52.025617|164318|SYSTEM    |
-- |NULL    |25628414          |4584116    |S        |Job Started              |2025-12-05 06:54:51.876731|164317|SYSTEM    |
-- |65511   |25628414          |4584116    |F        |Offer Sucessfully Created|2025-12-05 06:54:51.843321|164317|SYSTEM    |
-- +--------+------------------+-----------+---------+-------------------------+--------------------------+------+----------+

+--------+------------------+-----------+---------+-------------------------+--------------------------+------+----------+
|offer_id|serialized_item_id|customer_id|status_cd|status_msg               |log_date                  |job_id|created_by|
+--------+------------------+-----------+---------+-------------------------+--------------------------+------+----------+
|NULL    |20433424          |4777730    |S        |Job Started              |2025-12-05 07:10:39.469836|164326|SYSTEM    |
|65518   |20433424          |4777730    |F        |Offer Sucessfully Created|2025-12-05 07:10:39.462529|164326|SYSTEM    |
|NULL    |20460362          |4777730    |S        |Job Started              |2025-12-05 07:10:39.325384|164325|SYSTEM    |
|65517   |20460362          |4777730    |F        |Offer Sucessfully Created|2025-12-05 07:10:39.317117|164325|SYSTEM    |
|NULL    |20452366          |4777730    |S        |Job Started              |2025-12-05 07:10:39.187782|164324|SYSTEM    |
|65516   |20452366          |4777730    |F        |Offer Sucessfully Created|2025-12-05 07:10:39.177590|164324|SYSTEM    |
|NULL    |20454432          |4777730    |S        |Job Started              |2025-12-05 07:10:39.009922|164323|SYSTEM    |
|65515   |20454432          |4777730    |F        |Offer Sucessfully Created|2025-12-05 07:10:38.974865|164323|SYSTEM    |
+--------+------------------+-----------+---------+-------------------------+--------------------------+------+----------+




 SELECT ox.customer_id,ad.first_nm,ad.last_nm,ad.locality_nm,pt.phone_no,t.*
 FROM ( SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
 			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'
 				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP)
 			          ELSE
 				       date_trunc('day', LOCALTIMESTAMP)+interval '1 days'
 			     END AS coverage_start_dt,
 			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
 			          THEN
 			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
 			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
                ELSE
 				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
 			     END AS coverage_end_dt,
 			     ppt.BASE_PRICE_AMT,
 			     ppt.TERM_MONTHS,
 			     si.purchase_dt,
 			     pol.age,
 			     round(DATE_PART('day', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
 			     pol.description as policy_description
 			FROM
 			(SELECT * from serialized_item where LATEST_COVERAGE_EXP_DT   > LOCALTIMESTAMP and last_updated_ts > '2015-12-19 00:00:00.000000'
 			                                 and latest_coverage_type_id = 1
 			                                 and EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400::int > -732
 			                                 and EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400::int < -180
 			                               order by random() LIMIT 5000 ) si
 			JOIN pricing_scheme_lkp psl
 			ON(si.latest_coverage_type_id=psl.latest_coverage_type_id and
 			(EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
 			            between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
 			JOIN product_price_tbl ppt ON
 			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') -- BOSH-361
 			JOIN policy pol ON
 			(ppt.POLICY_ID=pol.POLICY_ID
 			)
 			JOIN policy_ext pex on
 			    (pex.POLICY_ID=pol.POLICY_ID and channels <> 'OOW' )
 			JOIN product_ext PE ON
 			(PE.product_id = ppt.product_id)
 			join pricing_scheme_tbl pst
 	                on pst.pricing_scheme_id = ppt.pricing_scheme_id
 			WHERE  si.LATEST_COVERAGE_EXP_DT   > LOCALTIMESTAMP   AND --BOSH-1733
 			PE.PRODUCT_COVERAGE_END_DT  >= CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
 			          THEN
 			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
 			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
 ELSE
 				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
 			        END
 			        ---
 			    and case when substr(pst.description, 1, 2) = 'RN' then
 					  round(DATE_PART('day', si.latest_coverage_exp_dt - si.purchase_dt)/365)
 				     else 0
 				end = coalesce (pol.age, 0)
 			) t
 LEFT join ownership_xref ox on ox.serialized_item_id = t.serialized_item_id
 LEFT join customer_tbl ct on ct.customer_id = ox.customer_id
 LEFT join address_tbl ad on ad.address_id = ct.primary_address_id
 LEFT join phone_tbl pt on pt.phone_id = ct.primary_phone_id
 where (coverage_end_dt - purchase_dt)  <= interval '3650 day'      --total coverage must be less than 10 years for all brands
 and ct.customer_id in (select t2.customer_id from customer_list_oow t2)
 ORDER BY TERM_MONTHS ASC;

select * from pricing_scheme_lkp;

select distinct channels from policy_ext where channels = 'OOW';

select * from BUNDLE_OFFER_LOG_TBL where log_date > '2025-12-04 05:38:45.306394' order by log_date desc;
-- +------+------------------+-----------+------------+----------------------------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
-- |job_id|serialized_item_id|customer_id|offer_status|error_desc                                                                        |existing_offer_id|created_by                       |log_date                  |offer_id|
-- +------+------------------+-----------+------------+----------------------------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
-- |164313|20759848          |4839342    |FE          |No offer got created. Error Raised: Unable to create offer: Product Not Eligible. |NULL             |abhay.jain@domesticandgeneral.com|2025-12-04 08:29:13.096574|BWU4W37 |
-- +------+------------------+-----------+------------+----------------------------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
-- +------+------------------+-----------+------------+----------------------------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
-- |job_id|serialized_item_id|customer_id|offer_status|error_desc                                                                        |existing_offer_id|created_by                       |log_date                  |offer_id|
-- +------+------------------+-----------+------------+----------------------------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
-- |164322|20054822          |4584116    |FE          |No offer got created. Error Raised: Unable to create offer: Product Not Eligible. |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:25.224897|B7QFUHR |
-- |164322|20054822          |4584116    |E           |Unable to create offer: Product Not Eligible.                                     |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:25.212586|B7QFUHR |
-- |164322|20054822          |4584116    |O           |Offer Items creating for serial item 20054822 and offer 65514                     |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:25.196868|B7QFUHR |
-- |164322|19653160          |4584116    |E           |Unable to create offer: Product Not Eligible.                                     |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:25.181170|B7QFUHR |
-- |164322|19653160          |4584116    |O           |Offer Items creating for serial item 19653160 and offer 65514                     |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:25.164539|B7QFUHR |
-- |164322|0                 |4584116    |S           |OOW-process started                                                               |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:22.300389|0       |
-- |164321|25598810          |4584116    |FO          |INWARRANTY-Final new Offer returned to App : B7VZKZ6                              |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:13.963755|B7VZKZ6 |
-- |164321|25598810          |4584116    |O           |Offer Items creating for serial item 25598810 and offer 65513                     |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:13.944936|B7VZKZ6 |
-- |164321|25628414          |4584116    |O           |Offer Items creating for serial item 25628414 and offer 65513                     |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:13.924321|B7VZKZ6 |
-- |164321|0                 |4584116    |S           |INWARRANTY-process started                                                        |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 07:06:10.534075|0       |
-- +------+------------------+-----------+------------+----------------------------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
-- +------+------------------+-----------+------------+--------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
-- |job_id|serialized_item_id|customer_id|offer_status|error_desc                                                    |existing_offer_id|created_by                       |log_date                  |offer_id|
-- +------+------------------+-----------+------------+--------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
-- |164340|169558173         |5138234    |FO          |INWARRANTY-Final new Offer returned to App : B8ELDBR          |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 11:08:40.376569|B8ELDBR |
-- |164340|169558173         |5138234    |O           |Offer Items creating for serial item 169558173 and offer 65526|NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 11:08:40.357969|B8ELDBR |
-- |164340|22424236          |5138234    |O           |Offer Items creating for serial item 22424236 and offer 65526 |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 11:08:40.323811|B8ELDBR |
-- |164340|0                 |5138234    |S           |INWARRANTY-process started                                    |NULL             |abhay.jain@domesticandgeneral.com|2025-12-05 11:08:37.404028|0       |
-- +------+------------------+-----------+------------+--------------------------------------------------------------+-----------------+---------------------------------+--------------------------+--------+
select pex.channels,pex.brand,oft.*, p.description, t.day
from offer_item_tbl oft join policy p on oft.policy_id = p.policy_id join term t on p.term_id = t.term_id
join policy_ext pex on pex.policy_id = p.policy_id
where offer_id IN (
         select ot.offer_id from offer_tbl ot where customer_id = 5082926
                                        and offer_start_utc_ts >= current_date - interval '1' day
    )
and offer_id < 500000
and active_ind = 'Y' and oft.last_updated_by ='Bundled Offer'
order by offer_id, t.day, policy_id;
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+--------+
-- |serialized_item_id|customer_id|offer_status|error_desc                                                   |log_date                  |offer_id|
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+--------+
-- |21968726          |5082926    |FO          |INWARRANTY-Final new Offer returned to App : B42CJN8         |2025-12-05 11:36:11.629387|B42CJN8 |
-- |21968726          |5082926    |O           |Offer Items creating for serial item 21968726 and offer 65529|2025-12-05 11:36:11.597605|B42CJN8 |
-- |21963674          |5082926    |O           |Offer Items creating for serial item 21963674 and offer 65529|2025-12-05 11:36:11.571441|B42CJN8 |
-- |21959492          |5082926    |O           |Offer Items creating for serial item 21959492 and offer 65529|2025-12-05 11:36:11.540248|B42CJN8 |
-- |21968716          |5082926    |O           |Offer Items creating for serial item 21968716 and offer 65529|2025-12-05 11:36:11.509264|B42CJN8 |
-- |23674680          |5082926    |E           |Serialized Item not eligible for offer creation              |2025-12-05 11:36:08.073610|        |
-- |0                 |5082926    |S           |INWARRANTY-process started                                   |2025-12-05 11:36:08.062876|0       |
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+--------+
+--------+---------+--------+-------------+-------------+---------+---------+------------------+--------------------------+--------------------------+
|channels|brand    |offer_id|offer_line_id|offer_type_cd|policy_id|price_amt|serialized_item_id|coverage_start_dt         |coverage_exp_dt           |
+--------+---------+--------+-------------+-------------+---------+---------+------------------+--------------------------+--------------------------+
|AM EB   |Thermador|65529   |1            |PolicyOffer  |9499     |116.55   |21968716          |2025-12-12 00:00:00.000000|2026-12-12 00:00:00.000000|
|AM EB   |Thermador|65529   |2            |PolicyOffer  |9814     |311.85   |21968716          |2025-12-12 00:00:00.000000|2028-12-12 00:00:00.000000|
|AM EB   |Thermador|65529   |3            |PolicyOffer  |9912     |357.00   |21968716          |2025-12-12 00:00:00.000000|2029-12-12 00:00:00.000000|
|AM EB   |Thermador|65529   |4            |PolicyOffer  |10004    |389.38   |21968716          |2025-12-12 00:00:00.000000|2030-12-12 00:00:00.000000|
|AM EB   |Thermador|65529   |5            |PolicyOffer  |10033    |105.00   |21959492          |2025-12-12 00:00:00.000000|2026-12-12 00:00:00.000000|
|AM EB   |Thermador|65529   |6            |PolicyOffer  |10111    |283.50   |21959492          |2025-12-12 00:00:00.000000|2028-12-12 00:00:00.000000|
|AM EB   |Thermador|65529   |7            |PolicyOffer  |10171    |314.65   |21959492          |2025-12-12 00:00:00.000000|2029-12-12 00:00:00.000000|
|AM EB   |Thermador|65529   |8            |PolicyOffer  |10182    |337.40   |21959492          |2025-12-12 00:00:00.000000|2030-12-12 00:00:00.000000|
|AM EB   |Thermador|65529   |9            |PolicyOffer  |9499     |116.55   |21963674          |2025-12-20 00:00:00.000000|2026-12-20 00:00:00.000000|
|AM EB   |Thermador|65529   |10           |PolicyOffer  |9814     |311.85   |21963674          |2025-12-20 00:00:00.000000|2028-12-20 00:00:00.000000|
|AM EB   |Thermador|65529   |11           |PolicyOffer  |9912     |357.00   |21963674          |2025-12-20 00:00:00.000000|2029-12-20 00:00:00.000000|
|AM EB   |Thermador|65529   |12           |PolicyOffer  |10004    |389.38   |21963674          |2025-12-20 00:00:00.000000|2030-12-20 00:00:00.000000|
|AM EB   |Thermador|65529   |13           |PolicyOffer  |9506     |267.75   |21968726          |2025-12-20 00:00:00.000000|2026-12-20 00:00:00.000000|
|AM EB   |Thermador|65529   |14           |PolicyOffer  |9821     |724.50   |21968726          |2025-12-20 00:00:00.000000|2028-12-20 00:00:00.000000|
|AM EB   |Thermador|65529   |15           |PolicyOffer  |9981     |792.93   |21968726          |2025-12-20 00:00:00.000000|2029-12-20 00:00:00.000000|
|AM EB   |Thermador|65529   |16           |PolicyOffer  |10011    |840.00   |21968726          |2025-12-20 00:00:00.000000|2030-12-20 00:00:00.000000|
+--------+---------+--------+-------------+-------------+---------+---------+------------------+--------------------------+--------------------------+


select * from serialized_item where serialized_item_id = 21963674;
-- +------------------+-----------+--------------------------+----------+
-- |serialized_item_id|serial_num |purchase_dt               |product_id|
-- +------------------+-----------+--------------------------+----------+
-- |21963674          |0309-000005|2023-12-20 00:00:00.000000|7289508   |
-- +------------------+-----------+--------------------------+----------+
select * from product_price_tbl where product_id = 7289508 and policy_id = 9499;
-- +---------+-----------------+----------+--------------+-----------+
-- |policy_id|pricing_scheme_id|product_id|base_price_amt|term_months|
-- +---------+-----------------+----------+--------------+-----------+
-- |9499     |243              |7289508   |116.55        |12         |
-- |9499     |244              |7289508   |93.24         |12         |
-- +---------+-----------------+----------+--------------+-----------+




select * from serialized_item where serialized_item_id = 27434710;
-- +------------------+-----------+--------------------------+----------+---------------+
-- |serialized_item_id|serial_num |purchase_dt               |product_id|last_updated_by|
-- +------------------+-----------+--------------------------+----------+---------------+
-- |27434710          |0502-003251|2025-07-24 00:00:00.000000|25761270  |bosh           |
-- +------------------+-----------+--------------------------+----------+---------------+
select * from product_price_tbl where product_id = 25761270 and policy_id = 8769;
-- +---------+-----------------+----------+--------------+-----------+-------------------------+
-- |policy_id|pricing_scheme_id|product_id|base_price_amt|term_months|price_before_discount_amt|
-- +---------+-----------------+----------+--------------+-----------+-------------------------+
-- |8769     |225              |25761270  |201.60        |12         |201.60                   |
-- |8769     |226              |25761270  |161.28        |12         |201.60                   |
-- +---------+-----------------+----------+--------------+-----------+-------------------------+

 SELECT ox.customer_id,ad.first_nm,ad.last_nm,ad.locality_nm,pt.phone_no,t.*
 FROM ( SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
 			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'
 				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP)
 			          ELSE
 				       date_trunc('day', LOCALTIMESTAMP)+interval '1 days'
 			     END AS coverage_start_dt,
 			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
 			          THEN
 			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
 			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
                ELSE
 				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
 			     END AS coverage_end_dt,
 			     ppt.BASE_PRICE_AMT,
 			     ppt.TERM_MONTHS,
 			     si.purchase_dt,
 			     pol.age,
 			     round(DATE_PART('day', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
 			     pol.description as policy_description
 			FROM
 			(SELECT * from serialized_item where LATEST_COVERAGE_EXP_DT   < LOCALTIMESTAMP and last_updated_ts > '2015-12-19 00:00:00.000000'
 			                                 and latest_coverage_type_id = 1
 			                                  and EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400::int > 22
 			                                 and EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400::int < 220
 			                               order by random()  LIMIT 50) si
 			JOIN pricing_scheme_lkp psl
 			ON(si.latest_coverage_type_id=psl.latest_coverage_type_id and
 			(EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
 			between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
 			JOIN product_price_tbl ppt ON
 			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') -- BOSH-361
 			JOIN policy pol ON
 			(ppt.POLICY_ID=pol.POLICY_ID
 			)
 			JOIN policy_ext pex on
 			    (pex.POLICY_ID=pol.POLICY_ID and channels = 'OOW' )
 			JOIN product_ext PE ON
 			(PE.product_id = ppt.product_id)
 			join pricing_scheme_tbl pst
 	                on pst.pricing_scheme_id = ppt.pricing_scheme_id
 			WHERE  si.LATEST_COVERAGE_EXP_DT   < LOCALTIMESTAMP   AND --BOSH-1733
 			PE.PRODUCT_COVERAGE_END_DT  >= CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
 			          THEN
 			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
 			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
 ELSE
 				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
 			        END
 			        ---
 			    and case when substr(pst.description, 1, 2) = 'RN' then
 					  round(DATE_PART('day', si.latest_coverage_exp_dt - si.purchase_dt)/365)
 				     else 0
 				end = coalesce (pol.age, 0)
 			) t
 LEFT join ownership_xref ox on ox.serialized_item_id = t.serialized_item_id
 LEFT join customer_tbl ct on ct.customer_id = ox.customer_id
 LEFT join address_tbl ad on ad.address_id = ct.primary_address_id
 LEFT join phone_tbl pt on pt.phone_id = ct.primary_phone_id
 where (coverage_end_dt - purchase_dt)  <= interval '3650 day'    --total coverage must be less than 10 years for all brands
 ORDER BY TERM_MONTHS ASC;

COMMIT;

insert into  customer_list_oow
 SELECT ox.customer_id,ad.first_nm,ad.last_nm,ad.locality_nm,pt.phone_no,t.serialized_item_id,t.policy_id
 FROM ( SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
 			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'
 				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP)
 			          ELSE
 				       date_trunc('day', LOCALTIMESTAMP)+interval '1 days'
 			     END AS coverage_start_dt,
 			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
 			          THEN
 			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
 			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
                ELSE
 				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
 			     END AS coverage_end_dt,
 			     ppt.BASE_PRICE_AMT,
 			     ppt.TERM_MONTHS,
 			     si.purchase_dt,
 			     pol.age,
 			     round(DATE_PART('day', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
 			     pol.description as policy_description
 			FROM
 			(SELECT * from serialized_item where LATEST_COVERAGE_EXP_DT   < LOCALTIMESTAMP and last_updated_ts > '2015-12-19 00:00:00.000000'
 			                                 and latest_coverage_type_id = 1
 			                                  and EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400::int > 22
 			                                 and EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400::int < 220
 			                               order by random()  LIMIT 500) si
 			JOIN pricing_scheme_lkp psl
 			ON(si.latest_coverage_type_id=psl.latest_coverage_type_id and
 			(EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
 			between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
 			JOIN product_price_tbl ppt ON
 			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') -- BOSH-361
 			JOIN policy pol ON
 			(ppt.POLICY_ID=pol.POLICY_ID
 			)
 			JOIN policy_ext pex on
 			    (pex.POLICY_ID=pol.POLICY_ID and channels = 'OOW' )
 			JOIN product_ext PE ON
 			(PE.product_id = ppt.product_id)
 			join pricing_scheme_tbl pst
 	                on pst.pricing_scheme_id = ppt.pricing_scheme_id
 			WHERE  si.LATEST_COVERAGE_EXP_DT   < LOCALTIMESTAMP   AND --BOSH-1733
 			PE.PRODUCT_COVERAGE_END_DT  >= CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
 			          THEN
 			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
 			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
 			          THEN
 				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
 ELSE
 				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
 			        END
 			        ---
 			    and case when substr(pst.description, 1, 2) = 'RN' then
 					  round(DATE_PART('day', si.latest_coverage_exp_dt - si.purchase_dt)/365)
 				     else 0
 				end = coalesce (pol.age, 0)
 			) t
 LEFT join ownership_xref ox on ox.serialized_item_id = t.serialized_item_id
 LEFT join customer_tbl ct on ct.customer_id = ox.customer_id
 LEFT join address_tbl ad on ad.address_id = ct.primary_address_id
 LEFT join phone_tbl pt on pt.phone_id = ct.primary_phone_id
 where (coverage_end_dt - purchase_dt)  <= interval '3650 day'    --total coverage must be less than 10 years for all brands
  ;

COMMIT;
select * from BUNDLE_OFFER_LOG_TBL where log_date > '2025-12-04 05:38:45.306394' order by log_date desc;
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+--------+
-- |serialized_item_id|customer_id|offer_status|error_desc                                                   |log_date                  |offer_id|
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+--------+
-- |22875432          |5246720    |FO          |OOW-Final new Offer returned to App : BBWF6NH                |2025-12-05 12:01:56.584284|BBWF6NH |
-- |22875432          |5246720    |O           |Offer Items creating for serial item 22875432 and offer 65532|2025-12-05 12:01:56.565430|BBWF6NH |
-- |23053774          |5246720    |O           |Offer Items creating for serial item 23053774 and offer 65532|2025-12-05 12:01:56.546338|BBWF6NH |
-- |0                 |5246720    |S           |OOW-process started                                          |2025-12-05 12:01:53.620878|0       |
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+--------+
select pex.channels,pex.brand,oft.*, p.description, t.day
from offer_item_tbl oft join policy p on oft.policy_id = p.policy_id join term t on p.term_id = t.term_id
join policy_ext pex on pex.policy_id = p.policy_id
where offer_id IN (
         select ot.offer_id from offer_tbl ot where customer_id = 3429186
                                        and offer_start_utc_ts >= current_date - interval '1' day
    )
and offer_id < 500000
and active_ind = 'Y' and oft.last_updated_by ='Bundled Offer'
order by offer_id, t.day, policy_id;
-- +--------+-----+--------+-------------+-------------+---------+---------+------------------+--------------------------+--------------------------+
-- |channels|brand|offer_id|offer_line_id|offer_type_cd|policy_id|price_amt|serialized_item_id|coverage_start_dt         |coverage_exp_dt           |
-- +--------+-----+--------+-------------+-------------+---------+---------+------------------+--------------------------+--------------------------+
-- |OOW     |Bosch|65532   |4            |PolicyOffer  |8103     |84.60    |22875432          |2025-12-06 00:00:00.000000|2026-12-06 00:00:00.000000|
-- |OOW     |Bosch|65532   |1            |PolicyOffer  |8103     |84.60    |23053774          |2025-12-06 00:00:00.000000|2026-12-06 00:00:00.000000|
-- |OOW     |Bosch|65532   |5            |PolicyOffer  |8150     |158.40   |22875432          |2025-12-06 00:00:00.000000|2027-12-06 00:00:00.000000|
-- |OOW     |Bosch|65532   |2            |PolicyOffer  |8150     |158.40   |23053774          |2025-12-06 00:00:00.000000|2027-12-06 00:00:00.000000|
-- |OOW     |Bosch|65532   |6            |PolicyOffer  |8211     |282.60   |22875432          |2025-12-06 00:00:00.000000|2029-12-06 00:00:00.000000|
-- |OOW     |Bosch|65532   |3            |PolicyOffer  |8211     |282.60   |23053774          |2025-12-06 00:00:00.000000|2029-12-06 00:00:00.000000|
-- +--------+-----+--------+-------------+-------------+---------+---------+------------------+--------------------------+--------------------------+
select * from serialized_item where serialized_item_id = 22875432;
-- +------------------+-----------+--------------------------+----------+
-- |serialized_item_id|serial_num |purchase_dt               |product_id|
-- +------------------+-----------+--------------------------+----------+
-- |22875432          |0402-000213|2024-05-09 00:00:00.000000|19838622  |
-- +------------------+-----------+--------------------------+----------+
select * from product_price_tbl where product_id = 19838622 and policy_id = 8103;
-- +---------+-----------------+----------+--------------+-----------+
-- |policy_id|pricing_scheme_id|product_id|base_price_amt|term_months|
-- +---------+-----------------+----------+--------------+-----------+
-- |8103     |227              |19838622  |84.60         |12         |
-- |8103     |236              |19838622  |84.60         |12         |
-- |8103     |237              |19838622  |84.60         |12         |
-- |8103     |238              |19838622  |84.60         |12         |
-- |8103     |239              |19838622  |84.60         |12         |
-- |8103     |240              |19838622  |84.60         |12         |
-- |8103     |241              |19838622  |84.60         |12         |
-- |8103     |242              |19838622  |84.60         |12         |
-- +---------+-----------------+----------+--------------+-----------+

