
select COUNT(*) from PRODUCT_CATALOG_TBL; --414

select * from  brand_lkp;--0
select * from product_lkp;--0
select * from  product_category_lkp;--0
select COUNT(*) from product_dim; --414
select * from  brand_dim;--3
select * from  product_category_dim;--6
select COUNT(*) from  product_attribute_xref;--414X4=1656



--Core value is Y for DNS
select  s.DO_NOT_SOLICIT_PRODUCT_IND,  c.DO_NOT_SOLICIT_PRODUCT_IND,c.MODEL_NO,c.PRODUCT_CATEGORY_NM,c.MARKETING_PRODUCT_NM
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.DO_NOT_SOLICIT_PRODUCT_IND <> c.DO_NOT_SOLICIT_PRODUCT_IND  --1
    ) and s.PRICE_AMT is not null ;
-- DO_NOT_SOLICIT_PRODUCT_IND,DO_NOT_SOLICIT_PRODUCT_IND
-- N                         ,Y


-- 109 product coverage date is changed
select s.Product_Coverage_End_Dt , c.Product_Coverage_End_Dt
    --COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt  --109
    )  ;


-- Here 103 rows have CORE value is = 2099-12-29
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt  --103
    )  and c.Product_Coverage_End_Dt = TO_DATE('2099-12-29 00:00:00', 'YYYY/MM/DD HH24:MI:SS') ;



--300 records have same dates and value also same this 2099-12-29
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt = c.Product_Coverage_End_Dt  --109
    )  and s.PRODUCT_COVERAGE_END_DT = TO_DATE('2099-12-29 00:00:00', 'YYYY/MM/DD HH24:MI:SS')  ;



-- All 414 same brand
select COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.BRAND_NM = c.BRAND_NM --0
    ) and s.BRAND_NM is not null and  c.BRAND_NM is not null  ;


--17  rows have  changed category
select --COUNT(*)
    s.PRODUCT_CATEGORY_NM ,  c.PRODUCT_CATEGORY_NM,c.MODEL_NO,c.MARKETING_PRODUCT_NM,c.PRODUCT_NM,s.PRODUCT_NM
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRODUCT_CATEGORY_NM <>  c.PRODUCT_CATEGORY_NM --0
--      or s.PRICE_AMT <> c.PRICE_AMT --414
    ) and s.PRODUCT_CATEGORY_NM is not null and  c.PRODUCT_CATEGORY_NM is not null  ;
--
-- STG_PRODUCT_CATEGORY_NM, CORE_PRODUCT_CATEGORY_NM
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- VENTILATION          ,OTHER
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING



--Price changed for all 414 rows
select Count(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT <> c.PRICE_AMT --414
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;



-- 402 rows have new price increased
select Count(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT > c.PRICE_AMT --402
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;



select s.PRICE_AMT , c.PRICE_AMT
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT > c.PRICE_AMT --402
    )   and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;

-- 12 rows have less price new value
select s.PRICE_AMT , c.PRICE_AMT
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT < c.PRICE_AMT --402
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;

-- PRICE_AMT,PRICE_AMT
-- 1399.00,1499.00
-- 4799.00,4999.00
-- 7999.00,8399.00
-- 7499.00,7599.00
-- 7999.00,8399.00
-- 5999.00,6499.00
-- 6499.00,6949.00
-- 6999.00,7599.00
-- 3799.00,4199.00
-- 1649.00,1749.00
-- 7499.00,7599.00
-- 7499.00,7599.00


-- All coloumns with list of data with compare STG and Core
select s.BRAND_NM AS BRAND_NM_stg , c.BRAND_NM AS BRAND_NM_CORE
       ,s.PRODUCT_CATEGORY_NM AS PRODUCT_CATEGORY_NM_stg , c.PRODUCT_CATEGORY_NM AS PRODUCT_CATEGORY_NM_CORE
     ,s.PRICE_AMT AS PRICE_AMT_stg , c.PRICE_AMT AS PRICE_AMT_CORE
     ,s.DO_NOT_SOLICIT_PRODUCT_IND AS DNS_stg , c.DO_NOT_SOLICIT_PRODUCT_IND AS DNS_CORE
      ,s.Product_Coverage_End_Dt AS Product_Coverage_End_Dt_stg , c.Product_Coverage_End_Dt AS Product_Coverage_End_Dt_CORE
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.BRAND_NM <> c.BRAND_NM
      or s.PRICE_AMT <> c.PRICE_AMT
      or s.PRODUCT_CATEGORY_NM <>  c.PRODUCT_CATEGORY_NM --0
     or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt
     or s.DO_NOT_SOLICIT_PRODUCT_IND <> c.DO_NOT_SOLICIT_PRODUCT_IND
    )   ;
