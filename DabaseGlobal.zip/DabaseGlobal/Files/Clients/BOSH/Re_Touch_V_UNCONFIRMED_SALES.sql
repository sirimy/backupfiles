 declare
          v_audit_key number;
        begin
            v_audit_key := bosh.get_audit_key (p_program_nm => 'Sales', p_descriptive_tx => 'Resubmitting V_UNCONFIRMED_SALES sales to Assurant', p_table_nm => 'ORDER_ITEM_TBL');
            DBMS_OUTPUT.put_line(v_audit_key);
            COMMIT;

            update bosh.ORDER_ITEM_TBL
               set    UPDATE_AUDIT_KEY = v_audit_key, SYNC_AUDIT_KEY = v_audit_key
             where (ORDER_KEY, ORDER_LINE_KEY)
              in (
                    select VU.ORDER_KEY,VU.ORDER_LINE_KEY  from V_UNCONFIRMED_SALES VU
              );

            commit;

        end;

 --check SQL for order extract
select * from BOSH.ORDER_EXTRACT_TBL where UNIQUE_IDENTIFIER
in(
select TO_CHAR(ORDER_KEY) || '-' || TO_CHAR(ORDER_LINE_KEY)   from bosh.ORDER_ITEM_TBL
where UPDATE_AUDIT_KEY = 716662
)
and PROCESS_DT =  date'2023-08-15'
;--71

--check sql for ACK file

select * from BOSH.RAW_CONTRACT_SALES_TBL where UNIQUE_IDENTIFIER
in (
    select TO_CHAR(ORDER_KEY) || '-' || TO_CHAR(ORDER_LINE_KEY)   from bosh.ORDER_ITEM_TBL
where UPDATE_AUDIT_KEY = 716662
);--15