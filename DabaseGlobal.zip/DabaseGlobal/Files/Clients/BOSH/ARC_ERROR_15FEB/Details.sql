-- [2025-02-16 00:52:28] Connected
-- BOSH> alter session set current_schema = BOSH
-- [2025-02-16 00:52:29] completed in 189 ms
-- BOSH> BEGIN BOSH.ARCHIVE_STAGE_TABLES; END;
-- [2025-02-16 00:52:29] completed in 287 ms


-- Create table COMMON_LOAD_TBL_ARCH_BACKUP_2025_02_16 AS
--     select * from COMMON_LOAD_TBL
--         where UNIQUE_SEQ_NO in(
--             select clt.UNIQUE_SEQ_NO from BOSH.COMMON_LOAD_TBL_ARCH clt
--             ) ;

-- delete from COMMON_LOAD_TBL
--         where UNIQUE_SEQ_NO in(
--             select clt.UNIQUE_SEQ_NO from BOSH.COMMON_LOAD_TBL_ARCH clt
--             ) ;