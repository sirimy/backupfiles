BOSH> DECLARE
             v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'CCPA-186', p_table_nm => 'email_dim,email_lkp');

      BEGIN


                  update bosh.email_dim
                  set    EMAIL_ADDRESS_TX = 'CCPA-' || to_char(EMAIL_KEY),
                         update_audit_key = v_audit_key,
                         sync_audit_key = null
                  where  EMAIL_KEY = 2384727;

                 DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );

                  update bosh.email_lkp
                  set    EMAIL_XID = 'CCPA-' || to_char(EMAIL_KEY),
                         update_audit_key = v_audit_key,
                         sync_audit_key = null
                  where  EMAIL_KEY = 2384727
                  and    source_system_cd = 0;



             DBMS_OUTPUT.PUT_LINE(v_audit_key);
             DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );

               COMMIT;

      END;
[2025-10-01 20:06:10] completed in 694 ms
1
1011471
1
[2025-10-01 20:06:22] transaction committed: @console_100 [BOSH-Core-Prod]
