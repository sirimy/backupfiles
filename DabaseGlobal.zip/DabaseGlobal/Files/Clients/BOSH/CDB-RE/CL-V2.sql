


    Select COUNT(*) from COMMON_LOAD_HOLD_TBL;--4417
    Select COUNT(*) from COMMON_LOAD_TBL;--4417
    select COUNT(*) from ADDRESS_OUTPUT_TBL;--4417
    select COUNT(*) from SI_OUTPUT_TBL;--4417
    select COUNT(*) from CUSTOMER_OUTPUT_TBL;--4417
    select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--4257
    select distinct SOURCE from SERIALIZED_ITEM_EXT_DIM;--   --CDB-REGISTRIA

    select COUNT(*) from visitor_dim;--3788
    select COUNT(*) from visitor_lkp;--3206
    select COUNT(*) from address_dim;--3781
    select COUNT(*) from address_lkp;--6314
    select COUNT(*) from visitor_address_xref;--3846
    select COUNT(*) from visitor_address_lkp;--3248
    select COUNT(*) from serialized_item_dim;--4257
    select COUNT(*) from serialized_item_lkp;--4218
    select COUNT(*) from visitor_ownership_xref;--4257


    select COUNT(*) from email_lkp;--0
    select COUNT(*) from email_dim;--0
    select COUNT(*) from visitor_email_xref;--0
    select COUNT(*) from visitor_email_lkp;--0
    select COUNT(*) from phone_dim;--0
    select COUNT(*) from phone_lkp;--0
    select COUNT(*) from visitor_phone_xref;--0
     select COUNT(*) from VISITOR_PREFERENCE_TBL;--0
    select COUNT(*) from VISITOR_PURL_XREF;--0
    select COUNT(*) from CUSTOMER_DIM;--0
    select COUNT(*) from HOUSEHOLD_LKP;--0
    select COUNT(*) from CUSTOMER_LKP;--0

    select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--0

    select * from p_raw_inwarranty_leads_tbl where unique_seq_no is not NULL order by INSERT_AUDIT_KEY desc;

    -- update serialized_item_ext_dim
    -- set source = 'INWARRANTY';

    select source, count(*) from serialized_item_ext_dim group by source;

    select * from serialized_item_ext_dim;


    select latest_coverage_type, name, count(*), max(registration_dt)
      from P_serialized_item_dim si left join P_latest_coverage_type_dim on coverage_type_key = latest_coverage_type
     group by latest_coverage_type, name
     order by 1;