--,'$' || REGEXP_SUBSTR(REPLACE(AC.PRICE_BAND,'$','') , '[^ to ]+', 1) || ' to $'  AS MIn

select * from BoschRenewalPricing_AgeCap;

Select AC.SKU,AC.PRODUCT_CATEGORY,AC.PRODUCT_BRAND,REPLACE(AC.ORIGINAL_TERM,' year','') As AGE,REPLACE(REPLACE(AC.TERM,' year',''),'s','') As TERM_COVERAGE_EXT
,REGEXP_SUBSTR(REPLACE(AC.PRICE_BAND,'$','') , '[^ to ]+', 1) AS MIn
,REPLACE(AC.PRICE_BAND,'$' || REGEXP_SUBSTR(REPLACE(AC.PRICE_BAND,'$','') , '[^ to ]+', 1) || ' to $','') AS MAx,
 REPLACE(AC.TWGIS_COST,'$','') AS TWGIS_COST, REPLACE(REPLACE(AC.SUGGESTEDRETAIL,'$',''),',','')   AS Retail
,'Bosch Renewal Pricing - Age Cap_082022.ods' AS File_nm,AC.CHANNELS
from BoschRenewalPricing_AgeCap AC;


declare
  v_audit_key number;
begin
  v_audit_key := bosh.get_audit_key (p_program_nm => 'RenewalPricing_AgeCap', p_descriptive_tx => 'BOSH-1030: Renewal New pricing', p_table_nm => 'raw_pricing_tbl');
  DBMS_OUTPUT.put_line(v_audit_key);

    Insert into raw_pricing_tbl RPT (RPT.SKU,RPT.PRODUCT_CAT_DESC,RPT.BRAND,RPT.AGE,RPT.TERM_COVERAGE_EXT,RPT.MIN_PRODUCT_PRICE
    ,RPT.MAX_PRODUCT_PRICE,RPT.TWGIS_COST,RPT.RETAIL_PRICE_AMT,RPT.FILE_NM,RPT.CHANNEL,RPT.INSERT_AUDIT_KEY)
    (Select AC.SKU,AC.PRODUCT_CATEGORY,AC.PRODUCT_BRAND,REPLACE(AC.ORIGINAL_TERM,' year','') As AGE,REPLACE(REPLACE(AC.TERM,' year',''),'s','') As TERM_COVERAGE_EXT
    ,REGEXP_SUBSTR(REPLACE(AC.PRICE_BAND,'$','') , '[^ to ]+', 1) AS MIn
    ,REPLACE(AC.PRICE_BAND,'$' || REGEXP_SUBSTR(REPLACE(AC.PRICE_BAND,'$','') , '[^ to ]+', 1) || ' to $','') AS MAx,
     REPLACE(AC.TWGIS_COST,'$','') AS TWGIS_COST,REPLACE(REPLACE(AC.SUGGESTEDRETAIL,'$',''),',','')  AS Retail
    ,'Bosch Renewal Pricing - Age Cap_082022.ods' AS File_nm,AC.CHANNELS,v_audit_key
    from BoschRenewalPricing_AgeCap AC);
    COMMIT;

    Policy_SEQ.nextval = 4000;

    update raw_pricing_tbl set  EFFECTIVE_DT = DATE '2022-08-01' ;

    COMMIT;

    update (select *
          from raw_pricing_tbl rp
          order by rp.BRAND,
                   case
                       when PRODUCT_CAT_DESC = 'Built-In Coffee Maker' then 1
                       when PRODUCT_CAT_DESC = 'Cooking' then 2
                       when PRODUCT_CAT_DESC = 'Dishwasher' then 3
                       when PRODUCT_CAT_DESC = 'Laundry - Dryer' then 4
                       when PRODUCT_CAT_DESC = 'Laundry - Washer' then 5
                       when PRODUCT_CAT_DESC = 'Refrigerator With Food Loss' then 6
                       when PRODUCT_CAT_DESC = 'Ventilation' then 7
                       end
                  , rp.AGE, rp.TERM_COVERAGE_EXT,rp.MIN_PRODUCT_PRICE, rp.RETAIL_PRICE_AMT)
    set policy_key = Policy_SEQ.nextval
               where nvl(policy_key, 0) = 0  ;


  COMMIT;
end;


