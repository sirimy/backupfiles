DECLARE
              --4/14/2016: AJ
              --We need to add policy_lkp records with source_system_cd 2 as these records would be used for lookup against orders/contract data created in web and imported to DWH
              v_audit_key NUMBER;
          BEGIN
              v_audit_key := bosh.get_audit_key (p_program_nm => 'POLICY', p_author_nm  => 'ajain', p_process_nm => 'POLICY Data Creation', p_descriptive_tx => 'POLICY Data Creation', p_table_nm => 'POLICY_LKP');

             DELETE FROM policy_lkp WHERE source_system_cd = 2;

             --Deleting those  records, which are there in core/DW already (from previous runs).
             DELETE FROM policy_lkp
              WHERE source_system_cd = 0
                AND TO_CHAR(policy_xid) IN (
                       SELECT policy_xid FROM p_policy_lkp
                        WHERE source_system_cd = 0);


            --using policy_key as policy_xid for ssc=2
             INSERT
               INTO POLICY_LKP (
                       policy_xid, source_system_cd, ext_id_type_cd, policy_key, insert_audit_key )
             SELECT policy_key as policy_xid, 2 as source_system_cd, 1 as ext_id_type_cd, policy_key, v_audit_key
               FROM
                    (
                     SELECT  policy_key as policy_xid, policy_key
                       FROM  policy_tbl
                     UNION
                     SELECT  policy_key as policy_xid, policy_key
                       FROM  p_policy_tbl
                     )
              WHERE  TO_CHAR(policy_key) NOT IN (
                        SELECT policy_xid FROM v_policy_lkp
                         WHERE source_system_cd = 2
                        );


             COMMIT;

          END;