select COUNT(PRODUCT_BRAND) from BoschRenewalPricing_AgeCap;--768
select PRODUCT_BRAND,COUNT(PRODUCT_BRAND) from BoschRenewalPricing_AgeCap
    Group by PRODUCT_BRAND;
-- PRODUCT_BRAND,COUNT(PRODUCT_BRAND)
-- Bosch,384
-- Thermador,384
select *  FROM policy_tbl order by POLICY_KEY; --768
select Distinct Age  FROM policy_tbl; --4
select COUNT(*)  FROM policy_lkp; --1536 = 768 X 2 -- so two record per SKU
-- select REGEXP_SUBSTR(PLK.POLICY_XID , '[^-]+', 1) as SKU,COUNT(PLK.POLICY_KEY) FROM policy_lkp PLK
--     group by REGEXP_SUBSTR(PLK.POLICY_XID , '[^-]+', 1);
select *  FROM policy_lkp Order by POLICY_KEY;
select *  FROM policy_lkp Where POLICY_XID = TO_CHAR(POLICY_KEY) ;--768
select *  FROM policy_lkp Where POLICY_XID <> TO_CHAR(POLICY_KEY);--768
select COUNT(*)  FROM policy_ext_tbl;--768
select COUNT(*)  FROM policy_fee_xref;--1536 = 768 X 2 -- so two record per POLICY_KEY for POLICY_FEE_TYPE_KEY = 1 and 3
select *  FROM policy_fee_xref order by POLICY_KEY;

select pft.name, count(*), count(distinct pfx.POLICY_KEY), count(distinct pol.name)
       --,pol.name, pfx.*, product_cat_desc, min_hp, max_hp
  from policy_fee_xref pfx
       join (select * from POLICY_FEE_TYPE pft
             union all
             select * from bosh.POLICY_FEE_TYPE pft
            ) pft on pft.POLICY_FEE_TYPE_Key = pfx.POLICY_FEE_TYPE_Key
       join policy_tbl pol on pol.policy_key = pfx.policy_key join policy_ext_tbl pex on pol.policy_key = pex.policy_key
 where 1=1
--    and sysdate between pol.effective_dt and pol.exp_dt
--    and pol.name like 'PREMIER PRO PLUS + GPS'
--    and pft.name = 'MSRP'
--  and POLICY_FEE_VALUE is not null
group by pft.name order by pft.name;


select POLICY_KEY,COUNT(POLICY_KEY)  FROM policy_fee_xref Group by POLICY_KEY order by POLICY_KEY;
select *  FROM policy_discount_tbl;--768
select Distinct DISCOUNT_PERCENTAGE  FROM policy_discount_tbl;--1
select COUNT(*) from policy_item_tbl ;--768
select  * from policy_item_tbl order by POLICY_ITEM_KEY;--768
select COUNT(*) from POLICY_COVERAGE_TBL;--1536 = 768 X 2 -- so two record per POLICY_KEY COVERAGE_TYPE_KEY = 2 and 3
select * from POLICY_COVERAGE_TBL Order by POLICY_KEY ;
select POLICY_KEY,COUNT(POLICY_KEY)  from POLICY_COVERAGE_TBL Group by POLICY_KEY;

select Name, listagg(distinct AGE, ', ') WITHIN GROUP (ORDER BY AGE) as AGE   FROM policy_tbl
          Group by Name
Order by Name;



select tcx.TERMS_AND_CONDITIONS_KEY, COUNTRY_ISO, tr.name, count(*), count(distinct POLICY_KEY) as policies, count(distinct psd.POSTAL_STATE_KEY) as states
       ,min(tcx.effective_dt), max(tcx.effective_dt), min(pol.effective_dt), max(pol.effective_dt), tac.DESCRIPTION
  from t_and_c_contract_template_xref tcx join policy_tbl pol using (policy_key)
       join p_term_dim tr using (term_key)
       join p_postal_state_dim psd on psd.postal_state_key = tcx.postal_state_key
       join p_TERMS_AND_CONDITIONS_DIM tac on tcx.TERMS_AND_CONDITIONS_KEY = tac.TERMS_AND_CONDITIONS_KEY
 group by tcx.TERMS_AND_CONDITIONS_KEY, COUNTRY_ISO, tr.name, tac.DESCRIPTION
 order by 1, 2;


select PRICING_SCHEME_KEY,COUNT(PRICING_SCHEME_KEY) from PRODUCT_PRICE_DIM Group by  PRICING_SCHEME_KEY ;
select PRODUCT_KEY,COUNT(PRODUCT_KEY) from PRODUCT_PRICE_DIM Group by PRODUCT_KEY ; -- 8 prices scheme per product

select PPD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_DESC,COUNT(PPD.PRICING_SCHEME_KEY) AS CNT, count(distinct PRODUCT_KEY) as products, count(distinct POLICY_KEY)
       ,listagg(distinct TERM_MONTHS, ', ') as terms
    from PRODUCT_PRICE_DIM PPD
         inner join (select * from BOSH.pricing_scheme_dim UNION select * from pricing_scheme_dim)  PSD
                                on PPD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    Group by PPD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_DESC
    Order by PRICING_SCHEME_KEY;

select Distinct Age  FROM policy_tbl order by Age; --4
select Distinct Age  from RAW_PRICING_TBL order by Age;



SELECT * FROM V_PRICING_SCHEME_DIM psd where
                        psd.PRICING_SCHEME_DESC LIKE '%RN%'
                       AND psd.END_DT >= trunc(sysdate);


     -- Generate product_price_dim data for RENEWAL PROGRAM (RN)
--
--      insert into product_price_dim
--          (
--          PRICING_SCHEME_KEY
--         ,PRODUCT_KEY
--         ,BASE_PRICE_AMT
--         ,TERM_MONTHS
--         ,TERM_DISCOUNT_AMT
--         ,GREATEST_SAVINGS_AMT
--         ,PREMIUM_AMT
--         ,PRICE_BEFORE_DISCOUNT_AMT
--         ,PRICE_LOW
--         ,PRICE_HIGH
--         ,POLICY_KEY
--         ,INSERT_AUDIT_KEY
--         ,UPDATE_AUDIT_KEY
--         ,SYNC_AUDIT_KEY
--         ,ACTIVE_IND
--         )
        select DISTINCT
            PSD.PRICING_SCHEME_DESC ,
            pl.age,
            r.BRAND,
            pl.NAME,
                PSD.PRICING_SCHEME_KEY as PRICING_SCHEME_KEY
               ,pd.PRODUCT_KEY
                ,pfee.retail_price_amt as BASE_PRICE_AMT
                ,pl.TERM_COVERAGE_EXT as TERM_MONTHS
                ,0 TERM_DISCOUNT_AMT
                ,0 GREATEST_SAVINGS_AMT
                ,0 PREMIUM_AMT
                ,pfee.retail_price_amt as PRICE_BEFORE_DISCOUNT_AMT
                ,'' PRICE_LOW
                ,'' PRICE_HIGH
                ,pl.POLICY_KEY
                ,'v_audit_key' as INSERT_AUDIT_KEY
                ,'' UPDATE_AUDIT_KEY
                ,'' SYNC_AUDIT_KEY
                ,'Y'
       from (select policy_key, brand, product_cat_desc, channels from POLICY_EXT_TBL r
             union
             select policy_key, brand, product_cat_desc, channels from p_POLICY_EXT_TBL r
            ) r
            join (select policy_key, policy_product_xid, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, age, tr.month as term_coverage_ext,pol.NAME
                    from policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                   where pol.exp_dt > sysdate
                 union
                 select policy_key, policy_product_xid, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, age, tr.month as term_coverage_ext,pol.NAME
                   from p_policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                  where pol.exp_dt > sysdate
                 ) pl on (r.policy_key = pl.policy_key)
            ---
            join ( SELECT *
                      FROM V_PRICING_SCHEME_DIM psd
                     WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), psd.load_dt) IN ( select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), max(psd2.load_dt)
                                             from v_pricing_scheme_dim psd2
                                            WHERE psd2.PRICING_SCHEME_DESC LIKE 'RN%'
                                            group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$')
                                          )
                       AND psd.PRICING_SCHEME_DESC LIKE 'RN%'
                       AND psd.END_DT >= trunc(sysdate)
                  ) psd
             on ( PSD.PRICING_SCHEME_DESC = case
                                                --when r.brand = 'THUS' and upper(r.channels) = 'OOW' then 'AO Thermador'
                                                --when r.brand = 'BSUS' and upper(r.channels) = 'OOW' then 'AO Bosh'
                                                when upper(r.brand) IN ('THUS', 'THERMADOR') and upper(r.channels) IN ('RENEWAL',  'RENEWAL PROGRAM') THEN 'RN ' || to_number(nvl(pl.age, 0) ) || ' Thermador'
                                                when upper(r.brand) IN ('BSUS', 'BOSCH')     and upper(r.channels) IN ('RENEWAL',  'RENEWAL PROGRAM') THEN 'RN ' || to_number(nvl(pl.age, 0) ) || ' Bosch'
                                                --when r.brand = 'BSUS' and upper(r.channels) = 'RENEWAL PROGRAM' AND pl.age = 2 THEN 'RN '|| pl.age + 1 ||' Bosh'
                                                --when r.brand = 'THUS' and upper(r.channels) = 'AM' THEN 'AM Thermador'
                                                --when r.brand = 'BSUS' and upper(r.channels) = 'AM' THEN 'AM Bosh'
                                                when upper(r.brand) IN ('GGUS', 'GAGGENAU')  and upper(r.channels) IN ('RENEWAL',  'RENEWAL PROGRAM') THEN 'RN ' || to_number(nvl(pl.age, 0) ) || ' Gaggenau'
                                             end )
            ---
            left join (select pfe.policy_key,
                               pfe.policy_fee_value * (1 - pdt.discount_percentage) as retail_price_amt
                               --pfe.policy_fee_value as retail_orig_price_amt, --debug
                               --pdt.discount_percentage,                       --debug
                         from P_POLICY_FEE_XREF  pfe
                         join P_POLICY_FEE_TYPE  pft
                           on ( PFE.POLICY_FEE_TYPE_KEY = PFT.POLICY_FEE_TYPE_KEY AND PFT.NAME = 'Retail amt')
                         join p_policy_discount_tbl pdt
                           on (pdt.policy_key = pfe.policy_key and pdt.policy_fee_type_key = pfe.policy_fee_type_key
                                and pdt.discount_key = 11 --hard coded for now
                                and trunc(sysdate) between pdt.effective_dt and pdt.end_dt
                               )
                      union all
                          select pfe.policy_key,
                               pfe.policy_fee_value * (1 - pdt.discount_percentage) as retail_price_amt
                               --pfe.policy_fee_value as retail_orig_price_amt, --debug
                               --pdt.discount_percentage,                       --debug
                          from POLICY_FEE_XREF  pfe
                          join P_POLICY_FEE_TYPE  pft
                            on ( PFE.POLICY_FEE_TYPE_KEY = PFT.POLICY_FEE_TYPE_KEY AND PFT.NAME = 'Retail amt')
                          join policy_discount_tbl pdt
                            on (pdt.policy_key = pfe.policy_key and pdt.policy_fee_type_key = pfe.policy_fee_type_key
                                and pdt.discount_key = 11 --hard coded for now
                                and trunc(sysdate) between pdt.effective_dt and pdt.end_dt
                               )
                   ) pfee
              on ( pfee.policy_key = pl.policy_key)

            join p_brand_dim bd on (CASE WHEN upper(r.brand) IN ('BSUS', 'BOSCH') THEN 'Bosch'
                                         WHEN upper(r.brand) IN ('THUS', 'THERMADOR') THEN 'Thermador'
                                         WHEN upper(r.brand) IN ('GGUS', 'GAGGENAU') THEN 'Gaggenau'
                                         ELSE r.brand
                                     END  = bd.brand_nm
                                   )
            join (
                    select pd.product_key,model_no,product_nm, product_dsc, product_category_nm,
                             case when lower(product_category_nm) like 'refrig%' then 'Refrigerator With Food Loss'--'REFRIGERATION W LOSS'
                             when lower(product_category_nm) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                             when lower(product_category_nm) like '%dish%' then 'DISHWASHER'
                             when lower(product_dsc) like '%hood%' or lower(PRODUCT_CATEGORY_nm) like '%venti%'  then 'VENTILATION'
                             when lower(product_category_nm) like 'cooking' then 'COOKING'
                             when lower(product_category_nm) like '%laundry%' and lower(product_dsc) like '%dryer%' then 'LAUNDRY-DRYER'
                             when lower(product_category_nm) like '%laundry%' then 'LAUNDRY-WASHER'
                             else 'other' end as bora_pricing_category,
                             brand_nm, price_amt, brand_key --,sku_no, upc_cd
                      from
                           bosh.v_product pd
                     where
                           NVL(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
                       and PRODUCT_COVERAGE_END_DT >= sysdate
                       and NVL( pd.price_amt, 0 ) <> 0
                       --and pd.product_key = 27686   --debug only
                    ) pd
                    on ( bd.brand_key = pd.brand_key
                          and upper(r.PRODUCT_CAT_DESC) = upper(pd.bora_pricing_category)
                          and pd.price_amt between pl.min_product_price and pl.max_product_price
                         )

       where UPPER(r.channels) IN ('RENEWAL', 'RENEWAL PROGRAM')
         and (PSD.PRICING_SCHEME_KEY, PD.PRODUCT_KEY, pl.POLICY_KEY) NOT IN
                (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                   FROM p_product_price_dim
                 UNION ALL
                 SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                   FROM product_price_dim
                )
       and pd.product_key  in ('19644','37436')
        Order by pd.product_key, pl.age,r.BRAND
      ;

select * from POLICY_TBL where POLICY_KEY in (3989,3988,3990,3992,3991,3994,3993,3995,3801,
3802,3804,3805,3803,3807,3806,3808);