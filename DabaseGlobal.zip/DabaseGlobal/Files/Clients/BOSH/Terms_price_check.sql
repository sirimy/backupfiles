

select * from BOSH.PHONE_DIM where PHONE_NO = '5306138473';

select * from BOSH.PHONE_LKP where PHONE_XID in('5306138473','3239958','20611833');

select * from BOSH.PHONE_DIM where PHONE_KEY in (533873,251610,533873);
+---------+----------+-------------+----------------+
|PHONE_KEY|PHONE_NO  |BAD_PHONE_IND|INSERT_AUDIT_KEY|
+---------+----------+-------------+----------------+
|251610   |5109092782|N            |55317           |
|533873   |5306138473|N            |124053          |
+---------+----------+-------------+----------------+

Select * from BOSH.AUDIT_TBL where AUDIT_KEY IN (124053,55317);

select * from COMMON_LOAD_HOLD_TBL where PHONE_NO = '5306138473';
+----------+---------+-----------------+
|PHONE_NO  |PHONE_XID|PRIMARY_PHONE_IND|
+----------+---------+-----------------+
|5306138473|3239958  |N                |
|5306138473|20611833 |Y                |
+----------+---------+-----------------+
+--------+----------+----------------------+--------------------------+
|phone_id|phone_no  |last_updated_by       |last_updated_ts           |
+--------+----------+----------------------+--------------------------+
|3239958 |5306138473|mrobinson@afterinc.com|2021-09-16 19:31:53.420000|
|20611833|5306138473|apaul@afterinc.com    |2023-10-04 20:10:30.120000|
+--------+----------+----------------------+--------------------------+
select * from BOSH.PHONE_LKP where PHONE_XID in('3239958','20611833');




Select * from BOSH.POLICY_TBL;
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+
|POLICY_KEY|NAME                                     |DESCRIPTION                               |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |MIN_PRODUCT_PRICE|
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+
|349       |Thermador Appliance Service plan - 1 Year|1 yr Thermador Appliance Service plan (AM)|THFGJ36U          |2016-05-01  |2021-12-31|3500.00          |
|350       |Thermador Appliance Service plan - 1 Year|1 yr Thermador Appliance Service plan (AM)|THFGK36U          |2016-05-01  |2021-12-31|5000.00          |
|351       |Thermador Appliance Service plan - 1 Year|1 yr Thermador Appliance Service plan (AM)|THFGM36U          |2016-05-01  |2021-12-31|6000.00          |
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+




select * from BOSH.RAW_PRICING_TBL where SKU in ('THFGP36UR4','THFGP48UR4');
+----------+---------------------------+---------+---+-----------------+-----------------+-----------------+----------+----------------+---------------------------------------------------+----------------+----------------+--------------+-------+---------+---------+----------+----------+-----------+--------+-------------------------------------------------------------------------------+---------------+------------+
|SKU       |PRODUCT_CAT_DESC           |BRAND    |AGE|TERM_COVERAGE_EXT|MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|TWGIS_COST|RETAIL_PRICE_AMT|FILE_NM                                            |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|PREMIUM|MARSH_FEE|ADMIN_FEE|POLICY_KEY|DEDUCTIBLE|WAIT_PERIOD|CURRENCY|COMMENTS                                                                       |CHANNEL        |EFFECTIVE_DT|
+----------+---------------------------+---------+---+-----------------+-----------------+-----------------+----------+----------------+---------------------------------------------------+----------------+----------------+--------------+-------+---------+---------+----------+----------+-----------+--------+-------------------------------------------------------------------------------+---------------+------------+
|THFGP36UR4|Refrigerator With Food Loss|Thermador|4  |3                |8000.00          |8999.99          |247.06    |1462.00         |Bosch_Renewal_Pricing_Adj_to_Match_Prior_Pricing_V3|234853          |NULL            |234853        |NULL   |NULL     |NULL     |1708      |NULL      |NULL       |NULL    |NULL                                                                           |RENEWAL PROGRAM|NULL        |
|THFGP36UR4|Refrigerator With Food Loss|Thermador|4  |3                |8000.00          |8999.99          |247.06    |1023.40         |Bosch_Renewal_Pricing_Adj_to_Match_Prior_Pricing_V3|505703          |NULL            |505703        |NULL   |NULL     |NULL     |3456      |NULL      |NULL       |NULL    |Existing Thermador pricing data was copied by reducing pricing by 30%. BOSH-963|RENEWAL PROGRAM|2022-01-01  |
|THFGP48UR4|REFRIGERATOR WITH FOOD LOSS|Thermador|4  |4                |8000.00          |8999.99          |327.93    |940.00          |ADDED_RENEWAL_PRICING_AND_MISSING_RATES            |718099          |NULL            |718099        |NULL   |NULL     |NULL     |6358      |NULL      |NULL       |USD     |NULL                                                                           |RENEWAL        |2023-08-21  |
+----------+---------------------------+---------+---+-----------------+-----------------+-----------------+----------+----------------+---------------------------------------------------+----------------+----------------+--------------+-------+---------+---------+----------+----------+-----------+--------+-------------------------------------------------------------------------------+---------------+------------+

Select * from BOSH.POLICY_TBL where POLICY_PRODUCT_XID = 'THFGP48UR4';
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+---+--------------+----------------+----------------+----------+--------------+---------------+------------+
|POLICY_KEY|NAME                                     |DESCRIPTION                               |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|CURRENCY_CD|POLICY_TYPE_KEY|TERM_KEY|CONTRACT_SALES_CHANNEL_KEY|COVERAGE_TIMING_STRATEGY_KEY|RESOLUTION_TYPE|IMAGE_LINK|THUMBNAIL_IMAGE_LINK|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|AGE|SYNC_AUDIT_KEY|SUBSCRIBABLE_IND|POLICY_GROUP_KEY|DEDUCTIBLE|DEDUCTIBLE_MAX|UNDERWRITER_KEY|NEW_USED_IND|
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+---+--------------+----------------+----------------+----------+--------------+---------------+------------+
|6358      |Thermador Appliance Service plan - 4 Year|4 yr Thermador Appliance Service plan (RN)|THFGP48UR4        |2023-08-21  |2099-12-31|8000.00          |8999.99          |USD        |1              |4       |3                         |1                           |NULL           |NULL      |NULL                |717637          |NULL            |4  |718100        |NULL            |1               |NULL      |NULL          |1              |N           |
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+---+--------------+----------------+----------------+----------+--------------+---------------+------------+

Select * from BOSH.POLICY_FEE_XREF where POLICY_KEY =   6358;
+----------+-------------------+----------------+--------------------------+--------------------------+----------------+----------------+--------------+
|POLICY_KEY|POLICY_FEE_TYPE_KEY|POLICY_FEE_VALUE|EFFECTIVE_DT              |END_DT                    |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+----------+-------------------+----------------+--------------------------+--------------------------+----------------+----------------+--------------+
|6358      |1                  |940.00          |2023-08-21 00:00:00.000000|2099-12-31 00:00:00.000000|717637          |NULL            |718108        |
|6358      |3                  |327.93          |2023-08-21 00:00:00.000000|2099-12-31 00:00:00.000000|717637          |NULL            |718108        |
+----------+-------------------+----------------+--------------------------+--------------------------+----------------+----------------+--------------+
Select * from BOSH.V_POLICY_FEE where POLICY_KEY =   6358;

Select * from BOSH.POLICY_TBL where POLICY_PRODUCT_XID = 'THFGP36UR4' and EXP_DT > sysdate;
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+---+--------------+----------------+----------------+----------+--------------+---------------+------------+
|POLICY_KEY|NAME                                     |DESCRIPTION                               |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|CURRENCY_CD|POLICY_TYPE_KEY|TERM_KEY|CONTRACT_SALES_CHANNEL_KEY|COVERAGE_TIMING_STRATEGY_KEY|RESOLUTION_TYPE|IMAGE_LINK|THUMBNAIL_IMAGE_LINK|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|AGE|SYNC_AUDIT_KEY|SUBSCRIBABLE_IND|POLICY_GROUP_KEY|DEDUCTIBLE|DEDUCTIBLE_MAX|UNDERWRITER_KEY|NEW_USED_IND|
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+---+--------------+----------------+----------------+----------+--------------+---------------+------------+
|3456      |Thermador Appliance Service plan - 3 Year|3 yr Thermador Appliance Service plan (RN)|THFGP36UR4        |2022-01-01  |2099-12-31|8000.00          |8999.99          |USD        |1              |3       |1                         |1                           |NULL           |NULL      |NULL                |504231          |547222          |4  |547222        |NULL            |1               |NULL      |NULL          |1              |N           |
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+---+--------------+----------------+----------------+----------+--------------+---------------+------------+

select distinct BASE_PRICE_AMT,TERM_MONTHS,PRODUCT_KEY,POLICY_KEY
from BOSH.PRODUCT_PRICE_DIM where PRICING_SCHEME_KEY in (103,169)
group by PRODUCT_KEY,POLICY_KEY
;

--Model No and SKU and brand and category
select  FT.BASE_PRICE_AMT,FT.TERM_MONTHS,ST.BASE_PRICE_AMT,ST.TERM_MONTHS,FT.POLICY_KEY,FT.PRODUCT_KEY,FT.PRICING_SCHEME_KEY from (
                  (select distinct BASE_PRICE_AMT, TERM_MONTHS, PRODUCT_KEY ,PRICING_SCHEME_KEY, POLICY_KEY
                   from BOSH.PRODUCT_PRICE_DIM
                    ) FT
                      join
                      (select distinct BASE_PRICE_AMT, TERM_MONTHS, PRODUCT_KEY, PRICING_SCHEME_KEY, POLICY_KEY
                       from BOSH.PRODUCT_PRICE_DIM
                        ) ST
                    on ft.PRODUCT_KEY =st.PRODUCT_KEY and ft.PRICING_SCHEME_KEY = st.PRICING_SCHEME_KEY and ft.TERM_MONTHS <> st.TERM_MONTHS
                  )
where FT.BASE_PRICE_AMT >= ST.BASE_PRICE_AMT  and ft.TERM_MONTHS < st.TERM_MONTHS;