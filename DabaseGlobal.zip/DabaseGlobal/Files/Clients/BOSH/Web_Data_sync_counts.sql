select * from pricing_scheme_tbl where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19'  order by last_updated_ts  desc;--6

select COUNT(*) from policy  where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19' ;--768

select COUNT(*)  from POLICY_EXT
where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19'  ; --768

select COUNT(*) from t_and_c_contract_template_xref
where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19' ;--39168


select COUNT(*) from POLICY_ITEM
    where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19'  ;--768

 select COUNT(*) from POLICY_COVERAGE
      where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19'   ;--1536

select COUNT(*) from policy_fee_xref
     where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19'   ;--0

select COUNT(*) from product_price_tbl
     where   TO_CHAR(LAST_UPDATED_TS,'YYYY-MM-DD') = '2022-08-19'   ;--9544