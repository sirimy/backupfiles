


select * from BOSH.SYNC_PROCESS_STATUS_TBL order by RUN_ID desc;



select * from BOSH.PRICING_SCHEME_DIM
where END_DT > sysdate AND PRICING_SCHEME_NAME in ('AO Thermador','AO Bosch')
order by PRICING_SCHEME_KEY;
+------------------+-------------------+-------------------+-------------------+----------+----------------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NAME|PRICING_SCHEME_DESC|PRICING_SCHEME_TYPE|LOAD_DT   |INSERT_AUDIT_KEY|
+------------------+-------------------+-------------------+-------------------+----------+----------------+
|227               |AO Bosch           |AO Bosch           |OOW                |2025-07-22|982962          |
|245               |AO Thermador       |AO Thermador       |OOW                |2025-07-22|982962          |
+------------------+-------------------+-------------------+-------------------+----------+----------------+
+------------------+-------------------+-------------------+----------+-------------------+----------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NAME|PRICING_SCHEME_DESC|LOAD_DT   |PRICING_SCHEME_TYPE|END_DT    |
+------------------+-------------------+-------------------+----------+-------------------+----------+
|281               |AO Bosch           |AO Bosch           |2026-02-11|OOW                |2099-12-31|
|299               |AO Thermador       |AO Thermador       |2026-02-11|OOW                |2099-12-31|
+------------------+-------------------+-------------------+----------+-------------------+----------+



select * from BOSH.POLICY_TBL where DESCRIPTION like '%AO%'
                              and EXP_DT > sysdate
                              order by POLICY_KEY desc; ;

begin
    pk_campaign_utilities.prc_populate_criteria('AS1-BSH-3' , 'AS000', '', '', 'between drop_dt -1400 and drop_dt -350', '1','12' ,'N', 'v_available_universe', 'brand_nm= ''BOSCH'' and Product_Category NOT IN (‘BUILT-IN COFFEE MAKER’, ‘VENTILATION’)');
    pk_campaign_utilities.prc_populate_criteria('AS1-THR-6' , 'AS000', '', '', 'between drop_dt -1050 and drop_dt -350', '1','24' ,'N', 'v_available_universe', 'brand_nm= ''THERMADOR'' and Product_Category NOT IN (‘BUILT-IN COFFEE MAKER’)');
end;


select cri.*, ai.creation_dt, au.CREATION_DT as last_updated_dt
  from P_criteria_dim cri left join audit_tbl ai on ai.audit_key = insert_audit_key
       left join audit_tbl au on au.audit_key = UPDATE_AUDIT_KEY
 where 1=1
   and active_ind = 'N'
   and (criteria_xid LIKE 'AS%') and au.CREATION_DT >= date '2024-07-01';

+------------+------------+-----------+----------+-----------+---------------+--------------------------------------+--------------------+---------------+--------------+--------------------+---------------------------------------------------------------------------------------------+----------------+----------------+---------------+------------------+--------------------------+--------------------------+
|CRITERIA_KEY|CRITERIA_XID|CRITERIA_CD|ACTIVE_IND|PURCHASE_DT|REGISTRATION_DT|LATEST_COVERAGE_EXP_DT                |LATEST_COVERAGE_TYPE|WARRANTY_MONTHS|COMMERCIAL_IND|SELECTION_TBL       |ADDITIONAL_SQL_TXT                                                                           |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SCORING_FILE_CD|STREAM_LENGTH_DAYS|CREATION_DT               |LAST_UPDATED_DT           |
+------------+------------+-----------+----------+-----------+---------------+--------------------------------------+--------------------+---------------+--------------+--------------------+---------------------------------------------------------------------------------------------+----------------+----------------+---------------+------------------+--------------------------+--------------------------+
|20862       |AS1-BSH-1   |AS000      |N         |null       |null           |between drop_dt -1050 and drop_dt -350|1                   |12             |N             |v_available_universe|brand_nm= 'BOSCH' and Product_Category NOT IN ('BUILT-IN COFFEE MAKER', 'VENTILATION')       |704326          |1010543         |null           |42                |2023-07-19 05:11:54.000000|2025-09-26 12:04:39.000000|
|20863       |AS1-BSH-2   |AS000      |N         |null       |null           |between drop_dt -1050 and drop_dt -350|1                   |12             |N             |v_available_universe|brand_nm= 'BOSCH' and Product_Category IN ('BUILT-IN COFFEE MAKER', 'VENTILATION')           |704327          |1010543         |null           |42                |2023-07-19 05:11:54.000000|2025-09-26 12:04:39.000000|
|21002       |AS1-THR-4   |AS000      |N         |null       |null           |between drop_dt -1050 and drop_dt -350|1                   |24             |N             |v_available_universe|brand_nm= 'THERMADOR' and MSRP <= 17500 and Product_Category NOT IN ('BUILT-IN COFFEE MAKER')|856084          |1010543         |null           |42                |2024-08-17 07:43:26.000000|2025-09-26 12:04:39.000000|
|21003       |AS1-THR-5   |AS000      |N         |null       |null           |between drop_dt -1050 and drop_dt -350|1                   |24             |N             |v_available_universe|brand_nm= 'THERMADOR' and MSRP <= 17500 and Product_Category IN ('BUILT-IN COFFEE MAKER')    |856085          |1010543         |null           |42                |2024-08-17 07:43:26.000000|2025-09-26 12:04:39.000000|
+------------+------------+-----------+----------+-----------+---------------+--------------------------------------+--------------------+---------------+--------------+--------------------+---------------------------------------------------------------------------------------------+----------------+----------------+---------------+------------------+--------------------------+--------------------------+


select  CRITERIA_KEY, criteria_xid, criteria_cd,cell_key, POPULATION_PCT, cell_cd,
       cell_xid, cell_nm, cell_group_xid, cell_group_nm,
       pricing_scheme_key, pricing_scheme_name, pricing_scheme_desc, CAMPAIGN_NM
       , warranty_months, additional_sql_txt, cell_group_key, state_machine_key, state_machine_nm
  from P_criteria_cell_xref
       join P_criteria_dim cr using(criteria_key) join AUDIT_TBL ai on ai.AUDIT_KEY = cr.INSERT_AUDIT_KEY
       left join audit_tbl au on au.audit_key = cr.UPDATE_AUDIT_KEY
       join P_cell_dim using (cell_key)
       join P_cell_group_dim using (cell_group_key)
       join P_campaign_dim cmp using (campaign_key)
       left join p_pricing_scheme_dim psd using (pricing_scheme_key)
       left join P_STATE_CELL_GROUP_XREF smcgx using (cell_group_key)
       left join P_STATE_MACHINE_TBL sm using (state_machine_key)
 where 1=1
   and active_ind = 'N'
   and (criteria_xid LIKE 'AS%') and au.CREATION_DT >= date '2024-07-01'
order by CRITERIA_XID;

+------------+------------+-----------+--------+--------------+-------+--------+------------------------------------------+--------------+------------------------------+------------------+--------------------------+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+--------------+-----------------+----------------+
|CRITERIA_KEY|CRITERIA_XID|CRITERIA_CD|CELL_KEY|POPULATION_PCT|CELL_CD|CELL_XID|CELL_NM                                   |CELL_GROUP_XID|CELL_GROUP_NM                 |PRICING_SCHEME_KEY|PRICING_SCHEME_NAME       |PRICING_SCHEME_DESC       |CAMPAIGN_NM      |WARRANTY_MONTHS|ADDITIONAL_SQL_TXT                                                                           |CELL_GROUP_KEY|STATE_MACHINE_KEY|STATE_MACHINE_NM|
+------------+------------+-----------+--------+--------------+-------+--------+------------------------------------------+--------------+------------------------------+------------------+--------------------------+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+--------------+-----------------+----------------+
|20862       |AS1-BSH-1   |AS000      |20865   |1.00          |01     |OS01-BSH|Aftermarket OOW Sweep 1 Effort - Bosch    |AS-01         |Aftermarket OOW Sweep 1 Effort|270               |AO Bosch - Old Model Sweep|AO Bosch - Old Model Sweep|Aftermarket Sweep|12             |brand_nm= 'BOSCH' and Product_Category NOT IN ('BUILT-IN COFFEE MAKER', 'VENTILATION')       |6846          |10024            |AM OOW Sweep    |
|20863       |AS1-BSH-2   |AS000      |20865   |1.00          |01     |OS01-BSH|Aftermarket OOW Sweep 1 Effort - Bosch    |AS-01         |Aftermarket OOW Sweep 1 Effort|270               |AO Bosch - Old Model Sweep|AO Bosch - Old Model Sweep|Aftermarket Sweep|12             |brand_nm= 'BOSCH' and Product_Category IN ('BUILT-IN COFFEE MAKER', 'VENTILATION')           |6846          |10024            |AM OOW Sweep    |
|21002       |AS1-THR-4   |AS000      |20866   |1.00          |11     |OS01-THR|Aftermarket OOW Sweep 1 Effort - Thermador|AS-01         |Aftermarket OOW Sweep 1 Effort|245               |AO Thermador              |AO Thermador              |Aftermarket Sweep|24             |brand_nm= 'THERMADOR' and MSRP <= 17500 and Product_Category NOT IN ('BUILT-IN COFFEE MAKER')|6846          |10024            |AM OOW Sweep    |
|21003       |AS1-THR-5   |AS000      |20866   |1.00          |11     |OS01-THR|Aftermarket OOW Sweep 1 Effort - Thermador|AS-01         |Aftermarket OOW Sweep 1 Effort|245               |AO Thermador              |AO Thermador              |Aftermarket Sweep|24             |brand_nm= 'THERMADOR' and MSRP <= 17500 and Product_Category IN ('BUILT-IN COFFEE MAKER')    |6846          |10024            |AM OOW Sweep    |
+------------+------------+-----------+--------+--------------+-------+--------+------------------------------------------+--------------+------------------------------+------------------+--------------------------+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+--------------+-----------------+----------------+



select * from BOSH.PRICING_SCHEME_DIM where PRICING_SCHEME_DESC like '%AO%' and END_DT > sysdate order by LOAD_DT desc;
+------------------+-------------------+-------------------+----------+-------------------+----------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NAME|PRICING_SCHEME_DESC|LOAD_DT   |PRICING_SCHEME_TYPE|END_DT    |
+------------------+-------------------+-------------------+----------+-------------------+----------+
|281               |AO Bosch           |AO Bosch           |2026-02-11|OOW                |2099-12-31|
|299               |AO Thermador       |AO Thermador       |2026-02-11|OOW                |2099-12-31|
+------------------+-------------------+-------------------+----------+-------------------+----------+


select PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS,COUNT(*) from BOSH.PRODUCT_PRICE_DIM PRD
        JOIN   BOSH.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = PRD.PRICING_SCHEME_KEY
where PSD.END_DT > sysdate AND PRICING_SCHEME_NAME in ('AO Thermador','AO Bosch')
group by PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS,PSD.PRICING_SCHEME_KEY
order by PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS;
+------------------+-------------------+-----------+--------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NAME|TERM_MONTHS|COUNT(*)|
+------------------+-------------------+-----------+--------+
|281               |AO Bosch           |12         |662     |
|281               |AO Bosch           |24         |662     |
|281               |AO Bosch           |48         |662     |
|299               |AO Thermador       |12         |512     |
|299               |AO Thermador       |36         |512     |
+------------------+-------------------+-----------+--------+

select PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS,COUNT(*) from (
        select PRD.* from BOSH.PRODUCT_PRICE_DIM PRD
                JOIN   BOSH.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = PRD.PRICING_SCHEME_KEY
        where PSD.END_DT > sysdate AND PRICING_SCHEME_NAME in ( 'AO Bosch')
        AND PRD.TERM_MONTHS <> 12
) PRD
        JOIN   BOSH.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = PRD.PRICING_SCHEME_KEY
group by PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS,PSD.PRICING_SCHEME_KEY
order by PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS;
+------------------+-------------------+-----------+--------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NAME|TERM_MONTHS|COUNT(*)|
+------------------+-------------------+-----------+--------+
|281               |AO Bosch           |24         |662     |
|281               |AO Bosch           |48         |662     |
+------------------+-------------------+-----------+--------+



select PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS,COUNT(*) from (
        select PRD.* from BOSH.PRODUCT_PRICE_DIM PRD
                JOIN   BOSH.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = PRD.PRICING_SCHEME_KEY
        where PSD.END_DT > sysdate AND PRICING_SCHEME_NAME in ('AO Thermador' )

) PRD
        JOIN   BOSH.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = PRD.PRICING_SCHEME_KEY
group by PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS,PSD.PRICING_SCHEME_KEY
order by PSD.PRICING_SCHEME_NAME,PRD.TERM_MONTHS;
+------------------+-------------------+-----------+--------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NAME|TERM_MONTHS|COUNT(*)|
+------------------+-------------------+-----------+--------+
|299               |AO Thermador       |12         |512     |
|299               |AO Thermador       |36         |512     |
+------------------+-------------------+-----------+--------+
