select serialized_item_id, latest_coverage_exp_dt, latest_coverage_exp_dt + interval '30 day' from serialized_item
where serialized_item_id in (22877906);

update serialized_item set latest_coverage_exp_dt = latest_coverage_exp_dt + interval '30 day'
where serialized_item_id in (183349383);
--1 rows
commit;


--------------------------------------
select oft.*, ofit.*, pol.description
  from offer_tbl oft join  offer_item_tbl ofit on ofit.offer_id = oft.offer_id
       left join policy pol on pol.policy_id = ofit.policy_id
 where 1=1
--   and oft.active_ind = 'Y'
   and oft.offer_id < 500000   --real time offer
   and customer_id = <Enter customer id>
--    and serialized_item_id = <Enter serialized_item_id >   --enter required serialized_item_id if there are multiple units
   and offer_start_utc_ts > current_date - interval '45' day   --recent real time offers only
  order by customer_id, serialized_item_id, offer_exp_dt, display_group_num, ofit.display_seq_num
limit 40;

--------------------------------

delete from offer_item_tbl where offer_id = :offer_id;
delete from offer_tbl where offer_id = :offer_id;
commit;

-----------------------------------------
select serialized_item_id, latest_coverage_exp_dt, latest_coverage_exp_dt - interval '30 day' from serialized_item
where serialized_item_id in (183349383);
update serialized_item set latest_coverage_exp_dt = latest_coverage_exp_dt - interval '30 day'
where serialized_item_id in (183349383);
--1 rows
commit;

---------------------------------------------------------------

--Following update is reqd for Aftermarket offers only
select oft.*, p.description, t.day
from offer_item_tbl oft join policy p on oft.policy_id = p.policy_id join term t on p.term_id = t.term_id
where offer_id IN (
         select ot.offer_id from offer_tbl ot where customer_id = <enter customer_id ...>
                                        and offer_start_utc_ts >= current_date - interval '1' day
    )
and offer_id < 500000
and active_ind = 'Y'
order by offer_id, t.day, policy_id;


-- update offer to reflect actual coverage dates
update offer_item_tbl
set
     coverage_start_dt = <Enter coverage_start_dt ...>
where offer_id IN (
    select ot.offer_id from offer_tbl ot where customer_id = 5377034
    and   offer_start_utc_ts >= current_date - interval '1' day and ot.active_ind = 'Y'
    )
-- and serialized_item_id = <serialized_item_id being handled>
and active_ind = 'Y'
-- and offer_id = <offer_id created above>
and offer_id < 500000;
--4 rows
commit;


WITH src AS (
    select oft.*, p.description, t.day as t_days
     from offer_item_tbl oft join policy p on oft.policy_id = p.policy_id join term t on p.term_id = t.term_id
    where offer_id IN (
        select ot.offer_id from offer_tbl ot where customer_id = <Enter customer_id ...>
                                             and offer_start_utc_ts >= current_date - interval '1' day and ot.active_ind = 'Y'
        )
-- and offer_id = <offer_id created above>
    and offer_id < 500000
    )
UPDATE offer_item_tbl tgt
   set coverage_exp_dt = tgt.coverage_start_dt + (src.t_days * interval '1 day')
  FROM src
 WHERE  tgt.offer_id = src.offer_id and tgt.serialized_item_id = src.serialized_item_id and tgt.offer_line_id = src.offer_line_id
   and src.active_ind = 'Y'
;
--4 rows
commit;
