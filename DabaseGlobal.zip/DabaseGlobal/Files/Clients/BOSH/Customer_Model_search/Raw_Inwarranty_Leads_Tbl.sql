select case when Model_Number like '%/%' then substr(Model_Number,1,instr(Model_Number,'/') -1) else Model_Number end AS  PRODUCT_UNIQUE_ID,
       r.*, ai.CREATION_DT
  from bosh.raw_inwarranty_leads_tbl r left join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
--where rownum <= 10
-- where ris_nr = '&&ris_nr' --IN ('T3061202', 'T3134955', 'T3137466')
--  where Serial_Nr = '&&Serial_Nr'
--  and FD = '&&FD'
-- and Model_Number like 'SHEM78WH5N%' 
where (  1=2 -- SUZIE	VAUGHAN
--       or ((first_name like 'SUZIE V%' ))
               --and last_name = 'VAUGHAN')) -- and state = 'NY')
--       or ((last_name = 'JIM' and first_name = 'FYFE') and state = 'TX')
      or nvl(EMAIL, 'xyz')  IN ('CHARLIE@CLARKHOLDINGS.CA')
--       or NVL(LOCATION_PHONE, '123') like '%3145705987' OR NVL(LOCATION_PHONE, '123') like '%+3145705987' OR NVL(LOCATION_PHONE, '123') like '%3145705987'
--       or ( nvl(trim(address), 'xyz') like '138 E 50%' and state = 'NY')
     )
 order by  brand, Model_Number, purchase_date nulls last, insert_audit_key
;

--inwarranty files are unique on ris_nr
SELECT FILE_NM, TRUNC (AT.CREATION_DT), count(*) All_Cnts, count(ADDRESS) as addresses, count(*) - count(ADDRESS) as diff,
        count(case when ERROR_DESC is null then RIS_NR end) as All_clean_cnts,
        count(distinct ris_nr), count(EMAIL) as Emails
--        , min(PURCHASE_DATE), max(PURCHASE_DATE)
--        max(to_date(PURCHASE_DATE, 'MM/DD/YYYY'))
  FROM bosh.raw_inwarranty_leads_tbl R
       LEFT JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
 WHERE 1=1
--   and r.ERROR_DESC is null
  AND TRUNC (AT.CREATION_DT) >= DATE '2023-07-01'
--   AND (  
--        file_nm LIKE '%cdb_%201801%'   or file_nm LIKE '%cdb_%201801%' or
--        file_nm LIKE '%cdb_%201810%'   or file_nm LIKE '%cdb_%201811%'
--        )
 GROUP BY FILE_NM, TRUNC (AT.CREATION_DT)
--  HAVING count(*) < 5000
--  having count(*) <> count(ADDRESS)
 ORDER BY  TRUNC (AT.CREATION_DT) desc, FILE_NM desc
 ;


--This sql is helpful to understand what data is being received in inwarranty files
select file_nm, trunc(CREATION_DT),
       count(*), count(distinct si.si_key) as unique_leads,
       count(distinct ris_nr || brand || substr(Model_Number, 1, instr(Model_Number, '/')-1) ) as Unique_Cnts
       ,min(CLAIM_REPAIR_DATE), max(CLAIM_REPAIR_DATE)
  from
       bosh.serialized_item_dim si
       join bosh.si_output_tbl_arch ar on si.si_key = posted_serial_item_key
       join bosh.raw_inwarranty_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
       join audit_tbl a on (audit_key = r.insert_audit_key)
       join bosh.serialized_item_ext_dim six on six.si_key = si.si_key
 where 1=1
--   and ERROR_DESC is null
  and creation_dt >= date '2023-07-01'
 group by file_nm, trunc(CREATION_DT)
 having count(*) > 100
 order by 1, 3;
-------------------------------------------------------------------------------------------------------
select * from (select * from raw_inwarranty_leads_tbl r order by dbms_random.random) where rownum <= 100;
select * from (select * from raw_inwarranty_leads_tbl r where ERROR_DESC is not null order by dbms_random.random) where rownum <= 100;

select * from (select * from bosh.raw_inwarranty_leads_tbl r order by dbms_random.random) where rownum <= 20;

select count(*), count(distinct ris_nr), count(distinct NAME_ADDRESS_HASH), count(PURCHASE_DATE) from raw_inwarranty_leads_tbl r;

select count(*), count(distinct ris_nr) from bosh.raw_inwarranty_leads_tbl r;
-------------------------------------------------------------------------------------------------------



SELECT count(*),  
       count(distinct ris_nr || brand || substr(Model_Number, 1, instr(Model_Number, '/')-1) ) as Unique_Cnts 
  FROM BOSH.raw_inwarranty_leads_tbl R
       --JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
 WHERE 1=1
--   and TRUNC (AT.CREATION_DT) >= DATE '2017-07-01'
   and r.file_nm like '%cosmos%'        
--   and file_nm IN ('bsh_after_cdb_20171115-20171116.txt', 'bsh_after_cdb_20171115-20171207.txt')
; 
--79055    39455   

SELECT R.*
  FROM BOSH.raw_inwarranty_leads_tbl R
       JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
 WHERE 1=1
   and TRUNC (AT.CREATION_DT) >= DATE '2017-12-01'
   and r.file_nm like 'bsh_after_cdb_iw_asp_20211001.txt'
   and ADDRESS like '%#%'
   --and iobject = '0063553008'
 order by dbms_random.random;
 
select file_nm, duplicate_ind, count(*), count(distinct si.si_key), 
       count(distinct ris_nr || brand || substr(Model_Number, 1, instr(Model_Number, '/')-1) ) as Unique_Cnts
       ,min(si.REGISTRATION_DT), max(si.REGISTRATION_DT)
  from  
       bosh.serialized_item_dim si 
       join bosh.si_output_tbl_arch ar on si.si_key = posted_serial_item_key
       join bosh.raw_inwarranty_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
       join audit_tbl a on (audit_key = si.insert_audit_key)
       join bosh.serialized_item_ext_dim six on six.si_key = si.si_key  
 where 1=1
--       file_nm LIKE '%cdb_%201810%'
  and creation_dt >= date '2023-07-01'
--    and si.SI_KEY IN (2012033, 2088049)
 group by file_nm, duplicate_ind
  ;         
 
 
select si.si_key, r.*
  from bosh.si_output_tbl_arch ar 
       join bosh.serialized_item_dim si on si.si_key = posted_serial_item_key
       join bosh.raw_inwarranty_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
 where 1=1
   --and r.file_nm like '%cosmos%'   
   and si.SI_KEY IN (2012033, 2088049);
   
select * from bosh.si_output_tbl_arch ar where posted_serial_item_key IN (786631, 794233);
select * from raw_inwarranty_leads_tbl r where unique_seq_no IN (2670233, 2682606);

select trunc(creation_dt), file_nm, count(distinct si.si_key), count(*), count(case when six.duplicate_ind = 'Y' then 1 end) as dupes
  from P_serialized_item_dim si left join P_serialized_item_ext_dim six on six.si_key = si.si_key
       join bosh.si_output_tbl_arch ar on si.si_key = posted_serial_item_key
       join bosh.raw_inwarranty_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
       join P_audit_tbl a on (audit_key = si.insert_audit_key)
 where 1=1
--   AND TRUNC (a.CREATION_DT) >= DATE '2018-01-01'
   AND (file_nm = 'bsh_after_cdb_asp_20180523_1-20180523.txt')
--   AND (file_nm LIKE '%cdb_%201801%'   or file_nm LIKE '%cdb_%201802%')
 group by trunc(creation_dt), file_nm
 having count(*) > 50
 order by trunc(creation_dt), file_nm;
 

select UPPER(TRIM(EMAIL)), count(distinct ris_nr), count(distinct Model_Number) 
  from bosh.raw_inwarranty_leads_tbl 
 where TRIM(EMAIL) is not null
   and TRIM(EMAIL)  not like '%NOEMAIL%' and TRIM(EMAIL)  not like '%NOMAIL%'
   and TRIM(EMAIL)  not like '%NONE@NONE%' and TRIM(EMAIL)  not like 'NA@%'
   and TRIM(EMAIL)  not like '%NOREPLY%' and TRIM(EMAIL)  not like 'NA@%'
   and TRIM(EMAIL)  not like '%NO.EMAIL%' and TRIM(EMAIL)  not like 'NA@%'
   
 group by UPPER(TRIM(EMAIL)) 
having count(distinct ris_nr) > 5
--    or count(distinct Model_Number) > 10
 order by count(distinct ris_nr) desc, UPPER(TRIM(EMAIL))
;

select * from raw_inwarranty_leads_tbl r where rownum <= 10;

select * from (select * from raw_inwarranty_leads_tbl r where serial_nr like '%E%' order by dbms_random.random) ;

-- update raw_inwarranty_leads_tbl r set ERROR_DESC = 'Corrupted Serial_NR'  where serial_nr like '%E%' and ERROR_DESC is null;
--63 rows
-- commit;


select * from common_load_hold_tbl where UNIQUE_SEQ_NO in (select r.UNIQUE_SEQ_NO from RAW_INWARRANTY_LEADS_TBL r where r.ERROR_DESC is not null);
-- delete from common_load_hold_tbl where UNIQUE_SEQ_NO in (select r.UNIQUE_SEQ_NO from RAW_INWARRANTY_LEADS_TBL r where r.ERROR_DESC is not null);
--63 rows
-- commit;


