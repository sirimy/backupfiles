select distinct case when E_NUMBER like '%/%' then substr(E_NUMBER,1,instr(E_NUMBER,'/') -1) else E_NUMBER end AS  PRODUCT_UNIQUE_ID,
       r.ACCOUNT_ID, FIRST_NM, LAST_NM, HOUSE_NO, STREET_ADDR1, STREET_ADDR2, CITY_NM, STATE_CD, ZIP_CD_TX, COUNTRY_CD, MOBILE_PHONE_NO,
       TELEPHONE_NO, EMAIL_ADDRESS_TX, BRAND, PRODUCT_CATEGORY, E_NUMBER, REGISTRATION_DT, PURCHASE_DT
       ,FILE_NM, INSERT_AUDIT_KEY, ERROR_DESC, UNIQUE_SEQ_NO, trunc (AT.CREATION_DT) as CREATION_DT
       ,EMAIL_PREF_IND
       ,MANUFACTURING_DATE_FD, CONSECUTIVE_NUMBER
       --,UPDATE_AUDIT_KEY,
  from bosh.raw_leads_tbl r 
       LEFT JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
where 1=1
-- and (FIRST_NM like 'DANIEL%' )
-- and  account_id = :account_id
-- and  account_id IN ('T7592508', '')
-- and COSMO_ID like '%2967571'
-- and e_number like :E_number
-- and e_number in ('T24IR905SP', '', '')
-- and case when E_NUMBER like '%/%' then substr(E_NUMBER,1,instr(E_NUMBER,'/') -1) else E_NUMBER end in ('SHP65CP5N', '')
and (
       1=2
--        or
--        account_id IN ('T7488762', '')
       or
       EMAIL_ADDRESS_TX in ('JIMTALBOT63@GMAIL.COM')
--        or
--        NVL(TELEPHONE_NO, '123') like '%3174172714' OR NVL(TELEPHONE_NO, '123') like '%3174172714' OR NVL(TELEPHONE_NO, '123') like '%3174172714'
--        or
--        NVL(MOBILE_PHONE_NO, '123') like '%3108046963' OR NVL(MOBILE_PHONE_NO, '123') like '%+3108046963' OR NVL(MOBILE_PHONE_NO, '123') like '%3108046963'
--        or
--        trim(street_addr1) like '138%50%' and state_cd = 'NY'
--        or
--        (FIRST_NM = 'CHARLIE' and LAST_NM IN ('CLARK', '') and NVL(STATE_CD, 'TX') = 'MB')
      )
--   and ERROR_DESC is null
--  order by account_id, case when E_NUMBER like '%/%' then substr(E_NUMBER,1,instr(E_NUMBER,'/') -1) else E_NUMBER end
--           ,e_number, purchase_dt nulls last, CREATION_DT
order by CREATION_DT
;

select * from (select * from raw_leads_tbl where ERROR_DESC IS NULL order by dbms_random.random ) where rownum <= 50 ;
select * from (select * from raw_leads_tbl where ERROR_DESC IS not null order by dbms_random.random ) where rownum <= 50 ;

select r.*, creation_dt from bosh.RAW_LEADS_TBL r LEFT JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
-- where file_nm = 'bsh_after_cdb_20171129-20171130.txt';
-- where file_nm = 'bsh_after_cdb_cosmos_201712013-20171214.txt';
-- where file_nm like 'photo_registrations_20180228-20180228.csv%'
-- where file_nm like 'bsh_after_cdb_asp_201907%'
 --where file_nm like 'bsh_after_cdb_asp_20191204.txt%'
 where 1=1
 and  account_id in ('T6976775', '')
--   and creation_dt >= date '2021-10-01'
--   and error_desc is null
--   and EMAIL_ADDRESS_TX in ('PERCYZEL@GMAIL.COM')
-- and case when E_NUMBER like '%/%' then substr(E_NUMBER,1,instr(E_NUMBER,'/') -1) else E_NUMBER end = 'T36FT810NS'
--   and trim(street_addr1) is null
--   and trim(email_address_tx) is null
-- and CONSECUTIVE_NUMBER is not null
--  order by INSERT_AUDIT_KEY, FILE_NM;
order by DBMS_RANDOM.RANDOM();



SELECT FILE_NM, count(*) All_Cnts, count(ERROR_DESC) as errors, count(trim(brand)) brand_cnt
       ,count(replace(trim(registration_dt), '0')) as regist_cnts, count(replace(trim(purchase_dt), '0')) as purchase_cnts
       ,count(distinct account_id || brand || e_number) as Unique_Cnts
       , (AT.CREATION_DT), count(case when trim(brand) is null and trim(purchase_dt) is null then 1 end) as dirty_leads
       ,count( case when trim(street_addr1) is null and trim(zip_cd_tx) is null then 1 end) as no_address
       ,count( case when trim(street_addr1) is null and trim(zip_cd_tx) is null and trim(EMAIL_ADDRESS_TX) is not null and trim(email_pref_ind) is null then 1 end) as no_address_with_email       
       ,count(email_pref_ind) as email_pref_ind
       ,count(distinct MANUFACTURING_DATE_FD || CONSECUTIVE_NUMBER) as unique_sns
       ,count(distinct IOBJECT), count(distinct COSMO_ID)
       ,min(PURCHASE_DT), min(REGISTRATION_DT), max(PURCHASE_DT), max(REGISTRATION_DT)
  FROM bosh.RAW_LEADS_TBL R
       LEFT JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
 WHERE 1=1
   AND TRUNC (AT.CREATION_DT) >= DATE '2024-02-01'
--    and error_desc is null
   --and (purchase_dt is null or purchase_dt like '00000%')
--   AND TRUNC (AT.CREATION_DT) <= DATE '2019-08-10'
--   and file_nm not LIKE '%hc%'
     and (FILE_NM like '%2023%' or FILE_NM like '%2024%')
--   AND (  
--        file_nm LIKE '%cdb_%201801%'   or file_nm LIKE '%cdb_%201801%' or
--        file_nm LIKE '%cdb_%201810%'   or file_nm LIKE '%cdb_%201811%'
--        )
 GROUP BY FILE_NM,  (AT.CREATION_DT)
--  having count(*) > 20000
 ORDER BY TRUNC (AT.CREATION_DT), FILE_NM
 ;


SELECT count(*),
       count(distinct account_id || brand || substr(e_number, 1, instr(e_number, '/')-1) ) as Unique_Cnts 
  FROM BOSH.RAW_LEADS_TBL R
       --JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
 WHERE 1=1
--   and TRUNC (AT.CREATION_DT) >= DATE '2017-07-01'
   and r.file_nm like '%cosmos%'        
--   and file_nm IN ('bsh_after_cdb_20171115-20171116.txt', 'bsh_after_cdb_20171115-20171207.txt')
; 
--79055    39455   

SELECT R.*
  FROM BOSH.RAW_LEADS_TBL R
       JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
 WHERE 1=1
   and TRUNC (AT.CREATION_DT) >= DATE '2020-08-01'
   and ERROR_DESC is null
--   and r.file_nm like '%cosmos%'   
   --and iobject = '0063553008'
 order by dbms_random.random;
 
select file_nm, SOURCE, count(*), count(distinct si.si_key),
       count(distinct account_id || brand || substr(r.e_number, 1, instr(r.e_number, '/')-1) ) as Unique_Cnts
  from  
       bosh.serialized_item_dim si 
       join bosh.si_output_tbl_arch ar on si.si_key = posted_serial_item_key
       join bosh.raw_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
       join audit_tbl a on (audit_key = si.insert_audit_key)
       join bosh.serialized_item_ext_dim six on six.si_key = si.si_key  
 where 1=1
--   and r.file_nm like '%cosmos%'
     and file_nm = 'bsh_after_cdb_catchup_re_20230801_20231031.txt'
  and creation_dt >= date '2023-08-01'
--   and creation_dt <= date '2023-11-30'
--    and si.SI_KEY IN (1408821, 1410551)
 group by file_nm, SOURCE
  ;         
 
 
select si.si_key, r.*
  from bosh.si_output_tbl_arch ar 
       join bosh.serialized_item_dim si on si.si_key = posted_serial_item_key
       join bosh.raw_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
 where 1=1
   --and r.file_nm like '%cosmos%'   
   and si.SI_KEY IN (1408821, 1410551);
   
select * from bosh.si_output_tbl_arch ar where posted_serial_item_key IN (786631, 794233);
select * from raw_leads_tbl r where unique_seq_no IN (2670233, 2682606);

select trunc(creation_dt), file_nm, count(distinct si.si_key), count(*), count(case when six.duplicate_ind = 'Y' then 1 end) as dupes
  from P_serialized_item_dim si left join P_serialized_item_ext_dim six on six.si_key = si.si_key
       join bosh.si_output_tbl_arch ar on si.si_key = posted_serial_item_key
       join bosh.raw_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
       join P_audit_tbl a on (audit_key = si.insert_audit_key)
 where 1=1
--   AND TRUNC (a.CREATION_DT) >= DATE '2018-01-01'
   AND (file_nm = 'bsh_after_cdb_asp_20180523_1-20180523.txt')
--   AND (file_nm LIKE '%cdb_%201801%'   or file_nm LIKE '%cdb_%201802%')
 group by trunc(creation_dt), file_nm
 having count(*) > 50
 order by trunc(creation_dt), file_nm;
 
select REGISTRATION_DT, count(*)  
  from bosh.RAW_LEADS_TBL r
 where file_nm like 'bsh_after_cdb_asp_20180718-20180920%'
 group by REGISTRATION_DT
 order by REGISTRATION_DT; 
 
select UPPER(TRIM(EMAIL_ADDRESS_TX)), count(distinct account_id), count(distinct e_number) 
  from bosh.raw_leads_tbl 
 where TRIM(EMAIL_ADDRESS_TX) is not null
   and TRIM(EMAIL_ADDRESS_TX)  not like '%NOEMAIL%' and TRIM(EMAIL_ADDRESS_TX)  not like '%NOMAIL%'
   and TRIM(EMAIL_ADDRESS_TX)  not like '%NONE@NONE%' and TRIM(EMAIL_ADDRESS_TX)  not like 'NA@%'
   and TRIM(EMAIL_ADDRESS_TX)  not like '%NOREPLY%' and TRIM(EMAIL_ADDRESS_TX)  not like 'NA@%'
   and TRIM(EMAIL_ADDRESS_TX)  not like '%NO.EMAIL%' and TRIM(EMAIL_ADDRESS_TX)  not like 'NA@%'
   
 group by UPPER(TRIM(EMAIL_ADDRESS_TX)) 
having count(distinct account_id) > 5
--    or count(distinct e_number) > 10
 order by count(distinct account_id) desc, UPPER(TRIM(EMAIL_ADDRESS_TX))
;

select * from RAW_LEADS_TBL r where rownum <= 10;

select * from p_visitor_lkp where visitor_xid = 'T3968220';


--Status of errored out records
select upper(trim(brand)),
        error_desc,
        count(*) All_Cnts 
       ,count(distinct account_id || brand || e_number || substr(e_number, 1, instr(e_number, '/')-1) || replace(trim(purchase_dt), '0')) as Unique_Cnts
       ,count(trim(brand)) brand_cnt, count(trim(registration_dt)) as regist_cnts, count(replace(trim(purchase_dt), '0')) as purchase_cnts
       ,count(case when trim(brand) is null and trim(purchase_dt) is null then 1 end) as dirty_leads
       ,count( case when trim(street_addr1) is null and trim(zip_cd_tx) is null then 1 end) as no_address
       ,count( case when trim(street_addr1) is null and trim(zip_cd_tx) is null and trim(EMAIL_ADDRESS_TX) is not null then 1 end) as no_address_with_email 
from   bosh.RAW_LEADS_TBL r
       LEFT JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
where  1=1
--and    (E_NUMBER like 'DF250762%' or E_NUMBER like 'DF251762%') --no rows
--and    upper(trim(brand)) = 'GAGGENAU'
and    creation_dt >= date '2021-11-01'
-- and    error_desc is not null
group by upper(trim(brand)), error_desc
order by upper(trim(brand)), error_desc;


select * from RAW_LEADS_TBL where rownum <= 5 ;

select * from RAW_builder_LEADS_TBL where rownum <= 5 ;

-- delete from raw_leads_tbl;
-- commit;
alter table raw_leads_tbl modify MANUFACTURING_DATE_FD varchar2(40);


select r.INSERT_AUDIT_KEY, CREATION_DT, count(*)
from   bosh.RAW_LEADS_TBL r join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
where  r.FILE_NM = 'bsh_after_cdb_20200501_20200731.txt' --and MANUFACTURING_DATE_FD like '0000%0000'
group by r.INSERT_AUDIT_KEY, CREATION_DT
order by r.INSERT_AUDIT_KEY, CREATION_DT;

select r.*, CREATION_DT
from   bosh.RAW_LEADS_TBL r join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
where  r.FILE_NM = 'bsh_after_cdb_20200501_20200731.txt' --and MANUFACTURING_DATE_FD like '0000%0000'
and    length(MANUFACTURING_DATE_FD) > 4
and    INSERT_AUDIT_KEY = 385570;
--no rows

select MANUFACTURING_DATE_FD, count(*)
from   bosh.RAW_LEADS_TBL r join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
where  r.FILE_NM = 'bsh_after_cdb_20200501_20200731.txt' --and MANUFACTURING_DATE_FD like '0000%0000'
and    INSERT_AUDIT_KEY = 385570
group by MANUFACTURING_DATE_FD order by 1;

select six.*, CREATION_DT
  from P_serialized_item_dim si
       left join P_serialized_item_ext_dim six on six.si_key = si.si_key
       left join P_audit_tbl a on (audit_key = si.insert_audit_key)
       left join P_product_dim pr on (pr.product_key = si.product_key )
       left join P_product_category_dim pc on (pc.product_category_key  = pr.product_category_key )
       left join P_product_category_dim ppc on (ppc.product_category_key  = pc.parent_category_key )
where  1=1
and    creation_dt >= date '2020-08-01'
and    source = 'WEB';


select FILE_NM,
        error_desc,
        count(*) All_Cnts
       ,count(distinct account_id || brand || e_number || substr(e_number, 1, instr(e_number, '/')-1) || replace(trim(purchase_dt), '0')) as Unique_Cnts
       ,count(trim(brand)) brand_cnt, count(trim(registration_dt)) as regist_cnts, count(replace(trim(purchase_dt), '0')) as purchase_cnts
       ,count(case when trim(brand) is null and trim(purchase_dt) is null then 1 end) as dirty_leads
       ,count( case when trim(street_addr1) is null and trim(zip_cd_tx) is null then 1 end) as no_address
       ,count( case when trim(street_addr1) is null and trim(zip_cd_tx) is null and trim(EMAIL_ADDRESS_TX) is not null then 1 end) as no_address_with_email
from   bosh.RAW_LEADS_TBL r
       LEFT JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
where  1=1
--and    (E_NUMBER like 'DF250762%' or E_NUMBER like 'DF251762%') --no rows
--and    upper(trim(brand)) = 'GAGGENAU'
and    creation_dt >= date '2023-01-01'
and FILE_NM not like 'bsh_after_cdb_hc_%'
-- and    error_desc is not null
group by FILE_NM, error_desc
order by FILE_NM, error_desc;




select FILE_NM,
       coalesce(purchase_dt, registration_dt) as purchase_dt
       ,count(*) All_Cnts
       ,count(trim(registration_dt)) as regist_cnts
       ,count(replace(trim(purchase_dt), '0')) as purchase_cnts

from   bosh.RAW_LEADS_TBL r
       LEFT JOIN BOSH.AUDIT_TBL AT ON (AT.AUDIT_KEY = R.INSERT_AUDIT_KEY)
where  1=1
--and    (E_NUMBER like 'DF250762%' or E_NUMBER like 'DF251762%') --no rows
--and    upper(trim(brand)) = 'GAGGENAU'
and    creation_dt >= date '2023-01-01'
and FILE_NM not like 'bsh_after_cdb_hc_%'
group by FILE_NM,
         coalesce(purchase_dt, registration_dt)
having count(*) > 50
order by FILE_NM, 2;


select FILE_NM, count(*), count(ERROR_DESC) from RAW_LEADS_TBL group by FILE_NM order by FILE_NM;