select distinct vd.CUSTOMER_KEY, --vd.VISITOR_KEY, vox.PRIMARY_IND, --,vox.insert_audit_key,
       creation_dt, si.si_key, pr.brand_key, pr.BRAND_NM, pr.model_no, pr.PRODUCT_DSC, pr.PRODUCT_CATEGORY_NM, full_dt as purchase_dt, si.WARRANTY_EXPIRATION_DT,si.REGISTRATION_DT
       ,si.LATEST_COVERAGE_EXP_DT,si.LATEST_COVERAGE_TYPE
      ,ad.source_cd, AD.FIRST_NM, MIDDLE_NM, LAST_NM, STATE_CD, em.EMAIL_ADDRESS_TX, ad.ADDRESS_LINE1_TX, ad.ADDRESS_LINE2_TX, CITY_NM --, COUNTRY_CD, ace_error_cd
      ,DERIVED_SUPPRESSION_CD, ADDRESS_SUPPRESSION_CD, PHONE_SUPPRESSION_CD, EMAIL_SUPPRESSION_CD
      ,six.REGISTRATION_DT, DUPLICATE_IND, SOURCE, MANUFACTURING_DATE_FD, CONSECUTIVE_NUMBER, E_NUMBER, REG_UNIQUE_IDENTIFIER
--       ,vd.VISITOR_KEY
--       , visitor_xid, ph.PHONE_NO, slkp.SI_XID, slkp.SOURCE_SYSTEM_CD
from P_visitor_dim vd
        join P_customer_dim cd on (cd.customer_key = vd.customer_key)
        join P_address_dim ad on (ad.address_key = CD.PRIMARY_ADDRESS_KEY)
        join P_VISITOR_OWNERSHIP_XREF vox on (VOX.visitor_key = vd.visitor_key)
        join P_SERIALIZED_ITEM_DIM si on si.si_key = vox.si_key
        left join date_dim dd on dd.date_key = si.purchase_dt_key 
        join P_Visitor_Lkp vlkp on vlkp.visitor_key = vd.visitor_key
        left join bosh.SERIALIZED_ITEM_EXT_DIM six on six.SI_KEY = si.SI_KEY
        left join bosh.SERIALIZED_ITEM_LKP slkp on slkp.SI_KEY = si.SI_KEY
        left join bosh.V_PRODUCT pr on pr.product_key = si.product_key
        left join AUDIT_TBL ai on ai.audit_key = si.insert_audit_key
        left join P_EMAIL_DIM em on em.EMAIL_KEY = cd.PRIMARY_EMAIL_KEY
        left join P_BRAND_DIM br on br.BRAND_KEY = pr.BRAND_KEY
        left join p_phone_dim ph on ph.PHONE_KEY = cd.PRIMARY_PHONE_KEY
 where 1=1
--   and (first_nm like 'ALEXANDRA%' or FIRM_NM like 'ALEXANDRA%') and LAST_NM like 'ARGUELLO%'  and STATE_CD = 'IL' --and address_line1_tx like '%MARIGOLD%'
--   and nvl(em.EMAIL_ADDRESS_TX, 'XYZ') in ('FAYETTECOUNTYHOMEOWNER@GMAIL.COM')
--      and ph.PHONE_NO in (
--         '8607020289'
--        )
--     and ADDRESS_LINE1_TX like '1059 3RD AVE%'
--       and PRIMARY_ADDRESS_KEY = 9021958
--   and duplicate_ind = 'N'
--   and pr.model_no in ('HMC80242UC', 'B36CT80SNS', 'HBL8743UC', 'NGM8646UC', 'SHPM78W54N')
   and pr.MODEL_NO in ('PRD606WESG')
--    and PRODUCT_CATEGORY_NM in ('LAUNDRY-DRYER', 'LAUNDRY-WASHER')
--     and pr.BRAND_KEY = 77   --GGN
--    and vlkp.VISITOR_KEY = 2333993
--  and vlkp.visitor_xid in ('T2972670', 'T2973859')
   and vd.customer_key  in (
4183282
     )
--   and SOURCE = 'WEB'
   and si.LATEST_COVERAGE_TYPE not in (21, 23, 22, 6)
--   and si.si_key in (
--          3504089, 3504090, 3504088
-- )
-- and slkp.SOURCE_SYSTEM_CD = 0
--    and si.SERIAL_NO in ('3005610995', '3005623676')
 order by brand_key, vd.customer_key, pr.model_no, si.si_key;
 
select * from P_address_dim ad 
 where 1=1
   and first_nm = 'MARY'
   and last_nm like 'KEMPER'
   and state_cd = 'OH'
--    and city_nm = 'CHICAGO'
   and ADDRESS_LINE1_TX like '1474 WINDWARD%';
   
select * from p_customer_dim where customer_key = 2208048;

select * from bosh.customer_dim  where customer_key = 504642;


select *
          from bosh.visitor_lkp vlkp1
               join bosh.VISITOR_DIM vd on vd.VISITOR_KEY = vlkp1.VISITOR_KEY
               join bosh.CUSTOMER_DIM cust on cust.CUSTOMER_KEY = vd.CUSTOMER_KEY
where cust.CUSTOMER_KEY = 2144428;
-- where vlkp1.VISITOR_KEY = 1106149;


select ptr.PREFERENCE_TYPE_NM, vpt.*, ai.* from bosh.VISITOR_PREFERENCE_TBL vpt left join AUDIT_TBL ai on ai.AUDIT_KEY = vpt.UPDATE_AUDIT_KEY
       left join bosh.PREFERENCE_TYPE_REF ptr on ptr.PREFERENCE_TYPE_KEY = vpt.PREFERENCE_TYPE_KEY
where VISITOR_KEY in (
    select VISITOR_KEY from bosh.VISITOR_DIM where CUSTOMER_KEY = 2615284
    )
order by EFFECTIVE_DT;

select * from bosh.PREFERENCE_Dim;


select * from bosh.VISITOR_PREFERENCE_TBL vpt where VISITOR_KEY in (
    select vd.VISITOR_KEY from bosh.VISITOR_DIM vd where vd.CUSTOMER_KEY = 2615284
    );

select * from bosh.ADDRESS_LKP where ADDRESS_XID = '2659791';
select * from bosh.ADDRESS_DIM where ADDRESS_key = 10954208;