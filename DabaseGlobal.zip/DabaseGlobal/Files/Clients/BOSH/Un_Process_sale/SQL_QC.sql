

select * from BOSH.RAW_CONTRACT_SALES_TBL where UNIQUE_IDENTIFIER in ('482811-1','489689-1','493399-1','493399-3','493399-4');


select OIT.SERIALIZED_ITEM_KEY,SID2.SI_KEY,oit.ORDER_KEY,SI_XID,SILKP.SOURCE_SYSTEM_CD,VLKP.VISITOR_XID,VLKP.VISITOR_KEY,VLKP.SOURCE_SYSTEM_CD
from BOSH.ORDER_ITEM_TBL  OIT
            JOIN BOSH.SERIALIZED_ITEM_DIM  SID2 on OIT.SERIALIZED_ITEM_KEY = SID2.SI_KEY
            JOIN BOSH.SERIALIZED_ITEM_LKP  SILKP on OIT.SERIALIZED_ITEM_KEY = SILKP.SI_KEY and SOURCE_SYSTEM_CD = 0
            JOIN BOSh.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            JOIN BOSH.VISITOR_LKP VLKP on OT.VISITOR_KEY = VLKP.VISITOR_KEY and VLKP.SOURCE_SYSTEM_CD = 1
         where OT.ORDER_KEY = 493399 and substr(si_xid, instr(si_xid, '-', 1, 2) + 1) <> VISITOR_XID;


select OIT.SERIALIZED_ITEM_KEY,SID2.SI_KEY,oit.ORDER_KEY,SI_XID,SILKP.SOURCE_SYSTEM_CD,VLKP.VISITOR_XID,VLKP.VISITOR_KEY,VLKP.SOURCE_SYSTEM_CD
from BOSH.ORDER_ITEM_TBL  OIT
            JOIN BOSH.SERIALIZED_ITEM_DIM  SID2 on OIT.SERIALIZED_ITEM_KEY = SID2.SI_KEY
            JOIN BOSH.SERIALIZED_ITEM_LKP  SILKP on OIT.SERIALIZED_ITEM_KEY = SILKP.SI_KEY and SOURCE_SYSTEM_CD = 0
            JOIN BOSh.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            JOIN BOSH.VISITOR_LKP VLKP on OT.VISITOR_KEY = VLKP.VISITOR_KEY and VLKP.SOURCE_SYSTEM_CD = 1
         where OT.ORDER_KEY = 489689 and substr(si_xid, instr(si_xid, '-', 1, 2) + 1) <> VISITOR_XID;
-- +-------------------+-------+---------+------------------------------+----------------+-----------+-----------+----------------+
-- |SERIALIZED_ITEM_KEY|SI_KEY |ORDER_KEY|SI_XID                        |SOURCE_SYSTEM_CD|VISITOR_XID|VISITOR_KEY|SOURCE_SYSTEM_CD|
-- +-------------------+-------+---------+------------------------------+----------------+-----------+-----------+----------------+
-- |4418700            |4418700|489689   |SHP65CP5N/25-20241213-T8369847|0               |T2378752   |269087     |1               |
-- +-------------------+-------+---------+------------------------------+----------------+-----------+-----------+----------------+
select * from BOSH.SERIALIZED_ITEM_LKP where SI_XID like '%T2378752%';


SELECT *
              FROM (SELECT DISTINCT vlkp.VISITOR_KEY,vlkp.visitor_xid, slkp.si_xid,TRIM(BILLING_UNIQUE_SEQ_NO)                                                          UNIQUE_SEQ_NO,
                                    oi.ORDER_KEY,
                                    oi.coverage_Start_Dt,
                                    oi.coverage_exp_dt,
                                    1                                                                                    SOURCE_SYSTEM_CD,
                                    P2_CONTRACT_NO                                                                       ORDER_XID,
                                    --NVL(OL.ORDER_XID,P2_CONTRACT_NO) ORDER_XID,
                                    P2_CONTRACT_NO                                                                       CONTRACT_XID,
                                    UPPER(TRIM(AD.FIRST_NM))                                                             FIRST_NM,
                                    ADDRESS_LINE1_TX,
                                    ad.ADDRESS_LINE2_TX,
                                    CITY_NM,
                                    STATE_CD,
                                    ZIP_CODE5_TX,
                                    TRUNC(OI.PURCHASE_DT)                                                                CONTRACT_SALE_DT,
                                    --CASE WHEN OT.SALES_SOURCE_CD IN ('MAIL_IN_SALES','WEB_SALES','CALL_CENTER_SALES') THEN
                                    --  OI.COVERAGE_START_DT
                                    --ELSE
                                    --TO_DATE( CONTRACT_START_DATE,'MM/DD/YYYY')   END CONTRACT_START_DT,
                                    TO_DATE(CONTRACT_START_DATE, 'MM/DD/YYYY')                                        AS CONTRACT_START_DT,
                                    --CASE WHEN OT.SALES_SOURCE_CD IN ('MAIL_IN_SALES','WEB_SALES','CALL_CENTER_SALES') THEN
                                    --  OI.COVERAGE_START_DT
                                    --ELSE TO_DATE( CONTRACT_START_DATE,'MM/DD/YYYY') END EFFECTIVE_DT,
                                    TO_DATE(CONTRACT_START_DATE, 'MM/DD/YYYY')                                        as EFFECTIVE_DT,
                                    --CASE WHEN OT.SALES_SOURCE_CD IN ('MAIL_IN_SALES','WEB_SALES','CALL_CENTER_SALES') THEN
                                    --    OI.COVERAGE_EXP_DT
                                    --ELSE TO_DATE( END_DATE,'MM/DD/YYYY')  END CONTRACT_END_DT,
                                    --CASE WHEN OT.SALES_SOURCE_CD IN ('MAIL_IN_SALES','WEB_SALES','CALL_CENTER_SALES') THEN
                                    --  OI.COVERAGE_EXP_DT
                                    --ELSE TO_DATE( CONTRACT_END_DATE,'MM/DD/YYYY') END  CONTRACT_END_DT,
                                    TO_DATE(CONTRACT_END_DATE, 'MM/DD/YYYY')                                          AS CONTRACT_END_DT,
                                    WARRANTY_EXPIRATION_DT                                                               WARRANTY_EXP_DT,
                                    TRUNC(OI.PURCHASE_DT)                                                                PURCHASE_DT,
                                    TRUNC(OI.PURCHASE_DT)                                                                REGISTER_DT,
                                    'BOSCH'                                                                              REGISTER_BY,
                                    --PURCHASE_DT_KEY + date '1989-12-31' PURCHASE_DT,
                                    OI.TAX_AMT,
                                    OI.TAX_AMT                                                                           RETAIL_TAX_AMT,
                                    UPPER(TRIM(''))                                                                      TAX_COUNTY,
                                    COALESCE(TO_NUMBER(OI.PRICE_AMT) - TO_NUMBER(NVL(OID.DISCOUNT_AMT, 0)),
                                             0)                                                                       as RETAIL_AMT,
                                    --nvl(to_number(TRIM (regexp_replace(DI.LINE_TAX,'[$]*','')))/DI.QUANTITY,0) as RETAIL_TAX_AMT,
                                    --nvl((TRIM (regexp_replace(DEALER_SELLING_PRICE,'[$]*',''))),0) as PRICE_AMT,
                                    UPPER(TRIM(AD.STATE_CD))                                                             TAXING_STATE_NM,
                                    UPPER(TRIM(''))                                                                      TAXING_COUNTY_NM,
                                    UPPER(TRIM(AD.CITY_NM))                                                              TAXING_CITY_NM,
                                    COUNTRY_CD                                                                           TAXING_COUNTRY_NM,
                                    (PH.PHONE_NO)                                                                        PRIMARY_PHONE_NO,
                                    --COMM.UTILITY.EMAIL_CLEAN (EMAIL_ADDRESS_TX) EMAIL_ADDRESS_TX,
                                    SYSDATE                                                                              INSERT_DT,
                                    UPPER(TRIM(FILE_NM))                                                                 FILE_NM,
                                    SUBSTR(UNIQUE_IDENTIFIER, INSTR(UNIQUE_IDENTIFIER, '-') + 1)                         ORDER_LINE_ID,
                                    --  L_INSERT_AUDIT_KEY INSERT_AUDIT_KEY,
                                    oi.LINE_ITEM_TYPE_CD,
                                    NVL(pl.policy_xid, '0')                                                              SKU_NO,
                                    'USA'                                                                                COUNTRY_CD,
                                    TRIM(A.STATUS_CD)                                                                    CONTRACT_STATUS_XID,
                                    'N'                                                                                  CALL_CENTER_FLAG,
                                    'USD'                                                                                CURRENCY_CD,
                                    'PURCHASE'                                                                           ADDRESS_TYPE,
                                    'READY'                                                                              PROCESS_STATUS_TX,
                                    OT.SALES_SOURCE_CD                                                                   SALES_SOURCE_CD,
                                    --                   DEALER_ID OUTLET_XID,
                                    --                   CANCELLED_BY CANCEL_BY,
                                    --                   'FULCRUM_'||OT.SALES_SOURCE_CD as CHANNEL_PARTNER_XID,
                                    'FULCRUM_' || OT.SALES_SOURCE_CD                                                     CREATED_BY,
                                    ''                                                                                   ORDER_ITEM_LINE_XID ----TRIM (MERCHANT_LINE_ITEM_NUMBER) ORDER_ITEM_LINE_XID,
                            ,
                                    si.SERIAL_NO                                                                         SI_UNIQUE_ID
                            ,
                                    pd.MODEL_NO                                                                          PRODUCT_UNIQUE_ID
                            ,
                                    '1'                                                                                  TERMS_AND_CONDTIONS_XID
                            ,
                                    '1'                                                                                  CONTRACT_TEMPLATE_XID
                            ,
                                    AL.ADDRESS_XID                                                                    AS ADDRESS_HASH_KEY,
                                    ROW_NUMBER() OVER (PARTITION BY slkp.si_key ORDER BY slkp.INSERT_AUDIT_KEY DESC ) AS rno                 --bosh-397
                    FROM BOSH.RAW_CONTRACT_SALES_TBL a
                             JOIN p_order_item_Tbl oi
                                  on (SUBSTR(UNIQUE_IDENTIFIER, 1, INSTR(UNIQUE_IDENTIFIER, '-') - 1) = OI.ORDER_KEY AND
                                      SUBSTR(UNIQUE_IDENTIFIER, INSTR(UNIQUE_IDENTIFIER, '-') + 1) = ORDER_LINE_KEY)
                             LEFT join p_ORDER_ITEM_DISC_INFO_LKP oid
                                       on (oi.ORDER_KEY = oid.order_key and OID.ORDER_LINE_KEY = oi.order_line_key)
                             JOIN p_order_tbl ot on (oi.order_key = ot.order_key)
                             JOIN P_VISITOR_LKP VLKP
                                  ON (OT.VISITOR_KEY = VLKP.VISITOR_KEY AND VLKP.SOURCE_SYSTEM_CD = 1)
                             JOIN P_SERIALIZED_ITEM_LKP SLKP
                                  ON (SLKP.SI_KEY = OI.SERIALIZED_ITEM_KEY AND SLKP.SOURCE_SYSTEM_CD = 0
                                      and substr(slkp.si_xid, instr(slkp.si_xid, '-', 1, 2) + 1) = vlkp.visitor_xid
                                      )
                             LEFT JOIN p_serialized_item_dim si on (OI.SERIALIZED_ITEM_KEY = si.SI_KEY)
                             JOIN p_product_dim pd on (si.product_key = pd.product_key)
                             LEFT JOIN p_order_lkp ol on (oi.ordeR_key = ol.order_key)
                             LEFT JOIN p_order_tbl ot on (oi.ordeR_key = ot.order_key)
                             --LEFT JOIN P_ORDER_ITEM_TBL oit on (oit.ordeR_key = ot.order_key)
                             --LEFT JOIN P_SERIALIZED_ITEM_LKP SLKP2 on SLKP2.SI_KEY = oit.SERIALIZED_ITEM_KEY AND  SLKP2.SOURCE_SYSTEM_CD = 0
                             LEFT JOIN p_shipping_info_tbl sh on (oi.order_key = sh.order_key)
                             LEFT JOIN p_billing_info_tbl bi on (oi.order_key = bi.order_key)
                             LEFT JOIN p_phone_dim ph on (sh.phone_key = ph.phone_key)
                             LEFT JOIN p_email_dim em on (bi.email_key = em.email_key)
                             LEFT JOIN p_address_dim ad on (sh.address_key = ad.address_key)
                             LEFT JOIN P_ADDRESS_LKP AL ON (AD.ADDRESS_KEY = AL.ADDRESS_KEY AND AL.source_system_cd = 0)
                             LEFT JOIN p_policy_lkp pl on (oi.policy_key = pl.policy_key and pl.source_system_cd = 0)
                    WHERE UNIQUE_IDENTIFIER in ('482811-1', '489689-1', '493399-1', '493399-3', '493399-4'));
-- +-----------+-----------+--------------------------------------------------+-------+------+-----------------------------+
-- |VISITOR_KEY|VISITOR_XID|SUBSTR(SLKP2.SI_XID,INSTR(SLKP2.SI_XID,'-',1,2)+1)|SI_KEY |SI_XID|SI_XID2                      |
-- +-----------+-----------+--------------------------------------------------+-------+------+-----------------------------+
-- |2564833    |T7600986   |T7600986                                          |3411383|NULL  |HDI8056U/04-20230123-T7600986|
-- |2564833    |T7600986   |T7600986                                          |3411383|NULL  |HDI8056U/04-20230123-T7600986|
-- |2564833    |T7600986   |T7600986                                          |3411383|NULL  |HDI8056U/04-20230123-T7600986|
-- |2564833    |T7600986   |T7600986                                          |3411383|NULL  |HDI8056U/04-20230123-T7600986|
-- |2564833    |T7600986   |T7600986                                          |3411383|NULL  |HDI8056U/04-20230123-T7600986|
-- |2564833    |T7600986   |T7600986                                          |3411383|NULL  |HDI8056U/04-20230123-T7600986|
-- +-----------+-----------+--------------------------------------------------+-------+------+-----------------------------+
-- 'T7600986'
-- 'T7600986'