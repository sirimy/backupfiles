

-- insert into RAW_CONTRACT_SALES_TBL
--     select * from BOSH.RAW_CONTRACT_SALES_TBL where UNIQUE_IDENTIFIER in ('482811-1','489689-1','493399-1','493399-3','493399-4');

select * from RAW_CONTRACT_SALES_TBL;

--
-- DECLARE
--        v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual process', p_process_nm => 'Un process sale', p_table_nm => 'RAW_CONTRACT_SALES_TBL');
--
-- BEGIN
--
--         update  RAW_CONTRACT_SALES_TBL
--             SET  INSERT_AUDIT_KEY = v_audit_key,BILLING_UNIQUE_SEQ_NO =NULL, SHIPPING_UNIQUE_SEQ_NO=NULL
--         where 1=1;
--
--        DBMS_OUTPUT.PUT_LINE(v_audit_key);
--        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
--
--
--        COMMIT;
--
-- END;
--


-- +-----------------+--------------+---------+-------------------+-----------------+-------------------------------------------------+
-- |UNIQUE_IDENTIFIER|P2_CONTRACT_NO|STATUS_CD|CONTRACT_START_DATE|CONTRACT_END_DATE|ERROR_TXT                                        |
-- +-----------------+--------------+---------+-------------------+-----------------+-------------------------------------------------+
-- |482811-1         |BSH-482811-1  |ACTIVE   |03/23/2026         |03/23/2029       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
-- |489689-1         |BSH-489689-1  |ACTIVE   |12/13/2025         |12/13/2029       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
-- |493399-4         |BSH-493399-4  |ACTIVE   |01/03/2026         |12/03/2027       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
-- |493399-1         |BSH-493399-1  |ACTIVE   |01/03/2026         |12/03/2027       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
-- |493399-3         |BSH-493399-3  |ACTIVE   |01/03/2026         |12/03/2027       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
-- +-----------------+--------------+---------+-------------------+-----------------+-------------------------------------------------+

BEGIN PK_CONTRACT.s_001_load_contract_sales; END;

select * from CONTRACT_COMMON_LOAD_TBL_HOLD;
-- +------------------+-------------------+----------------+-----------------+---------------+
-- |CLIENT_CONTRACT_NO|CONTRACT_STATUS_XID|CONTRACT_SALE_DT|CONTRACT_START_DT|CONTRACT_END_DT|
-- +------------------+-------------------+----------------+-----------------+---------------+
-- |BSH-482811-1      |ACTIVE             |2025-10-07      |2026-03-23       |2029-03-23     |
-- |BSH-482811-1      |ACTIVE             |2025-10-07      |2026-03-23       |2029-03-23     |
-- |BSH-489689-1      |ACTIVE             |2025-11-13      |2025-12-13       |2029-12-13     |
-- |BSH-489689-1      |ACTIVE             |2025-11-13      |2025-12-13       |2029-12-13     |
-- |BSH-493399-1      |ACTIVE             |2025-12-04      |2026-01-03       |2027-12-03     |
-- |BSH-493399-1      |ACTIVE             |2025-12-04      |2026-01-03       |2027-12-03     |
-- |BSH-493399-3      |ACTIVE             |2025-12-04      |2026-01-03       |2027-12-03     |
-- |BSH-493399-3      |ACTIVE             |2025-12-04      |2026-01-03       |2027-12-03     |
-- |BSH-493399-4      |ACTIVE             |2025-12-04      |2026-01-03       |2027-12-03     |
-- |BSH-493399-4      |ACTIVE             |2025-12-04      |2026-01-03       |2027-12-03     |
-- +------------------+-------------------+----------------+-----------------+---------------+

select AT2.CREATION_DT,COT.* from BOSH.CONTRACT_ORDER_TBL COT
            JOIN AUDIT_TBL AT2 on At2.AUDIT_KEY =cot.INSERT_AUDIT_KEY
         where ORDER_KEY || '-' || ORDER_LINE_KEY in (
    '482811-1',
    '482811-1',
    '489689-1',
    '489689-1',
    '493399-1',
    '493399-1',
    '493399-3',
    '493399-3',
    '493399-4',
    '493399-4'
    ) ;

-- +--------------------------+------------+---------+--------------+
-- |CREATION_DT               |CONTRACT_KEY|ORDER_KEY|ORDER_LINE_KEY|
-- +--------------------------+------------+---------+--------------+
-- |2026-01-05 10:24:06.000000|237322      |489689   |1             |
-- |2026-01-05 10:24:06.000000|237323      |482811   |1             |
-- |2026-01-05 10:24:06.000000|237324      |493399   |1             |
-- |2026-01-05 10:24:06.000000|237321      |493399   |3             |
-- |2026-01-05 10:24:06.000000|237320      |493399   |4             |
-- +--------------------------+------------+---------+--------------+