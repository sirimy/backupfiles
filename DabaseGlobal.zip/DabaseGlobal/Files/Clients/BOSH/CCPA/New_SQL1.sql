declare
    v_count number;
    v_customer_key number;
    v_latest_coverage_exp_dt date;
begin
    select count(*),max(cd.CUSTOMER_KEY),max(SIDM.LATEST_COVERAGE_EXP_DT)
            into v_count,v_customer_key,v_latest_coverage_exp_dt
    from  bosh.ORDER_TBL ot
           join bosh.ORDER_ITEM_TBL OIT on oit.ORDER_KEY = ot.ORDER_KEY
           join bosh.SERIALIZED_ITEM_DIM SIDM on SIDM.SI_KEY = OIT.SERIALIZED_ITEM_KEY
           join bosh.visitor_dim vd on vd.VISITOR_KEY = ot.VISITOR_KEY
           join bosh.customer_dim    cd  on (cd.customer_key = vd.customer_key)
           join bosh.address_dim     ad  on (ad.address_key  = cd.primary_address_key)
           left join bosh.email_Dim  em  on (em.email_key    = primary_email_key)
           left join bosh.Phone_Dim  ph  on (ph.phone_key    = primary_phone_key)
    where   1=1 and (NVL(EMAIL_ADDRESS_TX, 'XYZ') = UPPER(:Email)
                    or
                     NVL(PHONE_NO, '123') = :Phone1
                    OR
                     (ADDRESS_LINE1_TX like UPPER(:ADDRESS_LINE1_TX) and STATE_CD = :STATE)
                    )
        and GREATEST(SIDM.LATEST_COVERAGE_EXP_DT,oit.COVERAGE_EXP_DT)  > trunc(sysdate) - 2;


        IF v_count > 0 then
             -- Inserting in Raw table for future check customer data also suppress on the basis of v_latest_coverage_exp_dt
            -- Second script refer this table from CORE, that's why we are entering directly in core
            insert into BOSH.RAW_CCPA_TBL
            (REQUEST_DATE,CUSTOMER_NAME, ADDRESS1, ADDRESS2 , CITY , STATE , ZIP , PHONE , EMAIL_ADDRESS , CUSTOMER_FOUND_ESP,
                ESP_ACTIVE, COMPLETED_DATE, FILE_NM , INSERT_AUDIT_KEY, CUSTOMER_KEY, LATEST_COVERAGE_EXP_DT  , TICKET_NO   )
                values(sysdate,NULL,UPPER(:ADDRESS_LINE1_TX),NULL,NULL,:STATE,NULL,:Phone1,:Email,'Y','',sysdate,'manual_run',NULL,v_customer_key
                ,v_latest_coverage_exp_dt,:Ticket_no);
             commit;
            raise_application_error(-20001, 'There are orders against this customer...please check');
        end if;
end;