select vd.customer_key, ad.address_key, em.EMAIL_KEY, ph.PHONE_KEY,
           ad.FIRM_NM, ad.FIRST_NM, ad.MIDDLE_NM, ad.LAST_NM,
           ad.ADDRESS_LINE1_TX, ad.ADDRESS_LINE2_TX, ad.CITY_NM, ad.STATE_CD, ZIP_CODE5_TX, ZIP_CODE4_TX,
           em.EMAIL_ADDRESS_TX, ph.PHONE_NO
          --vl.visitor_xid,
    from   bosh.visitor_dim vd
           join bosh.customer_dim    cd  on (cd.customer_key = vd.customer_key)
           join bosh.address_dim     ad  on (ad.address_key  = cd.primary_address_key)
           left join bosh.email_Dim  em  on (em.email_key    = primary_email_key)
           left join bosh.Phone_Dim  ph  on (ph.phone_key    = primary_phone_key)
           --join bosh.visitor_lkp vl on (vl.visitor_key  = vd.visitor_key) --and vl.source_system_cd in (0, 1)
    where  1=1
    and   (
           NVL(EMAIL_ADDRESS_TX, 'XYZ') in ( upper(:Email))
           OR
           NVL(PHONE_NO, '123') like :Phone1 OR NVL(PHONE_NO, '123') like :Phone2 OR NVL(PHONE_NO, '123') like :Phone3
           OR
           (ADDRESS_LINE1_TX LIKE upper(:ADDRESS_LINE1_TX) and STATE_CD = :State)

    --  and first_nm like '%NATALIE%'
    --  and last_nm like '%SCHWARZ%'
    --  and cd.CUSTOMER_KEY in (:customer_key)
           );


-- Here enter vd.customer_key manually if found above value
  insert into RAW_CCPA_TBL
            (REQUEST_DATE,CUSTOMER_NAME, ADDRESS1, ADDRESS2 , CITY , STATE , ZIP , PHONE , EMAIL_ADDRESS , CUSTOMER_FOUND_ESP,
                ESP_ACTIVE, COMPLETED_DATE, FILE_NM , INSERT_AUDIT_KEY, CUSTOMER_KEY, LATEST_COVERAGE_EXP_DT  , TICKET_NO   )
                values(sysdate,
                       NULL,
                       UPPER(:ADDRESS_LINE1_TX),
                       NULL,
                       NULL,
                       :STATE,
                       NULL,
                       :Phone1,
                       :Email,
                       'N',
                       '',
                       sysdate,
                       'manual_run',
                       NULL,
                       NULL,--Manulupdate Customer key here
                       NULL,
                       :Ticket_no);


select * from BOSH.TERMS_AND_CONDITIONS_DIM order by TERMS_AND_CONDITIONS_KEY;