declare
    v_audit_key NUMBER;
    v_count     NUMBER;
    v_count2     NUMBER;
    v_latest_coverage_exp_dt date;
    --first use this sql to identify records to be updated
    --move forward after verifying that we are picking correct records
    cursor ccpa_dw_cur
    is
    select vd.customer_key, ad.address_key, em.EMAIL_KEY, ph.PHONE_KEY,
           ad.FIRM_NM, ad.FIRST_NM, ad.MIDDLE_NM, ad.LAST_NM,
           ad.ADDRESS_LINE1_TX, ad.ADDRESS_LINE2_TX, ad.CITY_NM, ad.STATE_CD, ZIP_CODE5_TX, ZIP_CODE4_TX,
           em.EMAIL_ADDRESS_TX, ph.PHONE_NO
          --vl.visitor_xid,
    from   bosh.visitor_dim vd
           join bosh.customer_dim    cd  on (cd.customer_key = vd.customer_key)
           join bosh.address_dim     ad  on (ad.address_key  = cd.primary_address_key)
           left join bosh.email_Dim  em  on (em.email_key    = primary_email_key)
           left join bosh.Phone_Dim  ph  on (ph.phone_key    = primary_phone_key)
           --join bosh.visitor_lkp vl on (vl.visitor_key  = vd.visitor_key) --and vl.source_system_cd in (0, 1)
    where  1=1
    and   (
           NVL(EMAIL_ADDRESS_TX, 'XYZ') in ( UPPER(:Email))
           OR
           NVL(PHONE_NO, '123') like :Phone1 OR NVL(PHONE_NO, '123') like :Phone2 OR NVL(PHONE_NO, '123') like :Phone3
           OR
           (ADDRESS_LINE1_TX LIKE UPPER(:ADDRESS_LINE1_TX) and STATE_CD = :State)

    --  and first_nm like '%NATALIE%'
    --  and last_nm like '%SCHWARZ%'
    --  and cd.CUSTOMER_KEY in (:customer_key)
           );


    --first use this sql to identify records to be updated
    --move forward after verifying that we are picking correct records
    cursor ccpa_sol_cur
    is
    select * from bosh.campaign_spool_file_tbl spl
    where  (
           NVL(EMAIL_ADDRESS, 'XYZ') in ( UPPER(:Email))
           or
           NVL(PHONE_NUMBER, '123') like :Phone1
           OR
           (ADDRESS_LINE1_TX LIKE UPPER(:ADDRESS_LINE1_TX) and STATE_CD = :State)
        );

begin

    v_audit_key := get_audit_key (p_program_nm => 'CCPA', p_descriptive_tx => 'CCPA', p_table_nm => 'VARIOUS');
    DBMS_OUTPUT.PUT_LINE('v_audit_key: ' || v_audit_key);
    COMMIT;

    for ccpa_dw_rec in ccpa_dw_cur loop


        v_latest_coverage_exp_dt:= NULL;
        v_count := 0;
        select count(*),max(SIDM.LATEST_COVERAGE_EXP_DT) into v_count,v_latest_coverage_exp_dt
        from
               bosh.ORDER_TBL ot
               join bosh.ORDER_ITEM_TBL OIT on oit.ORDER_KEY = ot.ORDER_KEY
                join bosh.SERIALIZED_ITEM_DIM SIDM on SIDM.SI_KEY = OIT.SERIALIZED_ITEM_KEY
               join bosh.visitor_dim vd on vd.VISITOR_KEY = ot.VISITOR_KEY
               join bosh.customer_dim    cd  on (cd.customer_key = vd.customer_key)
               join bosh.address_dim     ad  on (ad.address_key  = cd.primary_address_key)
               left join bosh.email_Dim  em  on (em.email_key    = primary_email_key)
               left join bosh.Phone_Dim  ph  on (ph.phone_key    = primary_phone_key)
               join bosh.ORDER_ITEM_TBL oit on oit.ORDER_KEY = ot.ORDER_KEY
        where  1=1
        and   (
                   NVL(EMAIL_ADDRESS_TX, 'XYZ') = ccpa_dw_rec.EMAIL_ADDRESS_TX
                   or
                   NVL(PHONE_NO, '123') = ccpa_dw_rec.PHONE_NO
                   OR
                   (ADDRESS_LINE1_TX = ccpa_dw_rec.ADDRESS_LINE1_TX and STATE_CD = ccpa_dw_rec.STATE_CD)
                )
        and  oit.COVERAGE_EXP_DT >= trunc(sysdate) - 2;

        -- Inserting in Raw table for future check customer data also suppress on the basis of v_latest_coverage_exp_dt
        -- First SQL may have inserted this record already but we are inserting here again as precaution in case first SQL was misssed
        select count(*) into v_count2 from RAW_CCPA_TBL where CUSTOMER_KEY = ccpa_dw_rec.CUSTOMER_KEY and TICKET_NO = :Ticket_no;

         IF v_count = 0 then
            insert into RAW_CCPA_TBL
            (REQUEST_DATE,CUSTOMER_NAME, ADDRESS1, ADDRESS2 , CITY , STATE , ZIP , PHONE , EMAIL_ADDRESS , CUSTOMER_FOUND_ESP,
            ESP_ACTIVE, COMPLETED_DATE, FILE_NM , INSERT_AUDIT_KEY, CUSTOMER_KEY, LATEST_COVERAGE_EXP_DT  , TICKET_NO   )
            values(sysdate,NULL,UPPER(:ADDRESS_LINE1_TX),NULL,NULL,:STATE,NULL,:Phone1,:Email,'Y','',sysdate,'manual_run',NULL,ccpa_dw_rec.CUSTOMER_KEY
            ,v_latest_coverage_exp_dt,:Ticket_no);
            -- Add not in for customer key and Ticket no not save second time
            commit;
         end if;



        IF v_count > 0 then
            raise_application_error(-20001, 'There are active orders against this customer...aborting ccpa update');
        end if;


--------------------------------
----update CL/archive tables
--------------------------------
        update bosh.COMMON_LOAD_TBL_ARCH
        set    first_nm = 'CCPA',
               middle_nm = null,
               LAST_NM = 'CCPA',
               firm_nm  = null,
               ADDRESS_LINE1_TX = 'CCPA',
               Phone_no  = NULL,
               EMAIL_ADDRESS_TX  = 'CCPA'
        where  1=1
        and   (
                   NVL(EMAIL_ADDRESS_TX, 'XYZ') = ccpa_dw_rec.EMAIL_ADDRESS_TX
                   or
                   NVL(PHONE_NO, '123') = ccpa_dw_rec.PHONE_NO
                   OR
                   (ADDRESS_LINE1_TX = ccpa_dw_rec.ADDRESS_LINE1_TX and STATE_CD = ccpa_dw_rec.STATE_CD)
                );

        DBMS_OUTPUT.PUT_LINE('Rows updated - COMMON_LOAD_TBL_ARCH: ' || to_char(sql%rowcount ));



        update bosh.DS_ACE_OUTPUT_TBL_ARCH
        set    first_nm = 'CCPA',
               middle_nm = null,
               LAST_NM = 'CCPA',
               firm_nm  = null,
               ADDRESS_LINE1_TX = 'CCPA-' || to_char(UNIQUE_SEQ_NO),
               zip_code4_tx = null,
               WORK_PHONE_NO  = NULL,
               HOME_PHONE_NO  = NULL,
               PRIMARY_STREET_NO = NULL,
               PRIMARY_STREET_NM = NULL,
               EMAIL_ADDRESS_TX  = 'CCPA'
        where  1=1
        and   NVL(EMAIL_ADDRESS_TX, 'xyz') = ccpa_dw_rec.EMAIL_ADDRESS_TX
               or
               NVL(HOME_PHONE_NO, '123') = ccpa_dw_rec.PHONE_NO
               or
               NVL(WORK_PHONE_NO, '123') = ccpa_dw_rec.PHONE_NO
               OR
               (ADDRESS_LINE1_TX = ccpa_dw_rec.ADDRESS_LINE1_TX and STATE_CD = ccpa_dw_rec.STATE_CD);

        DBMS_OUTPUT.PUT_LINE('Rows updated - DS_ACE_OUTPUT_TBL_ARCH: ' || to_char(sql%rowcount ));


        update bosh.NCOA_UPDATED_ADDRESS_TBL
        set    INPUT_ADDRESS_LINE1_TX = 'CCPA',
               ADDRESS_LINE1_TX  = 'CCPA',
               NEW_ADDRESS_LINE1_TX = 'CCPA'
        where (
               (INPUT_ADDRESS_LINE1_TX = ccpa_dw_rec.ADDRESS_LINE1_TX and INPUT_STATE_CD = ccpa_dw_rec.STATE_CD)
               OR
               (ADDRESS_LINE1_TX = ccpa_dw_rec.ADDRESS_LINE1_TX and STATE_CD = ccpa_dw_rec.STATE_CD)
               OR
               (NEW_ADDRESS_LINE1_TX = ccpa_dw_rec.ADDRESS_LINE1_TX and STATE_CD = ccpa_dw_rec.STATE_CD)
           );

        DBMS_OUTPUT.PUT_LINE('Rows updated - NCOA_UPDATED_ADDRESS_TBL: ' || to_char(sql%rowcount ));



--------------------------------
--Update DW tables
--------------------------------
        update bosh.address_dim
        set    first_nm = 'CCPA',
               middle_nm = null,
               LAST_NM = 'CCPA',
               firm_nm  = null,
               ADDRESS_LINE1_TX = 'CCPA-' || to_char(address_key),   --appending address_key as otherwise such records may appear to be similar and may get assigned to same address/customer by customer match process?
               PRIMARY_STREET_NM = NULL,
               PRIMARY_STREET_NO = NULL,
               update_audit_key = v_audit_key,
               sync_audit_key = null
        where  ADDRESS_KEY = ccpa_dw_rec.ADDRESS_KEY;

        DBMS_OUTPUT.PUT_LINE('Rows updated - address_dim: ' || to_char(sql%rowcount ));


        update bosh.email_dim
        set    EMAIL_ADDRESS_TX = 'CCPA-' || to_char(EMAIL_KEY),
               update_audit_key = v_audit_key,
               sync_audit_key = null
        where  EMAIL_KEY = ccpa_dw_rec.EMAIL_KEY;

        DBMS_OUTPUT.PUT_LINE('Rows updated - email_dim: ' || to_char(sql%rowcount ));


        --phone_tbl in web has a check constraint to make sure that phone_no is not null
	--any record with blank phone_no will fail the underlying process including sync
	--that is why we should update phone_no with 'some' value and not with nulls
        update bosh.phone_dim
        set    phone_no = 'CCPA-' || to_char(PHONE_KEY),
               update_audit_key = v_audit_key,
               sync_audit_key = null
        where  PHONE_KEY = ccpa_dw_rec.PHONE_KEY;

        DBMS_OUTPUT.PUT_LINE('Rows updated - phone_dim: ' || to_char(sql%rowcount ));


        update bosh.CUSTOMER_DIM
        set    DERIVED_SUPPRESSION_CD = 'Y', ADDRESS_SUPPRESSION_CD = 'Y', EMAIL_SUPPRESSION_CD = 'Y', PHONE_SUPPRESSION_CD = 'Y',
               update_audit_key = v_audit_key,
               sync_audit_key = null
        where  CUSTOMER_KEY = ccpa_dw_rec.CUSTOMER_KEY;

        DBMS_OUTPUT.PUT_LINE('Rows updated - customer_dim: ' || to_char(sql%rowcount ));

        update bosh.VISITOR_PREFERENCE_TBL vpt
        set    PREFERENCE_VALUE = 'N',
               update_audit_key = v_audit_key, SYNC_AUDIT_KEY = null
        where  PREFERENCE_VALUE = 'Y'
        and    VISITOR_KEY in (
                  select vd.VISITOR_KEY from bosh.VISITOR_DIM vd join bosh.CUSTOMER_DIM cust on cust.CUSTOMER_KEY = vd.CUSTOMER_KEY
                  where cust.CUSTOMER_KEY = ccpa_dw_rec.CUSTOMER_KEY
                );

        DBMS_OUTPUT.PUT_LINE('Rows updated - VISITOR_PREFERENCE_TBL: ' || to_char(sql%rowcount ));


        update PURL_DIM
        set    PURL_TXT = 'CCPA' || purl_key, UPDATE_AUDIT_KEY = v_audit_key, SYNC_AUDIT_KEY = null
        where PURL_KEY in (select PRIMARY_PURL_KEY from bosh.CUSTOMER_DIM where CUSTOMER_KEY = ccpa_dw_rec.CUSTOMER_KEY);

        --we shouldn't update DNS data?
        --update raw_email_dns_tbl r
        --set    EMAIL = 'CCPA-' || r.PARTNER
       -- where  upper(EMAIL) = upper(ccpa_dw_rec.EMAIL_ADDRESS_TX);
        --2 rows

        --DBMS_OUTPUT.PUT_LINE('Rows updated - raw_email_dns_tbl: ' || to_char(sql%rowcount ));



        update bosh.raw_leads_tbl r
        set    first_nm = 'CCPA',
               LAST_NM = 'CCPA',
               street_addr1 = 'CCPA',
               EMAIL_ADDRESS_TX = 'CCPA',
               TELEPHONE_NO = NULL
        where  (
                upper(trim(EMAIL_ADDRESS_TX)) = upper(ccpa_dw_rec.EMAIL_ADDRESS_TX)
                or
                instr(TELEPHONE_NO, ccpa_dw_rec.PHONE_NO) > 0
                or
                instr(MOBILE_PHONE_NO, ccpa_dw_rec.PHONE_NO) > 0
                or
                (upper(trim(STREET_ADDR1)) = ccpa_dw_rec.ADDRESS_LINE1_TX and STATE_CD = ccpa_dw_rec.STATE_CD)
               );

        DBMS_OUTPUT.PUT_LINE('Rows updated - raw_leads_tbl: ' || to_char(sql%rowcount ));

    end loop;

    commit;   --commit everything together


-------------------------------------
    --Update solicitation tables
-------------------------------------
    for ccpa_sol_rec in ccpa_sol_cur
    loop
        update bosh.campaign_spool_file_tbl spl
        set    first_nm = 'CCPA',
               middle_nm = null,
               LAST_NM = 'CCPA',
               firm_nm  = null,
               ADDRESS_LINE1_TX = 'CCPA',
               ADDRESS_LINE2_TX = NULL,
               EMAIL_ADDRESS = NULL,
               PHONE_NUMBER   = null,
               PURL           = null,
               PURL_LINK_TXT  = null,
               UPDATE_AUDIT_KEY = v_audit_key
        where spl.REFERENCE_ID = ccpa_sol_rec.REFERENCE_ID;

        DBMS_OUTPUT.PUT_LINE('Rows updated - campaign_spool_file_tbl: ' || to_char(sql%rowcount ));

        update bosh.EMAIL_EXTRACT_TBL
        set    FIRSTNAME     = 'CCPA',
               LASTNAME      = 'CCPA',
               EMAIL_ADDRESS = NULL
        where  INVITATIONCODE = ccpa_sol_rec.REFERENCE_ID;

        DBMS_OUTPUT.PUT_LINE('Rows updated - EMAIL_EXTRACT_TBL: ' || to_char(sql%rowcount ));


        ------------------------------------------------
        --check if bundle needs to be suppressed as well...if it is an active bundle with upcoming drops
        ------------------------------------------------

    end loop;

    commit;  --commit everything together



-------------------------------------
    --Update up rest of the raw tables
    --builder leads don't contain customer's name/email or phone and so nothing to be cleaned-up there
-------------------------------------
    update bosh.raw_registria_leads_tbl
        set    FIRST_NM = 'CCPA',
               LAST_NM = 'CCPA',
               SHIPPING_ADDRESS_LINE1_TX = 'CCPA',
               BILLING_ADDRESS_LINE1_TX  = 'CCPA',
               EMAIL_ADDRESS_TX = 'CCPA',
               PHONE_NO = NULL
    where  (
               NVL(EMAIL_ADDRESS_TX, 'XYZ') in ( :Email)
               OR
               NVL(PHONE_NO, '123') like :Phone1 OR NVL(PHONE_NO, '123') like :Phone2 OR NVL(PHONE_NO, '123') like :Phone3
               OR
               (SHIPPING_ADDRESS_LINE1_TX LIKE :ADDRESS_LINE1_TX and SHIPPING_STATE_CD = :State)
               OR
               (BILLING_ADDRESS_LINE1_TX LIKE :ADDRESS_LINE1_TX and BILLING_STATE_CD = :State)
               );

    DBMS_OUTPUT.PUT_LINE('Rows updated - raw_registria_leads_tbl: ' || to_char(sql%rowcount ));


    update bosh.RAW_INWARRANTY_LEADS_TBL r
    set    FIRST_NAME = 'CCPA',
           LAST_NAME = 'CCPA',
           ADDRESS = 'CCPA',
           EMAIL = 'CCPA',
           LOCATION_PHONE = NULL
    where  (
               NVL(EMAIL, 'XYZ') in ( :Email)
               OR
               NVL(LOCATION_PHONE, '123') like :Phone1 OR NVL(LOCATION_PHONE, '123') like :Phone2 OR NVL(LOCATION_PHONE, '123') like :Phone3
               OR
               (ADDRESS LIKE :ADDRESS and STATE = :State)
               );

    DBMS_OUTPUT.PUT_LINE('Rows updated - RAW_INWARRANTY_LEADS_TBL: ' || to_char(sql%rowcount ));

    commit;


exception
    when others then
    rollback ;
    raise;
end;
