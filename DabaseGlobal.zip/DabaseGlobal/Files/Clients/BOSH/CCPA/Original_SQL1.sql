declare
    v_count number;
begin
    select count(*) into v_count
        from
               bosh.ORDER_TBL ot
               join bosh.visitor_dim vd on vd.VISITOR_KEY = ot.VISITOR_KEY
               join bosh.customer_dim    cd  on (cd.customer_key = vd.customer_key)
               join bosh.address_dim     ad  on (ad.address_key  = cd.primary_address_key)
               left join bosh.email_Dim  em  on (em.email_key    = primary_email_key)
               left join bosh.Phone_Dim  ph  on (ph.phone_key    = primary_phone_key)

        where  1=1
        and   (
                   NVL(EMAIL_ADDRESS_TX, 'XYZ') = UPPER(:Email)
                   or
                   NVL(PHONE_NO, '123') = :Phone1
                   OR
                   (ADDRESS_LINE1_TX like UPPER(:ADDRESS_LINE1_TX) and STATE_CD = :STATE)
                );

        IF v_count > 0 then
            raise_application_error(-20001, 'There are orders against this customer...please check');
        end if;
end;