select serialized_item_id, latest_coverage_exp_dt, latest_coverage_exp_dt + interval '30 day' from serialized_item
where serialized_item_id in (23463828);

select oft.*, ofit.*, pol.description
  from offer_tbl oft join  offer_item_tbl ofit on ofit.offer_id = oft.offer_id
       left join policy pol on pol.policy_id = ofit.policy_id
 where 1=1
--   and oft.active_ind = 'Y'
   and oft.offer_id < 500000   --real time offer
   and customer_id = 5359392
--    and serialized_item_id = <Enter serialized_item_id >   --enter required serialized_item_id if there are multiple units
   and offer_start_utc_ts > current_date - interval '45' day   --recent real time offers only
  order by customer_id, serialized_item_id, offer_exp_dt, display_group_num, ofit.display_seq_num
limit 40;


select serialized_item_id, latest_coverage_exp_dt, latest_coverage_exp_dt - interval '30 day' from serialized_item
where serialized_item_id in (23463828);



--Following update is reqd for Aftermarket offers only
select oft.*, p.description, t.day
from offer_item_tbl oft join policy p on oft.policy_id = p.policy_id join term t on p.term_id = t.term_id
where offer_id IN (
         select ot.offer_id from offer_tbl ot where customer_id = 5359392
                                        and offer_start_utc_ts >= current_date - interval '1' day
    )
and offer_id < 500000
and active_ind = 'Y'
order by offer_id, t.day, policy_id;