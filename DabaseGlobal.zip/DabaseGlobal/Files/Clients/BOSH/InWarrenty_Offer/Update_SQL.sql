
update serialized_item set latest_coverage_exp_dt = latest_coverage_exp_dt + interval '30 day'
where serialized_item_id in (23463828);
--1 rows
commit;

delete from offer_item_tbl where offer_id = 51541;
delete from offer_tbl where offer_id = 51541;

delete from offer_item_tbl where offer_id = 51436;
delete from offer_tbl where offer_id = 51436;
commit;



update serialized_item set latest_coverage_exp_dt = latest_coverage_exp_dt - interval '30 day'
where serialized_item_id in (23463828);
--1 rows
commit;





-- update offer to reflect actual coverage dates
update offer_item_tbl
set
     coverage_start_dt = <Enter coverage_start_dt ...>
where offer_id IN (
    select ot.offer_id from offer_tbl ot where customer_id = 5359392
    and   offer_start_utc_ts >= current_date - interval '1' day and ot.active_ind = 'Y'
    )
-- and serialized_item_id = <serialized_item_id being handled>
and active_ind = 'Y'
-- and offer_id = <offer_id created above>
and offer_id < 500000;
--4 rows
commit;


WITH src AS (
    select oft.*, p.description, t.day as t_days
     from offer_item_tbl oft join policy p on oft.policy_id = p.policy_id join term t on p.term_id = t.term_id
    where offer_id IN (
        select ot.offer_id from offer_tbl ot where customer_id = <Enter customer_id ...>
                                             and offer_start_utc_ts >= current_date - interval '1' day and ot.active_ind = 'Y'
        )
-- and offer_id = <offer_id created above>
    and offer_id < 500000
    )
UPDATE offer_item_tbl tgt
   set coverage_exp_dt = tgt.coverage_start_dt + (src.t_days * interval '1 day')
  FROM src
 WHERE  tgt.offer_id = src.offer_id and tgt.serialized_item_id = src.serialized_item_id and tgt.offer_line_id = src.offer_line_id
   and src.active_ind = 'Y'
;
--4 rows
commit;