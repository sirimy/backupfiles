

select CCX.SI_KEY,CL.SI_XID, COUNT(CCX.CONTRACT_KEY) from BOSH.CONTRACT_COVERAGE_XREF CCX
                                    JOIN BOSH.CONTRACT_DIM CD on CD.CONTRACT_KEY = CCX.CONTRACT_KEY
                                    JOIN BOSH.SERIALIZED_ITEM_LKP CL on CL.SI_KEY = CCX.SI_KEY and CL.SOURCE_SYSTEM_CD = 0
                                  where COVERAGE_START_DT > sysdate - 30
                                    AND COVERAGE_TYPE_KEY = 2
                                    AND CD.CONTRACT_STATUS_KEY = 1
                                    AND CL.SI_XID not in (
                                            select SIL.SI_XID from BOSH.SERIALIZED_ITEM_LKP SIL where SIL.SOURCE_SYSTEM_CD = 0 group by SIL.SI_XID having  COUNT(SIL.SI_XID) >1
                                      )
GROUP BY CCX.SI_KEY,CL.SI_XID
Having COUNT(CCX.CONTRACT_KEY) > 1
;
+-------+-------------------------------+-----------------------+
|SI_KEY |SI_XID                         |COUNT(CCX.CONTRACT_KEY)|
+-------+-------------------------------+-----------------------+
|3657069|SHP65CM5N/xx-20231001-T8102690 |2                      |
|3556246|DWHD770WPR/xx-20230403-T7638515|4                      |
|3740849|T24IF905SP/21-20230807-T8086136|2                      |
|3891650|SHP78CM5N/22-20240510-T8669246 |2                      |
|3556255|T30IR905SP/xx-20230403-T7638515|2                      |
|3538649|VCIN48GWS/xx-20220916-T7278355 |2                      |
|3676916|SGSP365TS/xx-20230809-T8257682 |2                      |
+-------+-------------------------------+-----------------------+




select SI_XID from BOSH.SERIALIZED_ITEM_LKP where SOURCE_SYSTEM_CD = 0 group by SI_XID having  COUNT(SI_XID) >1 ;

select * from BOSH.CONTRACT_COVERAGE_XREF where SI_KEY = 3556246 AND COVERAGE_TYPE_KEY = 2;


Select * from BOSH.CONTRACT_DIM where CONTRACT_KEY in (
    select CONTRACT_KEY from BOSH.CONTRACT_COVERAGE_XREF where SI_KEY = 3556246 AND COVERAGE_TYPE_KEY = 2
);

Select * from BOSH.CONTRACT_ORDER_TBL where CONTRACT_KEY    in(
    Select CONTRACT_KEY from BOSH.CONTRACT_DIM where CONTRACT_KEY in (
        select CONTRACT_KEY from BOSH.CONTRACT_COVERAGE_XREF where SI_KEY = 3556246 AND COVERAGE_TYPE_KEY = 2
    )
)
;
+------------+---------+--------------+----------------+----------------+--------------+
|CONTRACT_KEY|ORDER_KEY|ORDER_LINE_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+------------+---------+--------------+----------------+----------------+--------------+
|183322      |397265   |1             |809618          |NULL            |809625        |
|180890      |392017   |1             |787916          |NULL            |787923        |
+------------+---------+--------------+----------------+----------------+--------------+

Select * from BOSH.ORDER_ITEM_TBL where ORDER_KEY in (370989) and SERIALIZED_ITEM_KEY = 3556246 ;
+---------+--------------+-------------+--------------+-------------------+----------+-----------+--------------------------+--------------------------+---------+-------------+-------+--------------------------+------------+---------+----------+----------------+----------------+-----------------+----------------+--------------+-----------+------------+---------------------+--------------+-----------+
|ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY    |OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|POLICY_KEY|PRODUCT_KEY|COVERAGE_START_DT         |COVERAGE_EXP_DT           |PRICE_AMT|LINE_QUANTITY|TAX_AMT|PURCHASE_DT               |SHIPPING_AMT|PROMO_KEY|BUNDLE_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|LINE_ITEM_TYPE_CD|SUBSCRIPTION_KEY|TAX_DETAIL_KEY|FLEXPAY_IND|COMMODITY_CD|ORDER_ITEM_STATUS_KEY|SYNC_AUDIT_KEY|PACKAGE_KEY|
+---------+--------------+-------------+--------------+-------------------+----------+-----------+--------------------------+--------------------------+---------+-------------+-------+--------------------------+------------+---------+----------+----------------+----------------+-----------------+----------------+--------------+-----------+------------+---------------------+--------------+-----------+
|392017   |1             |9422918073123|4             |3657069            |2892      |NULL       |2024-10-01 00:00:00.000000|2030-09-30 00:00:00.000000|379.20   |1            |24.65  |2024-03-02 00:00:00.000000|0           |NULL     |NULL      |787583          |809386          |PolicyLineItem   |NULL            |170526237     |N          |ESA         |NULL                 |809386        |NULL       |
|397265   |1             |9422918073075|4             |3657069            |2892      |NULL       |2024-10-01 00:00:00.000000|2030-09-30 00:00:00.000000|379.20   |1            |24.65  |2024-04-04 00:00:00.000000|0           |NULL     |NULL      |809330          |NULL            |PolicyLineItem   |NULL            |174457069     |N          |ESA         |NULL                 |809386        |NULL       |
+---------+--------------+-------------+--------------+-------------------+----------+-----------+--------------------------+--------------------------+---------+-------------+-------+--------------------------+------------+---------+----------+----------------+----------------+-----------------+----------------+--------------+-----------+------------+---------------------+--------------+-----------+

Select * from BOSH.ORDER_TBL where ORDER_KEY in (397265,392017)  ;

  select *
        from (
              select si.si_key, count(distinct ccx.contract_key)
                from p_serialized_item_dim si
                     join p_contract_coverage_xref ccx on ccx.si_key = si.si_key
                     join p_contract_lkp clkp on clkp.contract_key = ccx.contract_key
                     join p_contract_dim con on con.contract_key = clkp.contract_key
                     left join p_policy_ext_tbl pex ON (pex.policy_key = con.policy_key)

              where ccx.coverage_type_key = 2
                and con.retail_amt > 1
                --AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                and con.contract_status_key NOT IN (2, 3, 4, 5)
                AND exists (
                        select ccx3.si_key
                        from
                                p_contract_coverage_xref ccx3
                                join p_contract_lkp clkp3 on clkp3.contract_key = ccx3.contract_key
                                join p_contract_dim con3 on con3.contract_key = clkp3.contract_key
                                left join p_contract_status_dim cons3 on (cons3.contract_status_key = con3.contract_status_key)
                                join p_policy_ext_tbl pex3 ON (pex3.policy_key = con3.policy_key)
                        where
                              ccx3.coverage_type_key = 2
                        and ccx3.si_key  = ccx.si_key
                        and con3.contract_key <> con.contract_key
                        and
                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                             or
                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                            )
                        and con3.retail_amt > 1
                        AND con3.contract_status_key NOT IN (2, 3, 4, 5)   --canceled/fulfilled/expired
                        and pex3.channels = pex.channels
                        and con3.contract_end_dt >= trunc(sysdate) - 30
                       )

              group by si.si_key
             having count(distinct ccx.contract_key) >= 2
            );