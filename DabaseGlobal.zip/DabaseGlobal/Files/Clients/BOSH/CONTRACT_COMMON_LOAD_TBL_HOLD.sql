SELECT DISTINCT TRIM (BILLING_UNIQUE_SEQ_NO) UNIQUE_SEQ_NO,
                             oi.ORDER_KEY,
                             oi.coverage_Start_Dt,
                             oi.coverage_exp_dt,
                             1 SOURCE_SYSTEM_CD,
                             P2_CONTRACT_NO ORDER_XID,
                             --NVL(OL.ORDER_XID,P2_CONTRACT_NO) ORDER_XID,
                             P2_CONTRACT_NO CONTRACT_XID,
                             UPPER (TRIM (AD.FIRST_NM)) FIRST_NM,
                             ADDRESS_LINE1_TX,
                             ADDRESS_LINE2_TX,
                             CITY_NM,
                             STATE_CD,
                             ZIP_CODE5_TX,
                             VLKP.VISITOR_XID,
                             SLKP.SI_XID,
                             TRUNC( OI.PURCHASE_DT) CONTRACT_SALE_DT,
                             --CASE WHEN OT.SALES_SOURCE_CD IN ('MAIL_IN_SALES','WEB_SALES','CALL_CENTER_SALES') THEN
                             --  OI.COVERAGE_START_DT
                             --ELSE
                             --TO_DATE( CONTRACT_START_DATE,'MM/DD/YYYY')   END CONTRACT_START_DT,
                             TO_DATE( CONTRACT_START_DATE,'MM/DD/YYYY')  AS CONTRACT_START_DT,
                             --CASE WHEN OT.SALES_SOURCE_CD IN ('MAIL_IN_SALES','WEB_SALES','CALL_CENTER_SALES') THEN
                             --  OI.COVERAGE_START_DT
                             --ELSE TO_DATE( CONTRACT_START_DATE,'MM/DD/YYYY') END EFFECTIVE_DT,
                             TO_DATE( CONTRACT_START_DATE,'MM/DD/YYYY') as EFFECTIVE_DT,
                             --CASE WHEN OT.SALES_SOURCE_CD IN ('MAIL_IN_SALES','WEB_SALES','CALL_CENTER_SALES') THEN
                             --    OI.COVERAGE_EXP_DT
                             --ELSE TO_DATE( END_DATE,'MM/DD/YYYY')  END CONTRACT_END_DT,
                             --CASE WHEN OT.SALES_SOURCE_CD IN ('MAIL_IN_SALES','WEB_SALES','CALL_CENTER_SALES') THEN
                             --  OI.COVERAGE_EXP_DT
                             --ELSE TO_DATE( CONTRACT_END_DATE,'MM/DD/YYYY') END  CONTRACT_END_DT,
                             TO_DATE( CONTRACT_END_DATE,'MM/DD/YYYY') AS  CONTRACT_END_DT,
                             WARRANTY_EXPIRATION_DT  WARRANTY_EXP_DT,
                             TRUNC( OI.PURCHASE_DT)  PURCHASE_DT,
                             TRUNC(OI.PURCHASE_DT)  REGISTER_DT,
                             'BOSCH' REGISTER_BY,
                             --PURCHASE_DT_KEY + date '1989-12-31' PURCHASE_DT,
                             OI.TAX_AMT,
                             OI.TAX_AMT RETAIL_TAX_AMT,
                             UPPER(TRIM ('')) TAX_COUNTY,
                             COALESCE(TO_NUMBER(OI.PRICE_AMT) - TO_NUMBER(NVL(OID.DISCOUNT_AMT,0)),0) as RETAIL_AMT,
                             --nvl(to_number(TRIM (regexp_replace(DI.LINE_TAX,'[$]*','')))/DI.QUANTITY,0) as RETAIL_TAX_AMT,
                             --nvl((TRIM (regexp_replace(DEALER_SELLING_PRICE,'[$]*',''))),0) as PRICE_AMT,
                             UPPER(TRIM (AD.STATE_CD)) TAXING_STATE_NM,
                             UPPER(TRIM ('')) TAXING_COUNTY_NM,
                             UPPER(TRIM (AD.CITY_NM)) TAXING_CITY_NM,
                             COUNTRY_CD TAXING_COUNTRY_NM,
                             (PH.PHONE_NO) PRIMARY_PHONE_NO,
                             COMM.UTILITY.EMAIL_CLEAN (EMAIL_ADDRESS_TX) EMAIL_ADDRESS_TX,
                             SYSDATE  INSERT_DT,
                             UPPER (TRIM (FILE_NM)) FILE_NM,
                             SUBSTR(UNIQUE_IDENTIFIER,INSTR(UNIQUE_IDENTIFIER,'-')+1) ORDER_LINE_ID,
                             'L_INSERT_AUDIT_KEY' INSERT_AUDIT_KEY,
                             LINE_ITEM_TYPE_CD,
                             NVL(pl.policy_xid,'0') SKU_NO,
                             'USA' COUNTRY_CD,
                             TRIM(A.STATUS_CD) CONTRACT_STATUS_XID,
                             'N' CALL_CENTER_FLAG,
                             'USD' CURRENCY_CD,
                             'PURCHASE' ADDRESS_TYPE,
                             'READY' PROCESS_STATUS_TX,
                             OT.SALES_SOURCE_CD SALES_SOURCE_CD,
          --                   DEALER_ID OUTLET_XID,
          --                   CANCELLED_BY CANCEL_BY,
          --                   'FULCRUM_'||OT.SALES_SOURCE_CD as CHANNEL_PARTNER_XID,
                             'FULCRUM_' || OT.SALES_SOURCE_CD CREATED_BY,
                             '' ORDER_ITEM_LINE_XID ----TRIM (MERCHANT_LINE_ITEM_NUMBER) ORDER_ITEM_LINE_XID,
                             ,si.SERIAL_NO SI_UNIQUE_ID
                             ,pd.MODEL_NO PRODUCT_UNIQUE_ID
                             ,'1' TERMS_AND_CONDTIONS_XID
                             ,'1' CONTRACT_TEMPLATE_XID
                             ,AL.ADDRESS_XID AS ADDRESS_HASH_KEY ,
                              ROW_NUMBER () OVER (PARTITION BY slkp.si_key ORDER BY slkp.INSERT_AUDIT_KEY DESC ) AS rno    --bosh-397
                   FROM BOSH.RAW_CONTRACT_SALES_TBL  a
                   JOIN p_order_item_Tbl oi on ( SUBSTR(UNIQUE_IDENTIFIER,1,INSTR(UNIQUE_IDENTIFIER,'-')-1) = OI.ORDER_KEY AND SUBSTR(UNIQUE_IDENTIFIER,INSTR(UNIQUE_IDENTIFIER,'-')+1) = ORDER_LINE_KEY)
                   LEFT join p_ORDER_ITEM_DISC_INFO_LKP oid on (oi.ORDER_KEY = oid.order_key and OID.ORDER_LINE_KEY = oi.order_line_key)
                   JOIN p_order_tbl ot on ( oi.order_key = ot.order_key)
                   JOIN P_VISITOR_LKP VLKP ON ( OT.VISITOR_KEY = VLKP.VISITOR_KEY AND VLKP.SOURCE_SYSTEM_CD = 1)
                   JOIN P_SERIALIZED_ITEM_LKP SLKP ON ( SLKP.SI_KEY = OI.SERIALIZED_ITEM_KEY AND SLKP.SOURCE_SYSTEM_CD = 0
                                                        and substr(slkp.si_xid,instr(slkp.si_xid,'-',1,2)+1) = vlkp.visitor_xid)
                   JOIN p_serialized_item_dim si on   ( OI.SERIALIZED_ITEM_KEY = si.SI_KEY)
                   JOIN p_product_dim pd on ( si.product_key = pd.product_key)
                   LEFT JOIN p_order_lkp ol on (oi.ordeR_key = ol.order_key)
                   LEFT JOIN p_order_tbl ot on (oi.ordeR_key = ot.order_key)
                   LEFT JOIN p_shipping_info_tbl sh on ( oi.order_key = sh.order_key)
                   LEFT JOIN p_billing_info_tbl bi on ( oi.order_key = bi.order_key)
                   LEFT JOIN p_phone_dim ph on (sh.phone_key = ph.phone_key)
                   LEFT JOIN p_email_dim em on (bi.email_key = em.email_key)
                   LEFT JOIN p_address_dim ad on ( sh.address_key = ad.address_key)
                   LEFT JOIN P_ADDRESS_LKP AL ON ( AD.ADDRESS_KEY = AL.ADDRESS_KEY AND AL.source_system_cd = 0)
                   LEFT JOIN p_policy_lkp pl on ( oi.policy_key = pl.policy_key and pl.source_system_cd = 0)

             WHERE  a.UNIQUE_IDENTIFIER like '%325571%' and
                 NOT EXISTS ( SELECT 1 FROM CONTRACT_COMMON_LOAD_TBL_HOLD B
                                WHERE  a.billing_unique_seq_no IS NOT NULL
                                AND    b.unique_seq_no IS NOT NULL
                                AND    a.billing_unique_seq_no = b.unique_seq_no )