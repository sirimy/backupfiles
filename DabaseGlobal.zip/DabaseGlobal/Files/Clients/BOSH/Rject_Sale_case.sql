
Select * from v_product where MODEL_NO = 'HSLP751UC';

select * from BOSH.ORDER_EXTRACT_TBL where SKU_CD = 'BSCKX72U1';

Select * from BOSH.ORDER_TBL where ORDER_KEY = 320777;
--CALL_CENTER_INBOUND_SALES

Select * from BOSH.ORDER_ITEM_TBL where ORDER_KEY = 320777;
--SI_KEY =3016374 and Policy_Key =2874 and Price Amount = 956.00
Select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in (3016374,3016375);
--Product Key =20544 and Moedel No =HSLP751UC and Registration date =2022-07-20 15:57:12
Select * from BOSH.PRODUCT_DIM where PRODUCT_KEY in (20544,19676);
Select * from BOSH.V_PRODUCT where PRODUCT_KEY in (20544,19676);
--Product Name =Bosch Benchmark Combi + Steam and SKU  =825225908289 and Price Amt =6199.00 and Marketing Product Name =Steam Oven
select * from BOSH.PRODUCT_PRICE_DIM where PRODUCT_KEY in (20544) and POLICY_KEY = 2874;
--Term_Months = 72 = 6 years
-- PRICING_SCHEME_KEY = (76,78)
Select * from V_PRICING_SCHEME_DIM where PRICING_SCHEME_KEY in (76,78);
--76,AM Bosch
--78,EB Bosch
select * from BOSH.POLICY_TBL where POLICY_KEY in (2874);
--Policy Desc = 6 yr Bosch Appliance Service plan (AM)
-- Policy _ Prodct - XID = BSCKX72U1
--Min Price =5500.00 AND Max Price =6499.99
-- Term_key  = 6
select * from BOSH.POLICY_EXT_TBL where POLICY_KEY in (2874);
-- Brand = Bosch
-- CHANNELS  = AM EB


Select * from BOSH.RAW_CONTRACT_SALES_TBL where unique_identifier like '320777%';

Select * from BOSH.CONTRACT_ORDER_TBL where ORDER_KEY = 320777;
select * from BOSH.order_extract_tbl oet   where oet.unique_identifier like '320777%';

Select * from BOSH.RAW_CONTRACT_SALES_ERROR_TBL where unique_identifier like '320777%';

-- UNIQUE_IDENTIFIER,P2_CONTRACT_NO,STATUS_CD,CONTRACT_START_DATE,CONTRACT_END_DATE,ERROR_TXT,FILE_NM
-- 320777-2,BSH-320777-2,ACTIVE,10/12/2022,10/12/2028,CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR,BSH_Sale_Ack_07222022.txt

Select * from BOSH.CONTRACT_COMMON_LOAD_TBL_ARCH where CONTRACT_COMMON_LOAD_TBL_ARCH.ORDER_XID like '%320777%';
--SI_INIQUE_ID = DUH36252UC/xx-20211012-3642644
Select * from BOSH.CONTRACT_LKP where CONTRACT_XID like '%320777%';
Select * from BOSH.CONTRACT_LKP where CONTRACT_KEY = 140367;
--CONTRACT_KEY = 140367
Select * from BOSH.CONTRACT_DIM where CONTRACT_KEY = 140367;

--Sale dt = 2022-07-20
-- Policy Key = 2748
--COntract start date =2022-10-12



Select * from BOSH.CONTRACT_COVERAGE_XREF where CONTRACT_KEY = 140367;
--SI_Key =3016375
Select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in (3016375);
--Product Key =19676 and Moedel No = DUH36252UC and Registration date = 2022-07-20 15:59:30

Select * from BOSH.RAW_PRICING_TBL where SKU = 'BSCKX72U1';