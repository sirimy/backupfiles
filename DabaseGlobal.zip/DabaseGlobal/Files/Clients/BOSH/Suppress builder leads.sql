
-- select * from customer_tbl where first_nm = 'Imtiyaz' and customer_id = 9490001;
-- select * from serialized_item  where serialized_item_id = 149862919  AND  product_id = 7289370 order by last_updated_ts desc;
-- select * from order_tbl where order_id = 346531;

select * from BOSH.SYNC_PROCESS_MAPPING_TBL where upper(TARGET_TABLE_NAME) = 'COMMON_LOAD_HOLD_TBL';


select * from BOSH.VISITOR_LKP where VISITOR_XID = '9490001';
select * from BOSH.CUSTOMER_DIM where PRIMARY_VISITOR_KEY =2534037;
select * from BOSH.ORDER_TBL where VISITOR_KEY =2534037;
select * from BOSH.ORDER_ITEM_TBL where ORDER_KEY = 346531;
select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY =3376675;
select * from BOSH.CONTRACT_ORDER_TBL where ORDER_KEY = 346531;

select * from BOSH.CONTRACT_ORDER_TBL COT join AUDIT_TBL AT
         ON COT.INSERT_AUDIT_KEY = AT.AUDIT_KEY
         where AT.CREATION_DT > SYSDATE - 1
         order by INSERT_AUDIT_KEY desc;
select * from BOSH.CONTRACT_LKP COT join AUDIT_TBL AT
         ON COT.INSERT_AUDIT_KEY = AT.AUDIT_KEY
         where AT.CREATION_DT > SYSDATE - 1
         order by INSERT_AUDIT_KEY desc;

select * from BOSH.CONTRACT_DIM COT join AUDIT_TBL AT
         ON COT.INSERT_AUDIT_KEY = AT.AUDIT_KEY
         where AT.CREATION_DT > SYSDATE - 3
         order by INSERT_AUDIT_KEY desc;

select * from BOSH.SYNC_PROCESS_STATUS_TBL  order by RUN_ID desc;

-- delete from COMMON_LOAD_HOLD_TBL;

select * from COMMON_LOAD_HOLD_TBL;
select DISTINCT ORDER_KEY from COMMON_ORDER_HOLD_TBL order BY ORDER_KEY;

select * from COMMON_ORDER_HOLD_TBL order BY ORDER_KEY;

select ORDER_KEY,COUNT(ORDER_KEY),FILE_NM from COMMON_ORDER_HOLD_TBL GROUP BY   ORDER_KEY,FILE_NM;



SELECT DISTINCT
            unique_seq_no,
            source_system_cd,
            si_unique_id,
            si_xid,FILE_NM
            FROM	COMMON_LOAD_HOLD_TBL where si_xid is not NULL ;

select * from BOSH.SYNC_PROCESS_MAPPING_TBL where TARGET_COLUMN_NAME = upper('si_xid');

select * from BOSH.SYNC_PROCESS_STATUS_TBL where upper(TABLE_NAME) = 'COMMON_LOAD_SERIAL_ITEM_TBL' order by RUN_ID DESC;

-- python3 $HOME/python/sync/run_sync.py --source_schema BOSHBAPLWEB --target_schema BOSHSTG --target_table_name COMMON_LOAD_SERIAL_ITEM_TBL

SELECT DISTINCT
            unique_seq_no,
            source_system_cd,
            si_unique_id,
            si_xid
            FROM	COMMON_LOAD_HOLD_TBL;

select * from COMMON_LOAD_TBL;

SELECT DISTINCT
            unique_seq_no,
            source_system_cd,
            si_unique_id,
            si_xid
            FROM	common_load_tbl;

select * from si_output_tbl;

SELECT DISTINCT sot.posted_serial_item_key, 'WEB', 'N'
                  FROM si_output_tbl  sot
                       JOIN common_load_tbl clt ON ( sot.unique_seq_no = clt.unique_seq_no )
                       LEFT JOIN p_raw_leads_tbl rl ON ( rl.unique_seq_no = sot.unique_seq_no )
                       LEFT JOIN p_raw_inwarranty_leads_tbl rl2 ON ( rl2.unique_seq_no = sot.unique_seq_no )
                       LEFT JOIN p_raw_registria_leads_tbl rl3 ON ( rl3.unique_seq_no = sot.unique_seq_no )
                       LEFT JOIN p_raw_builder_leads_tbl rl4 ON ( rl4.unique_seq_no = sot.unique_seq_no )
                       LEFT JOIN p_raw_ggn_dns_tbl rl5 ON ( rl5.unique_seq_no = sot.unique_seq_no )
                 WHERE 1 = 1
                   AND rl.unique_seq_no IS NULL
                   AND rl2.unique_seq_no IS NULL
                   AND rl3.unique_seq_no IS NULL
                   AND rl4.unique_seq_no IS NULL
                   AND rl5.unique_seq_no IS NULL
                   AND clt.file_nm = 'v_sync_serilaized_item'
                   AND sot.posted_serial_item_key NOT IN (
                          SELECT six.si_key FROM serialized_item_ext_dim six
                          UNION ALL
                          SELECT six.si_key FROM p_serialized_item_ext_dim six
                          );

Select * from visitor_dim;
Select * from visitor_lkp;--0
Select * from visitor_history_tbl;
Select * from address_dim;
Select * from address_lkp;--0
Select * from visitor_address_xref;
Select * from visitor_address_lkp;
Select * from serialized_item_dim;
Select distinct PRODUCT_KEY,MODEL_NO from serialized_item_dim;
Select * from serialized_item_lkp;
select * from serialized_item_ext_dim;
Select * from visitor_ownership_xref;
Select * from email_lkp;
Select * from email_dim;
Select * from visitor_email_xref;
Select * from visitor_email_lkp;
Select * from phone_dim;
Select * from phone_lkp;
Select * from visitor_phone_xref;
Select * from visitor_phone_lkp;
Select * from VISITOR_PREFERENCE_TBL;
Select * from purl_dim;
Select * from VISITOR_PURL_XREF;
Select * from CUSTOMER_DIM;
Select * from HOUSEHOLD_LKP;
Select * from CUSTOMER_LKP;

-- delete COMMON_ORDER_HOLD_TBL;
select * from ORDER_TBL;-- where ORDER_KEY in (346527,346523);
select * from ORDER_LKP where ORDER_KEY in (346527,346523);
select * from VISITOR_LKP where VISITOR_XID = '9489801';
select * from CUSTOMER_DIM where PRIMARY_VISITOR_KEY =2534036;
select * from CUSTOMER_DIM where CUSTOMER_KEY = 4646036;
select * from ORDER_TBL where CREATED_TS is not null order by CREATED_TS desc;
select * from ORDER_TBL where VISITOR_KEY =2534036;
select * from ORDER_ITEM_TBL where ORDER_KEY = 346529;
select * from SERIALIZED_ITEM_DIM where SI_KEY in (3376673,3376674);
select * from CONTRACT_ORDER_TBL where ORDER_KEY in (346527,346523);

+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+-------------+--------+-------------+---------+------------+----------+------+-----------------+-----------------+---------------+---------+-------------+---------+-------------+-------------+-------------+-------------+----------+-----------------+------------------+---------------+----------+--------+-----------+----------------+---------------+---------------+-------------+--------------+----------------+--------------+---------------+--------------+------------+-------------+-----------------+--------+---------------+--------+---------+------------+-----------+----------------+-------------+---------+-------------------+-------------------+---------------------------+----------------+-----------------+-------------+----------------+--------------+------------------------+-----------------+------------+-------------------+------------------------+-------------------+---------------+--------------------+----------------------+-------------------+------------------+--------------+--------------+-------------------+-------------------+--------------+--------------+------------+--------------+--------------+------+------+-------------------------+---------------+-----------+-----------+-------------------+----------------------+------------+---------------------+------------------+--------------+-----------+-----------+----------------------+-----------------+-----------+--------------------+----------------+-----------------------+------------------------+--------------------------+
|ORDER_KEY|ORDER_XID|BILLING_PROFILE_XID|CREATED_BY      |PURCHASE_DT               |CALL_CENTER_FLAG|SUB_TOTAL_AMT|TAX_AMT|TAX_COUNTY|SURCHARGE_AMT|SHIPPING_AND_HANDLING_AMT|TOTAL_AMT|VISITOR_XID|ORDER_LINE_ID|OFFER_ID|OFFER_LINE_ID|SI_XID   |SI_UNIQUE_ID|POLICY_XID|SKU_NO|PRODUCT_UNIQUE_ID|COVERAGE_START_DT|COVERAGE_EXP_DT|PRICE_AMT|LINE_QUANTITY|PROMO_KEY|DISCOUNT1_AMT|DISCOUNT1_PCT|DISCOUNT2_AMT|DISCOUNT2_PCT|BUNDLE_KEY|LINE_ITEM_TYPE_CD|FCRM_ORDER_LINE_ID|SALES_SOURCE_CD|OUTLET_XID|DML_FLAG|FLEXPAY_IND|COUNTRY_TAX_RATE|COUNTRY_TAX_AMT|TAXING_STATE_NM|STATE_TAX_AMT|STATE_TAX_RATE|TAXING_COUNTY_NM|COUNTY_TAX_AMT|COUNTY_TAX_RATE|TAXING_CITY_NM|CITY_TAX_AMT|CITY_TAX_RATE|TAXING_COUNTRY_NM|TAX_RATE|SUBSCRIPTION_ID|PHONE_NO|PHONE_XID|ADDRESS_TYPE|ADDRESS_XID|ADDRESS_HASH_KEY|EMAIL_ADDRESS|EMAIL_XID|INSERT_DT          |EFFECTIVE_DT       |FILE_NM                    |SOURCE_SYSTEM_CD|PROCESS_STATUS_TX|UNIQUE_SEQ_NO|INSERT_AUDIT_KEY|TAX_DETAIL_KEY|SURCHARGE_ASSESSMENT_KEY|SURCHARGE_TYPE_CD|COMMODITY_CD|TOTAL_ORDER_TAX_AMT|TOTAL_ORDER_SHIPPING_AMT|ORDER_ITEM_LINE_XID|ORDER_STATUS_ID|ORDER_ITEM_STATUS_ID|ADDRESS_CHNG_STATUS_CD|SECONDARY_PHONE_XID|SECONDARY_PHONE_NO|ORDER_DISC_AMT|ORDER_DISC_XID|ORDER_ITEM_DISC_AMT|ORDER_ITEM_DISC_XID|PAYMENT_TX_KEY|PAYMENT_SEQ_NO|PAYMENT_TYPE|MASKED_CARD_NO|CARD_HOLDER_NM|CAW_TX|ECI_TX|PAYER_AUTHENTICATION_FLAG|PAYMENT_TX_TYPE|PAYMENT_AMT|CURRENCY_CD|MASKED_BANK_ACCT_NO|MASKED_BANK_ROUTING_NO|CARD_TYPE_TX|PAYMENT_REFERENCE_NUM|PAYMENT_DEPOSIT_DT|SYNC_AUDIT_KEY|PRODUCT_XID|PACKAGE_XID|ORDER_ITEM_TRACKING_NO|SHIP_QUANTITY_AMT|SHIPPING_TS|SHIPPING_PROVIDER_NM|OUTLET_UNIQUE_ID|ORDER_DISCOUNT_INFO_KEY|ORDER_ITEM_DISC_INFO_KEY|CREATED_TS                |
+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+-------------+--------+-------------+---------+------------+----------+------+-----------------+-----------------+---------------+---------+-------------+---------+-------------+-------------+-------------+-------------+----------+-----------------+------------------+---------------+----------+--------+-----------+----------------+---------------+---------------+-------------+--------------+----------------+--------------+---------------+--------------+------------+-------------+-----------------+--------+---------------+--------+---------+------------+-----------+----------------+-------------+---------+-------------------+-------------------+---------------------------+----------------+-----------------+-------------+----------------+--------------+------------------------+-----------------+------------+-------------------+------------------------+-------------------+---------------+--------------------+----------------------+-------------------+------------------+--------------+--------------+-------------------+-------------------+--------------+--------------+------------+--------------+--------------+------+------+-------------------------+---------------+-----------+-----------+-------------------+----------------------+------------+---------------------+------------------+--------------+-----------+-----------+----------------------+-----------------+-----------+--------------------+----------------+-----------------------+------------------------+--------------------------+
|346523   |QOH2FH   |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |2.75         |6.35   |NULL      |NULL         |0.00                     |2.75     |9489801    |1            |NULL    |NULL         |149862693|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |0               |0              |CT             |6.35         |.0635         |FAIRFIELD       |0             |0              |NORWALK       |0           |0            |US               |NULL    |NULL           |NULL    |149862699|BILLING     |2874791    |NULL            |NULL         |149862701|2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555303      |668257          |149862691     |NULL                    |NULL             |NULL        |0.00               |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 06:01:09.993000|
|346523   |QOH2FH   |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |2.75         |6.35   |NULL      |NULL         |0.00                     |2.75     |9489801    |2            |NULL    |NULL         |149862697|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |NULL            |NULL           |NULL           |NULL         |NULL          |NULL            |NULL          |NULL           |NULL          |NULL        |NULL         |NULL             |NULL    |NULL           |NULL    |149862699|SHIPPING    |2874793    |NULL            |NULL         |NULL     |2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555312      |668257          |NULL          |NULL                    |NULL             |NULL        |0.00               |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 06:01:09.993000|
|346523   |QOH2FH   |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |2.75         |6.35   |NULL      |NULL         |0.00                     |2.75     |9489801    |1            |NULL    |NULL         |149862693|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |NULL            |NULL           |NULL           |NULL         |NULL          |NULL            |NULL          |NULL           |NULL          |NULL        |NULL         |NULL             |NULL    |NULL           |NULL    |149862699|SHIPPING    |2874793    |NULL            |NULL         |NULL     |2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555311      |668257          |NULL          |NULL                    |NULL             |NULL        |0.00               |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 06:01:09.993000|
|346523   |QOH2FH   |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |2.75         |6.35   |NULL      |NULL         |0.00                     |2.75     |9489801    |2            |NULL    |NULL         |149862697|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |0               |0              |CONNECTICUT    |6.35         |.0635         |FAIRFIELD       |0             |0              |NORWALK       |0           |0            |US               |NULL    |NULL           |NULL    |149862699|BILLING     |2874791    |NULL            |NULL         |149862701|2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555304      |668257          |149862695     |NULL                    |NULL             |NULL        |0.00               |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 06:01:09.993000|
|346527   |QOH2FH-1 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |274.97       |6.35   |NULL      |NULL         |0.00                     |274.97   |9489801    |1            |NULL    |NULL         |149862797|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |NULL            |NULL           |NULL           |NULL         |NULL          |NULL            |NULL          |NULL           |NULL          |NULL        |NULL         |NULL             |NULL    |NULL           |NULL    |149862803|SHIPPING    |2874997    |NULL            |NULL         |NULL     |2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555313      |668257          |NULL          |NULL                    |NULL             |NULL        |0.00               |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 07:19:24.105000|
|346527   |QOH2FH-1 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |274.97       |6.35   |NULL      |NULL         |0.00                     |274.97   |9489801    |2            |NULL    |NULL         |149862801|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |NULL            |NULL           |NULL           |NULL         |NULL          |NULL            |NULL          |NULL           |NULL          |NULL        |NULL         |NULL             |NULL    |NULL           |NULL    |149862803|SHIPPING    |2874997    |NULL            |NULL         |NULL     |2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555314      |668257          |NULL          |NULL                    |NULL             |NULL        |0.00               |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 07:19:24.105000|
|346527   |QOH2FH-1 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |274.97       |6.35   |NULL      |NULL         |0.00                     |274.97   |9489801    |1            |NULL    |NULL         |149862797|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |0               |0              |CT             |6.35         |.0635         |FAIRFIELD       |0             |0              |NORWALK       |0           |0            |US               |NULL    |NULL           |NULL    |149862803|BILLING     |2874995    |NULL            |NULL         |149862805|2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555305      |668257          |149862795     |NULL                    |NULL             |NULL        |0.00               |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 07:19:24.105000|
|346527   |QOH2FH-1 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |274.97       |6.35   |NULL      |NULL         |0.00                     |274.97   |9489801    |2            |NULL    |NULL         |149862801|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |0               |0              |CONNECTICUT    |6.35         |.0635         |FAIRFIELD       |0             |0              |NORWALK       |0           |0            |US               |NULL    |NULL           |NULL    |149862803|BILLING     |2874995    |NULL            |NULL         |149862805|2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555306      |668257          |149862799     |NULL                    |NULL             |NULL        |0.00               |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 07:19:24.105000|
+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+-------------+--------+-------------+---------+------------+----------+------+-----------------+-----------------+---------------+---------+-------------+---------+-------------+-------------+-------------+-------------+----------+-----------------+------------------+---------------+----------+--------+-----------+----------------+---------------+---------------+-------------+--------------+----------------+--------------+---------------+--------------+------------+-------------+-----------------+--------+---------------+--------+---------+------------+-----------+----------------+-------------+---------+-------------------+-------------------+---------------------------+----------------+-----------------+-------------+----------------+--------------+------------------------+-----------------+------------+-------------------+------------------------+-------------------+---------------+--------------------+----------------------+-------------------+------------------+--------------+--------------+-------------------+-------------------+--------------+--------------+------------+--------------+--------------+------+------+-------------------------+---------------+-----------+-----------+-------------------+----------------------+------------+---------------------+------------------+--------------+-----------+-----------+----------------------+-----------------+-----------+--------------------+----------------+-----------------------+------------------------+--------------------------+
+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+-------------+--------+-------------+---------+------------+----------+------+-----------------+-----------------+---------------+---------+-------------+---------+-------------+-------------+-------------+-------------+----------+-----------------+------------------+---------------+----------+--------+-----------+----------------+---------------+---------------+-------------+--------------+----------------+--------------+---------------+--------------+------------+-------------+-----------------+--------+---------------+--------+---------+------------+-----------+----------------+-------------+---------+-------------------+-------------------+---------------------------+----------------+-----------------+-------------+----------------+----------+--------------+------------------------+-----------------+------------+-------------------+------------------------+-------------------+---------------+--------------------+----------------------+-------------------+------------------+--------------+--------------+-------------------+-------------------+--------------+--------------+------------+--------------+--------------+------+------+-------------------------+---------------+-----------+-----------+-------------------+----------------------+------------+---------------------+------------------+--------------+-----------+-----------+----------------------+-----------------+-----------+--------------------+----------------+-----------------------+------------------------+--------------------------+
|ORDER_KEY|ORDER_XID|BILLING_PROFILE_XID|CREATED_BY      |PURCHASE_DT               |CALL_CENTER_FLAG|SUB_TOTAL_AMT|TAX_AMT|TAX_COUNTY|SURCHARGE_AMT|SHIPPING_AND_HANDLING_AMT|TOTAL_AMT|VISITOR_XID|ORDER_LINE_ID|OFFER_ID|OFFER_LINE_ID|SI_XID   |SI_UNIQUE_ID|POLICY_XID|SKU_NO|PRODUCT_UNIQUE_ID|COVERAGE_START_DT|COVERAGE_EXP_DT|PRICE_AMT|LINE_QUANTITY|PROMO_KEY|DISCOUNT1_AMT|DISCOUNT1_PCT|DISCOUNT2_AMT|DISCOUNT2_PCT|BUNDLE_KEY|LINE_ITEM_TYPE_CD|FCRM_ORDER_LINE_ID|SALES_SOURCE_CD|OUTLET_XID|DML_FLAG|FLEXPAY_IND|COUNTRY_TAX_RATE|COUNTRY_TAX_AMT|TAXING_STATE_NM|STATE_TAX_AMT|STATE_TAX_RATE|TAXING_COUNTY_NM|COUNTY_TAX_AMT|COUNTY_TAX_RATE|TAXING_CITY_NM|CITY_TAX_AMT|CITY_TAX_RATE|TAXING_COUNTRY_NM|TAX_RATE|SUBSCRIPTION_ID|PHONE_NO|PHONE_XID|ADDRESS_TYPE|ADDRESS_XID|ADDRESS_HASH_KEY|EMAIL_ADDRESS|EMAIL_XID|INSERT_DT          |EFFECTIVE_DT       |FILE_NM                    |SOURCE_SYSTEM_CD|PROCESS_STATUS_TX|UNIQUE_SEQ_NO|INSERT_AUDIT_KEY|PROCESS_DT|TAX_DETAIL_KEY|SURCHARGE_ASSESSMENT_KEY|SURCHARGE_TYPE_CD|COMMODITY_CD|TOTAL_ORDER_TAX_AMT|TOTAL_ORDER_SHIPPING_AMT|ORDER_ITEM_LINE_XID|ORDER_STATUS_ID|ORDER_ITEM_STATUS_ID|ADDRESS_CHNG_STATUS_CD|SECONDARY_PHONE_XID|SECONDARY_PHONE_NO|ORDER_DISC_AMT|ORDER_DISC_XID|ORDER_ITEM_DISC_AMT|ORDER_ITEM_DISC_XID|PAYMENT_TX_KEY|PAYMENT_SEQ_NO|PAYMENT_TYPE|MASKED_CARD_NO|CARD_HOLDER_NM|CAW_TX|ECI_TX|PAYER_AUTHENTICATION_FLAG|PAYMENT_TX_TYPE|PAYMENT_AMT|CURRENCY_CD|MASKED_BANK_ACCT_NO|MASKED_BANK_ROUTING_NO|CARD_TYPE_TX|PAYMENT_REFERENCE_NUM|PAYMENT_DEPOSIT_DT|SYNC_AUDIT_KEY|PRODUCT_XID|PACKAGE_XID|ORDER_ITEM_TRACKING_NO|SHIP_QUANTITY_AMT|SHIPPING_TS|SHIPPING_PROVIDER_NM|OUTLET_UNIQUE_ID|ORDER_DISCOUNT_INFO_KEY|ORDER_ITEM_DISC_INFO_KEY|CREATED_TS                |
+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+-------------+--------+-------------+---------+------------+----------+------+-----------------+-----------------+---------------+---------+-------------+---------+-------------+-------------+-------------+-------------+----------+-----------------+------------------+---------------+----------+--------+-----------+----------------+---------------+---------------+-------------+--------------+----------------+--------------+---------------+--------------+------------+-------------+-----------------+--------+---------------+--------+---------+------------+-----------+----------------+-------------+---------+-------------------+-------------------+---------------------------+----------------+-----------------+-------------+----------------+----------+--------------+------------------------+-----------------+------------+-------------------+------------------------+-------------------+---------------+--------------------+----------------------+-------------------+------------------+--------------+--------------+-------------------+-------------------+--------------+--------------+------------+--------------+--------------+------+------+-------------------------+---------------+-----------+-----------+-------------------+----------------------+------------+---------------------+------------------+--------------+-----------+-----------+----------------------+-----------------+-----------+--------------------+----------------+-----------------------+------------------------+--------------------------+
|346529   |QOH2FH-2 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |212.68       |6.35   |NULL      |NULL         |0.00                     |225.46   |9489801    |1            |NULL    |NULL         |149862851|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |0               |0              |CT             |6.35         |.0635         |FAIRFIELD       |0             |0              |NORWALK       |0           |0            |US               |NULL    |NULL           |NULL    |149862857|BILLING     |2875191    |NULL            |NULL         |149862859|2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555307      |668257          |20230428  |149862849     |NULL                    |NULL             |NULL        |12.70              |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 07:46:05.858000|
|346529   |QOH2FH-2 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |212.68       |6.35   |NULL      |NULL         |0.00                     |225.46   |9489801    |2            |NULL    |NULL         |149862855|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |0               |0              |CONNECTICUT    |6.35         |.0635         |FAIRFIELD       |0             |0              |NORWALK       |0           |0            |US               |NULL    |NULL           |NULL    |149862857|BILLING     |2875191    |NULL            |NULL         |149862859|2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555308      |668257          |20230428  |149862853     |NULL                    |NULL             |NULL        |12.70              |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 07:46:05.858000|
|346529   |QOH2FH-2 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |212.68       |6.35   |NULL      |NULL         |0.00                     |225.46   |9489801    |1            |NULL    |NULL         |149862851|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |NULL            |NULL           |NULL           |NULL         |NULL          |NULL            |NULL          |NULL           |NULL          |NULL        |NULL         |NULL             |NULL    |NULL           |NULL    |149862857|SHIPPING    |2875193    |NULL            |NULL         |NULL     |2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555315      |668257          |20230428  |NULL          |NULL                    |NULL             |NULL        |12.70              |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 07:46:05.858000|
|346529   |QOH2FH-2 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |212.68       |6.35   |NULL      |NULL         |0.00                     |225.46   |9489801    |2            |NULL    |NULL         |149862855|NULL        |5042      |NULL  |NULL             |NULL             |NULL           |106.34   |1            |NULL     |NULL         |NULL         |NULL         |NULL         |NULL      |PolicyLineItem   |NULL              |BUILDER_APP    |NULL      |NULL    |N          |NULL            |NULL           |NULL           |NULL         |NULL          |NULL            |NULL          |NULL           |NULL          |NULL        |NULL         |NULL             |NULL    |NULL           |NULL    |149862857|SHIPPING    |2875193    |NULL            |NULL         |NULL     |2023-04-28 13:04:19|2023-04-28 13:03:19|v_sync_order_common_extract|2               |READY            |8555316      |668257          |20230428  |NULL          |NULL                    |NULL             |NULL        |12.70              |NULL                    |NULL               |NULL           |NULL                |NULL                  |NULL               |NULL              |NULL          |NULL          |NULL               |NULL               |NULL          |NULL          |NULL        |NULL          |NULL          |NULL  |NULL  |NULL                     |NULL           |NULL       |USD        |NULL               |NULL                  |NULL        |NULL                 |NULL              |NULL          |NULL       |NULL       |NULL                  |NULL             |NULL       |NULL                |NULL            |NULL                   |NULL                    |2023-04-26 07:46:05.858000|
+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+-------------+--------+-------------+---------+------------+----------+------+-----------------+-----------------+---------------+---------+-------------+---------+-------------+-------------+-------------+-------------+----------+-----------------+------------------+---------------+----------+--------+-----------+----------------+---------------+---------------+-------------+--------------+----------------+--------------+---------------+--------------+------------+-------------+-----------------+--------+---------------+--------+---------+------------+-----------+----------------+-------------+---------+-------------------+-------------------+---------------------------+----------------+-----------------+-------------+----------------+----------+--------------+------------------------+-----------------+------------+-------------------+------------------------+-------------------+---------------+--------------------+----------------------+-------------------+------------------+--------------+--------------+-------------------+-------------------+--------------+--------------+------------+--------------+--------------+------+------+-------------------------+---------------+-----------+-----------+-------------------+----------------------+------------+---------------------+------------------+--------------+-----------+-----------+----------------------+-----------------+-----------+--------------------+----------------+-----------------------+------------------------+--------------------------+

select * from P_COMMON_ORDER_ERROR_TBL where order_key in (346527,346523) order by order_key;

+---------------------------------------+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+
|ERROR_DESC                             |ORDER_KEY|ORDER_XID|BILLING_PROFILE_XID|CREATED_BY      |PURCHASE_DT               |CALL_CENTER_FLAG|SUB_TOTAL_AMT|TAX_AMT|
+---------------------------------------+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+
|Error 2: Unable to find Serialized Item|346523   |QOH2FH   |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |2.75         |6.35   |
|Error 2: Unable to find Serialized Item|346523   |QOH2FH   |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |2.75         |6.35   |
|Error 2: Unable to find Serialized Item|346523   |QOH2FH   |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |2.75         |6.35   |
|Error 2: Unable to find Serialized Item|346523   |QOH2FH   |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |2.75         |6.35   |
|Error 2: Unable to find Serialized Item|346527   |QOH2FH-1 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |274.97       |6.35   |
|Error 2: Unable to find Serialized Item|346527   |QOH2FH-1 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |274.97       |6.35   |
|Error 2: Unable to find Serialized Item|346527   |QOH2FH-1 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |274.97       |6.35   |
|Error 2: Unable to find Serialized Item|346527   |QOH2FH-1 |NULL               |builder-services|2023-04-25 05:00:00.000000|N               |274.97       |6.35   |
+---------------------------------------+---------+---------+-------------------+----------------+--------------------------+----------------+-------------+-------+

-- delete from BOSH.SYNC_PROCESS_STATUS_TBL where RUN_ID > 61768;
-- delete from COMMON_ORDER_HOLD_TBL;
-- delete from COMMON_ORDER_HOLD_TBL;
-- delete from COMMON_LOAD_HOLD_TBL;
-- delete from COMMON_CLAIM_HOLD_TBL;
--delete from CONTRACT_COMMON_LOAD_TBL_HOLD;

select * from P_COMMON_LOAD_OUTPUT_TBL_ARCH where VISITOR_KEY =2534036 order by PROCESS_DT desc;
--select * from order_tbl where order_id in (346529,346527,346523) and sales_source_cd = 'BUILDER_APP' order by order_id desc;
select * from bosh.COMMON_ORDER_TBL_ARCH where order_key in (346529,346527,346523);
select count(*) from bosh.COMMON_ORDER_TBL_ARCH where ORDER_XID in ('346529','346527','346523');

--select * from BOSH.SYNC_PROCESS_STATUS_TBL where RUN_ID > 61768 order by RUN_ID asc;

select * from BOSH.SYNC_PROCESS_STATUS_TBL where RUN_ID >  61861  order by RUN_ID desc;

select distinct sales_source_cd from BOSH.ORDER_TBL;
COMMIT;
---------------------------------------------------------------------------------
select * from BOSH.ORDER_TBL where ORDER_KEY in (346547,346545,346533);
select * from BOSH.ORDER_LKP where ORDER_KEY in (346547,346545,346533);
select * from BOSH.ORDER_ITEM_TBL where ORDER_KEY in (346547,346545,346533);

select ORDER_KEY,COUNT(ORDER_KEY) from BOSH.ORDER_ITEM_TBL where ORDER_KEY in (346547,346545,346533)
Group by ORDER_KEY;

select * from ORDER_TBL where ORDER_KEY in (346529,346527,346523);
select * from ORDER_LKP where ORDER_KEY in (346529,346527,346523);
select * from VISITOR_LKP where VISITOR_XID = '9489801';
select * from CUSTOMER_DIM where PRIMARY_VISITOR_KEY =2534036;
select * from CUSTOMER_DIM where CUSTOMER_KEY = 4646036;
select * from ORDER_TBL where CREATED_TS is not null order by CREATED_TS desc;
select * from ORDER_TBL where VISITOR_KEY =2534036;
select * from ORDER_ITEM_TBL where ORDER_KEY = 346529;
select * from SERIALIZED_ITEM_DIM where SI_KEY in (3376673,3376674);
select * from CONTRACT_ORDER_TBL where ORDER_KEY = 346529;
+---------+---------+----------------+--------------+----------------+----------------+--------------+
|ORDER_KEY|ORDER_XID|SOURCE_SYSTEM_CD|EXT_ID_TYPE_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+---------+---------+----------------+--------------+----------------+----------------+--------------+
|346529   |QOH2FH-2 |2               |2             |668257          |NULL            |668297        |
+---------+---------+----------------+--------------+----------------+----------------+--------------+

-----------------------------------------------------------------------------
select * from BOSH.ORDER_TBL where ORDER_KEY in (346529);
select * from BOSH.ORDER_LKP where ORDER_KEY in (346529);
select * from BOSH.VISITOR_LKP where VISITOR_XID = '9489801';
select * from BOSH.CUSTOMER_DIM where PRIMARY_VISITOR_KEY =2534036;
select * from BOSH.CUSTOMER_DIM where CUSTOMER_KEY = 4646036;
select * from BOSH.ORDER_TBL where VISITOR_KEY =2534036;
select * from BOSH.ORDER_ITEM_TBL where ORDER_KEY = 346529;
+---------+--------------+---------+--------------+-------------------+----------+-----------+-----------------+--------------------------+---------+-------------+-------+--------------------------+------------+---------+----------+----------------+----------------+-----------------+----------------+--------------+-----------+------------+---------------------+--------------+-----------+
|ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY|OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|POLICY_KEY|PRODUCT_KEY|COVERAGE_START_DT|COVERAGE_EXP_DT           |PRICE_AMT|LINE_QUANTITY|TAX_AMT|PURCHASE_DT               |SHIPPING_AMT|PROMO_KEY|BUNDLE_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|LINE_ITEM_TYPE_CD|SUBSCRIPTION_KEY|TAX_DETAIL_KEY|FLEXPAY_IND|COMMODITY_CD|ORDER_ITEM_STATUS_KEY|SYNC_AUDIT_KEY|PACKAGE_KEY|
+---------+--------------+---------+--------------+-------------------+----------+-----------+-----------------+--------------------------+---------+-------------+-------+--------------------------+------------+---------+----------+----------------+----------------+-----------------+----------------+--------------+-----------+------------+---------------------+--------------+-----------+
|346529   |1             |NULL     |NULL          |3376673            |5042      |NULL       |NULL             |2025-04-24 00:00:00.000000|106.34   |1            |6.35   |2023-04-25 05:00:00.000000|0           |NULL     |NULL      |668257          |NULL            |PolicyLineItem   |NULL            |149862849     |N          |NULL        |NULL                 |668303        |NULL       |
|346529   |2             |NULL     |NULL          |3376674            |5042      |NULL       |NULL             |2025-04-24 00:00:00.000000|106.34   |1            |6.35   |2023-04-25 05:00:00.000000|0           |NULL     |NULL      |668257          |NULL            |PolicyLineItem   |NULL            |149862853     |N          |NULL        |NULL                 |668303        |NULL       |
+---------+--------------+---------+--------------+-------------------+----------+-----------+-----------------+--------------------------+---------+-------------+-------+--------------------------+------------+---------+----------+----------------+----------------+-----------------+----------------+--------------+-----------+------------+---------------------+--------------+-----------+

select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in (3376673,3376674);
+-------+-----------+---------+---------+---------------+----------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
|SI_KEY |PRODUCT_KEY|SERIAL_NO|MODEL_NO |PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT|PURCHASE_AMT|CURRENCY_CD|LAST_UPDATED_LEADS_DT|REGISTRATION_DT    |QUALITY_SCORE|END_DT|DIM_STATUS_CD|LATEST_COVERAGE_EXP_DT|LATEST_COVERAGE_TYPE|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-------+-----------+---------+---------+---------------+----------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
|3376673|26984      |S1234    |NITP668UC|12125          |NULL                  |NULL        |USD        |NULL                 |2023-04-28 11:43:59|10           |NULL  |A            |NULL                  |1                   |667929          |668268          |668268        |
|3376674|26984      |S1234    |NITP668UC|12125          |NULL                  |NULL        |USD        |NULL                 |2023-04-28 11:43:59|10           |NULL  |A            |NULL                  |1                   |667929          |668268          |668268        |
+-------+-----------+---------+---------+---------------+----------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+

select * from BOSH.SERIALIZED_ITEM_EXT_DIM where SI_KEY in (3376673,3376674);
+-------+---------------+-------+----------------+----------------+--------------+--------+-------------+------+---------------------+------------------+--------+---------------------+-------------------+-------------------+----------------+
|SI_KEY |REGISTRATION_DT|IOBJECT|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|COSMO_ID|DUPLICATE_IND|SOURCE|MANUFACTURING_DATE_FD|CONSECUTIVE_NUMBER|E_NUMBER|REG_UNIQUE_IDENTIFIER|OWNERSHIP_INTENTION|INSTALL_DT         |ADDRESS_LINE2_TX|
+-------+---------------+-------+----------------+----------------+--------------+--------+-------------+------+---------------------+------------------+--------+---------------------+-------------------+-------------------+----------------+
|3376673|NULL           |NULL   |667976          |668341          |668341        |NULL    |N            |WEB   |NULL                 |NULL              |NULL    |NULL                 |NULL               |2023-04-13 05:00:00|10B             |
|3376674|NULL           |NULL   |667976          |668341          |668341        |NULL    |N            |WEB   |NULL                 |NULL              |NULL    |NULL                 |NULL               |2023-04-13 05:00:00|10B             |
+-------+---------------+-------+----------------+----------------+--------------+--------+-------------+------+---------------------+------------------+--------+---------------------+-------------------+-------------------+----------------+

select * from BOSH.SERIALIZED_ITEM_LKP where SI_KEY in (3376673,3376674);
+-------+-----------------------------+----------------+--------------+----------------+----------------+--------------+
|SI_KEY |SI_XID                       |SOURCE_SYSTEM_CD|EXT_ID_TYPE_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-------+-----------------------------+----------------+--------------+----------------+----------------+--------------+
|3376673|149862851                    |2               |1             |667929          |NULL            |667966        |
|3376673|NITP668UC/xx-20230313-4646036|0               |2             |668343          |NULL            |668344        |
|3376674|149862855                    |2               |1             |667929          |NULL            |667966        |
|3376674|NITP668UC/xx-20230313-4646036|0               |2             |668343          |NULL            |668344        |
+-------+-----------------------------+----------------+--------------+----------------+----------------+--------------+


select * from BOSH.CONTRACT_ORDER_TBL where ORDER_KEY = 346529;

select * from BOSH.SERIALIZED_ITEM_LKP order by INSERT_AUDIT_KEY desc;

-----------------------------------------------------------------------------------
select * from BOSH.ORDER_TBL where ORDER_KEY in (346529,346527,346523,346531);
select * from BOSH.ORDER_LKP where ORDER_KEY in (346529,346527,346523,346531);
select * from BOSH.VISITOR_LKP where VISITOR_XID = '4646044';
select * from BOSH.CUSTOMER_DIM where PRIMARY_VISITOR_KEY =2534037;
select * from BOSH.CUSTOMER_DIM where CUSTOMER_KEY = 4646044;
select * from BOSH.ORDER_TBL where VISITOR_KEY =2534037;
select * from BOSH.ORDER_ITEM_TBL where ORDER_KEY = 346531;
select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY =3376675;
+-------+-----------+---------+----------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
|SI_KEY |PRODUCT_KEY|SERIAL_NO|MODEL_NO  |PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |PURCHASE_AMT|CURRENCY_CD|LAST_UPDATED_LEADS_DT|REGISTRATION_DT    |QUALITY_SCORE|END_DT|DIM_STATUS_CD|LATEST_COVERAGE_EXP_DT|LATEST_COVERAGE_TYPE|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-------+-----------+---------+----------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
|3376675|31074      |NULL     |SHPM65Z55N|12144          |2024-04-01 00:00:00.000000|NULL        |USD        |NULL                 |2023-04-26 11:26:46|0            |NULL  |A            |2024-04-01            |1                   |667929          |668163          |668163        |
+-------+-----------+---------+----------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+

select * from BOSH.CONTRACT_ORDER_TBL where ORDER_KEY = 346531;


select *  from bosh.raw_inwarranty_leads_tbl r join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
    where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and CREATION_DT >= date '2022-01-01';

select *
  from (
    SELECT ADDRESS, FIRST_NAME,
           COUNT(distinct coalesce(FIRST_NAME, 'xyz') || ADDRESS || MODEL_NUMBER || PURCHASE_DATE) as leads,
           COUNT(distinct case when ADDRESS not like '%#%' then coalesce(FIRST_NAME, 'xyz') || ADDRESS || MODEL_NUMBER || PURCHASE_DATE end) as leads_without_apt,
           min(CREATION_DT), max(CREATION_DT)
     from bosh.raw_inwarranty_leads_tbl r join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
    where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and CREATION_DT >= date '2022-01-01'
--     GROUP BY FIRST_NAME, ADDRESS
--     Order by ADDRESS, FIRST_NAME
    );

select  r.ADDRESS,pa.ADDRESS_LINE1_TX,
        Substr (pa.ADDRESS_LINE2_TX, 1,instr(pa.ADDRESS_LINE2_TX,' ') - 1) AS SUIT,
        pa.ADDRESS_LINE2_TX,r.FIRST_NAME,r.LAST_NAME,pa.FIRST_NM,pa.LAST_NM,pa.FIRM_NM
from P_ADDRESS_OUTPUT_TBL_ARCH pa join bosh.raw_inwarranty_leads_tbl r
        on pa.UNIQUE_SEQ_NO = r.UNIQUE_SEQ_NO
        join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
         where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and ADDRESS not like '%#%' and ADDRESS not like '% UNIT%' and ADDRESS not like '% APT%'
    and ADDRESS not like '% LOT%' and ADDRESS not like '% SUITE%' and ADDRESS not like '% STE%'
    --and CREATION_DT >= date '2022-01-01'
    and pa.ADDRESS_LINE2_TX is not null
order by ADDRESS;
+----------------------------------+-----------------------+----+----------------+
|ADDRESS                           |ADDRESS_LINE1_TX       |SUIT|ADDRESS_LINE2_TX|
+----------------------------------+-----------------------+----+----------------+
|11306 VILLA BELLAGIO DR           |6005 STATE BRIDGE RD   |APT |APT 1138        |
|133 SEAPORT BOULEVARD T2-803      |133 SEAPORT BLVD       |NULL|T2-803          |
|1402 MISSOURI ST A                |1402 MISSOURI ST       |NULL|A               |
|2000 SOUTH OCEAN DRIVE 26TH FLOOR |2000 S OCEAN DR        |26TH|26TH FL         |
|211 N HARBOR DR                   |12725 VININGS CREEK DR |APT |APT 725         |
|211 N HARBOR DR 2002              |211 N HARBOR DR        |APT |APT 2002        |
|211 N HARBOR DR 2803              |211 N HARBOR DR        |APT |APT 2803        |
|211 N HARBOR DR 2803              |211 N HARBOR DR        |APT |APT 2803        |
|211 N HARBOR DR 404               |211 N HARBOR DR        |APT |APT 404         |
|211 N HARBOR DR 809               |211 N HARBOR DR        |APT |APT 809         |
|211 N HARBOR DR 809               |211 N HARBOR DR        |APT |APT 809         |
|2417 ALBEMARLE ROAD 12A           |2417 ALBEMARLE RD      |APT |APT 12A         |
|30 GREENWELL LANE 3187H6          |30 GREENWELL LN        |NULL|3187H6          |
|33 KIRKLAND ST 5TH FLOOR          |33 KIRKLAND ST         |5TH |5TH FL          |
|3301 ARAPAHOE AVENUE, E418        |3301 ARAPAHOE AVE      |NULL|E418            |
|3939 WISCONSIN AVE NW E1-402      |3939 WISCONSIN AVE NW  |NULL|E1-402          |
|3939 WISCONSIN AVENUE NORTHWEST B2|167 E 61ST ST          |APT |APT 11A         |
|3939 WISCONSIN AVENUE NORTHWEST B2|3939 WISCONSIN AVE NW  |NULL|B2              |
|3939 WISCONSIN AVENUE NORTHWEST B2|3939 WISCONSIN AVE NW  |NULL|B2              |
|4 WASHINGTON SQ VILLAGE , 5R      |4 WASHINGTON SQUARE VLG|APT |APT 5R          |
|430 EAST 80TH ST 6TH FLOOR        |430 E 80TH ST          |6TH |6TH FL          |
|50 CLINTON ST 2A                  |50 CLINTON ST          |APT |APT 2A          |
|50 CLINTON ST 2A                  |50 CLINTON ST          |APT |APT 2A          |
|50 CLINTON ST 2A                  |50 CLINTON ST          |APT |APT 2A          |
|500 WAVERLY AVE PH1               |500 WAVERLY AVE        |PH  |PH 1            |
|507 W 28TH ST PH 3D               |507 W 28TH ST          |PH  |PH 3D           |
|527 WEST 27TH STREET 10A          |527 W 27TH ST          |NULL|10A             |
|527 WEST 27TH STREET 10A          |527 W 27TH ST          |NULL|10A             |
|555 WEST 22ND STREET 6FE          |555 W 22ND ST          |NULL|6FE             |
|645 WEST 59TH STREET 36A          |645 W 59TH ST          |NULL|36A             |
|645 WEST 59TH STREET 36A          |645 W 59TH ST          |NULL|36A             |
|645 WEST 59TH STREET 36B          |645 W 59TH ST          |NULL|36B             |
|645 WEST 59TH STREET 36B          |645 W 59TH ST          |NULL|36B             |
|645 WEST 59TH STREET 36B          |645 W 59TH ST          |NULL|36B             |
|6560-1 MONTANA AVE                |6560 MONTANA AVE       |NULL|1               |
|67 FRANKLIN ST 4C                 |67 FRANKLIN ST         |APT |APT 4C          |
|67 FRANKLIN ST 4C                 |67 FRANKLIN ST         |APT |APT 4C          |
|685 1ST AVENUE 25G                |685 1ST AVE            |APT |APT 25G         |
|685 1ST AVENUE 25G                |685 1ST AVE            |APT |APT 25G         |
|685 1ST AVENUE 30L                |685 1ST AVE            |APT |APT 30L         |
|685 1ST AVENUE 40F                |685 1ST AVE            |APT |APT 40F         |
|7 SUNSET DR                       |12109 NE 171ST PL      |APT |APT B103        |
|7407-4 E MINNEZONA AVE            |7407 E MINNEZONA AVE   |NULL|4               |
|8 SPRUCE STREET 66A               |8 SPRUCE ST            |APT |APT 66A         |
|91 LEONARD STREET 9F              |91 LEONARD ST          |APT |APT 9F          |
|99 HUDSON ST PH02 FLOOR 74        |99 HUDSON ST           |FL  |FL 74           |
+----------------------------------+-----------------------+----+----------------+



select  r.ADDRESS,pa.ADDRESS_LINE1_TX,
        Substr (pa.ADDRESS_LINE2_TX, 1,instr(pa.ADDRESS_LINE2_TX,' ') - 1) AS SUIT,
        pa.ADDRESS_LINE2_TX,r.FIRST_NAME,r.LAST_NAME,pa.FIRST_NM,pa.LAST_NM,pa.FIRM_NM
from P_ADDRESS_OUTPUT_TBL_ARCH pa join bosh.raw_inwarranty_leads_tbl r
        on pa.UNIQUE_SEQ_NO = r.UNIQUE_SEQ_NO
        join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
         where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and ADDRESS not like '%#%'
    and CREATION_DT >= date '2022-01-01'
    and pa.ADDRESS_LINE2_TX is not null;

+---------------------------------------+-----------------------+----+----------------+-------------------------------------+---------+----------+-------------+--------------------------+
|ADDRESS                                |ADDRESS_LINE1_TX       |SUIT|ADDRESS_LINE2_TX|FIRST_NAME                           |LAST_NAME|FIRST_NM  |LAST_NM      |FIRM_NM                   |
+---------------------------------------+-----------------------+----+----------------+-------------------------------------+---------+----------+-------------+--------------------------+
|301 WEST AVENUE UNIT 3805              |301 WEST AVE           |APT |APT 3805        |JENNY TEAGUE BSP (BLDG CONTACT)      |NULL     |JENNY     |TEAGUE       |NULL                      |
|44 EAST AVE UNIT 1301                  |44 EAST AVE            |UNIT|UNIT 1301       |ANDRES BARBOZA BSP (BLDG CONTACT)    |NULL     |ANDRES    |BARBOZA      |NULL                      |
|515 WEST 18TH STREET UNIT 1502         |515 W 18TH ST          |APT |APT 1502        |KARINA TAVERNAS BSP (BLDG CONTACT)   |NULL     |KARINA    |TAVERNAS     |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 617 |133 SEAPORT BLVD       |UNIT|UNIT 617        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 1102|133 SEAPORT BLVD       |UNIT|UNIT 1102       |ROBERT FORCE FACILITY MANAGER        |NULL     |ROBERT    |FORCE        |NULL                      |
|2000 SOUTH OCEAN DRIVE 26TH FLOOR      |2000 S OCEAN DR        |26TH|26TH FL         |CHARLES BRADFORD (BLDG CONTACT)      |NULL     |CHARLES   |BRADFORD     |NULL                      |
|211 N HARBOR DR 2803                   |211 N HARBOR DR        |APT |APT 2803        |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|7 SUNSET DR                            |12109 NE 171ST PL      |APT |APT B103        |KEITH ARMSTRONG BUILDING &           |NULL     |MICHAEL   |GRIMES       |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 817 |133 SEAPORT BLVD       |UNIT|UNIT 817        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD TOWER 2 UNIT 720 |133 SEAPORT BLVD       |UNIT|UNIT 720        |ROBERT FORCE (BLDG CONTACT           |NULL     |ROBERT    |FORCE        |NULL                      |
|211 N HARBOR DR 809                    |211 N HARBOR DR        |APT |APT 809         |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|133 SEAPORT BOULEVARD TOWER 1 UNIT 1102|133 SEAPORT BLVD       |UNIT|UNIT 1102       |ROBERT FORCE FACILITY MANAGER        |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD T2 UNIT 712      |133 SEAPORT BLVD       |UNIT|UNIT 712        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD TOWER 2 UNIT 720 |133 SEAPORT BLVD       |UNIT|UNIT 720        |ROBERT FORCE (BLDG CONTACT           |NULL     |ROBERT    |FORCE        |NULL                      |
|6560-1 MONTANA AVE                     |6560 MONTANA AVE       |NULL|1               |BUILDERS SOURCE                      |NULL     |NULL      |NULL         |BUILDERS SOURCE           |
|211 N HARBOR DR 809                    |211 N HARBOR DR        |APT |APT 809         |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|211 N HARBOR DR 404                    |211 N HARBOR DR        |APT |APT 404         |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|33. MARIGOLD AVE UNIT 9                |33. MARIGOLD AVE UNIT 9|UNIT|UNIT 9          |BUILDER WOODY COUCH                  |NULL     |NULL      |NULL         |BUILDER WOODY COUCH       |
|1059 3RD AVENUE UNIT 20A               |1059 3RD AVE           |APT |APT 20A         |JOHN CORBETT (BUILDER)               |NULL     |JOHN      |CORBETT      |NULL                      |
|1059 3RD AVENUE UNIT 17B               |1059 3RD AVE           |APT |APT 17B         |JOHN CORBETT (BUILDER)               |NULL     |JOHN      |CORBETT      |NULL                      |
|1059 3RD AVENUE UNIT 11A               |1059 3RD AVE           |APT |APT 11A         |JOHN CORBETT (BUILDER)               |NULL     |JOHN      |CORBETT      |NULL                      |
|645 WEST 59TH STREET 36A               |645 W 59TH ST          |NULL|36A             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|645 WEST 59TH STREET 36A               |645 W 59TH ST          |NULL|36A             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|645 WEST 59TH STREET 36B               |645 W 59TH ST          |NULL|36B             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|685 1ST AVENUE 40F                     |685 1ST AVE            |APT |APT 40F         |WELLINGTON CABRERA(BLDG CONTACT)     |NULL     |WELLINGTON|CABRERA      |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 718 |133 SEAPORT BLVD       |UNIT|UNIT 718        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|645 WEST 59TH STREET 36B               |645 W 59TH ST          |NULL|36B             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 718 |133 SEAPORT BLVD       |UNIT|UNIT 718        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|91 LEONARD STREET 9F                   |91 LEONARD ST          |APT |APT 9F          |MARTIN PALJUSTEVIC (BUILDING CONTACT)|NULL     |MARTIN    |PALJUSTEVIC  |NULL                      |
|555 WEST 22ND STREET 6FE               |555 W 22ND ST          |NULL|6FE             |ROGER BLDG CONTACT                   |NULL     |NULL      |NULL         |ROGER BLDG. CONTACT       |
|3939 WISCONSIN AVENUE NORTHWEST B2     |3939 WISCONSIN AVE NW  |NULL|B2              |MATT BLDG CONTACT                    |NULL     |NULL      |NULL         |MATT BLDG. CONTACT        |
|685 1ST AVENUE 30L                     |685 1ST AVE            |APT |APT 30L         |RYAN PALMER BUILDING CONTACT         |NULL     |RYAN      |PALMER       |NULL                      |
|645 WEST 59TH STREET 36B               |645 W 59TH ST          |NULL|36B             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|3939 WISCONSIN AVE NW E1-402           |3939 WISCONSIN AVE NW  |NULL|E1-402          |MATT (BLDG CONTACT)                  |NULL     |NULL      |NULL         |MATT (BLDG. CONTACT)      |
|3939 WISCONSIN AVENUE NORTHWEST B2     |167 E 61ST ST          |APT |APT 11A         |MATT BLDG CONTACT                    |NULL     |WAYNE     |TAUB         |NULL                      |
|3939 WISCONSIN AVENUE NORTHWEST B2     |3939 WISCONSIN AVE NW  |NULL|B2              |MATT BLDG CONTACT                    |NULL     |NULL      |NULL         |MATT BLDG. CONTACT        |
|211 N HARBOR DR 2803                   |211 N HARBOR DR        |APT |APT 2803        |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|7407-4 E MINNEZONA AVE                 |7407 E MINNEZONA AVE   |NULL|4               |HAWK BUILDERS                        |NULL     |NULL      |NULL         |HAWK BUILDERS             |
|527 WEST 27TH STREET 10A               |527 W 27TH ST          |NULL|10A             |EDWARD LYONS (BLDG CONTACT)          |NULL     |EDWARD    |LYONS        |NULL                      |
|685 1ST AVENUE 25G                     |685 1ST AVE            |APT |APT 25G         |WELLINGTON CABRERA(BLDG CONTACT)     |NULL     |WELLINGTON|CABRERA      |NULL                      |
|133 SEAPORT BOULEVARD T2 UNIT 712      |133 SEAPORT BLVD       |UNIT|UNIT 712        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|300 SOUTH UNION STREET BLDG 2 UNIT 208 |300 S UNION ST         |BLDG|BLDG 2          |ADAM THORMAHLEN (BUILDING CONTACT)   |NULL     |ADAM      |THORMAHLEN   |NULL                      |
|211 N HARBOR DR                        |12725 VININGS CREEK DR |APT |APT 725         |LAKE SHORE EAST BUILDING J           |NULL     |STEPHEN   |VANNOY       |NULL                      |
|527 WEST 27TH STREET 10A               |527 W 27TH ST          |NULL|10A             |EDWARD LYONS (BLDG CONTACT)          |NULL     |EDWARD    |LYONS        |NULL                      |
|99 HUDSON ST PH02 FLOOR 74             |99 HUDSON ST           |FL  |FL 74           |JOSEPH SUSCOVICH (BUILDING CONTACT)  |NULL     |JOSEPH    |SUSCOVICH    |NULL                      |
|211 N HARBOR DR 2002                   |211 N HARBOR DR        |APT |APT 2002        |O BUILDING J                         |NULL     |NULL      |NULL         |O BUILDING J              |
|33. MARIGOLD AVE UNIT 9                |33. MARIGOLD AVE UNIT 9|UNIT|UNIT 9          |BUILDER WOODY COUCH                  |NULL     |NULL      |NULL         |BUILDER WOODY COUCH       |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 802 |133 SEAPORT BLVD       |UNIT|UNIT 802        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 802 |133 SEAPORT BLVD       |UNIT|UNIT 802        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|100 BARROW STREET UNIT 4A              |100 BARROW ST          |APT |APT 4A          |MIKE BLDG MANAGER                    |NULL     |NULL      |NULL         |NULL                      |
|685 1ST AVENUE 25G                     |685 1ST AVE            |APT |APT 25G         |WELLINGTON CABRERA(BLDG CONTACT)     |NULL     |WELLINGTON|CABRERA      |NULL                      |
|210 BIRDSEYE LOT 77                    |210 BIRDSEYE           |LOT |LOT 77          |CALPAC BUILDER SCOTT                 |NULL     |NULL      |NULL         |NULL                      |
|133 SEAPORT BOULEVARD T2-803           |133 SEAPORT BLVD       |NULL|T2-803          |ROBERT FORCE BUILDING CONTACT        |NULL     |ROBERT    |FORCE        |NULL                      |
+---------------------------------------+-----------------------+----+----------------+-------------------------------------+---------+----------+-------------+--------------------------+


+---------------------------------------+----------------------+----+----------------+---------------------------------------+
|ADDRESS                                |ADDRESS_LINE1_TX      |SUIT|ADDRESS_LINE2_TX|FIRST_NAME                             |
+---------------------------------------+----------------------+----+----------------+---------------------------------------+
|50 BRIDGE PARK DRIVE #18E              |50 BRIDGE PARK DR     |APT |APT 18E         |IBRAN (RESIDENT MANAGER)               |
|131 BEVERLY STREET #11H                |131 BEVERLY ST        |STE |STE 11H         |DUPLICATE STEVE HEATH (BLDG CONTACT)   |
|301 WEST AVENUE UNIT 3805              |301 WEST AVE          |APT |APT 3805        |JENNY TEAGUE BSP (BLDG CONTACT)        |
|301 ALTARA AVENUE #816                 |301 ALTARA AVE        |APT |APT 816         |STEPHANIE HILZEN (RESIDENT MANAGER)    |
|18501 COLLINS AVENUE #1001             |18501 COLLINS AVE     |APT |APT 1001        |ROBERT MADERA (BLDG CONTACT)           |
|44 EAST AVE UNIT 1301                  |44 EAST AVE           |UNIT|UNIT 1301       |ANDRES BARBOZA BSP (BLDG CONTACT)      |
|100 SHAWMUT AVENUE #509                |100 SHAWMUT AVE       |UNIT|UNIT 509        |EMILY ANTONELLI BSP (BLDG CONTACT)     |
|11 HOYT STREET #10F                    |11 HOYT ST            |APT |APT 10F         |IZZY BUILDING CONTACT                  |
|3107 PEACHTREE RD N# #1202             |3107 PEACHTREE RD NE  |UNIT|UNIT 1202       |SCOTT SMITH (BLDG CONTACT)             |
|400 W 61ST STREET #1932                |400 W 61ST ST         |APT |APT 1932        |DARREN MANICKCHAND BSP BUILDING CONTACT|
|320 ADOLPHUS AVENUE #613               |320 ADOLPHUS AVE      |APT |APT 613         |JACKIE NOVOA (BLDG CONTACT)            |
|8310 SOUTHWESTERN BOULEVARD #BLDG G    |8310 SOUTHWESTERN BLVD|BLDG|BLDG G          |MIGUEL CASTRO (BLDG CONTACT)           |
|6803 CAMERON DRIVE NORTHWEST #115      |6803 CAMERON DR NW    |APT |APT 115         |JOE ALFONSO BSP (BLDG CONTACT)         |
|11 HOYT STREET #14H                    |11 HOYT ST            |APT |APT 14H         |IZZY GJONBALAJ - BLDG CONTACT          |
|11 HOYT STREET #5G                     |11 HOYT ST            |APT |APT 5G          |IZZY GJONBALAJ - BLDG CONTACT          |
|11 HOYT STREET #21K                    |11 HOYT ST            |APT |APT 21K         |IZZY GJONBALAJ - BLDG CONTACT          |
|18501 COLLINS AVENUE #702              |18501 COLLINS AVE     |APT |APT 702         |ROD CARRILLO BSP BUILDING CONTACT      |
|18501 COLLINS AVENUE #702              |18501 COLLINS AVE     |APT |APT 702         |ROD CARRILLO BSP BUILDING CONTACT      |
|1 BOERUM PLACE #7F                     |1 BOERUM PL           |APT |APT 7F          |DAVID BUILDING SUPER                   |
|1788 NORTH PIERCE STREET WEST TWR #2014|1788 N PIERCE ST      |APT |APT 2014        |LIANNE URODA - BLDG CONTACT            |
|1788 NORTH PIERCE STREET WEST TWR #2201|1788 N PIERCE ST      |APT |APT 2201        |LIANNE URODA - BLDG CONTACT            |
|212 5TH AVENUE #12B                    |212 5TH AVE           |APT |APT 12B         |CHRIS DOWER (BLDG CONTACT)             |
|685 1ST AVENUE #11G                    |685 1ST AVE           |APT |APT 11G         |WELLINGTON CABRERA (BLDG CONTACT)      |
|2510 6TH AVENUE #610                   |2510 6TH AVE          |UNIT|UNIT 610        |RACHEL JOHANSON (BLDG CONTACT)         |
|121 STEWART STREET FL 13 UNIT #1203    |121 STEWART ST        |FL  |FL 13           |DENISE BLDG CONTACT                    |
|1788 NORTH PIERCE STREET #2112         |1788 N PIERCE ST      |APT |APT 2112        |LIANNE URODA BSP (BLDG CONTACT)        |
|180 EAST 88TH STREET #14A              |180 E 88TH ST         |APT |APT 14A         |NORI POCESTA(BLDG CONTACT)             |
|180 EAST 88TH STREET #14A              |180 E 88TH ST         |APT |APT 14A         |NORI POCESTA(BLDG CONTACT)             |
|131-01 40TH ROAD #17Y                  |13101 40TH RD         |APT |APT 17Y         |LARRY LIN BSP (BLDG CONTACT)           |
|150 EAST 23RD STREET #10B              |150 E 23RD ST         |APT |APT 10B         |ENVER BUILDING MANAGER                 |
+---------------------------------------+----------------------+----+----------------+---------------------------------------+


select  COUNT(*)
from P_ADDRESS_OUTPUT_TBL_ARCH pa join bosh.raw_inwarranty_leads_tbl r
        on pa.UNIQUE_SEQ_NO = r.UNIQUE_SEQ_NO
        join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
         where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and ADDRESS like '%#%'
    and CREATION_DT >= date '2022-01-01'
    and pa.ADDRESS_LINE2_TX is not null;

select SUIT,COUNT(SUIT) from (
select  Substr (pa.ADDRESS_LINE2_TX, 1,instr(pa.ADDRESS_LINE2_TX,' ') - 1) AS SUIT
from P_ADDRESS_OUTPUT_TBL_ARCH pa join bosh.raw_inwarranty_leads_tbl r
        on pa.UNIQUE_SEQ_NO = r.UNIQUE_SEQ_NO
        join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
         where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and CREATION_DT >= date '2022-01-01'
    and pa.ADDRESS_LINE2_TX is not null)
Group by SUIT
;
+----+-----------+
|SUIT|COUNT(SUIT)|
+----+-----------+
|APT |1731       |
|UNIT|565        |
|STE |30         |
|PH  |22         |
|FL  |12         |
|BLDG|11         |
|17TH|4          |
|5TH |2          |
|14TH|2          |
|26TH|1          |
|21ST|1          |
|LOT |1          |
|NULL|0          |
+----+-----------+




+-----------------------------------+----------------------+----------------+---------------------------------------+---------+---------+-----------+---------------------+
|ADDRESS                            |ADDRESS_LINE1_TX      |ADDRESS_LINE2_TX|FIRST_NAME                             |LAST_NAME|FIRST_NM |LAST_NM    |FIRM_NM              |
+-----------------------------------+----------------------+----------------+---------------------------------------+---------+---------+-----------+---------------------+
|50 BRIDGE PARK DRIVE #18E          |50 BRIDGE PARK DR     |APT 18E         |IBRAN (RESIDENT MANAGER)               |NULL     |NULL     |IBRAN      |NULL                 |
|131 BEVERLY STREET #11H            |131 BEVERLY ST        |STE 11H         |DUPLICATE STEVE HEATH (BLDG CONTACT)   |NULL     |STEVE    |HEATH      |NULL                 |
|301 ALTARA AVENUE #816             |301 ALTARA AVE        |APT 816         |STEPHANIE HILZEN (RESIDENT MANAGER)    |NULL     |STEPHANIE|HILZEN     |NULL                 |
|18501 COLLINS AVENUE #1001         |18501 COLLINS AVE     |APT 1001        |ROBERT MADERA (BLDG CONTACT)           |NULL     |ROBERT   |MADERA     |NULL                 |
|44 EAST AVE UNIT 1301              |44 EAST AVE           |UNIT 1301       |ANDRES BARBOZA BSP (BLDG CONTACT)      |NULL     |ANDRES   |BARBOZA    |NULL                 |
|100 SHAWMUT AVENUE #509            |100 SHAWMUT AVE       |UNIT 509        |EMILY ANTONELLI BSP (BLDG CONTACT)     |NULL     |EMILY    |ANTONELLI  |NULL                 |
|11 HOYT STREET #10F                |11 HOYT ST            |APT 10F         |IZZY BUILDING CONTACT                  |NULL     |NULL     |NULL       |IZZY BUILDING CONTACT|
|3107 PEACHTREE RD N# #1202         |3107 PEACHTREE RD NE  |UNIT 1202       |SCOTT SMITH (BLDG CONTACT)             |NULL     |SCOTT    |SMITH      |NULL                 |
|400 W 61ST STREET #1932            |400 W 61ST ST         |APT 1932        |DARREN MANICKCHAND BSP BUILDING CONTACT|NULL     |DARREN   |MANICKCHAND|NULL                 |
|320 ADOLPHUS AVENUE #613           |320 ADOLPHUS AVE      |APT 613         |JACKIE NOVOA (BLDG CONTACT)            |NULL     |JACKIE   |NOVOA      |NULL                 |
|8310 SOUTHWESTERN BOULEVARD #BLDG G|8310 SOUTHWESTERN BLVD|BLDG G          |MIGUEL CASTRO (BLDG CONTACT)           |NULL     |MIGUEL   |CASTRO     |NULL                 |
|6803 CAMERON DRIVE NORTHWEST #115  |6803 CAMERON DR NW    |APT 115         |JOE ALFONSO BSP (BLDG CONTACT)         |NULL     |JOE      |ALFONSO    |NULL                 |
|11 HOYT STREET #14H                |11 HOYT ST            |APT 14H         |IZZY GJONBALAJ - BLDG CONTACT          |NULL     |IZZY     |GJONBALAJ  |NULL                 |
|11 HOYT STREET #5G                 |11 HOYT ST            |APT 5G          |IZZY GJONBALAJ - BLDG CONTACT          |NULL     |IZZY     |GJONBALAJ  |NULL                 |
+-----------------------------------+----------------------+----------------+---------------------------------------+---------+---------+-----------+---------------------+


select * from si_output_tbl;
select * from common_load_tbl;

select  r.ADDRESS,pa.ADDRESS_LINE1_TX,
        Substr (pa.ADDRESS_LINE2_TX, 1,instr(pa.ADDRESS_LINE2_TX,' ') - 1) AS SUIT,
        pa.ADDRESS_LINE2_TX,r.FIRST_NAME,r.LAST_NAME,pa.FIRST_NM,pa.LAST_NM,pa.FIRM_NM
    from P_ADDRESS_OUTPUT_TBL_ARCH pa join bosh.raw_inwarranty_leads_tbl r
        on pa.UNIQUE_SEQ_NO = r.UNIQUE_SEQ_NO
        join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
        where
        (1=2
        or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null
    and MODEL_NUMBER is not null
    and PURCHASE_DATE is not null
    and ADDRESS not like '%#%'
    and ADDRESS not like '% UNIT%'
    and ADDRESS not like '% APT%'
    and ADDRESS not like '% LOT%'
    and ADDRESS not like '% SUITE%'
    and ADDRESS not like '% FLOOR'
    and ADDRESS not like '% STE%'    --and CREATION_DT >= date '2022-01-01'
    and pa.ADDRESS_LINE2_TX is not null
    order by ADDRESS;

  -- If purchase_dt is NULL then error out the record
      -- Such records will be suppressed from loading into commo_load_hold_tbl
      --Added TRIM to the columns in WHERE clause on 4/23/2019
      UPDATE RAW_INWARRANTY_LEADS_TBL
      SET    PURCHASE_DATE = NULL,
             ERROR_DESC = 'Purchase_dt IS NULL'
      WHERE  CHK_DATE(PURCHASE_DATE) IS NULL;

    select * from bosh.RAW_INWARRANTY_LEADS_TBL
    Where
     (1=2
        or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
        and ADDRESS is not null
        and ERROR_DESC is null
        and ADDRESS not like '%#%'
        and ADDRESS not like '% UNIT%'
        and ADDRESS not like '% APT%'
        and ADDRESS not like '% LOT%'
        and ADDRESS not like '% SUITE%'
        and ADDRESS not like '% FLOOR'
        and ADDRESS not like '% STE%'
        Order by ADDRESS;


    Update bosh.RAW_INWARRANTY_LEADS_TBL
        SET ERROR_DESC = 'Suppress builder leads -1'
    Where
       (1=2
        or FIRST_NAME like '%BUILDER%' or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%' or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%' or FIRST_NAME like '%MANAGER%'
        )
        and ADDRESS is not null and ERROR_DESC is null
        and ADDRESS not like '%#%'
        and ADDRESS not like '% UNIT%'and ADDRESS not like '% APT%'
        and ADDRESS not like '% LOT%'and ADDRESS not like '% SUITE%'
        and ADDRESS not like '% FLOOR' and ADDRESS not like '% STE%'
       ;


    -- SET ERROR_DESC = 'Suppress builder leads -2'
    --[new]
      (or FIRST_NAME like '%BUILDER%' or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%' or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%' or FIRST_NAME like '%MANAGER%')
     and ERROR_DESC is null
     --Address count at least more than 2


    select * from bosh.RAW_INWARRANTY_LEADS_TBL
    where (1=2
                            or   FIRST_NAME like '%BUILDER%'
                            or FIRST_NAME like '%BLDG%'
                            or FIRST_NAME like '%BUILDING%'
                            or FIRST_NAME like '%CONTACT%'
                            or FIRST_NAME like '%SUPER%'
                            or FIRST_NAME like '%MANAGER%'
                            )
        AND ERROR_DESC is null
        AND (ADDRESS,FILE_NM) in (
                select ADDRESS,FILE_NM from bosh.RAW_INWARRANTY_LEADS_TBL
                    where (1=2
                            or   FIRST_NAME like '%BUILDER%'
                            or FIRST_NAME like '%BLDG%'
                            or FIRST_NAME like '%BUILDING%'
                            or FIRST_NAME like '%CONTACT%'
                            or FIRST_NAME like '%SUPER%'
                            or FIRST_NAME like '%MANAGER%'
                            )
                        AND ADDRESS not in (
                                select ADDRESS from bosh.RAW_INWARRANTY_LEADS_TBL
                                Where  (1=2    or   FIRST_NAME like '%BUILDER%'
                                    or FIRST_NAME like '%BLDG%'  or FIRST_NAME like '%BUILDING%'
                                    or FIRST_NAME like '%CONTACT%'   or FIRST_NAME like '%SUPER%'
                                    or FIRST_NAME like '%MANAGER%'    )
                                    and ADDRESS is not null and ERROR_DESC is null
                                    and ADDRESS not like '%#%' and ADDRESS not like '% UNIT%'
                                    and ADDRESS not like '% APT%' and ADDRESS not like '% LOT%'
                                    and ADDRESS not like '% SUITE%'and ADDRESS not like '% FLOOR'
                                    and ADDRESS not like '% STE%')
                    Group by ADDRESS,FILE_NM
                    Having count(ADDRESS)>2
                )
    order by ADDRESS
    ;