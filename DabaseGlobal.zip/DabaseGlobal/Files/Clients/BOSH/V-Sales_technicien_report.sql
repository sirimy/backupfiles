
Select offer_start_utc_ts,User_id "User Id",COUNT(offer_id) "Offers",COUNT( distinct order_id) "Sales",COUNT(distinct serialized_item_id) "Sales Items",SUM(Retail_amnt) "Retail Amount"
from  v_sales_by_technician
where 1 = 1
   and
    (
        (offer_start_utc_ts::date >= current_date::date - interval '2 day' and offer_start_utc_ts::date < current_date::date  and '2' <> '30' )
        Or
       (
          offer_start_utc_ts::date >= date_trunc('month', (date_trunc('month', current_date) - interval '1 day'))::date
              and
           offer_start_utc_ts::date <= (date_trunc('month', current_date) - interval '1 day')::date
              and '2' = '30'
       )
    )
 GROUP BY User_id,offer_start_utc_ts;


Select '2025-01-29 08:00:04.000000'::date - interval '1 day',User_id "User Id",COUNT(offer_id) "Offers",COUNT( distinct order_id) "Sales",COUNT(distinct serialized_item_id) "Sales Items",SUM(Retail_amnt) "Retail Amount"
from  v_sales_by_technician where 1 = 1
and
(
    ('2025-01-28 00:00:00.000000'::date >= '2025-01-29 08:00:04.000000'::date - interval '1 day' and '2025-01-28 00:00:00.000000'::date < '2025-01-29 08:00:04.000000'::date  and '1' <> '30' )
--         Or
--     (           '2025-01-28 00:00:00.000000'::date >= date_trunc('month', (date_trunc('month', '2025-01-29 08:00:04.000000') - interval '1 day'))::date
--                     and
--                 '2025-01-28 00:00:00.000000'::date <= (date_trunc('month', '2025-01-29 08:00:04.000000') - interval '1 day')::date               and '1' = '30'        )
    )
and offer_start_utc_ts = '2025-01-28 00:00:00.000000'
GROUP BY User_id,'2025-01-29 08:00:04.000000'::date - interval '1 day'
;


select * from v_sales_by_technician order by offer_start_utc_ts desc;

--2025-01-29 08:00:04,498 -                    log.py:  109 - INFO -  Select User_id "User Id",COUNT(offer_id) "Offers",COUNT( distinct order_id) "Sales",COUNT(distinct serialized_item_id) "Sales Items",SUM(Retail_amnt) "Retail Amount" from  v_sales_by_technician where 1 = 1    and     (         (offer_start_utc_ts::date >= current_date::date - interval '1 day' and offer_start_utc_ts::date < current_date::date  and '1' <> '30' )         Or        (           offer_start_utc_ts::date >= date_trunc('month', (date_trunc('month', current_date) - interval '1 day'))::date               and            offer_start_utc_ts::date <= (date_trunc('month', current_date) - interval '1 day')::date               and '1' = '30'        )     )  GROUP BY User_id;



Select User_id "User Id",COUNT(offer_id) "Offers",COUNT( distinct order_id) "Sales",COUNT(distinct serialized_item_id) "Sales Items",SUM(Retail_amnt) "Retail Amount"
from  v_sales_by_technician where 1 = 1    and
(
  (offer_start_utc_ts::date >= current_date::date - interval '1 day' and offer_start_utc_ts::date < current_date::date  and '1' <> '30' )
      Or
  (
      offer_start_utc_ts::date >= date_trunc('month', (date_trunc('month', current_date) - interval '1 day'))::date
          and
      offer_start_utc_ts::date <= (date_trunc('month', current_date) - interval '1 day')::date
          and '1' = '30'
      )
  )  GROUP BY User_id;

SELECT CURRENT_DATE,current_date::date - interval '1 day';


SELECT t.user_id,
    t.offer_id,
    t.order_id,
    t.serialized_item_id,
    t.retail_amnt,
    t.offer_start_utc_ts,t.rno
   FROM ( SELECT bolt.created_by AS user_id,
            ot.offer_id,
            oit.order_id,
            bolt.serialized_item_id,
            oit.price_amt AS retail_amnt,
            ot.offer_start_utc_ts,
            row_number() OVER (PARTITION BY bolt.serialized_item_id, bolt.created_by ORDER BY bolt.log_date DESC) AS rno
           FROM bundle_offer_log_tbl bolt
             JOIN offer_tbl ot ON ot.new_offer_id::text = bolt.offer_id::text
             LEFT JOIN order_item_tbl oit ON oit.offer_id = ot.offer_id) t
  WHERE t.rno = 1
order by t.offer_start_utc_ts desc;
;


SELECT bolt.job_id,bolt.created_by AS user_id,
            ot.offer_id,
            oit.order_id,
            bolt.serialized_item_id,
            oit.price_amt AS retail_amnt,
            ot.offer_start_utc_ts,
            row_number() OVER (PARTITION BY bolt.serialized_item_id, bolt.created_by ORDER BY bolt.log_date DESC) AS rno
           FROM bundle_offer_log_tbl bolt
             JOIN offer_tbl ot ON ot.new_offer_id::text = bolt.offer_id::text
             LEFT JOIN order_item_tbl oit ON oit.offer_id = ot.offer_id
order by ot.offer_start_utc_ts desc
;

SELECT bolt.log_date,bolt.job_id,bolt.created_by AS user_id,
            ot.offer_id,
            oit.order_id,
            bolt.serialized_item_id,
            oit.price_amt AS retail_amnt,
            ot.offer_start_utc_ts,
            row_number() OVER (PARTITION BY bolt.serialized_item_id, bolt.created_by ORDER BY bolt.log_date DESC) AS rno
           FROM bundle_offer_log_tbl bolt
             JOIN offer_tbl ot ON ot.new_offer_id::text = bolt.offer_id::text
             LEFT JOIN order_item_tbl oit ON oit.offer_id = ot.offer_id
order by bolt.log_date desc
;




Select User_id "User Id",COUNT(offer_id) "Offers",COUNT( distinct order_id) "Sales",COUNT(distinct serialized_item_id) "Sales Items",SUM(Retail_amnt) "Retail Amount"
from  v_sales_by_technician
where 1 = 1
   and
    (
        (offer_start_utc_ts::date >= current_date::date - interval 'interval_value day' and offer_start_utc_ts::date < current_date::date  and 'interval_value' <> '30' )
        Or
       (
          offer_start_utc_ts::date >= date_trunc('month', (date_trunc('month', current_date) - interval '1 day'))::date
              and
           offer_start_utc_ts::date <= (date_trunc('month', current_date) - interval '1 day')::date
              and 'interval_value' = '30'
       )
    )
 GROUP BY User_id;
