--510355 to ORDER # 518801

select  *
        --order_no, first_nm, last_nm, order_purchase_dt, PRICE_AMT, CREATED_BY
  from (
select psd.COUNTRY_ISO, si.SI_KEY, ot.order_key as order_no, OIT.ORDER_LINE_KEY, trunc(ot.purchase_dt) as  order_purchase_dt,
       con.contract_key, contract_xid, con.contract_status_key, can.cancel_dt, con.retail_amt, OIT.PRICE_AMT, disc.discount_amt, OIT.Tax_Amt,
       ot.SUB_TOTAL_AMT, ot.TAX_AMT as order_tax_amt, ot.TOTAL_AMT as order_TOTAL_AMT, oit.FLEXPAY_IND,
       --confirmation_key,
       si.purchase_dt_key + date '1989-12-31' as si_purchase_dt
       , si.warranty_expiration_dt, ( trunc(si.warranty_expiration_dt) - ( si.purchase_dt_key + date '1989-12-31')) as warr_days
       , LATEST_COVERAGE_EXP_DT, LATEST_COVERAGE_TYPE, con.CONTRACT_END_DT
       , fee.Premium_Amt, SIF.ADDRESS_KEY, addr.first_nm, addr.last_nm, ADDR.STATE_CD as sif_STATE_CD, ADDR_bit.STATE_CD as bit_STATE_CD, ct.COUNTRY_3BYTE_CD,
         ot.CREATED_BY --,addr.ADDRESS_LINE1_TX, addr.CITY_NM, addr.ZIP_CODE5_TX
       ,pol.policy_product_xid as SKU, pol.description as pol_desc,
        --pex.PRODUCT_CAT_DESC as pex_desc, pex,ct.NAME, pex.CHANNELS ,
        oit.policy_key, pol.term_key
       , ot.visitor_key, vd.CUSTOMER_KEY, oit.offer_key, sales_source_cd
 from
       bosh.order_item_tbl oit
       join bosh.order_tbl ot
       ON ( ot.ORDER_KEY = oit.ORDER_KEY )
       join bosh.serialized_item_dim si ON (si.si_key = oit.serialized_item_key)
       LEFT JOIN bosh.order_item_disc_info_lkp disc
                ON (    disc.order_key = oit.order_key
                    AND disc.order_line_key = oit.order_line_key)
       LEFT join bosh.SHIPPING_INFO_TBL sif
       ON ( SIF.order_key = oit.order_key)
       LEFT join bosh.ADDRESS_DIM  ADDR
       ON ( ADDR.ADDRESS_KEY = SIF.ADDRESS_KEY)
       JOIN bosh.v_policy_fee fee
       ON fee.policy_key = oit.policy_key
--        LEFT JOIN bosh.order_confirmation_tbl  oct
--        ON (    oct.order_key = oit.order_key
--                     AND oct.order_line_key = oit.order_line_key)
       left join bosh.contract_order_tbl cot
       ON ( OIT.ORDER_KEY = COT.ORDER_KEY
            AND OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY)
       left join bosh.contract_lkp clkp on clkp.contract_key = cot.contract_key and clkp.source_system_cd = 0
       left join bosh.contract_dim con
       ON ( con.contract_key = clkp.contract_key)
       left join bosh.contract_cancellation_dim can
       ON ( can.contract_key = con.contract_key)
       left join bosh.policy_tbl pol on pol.policy_key = oit.policy_key
       left join bosh.POLICY_EXT_TBL pex on pex.policy_key = pol.policy_key
       left join bosh.POSTAL_STATE_DIM psd on psd.POSTAL_STATE_CD = ADDR.STATE_CD
       left join bosh.COUNTRY_TBL ct on ct.COUNTRY_KEY = psd.COUNTRY_KEY

       LEFT join bosh.BILLING_INFO_TBL bit
       ON ( bit.order_key = oit.order_key)
       LEFT join bosh.ADDRESS_DIM  ADDR_bit
       ON ( ADDR_bit.ADDRESS_KEY = bit.ADDRESS_KEY)
        left join bosh.POSTAL_STATE_DIM psd2 on psd2.POSTAL_STATE_CD = ADDR_bit.STATE_CD
       left join bosh.COUNTRY_TBL ct2 on ct2.COUNTRY_KEY = psd2.COUNTRY_KEY
       left join bosh.visitor_dim vd on vd.VISITOR_KEY = ot.VISITOR_KEY
 where 1=1
 --  and vd.CUSTOMER_KEY =3531090
--    and oit.POLICY_KEY = 149
--   and con.contract_key IN  (74236359, 74251039)
--   and contract_xid = :contract_xid
--      and CONTRACT_XID in (
-- '40955564', '41009280', '41008647'
--      ) --and pex.DESCRIPTION like '%Upgrade'
--   and oit.purchase_dt >= date '2020-03-01'
--   and trunc(ot.ORDER_CREATED_TS) >= date '2022-12-01'
--    and pex.DESCRIPTION = 'Commercial Generators'
   and ot.order_key IN (
--         :order_key
510355 ,518801

    )
--    and si.serial_no IN (:PID)
--       and si.SERIAL_NO in (
-- -- '3009854847',
-- -- '3009752748',
-- -- '3007207163',
-- -- '3006892379', '3000093285',
--     '3001696982', '3001696982'
-- ,''
--      )
--  and FLEXPAY_IND = 'Y'
--       and si.serial_no IN ( '3000075641')
--           '3004064626', '3004064626', '3001361914', '3000147997', '3004828345'
--    and si.si_key IN ( 4197809 )
--   and sales_source_cd = 'MAIL_IN_CHECK_SALES'
--  and LATEST_COVERAGE_TYPE = 1
--  and CONTRACT_STATUS_KEY = 8
--  and ADDR.STATE_CD IN ('IA', 'KY', 'MN', 'MS', 'SC')
--     and oit.POLICY_KEY in (131, 132) --and ot.ORDER_CREATED_TS <=
  ) t
  where 1=1
--   and trunc(ORDER_CREATED_TS) = date '2024-01-02' and sif_STATE_CD in ('UT', 'CA')
--   and OFFER_KEY < 500000
--   and contract_status_key = 1
--   and LATEST_COVERAGE_EXP_DT = WARRANTY_EXPIRATION_DT
--where warr_days > 100 and warr_days < 365
-- where  order_purchase_dt- si_purchase_dt > 100
--     and contract_xid  --= :Contract_XID
--         in (
-- '40514462',
--             )
-- and policy_key in (161, 167) and state_cd = 'FL'
--   and STATE_CD = 'ON'
--  and COUNTRY_ISO = 'en_CA' --and TERM_KEY = 5
 order by order_no, order_purchase_dt, SI_KEY,contract_xid
-- order by ORDER_CREATED_TS desc
-- order by DBMS_RANDOM.RANDOM()
;

 +----------+--------+-----------+------------+--------------+---------------+
|POLICY_KEY|TERM_KEY|VISITOR_KEY|CUSTOMER_KEY|OFFER_KEY     |SALES_SOURCE_CD|
+----------+--------+-----------+------------+--------------+---------------+
|9823      |3       |2958365    |5393702     |12830693001007|EMAIL_WEB_SALES|
|3074      |3       |2958365    |5393702     |12863951000953|EMAIL_WEB_SALES|
|10111     |3       |2958365    |5393702     |13134794000956|WEB_SALES      |
|10467     |3       |2958365    |5393702     |13126992001633|WEB_SALES      |
+----------+--------+-----------+------------+--------------+---------------+

 select * from BOSH.CUSTOMER_LKP where CUSTOMER_KEY = 5393702;
-- +------------+------------+
-- |CUSTOMER_KEY|CUSTOMER_XID|
-- +------------+------------+
-- |5393702     |5393702     |
-- |5393702     |5393702     |
-- +------------+------------+

select * from BOSH.CUSTOMER_LKP where CUSTOMER_XID in ('5393702','5444884');
-- +------------+------------+
-- |CUSTOMER_KEY|CUSTOMER_XID|
-- +------------+------------+
-- |5393702     |5393702     |
-- |5393702     |5393702     |
-- |5444884     |5444884     |
-- |5444884     |5444884     |
-- +------------+------------+

select * from BOSH.CUSTOMER_DIM where CUSTOMER_KEY in (5393702,5444884);
-- +------------+-------------+-------------------+
-- |CUSTOMER_KEY|HOUSEHOLD_KEY|PRIMARY_VISITOR_KEY|
-- +------------+-------------+-------------------+
-- |5393702     |2587790      |2958365            |
-- |5444884     |2587790      |2958365            |
-- +------------+-------------+-------------------+