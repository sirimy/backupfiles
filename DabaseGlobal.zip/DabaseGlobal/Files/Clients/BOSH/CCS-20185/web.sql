

select * from customer_tbl where customer_id =5393702;
-- primary_address_id,customer_id
-- 4625191,5393702

select * from order_tbl where customer_id in (5393702,5444884);
-- customer_id,order_id,order_xid
-- 5444884,510355,3428391
-- 5444884,518801,3432613

select * from customer_tbl where customer_id =5444884;
-- primary_address_id,customer_id
-- 13701382,5444884