SELECT * FROM processing_queue_tbl
where entity_classifier_cd = 'Order' and processing_type_cd = 'CONTRACT_CREATION'
order by entity_identifier_key desc;

select * from order_tbl where order_id in(
348443,348441,348433,348431,
348429,348427);--2023-04-27 00:10:24.203000
+--------+---------+------------------+----------+--------------------------+----------------+-------------+-------+--------------+-------------+-------------------------+---------+-----------+--------+---------------+--------------------------+---------------+---------+---------------+-----------+--------------------------+
order_id|order_xid|billing_profile_id|created_by|purchase_dt,call_center_flag|sub_total_amt|tax_amt|tax_county    |surcharge_amt|shipping_and_handling_amt|total_amt|customer_id|dml_flag|last_updated_by|last_updated_ts           |sales_source_cd|outlet_id|order_status_id|currency_cd|created_ts ,
+--------+---------+------------------+----------+--------------------------+----------------+-------------+-------+--------------+-------------+-------------------------+---------+-----------+--------+---------------+--------------------------+---------------+---------+---------------+-----------+--------------------------+
|348427  |3347430  |NULL              |SYSTEM    |2023-04-27 00:10:24.203000|N,231.00       |19.06  |MONTGOMERY    |0.00         |0.00      ,250.06   |4081714    |NULL    |bosh           |2023-04-27 07:11:13.953049|EMAIL_WEB_SALES|NULL     |NULL           |USD        |2023-04-27 00:10:27.509000|
|348429  |3347431  |150824373         |SYSTEM    |2023-04-27 00:39:17.766000|N,662.76       |0.00   |GILPIN        |4.00         |0.00      ,666.76   |3253148    |NULL    |bosh           |2023-04-27 07:11:13.953049|EMAIL_WEB_SALES|NULL     |NULL           |USD        |2023-04-27 00:39:21.249000|
|348431  |3347432  |150825875         |SYSTEM    |2023-04-27 01:37:10.747000|N,120.00       |0.00   |LEE           |4.00         |0.00      ,124.00   |4287468    |NULL    |bosh           |2023-04-27 07:11:13.953049|EMAIL_WEB_SALES|NULL     |NULL           |USD        |2023-04-27 01:37:15.441000|
|348433  |3347433  |NULL              |SYSTEM    |2023-04-27 01:38:22.138000|N,497.70       |0.00   |WORCESTER     |0.00         |0.00      ,497.70   |1593252    |NULL    |bosh           |2023-04-27 07:11:13.953049|EMAIL_WEB_SALES|NULL     |NULL           |USD        |2023-04-27 01:38:25.854000|
|348441  |3347437  |NULL              |SYSTEM    |2023-04-27 02:43:42.127000|N,60.00        |0.00   |NEVADA        |0.00         |0.00      ,60.00    |4318716    |NULL    |bosh           |2023-04-27 07:11:13.953049|EMAIL_WEB_SALES|NULL     |NULL           |USD        |2023-04-27 02:43:45.435000|
|348443  |3347438  |NULL              |SYSTEM    |2023-04-27 03:04:48.192000|N,424.00       |12.72  |PRINCE WILLIAM|0.00         |0.00      ,436.72   |4074934    |NULL    |bosh           |2023-04-27 07:11:13.953049|EMAIL_WEB_SALES|NULL     |NULL           |USD        |2023-04-27 03:04:51.457000|
+--------+---------+------------------+----------+--------------------------+----------------+-------------+-------+--------------+-------------+-------------------------+---------+-----------+--------+---------------+--------------------------+---------------+---------+---------------+-----------+--------------------------+

Select * from contract_order where order_id in (
select order_id from order_tbl where order_id in(
348443,348441,348433,348431,
348429,348427));--2023-04-27 00:10:24.203000
-- zero rows



 select * from order_tbl where order_id in(
348425,348423,348421,348417,348415,348413,348411,348409,348399,
348397,348395,348393,348391,348381,348379,348377,348375,348361,
348359,348357,348355,348353,348351,348349,348347,348345,348343,
348341,348339,348337,348335,348333,348331,348329,348327,348325,
348323,348321,348317,348315,348313,348309,348307,348305,348303,
348301,348299,348297,348295,348293,348289,348285,348283,348281,
348279,348277,348275,348273,348271,348269,348267,348265,348261,
348257,348255);--2023-04-26 20:39:03.194000
--65 rows


Select * from contract_order where order_id in (
 select order_id from order_tbl where order_id in(
348425,348423,348421,348417,348415,348413,348411,348409,348399,
348397,348395,348393,348391,348381,348379,348377,348375,348361,
348359,348357,348355,348353,348351,348349,348347,348345,348343,
348341,348339,348337,348335,348333,348331,348329,348327,348325,
348323,348321,348317,348315,348313,348309,348307,348305,348303,
348301,348299,348297,348295,348293,348289,348285,348283,348281,
348279,348277,348275,348273,348271,348269,348267,348265,348261,
348257,348255));--2023-04-26 20:39:03.194000




select * from order_tbl where order_id in(
348213,348257,348221,348217,348255,348215,348233,
348241,348243,348211,348223,348247,348223,348257,
348245,348205,348211,348221,348249,348237,348237,
348227,348257,348253,348225,348253,348253,348229,
348207,348253,348201,348253,348253,348239,348235,
348203,348221) order by created_ts;-- 25

SELECT * FROM processing_queue_tbl
where entity_classifier_cd = 'Order' and processing_type_cd = 'CONTRACT_CREATION'
and last_updated_ts > '2023-04-27 00:10:27.00'
order by entity_identifier_key desc;


SELECT * FROM processing_queue_tbl
where entity_classifier_cd = 'Order' and processing_type_cd = 'CONTRACT_CREATION'
and last_updated_ts < '2023-04-27 00:10:27.00' and last_updated_ts > '2023-04-26 00:00:00.00'
order by entity_identifier_key desc;


SELECT * FROM processing_queue_tbl
where entity_classifier_cd = 'Order' and processing_type_cd = 'CONTRACT_CREATION'
and last_updated_ts < '2023-04-26 00:00:00.00' and last_updated_ts > '2023-04-25 00:00:00.00'
order by entity_identifier_key desc;

+---------------------+--------------------+------------------+--------------------+----------+--------+----------------------------------+-----------------------+--------------------------+
|entity_identifier_key|entity_classifier_cd|processing_type_cd|processing_status_cd|attempt_no|note_txt|target_host_nm                    |last_updated_by        |last_updated_ts           |
+---------------------+--------------------+------------------+--------------------+----------+--------+----------------------------------+-----------------------+--------------------------+
|348249               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|SYSTEM                 |2023-04-25 23:22:08.969000|
|348247               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 22:08:19.072000|
|348245               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 22:01:40.430000|
|348243               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|sromero@afterinc.com   |2023-04-25 21:34:34.730000|
|348241               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|SYSTEM                 |2023-04-25 21:05:38.448000|
|348239               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|mcarrillo@afterinc.com |2023-04-25 20:29:04.343000|
|348237               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|sromero@afterinc.com   |2023-04-25 19:49:11.907000|
|348235               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|SYSTEM                 |2023-04-25 19:16:20.213000|
|348233               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|jjaconette@afterinc.com|2023-04-25 18:07:43.693000|
|348229               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|SYSTEM                 |2023-04-25 17:44:32.285000|
|348227               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 17:45:38.587000|
|348225               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|imiah@afterinc.com     |2023-04-25 17:37:08.277000|
|348223               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|SYSTEM                 |2023-04-25 17:26:05.155000|
|348221               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|imiah@afterinc.com     |2023-04-25 16:27:19.435000|
|348217               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|SYSTEM                 |2023-04-25 16:10:32.975000|
|348215               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|jjaconette@afterinc.com|2023-04-25 16:06:43.974000|
|348213               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 15:45:42.307000|
|348211               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|sromero@afterinc.com   |2023-04-25 15:28:41.415000|
|348207               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|SYSTEM                 |2023-04-25 15:19:39.012000|
|348205               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|apaul@afterinc.com     |2023-04-25 14:20:43.655000|
|348203               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-2.cloud.afterinc.com|SYSTEM                 |2023-04-25 13:34:20.924000|
|348201               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 13:13:04.826000|
|348197               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 01:47:28.607000|
|348195               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 01:11:08.066000|
|348193               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 00:48:28.023000|
|348191               |Order               |CONTRACT_CREATION |NEW                 |1         |NULL    |bosh-prod-app-1.cloud.afterinc.com|SYSTEM                 |2023-04-25 00:10:41.302000|
+---------------------+--------------------+------------------+--------------------+----------+--------+----------------------------------+-----------------------+--------------------------+

Select * from contract_order where order_id::text in (
SELECT entity_identifier_key FROM processing_queue_tbl
where entity_classifier_cd = 'Order' and processing_type_cd = 'CONTRACT_CREATION'
and last_updated_ts < '2023-04-26 00:00:00.00' and last_updated_ts > '2023-04-25 00:00:00.00'
order by entity_identifier_key desc);
+-----------+--------+-------------+---------------+--------------------------+
|contract_id|order_id|order_line_id|last_updated_by|last_updated_ts           |
+-----------+--------+-------------+---------------+--------------------------+
|19832062   |348191  |1            |bosh           |2023-04-27 07:11:46.806482|
|19832076   |348195  |2            |bosh           |2023-04-27 07:11:46.806482|
|19832090   |348193  |1            |bosh           |2023-04-27 07:11:46.806482|
|19832126   |348195  |1            |bosh           |2023-04-27 07:11:46.806482|
|19832138   |348197  |1            |bosh           |2023-04-27 07:11:46.806482|
+-----------+--------+-------------+---------------+--------------------------+

Select * from contract where contract_id in (
Select contract_id from contract_order where order_id::text in (
SELECT entity_identifier_key FROM processing_queue_tbl
where entity_classifier_cd = 'Order' and processing_type_cd = 'CONTRACT_CREATION'
and last_updated_ts < '2023-04-26 00:00:00.00' and last_updated_ts > '2023-04-25 00:00:00.00'
order by entity_identifier_key desc));

+-----------+-------------------+--------------------------+--------------------------+--------------------------+----------+-----------+------------+---------------+-----+-------------+-----------------------+---------+------------------+---------------+---------------+----------+-------------------+-----------+-------------------+--------+--------------------------+--------------------+---------+
|contract_id|client_contract_num|contract_sale_dt          |contract_start_dt         |contract_end_dt           |retail_amt|currency_cd|discount_amt|net_premium_amt|tax  |risk_free_amt|terms_and_conditions_id|policy_id|contract_status_id|last_updated_by|resolution_type|address_id|client_customer_num|customer_id|purchase_address_id|dml_flag|last_updated_ts           |contract_template_id|outlet_id|
+-----------+-------------------+--------------------------+--------------------------+--------------------------+----------+-----------+------------+---------------+-----+-------------+-----------------------+---------+------------------+---------------+---------------+----------+-------------------+-----------+-------------------+--------+--------------------------+--------------------+---------+
|19832062   |BSH-348191-1       |2023-04-25 00:00:00.000000|2023-12-12 00:00:00.000000|2029-12-12 00:00:00.000000|197.60    |USD        |NULL        |NULL           |16.30|NULL         |1                      |2888     |1                 |bosh           |NULL           |11162254  |NULL               |4332156    |11162254           |NULL    |2023-04-27 07:11:46.517938|1                   |NULL     |
|19832076   |BSH-348195-2       |2023-04-25 00:00:00.000000|2023-05-07 00:00:00.000000|2025-05-07 00:00:00.000000|151.20    |USD        |NULL        |NULL           |10.58|NULL         |1                      |748      |1                 |bosh           |NULL           |8935214   |NULL               |3548306    |8935214            |NULL    |2023-04-27 07:11:46.517938|1                   |NULL     |
|19832090   |BSH-348193-1       |2023-04-25 00:00:00.000000|2023-05-25 00:00:00.000000|2026-04-25 00:00:00.000000|235.20    |USD        |NULL        |NULL           |0.00 |NULL         |1                      |3105     |1                 |bosh           |NULL           |9059414   |NULL               |3603310    |9059414            |NULL    |2023-04-27 07:11:46.517938|1                   |NULL     |
|19832126   |BSH-348195-1       |2023-04-25 00:00:00.000000|2023-05-04 00:00:00.000000|2025-05-04 00:00:00.000000|161.10    |USD        |NULL        |NULL           |11.28|NULL         |1                      |723      |1                 |bosh           |NULL           |8935214   |NULL               |3548306    |8935214            |NULL    |2023-04-27 07:11:46.517938|1                   |NULL     |
|19832138   |BSH-348197-1       |2023-04-25 00:00:00.000000|2023-08-02 00:00:00.000000|2026-08-02 00:00:00.000000|270.00    |USD        |NULL        |NULL           |0.00 |NULL         |1                      |4137     |1                 |bosh           |NULL           |1378391   |NULL               |1544400    |1378391            |NULL    |2023-04-27 07:11:46.517938|1                   |NULL     |
+-----------+-------------------+--------------------------+--------------------------+--------------------------+----------+-----------+------------+---------------+-----+-------------+-----------------------+---------+------------------+---------------+---------------+----------+-------------------+-----------+-------------------+--------+--------------------------+--------------------+---------+
+-----------+-------------------+--------------------------+
|contract_id|client_contract_num|contract_sale_dt          |
+-----------+-------------------+--------------------------+
|19832062   |BSH-348191-1       |2023-04-25 00:00:00.000000|
|19832076   |BSH-348195-2       |2023-04-25 00:00:00.000000|
|19832090   |BSH-348193-1       |2023-04-25 00:00:00.000000|
|19832126   |BSH-348195-1       |2023-04-25 00:00:00.000000|
|19832138   |BSH-348197-1       |2023-04-25 00:00:00.000000|
+-----------+-------------------+--------------------------+


Select COUNT(*) from order_tbl where order_id in (
select order_id from contract_order ); --78558

Select COUNT(*) from order_tbl  where order_id not in (
select order_id from contract_order ); --760

Select COUNT(*) from contract;--92361

Select COUNT(*) from contract_order;--92361


Select COUNT(*) from contract_items;--92244

COMMIT;

--after Sales ackndowlde comes

Select COUNT(*) from order_tbl where order_id in (
select order_id from contract_order ); --78558

Select COUNT(*) from order_tbl  where order_id not in (
select order_id from contract_order ); --760

Select COUNT(*) from contract;--92361

Select COUNT(*) from contract_order;--92361


Select COUNT(*) from contract_items;--92244

-----------DW----------------------------


select COUNT(*) from BOSH.RAW_CONTRACT_SALES_TBL
where FILE_NM = 'BSH_Sale_Ack_04262023.txt' order by  INSERT_AUDIT_KEY desc;

select * from BOSH.RAW_CONTRACT_SALES_TBL order by  INSERT_AUDIT_KEY desc;

select * from BOSH.RAW_CONTRACT_SALES_TBL where FILE_NM = 'BSH_Sale_Ack_04262023.txt'
and P2_CONTRACT_NO in (
'BSH-348191-1',
'BSH-348195-2',
'BSH-348193-1',
'BSH-348195-1',
'BSH-348197-1'
        )
order by  INSERT_AUDIT_KEY desc;

+--------------+---------+-------------------------------------------------+
|P2_CONTRACT_NO|STATUS_CD|ERROR_TXT                                        |
+--------------+---------+-------------------------------------------------+
|BSH-348195-1  |ACTIVE   |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
|BSH-348195-2  |ACTIVE   |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
|BSH-348197-1  |ACTIVE   |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
|BSH-348191-1  |ACTIVE   |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
|BSH-348193-1  |ACTIVE   |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|
+--------------+---------+-------------------------------------------------+

Select COUNT(*) from BOSH.ORDER_TBL where ORDER_KEY in (
select ORDER_KEY from BOSH.CONTRACT_ORDER_TBL ); --78558

Select COUNT(*) from BOSH.ORDER_TBL  where ORDER_KEY not in (
select ORDER_KEY from  BOSH.CONTRACT_ORDER_TBL ); --144