select oft.*, ofit.*, pol.description
  from offer_tbl oft
       join  offer_item_tbl ofit on ofit.offer_id = oft.offer_id
       left join policy pol on pol.policy_id = ofit.policy_id
 where 1=1
   and new_offer_id = 'BRRXJCF';