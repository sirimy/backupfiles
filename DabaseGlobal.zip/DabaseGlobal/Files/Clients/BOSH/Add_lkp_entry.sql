 select --distinct a.unique_seq_no, a.visitor_xid, b.visitor_key,vv.visitor_key,
                  distinct g.si_key
                  , case when instr(a.model_no, '/') > 0 then a.model_no else nvl(a.model_no, g.model_no) || '/xx' end --model_no
                  || - to_char(trunc(purchase_Dt), 'YYYYMMDD') --purchase_Dt
                  || '-' || account_id
                  AS new_si_xid
                 , 0 source_system_cd
                 , 2 ext_id_type_cd
                 , 'V_AUDIT_KEY'
                 , null update_audit_key
                 , null sync_audit_key
            from bosh.common_load_tbl_arch a
            join bosh.common_load_output_tbl_arch b on ( a.unique_seq_no = b.unique_seq_no and b.process_Dt = a.process_Dt)
            join bosh.si_output_Tbl_arch d on ( a.unique_seq_no = d.unique_seq_no and d.process_Dt = a.process_dt)
            join bosh.serialized_item_dim g on ( posted_serial_item_key = g.si_key)
            left join bosh.serialized_item_lkp h on ( g.si_key = h.si_key and h.source_system_cd = 0)
            left join (
                --fetch other si_keys for this visitor and fetch account_id from there
                select distinct a.visitor_key, a.si_key, b.si_key other_si_key, c.si_xid,
                                 --substr(c.si_xid,instr(c.si_xid,'-',1,2)+1) account_id
                                case when instr(c.si_xid, '-', 1, 3) = 0 then substr(c.si_xid, instr(c.si_xid, '-', 1, 2) + 1)   --if si_xid ends with account_id
                                      --if si_xid has data after account_id
                                     else substr(c.si_xid, instr(c.si_xid, '-', 1, 2) + 1, instr(c.si_xid, '-', 1, 3) - instr(c.si_xid, '-', 1, 2)-1)
                                 end as account_id
                   from bosh.visitor_ownership_Xref a
                        join bosh.visitor_ownership_xref b on a.visitor_key = b.visitor_key
                        join bosh.serialized_item_lkp c on b.si_key = c.si_key and c.source_system_cd = 0
                  where 1=1
                     and a.si_key = 4264341
                 ) vo on (g.si_key = nvl(vo.si_key, vo.other_si_key) )
            where 1=1

            and a.model_no is not null
            and a.visitor_xid is not null
            and account_id is not null
            and posted_serial_item_key = 4264341

                 ;

DECLARE
    v_audit_key INTEGER;

BEGIN

    v_audit_key := get_audit_key (p_program_nm => 'POST_SI_LKP', p_DESCRIPTIVE_TX => 'Loading si_lkp records for web products', p_table_nm => 'SERIALIZED_ITEM_LKP', p_author_nm => 'vpatel' );
    DBMS_OUTPUT.put_line(v_audit_key);
    COMMIT;

    insert into serialized_item_lkp
    select src.*
    from  (
           select --distinct a.unique_seq_no, a.visitor_xid, b.visitor_key,vv.visitor_key,
                  distinct g.si_key
                  , case when instr(a.model_no, '/') > 0 then a.model_no else nvl(a.model_no, g.model_no) || '/xx' end --model_no
                  || - to_char(trunc(purchase_Dt), 'YYYYMMDD') --purchase_Dt
                  || '-' || account_id
                  AS new_si_xid
                 , 0 source_system_cd
                 , 2 ext_id_type_cd
                 , V_AUDIT_KEY
                 , null update_audit_key
                 , null sync_audit_key
            from bosh.common_load_tbl_arch a
            join bosh.common_load_output_tbl_arch b on ( a.unique_seq_no = b.unique_seq_no and b.process_Dt = a.process_Dt)
            join bosh.si_output_Tbl_arch d on ( a.unique_seq_no = d.unique_seq_no and d.process_Dt = a.process_dt)
            join serialized_item_dim g on ( posted_serial_item_key = g.si_key)
            left join serialized_item_lkp h on ( g.si_key = h.si_key and h.source_system_cd = 0)
            left join (
                --fetch other si_keys for this visitor and fetch account_id from there
                select distinct a.visitor_key, a.si_key, b.si_key other_si_key, c.si_xid,
                                 --substr(c.si_xid,instr(c.si_xid,'-',1,2)+1) account_id
                                case when instr(c.si_xid, '-', 1, 3) = 0 then substr(c.si_xid, instr(c.si_xid, '-', 1, 2) + 1)   --if si_xid ends with account_id
                                      --if si_xid has data after account_id
                                     else substr(c.si_xid, instr(c.si_xid, '-', 1, 2) + 1, instr(c.si_xid, '-', 1, 3) - instr(c.si_xid, '-', 1, 2)-1)
                                 end as account_id
                   from visitor_ownership_Xref a
                        join visitor_ownership_xref b on a.visitor_key = b.visitor_key
                        join serialized_item_lkp c on b.si_key = c.si_key and c.source_system_cd = 0
                  where 1=1
                     and a.si_key = 4264341
                 ) vo on (g.si_key = nvl(vo.si_key, vo.other_si_key) )
            where 1=1

            and a.model_no is not null
            and a.visitor_xid is not null
            and account_id is not null
            and posted_serial_item_key = 4264341
           ) src
          ---

                 ;

    COMMIT;

END;