

select * from PRODUCT_PRICE_DIM;

select tcx.TERMS_AND_CONDITIONS_KEY, COUNTRY_ISO, tr.name, count(*), count(distinct POLICY_KEY) as policies, count(distinct psd.POSTAL_STATE_KEY) as states
       ,min(tcx.effective_dt), max(tcx.effective_dt), min(pol.effective_dt), max(pol.effective_dt), tac.DESCRIPTION
  from t_and_c_contract_template_xref tcx join policy_tbl pol using (policy_key)
       join p_term_dim tr using (term_key)
       join p_postal_state_dim psd on psd.postal_state_key = tcx.postal_state_key
       join p_TERMS_AND_CONDITIONS_DIM tac on tcx.TERMS_AND_CONDITIONS_KEY = tac.TERMS_AND_CONDITIONS_KEY
 group by tcx.TERMS_AND_CONDITIONS_KEY, COUNTRY_ISO, tr.name, tac.DESCRIPTION
 order by 1, 2;

+------------------------+-----------+-------+--------+--------+------+---------------------+---------------------+---------------------+---------------------+---------------------------------------------------------------+
|TERMS_AND_CONDITIONS_KEY|COUNTRY_ISO|NAME   |COUNT(*)|POLICIES|STATES|MIN(TCX.EFFECTIVE_DT)|MAX(TCX.EFFECTIVE_DT)|MIN(POL.EFFECTIVE_DT)|MAX(POL.EFFECTIVE_DT)|DESCRIPTION                                                    |
+------------------------+-----------+-------+--------+--------+------+---------------------+---------------------+---------------------+---------------------+---------------------------------------------------------------+
|11                      |USA        |2 Years|1938    |38      |51    |2023-07-25           |2023-07-25           |2023-07-25           |2023-07-25           |Builder Bosch Appliance Service Plan - Terms And Conditions    |
|11                      |USA        |3 Years|3876    |76      |51    |2023-07-25           |2023-07-25           |2023-07-25           |2023-07-25           |Builder Bosch Appliance Service Plan - Terms And Conditions    |
|11                      |USA        |4 Years|5814    |114     |51    |2023-07-25           |2023-07-25           |2023-07-25           |2023-07-25           |Builder Bosch Appliance Service Plan - Terms And Conditions    |
|12                      |USA        |2 Years|1887    |37      |51    |2023-07-25           |2023-07-25           |2023-07-25           |2023-07-25           |Builder Thermador Appliance Service Plan - Terms And Conditions|
|12                      |USA        |3 Years|3774    |74      |51    |2023-07-25           |2023-07-25           |2023-07-25           |2023-07-25           |Builder Thermador Appliance Service Plan - Terms And Conditions|
|12                      |USA        |4 Years|5661    |111     |51    |2023-07-25           |2023-07-25           |2023-07-25           |2023-07-25           |Builder Thermador Appliance Service Plan - Terms And Conditions|
+------------------------+-----------+-------+--------+--------+------+---------------------+---------------------+---------------------+---------------------+---------------------------------------------------------------+

select COUNT(*) from PRODUCT_PRICE_DIM;--5700

select PPD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_DESC,COUNT(PPD.PRICING_SCHEME_KEY) AS CNT,
       count(distinct PRODUCT_KEY) as products, count(distinct POLICY_KEY)
,listagg(distinct TERM_MONTHS, ', ') as terms
from PRODUCT_PRICE_DIM PPD
 inner join (select * from BOSH.pricing_scheme_dim UNION select * from pricing_scheme_dim)  PSD
                        on PPD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
Group by PPD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_DESC
Order by PRICING_SCHEME_KEY;
+------------------+-------------------+----+--------+-------------------------+----------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|CNT |PRODUCTS|COUNT(DISTINCTPOLICY_KEY)|TERMS     |
+------------------+-------------------+----+--------+-------------------------+----------+
|162               |RN 4 Bosch         |601 |601     |28                       |48        |
|163               |RN 5 Bosch         |1202|601     |56                       |36, 48    |
|164               |RN 6 Bosch         |1803|601     |84                       |24, 36, 48|
|169               |RN 4 Thermador     |349 |349     |26                       |48        |
|170               |RN 5 Thermador     |698 |349     |52                       |36, 48    |
|171               |RN 6 Thermador     |1047|349     |78                       |24, 36, 48|
+------------------+-------------------+----+--------+-------------------------+----------+

select count( Distinct PT.POLICY_PRODUCT_XID ) from PRODUCT_PRICE_DIM PRD
    inner join POLICY_TBL PT on PRD.POLICY_KEY = PT.POLICY_KEY;--324

Select distinct MIN_PRODUCT_PRICE,MAX_PRODUCT_PRICE from POLICY_TBL where POLICY_PRODUCT_XID not in
                               (
select  Distinct PT.POLICY_PRODUCT_XID  from PRODUCT_PRICE_DIM PRD
    inner join POLICY_TBL PT on PRD.POLICY_KEY = PT.POLICY_KEY
) order by MIN_PRODUCT_PRICE;--324
+-----------------+-----------------+
|MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|
+-----------------+-----------------+
|1500.00          |1999.99          |
|2000.00          |2499.99          |
|2500.00          |2999.99          |
|3000.00          |3499.99          |
|3500.00          |4999.99          |
|5000.00          |5499.99          |
|5500.00          |5999.99          |
|6000.00          |6999.99          |
|7000.00          |7999.99          |
|8000.00          |8999.99          |
|9000.00          |9999.99          |
|10000.00         |12499.99         |
+-----------------+-----------------+
