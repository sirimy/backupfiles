
select COUNT(*) from UPDATED_THERMADOR_COOKING_RENEWAL_PRICING_20230830;--450

select PRODUCT_CATEGORY,AGE,CHANNEL,COUNT(*) from ADDED_RENEWAL_PRICING_AND_MISSING_RATES_1346
Group by PRODUCT_CATEGORY,AGE,CHANNEL
order by PRODUCT_CATEGORY,AGE;

--SKU	PRODUCT_CATEGORY	BRAND	AGE	TERM	MIN_PRODUCT_PRICE	MAX_PRODUCT_PRICE	PREMIUM_AMT	OFFERED_PRICE	CHANNEL

select SKU              ,
    PRODUCT_CATEGORY   ,
    BRAND              ,
    AGE                ,
    TERM               ,
    MIN_PRODUCT_PRICE  ,
    MAX_PRODUCT_PRICE  ,
    PREMIUM_AMT    ,
    OFFERED_PRICE ,
    CHANNEL
From ADDED_RENEWAL_PRICING_AND_MISSING_RATES_1346;
+----------+---------------------+-----+---+----+-----------------+-----------------+-----------+-------------+-------+
|SKU       |PRODUCT_CATEGORY     |BRAND|AGE|TERM|MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|PREMIUM_AMT|OFFERED_PRICE|CHANNEL|
+----------+---------------------+-----+---+----+-----------------+-----------------+-----------+-------------+-------+
|BSCMF48UR4|BUILT-IN COFFEE MAKER|Bosch|4  |4   |2,000            |2,499.99         |129.7      |556          |Renewal|
|BSCMF36UR5|BUILT-IN COFFEE MAKER|Bosch|5  |3   |2,000            |2,499.99         |111.96     |471          |Renewal|
|BSCMF48UR5|BUILT-IN COFFEE MAKER|Bosch|5  |4   |2,000            |2,499.99         |148.54     |596          |Renewal|
+----------+---------------------+-----+---+----+-----------------+-----------------+-----------+-------------+-------+

select
    SKU              ,
    PRODUCT_CATEGORY   ,
    BRAND              ,
    AGE                ,
    TERM               ,
    MIN_PRODUCT_PRICE  ,
    MAX_PRODUCT_PRICE  ,
    PREMIUM_AMT    ,
    OFFERED_PRICE ,
    CHANNEL,
    AFTER_POLICY_ID
from  ADDED_RENEWAL_PRICING_AND_MISSING_BAND_1346;

update ADDED_RENEWAL_PRICING_AND_MISSING_BAND_1346
SET
    MIN_PRODUCT_PRICE = Replace(MIN_PRODUCT_PRICE,'$',''),
    MAX_PRODUCT_PRICE = Replace(MAX_PRODUCT_PRICE,'$',''),
    PREMIUM_AMT = Replace(PREMIUM_AMT,'$',''),
    OFFERED_PRICE = Replace(OFFERED_PRICE,'$','')
;

select COUNT(*) from RAW_PRICING_TBL;--450

select COUNT(*),FILE_NM from RAW_PRICING_TBL
Group by FILE_NM;--
+--------+-------------------------------------------+
|COUNT(*)|FILE_NM                                    |
+--------+-------------------------------------------+
|450     |ADDED_RENEWAL_PRICING_AND_MISSING_RATES    |
|127     |ADDED_RENEWAL_PRICING_AND_MISSING_BAND_1346|
+--------+-------------------------------------------+



insert into RAW_PRICING_TBL
(SKU , PRODUCT_CAT_DESC ,BRAND ,AGE ,TERM_COVERAGE_EXT ,MIN_PRODUCT_PRICE , MAX_PRODUCT_PRICE, TWGIS_COST, RETAIL_PRICE_AMT ,CURRENCY,CHANNEL,FILE_NM,OLD_POLICY_KEY)
select SKU ,PRODUCT_CATEGORY , BRAND , AGE , TERM , TO_NUMBER(Replace(MIN_PRODUCT_PRICE,',',''))  , TO_NUMBER(Replace(MAX_PRODUCT_PRICE,',',''))
, TO_NUMBER(Replace(PREMIUM_AMT,',','')) , TO_NUMBER(Replace(OFFERED_PRICE,',','')) ,'USD' , CHANNEL,'ADDED_RENEWAL_PRICING_AND_MISSING_BAND_1346',AFTER_POLICY_ID
From ADDED_RENEWAL_PRICING_AND_MISSING_BAND_1346 where SKU is not null ;


select  Distinct BRAND ,PRODUCT_CAT_DESC ,CHANNEL
from RAW_PRICING_TBL order by BRAND,PRODUCT_CAT_DESC;
 +---------+---------------------+-------+
|BRAND    |PRODUCT_CAT_DESC     |CHANNEL|
+---------+---------------------+-------+
|Bosch    |BUILT-IN COFFEE MAKER|AM EB  |
|Bosch    |BUILT-IN COFFEE MAKER|OOW    |
|Bosch    |BUILT-IN COFFEE MAKER|RENEWAL|
|Bosch    |COOKING              |RENEWAL|
|Bosch    |DISHWASHER           |RENEWAL|
|Bosch    |LAUNDRY-DRYER        |RENEWAL|
|Bosch    |LAUNDRY-WASHER       |RENEWAL|
|Bosch    |REFRIGERATION W LOSS |RENEWAL|
|Bosch    |VENTILATION          |RENEWAL|
|Thermador|BUILT-IN COFFEE MAKER|AM EB  |
|Thermador|BUILT-IN COFFEE MAKER|OOW    |
|Thermador|BUILT-IN COFFEE MAKER|RENEWAL|
|Thermador|COOKING              |AM EB  |
|Thermador|COOKING              |OOW    |
|Thermador|COOKING              |RENEWAL|
|Thermador|DISHWASHER           |RENEWAL|
|Thermador|REFRIGERATION W LOSS |RENEWAL|
|Thermador|VENTILATION          |AM EB  |
|Thermador|VENTILATION          |OOW    |
|Thermador|VENTILATION          |RENEWAL|
+---------+---------------------+-------+


select  Distinct PRODUCT_CAT_DESC
from RAW_PRICING_TBL order by PRODUCT_CAT_DESC;
+---------------------+
|PRODUCT_CAT_DESC     |
+---------------------+
|BUILT-IN COFFEE MAKER|
|COOKING              |
|DISHWASHER           |
|LAUNDRY-DRYER        |
|LAUNDRY-WASHER       |
|REFRIGERATION W LOSS |
|VENTILATION          |
+---------------------+



select distinct PRODUCT_CAT_DESC from RAW_PRICING_TBL
    where PRODUCT_CAT_DESC not in (select  PRODUCT_CATEGORY_NM  from BOSH.PRODUCT_CATEGORY_DIM );
+---------------------+
|PRODUCT_CAT_DESC     |
+---------------------+
|Built-In Coffee Maker|
|Ventilation          |
|Cooking              |
+---------------------+
select  PRODUCT_CATEGORY_NM  from BOSH.PRODUCT_CATEGORY_DIM ;
+---------------------+
|PRODUCT_CATEGORY_NM  |
+---------------------+
|VENTILATION          |
|REFRIGERATION W LOSS |
|COOKING              |
|DISHWASHER           |
|BUILT-IN COFFEE MAKER|
|LAUNDRY-WASHER       |
|LAUNDRY-DRYER        |
|OTHER                |
+---------------------+
update RAW_PRICING_TBL set PRODUCT_CAT_DESC = 'BUILT-IN COFFEE MAKER' where PRODUCT_CAT_DESC = 'Built-In Coffee Maker';
update RAW_PRICING_TBL set PRODUCT_CAT_DESC = 'VENTILATION' where PRODUCT_CAT_DESC = 'Ventilation';
update RAW_PRICING_TBL set PRODUCT_CAT_DESC = 'COOKING' where PRODUCT_CAT_DESC = 'Cooking';
COMMIT;



select  SKU , PRODUCT_CAT_DESC ,BRAND ,AGE ,TERM_COVERAGE_EXT ,MIN_PRODUCT_PRICE , MAX_PRODUCT_PRICE, TWGIS_COST, RETAIL_PRICE_AMT ,CURRENCY,CHANNEL
from RAW_PRICING_TBL;

select  SKU , PRODUCT_CAT_DESC ,  BRAND     , AGE     ,  TERM_COVERAGE_EXT ,
MIN_PRODUCT_PRICE ,   MAX_PRODUCT_PRICE  , TWGIS_COST  , RETAIL_PRICE_AMT ,
CURRENCY       , WAIT_PERIOD , PREMIUM , MARSH_FEE , ADMIN_FEE ,COMMENTS ,POLICY_KEY ,CHANNEL ,EFFECTIVE_DT --,OLD_POLICY_KEY
from BOSH.RAW_PRICING_TBL order by INSERT_AUDIT_KEY desc;

insert into RAW_PRICING_TBL
(SKU , PRODUCT_CAT_DESC ,BRAND ,AGE ,TERM_COVERAGE_EXT ,MIN_PRODUCT_PRICE , MAX_PRODUCT_PRICE, TWGIS_COST, RETAIL_PRICE_AMT ,CURRENCY,CHANNEL,FILE_NM)
select SKU ,PRODUCT_CATEGORY , BRAND , AGE , TERM , TO_NUMBER(Replace(MIN_PRODUCT_PRICE,',',''))  , TO_NUMBER(Replace(MAX_PRODUCT_PRICE,',',''))
, PREMIUM_AMT , TO_NUMBER(Replace(OFFERED_PRICE,',','')) ,'USD' , CHANNEL,'ADDED_RENEWAL_PRICING_AND_MISSING_RATES'
From ADDED_RENEWAL_PRICING_AND_MISSING_RATES_1346;


select distinct PRODUCT_CAT_DESC from RAW_PRICING_TBL
    where PRODUCT_CAT_DESC not in ( Select PCD.PRODUCT_CATEGORY_NM from BOSH.PRODUCT_CATEGORY_DIM PCD );
--REFRIGERATOR WITH FOOD LOSS

Select PCD.PRODUCT_CATEGORY_NM from BOSH.PRODUCT_CATEGORY_DIM PCD;



select distinct CHANNEL from RAW_PRICING_TBL;--450
+-------+
|CHANNEL|
+-------+
|AM EB  |
|RENEWAL|
|OOW    |
+-------+

-- ALTER SEQUENCE policy_seq INCREMENT BY 463;
-- select policy_seq.nextval from dual;--6461
--ALTER SEQUENCE policy_seq INCREMENT BY 1;

 SELECT
                    policy_key
                   ,BRAND
                   ,pri.Name, pri.Description
                   , POLICY_PRODUCT_XID
                   ,POLICY_LKP_XID
                   ,RETAIL_PRICE_AMT, DEALER_COST, PREMIUM_AMT, tr.TERM_KEY
                   ,effective_dt, exp_dt, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE
                   ,uw.UNDERWRITER_KEY
                   ,CONTRACT_SALES_CHANNEL_Key, COVERAGE_TIMING_STRATEGY_Key, DEDUCTIBLE
                   ,NEW_USED_IND, CURRENCY_CD, 0 as insert_audit_key
                   ---
                   , POLICY_TYPE_KEY, POLICY_GROUP_KEY
                   ---
                   ,age
                   ,PRODUCT_CAT_DESC, channel
             FROM
               (SELECT
                        policy_key   --Policy_SEQ.nextval as
                        ,BRAND
                        ,BRAND || ' Appliance Service plan - '  || TERM_COVERAGE_EXT || ' Year' as name
                        ,TERM_COVERAGE_EXT || ' yr ' || BRAND || ' Appliance Service plan ' ||
                            case when upper(channel) IN ('RENEWAL', 'RENEWAL PROGRAM') THEN '(RN)'
                                 when upper(channel) IN ('AM EB', 'AFTERMARKET') THEN '(AM)'
                                 when upper(channel) IN ('OOW', 'AFTERMARKET SWEEP') THEN '(AO)'
                                 else upper(channel)
                             END
                            as description
                        ,SKU AS POLICY_PRODUCT_XID
                        ,SKU || '-' || POLICY_KEY AS POLICY_LKP_XID --This is required/used when we are using existing SKUs to create new policy_keys
                        ,v.EFFECTIVE_DT, DATE '2099-12-31' AS EXP_DT
                        ,MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE
                        , 'USD' as CURRENCY_CD
                        , 1 AS POLICY_TYPE_KEY, 1 AS POLICY_GROUP_KEY
                        ,PRODUCT_CAT_DESC
                        ,RETAIL_PRICE_AMT
                        ,NULL as DEALER_COST
                        ,TWGIS_COST AS PREMIUM_AMT
                        , Age
                        ,TERM_COVERAGE_EXT * 365 AS Term_Days
                        ,3 AS CONTRACT_SALES_CHANNEL_Key
                        ,
                         case when upper(channel) IN ('RENEWAL', 'RENEWAL PROGRAM') THEN 1
                              when upper(channel) IN ('AM EB', 'AFTERMARKET') THEN 1
                              when upper(channel) IN ('OOW', 'AFTERMARKET SWEEP') THEN 3
                              else 1
                          END AS COVERAGE_TIMING_STRATEGY_Key

                        ,'REPAIR_AND_REPLACEMENT' AS RESOLUTION_TYPE
                        ,null as DEDUCTIBLE
                        ,'N' as NEW_USED_IND
                        ,'TWG' AS UNDERWRITER_NM
                        ,channel
                        ---
                   FROM RAW_PRICING_TBL v
                ) pri
                left join p_term_dim tr on (tr.day = pri.Term_Days)
                left join p_underwriter_tbl uw on (uw.name = pri.underwriter_nm);





select * FROM policy_lkp;
select * FROM policy_tbl;
select * FROM policy_ext_tbl;
select * FROM policy_fee_xref;
select * FROM policy_discount_tbl;

select Count(*) FROM policy_lkp;--900
select Count(*) FROM policy_lkp where SOURCE_SYSTEM_CD = 0;--450
select Count(*) FROM policy_lkp where SOURCE_SYSTEM_CD <> 0;--450
select Count(*) FROM policy_tbl;--450
select Count(*) FROM policy_ext_tbl;--450
select Count(*) FROM policy_fee_xref;--900
select Count(*) FROM policy_discount_tbl;--450
select Count(*) FROM policy_item_tbl;--450
select Count(*) FROM POLICY_COVERAGE_TBL;--900
select count( distinct POLICY_KEY),Count(*) FROM POLICY_COVERAGE_TBL;--900
+-------------------------+--------+
|COUNT(DISTINCTPOLICY_KEY)|COUNT(*)|
+-------------------------+--------+
|450                      |900     |
+-------------------------+--------+


select count(*) from t_and_c_contract_template_xref; --22950

select count( distinct tc.TERMS_AND_CONDITIONS_KEY),count( distinct tc.POSTAL_STATE_KEY),
       count( distinct tc.POLICY_KEY),count(*)
from t_and_c_contract_template_xref tc
;
+------------------------------------------+----------------------------------+----------------------------+--------+
|COUNT(DISTINCTTC.TERMS_AND_CONDITIONS_KEY)|COUNT(DISTINCTTC.POSTAL_STATE_KEY)|COUNT(DISTINCTTC.POLICY_KEY)|COUNT(*)|
+------------------------------------------+----------------------------------+----------------------------+--------+
|2                                         |51                                |450                         |22950   |
+------------------------------------------+----------------------------------+----------------------------+--------+


