
-- delete from RAW_PRICING_TBL;--450

select * from BOSCHPRICINGUPDATE092023;
+-------------+---------------------+---------+---+----+-----------------+-----------------+-----------+-------------+-------+
|SKU          |PRODUCT_CATEGORY     |BRAND    |AGE|TERM|MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|PREMIUM_AMT|OFFERED_PRICE|CHANNEL|
+-------------+---------------------+---------+---+----+-----------------+-----------------+-----------+-------------+-------+
|THCMJ12UU3075|Built-In Coffee Maker|Thermador|2  |1   |3500.00          |4999.99          |65.97      |197.91       |OOW    |
|THCMJ36UU3075|Built-In Coffee Maker|Thermador|2  |3   |3500.00          |4999.99          |209.88     |504.67       |OOW    |
|THCKU12UU3075|Cooking              |Thermador|2  |1   |17500.00         |19999.99         |117.05     |510.00       |OOW    |
|THCKU36UU3075|Cooking              |Thermador|2  |3   |17500.00         |19999.99         |348.35     |1375.00      |OOW    |
|THVTJ12UU3075|Ventilation          |Thermador|2  |1   |3500.00          |4999.99          |83.10      |170.00       |OOW    |
|THVTJ36UU3075|Ventilation          |Thermador|2  |3   |3500.00          |4999.99          |245.40     |460.00       |OOW    |
|BSCMH12UU3075|Built-In Coffee Maker|Bosch    |1  |1   |3000.00          |3499.99          |47.39      |170.00       |OOW    |
|BSCMH24UU3075|Built-In Coffee Maker|Bosch    |1  |2   |3000.00          |3499.99          |94.59      |320.00       |OOW    |
|BSCMH48UU3075|Built-In Coffee Maker|Bosch    |1  |4   |3000.00          |3499.99          |193.31     |600.00       |OOW    |
+-------------+---------------------+---------+---+----+-----------------+-----------------+-----------+-------------+-------+



-- insert into RAW_PRICING_TBL
-- (SKU , PRODUCT_CAT_DESC ,BRAND ,AGE ,TERM_COVERAGE_EXT ,MIN_PRODUCT_PRICE , MAX_PRODUCT_PRICE, TWGIS_COST, RETAIL_PRICE_AMT ,CURRENCY,CHANNEL,FILE_NM,OLD_POLICY_KEY)
-- select SKU ,PRODUCT_CATEGORY , BRAND , AGE , TERM , TO_NUMBER(Replace(MIN_PRODUCT_PRICE,',',''))  , TO_NUMBER(Replace(MAX_PRODUCT_PRICE,',',''))
-- , TO_NUMBER(Replace(PREMIUM_AMT,',','')) , TO_NUMBER(Replace(OFFERED_PRICE,',','')) ,'USD' , CHANNEL,'BOSCHPRICINGUPDATE092023',''
-- From BOSCHPRICINGUPDATE092023 where SKU is not null ;

select * from RAW_PRICING_TBL order by SKU;--9

select COUNT(*) from RAW_PRICING_TBL;--9

select COUNT(*),FILE_NM from RAW_PRICING_TBL
Group by FILE_NM;--
+--------+------------------------+
|COUNT(*)|FILE_NM                 |
+--------+------------------------+
|9       |BOSCHPRICINGUPDATE092023|
+--------+------------------------+





select  Distinct BRAND ,PRODUCT_CAT_DESC ,CHANNEL
from RAW_PRICING_TBL order by BRAND,PRODUCT_CAT_DESC;
+---------+---------------------+-------+
|BRAND    |PRODUCT_CAT_DESC     |CHANNEL|
+---------+---------------------+-------+
|Bosch    |Built-In Coffee Maker|OOW    |
|Thermador|Built-In Coffee Maker|OOW    |
|Thermador|Cooking              |OOW    |
|Thermador|Ventilation          |OOW    |
+---------+---------------------+-------+



select  Distinct PRODUCT_CAT_DESC
from RAW_PRICING_TBL order by PRODUCT_CAT_DESC;
+---------------------+
|PRODUCT_CAT_DESC     |
+---------------------+
|Built-In Coffee Maker|
|Cooking              |
|Ventilation          |
+---------------------+




select distinct PRODUCT_CAT_DESC from RAW_PRICING_TBL
    where PRODUCT_CAT_DESC not in (select  PRODUCT_CATEGORY_NM  from BOSH.PRODUCT_CATEGORY_DIM );



select  SKU , PRODUCT_CAT_DESC ,BRAND ,AGE ,TERM_COVERAGE_EXT ,MIN_PRODUCT_PRICE , MAX_PRODUCT_PRICE, TWGIS_COST, RETAIL_PRICE_AMT ,CURRENCY,CHANNEL
from RAW_PRICING_TBL;

select  SKU , PRODUCT_CAT_DESC ,  BRAND     , AGE     ,  TERM_COVERAGE_EXT ,
MIN_PRODUCT_PRICE ,   MAX_PRODUCT_PRICE  , TWGIS_COST  , RETAIL_PRICE_AMT ,
CURRENCY       , WAIT_PERIOD , PREMIUM , MARSH_FEE , ADMIN_FEE ,COMMENTS ,POLICY_KEY ,CHANNEL ,EFFECTIVE_DT --,OLD_POLICY_KEY
from BOSH.RAW_PRICING_TBL order by INSERT_AUDIT_KEY desc;

 update raw_pricing_tbl
               set    effective_dt = date '2023-11-13';



select * FROM policy_lkp;--9
select * FROM policy_tbl;--9
select * FROM policy_ext_tbl;--9
select * FROM policy_fee_xref;--18
select * FROM policy_discount_tbl;--9

select Count(*) FROM policy_lkp;--18
select Count(*) FROM policy_lkp where SOURCE_SYSTEM_CD = 0;--9
select Count(*) FROM policy_lkp where SOURCE_SYSTEM_CD <> 0;--9
select Count(*) FROM policy_tbl;--9
select Count(*) FROM policy_ext_tbl;--9
select Count(*) FROM policy_fee_xref;--18
select Count(*) FROM policy_discount_tbl;--9
select Count(*) FROM policy_item_tbl;--9
select Count(*) FROM POLICY_COVERAGE_TBL;--18
select count( distinct POLICY_KEY),Count(*) FROM POLICY_COVERAGE_TBL;--900
+-------------------------+--------+
|COUNT(DISTINCTPOLICY_KEY)|COUNT(*)|
+-------------------------+--------+
|9                        |18      |
+-------------------------+--------+



select count(*) from t_and_c_contract_template_xref; --459

select count( distinct tc.TERMS_AND_CONDITIONS_KEY),count( distinct tc.POSTAL_STATE_KEY),
       count( distinct tc.POLICY_KEY),count(*)
from t_and_c_contract_template_xref tc
;
+------------------------------------------+----------------------------------+----------------------------+--------+
|COUNT(DISTINCTTC.TERMS_AND_CONDITIONS_KEY)|COUNT(DISTINCTTC.POSTAL_STATE_KEY)|COUNT(DISTINCTTC.POLICY_KEY)|COUNT(*)|
+------------------------------------------+----------------------------------+----------------------------+--------+
|2                                         |51                                |9                           |459     |
+------------------------------------------+----------------------------------+----------------------------+--------+

select count(*) from PRODUCT_PRICE_DIM; --90

-- BEGIN BOSHSTG.PROC_PRODUCT_PRICING; END;




select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join policy_tbl pol on (pol.policy_key = ppd.policy_key)
-- where  pricing_scheme_key = 78
-- where  PRICING_SCHEME_KEY in ( 61, 62, 74)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;

+-------------------+------------------+-------------------+---+-----------------------+-----+
|PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE|COUNT(DISTINCTTERM_KEY)|TERMS|
+-------------------+------------------+-------------------+---+-----------------------+-----+
|OOW                |159               |AO Thermador       |2  |2                      |1, 3 |
|OOW                |183               |RO 3 Thermador     |2  |2                      |1, 3 |
|OOW                |184               |RO 4 Thermador     |2  |1                      |1    |
|OOW                |185               |RO 5 Thermador     |2  |1                      |1    |
|OOW                |186               |RO 6 Thermador     |2  |2                      |1, 3 |
|OOW                |187               |RO 7 Thermador     |2  |1                      |1    |
|OOW                |188               |RO 8 Thermador     |2  |1                      |1    |
+-------------------+------------------+-------------------+---+-----------------------+-----+
+-------------------+------------------+-------------------+---+-----------------------+-----+
|PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE|COUNT(DISTINCTTERM_KEY)|TERMS|
+-------------------+------------------+-------------------+---+-----------------------+-----+
|OOW                |159               |AO Thermador       |2  |2                      |1, 3 |
|OOW                |183               |RO 3 Thermador     |2  |2                      |1, 3 |
|OOW                |184               |RO 4 Thermador     |2  |1                      |1    |
|OOW                |185               |RO 5 Thermador     |2  |1                      |1    |
|OOW                |186               |RO 6 Thermador     |2  |2                      |1, 3 |
|OOW                |187               |RO 7 Thermador     |2  |1                      |1    |
|OOW                |188               |RO 8 Thermador     |2  |1                      |1    |
+-------------------+------------------+-------------------+---+-----------------------+-----+


select PT.POLICY_PRODUCT_XID,PFX.POLICY_FEE_VALUE from POLICY_FEE_XREF PFX
        JOIN POLICY_TBL PT on PFX.POLICY_KEY = PT.POLICY_KEY
        Where PT.POLICY_PRODUCT_XID in (
'THCMJ12UU3075','THCMJ36UU3075','THCKU12UU3075','THCKU36UU3075',
'THVTJ12UU3075','THVTJ36UU3075','BSCMH12UU3075','BSCMH24UU3075','BSCMH48UU3075'
) and PFX.POLICY_FEE_TYPE_KEY = 1
Order by PT.POLICY_PRODUCT_XID;
+------------------+----------------+
|POLICY_PRODUCT_XID|POLICY_FEE_VALUE|
+------------------+----------------+
|BSCMH12UU3075     |170.00          |
|BSCMH24UU3075     |320.00          |
|BSCMH48UU3075     |600.00          |
|THCKU12UU3075     |510.00          |
|THCKU36UU3075     |1375.00         |
|THCMJ12UU3075     |197.91          |
|THCMJ36UU3075     |504.67          |
|THVTJ12UU3075     |170.00          |
|THVTJ36UU3075     |460.00          |
+------------------+----------------+
    --Old RETAIL_PRICE_AMT showing below
+------------------+----------------+
|POLICY_PRODUCT_XID|POLICY_FEE_VALUE|
+------------------+----------------+
|BSCMH12UU3075     |170.00          |
|BSCMH24UU3075     |320.00          |
|BSCMH48UU3075     |600.00          |
|THCKU12UU3075     |683.00          |
|THCKU36UU3075     |2070.00         |
|THCMJ12UU3075     |377.00          |
|THCMJ36UU3075     |1239.00         |
|THVTJ12UU3075     |480.00          |
|THVTJ36UU3075     |1452.00         |
+------------------+----------------+



select PT.POLICY_PRODUCT_XID,PFX.POLICY_FEE_VALUE from POLICY_FEE_XREF PFX
        JOIN POLICY_TBL PT on PFX.POLICY_KEY = PT.POLICY_KEY
        Where PT.POLICY_PRODUCT_XID in (
'THCMJ12UU3075','THCMJ36UU3075','THCKU12UU3075','THCKU36UU3075',
'THVTJ12UU3075','THVTJ36UU3075','BSCMH12UU3075','BSCMH24UU3075','BSCMH48UU3075'
) and PFX.POLICY_FEE_TYPE_KEY = 3
Order by PT.POLICY_PRODUCT_XID;
+------------------+----------------+
|POLICY_PRODUCT_XID|POLICY_FEE_VALUE|
+------------------+----------------+
|BSCMH12UU3075     |47.39           |
|BSCMH24UU3075     |94.59           |
|BSCMH48UU3075     |193.31          |
|THCKU12UU3075     |117.05          |
|THCKU36UU3075     |348.35          |
|THCMJ12UU3075     |65.97           |
|THCMJ36UU3075     |209.88          |
|THVTJ12UU3075     |83.10           |
|THVTJ36UU3075     |245.40          |
+------------------+----------------+
--old PREMIUM_AMT
+------------------+----------------+
|POLICY_PRODUCT_XID|POLICY_FEE_VALUE|
+------------------+----------------+
|BSCMH12UU3075     |90.28           |
|BSCMH24UU3075     |184.42          |
|BSCMH48UU3075     |381.61          |
|THCKU12UU3075     |341.64          |
|THCKU36UU3075     |1035.04         |
|THCMJ12UU3075     |188.42          |
|THCMJ36UU3075     |619.65          |
|THVTJ12UU3075     |239.81          |
|THVTJ36UU3075     |726.20          |
+------------------+----------------+

