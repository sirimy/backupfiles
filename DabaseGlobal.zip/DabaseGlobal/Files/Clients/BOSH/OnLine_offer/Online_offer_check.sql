SELECT SERIALIZED_ITEM_ID, PE_PRODUCT_COVERAGE_END_DT  , CASE WHEN si_LATEST_COVERAGE_EXP_DT> LOCALTIMESTAMP
			                                            THEN  date_trunc('day',si_LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt_TERM_MONTHS * interval '1 month'
			                                            WHEN si_LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
                                                        THEN  date_trunc('day', LOCALTIMESTAMP) + ppt_TERM_MONTHS * interval '1 month'
                                                                  ELSE
                                                              date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt_TERM_MONTHS * interval '1 month'
                                                      END

			       , substr(pst_description, 1, 2), round(DATE_PART('day', si_LATEST_COVERAGE_EXP_DT - si_purchase_dt)/365), case when substr(pst_description, 1, 2) = 'RN'
                             then  round(DATE_PART('day', si_LATEST_COVERAGE_EXP_DT - si_purchase_dt)/365)
				             else 0
				             end, coalesce (pol_age, 0)
 FROM ( SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'
				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day', LOCALTIMESTAMP)
			          ELSE
				       date_trunc('day', LOCALTIMESTAMP)+interval '1 days'
			     END AS coverage_start_dt,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
			          THEN
			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
                                  ELSE
				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
			     END AS coverage_end_dt,
			     ppt.BASE_PRICE_AMT,
			     ppt.TERM_MONTHS,
			     si.purchase_dt,
			     pol.age,
			     round(DATE_PART('day', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
			     pol.description as policy_description,
			     PE.PRODUCT_COVERAGE_END_DT as PE_PRODUCT_COVERAGE_END_DT,
			     si.LATEST_COVERAGE_EXP_DT AS si_LATEST_COVERAGE_EXP_DT,ppt.TERM_MONTHS  AS ppt_TERM_MONTHS ,
			     pst.description as pst_description,si.purchase_dt AS si_purchase_dt,pol.age AS pol_age

			FROM
                    (SELECT * from serialized_item where serialized_item_id in(198075371 )  ) si
                    JOIN pricing_scheme_lkp psl  ON(si.latest_coverage_type_id=psl.latest_coverage_type_id
                                                        and  (EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
                                                            between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
                    JOIN product_price_tbl ppt ON
                                            (  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') -- BOSH-361
                    JOIN policy pol ON   (ppt.POLICY_ID=pol.POLICY_ID )
			        JOIN product_ext PE ON  (PE.product_id = ppt.product_id)
			        join pricing_scheme_tbl pst  on pst.pricing_scheme_id = ppt.pricing_scheme_id
WHERE
			        PE.PRODUCT_COVERAGE_END_DT  >= CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
			                                            THEN  date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
			                                            WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
                                                        THEN  date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'
                                                                  ELSE
                                                              date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
                                                      END

			        and case when substr(pst.description, 1, 2) = 'RN'
                             then  round(DATE_PART('day', si.latest_coverage_exp_dt - si.purchase_dt)/365)
				             else 0
				             end = coalesce (pol.age, 0)
			) t
    where (coverage_end_dt - purchase_dt)  <= interval '3650 day'    --total coverage must be less than 10 years for all brands
    ORDER BY TERM_MONTHS ASC;
--,21706488,21970488,22754086,22602544,22598054,22593858


select distinct description,age,effective_dt,exp_dt  from policy where   description like '%AO%'
                                                                   and exp_dt > now() order by effective_dt desc;

select distinct description,effective_dt ,age from policy where  description like '%AM%'
                  ;


select pst.description,pol.description,S.* from (
        select ppt.pricing_scheme_id,ppt.product_id,ppt.policy_id,ppt.term_months  FROM
            (SELECT * from serialized_item where serialized_item_id in(198075371)  ) si
            JOIN pricing_scheme_lkp psl  ON(si.latest_coverage_type_id=psl.latest_coverage_type_id
                                            and  (EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
                                                between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
            JOIN product_price_tbl ppt ON
                    (  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y')
     ) S JOIN pricing_scheme_tbl pst on pst.pricing_scheme_id = S.pricing_scheme_id
         JOIN policy pol on pol.policy_id = S.policy_id     ;
+------------+---------------------------------------+-----------------+----------+---------+-----------+
|description |description                            |pricing_scheme_id|product_id|policy_id|term_months|
+------------+---------------------------------------+-----------------+----------+---------+-----------+
|EB Bosch-ACM|12 yr Bosch Appliance Service plan (AM)|222              |22141406  |6582     |12         |
|EB Bosch-ACM|24 yr Bosch Appliance Service plan (AM)|222              |22141406  |6583     |24         |
|EB Bosch-ACM|48 yr Bosch Appliance Service plan (AM)|222              |22141406  |6584     |48         |
|EB Bosch-ACM|72 yr Bosch Appliance Service plan (AM)|222              |22141406  |6586     |72         |
+------------+---------------------------------------+-----------------+----------+---------+-----------+


select distinct pricing_scheme_id from product_price_tbl where product_id in (SELECT product_id from serialized_item where serialized_item_id in(198075371,21706488,21970488,22754086,22602544,22598054,22593858) );
+-----------------+
|pricing_scheme_id|
+-----------------+
|220              |
|221              |
|222              |
+-----------------+


SELECT * FROM pricing_scheme_tbl WHERE  end_dt > now() order by pricing_scheme_id;
+-----------------+------------+------------+
|pricing_scheme_id|name        |description |
+-----------------+------------+------------+
|151              |AM Bosch    |AM Bosch    |
|152              |AM Gaggenau |AM Gaggenau |
|153              |AM Thermador|AM Thermador|
|154              |EB Bosch    |EB Bosch    |
|155              |EB Gaggenau |EB Gaggenau |
|156              |EB Thermador|EB Thermador|
|157              |AO Bosch    |AO Bosch    |
|158              |AO Gaggenau |AO Gaggenau |
|159              |AO Thermador|AO Thermador|
+-----------------+------------+------------+

SELECT * FROM pricing_scheme_tbl WHERE description IN( 'EB Bosch','AM Bosch','AO Bosch')
and end_dt > now();
+-----------------+--------+-----------+---------------+--------------------------+
|pricing_scheme_id|name    |description|last_updated_by|last_updated_ts           |
+-----------------+--------+-----------+---------------+--------------------------+
|157              |AO Bosch|AO Bosch   |bosh           |2023-08-24 10:57:37.247200|
|151              |AM Bosch|AM Bosch   |bosh           |2023-08-24 10:57:37.247200|
|154              |EB Bosch|EB Bosch   |bosh           |2023-08-24 10:57:37.247200|
+-----------------+--------+-----------+---------------+--------------------------+
SELECT * FROM pricing_scheme_tbl WHERE pricing_scheme_id IN(159,153,156) order by pricing_scheme_id;
+-----------------+------------+------------+
|pricing_scheme_id|name        |description |
+-----------------+------------+------------+
|153              |AM Thermador|AM Thermador|
|156              |EB Thermador|EB Thermador|
|159              |AO Thermador|AO Thermador|
+-----------------+------------+------------+

INSERT INTO PRICING_SCHEME_LKP
SELECT latest_coverage_type_id   ,
    days_from_covrg_low      ,
    days_from_covrg_high     ,
    221        ,
    'BOSH-1589'         ,
    now()        FROM PRICING_SCHEME_LKP where pricing_scheme_id IN(159);

INSERT INTO PRICING_SCHEME_LKP
SELECT latest_coverage_type_id   ,
    days_from_covrg_low      ,
    days_from_covrg_high     ,
    220        ,
    'BOSH-1589'           ,
    now()        FROM PRICING_SCHEME_LKP where pricing_scheme_id IN(153);

INSERT INTO PRICING_SCHEME_LKP
SELECT latest_coverage_type_id   ,
    days_from_covrg_low      ,
    days_from_covrg_high     ,
    222        ,
    'BOSH-1589'           ,
    now()        FROM PRICING_SCHEME_LKP where pricing_scheme_id IN(156);

+-----------------------+-------------------+--------------------+-----------------+---------------+--------------------------+
|latest_coverage_type_id|days_from_covrg_low|days_from_covrg_high|pricing_scheme_id|last_updated_by|last_updated_ts           |
+-----------------------+-------------------+--------------------+-----------------+---------------+--------------------------+
|1                      |1                  |365                 |157              |BOSH-1140      |2023-02-16 10:49:09.269400|
|1                      |-365               |-84                 |154              |BOSH-1140      |2023-02-16 10:49:09.269400|
|1                      |-83                |0                   |151              |BOSH-1140      |2023-02-16 10:49:09.269400|
+-----------------------+-------------------+--------------------+-----------------+---------------+--------------------------+

    COMMIT;

update policy set age = NULL where  policy_id >= 6550 --description like '%AM%'
                 and exp_dt > now();

  COMMIT;