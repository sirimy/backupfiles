 /******************************************************************************
   Case Details: When Sync process fail at Contract_Order



  */