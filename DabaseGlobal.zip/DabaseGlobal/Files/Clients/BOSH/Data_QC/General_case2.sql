
-- Find Order with multiple items Where Count of order items is more than distinct count of SI_Key
    --also check if Active orders only

 select ORDER_KEY,
        COUNT(ORDER_LINE_KEY),
        COUNT(distinct SERIALIZED_ITEM_KEY )
        from BOSH.ORDER_ITEM_TBL
        where ORDER_KEY in(
                            select oit.ORDER_KEY from BOSH.ORDER_ITEM_TBL OIT
                                where OIT.COVERAGE_EXP_DT > sysdate
                                GROUP BY  oit.ORDER_KEY
                                Having  COUNT(oit.ORDER_KEY) > 1
                            )
GROUP BY ORDER_KEY
Having COUNT(ORDER_LINE_KEY) <> COUNT(distinct SERIALIZED_ITEM_KEY )
;
+---------+---------------------+----------------------------------+
|ORDER_KEY|COUNT(ORDER_LINE_KEY)|COUNT(DISTINCTSERIALIZED_ITEM_KEY)|
+---------+---------------------+----------------------------------+
|315759   |6                    |5                                 |
|376383   |2                    |1                                 |
|375823   |2                    |1                                 |
|363729   |6                    |5                                 |
|278783   |4                    |3                                 |
+---------+---------------------+----------------------------------+





select ':' || SI_XID || ':,' from BOSH.SERIALIZED_ITEM_LKP where SI_XID in (
    select SI_XID from BOSH.SERIALIZED_ITEM_LKP where SI_KEY in (
                        select distinct si_key

                        from (
                              select si.si_key, count(distinct ccx.contract_key), min(CREATION_DT) AS CREATION_DT
                                from p_serialized_item_dim si
                                     join p_contract_coverage_xref ccx on ccx.si_key = si.si_key
                                     join p_contract_lkp clkp on clkp.contract_key = ccx.contract_key
                                     join p_contract_dim con on con.contract_key = clkp.contract_key
                                     left join p_policy_ext_tbl pex ON (pex.policy_key = con.policy_key)
                                     join AUDIT_TBL att on att.AUDIT_KEY = con.INSERT_AUDIT_KEY
                              where ccx.coverage_type_key = 2
                                and con.retail_amt > 1
                                --AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                                and con.contract_status_key NOT IN (2, 3, 4, 5)
                                AND exists (
                                        select ccx3.si_key
                                        from
                                                p_contract_coverage_xref ccx3
                                                join p_contract_lkp clkp3 on clkp3.contract_key = ccx3.contract_key
                                                join p_contract_dim con3 on con3.contract_key = clkp3.contract_key
                                                left join p_contract_status_dim cons3 on (cons3.contract_status_key = con3.contract_status_key)
                                                join p_policy_ext_tbl pex3 ON (pex3.policy_key = con3.policy_key)
                                        where
                                              ccx3.coverage_type_key = 2
                                        and ccx3.si_key  = ccx.si_key
                                        and con3.contract_key <> con.contract_key
                                        and
                                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                                             or
                                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                                             or
                                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                                             or
                                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                                            )
                                        and con3.retail_amt > 1
                                        AND con3.contract_status_key NOT IN (2, 3, 4, 5)   --canceled/fulfilled/expired
                                        and pex3.channels = pex.channels
                                        and con3.contract_end_dt >= trunc(sysdate) - 30
                                       )
                                AND att.CREATION_DT > SYSDATE - 366
                              group by si.si_key
                             having count(distinct ccx.contract_key) >= 2
                            )
        )
    )
and SOURCE_SYSTEM_CD = 0
GROUP BY SI_XID
Having COUNT(SI_XID) = 1
;


Select * from BOSH.CONTRACT_COVERAGE_XREF where SI_KEY in (
     select distinct SI_KEY from BOSH.SERIALIZED_ITEM_LKP
    where SI_XID in(
    'SHEM63W55N/xx-20180601-T3296341',
    'SHV88PZ63N/xx-20191213-T1979687',
    'SGSX305TS/xx-20190825-T2710443',
    'SHS843AF5N/xx-20201027-T4623882',
    'DWHD770WPR/xx-20230403-T7638515',
    'T30IR905SP/xx-20230403-T7638515',
    'SHEM63W55N/xx-20191109-T4039120',
    'SPX68U55UC/42-20171116-IW3068218299',
    'SHPM78Z55N/01-20210101-T6289491',
    'DWHD650WFP/xx-20220401-T7317375',
    'DWHD770WFM/01-20210708-T6759240',
    'SHEM63W55N/xx-20230215-T7701736',
    'SHEM63W55N/xx-20230714-T7934120',
    'HMV5053U/xx-20240320-T8552280',
    'SHP9PCM5N/xx-20240325-REG252156961',
    'SHE3AEM6N/33-20240401-T8569179',
    'SHP865YP5N/xx-20190801-T3884217',
    'SHSM63W52N/13-20200615-T4319913',
    'B36CD50SNS/xx-20201118-T4634643',
    'B36CT80SNS/02-20220913-T7510087',
    'SHXM78Z55N/xx-20230614-T7947399',
    'SHP78CM5N/xx-20230927-T8129712',
    'SHX78CM5N/xx-20231113-REG249012799',
    'SHPM65W55N/10-20190326-T3660439',
    'SHP865WD5N/xx-20190807-T3834218',
    'SHPM65Z55N/xx-20210503-T5056881',
    'SHE53C82N/xx-20231004-T8268615',
    'SHXM4AY55N/xx-20240110-T8543475',
    'SHXM4AY55N/xx-20200101-T4092257',
    'SHX3AR72UC/22-20190618-T3780971',
    'SHX863WD5N/13-20190827-T3868684',
    'SHPM65Z55N/xx-20200103-T4068585',
    'WTG86403UC/xx-20210501-T4922172',
    'T36IB900SP/12-20210529-T4988658',
    'SHXM78Z55N/20-20230218-T7728821',
    'SHP65CM5N/xx-20231001-T8102690',
    'SHE53C85N/xx-20231101-T8187965',
    'SGSP365TS/xx-20230809-T8257682',
    'T24IF905SP/21-20230807-T8086136',
    'SHP78CM6N/22-20240401-T8588593',
    'SHV88PZ63N/xx-20191213-923402',
    'VCIN48GWS/xx-20220916-T7278355',
    'SHPM78Z55N/01-20210511-T4920783',
    'SHE3AR72UC/31-20231115-T8223571',
    'DWHD440MFP/xx-20190101-T3588850',
    'SHV88PZ63N/xx-20191213-14345897',
    'SHX3AR75UC/25-20200104-T4110285',
    'HGI8056UC/03-20210302-IW1528201010'

    )
    and SOURCE_SYSTEM_CD = 0
   )
and COVERAGE_END_DT > sysdate
and COVERAGE_START_DT > sysdate-365
and COVERAGE_TYPE_KEY = 2
ORDER BY SI_KEY

;



select distinct  OIT.ORDER_KEY,OT.PURCHASE_DT,CD.CONTRACT_KEY,CD.CONTRACT_STATUS_KEY,CD.CONTRACT_SALE_DT
     ,OIT.SERIALIZED_ITEM_KEY,PTT.PAYMENT_AMT,PTT.PAYMENT_TYPE from  BOSH.ORDER_ITEM_TBL OIT
                LEFT JOIN BOSH.ORDER_TBL OT ON OT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_ORDER_TBL COT ON  COT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_DIM CD ON  COT.CONTRACT_KEY = CD.CONTRACT_KEY
                LEFT JOIN BOSH.PAYMENT_TX_TBL PTT ON PTT.ORDER_KEY = OIT.ORDER_KEY
          where   COT.CONTRACT_KEY in (
                                 Select CCX.CONTRACT_KEY from BOSH.CONTRACT_COVERAGE_XREF CCX where SI_KEY in (
                                     select distinct SI_KEY from BOSH.SERIALIZED_ITEM_LKP
                                    where SI_XID in(
                                    'SHEM63W55N/xx-20180601-T3296341',
                                    'SHV88PZ63N/xx-20191213-T1979687',
                                    'SGSX305TS/xx-20190825-T2710443',
                                    'SHS843AF5N/xx-20201027-T4623882',
                                    'DWHD770WPR/xx-20230403-T7638515',
                                    'T30IR905SP/xx-20230403-T7638515',
                                    'SHEM63W55N/xx-20191109-T4039120',
                                    'SPX68U55UC/42-20171116-IW3068218299',
                                    'SHPM78Z55N/01-20210101-T6289491',
                                    'DWHD650WFP/xx-20220401-T7317375',
                                    'DWHD770WFM/01-20210708-T6759240',
                                    'SHEM63W55N/xx-20230215-T7701736',
                                    'SHEM63W55N/xx-20230714-T7934120',
                                    'HMV5053U/xx-20240320-T8552280',
                                    'SHP9PCM5N/xx-20240325-REG252156961',
                                    'SHE3AEM6N/33-20240401-T8569179',
                                    'SHP865YP5N/xx-20190801-T3884217',
                                    'SHSM63W52N/13-20200615-T4319913',
                                    'B36CD50SNS/xx-20201118-T4634643',
                                    'B36CT80SNS/02-20220913-T7510087',
                                    'SHXM78Z55N/xx-20230614-T7947399',
                                    'SHP78CM5N/xx-20230927-T8129712',
                                    'SHX78CM5N/xx-20231113-REG249012799',
                                    'SHPM65W55N/10-20190326-T3660439',
                                    'SHP865WD5N/xx-20190807-T3834218',
                                    'SHPM65Z55N/xx-20210503-T5056881',
                                    'SHE53C82N/xx-20231004-T8268615',
                                    'SHXM4AY55N/xx-20240110-T8543475',
                                    'SHXM4AY55N/xx-20200101-T4092257',
                                    'SHX3AR72UC/22-20190618-T3780971',
                                    'SHX863WD5N/13-20190827-T3868684',
                                    'SHPM65Z55N/xx-20200103-T4068585',
                                    'WTG86403UC/xx-20210501-T4922172',
                                    'T36IB900SP/12-20210529-T4988658',
                                    'SHXM78Z55N/20-20230218-T7728821',
                                    'SHP65CM5N/xx-20231001-T8102690',
                                    'SHE53C85N/xx-20231101-T8187965',
                                    'SGSP365TS/xx-20230809-T8257682',
                                    'T24IF905SP/21-20230807-T8086136',
                                    'SHP78CM6N/22-20240401-T8588593',
                                    'SHV88PZ63N/xx-20191213-923402',
                                    'VCIN48GWS/xx-20220916-T7278355',
                                    'SHPM78Z55N/01-20210511-T4920783',
                                    'SHE3AR72UC/31-20231115-T8223571',
                                    'DWHD440MFP/xx-20190101-T3588850',
                                    'SHV88PZ63N/xx-20191213-14345897',
                                    'SHX3AR75UC/25-20200104-T4110285',
                                    'HGI8056UC/03-20210302-IW1528201010'

                                    )
                                    and SOURCE_SYSTEM_CD = 0
                                   )
                                and COVERAGE_END_DT > sysdate
                                and COVERAGE_START_DT > sysdate-365
                                and COVERAGE_TYPE_KEY = 2

              )
ORDER BY OIT.SERIALIZED_ITEM_KEY
;




--Duplicate SI_KEY = 3048218
select  * from  BOSH.CONTRACT_DIM where CONTRACT_KEY in (181628,178565);
+------------+-------------------+----------------+-----------------+---------------+----------+----------+
|CONTRACT_KEY|CONTRACT_STATUS_KEY|CONTRACT_SALE_DT|CONTRACT_START_DT|CONTRACT_END_DT|RETAIL_AMT|POLICY_KEY|
+------------+-------------------+----------------+-----------------+---------------+----------+----------+
|178565      |1                  |2024-01-25      |2024-04-01       |2025-04-01     |80.50     |3016      |
|181628      |1                  |2024-03-08      |2024-04-01       |2025-04-01     |80.50     |3016      |
+------------+-------------------+----------------+-----------------+---------------+----------+----------+
select  * from  BOSH.POLICY_TBL where  POLICY_KEY in (3016);
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+
|POLICY_KEY|NAME                                     |DESCRIPTION                               |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+
|3016      |Thermador Appliance Service plan - 1 Year|1 yr Thermador Appliance Service plan (AM)|THDHD36U          |2022-01-01  |2099-12-31|
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+

select  * from  BOSH.ORDER_ITEM_TBL where ORDER_KEY in (
        select  ORDER_KEY from  BOSH.CONTRACT_ORDER_TBL where CONTRACT_KEY in (181628,178565)
)
;
+---------+--------------+-------------+--------------+-------------------+----------+--------------------------+--------------------------+--------------------------+
|ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY    |OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|POLICY_KEY|COVERAGE_START_DT         |PURCHASE_DT               |COVERAGE_EXP_DT           |
+---------+--------------+-------------+--------------+-------------------+----------+--------------------------+--------------------------+--------------------------+
|387155   |1             |9238839001005|1             |3048218            |3016      |2024-04-01 00:00:00.000000|2024-01-25 00:00:00.000000|2025-04-01 00:00:00.000000|
|393573   |1             |9238839001050|1             |3048218            |3016      |2024-04-01 00:00:00.000000|2024-03-08 00:00:00.000000|2025-04-01 00:00:00.000000|
+---------+--------------+-------------+--------------+-------------------+----------+--------------------------+--------------------------+--------------------------+
-- Same si_key if payment
-- Payment_Tx table against order_id



    select  * from  BOSH.ORDER_TBL where ORDER_KEY in (
        select  ORDER_KEY from  BOSH.CONTRACT_ORDER_TBL where CONTRACT_KEY in (181628,178565)
)
;
+---------+---------+-------------------+--------------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+----------------+----------------+-------------------+----------+-----------------+----------------+------------------+------------------+--------------+-----------+--------------------------+
|ORDER_KEY|ORDER_XID|BILLING_PROFILE_KEY|CREATED_BY          |PURCHASE_DT               |CALL_CENTER_FLAG|SUB_TOTAL_AMT|TAX_AMT|TAX_COUNTY|SURCHARGE_AMT|SHIPPING_AND_HANDLING_AMT|TOTAL_AMT|VISITOR_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SALES_SOURCE_CD    |OUTLET_KEY|SURCHARGE_TYPE_CD|ORDER_STATUS_KEY|ORDER_DISCOUNT_AMT|ORDER_DISCOUNT_KEY|SYNC_AUDIT_KEY|CURRENCY_CD|CREATED_TS                |
+---------+---------+-------------------+--------------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+----------------+----------------+-------------------+----------+-----------------+----------------+------------------+------------------+--------------+-----------+--------------------------+
|387155   |3366794  |NULL               |godoi@afterinc.com  |2024-01-25 00:00:00.000000|Y               |80.50        |0.00   |ORANGE    |0.00         |0.00                     |80.50    |2294858    |777002          |789203          |MAIL_IN_CHECK_SALES|NULL      |NULL             |NULL            |NULL              |NULL              |789203        |USD        |2024-02-01 16:47:23.520000|
|393573   |3370003  |NULL               |ebriggs@afterinc.com|2024-03-08 00:00:00.000000|Y               |80.50        |0.00   |ORANGE    |0.00         |0.00                     |80.50    |2294858    |789150          |NULL            |MAIL_IN_CHECK_SALES|NULL      |NULL             |NULL            |NULL              |NULL              |789203        |USD        |2024-03-14 19:50:56.922000|
+---------+---------+-------------------+--------------------+--------------------------+----------------+-------------+-------+----------+-------------+-------------------------+---------+-----------+----------------+----------------+-------------------+----------+-----------------+----------------+------------------+------------------+--------------+-----------+--------------------------+

    select  * from  BOSH.PAYMENT_TX_TBL where ORDER_KEY in (
        select  ORDER_KEY from  BOSH.CONTRACT_ORDER_TBL where CONTRACT_KEY in (181628,178565)
)
;

select * from BOSH.ORDER_LKP where ORDER_KEY in (
        select  ORDER_KEY from  BOSH.CONTRACT_ORDER_TBL where CONTRACT_KEY in (181628,178565)
)
;

select  OIT.ORDER_KEY,OT.PURCHASE_DT,CD.CONTRACT_KEY,CD.CONTRACT_STATUS_KEY,CD.CONTRACT_SALE_DT
     ,OIT.SERIALIZED_ITEM_KEY,PTT.PAYMENT_AMT,PTT.PAYMENT_TYPE from  BOSH.ORDER_ITEM_TBL OIT
                LEFT JOIN BOSH.ORDER_TBL OT ON OT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_ORDER_TBL COT ON  COT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_DIM CD ON  COT.CONTRACT_KEY = CD.CONTRACT_KEY
                LEFT JOIN BOSH.PAYMENT_TX_TBL PTT ON PTT.ORDER_KEY = OIT.ORDER_KEY
          where   COT.CONTRACT_KEY in (181628,178565)

;
select distinct OIT.ORDER_KEY,COT.ORDER_LINE_KEY,
                SID.LATEST_COVERAGE_TYPE,SID.LATEST_COVERAGE_EXP_DT,
                OT.PURCHASE_DT,CD.CONTRACT_KEY,CD.CONTRACT_STATUS_KEY
                ,CD.CONTRACT_SALE_DT
                ,OIT.SERIALIZED_ITEM_KEY
                --,PTT.PAYMENT_AMT
                ,PTT.PAYMENT_TYPE
                ,CCD.CANCEL_DT,RCCT.CANCEL_REASON,RCCT.CANCELLATION_DATE
from  BOSH.ORDER_ITEM_TBL OIT
                LEFT JOIN BOSH.SERIALIZED_ITEM_DIM SID ON SID.SI_KEY = OIT.SERIALIZED_ITEM_KEY
                LEFT JOIN BOSH.ORDER_TBL OT ON OT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_ORDER_TBL COT ON  COT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_DIM CD ON  COT.CONTRACT_KEY = CD.CONTRACT_KEY
                LEFT JOIN BOSH.PAYMENT_TX_TBL PTT ON PTT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_CANCELLATION_DIM CCD on CCD.CONTRACT_KEY = CD.CONTRACT_KEY
                LEFT JOIN RAW_CONTRACT_CANCELS_TBL RCCT ON RCCT.UNIQUE_IDENTIFIER = OIT.ORDER_KEY || '-' || OIT.ORDER_LINE_KEY
          where   COT.CONTRACT_KEY in (181628,178565)
order by SERIALIZED_ITEM_KEY
;



-- Find Order with multiple items Where Count of order items is more than distinct count of SI_Key
    --also check if Active orders only



select * from BOSH.SERIALIZED_ITEM_LKP where SI_KEY in (3048218);

select distinct ORDER_STATUS_KEY from BOSH.ORDER_TBL;

--Duplicate SI_KEY = 3177095
select  * from  BOSH.CONTRACT_COVERAGE_XREF where CONTRACT_KEY in (171991,172023) and COVERAGE_TYPE_KEY = 2;
+------------+-----------------+---------------------+-------+--------------------------+--------------------------+
|CONTRACT_KEY|COVERAGE_TYPE_KEY|COVERED_COMPONENT_KEY|SI_KEY |COVERAGE_START_DT         |COVERAGE_END_DT           |
+------------+-----------------+---------------------+-------+--------------------------+--------------------------+
|171991      |2                |1                    |3177095|2023-11-01 00:00:00.000000|2032-10-30 00:00:00.000000|
|172023      |2                |1                    |3177095|2023-11-01 00:00:00.000000|2032-10-30 00:00:00.000000|
+------------+-----------------+---------------------+-------+--------------------------+--------------------------+
select distinct OIT.ORDER_KEY,COT.ORDER_LINE_KEY,OT.PURCHASE_DT,CD.CONTRACT_KEY,CD.CONTRACT_STATUS_KEY
                ,CD.CONTRACT_SALE_DT
                ,OIT.SERIALIZED_ITEM_KEY
                --,PTT.PAYMENT_AMT
                ,PTT.PAYMENT_TYPE,RCCT.CANCEL_REASON,RCCT.CANCELLATION_DATE
from  BOSH.ORDER_ITEM_TBL OIT
                LEFT JOIN BOSH.ORDER_TBL OT ON OT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_ORDER_TBL COT ON  COT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_DIM CD ON  COT.CONTRACT_KEY = CD.CONTRACT_KEY
                LEFT JOIN BOSH.PAYMENT_TX_TBL PTT ON PTT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN RAW_CONTRACT_CANCELS_TBL RCCT ON RCCT.UNIQUE_IDENTIFIER = OIT.ORDER_KEY || '-' || OIT.ORDER_LINE_KEY
          where   COT.CONTRACT_KEY in (171991,172023)
order by SERIALIZED_ITEM_KEY
;
select  * from  BOSH.CONTRACT_DIM where CONTRACT_KEY in (171991,172023);
+------------+-------------------+----------------+-----------------+---------------+----------+--------------+----------+
|CONTRACT_KEY|CONTRACT_STATUS_KEY|CONTRACT_SALE_DT|CONTRACT_START_DT|CONTRACT_END_DT|RETAIL_AMT|RETAIL_TAX_AMT|POLICY_KEY|
+------------+-------------------+----------------+-----------------+---------------+----------+--------------+----------+
|171991      |1                  |2023-11-01      |2023-12-01       |2026-11-01     |839.16    |50.35         |3127      |
|172023      |1                  |2023-11-01      |2023-12-01       |2026-11-01     |839.16    |50.35         |3127      |
+------------+-------------------+----------------+-----------------+---------------+----------+--------------+----------+

select  * from  BOSH.POLICY_TBL where  POLICY_KEY in (3127);
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+
|POLICY_KEY|NAME                                     |DESCRIPTION                               |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+
|3127      |Thermador Appliance Service plan - 3 Year|3 yr Thermador Appliance Service plan (AO)|THFGN36UU3075     |2022-01-01  |2099-12-31|
+----------+-----------------------------------------+------------------------------------------+------------------+------------+----------+
select  * from  BOSH.ORDER_ITEM_TBL where ORDER_KEY in (
        select  ORDER_KEY from  BOSH.CONTRACT_ORDER_TBL where CONTRACT_KEY in (171991,172023)
)
;
+---------+--------------+---------+--------------+-------------------+----------+--------------------------+--------------------------+--------------------------+
|ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY|OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|POLICY_KEY|COVERAGE_START_DT         |PURCHASE_DT               |COVERAGE_EXP_DT           |
+---------+--------------+---------+--------------+-------------------+----------+--------------------------+--------------------------+--------------------------+
|373825   |1             |40579    |2             |3177095            |3127      |2023-11-02 00:00:00.000000|2023-11-01 14:20:11.336000|2026-11-02 00:00:00.000000|
|373825   |2             |40581    |2             |3584516            |3127      |2023-11-02 00:00:00.000000|2023-11-01 14:20:11.336000|2026-11-02 00:00:00.000000|
|373825   |3             |40578    |2             |3175045            |3108      |2023-11-02 00:00:00.000000|2023-11-01 14:20:11.336000|2026-11-02 00:00:00.000000|
+---------+--------------+---------+--------------+-------------------+----------+--------------------------+--------------------------+--------------------------+
