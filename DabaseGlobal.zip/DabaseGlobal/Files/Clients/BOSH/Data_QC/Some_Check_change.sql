-- program_nm,user_nm,author_nm,process_nm,descriptive_tx,record_count,creation_dt,table_nm,log_type
-- PKG_DATA_QC.PROC_DATA_QC,BOSHSTG,AJAIN,Daily data QA,"There are 134 si_key(s), which are appearing against multiple active contracts.",134,2024-08-12 06:45:06.094007,CONTRACT_DIM,WARNING
-- PKG_DATA_QC.PROC_DATA_QC,BOSHSTG,AJAIN,Daily data QA,"There are 44 si_key(s), which are appearing against multiple orders.",44,2024-08-12 06:45:29.222653,ORDER_ITEM_TBL,WARNING
-- PKG_DATA_QC.PROC_DATA_QC,BOSHSTG,AJAIN,Daily data QA,There are 26 Active contracts/serials with a latest_coverage_type other then 2.,26,2024-08-12 06:45:29.718252,SERIALIZED_ITEM_DIM,WARNING
-- PKG_DATA_QC.PROC_DATA_QC,BOSHSTG,AJAIN,Daily data QA,There are 6 canceled contracts/serials with single order but latest_coverage_type is not 3.,6,2024-08-12 06:45:30.561299,SERIALIZED_ITEM_DIM,WARNING
-- PKG_DATA_QC.PROC_DATA_QC,BOSHSTG,AJAIN,Daily data QA,There are 8 canceled contracts/serials with multiple orders and no contract is active and latest_coverage_type is not 3.,8,2024-08-12 06:45:50.008821,CONTRACT_DIM,WARNING
-- PKG_DATA_QC.PROC_DATA_QC,BOSHSTG,AJAIN,Daily data QA,There are 77 serials with orders but latest_coverage_type is 1.,77,2024-08-12 06:45:50.618923,SERIALIZED_ITEM_DIM,WARNING
-- PKG_DATA_QC.PROC_DATA_QC,BOSHSTG,AJAIN,Daily data QA,There are 60 customers with DM suppressed in Web but not in DW,60,2024-08-12 06:46:00.406497,CONTRACT_DIM,WARNING
-- PKG_DATA_QC.PROC_DATA_QC,BOSHSTG,AJAIN,Daily data QA,There are 8 confirmed orders but contract has not been created yet,8,2024-08-12 06:46:02.012478,RAW_CONTRACT_SALES_TBL,WARNING
--
--     There are X si_key(s), which are appearing against multiple active contracts.
 select distinct si_key

        from (
              select si.si_key, count(distinct ccx.contract_key), min(CREATION_DT) AS CREATION_DT
                from p_serialized_item_dim si
                     join p_contract_coverage_xref ccx on ccx.si_key = si.si_key
                     join p_contract_lkp clkp on clkp.contract_key = ccx.contract_key
                     join p_contract_dim con on con.contract_key = clkp.contract_key
                     left join p_policy_ext_tbl pex ON (pex.policy_key = con.policy_key)
                     join AUDIT_TBL att on att.AUDIT_KEY = con.INSERT_AUDIT_KEY
              where ccx.coverage_type_key = 2
                and con.retail_amt > 1
                --AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                and con.contract_status_key NOT IN (2, 3, 4, 5)
                AND exists (
                        select ccx3.si_key
                        from
                                p_contract_coverage_xref ccx3
                                join p_contract_lkp clkp3 on clkp3.contract_key = ccx3.contract_key
                                join p_contract_dim con3 on con3.contract_key = clkp3.contract_key
                                left join p_contract_status_dim cons3 on (cons3.contract_status_key = con3.contract_status_key)
                                join p_policy_ext_tbl pex3 ON (pex3.policy_key = con3.policy_key)
                        where
                              ccx3.coverage_type_key = 2
                        and ccx3.si_key  = ccx.si_key
                        and con3.contract_key <> con.contract_key
                        and
                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                             or
                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                            )
                        and con3.retail_amt > 1
                        AND con3.contract_status_key NOT IN (2, 3, 4, 5)   --canceled/fulfilled/expired
                        and pex3.channels = pex.channels
                        and con3.contract_end_dt >= trunc(sysdate) - 30
                       )
                AND att.CREATION_DT > SYSDATE - 366
              group by si.si_key
             having count(distinct ccx.contract_key) >= 2
            );
+---------------------+--------------------------+
|COUNT(DISTINCTSI_KEY)|MIN(CREATION_DT)          |
+---------------------+--------------------------+
|134                  |2018-04-20 02:00:14.000000|
+---------------------+--------------------------+

--     There are X si_key(s), which are appearing against multiple orders.
 select count(*), min(CREATION_DT)

        from (
              SELECT serialized_item_key, count(*), count(distinct oit.order_key), min(CREATION_DT) AS CREATION_DT
                FROM p_order_tbl o
                     JOIN p_order_item_tbl oit on (oit.order_key = o.order_key)
                     left join p_contract_order_tbl co on (co.order_key = oit.order_key and co.order_line_key = oit.order_line_key)
                     left join p_contract_dim con on (con.contract_key = co.contract_key)
                     left join p_contract_status_dim cons on (cons.contract_status_key = con.contract_status_key)
                     left join p_policy_ext_tbl pex ON (pex.policy_key = oit.policy_key)
                     join AUDIT_TBL att on att.AUDIT_KEY = o.INSERT_AUDIT_KEY
               WHERE oit.price_amt > 1
                AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                AND ( con.contract_status_key IS NULL OR con.contract_status_key NOT IN (2, 3, 4, 5) )
                AND exists (
                        select oit3.serialized_item_key
                        from   P_ORDER_ITEM_TBL oit3
                                join p_contract_order_tbl co3 on (co3.order_key = oit3.order_key and co3.order_line_key = oit3.order_line_key)
                                join p_contract_dim con3 on (con3.contract_key = co3.contract_key)
                                left join p_contract_status_dim cons3 on (cons3.contract_status_key = con3.contract_status_key)
                                join p_policy_ext_tbl pex3 ON (pex3.policy_key = oit3.policy_key)
                        where 1 = 1
                        and oit3.serialized_item_key  = oit.serialized_item_key
                        and oit3.order_key <> oit.order_key
                        and con3.contract_key <> con.contract_key
                        and
                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                             or
                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                            )
                        and oit3.price_amt > 1
                        AND ( con3.contract_status_key IS NULL OR con3.contract_status_key NOT IN (2, 3, 4, 5) )  --canceled/fulfilled/expired
                        and pex3.channels = pex.channels
                        and con3.contract_end_dt >= trunc(sysdate) - 60
                       )
               GROUP BY serialized_item_key
              HAVING COUNT(*) >= 2
             );
+--------+--------------------------+
|COUNT(*)|MIN(CREATION_DT)          |
+--------+--------------------------+
|44      |2022-06-09 02:32:03.000000|
+--------+--------------------------+


--     There are X Active contracts/serials with a latest_coverage_type other then 2.
 select count(*) , min(CREATION_DT),max(CREATION_DT)
        from (
              select distinct cc.contract_key, cc.contract_status_key, si.si_key, si.latest_coverage_type,att.CREATION_DT
                from p_contract_dim cc
                    join p_contract_coverage_xref ccx
                      ON (cc.contract_key = ccx.contract_key)
                    join p_serialized_item_dim si
                      ON (si.si_key = ccx.si_key)
                    join AUDIT_TBL att on att.AUDIT_KEY = cc.INSERT_AUDIT_KEY
               where
                     (cc.contract_status_key = 1 and si.latest_coverage_type not in (2, 9, 22))
               and CREATION_DT > sysdate - 366
             );
-- last 1 year check for p_contract_dim insert key
+--------+--------------------------+
|COUNT(*)|MIN(CREATION_DT)          |
+--------+--------------------------+
|27      |2020-12-02 11:40:02.000000|
+--------+--------------------------+
    -- need to check latest status of contract and SI coverage type
+--------+--------------------------+--------------------------+
|COUNT(*)|MIN(CREATION_DT)          |MAX(CREATION_DT)          |
+--------+--------------------------+--------------------------+
|13      |2023-09-19 12:19:37.000000|2024-08-11 11:40:03.000000|
+--------+--------------------------+--------------------------+

--     There are X canceled contracts/serials with single order but latest_coverage_type is not 3.
  select count(distinct si_key)   ,min(cancel_dt)
        from (
              select distinct cc.contract_key, cc.contract_status_key, si.si_key, si.latest_coverage_type, si.latest_coverage_exp_dt
                    , can.cancel_dt, can.cancel_effective_dt, cc.contract_end_dt, oect.cancellation_process_dt
              from  p_contract_dim cc
                    join p_contract_lkp clkp
                    ON (clkp.contract_key = cc.contract_key and clkp.source_system_cd = 0)
                    join p_contract_cancellation_dim can
                    ON (can.contract_key = cc.contract_key)
                    --join p_contract_coverage_xref ccx
                    --ON (cc.contract_key = ccx.contract_key)
                    join p_contract_order_tbl cot
                    ON (cot.contract_key = cc.contract_key)
                    join p_ORDER_ITEM_TBL oit ON oit.order_key = cot.order_key and oit.order_line_key = cot.order_line_key
                    join p_serialized_item_dim si
                    ON (si.si_key = oit.serialized_item_key)
                    left join bosh.order_extract_cancel_tbl oect on oect.p2contract_number = clkp.contract_xid
             where
                     (cc.contract_status_key in (2, 3) and si.latest_coverage_type NOT IN (3,20))
                and cancel_dt > sysdate - 366
               and si.si_key IN (
                      SELECT oit.serialized_item_key FROM p_order_item_tbl oit
                      GROUP BY serialized_item_key HAVING COUNT (DISTINCT order_key) = 1
                     )
             );
+---------------------+--------------------------+
|COUNT(DISTINCTSI_KEY)|MIN(CANCEL_DT)            |
+---------------------+--------------------------+
|5                    |2021-08-13 00:00:00.259000|
+---------------------+--------------------------+

--     There are X canceled contracts/serials with multiple orders and no contract is active and latest_coverage_type is not 3.
select count(*),min(cancel_dt)
        from (
              select con.contract_key, con.contract_status_key, si.si_key, si.warranty_expiration_dt, si.latest_coverage_type, si.latest_coverage_exp_dt
                    ,oit.purchase_dt, can.cancel_dt, can.cancel_effective_dt, con.contract_end_dt, oect.cancellation_process_dt
                    ,row_number() over(partition by  si.si_key order by can.cancel_effective_dt desc) as rno
              from   p_contract_dim con
                     join p_contract_lkp clkp
                     ON (clkp.contract_key = con.contract_key and clkp.source_system_cd = 0)
                     join p_contract_cancellation_dim can
                     on (can.contract_key = con.contract_key)
                     join p_contract_order_tbl cot
                     on (cot.contract_key = con.contract_key)
                     join p_order_item_tbl oit on oit.order_key = cot.order_key and oit.order_line_key = cot.order_line_key
                     join p_serialized_item_dim si
                     on (si.si_key = oit.serialized_item_key)
                     left join bosh.order_extract_cancel_tbl oect on oect.p2contract_number = clkp.contract_xid
              where
                     (con.contract_status_key = 2 and si.latest_coverage_type <> 3)
              and    si.si_key  in (
                         select oit.serialized_item_key from p_order_item_tbl oit
                         group by serialized_item_key   having count (distinct order_key) > 1   --this serial has multiple orders
                         )

              and    not  exists  (
                                select con2.contract_key
                                  from p_contract_dim con2
                                      join p_contract_order_tbl cot2
                                      on (cot2.contract_key = con2.contract_key)
                                      join p_order_item_tbl oit2 on oit2.order_key = cot2.order_key and oit2.order_line_key = cot2.order_line_key

                                 where con2.contract_status_key in (1, 5)   --8 is Active Pending in some setups
                                       --no other contract with  coverage_exp_dt >= the one we are processing in sql above
                                   and (oit2.coverage_exp_dt >= oit.coverage_exp_dt or abs(trunc(oit2.coverage_exp_dt) - trunc(oit.coverage_exp_dt)) <= 31 )
                                   and  con2.contract_key <> con.contract_key -- contract is not the one we are processing
                                   and  oit2.serialized_item_key = si.si_key
                                )
             )
       where rno = 1;
-- exist clause :
+--------+--------------------------+
|COUNT(*)|MIN(CANCEL_DT)            |
+--------+--------------------------+
|8       |2021-08-10 00:00:00.387000|
+--------+--------------------------+

--     There are X serials with orders but latest_coverage_type is 1.
 --Serials with sales and no cancels then latest_coverage_type should be 2
      select count(*),min(CONTRACT_START_DATE)
        from (
                select * from (
                    select si.SI_KEY, si.PRODUCT_KEY, si.MODEL_NO, si.PURCHASE_DT_KEY, si.WARRANTY_EXPIRATION_DT, si.REGISTRATION_DT, si.LATEST_COVERAGE_EXP_DT, si.LATEST_COVERAGE_TYPE
                           ,oit.purchase_dt, oit.coverage_start_dt, oit.coverage_exp_dt
                           ,r.CONTRACT_START_DATE, r.CONTRACT_END_DATE, r.P2_CONTRACT_NO
                           ,row_number() over(partition by si.si_key order by oit.purchase_dt desc) as rno
                      from p_serialized_item_dim  si
                           join p_serialized_item_ext_dim six on six.si_key = si.si_key
                           JOIN p_order_item_tbl oit on oit.serialized_item_key = si.si_key
                           JOIN p_order_tbl o on (oit.order_key = o.order_key)
                           LEFT JOIN bosh.raw_contract_sales_tbl r on oit.order_key || '-' || oit.order_line_key = r.unique_identifier
                     where latest_coverage_type = 1
                --       and duplicate_ind = 'N'
                       and o.purchase_dt <= SYSDATE - 7
                       and si.si_key not in (
                              select  oit2.serialized_item_key
                                from   p_contract_dim con2
                                       JOIN p_contract_order_tbl cot2 on (cot2.contract_key = con2.contract_key)
                                       JOIN p_order_item_tbl  oit2 on (oit2.order_key = cot2.order_key and oit2.order_line_key = cot2.order_line_key)
                                WHERE  con2.contract_status_key IN (2, 3)   --canceled?
                              )
                )
                where rno = 1
            );--96
+--------+------------------------+
|COUNT(*)|MIN(CONTRACT_START_DATE)|
+--------+------------------------+
|96      |01/14/2023              |
+--------+------------------------+

--     There are X confirmed orders but contract has not been created yet
 --Orders where a sales confirmation has been received but contract has not been created
      SELECT COUNT(DISTINCT UNIQUE_IDENTIFIER)
        FROM (
                SELECT A.*
                  FROM P_ORDER_EXTRACT_TBL A
                       LEFT JOIN P_RAW_CONTRACT_SALES_TBL B ON ( A.UNIQUE_IDENTIFIER = B.UNIQUE_IDENTIFIER)
                       --LEFT JOIN P_RAW_CONTRACT_SALES_ERROR_TBL C ON ( A.UNIQUE_IDENTIFIER = C.UNIQUE_IDENTIFIER)
                       LEFT JOIN P_CONTRACT_ORDER_TBL COT ON (COT.ORDER_KEY || '-' || COT.ORDER_LINE_KEY = A.UNIQUE_IDENTIFIER)
                 WHERE process_dt < TRUNC(SYSDATE) - 1
                   AND ( b.unique_identifier IS NOT NULL ) --AND c.unique_identifier IS NULL
                   AND cot.contract_key IS NULL
             );--3