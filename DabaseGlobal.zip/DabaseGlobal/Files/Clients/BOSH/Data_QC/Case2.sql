--Case here
    -- Same SI_KEY in two contract and in two different order
    -- Policy ID are different but both are AM EB
    -- Dates are over ride
                --Bosch Appliance Service plan - 4 Year CONTRACT_START_DT = 2024-02-18 and CONTRACT_END_DT = 2028-02-18
                --Bosch Appliance Service plan - 6 Year CONTRACT_START_DT = 2024-02-18 and CONTRACT_END_DT = 2030-02-18

select  * from  BOSH.CONTRACT_COVERAGE_XREF where SI_KEY = 3384595;
+------------+-----------------+---------------------+-------+
|CONTRACT_KEY|COVERAGE_TYPE_KEY|COVERED_COMPONENT_KEY|SI_KEY |
+------------+-----------------+---------------------+-------+
|163426      |2                |1                    |3384595|
|163426      |3                |1                    |3384595|
|176718      |3                |1                    |3384595|
|176718      |2                |1                    |3384595|
+------------+-----------------+---------------------+-------+

select  * from  BOSH.POLICY_EXT_TBL where  POLICY_KEY in (2888,440);
+----------+-----+--------+----------------+----------------+
|POLICY_KEY|BRAND|CHANNELS|PRODUCT_CAT_DESC|INSERT_AUDIT_KEY|
+----------+-----+--------+----------------+----------------+
|440       |BSUS |AM EB   |Dishwasher      |95765           |
|2888      |Bosch|AM EB   |Dishwasher      |396936          |
+----------+-----+--------+----------------+----------------+

select  * from  BOSH.POLICY_TBL where  POLICY_KEY in (2888,440);
+----------+-------------------------------------+--------------------------------------+------------------+------------+----------+
|POLICY_KEY|NAME                                 |DESCRIPTION                           |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |
+----------+-------------------------------------+--------------------------------------+------------------+------------+----------+
|440       |Bosch Appliance Service plan - 4 Year|4 yr Bosch Appliance Service plan (AM)|BSDHB60U          |2016-05-01  |2099-12-31|
|2888      |Bosch Appliance Service plan - 6 Year|6 yr Bosch Appliance Service plan (AM)|BSDHB72U1         |2020-11-02  |2099-12-31|
+----------+-------------------------------------+--------------------------------------+------------------+------------+----------+


select  OIT.ORDER_KEY,OT.PURCHASE_DT,CD.CONTRACT_KEY,CD.CONTRACT_STATUS_KEY,CD.CONTRACT_SALE_DT
     ,OIT.SERIALIZED_ITEM_KEY,PTT.PAYMENT_AMT,PTT.PAYMENT_TYPE from  BOSH.ORDER_ITEM_TBL OIT
                LEFT JOIN BOSH.ORDER_TBL OT ON OT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_ORDER_TBL COT ON  COT.ORDER_KEY = OIT.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_DIM CD ON  COT.CONTRACT_KEY = CD.CONTRACT_KEY
                LEFT JOIN BOSH.PAYMENT_TX_TBL PTT ON PTT.ORDER_KEY = OIT.ORDER_KEY
          where   COT.CONTRACT_KEY in (163426,176718)

;

+---------+--------------------------+------------+-------------------+----------------+-------------------+-----------+------------+
|ORDER_KEY|PURCHASE_DT               |CONTRACT_KEY|CONTRACT_STATUS_KEY|CONTRACT_SALE_DT|SERIALIZED_ITEM_KEY|PAYMENT_AMT|PAYMENT_TYPE|
+---------+--------------------------+------------+-------------------+----------------+-------------------+-----------+------------+
|358803   |2023-07-20 00:00:00.000000|163426      |1                  |2023-07-20      |3384595            |197.60     |CHECK_BYPASS|
|383147   |2024-01-01 00:00:00.000000|176718      |1                  |2024-01-01      |3384595            |168.00     |CHECK_BYPASS|
+---------+--------------------------+------------+-------------------+----------------+-------------------+-----------+------------+


select  * from  BOSH.CONTRACT_DIM where CONTRACT_KEY in (163426,176718);
+------------+-------------------+----------------+-----------------+---------------+----------+----------+
|CONTRACT_KEY|CONTRACT_STATUS_KEY|CONTRACT_SALE_DT|CONTRACT_START_DT|CONTRACT_END_DT|RETAIL_AMT|POLICY_KEY|
+------------+-------------------+----------------+-----------------+---------------+----------+----------+
|163426      |1                  |2023-07-20      |2024-02-18       |2030-02-18     |197.60    |2888      |
|176718      |1                  |2024-01-01      |2024-02-18       |2028-02-18     |168.00    |440       |
+------------+-------------------+----------------+-----------------+---------------+----------+----------+

select  * from  BOSH.CONTRACT_ORDER_TBL where CONTRACT_KEY in (163426,176718);
+------------+---------+--------------+
|CONTRACT_KEY|ORDER_KEY|ORDER_LINE_KEY|
+------------+---------+--------------+
|163426      |358803   |1             |
|176718      |383147   |1             |
+------------+---------+--------------+

select  * from  BOSH.ORDER_ITEM_TBL where ORDER_KEY in (358803,383147);
+---------+--------------+-------------+--------------+-------------------+----------+--------------------------+--------------------------+
|ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY    |OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|POLICY_KEY|COVERAGE_START_DT         |COVERAGE_EXP_DT           |
+---------+--------------+-------------+--------------+-------------------+----------+--------------------------+--------------------------+
|358803   |1             |8198617073065|4             |3384595            |2888      |2024-02-19 00:00:00.000000|2030-02-17 00:00:00.000000|
|383147   |1             |8198617073113|3             |3384595            |440       |2024-02-19 00:00:00.000000|2028-02-18 00:00:00.000000|
+---------+--------------+-------------+--------------+-------------------+----------+--------------------------+--------------------------+

select  * from  BOSH.ORDER_TBL where ORDER_KEY in (358803,383147);
+---------+---------+----------------------+--------------------------+----------------+
|ORDER_KEY|ORDER_XID|CREATED_BY            |PURCHASE_DT               |CALL_CENTER_FLAG|
+---------+---------+----------------------+--------------------------+----------------+
|358803   |3352618  |lmartinez@afterinc.com|2023-07-20 00:00:00.000000|Y               |
|383147   |3364790  |godoi@afterinc.com    |2024-01-01 00:00:00.000000|Y               |
+---------+---------+----------------------+--------------------------+----------------+


select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in (3384595);
+-------+-----------+-----------+----------+---------------+--------------------------+-------------------+----------------------+
|SI_KEY |PRODUCT_KEY|SERIAL_NO  |MODEL_NO  |PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |REGISTRATION_DT    |LATEST_COVERAGE_EXP_DT|
+-------+-----------+-----------+----------+---------------+--------------------------+-------------------+----------------------+
|3384595|28604      |0000-010131|SHEM3AY55N|12102          |2024-02-18 00:00:00.000000|2023-07-25 19:06:12|2028-02-18            |
+-------+-----------+-----------+----------+---------------+--------------------------+-------------------+----------------------+


select * from BOSH.SERIALIZED_ITEM_LKP where SI_KEY in (3384595);
+-------+-------------------------------+----------------+
|SI_KEY |SI_XID                         |SOURCE_SYSTEM_CD|
+-------+-------------------------------+----------------+
|3384595|19823116                       |2               |
|3384595|SHEM3AY55N/xx-20230218-T7763003|0               |
+-------+-------------------------------+----------------+

