select SI_XID from BOSH.SERIALIZED_ITEM_LKP where SI_XID in (
    select SI_XID from BOSH.SERIALIZED_ITEM_LKP where SI_KEY in (
                        select distinct si_key

                        from (
                              select si.si_key, count(distinct ccx.contract_key), min(CREATION_DT) AS CREATION_DT
                                from p_serialized_item_dim si
                                     join p_contract_coverage_xref ccx on ccx.si_key = si.si_key
                                     join p_contract_lkp clkp on clkp.contract_key = ccx.contract_key
                                     join p_contract_dim con on con.contract_key = clkp.contract_key
                                     left join p_policy_ext_tbl pex ON (pex.policy_key = con.policy_key)
                                     join AUDIT_TBL att on att.AUDIT_KEY = con.INSERT_AUDIT_KEY
                              where ccx.coverage_type_key = 2
                                and con.retail_amt > 1
                                --AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                                and con.contract_status_key NOT IN (2, 3, 4, 5)
                                AND exists (
                                        select ccx3.si_key
                                        from
                                                p_contract_coverage_xref ccx3
                                                join p_contract_lkp clkp3 on clkp3.contract_key = ccx3.contract_key
                                                join p_contract_dim con3 on con3.contract_key = clkp3.contract_key
                                                left join p_contract_status_dim cons3 on (cons3.contract_status_key = con3.contract_status_key)
                                                join p_policy_ext_tbl pex3 ON (pex3.policy_key = con3.policy_key)
                                        where
                                              ccx3.coverage_type_key = 2
                                        and ccx3.si_key  = ccx.si_key
                                        and con3.contract_key <> con.contract_key
                                        and
                                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                                             or
                                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                                             or
                                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                                             or
                                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                                            )
                                        and con3.retail_amt > 1
                                        AND con3.contract_status_key NOT IN (2, 3, 4, 5)   --canceled/fulfilled/expired
                                        and pex3.channels = pex.channels
                                        and con3.contract_end_dt >= trunc(sysdate) - 30
                                       )
                                AND att.CREATION_DT > SYSDATE - 366
                              group by si.si_key
                             having count(distinct ccx.contract_key) >= 2
                            )
        )
    )
and SOURCE_SYSTEM_CD = 0
GROUP BY SI_XID
Having COUNT(SI_XID)> 1
;
+-----------------------------------+
|SI_XID                             |
+-----------------------------------+
|SHEM63W55N/xx-20221228-T7605918    |
|SGSX305TS/xx-20190825-T2493515     |
|B36CT80SNS/xx-20220913-4393590     |
|DWHD650WFP/xx-20220310-T7602354    |
|DWHD770CPR/xx-20231001-T6964795    |
|MD24WS/xx-20230403-T7638515        |
|MD24WS/xx-20230403-T7647574        |
|SHX9PCM5N/xx-20231226-5333256      |
|DWHD770WPR/xx-20230403-T7647574    |
|DWHD650WFP/xx-20220504-T7210292    |
|DWHD650WFP/xx-20221205-T8403002    |
|SHXM4AY55N/xx-20230215-T7716107    |
|ME302YP/xx-20230626-T7918448       |
|SGSX305TS/xx-20190825-T2385331     |
|WTG86403UC/xx-20210501-T4922230    |
|T36IB900SP/xx-20210529-IW40181518  |
|WTG86403UC/xx-20210501-T5047215    |
|DWHD770WFP/xx-20220722-T7256415    |
|T30IR905SP/xx-20230403-T7647574    |
|T36IB900SP/xx-20210529-IW2277087452|
|DWHD770WPR/xx-20220301-T7434036    |
|DWHD770WFM/xx-20210708-IW3943401686|
|ME302WS/xx-20220425-T7252779       |
|SHPM78Z54N/xx-20230425-4933624     |
|DWHD650WFP/xx-20220310-T7028329    |
|DWHD660WFP/xx-20221101-T4555249    |
|SHVM78Z53N/xx-20230515-T7866467    |
|DWHD650WPR/xx-20211216-T6942419    |
|SHV863WD3N/xx-20181115-T3563247    |
+-----------------------------------+



 select SIX.SOURCE,SIL.* from BOSH.SERIALIZED_ITEM_LKP SIL
          join BOSH.SERIALIZED_ITEM_EXT_DIM SIX on SIX.SI_KEY =SIL.SI_KEY
where SIL.SI_XID in(
'SHEM63W55N/xx-20221228-T7605918',
'SGSX305TS/xx-20190825-T2493515',
'B36CT80SNS/xx-20220913-4393590',
'DWHD650WFP/xx-20220310-T7602354',
'DWHD770CPR/xx-20231001-T6964795',
'MD24WS/xx-20230403-T7638515',
'MD24WS/xx-20230403-T7647574',
'SHX9PCM5N/xx-20231226-5333256',
'DWHD770WPR/xx-20230403-T7647574',
'DWHD650WFP/xx-20220504-T7210292',
'DWHD650WFP/xx-20221205-T8403002',
'SHXM4AY55N/xx-20230215-T7716107',
'ME302YP/xx-20230626-T7918448',
'SGSX305TS/xx-20190825-T2385331',
'WTG86403UC/xx-20210501-T4922230',
'T36IB900SP/xx-20210529-IW40181518',
'WTG86403UC/xx-20210501-T5047215',
'DWHD770WFP/xx-20220722-T7256415',
'T30IR905SP/xx-20230403-T7647574',
'T36IB900SP/xx-20210529-IW2277087452',
'DWHD770WPR/xx-20220301-T7434036',
'DWHD770WFM/xx-20210708-IW3943401686',
'ME302WS/xx-20220425-T7252779',
'SHPM78Z54N/xx-20230425-4933624',
'DWHD650WFP/xx-20220310-T7028329',
'DWHD660WFP/xx-20221101-T4555249',
'SHVM78Z53N/xx-20230515-T7866467',
'DWHD650WPR/xx-20211216-T6942419',
'SHV863WD3N/xx-20181115-T3563247'
)
and SOURCE_SYSTEM_CD = 0
ORDER BY SI_XID
;