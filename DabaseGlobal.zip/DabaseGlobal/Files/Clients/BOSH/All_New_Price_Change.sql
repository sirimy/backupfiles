
select COUNT(Distinct MATERIAL) from BOSH.RAW_MODEL_MASTER_TBL ;

SELECT COUNT(Distinct MATERIAL) FROM
( SELECT
    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
FROM
    BOSH.RAW_MODEL_MASTER_TBL  RMMT)
WHERE r = 1;


insert into RAW_MODEL_MASTER_TBL_LATEST
SELECT * FROM
( SELECT
    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
FROM
    BOSH.RAW_MODEL_MASTER_TBL  RMMT)
WHERE r = 1;

--order by MATERIAL,r;
--WHERE r = 1;

select * from BOSH.PRODUCT_DIM;

select COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST where MATERIAL_GROUP <> 'Accessory' and MAP_UMRP is not null ;


select COUNT(*) from
RAW_MODEL_MASTER_TBL_LATEST tgt
    inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c
            where c.PRICE_AMT is not null) src
    on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0);


insert into RAW_MODEL_MASTER_TBL_LATEST
SELECT * FROM
( SELECT
    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
FROM
    BOSH.RAW_MODEL_MASTER_TBL  RMMT  inner join AUDIT_TBL AT ON RMMT.INSERT_AUDIT_KEY = AT.AUDIT_KEY
Where AT.CREATION_DT  >= TO_DATE('01/MAR/2022 00:00:00', 'dd/mon/yyyy HH24:MI:SS'))
WHERE r = 1;


Update RAW_MODEL_MASTER_TBL_LATEST
SET ERROR_DESC = 'Model exist with same price in core'
where TRIM(MATERIAL) not in (
select  TRIM(MATERIAL) from
RAW_MODEL_MASTER_TBL_LATEST tgt
    inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c
            where c.PRICE_AMT is not null) src
    on (TRIM(src.BRAND_NM) = TRIM(tgt.BRAND) and TRIM(src.MODEL_NO) = TRIM(tgt.MATERIAL) )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
        and TRIM(tgt.MATERIAL_GROUP) <> 'Accessory' and tgt.MAP_UMRP is not null );

insert into RAW_MODEL_MASTER_TBL
select  MATERIAL           ,
    MATERIAL_DESCRIPTION  ,
    BRAND       ,
    MATERIAL_GROUP     ,
    SALES_STATUS    ,
    VALID_FROM     ,
    EF_OUT_DATE     ,
    UPC_CODE       ,
    NEW_BUSINESS_FIELD  ,
    PRODUCT_TYPE    ,
    MAP_UMRP       ,
    SK_MARKETING_DESCRIPTION ,
    FILE_NM     ,
    INSERT_AUDIT_KEY  ,
    UNIQUE_SEQ_NO   ,
    ERROR_DESC      from RAW_MODEL_MASTER_TBL_LATEST Where ERROR_DESC is null;



Update RAW_MODEL_MASTER_TBL_LATEST
SET ERROR_DESC = 'Model exist with same price in core'
where TRIM(MATERIAL) not in (
select  TRIM(MATERIAL) from
RAW_MODEL_MASTER_TBL_LATEST tgt
    inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c
            where c.PRICE_AMT is not null) src
    on (TRIM(src.BRAND_NM) = TRIM(tgt.BRAND) and TRIM(src.MODEL_NO) = TRIM(tgt.MATERIAL) )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
        and TRIM(tgt.MATERIAL_GROUP) <> 'Accessory' and tgt.MAP_UMRP is not null );


select COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST Where ERROR_DESC is null;


