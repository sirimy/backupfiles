
Create table BAD_ADDRESS_REPROCESS_GNRC_1699 as (
select SI.SI_KEY,SI.SERIAL_NO,AD.ADDRESS_LINE1_TX,AD.ACE_ERROR_CD,AD.ADDRESS_KEY,CS.CUSTOMER_KEY,SI.PURCHASE_DT_KEY,ddPURCHASE_DT.FULL_DT,SI.LATEST_COVERAGE_TYPE,SI.LATEST_COVERAGE_EXP_DT,SI.WARRANTY_EXPIRATION_DT
--       COUNT(distinct si.SI_KEY ) CNT --28436
--     ,min( ddPURCHASE_DT.FULL_DT ) MINDATE
    --ddPURCHASE_DT.FULL_DT,SI.SI_KEY,(date '2025-01-31' - ddPURCHASE_DT.FULL_DT )/365
   from   gnrc.SERIALIZED_ITEM_DIM si
            --left join gnrc.SERIALIZED_ITEM_LKP slkp on si.SI_KEY = slkp.SI_KEY and slkp.SOURCE_SYSTEM_CD = 0
            join gnrc.VISITOR_OWNERSHIP_XREF vox on vox.SI_KEY = si.SI_KEY and PRIMARY_IND = 'Y'
            join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM cs on cs.CUSTOMER_KEY = vd.CUSTOMER_KEY
            join gnrc.ADDRESS_DIM ad on ad.ADDRESS_KEY = cs.PRIMARY_ADDRESS_KEY
            JOIN GNRC.V_PRODUCT VP ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
            join fas.date_dim ddPURCHASE_DT on ddPURCHASE_DT.date_key = si.PURCHASE_DT_KEY
            --left join gnrc.VISITOR_LKP VL on VL.VISITOR_KEY = cs.PRIMARY_VISITOR_KEY
            LEFT JOIN p_postal_state_dim psd ON UPPER(TRIM(psd.postal_state_cd)) = UPPER(TRIM(ad.STATE_CD))
            LEFT JOIN p_country_tbl ctry ON ctry.country_key = psd.country_key
   where 1=1
          AND vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'--
          AND ad.COUNTRY_CD = 'USA'--
          and ad.ACE_ERROR_CD like 'E%'--
          and ad.SOURCE_CD is NULL--
          --and (ADDRESS_LINE1_TX is null or not ( regexp_like(ADDRESS_LINE1_TX, '[[:digit:]]')  and   regexp_like(ADDRESS_LINE1_TX, '[[:alpha:]]'))) --633
          and VP.DO_NOT_SOLICIT_PRODUCT_IND = 'N' -- Model is not DNS
          and (date '2025-01-31' - ddPURCHASE_DT.FULL_DT )/365 <= 6 -- Total Length from purchase date is less than 6 year by using Jan 31st is less than equal to purchase date + 6 years
          and si.LATEST_COVERAGE_TYPE not in (2,6,21,20)-- latest coverage type not in (6,21)

         );

select SI.SI_KEY,SI.SERIAL_NO,AD.ADDRESS_LINE1_TX,AD.ACE_ERROR_CD,AD.ADDRESS_KEY,CS.CUSTOMER_KEY,SI.PURCHASE_DT_KEY,ddPURCHASE_DT.FULL_DT,SI.LATEST_COVERAGE_TYPE,SI.LATEST_COVERAGE_EXP_DT,SI.WARRANTY_EXPIRATION_DT
      --COUNT(distinct si.SI_KEY ) CNT -- old count before re procsess 28436
   from   gnrc.SERIALIZED_ITEM_DIM si
            join gnrc.VISITOR_OWNERSHIP_XREF vox on vox.SI_KEY = si.SI_KEY and PRIMARY_IND = 'Y'
            join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM cs on cs.CUSTOMER_KEY = vd.CUSTOMER_KEY
            join gnrc.ADDRESS_DIM ad on ad.ADDRESS_KEY = cs.PRIMARY_ADDRESS_KEY
            JOIN GNRC.V_PRODUCT VP ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
            join fas.date_dim ddPURCHASE_DT on ddPURCHASE_DT.date_key = si.PURCHASE_DT_KEY
            LEFT JOIN p_postal_state_dim psd ON UPPER(TRIM(psd.postal_state_cd)) = UPPER(TRIM(ad.STATE_CD))
            LEFT JOIN p_country_tbl ctry ON ctry.country_key = psd.country_key
   where 1=1
          AND vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'--
          AND ad.COUNTRY_CD = 'USA'--
          and ad.ACE_ERROR_CD like 'E%'--
          and ad.SOURCE_CD is NULL--
          and VP.DO_NOT_SOLICIT_PRODUCT_IND = 'N' -- Model is not DNS
          and (date '2025-01-31' - ddPURCHASE_DT.FULL_DT )/365 <= 6 -- Total Length from purchase date is less than 6 year by using Jan 31st is less than equal to purchase date + 6 years
          and si.LATEST_COVERAGE_TYPE not in (2,6,21,20)-- latest coverage type not in (6,21)
;-- New count is now 24369
-- +-------+----------+----------------------+------------+-----------+------------+---------------+----------+--------------------+----------------------+--------------------------+
-- |SI_KEY |SERIAL_NO |ADDRESS_LINE1_TX      |ACE_ERROR_CD|ADDRESS_KEY|CUSTOMER_KEY|PURCHASE_DT_KEY|FULL_DT   |LATEST_COVERAGE_TYPE|LATEST_COVERAGE_EXP_DT|WARRANTY_EXPIRATION_DT    |
-- +-------+----------+----------------------+------------+-----------+------------+---------------+----------+--------------------+----------------------+--------------------------+
-- |1434484|3012607432|23182 JOAQUIN GULLY RD|E421        |687836     |650318      |12041          |2022-12-19|1                   |2024-12-18            |2024-12-18 00:00:00.000000|
-- |2056984|3014234302|193 UPPER 7 PONDS RD  |E421        |8906524    |160594      |12702          |2024-10-10|1                   |2026-10-09            |2026-10-09 00:00:00.000000|
-- |1805837|3012272875|1 JONAH'S LN          |E412        |7691860    |134134      |12296          |2023-08-31|5                   |2030-08-30            |2025-08-30 00:00:00.000000|
-- |1455372|3007938176|658 TRUMAN HOLLOW RD  |E412        |6266650    |288796      |12106          |2023-02-22|1                   |2025-02-21            |2025-02-21 00:00:00.000000|
-- |1781314|3010436131|7022 S HIGHWAY 40     |E421        |7587464    |640080      |12285          |2023-08-20|1                   |2025-08-19            |2025-08-19 00:00:00.000000|
-- |731128 |3004839543|34076 HWY 70          |E421        |3153632    |652512      |10848          |2019-09-13|1                   |2021-09-13            |2021-09-13 00:00:00.000000|
-- |1514051|3012727056|7643 DEAN RD          |E412        |6510738    |511346      |12199          |2023-05-26|1                   |2025-05-25            |2025-05-25 00:00:00.000000|
-- |750945 |3004890882|5766 108TH ST         |E421        |3245372    |566894      |10895          |2019-10-30|1                   |2021-10-30            |2021-10-30 00:00:00.000000|
-- |775210 |3005199685|3850 ALBION RIDGE G RD|E421        |3350064    |650380      |10940          |2019-12-14|1                   |2021-12-14            |2021-12-14 00:00:00.000000|
-- |917380 |3006682690|501 EBONY             |E421        |3966292    |632294      |11243          |2020-10-12|1                   |2022-10-11            |2022-10-11 00:00:00.000000|
-- +-------+----------+----------------------+------------+-----------+------------+---------------+----------+--------------------+----------------------+--------------------------+

select * from  BAD_ADDRESS_REPROCESS_GNRC_1699_PROD AD1;
-- +-------+----------+----------------------+------------+-----------+------------+---------------+----------+--------------------+----------------------+--------------------------+---------+--------------------+
-- |SI_KEY |SERIAL_NO |ADDRESS_LINE1_TX      |ACE_ERROR_CD|ADDRESS_KEY|CUSTOMER_KEY|PURCHASE_DT_KEY|FULL_DT   |LATEST_COVERAGE_TYPE|LATEST_COVERAGE_EXP_DT|WARRANTY_EXPIRATION_DT    |FIXED_IND|TYPE                |
-- +-------+----------+----------------------+------------+-----------+------------+---------------+----------+--------------------+----------------------+--------------------------+---------+--------------------+
-- |1434484|3012607432|23182 JOAQUIN GULLY RD|E421        |687836     |650318      |12041          |2022-12-19|1                   |2024-12-18            |2024-12-18 00:00:00.000000|N        |RAW_LEADS_TBL       |
-- |2056984|3014234302|193 UPPER 7 PONDS RD  |E421        |8906524    |160594      |12702          |2024-10-10|1                   |2026-10-09            |2026-10-09 00:00:00.000000|N        |RAW_LEADS_TBL       |
-- |1805837|3012272875|1 JONAH'S LN          |E412        |7691860    |134134      |12296          |2023-08-31|5                   |2030-08-30            |2025-08-30 00:00:00.000000|N        |RAW_DEALER_LEADS_TBL|
-- |1455372|3007938176|658 TRUMAN HOLLOW RD  |E412        |6266650    |288796      |12106          |2023-02-22|1                   |2025-02-21            |2025-02-21 00:00:00.000000|N        |RAW_LEADS_TBL       |
-- |1781314|3010436131|7022 S HIGHWAY 40     |E421        |7587464    |640080      |12285          |2023-08-20|1                   |2025-08-19            |2025-08-19 00:00:00.000000|N        |RAW_LEADS_TBL       |
-- |731128 |3004839543|34076 HWY 70          |E421        |3153632    |652512      |10848          |2019-09-13|1                   |2021-09-13            |2021-09-13 00:00:00.000000|N        |RAW_LEADS_TBL       |
-- |832468 |3005478464|116 LICK LOG HOLW     |E421        |3584186    |294442      |11085          |2020-05-07|1                   |2022-05-06            |2022-05-06 00:00:00.000000|Y        |RAW_LEADS_TBL       |
-- |1514051|3012727056|7643 DEAN RD          |E412        |6510738    |511346      |12199          |2023-05-26|1                   |2025-05-25            |2025-05-25 00:00:00.000000|N        |RAW_LEADS_TBL       |
-- |750945 |3004890882|5766 108TH ST         |E421        |3245372    |566894      |10895          |2019-10-30|1                   |2021-10-30            |2021-10-30 00:00:00.000000|N        |RAW_LEADS_TBL       |
-- |775210 |3005199685|3850 ALBION RIDGE G RD|E421        |3350064    |650380      |10940          |2019-12-14|1                   |2021-12-14            |2021-12-14 00:00:00.000000|N        |RAW_LEADS_TBL       |
-- +-------+----------+----------------------+------------+-----------+------------+---------------+----------+--------------------+----------------------+--------------------------+---------+--------------------+


-- 1681 rows from  RAW_DEALER_LEADS_TBL
         select
               RLT.owner_name, owner_address1, owner_city, owner_state, owner_postcode, owner_phone_number, owner_email, equipment,
               valid_from_date, material, material_name, purchase_date, product_hier_level1, product_hier_level1_name, product_hier_level2,
               product_hier_level2_name, master_warranty_number, master_warranty_desc, warranty_start_date, min_warranty_end_dt,
               max_warranty_end_dt, notification_count, product_hire_level3, product_hire_level_3_name, sales_office, EXTENDED_WARRANTY_END_DATE
         from BAD_ADDRESS_REPROCESS_GNRC_1699_PROD AD1
                 JOIN (select * from (
                         select rlt.*, row_number() over (partition by LTRIM(TRIM(RLT.EQUIPMENT), '0') order by rlt.INSERT_AUDIT_KEY desc) rno
                           from GNRC.RAW_DEALER_LEADS_TBL RLT
                        ) RLT
                     where RLT.rno = 1
                     ) RLT
                    ON  (   AD1.SERIAL_NO = LTRIM(TRIM(RLT.EQUIPMENT),'0')
                        )
        Where FIXED_IND = 'N' AND TYPE = 'RAW_DEALER_LEADS_TBL';




select --SI.SI_KEY,SI.SERIAL_NO,AD.ADDRESS_LINE1_TX,AD.ACE_ERROR_CD,AD.ADDRESS_KEY,CS.CUSTOMER_KEY,SI.PURCHASE_DT_KEY,ddPURCHASE_DT.FULL_DT,SI.LATEST_COVERAGE_TYPE,SI.LATEST_COVERAGE_EXP_DT,SI.WARRANTY_EXPIRATION_DT
      COUNT(distinct si.SI_KEY ) CNT -- old count before re procsess 28436
   from   gnrc.SERIALIZED_ITEM_DIM si
            join gnrc.VISITOR_OWNERSHIP_XREF vox on vox.SI_KEY = si.SI_KEY and PRIMARY_IND = 'Y'
            join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM cs on cs.CUSTOMER_KEY = vd.CUSTOMER_KEY
            join gnrc.ADDRESS_DIM ad on ad.ADDRESS_KEY = cs.PRIMARY_ADDRESS_KEY
            JOIN GNRC.V_PRODUCT VP ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
            join fas.date_dim ddPURCHASE_DT on ddPURCHASE_DT.date_key = si.PURCHASE_DT_KEY
            LEFT JOIN p_postal_state_dim psd ON UPPER(TRIM(psd.postal_state_cd)) = UPPER(TRIM(ad.STATE_CD))
            LEFT JOIN p_country_tbl ctry ON ctry.country_key = psd.country_key
   where 1=1
          AND vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'--
          AND ad.COUNTRY_CD = 'USA'--
          and ad.ACE_ERROR_CD like 'E%'--
          and ad.SOURCE_CD is NULL--
          and VP.DO_NOT_SOLICIT_PRODUCT_IND = 'N' -- Model is not DNS
          and (date '2025-01-31' - ddPURCHASE_DT.FULL_DT )/365 <= 6 -- Total Length from purchase date is less than 6 year by using Jan 31st is less than equal to purchase date + 6 years
          and si.LATEST_COVERAGE_TYPE not in (2,6,21,20)-- latest coverage type not in (6,21)
;-- New count is now 24369
-- 25937