select max(ATT.CREATION_DT),min(ATT.CREATION_DT),AD.ADDRESS_LINE1_TX,AD.COUNTRY_CD,SUPPRESSION_CD,ACE_ERROR_CD,COUNT(*) from GNRC.ADDRESS_DIM AD
            LEFT JOIN AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
         where ADDRESS_LINE1_TX IS NULL AND substr(coalesce(ace_error_cd,'x'),1,1) <> 'E' and COUNTRY_CD <> 'CAN'
group by AD.ADDRESS_LINE1_TX,SUPPRESSION_CD,ACE_ERROR_CD,AD.COUNTRY_CD
;--0
-- +--------------------------+--------------------------+----------------+----------+--------------+------------+--------+
-- |MAX(ATT.CREATION_DT)      |MIN(ATT.CREATION_DT)      |ADDRESS_LINE1_TX|COUNTRY_CD|SUPPRESSION_CD|ACE_ERROR_CD|COUNT(*)|
-- +--------------------------+--------------------------+----------------+----------+--------------+------------+--------+
-- |2025-09-04 19:15:40.000000|2017-08-18 02:05:11.000000|NULL            |USA       |N             |NULL        |452     |
-- |2017-11-10 02:05:11.000000|2017-11-10 02:05:11.000000|NULL            |USA       |N             |S89000      |1       |
-- |2018-05-10 19:15:56.000000|2017-02-20 09:27:00.000000|NULL            |USA       |N             |S00000      |3       |
-- |2018-01-05 02:56:24.000000|2018-01-05 02:56:24.000000|NULL            |USA       |N             |S81000      |1       |
-- |2018-06-21 19:15:53.000000|2017-02-20 09:27:00.000000|NULL            |USA       |N             |S80000      |5       |
-- |2018-06-21 19:15:53.000000|2018-06-14 19:15:55.000000|NULL            |USA       |N             |SA0000      |2       |
-- |2025-07-16 02:20:38.000000|2025-04-30 21:13:50.000000|NULL            |USA       |Y             |NULL        |18      |
-- +--------------------------+--------------------------+----------------+----------+--------------+------------+--------+