GNRC> DECLARE
             v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC-1835', p_table_nm => 'ADDRESS_DIM');

      BEGIN

              update  ADDRESS_DIM
                  SET  SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key,ACE_ERROR_CD = 'E0000',SUPPRESSION_CD = 'Y'
              where ADDRESS_KEY in (

                      select ADDRESS_KEY from (
                      select AD.ADDRESS_KEY,ATT.CREATION_DT,LTRIM(TRIM(ADDRESS_LINE1_TX) ,'0') ADDRESS_LINE1_TX_NEW,AD.ADDRESS_LINE1_TX,SUPPRESSION_CD,COUNTRY_CD ,ACE_ERROR_CD from GNRC.ADDRESS_DIM AD
                                  LEFT JOIN AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                               where  not REGEXP_LIKE(LTRIM(TRIM(ADDRESS_LINE1_TX),'0'), '^[0-9]')

                                 AND ADDRESS_KEY in (
                                     select AD.ADDRESS_KEY from GNRC.ADDRESS_DIM AD  where ADDRESS_LINE1_TX Like '0%'
                                   )
                                  AND substr(coalesce(ace_error_cd,'x'),1,1) <> 'E'
                      )
                      where    not REGEXP_LIKE(LTRIM(TRIM(ADDRESS_LINE1_TX_NEW),'N'), '^[0-9]')
                                 AND not REGEXP_LIKE(LTRIM(TRIM(ADDRESS_LINE1_TX_NEW),'S'), '^[0-9]')
                                  AND not REGEXP_LIKE(LTRIM(TRIM(ADDRESS_LINE1_TX_NEW),'-'), '^[0-9]')
                                  AND COUNTRY_CD <> 'CAN'
                  )

              ;

             DBMS_OUTPUT.PUT_LINE(v_audit_key);
            DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );


            -- COMMIT;

      END;
[2025-09-12 01:38:43] completed in 1 s 248 ms
1113320
19
