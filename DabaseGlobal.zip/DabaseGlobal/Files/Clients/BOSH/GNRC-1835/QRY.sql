
select ATT.CREATION_DT,AD.ADDRESS_LINE1_TX,SUPPRESSION_CD ,ACE_ERROR_CD from GNRC.ADDRESS_DIM AD
            LEFT JOIN AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
         where ADDRESS_LINE1_TX Like '000%';
-- +--------------------------+--------------------+--------------+------------+
-- |CREATION_DT               |ADDRESS_LINE1_TX    |SUPPRESSION_CD|ACE_ERROR_CD|
-- +--------------------------+--------------------+--------------+------------+
-- |2017-02-20 09:27:00.000000|00007 KOEHN RD      |N             |S00000      |
-- |2017-09-22 02:05:10.000000|000 RIDGELINE DR    |N             |E421        |
-- |2018-05-10 19:15:56.000000|00000 YAGGY RD      |N             |E421        |
-- |2021-03-17 11:51:49.000000|0000 LEESVILLE RD   |N             |E421        |
-- |2021-05-13 19:15:34.000000|0000 11TH PUMP #2   |N             |E412        |
-- |2021-05-13 19:15:34.000000|0000 10TH. ST       |N             |E421        |
-- |2021-11-18 19:15:34.000000|000 NO ADDRESS GIVEN|N             |E412        |
-- |2022-07-28 19:15:35.000000|00001 KOEHN RD      |N             |S00000      |
-- |2022-09-20 09:12:50.000000|0001                |N             |E420        |
-- |2023-08-29 09:25:29.000000|0000000000          |N             |E420        |
-- |2023-12-15 11:31:29.000000|0000                |N             |E420        |
-- |2025-01-22 05:20:51.000000|0000000000          |N             |E420        |
-- |2025-01-28 05:23:27.000000|000 NO ADDRESS GIVEN|N             |E412        |
-- |2025-05-08 19:15:40.000000|000 OLD SCHOOL RD   |N             |NULL        |
-- +--------------------------+--------------------+--------------+------------+


select ATT.CREATION_DT,AD.ADDRESS_LINE1_TX,SUPPRESSION_CD ,ACE_ERROR_CD from GNRC.ADDRESS_DIM AD
            LEFT JOIN AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
         where ADDRESS_LINE1_TX Like '0 %';
-- +--------------------------+------------------------+--------------+------------+
-- |CREATION_DT               |ADDRESS_LINE1_TX        |SUPPRESSION_CD|ACE_ERROR_CD|
-- +--------------------------+------------------------+--------------+------------+
-- |2017-02-20 09:27:00.000000|0 STRAWBERRY LN         |N             |S00000      |
-- |2017-02-20 09:27:00.000000|0 LANG LN               |N             |E412        |
-- |2017-02-20 09:27:00.000000|0 BROADWAY N            |N             |S00000      |
-- |2017-02-20 09:27:00.000000|0 GRAVEL ISLAND RD      |N             |S00000      |
-- |2017-02-20 09:27:00.000000|0 PACIFIC ST            |N             |E421        |
-- |2017-02-20 09:27:00.000000|0 SKYTOP LDG            |N             |S80000      |
-- |2017-02-20 09:27:00.000000|0 MCCARTHY AVE          |N             |S00000      |
-- |2017-02-20 09:27:00.000000|0 UNIVERSITY OF MARYLAND|N             |S00000      |
-- |2017-02-20 09:27:00.000000|0 CATRON WAY            |N             |E421        |
-- |2017-02-20 09:27:00.000000|0 RED SAND TRL          |N             |E421        |
-- |2017-04-07 07:48:56.000000|0 MCCARTHY AVE          |N             |S00000      |
-- |2017-07-31 01:22:51.000000|0 STATE ROUTE 9N LN     |N             |S00000      |
-- |2018-02-15 19:16:07.000000|0 OLD ANDERSON CREEK RD |N             |E421        |
-- |2018-08-21 09:35:40.000000|0 VERULAM RD            |N             |NULL        |
-- |2018-08-21 09:35:40.000000|0 PARADISE LAKE ST      |N             |NULL        |
-- |2018-08-21 09:35:40.000000|0 ROBERT RD             |N             |NULL        |
-- |2018-11-08 19:16:04.000000|0 BUGGY WHIP DR         |N             |S80000      |
-- |2019-06-13 19:16:52.000000|0 TORRES NW 9TH AVE     |N             |E412        |
-- |2019-08-08 19:16:52.000000|0 COUNTY ROAD TOWNSHIP  |N             |E412        |
-- |2019-12-12 19:16:35.000000|0 ERLEN DR              |N             |S00000      |
-- |2020-11-26 19:15:31.000000|0 CAROL DRIVE           |N             |E421        |
-- |2020-12-10 19:15:32.000000|0 FREEMAN RD            |N             |E421        |
-- |2021-01-07 19:15:32.000000|0 DEVILS ELBOW          |N             |S00000      |
-- |2021-02-11 19:15:33.000000|0 WESTWAYS RD.          |N             |E412        |
-- |2021-03-17 11:51:49.000000|0 S 525 INDIDAN ROAD    |N             |E412        |
-- |2021-03-17 11:51:49.000000|0 HORSESHOE TRL         |N             |E421        |
-- |2021-06-10 19:15:37.000000|0 SUNDEW LANE           |N             |NULL        |
-- |2022-04-11 11:18:12.000000|0 LAUGHLIN AFB          |N             |S00000      |
-- |2023-01-26 19:15:36.000000|0 HIAWATHA IS           |N             |S00000      |
-- |2023-03-09 19:15:33.000000|0 BAYBERRY RD           |N             |E421        |
-- |2023-05-18 19:15:34.000000|0 VISCARNO              |N             |E412        |
-- |2023-05-25 19:15:36.000000|0 OLD STOCKTON RD       |N             |E421        |
-- |2023-05-25 19:15:36.000000|0 MURRAY BLVD           |N             |E421        |
-- |2023-05-25 19:15:36.000000|0 PEETEER VILLE         |N             |E421        |
-- |2023-05-25 19:15:36.000000|0 GOOD HOPE RD          |N             |E421        |
-- |2023-05-25 19:15:36.000000|0 UNITY CHURCH RD       |N             |E421        |
-- |2023-07-20 19:15:38.000000|0 COTTON PT             |N             |S00000      |
-- |2023-08-29 09:25:29.000000|0 VIVA WAY              |N             |E421        |
-- |2023-08-29 09:25:29.000000|0 ADDRESS GIVE N        |N             |NULL        |
-- |2023-10-12 19:15:36.000000|0 DOUBLE OX RD          |N             |E421        |
-- |2023-11-02 19:15:37.000000|0 SANTA FE LN           |N             |E421        |
-- |2023-12-28 19:15:40.000000|0 SWAN VIEW DR          |N             |E421        |
-- |2024-01-04 19:15:39.000000|0 STATE ROUTE 54A       |N             |E421        |
-- |2024-02-01 19:15:38.000000|0 DETWILER RD           |N             |E412        |
-- |2024-02-01 19:15:38.000000|0 BEAR GRASS LN         |N             |E421        |
-- |2024-07-23 09:40:37.000000|0 FAIRY ISLAND          |N             |NULL        |
-- |2024-08-22 19:15:39.000000|0 AVE                   |N             |NULL        |
-- |2025-01-02 11:21:22.000000|0 PARKWAY DRIVE         |N             |E421        |
-- |2025-01-28 05:23:27.000000|0 CAROL DRIVE           |N             |E421        |
-- |2025-01-28 05:23:27.000000|0 BAYBERRY RD           |N             |S80000      |
-- |2025-03-20 19:15:41.000000|0 ATLANTA STREET        |N             |E421        |
-- |2025-06-26 19:15:40.000000|0 MAIN ST               |N             |NULL        |
-- |2025-07-03 19:15:38.000000|0 GRIGGSTOWN RD         |N             |NULL        |
-- |2025-09-04 19:15:40.000000|0 STATE ROUTE 9N LN     |N             |NULL        |
-- +--------------------------+------------------------+--------------+------------+

select * from (
select ATT.CREATION_DT,LTRIM(TRIM(ADDRESS_LINE1_TX) ,'0') ADDRESS_LINE1_TX_NEW,AD.ADDRESS_LINE1_TX,SUPPRESSION_CD,COUNTRY_CD ,ACE_ERROR_CD from GNRC.ADDRESS_DIM AD
            LEFT JOIN AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
         where  not REGEXP_LIKE(LTRIM(TRIM(ADDRESS_LINE1_TX),'0'), '^[0-9]')

           AND ADDRESS_KEY in (
               select AD.ADDRESS_KEY from GNRC.ADDRESS_DIM AD  where ADDRESS_LINE1_TX Like '0%'
             )
            AND substr(coalesce(ace_error_cd,'x'),1,1) <> 'E'
)
where    not REGEXP_LIKE(LTRIM(TRIM(ADDRESS_LINE1_TX_NEW),'N'), '^[0-9]')
           AND not REGEXP_LIKE(LTRIM(TRIM(ADDRESS_LINE1_TX_NEW),'S'), '^[0-9]')
            AND not REGEXP_LIKE(LTRIM(TRIM(ADDRESS_LINE1_TX_NEW),'-'), '^[0-9]')
             ;
-- remove starting from E
-- remove also from starting from N or S so we remove one more charter and check if numeric present
-- we will update with E0000 and Suppression_cd = 'Y'
-- we also handle address use dashes like -100 BELLAIR AVE
--check how many Canada records
-- +--------------------------+-----------------------+------------------------+--------------+----------+------------+
-- |CREATION_DT               |ADDRESS_LINE1_TX_NEW   |ADDRESS_LINE1_TX        |SUPPRESSION_CD|COUNTRY_CD|ACE_ERROR_CD|
-- +--------------------------+-----------------------+------------------------+--------------+----------+------------+
-- |2018-08-21 09:35:40.000000| VERULAM RD            |0 VERULAM RD            |N             |CAN       |NULL        |
-- |2018-08-21 09:35:40.000000| PARADISE LAKE ST      |0 PARADISE LAKE ST      |N             |CAN       |NULL        |
-- |2018-08-21 09:35:40.000000| ROBERT RD             |0 ROBERT RD             |N             |CAN       |NULL        |
-- |2021-06-10 19:15:37.000000| SUNDEW LANE           |0 SUNDEW LANE           |N             |CAN       |NULL        |
-- |2023-08-29 09:25:29.000000| ADDRESS GIVE N        |0 ADDRESS GIVE N        |N             |CAN       |NULL        |
-- |2024-07-23 09:40:37.000000| FAIRY ISLAND          |0 FAIRY ISLAND          |N             |CAN       |NULL        |
-- |2024-08-22 19:15:39.000000| AVE                   |0 AVE                   |N             |CAN       |NULL        |
-- |2017-02-20 09:27:00.000000| STRAWBERRY LN         |0 STRAWBERRY LN         |N             |USA       |S00000      |
-- |2017-02-20 09:27:00.000000| BROADWAY N            |0 BROADWAY N            |N             |USA       |S00000      |
-- |2017-02-20 09:27:00.000000| GRAVEL ISLAND RD      |0 GRAVEL ISLAND RD      |N             |USA       |S00000      |
-- |2017-02-20 09:27:00.000000| SKYTOP LDG            |0 SKYTOP LDG            |N             |USA       |S80000      |
-- |2017-02-20 09:27:00.000000| MCCARTHY AVE          |0 MCCARTHY AVE          |N             |USA       |S00000      |
-- |2017-02-20 09:27:00.000000| UNIVERSITY OF MARYLAND|0 UNIVERSITY OF MARYLAND|N             |USA       |S00000      |
-- |2017-04-07 07:48:56.000000| MCCARTHY AVE          |0 MCCARTHY AVE          |N             |USA       |S00000      |
-- |2017-07-31 01:22:51.000000| STATE ROUTE 9N LN     |0 STATE ROUTE 9N LN     |N             |USA       |S00000      |
-- |2018-11-08 19:16:04.000000| BUGGY WHIP DR         |0 BUGGY WHIP DR         |N             |USA       |S80000      |
-- |2019-12-12 19:16:35.000000| ERLEN DR              |0 ERLEN DR              |N             |USA       |S00000      |
-- |2021-01-07 19:15:32.000000| DEVILS ELBOW          |0 DEVILS ELBOW          |N             |USA       |S00000      |
-- |2022-04-11 11:18:12.000000| LAUGHLIN AFB          |0 LAUGHLIN AFB          |N             |USA       |S00000      |
-- |2023-01-26 19:15:36.000000| HIAWATHA IS           |0 HIAWATHA IS           |N             |USA       |S00000      |
-- |2023-07-20 19:15:38.000000| COTTON PT             |0 COTTON PT             |N             |USA       |S00000      |
-- |2025-01-28 05:23:27.000000| BAYBERRY RD           |0 BAYBERRY RD           |N             |USA       |S80000      |
-- |2025-05-08 19:15:40.000000| OLD SCHOOL RD         |000 OLD SCHOOL RD       |N             |USA       |NULL        |
-- |2025-06-26 19:15:40.000000| MAIN ST               |0 MAIN ST               |N             |USA       |NULL        |
-- |2025-07-03 19:15:38.000000| GRIGGSTOWN RD         |0 GRIGGSTOWN RD         |N             |USA       |NULL        |
-- |2025-09-04 19:15:40.000000| STATE ROUTE 9N LN     |0 STATE ROUTE 9N LN     |N             |USA       |NULL        |
-- +--------------------------+-----------------------+------------------------+--------------+----------+------------+
-- +--------------------------+---------------------------------+------------------------+--------------+------------+
-- |CREATION_DT               |LTRIM(TRIM(ADDRESS_LINE1_TX),'0')|ADDRESS_LINE1_TX        |SUPPRESSION_CD|ACE_ERROR_CD|
-- +--------------------------+---------------------------------+------------------------+--------------+------------+
-- |2017-02-20 09:27:00.000000| STRAWBERRY LN                   |0 STRAWBERRY LN         |N             |S00000      |
-- |2017-02-20 09:27:00.000000| LANG LN                         |0 LANG LN               |N             |E412        |
-- |2017-02-20 09:27:00.000000| BROADWAY N                      |0 BROADWAY N            |N             |S00000      |
-- |2017-02-20 09:27:00.000000| GRAVEL ISLAND RD                |0 GRAVEL ISLAND RD      |N             |S00000      |
-- |2017-02-20 09:27:00.000000| PACIFIC ST                      |0 PACIFIC ST            |N             |E421        |
-- |2017-02-20 09:27:00.000000|-100 BELLAIR AVE                 |00-100 BELLAIR AVE      |Y             |S00000      |
-- |2017-02-20 09:27:00.000000|-132 YERGER RD                   |00-132 YERGER RD        |N             |S00000      |
-- |2017-02-20 09:27:00.000000|-162 TUNBRIDGE RD                |00-162 TUNBRIDGE RD     |N             |S00000      |
-- |2017-02-20 09:27:00.000000| SKYTOP LDG                      |0 SKYTOP LDG            |N             |S80000      |
-- |2017-02-20 09:27:00.000000| MCCARTHY AVE                    |0 MCCARTHY AVE          |N             |S00000      |
-- |2017-02-20 09:27:00.000000| UNIVERSITY OF MARYLAND          |0 UNIVERSITY OF MARYLAND|N             |S00000      |
-- |2017-02-20 09:27:00.000000| CATRON WAY                      |0 CATRON WAY            |N             |E421        |
-- |2017-02-20 09:27:00.000000|N636 FIELDSTONE LN               |0N636 FIELDSTONE LN     |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N311 CHARLOTTE DR                |0N311 CHARLOTTE DR      |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N856 SHADE TREE LN               |0N856 SHADE TREE LN     |N             |S00000      |
-- |2017-02-20 09:27:00.000000|S651 CORNELL AVE                 |0S651 CORNELL AVE       |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N748 PETER RD                    |0N748 PETER RD          |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N546 WILLOW RD                   |0N546 WILLOW RD         |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N708 PETER RD                    |0N708 PETER RD          |Y             |S00000      |
-- |2017-02-20 09:27:00.000000|N436 WILLOW RD                   |0N436 WILLOW RD         |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N650 COVENTRY DR                 |0N650 COVENTRY DR       |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N177 WOODLAND CT                 |0N177 WOODLAND CT       |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N651 HERRICK DR                  |0N651 HERRICK DR        |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N751 WAVERLY CT                  |0N751 WAVERLY CT        |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N026 PIERCE AVE                  |0N026 PIERCE AVE        |N             |S00000      |
-- |2017-02-20 09:27:00.000000|S016 COTTONWOOD DR               |0S016 COTTONWOOD DR     |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N075 COBBLESTONE LN              |0N075 COBBLESTONE LN    |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N431 SILVERWOOD CT               |0N431 SILVERWOOD CT     |N             |SA0000      |
-- |2017-02-20 09:27:00.000000|N068 ROBBINS ST                  |0N068 ROBBINS ST        |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N355 WINFIELD RD                 |0N355 WINFIELD RD       |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N187 ROBBINS ST                  |0N187 ROBBINS ST        |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N378 COUNTY FARM RD              |0N378 COUNTY FARM RD    |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N178 CALVIN CT                   |0N178 CALVIN CT         |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N236 STANLEY ST                  |0N236 STANLEY ST        |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N420 KELLY CT                    |0N420 KELLY CT          |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N269 WOODVALE ST                 |0N269 WOODVALE ST       |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N307 CALVIN CT                   |0N307 CALVIN CT         |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N644 ALTA LN                     |0N644 ALTA LN           |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N508 ARBOR CT                    |0N508 ARBOR CT          |N             |S00000      |
-- |2017-02-20 09:27:00.000000|S065 RIVER LN                    |0S065 RIVER LN          |N             |S00000      |
-- |2017-02-20 09:27:00.000000|S118 WINFIELD RD                 |0S118 WINFIELD RD       |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N047 STANLEY ST                  |0N047 STANLEY ST        |N             |S00000      |
-- |2017-02-20 09:27:00.000000|S504 EAST ST                     |0S504 EAST ST           |N             |S00000      |
-- |2017-02-20 09:27:00.000000|S675 GRANT ST                    |0S675 GRANT ST          |N             |S00000      |
-- |2017-02-20 09:27:00.000000|N427 VIRGINIA ST                 |0N427 VIRGINIA ST       |N             |S00000      |
-- |2017-02-20 09:27:00.000000| RED SAND TRL                    |0 RED SAND TRL          |N             |E421        |
-- |2017-04-07 07:48:56.000000| MCCARTHY AVE                    |0 MCCARTHY AVE          |N             |S00000      |
-- |2017-07-31 01:22:51.000000| STATE ROUTE 9N LN               |0 STATE ROUTE 9N LN     |N             |S00000      |
-- |2017-09-16 00:05:30.000000|N708 PETER RD                    |0N708 PETER RD          |N             |S90000      |
-- |2017-09-22 02:05:10.000000| RIDGELINE DR                    |000 RIDGELINE DR        |N             |E421        |
-- +--------------------------+---------------------------------+------------------------+--------------+------------+

select max(ATT.CREATION_DT),min(ATT.CREATION_DT),AD.ADDRESS_LINE1_TX,AD.COUNTRY_CD,SUPPRESSION_CD,ACE_ERROR_CD,COUNT(*) from GNRC.ADDRESS_DIM AD
            LEFT JOIN AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
         where ADDRESS_LINE1_TX IS NULL AND substr(coalesce(ace_error_cd,'x'),1,1) <> 'E'
group by AD.ADDRESS_LINE1_TX,SUPPRESSION_CD,ACE_ERROR_CD,AD.COUNTRY_CD
;--0


select --max(ATT.CREATION_DT),min(ATT.CREATION_DT),AD.ADDRESS_LINE1_TX,SUPPRESSION_CD,ACE_ERROR_CD,COUNT(*)
ATT.CREATION_DT,AD.ADDRESS_LINE1_TX,AD.ADDRESS_LINE2_TX,AD.CITY_NM,AD.ZIP_CODE5_TX,AD.STATE_CD,SUPPRESSION_CD,ACE_ERROR_CD
from GNRC.ADDRESS_DIM AD
            LEFT JOIN AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
         where ADDRESS_LINE1_TX IS NULL   AND substr(coalesce(ace_error_cd,'x'),1,1) <> 'E' and COUNTRY_CD <> 'CAN'
ORDER BY DBMS_RANDOM.RANDOM()
--group by AD.ADDRESS_LINE1_TX,SUPPRESSION_CD,ACE_ERROR_CD
;--0
-- ACE_ERROR_CD = E0000
-- SUPPRESSION_CD = Y