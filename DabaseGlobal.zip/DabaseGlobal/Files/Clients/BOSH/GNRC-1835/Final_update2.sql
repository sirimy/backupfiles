[2025-09-12 01:45:14] transaction committed: @console_94 [GNRC-CORE-PROD]
GNRC> DECLARE
                   v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update for ADDRESS_LINE1_TX IS NULL', p_process_nm => 'GNRC-1835', p_table_nm => 'ADDRESS_DIM');

            BEGIN

                    update  ADDRESS_DIM
                        SET  SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key,ACE_ERROR_CD = 'E0000',SUPPRESSION_CD = 'Y'
                    where ADDRESS_KEY in (
                              select ADDRESS_KEY from GNRC.ADDRESS_DIM AD
                                  LEFT JOIN AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                               where ADDRESS_LINE1_TX IS NULL AND substr(coalesce(ace_error_cd,'x'),1,1) <> 'E' and COUNTRY_CD <> 'CAN'

                        )

                    ;

                   DBMS_OUTPUT.PUT_LINE(v_audit_key);
                   DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );


                  -- COMMIT;

            END;
[2025-09-12 01:52:31] completed in 1 s 8 ms
1113321
482
