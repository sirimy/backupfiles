


select * from policy where description like '%AO%' and effective_dt = '2025-07-22 00:00:00.000000'
                       and age is not null;


BOSH: boshbaplweb, public> update policy
                           SET age = NULL
                           where description like '%AO%' and effective_dt = '2025-07-22 00:00:00.000000'
                                                  and age is not null
[2025-08-25 20:37:34] 172 rows affected in 270 ms
[2025-08-25 20:37:37] transaction committed: @console_81 [BOSH-WEb-PROD]
