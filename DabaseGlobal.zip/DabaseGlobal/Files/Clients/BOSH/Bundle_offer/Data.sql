
select * from ownership_xref where serialized_item_id = 21324766;

select customer_id,COUNT(*) from ownership_xref
group by customer_id
having count(*) > 5
ORDER BY customer_id
;
-- +-----------+-----+
-- |customer_id|count|
-- +-----------+-----+
-- |36290      |8    |
-- |44284      |8    |
-- |48536      |8    |
-- |51412      |8    |
-- |51594      |8    |
-- |37056      |9    |
-- |40588      |9    |
-- |1072       |10   |
-- |9632       |10   |
-- |39602      |10   |
-- |48636      |11   |
-- |8614       |12   |
-- |35016      |12   |
-- |28756      |16   |
-- |23022      |29   |
-- +-----------+-----+
select ox.customer_id,b.name, si.serialized_item_id,si.latest_coverage_exp_dt,si.latest_coverage_type_id
from ownership_xref ox join serialized_item si on ox.serialized_item_id = si.serialized_item_id
    join product p on si.product_id = p.product_id
    join brand b on p.brand_id = b.brand_id
where ox.customer_id = 4911728;
--ARRAY['21245258','21318798','21324766']
--ARRAY['21169470','21238092','21238434','21241322','21242616']
-- +-----------+---------+------------------+--------------------------+-----------------------+
-- |customer_id|name     |serialized_item_id|latest_coverage_exp_dt    |latest_coverage_type_id|
-- +-----------+---------+------------------+--------------------------+-----------------------+
-- |4911728    |Bosch    |21245258          |2024-09-30 00:00:00.000000|1                      |
-- |4911728    |Bosch    |21318798          |2024-10-10 00:00:00.000000|1                      |
-- |4911728    |Bosch    |21324766          |2024-10-10 00:00:00.000000|1                      |
-- |4911728    |Thermador|21169470          |2025-07-08 00:00:00.000000|1                      |
-- |4911728    |Thermador|21238092          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21238434          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21241322          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21242616          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21246798          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21254864          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21257402          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21258602          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21259860          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|21260116          |2025-09-30 00:00:00.000000|1                      |
-- |4911728    |Thermador|22115400          |2025-11-15 00:00:00.000000|1                      |
-- +-----------+---------+------------------+--------------------------+-----------------------+

-- +-----------+-----+------------------+--------------------------+-----------------------+
-- |customer_id|name |serialized_item_id|latest_coverage_exp_dt    |latest_coverage_type_id|
-- +-----------+-----+------------------+--------------------------+-----------------------+
-- |5304946    |Bosch|23112354          |2025-02-07 00:00:00.000000|1                      |
-- |5304946    |Bosch|23128928          |2025-02-07 00:00:00.000000|1                      |
-- +-----------+-----+------------------+--------------------------+-----------------------+
--ARRAY['23112354','23128928']

-- +-----------+-----+------------------+--------------------------+-----------------------+
-- |customer_id|name |serialized_item_id|latest_coverage_exp_dt    |latest_coverage_type_id|
-- +-----------+-----+------------------+--------------------------+-----------------------+
-- |5306400    |Bosch|23118134          |2025-02-04 00:00:00.000000|1                      |
-- |5306400    |Bosch|23118522          |2024-12-07 00:00:00.000000|1                      |
-- |5306400    |Bosch|23122066          |2025-02-04 00:00:00.000000|1                      |
-- |5306400    |Bosch|24410752          |2025-09-07 00:00:00.000000|1                      |
-- +-----------+-----+------------------+--------------------------+-----------------------+
--ARRAY['23118134','23118522','23122066','24410752']

-- +-----------+-----+------------------+--------------------------+-----------------------+
-- |customer_id|name |serialized_item_id|latest_coverage_exp_dt    |latest_coverage_type_id|
-- +-----------+-----+------------------+--------------------------+-----------------------+
-- |5194932    |Bosch|22591498          |2025-03-06 00:00:00.000000|1                      |
-- |5194932    |Bosch|23116740          |2025-03-06 00:00:00.000000|1                      |
-- |5194932    |Bosch|23116790          |2025-03-06 00:00:00.000000|1                      |
-- |5194932    |Bosch|23131656          |2025-03-06 00:00:00.000000|1                      |
-- |5194932    |Bosch|23131710          |2025-03-06 00:00:00.000000|1                      |
-- |5194932    |Bosch|23132366          |2025-03-06 00:00:00.000000|1                      |
-- +-----------+-----+------------------+--------------------------+-----------------------+
--ARRAY['22591498','23116740','23116790','23131656','23131710','23132366']

-- +-----------+---------+------------------+--------------------------+-----------------------+
-- |customer_id|name     |serialized_item_id|latest_coverage_exp_dt    |latest_coverage_type_id|
-- +-----------+---------+------------------+--------------------------+-----------------------+
-- |4946300    |Thermador|21317292          |2025-06-07 00:00:00.000000|1                      |
-- |4946300    |Thermador|21317702          |2025-06-07 00:00:00.000000|1                      |
-- |4946300    |Thermador|21325104          |2025-05-31 00:00:00.000000|1                      |
-- |4946300    |Thermador|21333664          |2025-06-07 00:00:00.000000|1                      |
-- |4946300    |Thermador|21336234          |2025-06-07 00:00:00.000000|1                      |
-- |4946300    |Thermador|25371534          |2026-10-01 00:00:00.000000|1                      |
-- |4946300    |Thermador|25374904          |2026-10-01 00:00:00.000000|1                      |
-- |4946300    |Thermador|25383182          |2026-10-01 00:00:00.000000|1                      |
-- +-----------+---------+------------------+--------------------------+-----------------------+
--ARRAY['21317292','21317702','21325104','21333664','21336234']

-- +-----------+---------+------------------+--------------------------+-----------------------+
-- |customer_id|name     |serialized_item_id|latest_coverage_exp_dt    |latest_coverage_type_id|
-- +-----------+---------+------------------+--------------------------+-----------------------+
-- |35016      |Bosch    |2515374           |2016-04-27 00:00:00.000000|1                      |
-- |35016      |Thermador|14950336          |2023-05-10 00:00:00.000000|1                      |
-- |35016      |Thermador|14954852          |2023-05-10 00:00:00.000000|1                      |
-- |35016      |Thermador|14954878          |2023-05-10 00:00:00.000000|1                      |
-- |35016      |Thermador|14957976          |2023-05-10 00:00:00.000000|1                      |
-- |35016      |Thermador|14960316          |2023-05-10 00:00:00.000000|1                      |
-- |35016      |Thermador|16779044          |2023-12-03 00:00:00.000000|1                      |
-- |35016      |Thermador|18946108          |2023-05-10 00:00:00.000000|1                      |
-- |35016      |Thermador|19091604          |2023-11-17 00:00:00.000000|1                      |
-- |35016      |Thermador|19689078          |2023-12-19 00:00:00.000000|1                      |
-- +-----------+---------+------------------+--------------------------+-----------------------+


-- +------+------------------+-----------+------------+--------------------------------------------------------------------------------+-----------------+----------+--------------------------+--------+
-- |job_id|serialized_item_id|customer_id|offer_status|error_desc                                                                      |existing_offer_id|created_by|log_date                  |offer_id|
-- +------+------------------+-----------+------------+--------------------------------------------------------------------------------+-----------------+----------+--------------------------+--------+
-- |151807|14954852          |35016      |O           |Offer Items creating for serial item 14954852 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.143620|B6637UV |
-- |151807|14954852          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.158611|B6637UV |
-- |151807|18946108          |35016      |O           |Offer Items creating for serial item 18946108 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.167982|B6637UV |
-- |151807|18946108          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.182467|B6637UV |
-- |151807|14960316          |35016      |O           |Offer Items creating for serial item 14960316 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.191576|B6637UV |
-- |151807|14960316          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.205427|B6637UV |
-- |151807|19091604          |35016      |O           |Offer Items creating for serial item 19091604 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.214163|B6637UV |
-- |151807|19091604          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.227325|B6637UV |
-- |151807|14957976          |35016      |O           |Offer Items creating for serial item 14957976 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.235726|B6637UV |
-- |151807|14957976          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.248814|B6637UV |
-- |151807|14950336          |35016      |O           |Offer Items creating for serial item 14950336 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.257174|B6637UV |
-- |151807|14950336          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.270330|B6637UV |
-- |151807|14954878          |35016      |O           |Offer Items creating for serial item 14954878 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.279183|B6637UV |
-- |151807|14954878          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.293058|B6637UV |
-- |151807|19689078          |35016      |O           |Offer Items creating for serial item 19689078 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.301662|B6637UV |
-- |151807|19689078          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.315153|B6637UV |
-- |151807|16779044          |35016      |O           |Offer Items creating for serial item 16779044 and offer 61722                   |NULL             |iahmad    |2025-09-11 06:57:22.323881|B6637UV |
-- |151807|16779044          |35016      |E           |Unable to create offer: Product Not Eligible                                    |NULL             |iahmad    |2025-09-11 06:57:22.337077|B6637UV |
-- |151807|16779044          |35016      |FE          |No offer got created. Error Raised: Unable to create offer: Product Not Eligible|NULL             |iahmad    |2025-09-11 06:57:22.349321|B6637UV |
-- +------+------------------+-----------+------------+--------------------------------------------------------------------------------+-----------------+----------+--------------------------+--------+


-- +-----------+---------+------------------+--------------------------+-----------------------+
-- |customer_id|name     |serialized_item_id|latest_coverage_exp_dt    |latest_coverage_type_id|
-- +-----------+---------+------------------+--------------------------+-----------------------+
-- |9744201    |Thermador|216214113         |2027-04-23 00:00:00.000000|1                      |
-- |9744201    |Thermador|216214119         |2027-04-23 00:00:00.000000|1                      |
-- |9744201    |Thermador|216214125         |2027-04-23 00:00:00.000000|1                      |
-- |9744201    |Thermador|216214159         |2027-04-23 00:00:00.000000|1                      |
-- |9744201    |Thermador|216214165         |2027-04-23 00:00:00.000000|1                      |
-- |9744201    |Thermador|216214171         |2027-04-23 00:00:00.000000|1                      |
-- +-----------+---------+------------------+--------------------------+-----------------------+
-- +------+------------------+-----------+------------+--------------------------------------------------------------+-----------------+----------+--------------------------+--------+
-- |job_id|serialized_item_id|customer_id|offer_status|error_desc                                                    |existing_offer_id|created_by|log_date                  |offer_id|
-- +------+------------------+-----------+------------+--------------------------------------------------------------+-----------------+----------+--------------------------+--------+
-- |151806|216214125         |9744201    |O           |Offer Items creating for serial item 216214125 and offer 61721|NULL             |iahmad    |2025-09-11 06:52:27.349611|BHG2BWL |
-- |151806|216214171         |9744201    |O           |Offer Items creating for serial item 216214171 and offer 61721|NULL             |iahmad    |2025-09-11 06:52:27.376990|BHG2BWL |
-- |151806|216214159         |9744201    |O           |Offer Items creating for serial item 216214159 and offer 61721|NULL             |iahmad    |2025-09-11 06:52:27.396414|BHG2BWL |
-- |151806|216214165         |9744201    |O           |Offer Items creating for serial item 216214165 and offer 61721|NULL             |iahmad    |2025-09-11 06:52:27.412552|BHG2BWL |
-- |151806|216214119         |9744201    |O           |Offer Items creating for serial item 216214119 and offer 61721|NULL             |iahmad    |2025-09-11 06:52:27.428354|BHG2BWL |
-- |151806|216214113         |9744201    |O           |Offer Items creating for serial item 216214113 and offer 61721|NULL             |iahmad    |2025-09-11 06:52:27.442941|BHG2BWL |
-- |151806|216214113         |9744201    |FO          |Final new Offer returned to App : BHG2BWL                     |NULL             |iahmad    |2025-09-11 06:52:27.460021|BHG2BWL |
-- +------+------------------+-----------+------------+--------------------------------------------------------------+-----------------+----------+--------------------------+--------+
select * from BUNDLE_OFFER_LOG_TBL where log_date > '2025-09-10 00:00:00.000000';
-- +------+------------------+-----------+------------+-------------------------------------------------------------+
-- |job_id|serialized_item_id|customer_id|offer_status|error_desc                                                   |
-- +------+------------------+-----------+------------+-------------------------------------------------------------+
-- |151812|23131710          |5194932    |O           |Offer Items creating for serial item 23131710 and offer 61727|
-- |151812|23131710          |5194932    |E           |Unable to create offer: Product Not Eligible                 |
-- |151812|23116790          |5194932    |O           |Offer Items creating for serial item 23116790 and offer 61727|
-- |151812|23116790          |5194932    |E           |Unable to create offer: Product Not Eligible                 |
-- |151812|23116740          |5194932    |O           |Offer Items creating for serial item 23116740 and offer 61727|
-- |151812|23116740          |5194932    |E           |Unable to create offer: Product Not Eligible                 |
-- |151812|22591498          |5194932    |O           |Offer Items creating for serial item 22591498 and offer 61727|
-- |151812|22591498          |5194932    |E           |Unable to create offer: Product Not Eligible                 |
-- |151812|23132366          |5194932    |O           |Offer Items creating for serial item 23132366 and offer 61727|
-- |151812|23131656          |5194932    |O           |Offer Items creating for serial item 23131656 and offer 61727|
-- |151812|23131656          |5194932    |E           |Unable to create offer: Product Not Eligible                 |
-- |151812|23131656          |5194932    |FO          |Final new Offer returned to App : BEGCLWK                    |
-- +------+------------------+-----------+------------+-------------------------------------------------------------+
select * from BUNDLE_OFFER_LOG_TBL where log_date > '2025-09-10 00:00:00.000000' and customer_id = '5304946';
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+
-- |serialized_item_id|customer_id|offer_status|error_desc                                                   |log_date                  |
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+
-- |23112354          |5304946    |O           |Offer Items creating for serial item 23112354 and offer 61729|2025-09-11 18:34:36.777882|
-- |23128928          |5304946    |O           |Offer Items creating for serial item 23128928 and offer 61729|2025-09-11 18:34:36.800511|
-- |23128928          |5304946    |FO          |Final new Offer returned to App : B2TYHUH                    |2025-09-11 18:34:36.822059|
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+
select oit.last_updated_by,offer_id,serialized_item_id,p.description,policy_ext.channels,oit.last_updated_ts
from offer_item_tbl oit
    join policy p on oit.policy_id = p.policy_id
    join policy_ext on p.policy_id = policy_ext.policy_id
where offer_id = 61729;
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
-- |last_updated_by|offer_id|serialized_item_id|description                            |channels|last_updated_ts           |
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
-- |Bundled Offer  |61729   |23128928          |4 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:34:25.577856|
-- |Bundled Offer  |61729   |23128928          |2 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:34:25.577856|
-- |Bundled Offer  |61729   |23128928          |1 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:34:25.577856|
-- |Bundled Offer  |61729   |23112354          |4 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:34:25.577856|
-- |Bundled Offer  |61729   |23112354          |2 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:34:25.577856|
-- |Bundled Offer  |61729   |23112354          |1 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:34:25.577856|
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
select * from offer_tbl where new_offer_id in ('B2TYHUH') order by last_updated_ts;
-- +---------------+------------+--------+-----------+--------------------------+
-- |last_updated_by|new_offer_id|offer_id|customer_id|offer_start_utc_ts        |
-- +---------------+------------+--------+-----------+--------------------------+
-- |Bundled Offer  |B2TYHUH     |61729   |5304946    |2025-09-10 00:00:00.000000|
-- +---------------+------------+--------+-----------+--------------------------+


select oit.last_updated_by,offer_id,serialized_item_id,p.description,policy_ext.channels,oit.last_updated_ts
from offer_item_tbl oit
    join policy p on oit.policy_id = p.policy_id
    join policy_ext on p.policy_id = policy_ext.policy_id
where offer_id = 61729;
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
-- |last_updated_by|offer_id|serialized_item_id|description                            |channels|last_updated_ts           |
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
-- |Bundled Offer  |61727   |23132366          |4 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:03:32.675969|
-- |Bundled Offer  |61727   |23132366          |2 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:03:32.675969|
-- |Bundled Offer  |61727   |23132366          |1 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:03:32.675969|
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+


select oit.last_updated_by,offer_id,serialized_item_id,p.description,policy_ext.channels,oit.last_updated_ts
from offer_item_tbl oit
    join policy p on oit.policy_id = p.policy_id
    join policy_ext on p.policy_id = policy_ext.policy_id
where offer_id = 61726;
-- +---------------+--------+------------------+------------------------------------------+--------+--------------------------+
-- |last_updated_by|offer_id|serialized_item_id|description                               |channels|last_updated_ts           |
-- +---------------+--------+------------------+------------------------------------------+--------+--------------------------+
-- |Bundled Offer  |61726   |21317702          |3 yr Thermador Appliance Service plan (AO)|OOW     |2025-09-11 15:44:49.700792|
-- |Bundled Offer  |61726   |21317702          |1 yr Thermador Appliance Service plan (AO)|OOW     |2025-09-11 15:44:49.700792|
-- +---------------+--------+------------------+------------------------------------------+--------+--------------------------+

select fn_real_time_offer_bundled_test('Bosch',ARRAY['23118134','23118522','23122066','24410752']::text[],'5306400','iahmad','oow');
-- BP3NUZC,BSFMZLV

select * from BUNDLE_OFFER_LOG_TBL where log_date > '2025-09-10 00:00:00.000000' and customer_id = '5306400';
-- +------+------------------+-----------+------------+-------------------------------------------------------------+
-- |job_id|serialized_item_id|customer_id|offer_status|error_desc                                                   |
-- +------+------------------+-----------+------------+-------------------------------------------------------------+
-- |151813|23118522          |5306400    |EO          |Active offer exists for serialized_itm_id.                   |
-- |151813|23118134          |5306400    |O           |Offer Items creating for serial item 23118134 and offer 61728|
-- |151813|23122066          |5306400    |O           |Offer Items creating for serial item 23122066 and offer 61728|
-- |151813|23122066          |5306400    |E           |Unable to create offer: Product Not Eligible                 |
-- |151813|23118522          |5306400    |O           |Offer Items creating for serial item 23118522 and offer 61728|
-- |151813|23118522          |5306400    |E           |Unable to create offer: Product Not Eligible                 |
-- |151813|24410752          |5306400    |O           |Offer Items creating for serial item 24410752 and offer 61728|
-- |151813|24410752          |5306400    |E           |Unable to create offer: Product Not Eligible                 |
-- |151813|24410752          |5306400    |FO          |Final new Offer returned to App : BP3NUZC,BSFMZLV            |
-- +------+------------------+-----------+------------+-------------------------------------------------------------+
select oit.last_updated_by,offer_id,serialized_item_id,p.description,policy_ext.channels,oit.last_updated_ts
from offer_item_tbl oit
    join policy p on oit.policy_id = p.policy_id
    join policy_ext on p.policy_id = policy_ext.policy_id
where offer_id = 61728;
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
-- |last_updated_by|offer_id|serialized_item_id|description                            |channels|last_updated_ts           |
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
-- |Bundled Offer  |61728   |23118134          |1 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:17:55.895181|
-- |Bundled Offer  |61728   |23118134          |2 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:17:55.895181|
-- |Bundled Offer  |61728   |23118134          |4 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 18:17:55.895181|
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+

select * from offer_tbl where new_offer_id in ('BP3NUZC','BSFMZLV') order by last_updated_ts;
-- +---------------+--------------+-----------+--------------------------+--------------------------+------------+
-- |last_updated_by|offer_id      |customer_id|offer_exp_utc_ts          |last_updated_ts           |new_offer_id|
-- +---------------+--------------+-----------+--------------------------+--------------------------+------------+
-- |bosh           |11847464074137|5306400    |2025-10-13 00:00:00.000000|2025-07-29 12:42:45.120719|BSFMZLV     |
-- |Bundled Offer  |61728         |5306400    |2025-09-18 18:17:55.895181|2025-09-11 18:17:55.895181|BP3NUZC     |
-- +---------------+--------------+-----------+--------------------------+--------------------------+------------+


select * from BUNDLE_OFFER_LOG_TBL where log_date > '2025-09-10 00:00:00.000000' and customer_id = '4911728';
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+
-- |serialized_item_id|customer_id|offer_status|error_desc                                                   |log_date                  |
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+
-- |21245258          |4911728    |O           |Offer Items creating for serial item 21245258 and offer 61730|2025-09-11 19:23:38.264030|
-- |21245258          |4911728    |E           |Unable to create offer: Product Not Eligible                 |2025-09-11 19:23:38.278021|
-- |21324766          |4911728    |O           |Offer Items creating for serial item 21324766 and offer 61730|2025-09-11 19:23:38.286942|
-- |21318798          |4911728    |O           |Offer Items creating for serial item 21318798 and offer 61730|2025-09-11 19:23:38.300598|
-- |21318798          |4911728    |FO          |Final new Offer returned to App : BJGPE2W                    |2025-09-11 19:23:38.337525|
-- +------------------+-----------+------------+-------------------------------------------------------------+--------------------------+

select oit.last_updated_by,offer_id,serialized_item_id,p.description,policy_ext.channels,oit.last_updated_ts
from offer_item_tbl oit
    join policy p on oit.policy_id = p.policy_id
    join policy_ext on p.policy_id = policy_ext.policy_id
where offer_id = 61730;
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
-- |last_updated_by|offer_id|serialized_item_id|description                            |channels|last_updated_ts           |
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
-- |Bundled Offer  |61730   |21318798          |4 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 19:23:27.008625|
-- |Bundled Offer  |61730   |21318798          |2 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 19:23:27.008625|
-- |Bundled Offer  |61730   |21318798          |1 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 19:23:27.008625|
-- |Bundled Offer  |61730   |21324766          |4 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 19:23:27.008625|
-- |Bundled Offer  |61730   |21324766          |2 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 19:23:27.008625|
-- |Bundled Offer  |61730   |21324766          |1 yr Bosch Appliance Service plan (OOW)|OOW     |2025-09-11 19:23:27.008625|
-- +---------------+--------+------------------+---------------------------------------+--------+--------------------------+
select * from offer_tbl where new_offer_id in ('BJGPE2W') order by last_updated_ts;
-- +---------------+--------+-----------+--------------------------+
-- |last_updated_by|offer_id|customer_id|last_updated_ts           |
-- +---------------+--------+-----------+--------------------------+
-- |Bundled Offer  |61730   |4911728    |2025-09-11 19:23:27.008625|
-- +---------------+--------+-----------+--------------------------+


select * from BUNDLE_OFFER_LOG_TBL where log_date > '2025-09-11 19:23:38.337525' and customer_id = '4911728';
-- +------+------------------+-----------+------------+-------------------------------------------------------------+--------------------------+
-- |job_id|serialized_item_id|customer_id|offer_status|error_desc                                                   |log_date                  |
-- +------+------------------+-----------+------------+-------------------------------------------------------------+--------------------------+
-- |151817|21238092          |4911728    |EO          |Active offer exists for serialized_itm_id.                   |2025-09-11 19:35:51.795430|
-- |151817|21241322          |4911728    |EO          |Active offer exists for serialized_itm_id.                   |2025-09-11 19:35:51.805182|
-- |151817|21169470          |4911728    |O           |Offer Items creating for serial item 21169470 and offer 61732|2025-09-11 19:36:03.660963|
-- |151817|21169470          |4911728    |E           |Unable to create offer: Product Not Eligible                 |2025-09-11 19:36:03.685657|
-- |151817|21238092          |4911728    |O           |Offer Items creating for serial item 21238092 and offer 61732|2025-09-11 19:36:03.696502|
-- |151817|21241322          |4911728    |O           |Offer Items creating for serial item 21241322 and offer 61732|2025-09-11 19:36:03.718471|
-- |151817|21242616          |4911728    |O           |Offer Items creating for serial item 21242616 and offer 61732|2025-09-11 19:36:03.771074|
-- |151817|21238434          |4911728    |O           |Offer Items creating for serial item 21238434 and offer 61732|2025-09-11 19:36:03.805331|
-- |151817|21238434          |4911728    |FO          |Final new Offer returned to App : BA7N9U3                    |2025-09-11 19:36:03.838942|
-- +------+------------------+-----------+------------+-------------------------------------------------------------+--------------------------+


select oit.last_updated_by,offer_id,serialized_item_id,p.description,policy_ext.channels,oit.last_updated_ts
from offer_item_tbl oit
    join policy p on oit.policy_id = p.policy_id
    join policy_ext on p.policy_id = policy_ext.policy_id
where offer_id = 61732;
-- +---------------+--------+------------------+------------------------------------------+--------+--------------------------+
-- |last_updated_by|offer_id|serialized_item_id|description                               |channels|last_updated_ts           |
-- +---------------+--------+------------------+------------------------------------------+--------+--------------------------+
-- |Bundled Offer  |61732   |21238434          |5 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21238434          |4 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21238434          |3 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21238434          |1 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21242616          |5 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21242616          |4 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21242616          |3 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21242616          |1 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21241322          |5 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21241322          |4 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21241322          |3 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21241322          |1 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21238092          |5 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21238092          |4 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21238092          |3 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- |Bundled Offer  |61732   |21238092          |1 yr Thermador Appliance Service plan (AM)|AM EB   |2025-09-11 19:35:51.575072|
-- +---------------+--------+------------------+------------------------------------------+--------+--------------------------+
select * from offer_tbl where new_offer_id in ('BA7N9U3') order by last_updated_ts;
-- +------------+---------------+--------+-----------+--------------------------+
-- |new_offer_id|last_updated_by|offer_id|customer_id|last_updated_ts           |
-- +------------+---------------+--------+-----------+--------------------------+
-- |BA7N9U3     |Bundled Offer  |61732   |4911728    |2025-09-11 19:35:51.575072|
-- +------------+---------------+--------+-----------+--------------------------+