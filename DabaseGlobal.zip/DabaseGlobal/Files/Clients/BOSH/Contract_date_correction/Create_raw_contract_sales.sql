-- BOSHSTG>
    DECLARE
                 v_audit_key INTEGER := get_audit_key (p_program_nm => 'Manual update', p_DESCRIPTIVE_TX => 'Manually populating data for contracts with date issue BOSH-1941', p_table_nm => 'RAW_CONTRACT_SALES_TBL', p_author_nm => 'iahmad' );
         BEGIN

                 Insert into RAW_CONTRACT_SALES_TBL
                     (UNIQUE_IDENTIFIER, P2_CONTRACT_NO, STATUS_CD,
                      CONTRACT_START_DATE, CONTRACT_END_DATE,
                      ERROR_TXT, FILE_NM, BILLING_UNIQUE_SEQ_NO, SHIPPING_UNIQUE_SEQ_NO, INSERT_AUDIT_KEY)
                  select  Replace(T1.NAME,'BSH-','') AS UNIQUE_IDENTIFIER, T1.NAME AS P2_CONTRACT_NO, 'ACTIVE',
                          TO_CHAR(CORRECTED_CONTRACT_START_DATE, 'MM/DD/YYYY'), TO_CHAR(CORRECT_CONTRACT_END_DATE, 'MM/DD/YYYY'),
                          'CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR', 'Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941', NULL, NULL, v_audit_key
                 from  BOSHSTG.OOW_CONTRACTS_V2_BOSH_1941_20251027 T1
                 where T1.NAME in (
                         SELECT T2.NAME   FROM BOSHSTG.OOW_CONTRACTS_V2_BOSH_1941_20251027 T2
                                         JOIN bosh.ORDER_ITEM_TBL OIT ON 'BSH' || '-' || ORDER_KEY  || '-' || ORDER_LINE_KEY = T2.NAME
                                         LEFT join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY
                                         LEFT JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = OIT.ORDER_KEY and COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY
                                         LEFT JOIN BOSH.CONTRACT_DIM CD on CD.CONTRACT_KEY = COT.CONTRACT_KEY
                         where CD.CONTRACT_KEY is NULL
                     );

                DBMS_OUTPUT.PUT_LINE(v_audit_key);
                DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );


                COMMIT;

         END;
--
-- [2025-10-29 00:14:53] completed in 700 ms
-- 1021219
-- 14
-- [2025-10-29 00:14:57] transaction committed: @console_119 [BOSH-STg-Prod]


-- BOSHSTG>
    DECLARE
                 v_audit_key INTEGER := get_audit_key (p_program_nm => 'Manual update', p_DESCRIPTIVE_TX => 'Manually populating data for contracts with date issue BOSH-1943', p_table_nm => 'RAW_CONTRACT_SALES_TBL', p_author_nm => 'iahmad' );
         BEGIN

                 Insert into RAW_CONTRACT_SALES_TBL
                     (UNIQUE_IDENTIFIER, P2_CONTRACT_NO, STATUS_CD,
                      CONTRACT_START_DATE, CONTRACT_END_DATE,
                      ERROR_TXT, FILE_NM, BILLING_UNIQUE_SEQ_NO, SHIPPING_UNIQUE_SEQ_NO, INSERT_AUDIT_KEY)
                 select  Replace(T1.NAME,'BSH-','') AS UNIQUE_IDENTIFIER, T1.NAME AS P2_CONTRACT_NO, 'ACTIVE',
                          TO_CHAR(CORRECTED_CONTRACT_START_DATE, 'MM/DD/YYYY'), TO_CHAR(CORRECTED_CONTRACT_END_DATE, 'MM/DD/YYYY'),
                          'CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR', 'Bosch_REN_Contracts_DUPLICATE_VALUE_BOSH_1941', NULL, NULL, v_audit_key
                 from  BOSHSTG.REN_CONTRACTS_V2_BOSH_1943_20251027 T1
                 where T1.NAME in (
                         SELECT T2.NAME   FROM BOSHSTG.REN_CONTRACTS_V2_BOSH_1943_20251027 T2
                                         JOIN bosh.ORDER_ITEM_TBL OIT ON 'BSH' || '-' || ORDER_KEY  || '-' || ORDER_LINE_KEY = T2.NAME
                                         LEFT join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY
                                         LEFT JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = OIT.ORDER_KEY and COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY
                                         LEFT JOIN BOSH.CONTRACT_DIM CD on CD.CONTRACT_KEY = COT.CONTRACT_KEY
                         where CD.CONTRACT_KEY is NULL
                     );

                DBMS_OUTPUT.PUT_LINE(v_audit_key);
                DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );


                COMMIT;

         END;
-- [2025-10-29 00:16:03] completed in 864 ms
-- 1021220
-- 3
-- [2025-10-29 00:16:08] transaction committed: @console_119 [BOSH-STg-Prod]

-- +-----------------+--------------+---------+-------------------+-----------------+-------------------------------------------------+---------------------------------------------+---------------------+----------------------+----------------+
-- |UNIQUE_IDENTIFIER|P2_CONTRACT_NO|STATUS_CD|CONTRACT_START_DATE|CONTRACT_END_DATE|ERROR_TXT                                        |FILE_NM                                      |BILLING_UNIQUE_SEQ_NO|SHIPPING_UNIQUE_SEQ_NO|INSERT_AUDIT_KEY|
-- +-----------------+--------------+---------+-------------------+-----------------+-------------------------------------------------+---------------------------------------------+---------------------+----------------------+----------------+
-- |477009-1         |BSH-477009-1  |ACTIVE   |10/03/2025         |10/03/2026       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477069-1         |BSH-477069-1  |ACTIVE   |10/03/2025         |10/03/2026       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477093-1         |BSH-477093-1  |ACTIVE   |10/03/2025         |10/03/2027       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477105-1         |BSH-477105-1  |ACTIVE   |10/03/2025         |10/03/2029       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477137-1         |BSH-477137-1  |ACTIVE   |10/04/2025         |10/04/2026       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477019-1         |BSH-477019-1  |ACTIVE   |10/03/2025         |10/03/2029       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477079-1         |BSH-477079-1  |ACTIVE   |10/03/2025         |10/03/2026       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477111-1         |BSH-477111-1  |ACTIVE   |10/03/2025         |10/03/2029       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477147-1         |BSH-477147-1  |ACTIVE   |10/04/2025         |10/04/2029       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477125-1         |BSH-477125-1  |ACTIVE   |10/04/2025         |10/04/2028       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477121-1         |BSH-477121-1  |ACTIVE   |10/03/2025         |10/03/2027       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477109-1         |BSH-477109-1  |ACTIVE   |10/03/2025         |10/03/2026       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477005-1         |BSH-477005-1  |ACTIVE   |09/23/2025         |09/23/2026       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477127-1         |BSH-477127-1  |ACTIVE   |10/04/2025         |10/04/2026       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_OOW_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021219         |
-- |477107-1         |BSH-477107-1  |ACTIVE   |03/19/2026         |03/19/2027       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_REN_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021220         |
-- |477045-1         |BSH-477045-1  |ACTIVE   |09/04/2025         |09/04/2029       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_REN_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021220         |
-- |477061-1         |BSH-477061-1  |ACTIVE   |09/04/2025         |09/04/2026       |CONTRACT PROCESSED SUCCESSFULLY WITHOUT ANY ERROR|Bosch_REN_Contracts_DUPLICATE_VALUE_BOSH_1941|NULL                 |NULL                  |1021220         |
-- +-----------------+--------------+---------+-------------------+-----------------+-------------------------------------------------+---------------------------------------------+---------------------+----------------------+----------------+


