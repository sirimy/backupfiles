
SELECT T1.NAME, trunc(oit.PURCHASE_DT) as PURCHASE_DT,OT.CREATED_TS , ot.SALES_SOURCE_CD,
       trunc(OIT.COVERAGE_START_DT) as COVERAGE_START_DT, trunc(OIT.COVERAGE_EXP_DT) as COVERAGE_EXP_DT,
       T1.CORRECTED_CONTRACT_START_DATE, T1.CORRECT_CONTRACT_END_DATE,
        cd.CONTRACT_START_DT, cd.CONTRACT_END_DT,
       TRUNC(T1.CORRECTED_CONTRACT_START_DATE) - TRUNC(OIT.COVERAGE_START_DT) Days,
       TRUNC(T1.CORRECTED_CONTRACT_START_DATE) - TRUNC(OIT.PURCHASE_DT) as Days2
FROM BOSHSTG.OOW_CONTRACTS_V2_BOSH_1941_20251027 T1
                JOIN bosh.ORDER_ITEM_TBL OIT ON 'BSH' || '-' || ORDER_KEY  || '-' || ORDER_LINE_KEY = T1.NAME
                join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY
                JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = OIT.ORDER_KEY and COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY
                JOIN BOSH.CONTRACT_DIM CD on CD.CONTRACT_KEY = COT.CONTRACT_KEY
where 1=1
--   and TRUNC(T1.CORRECTED_CONTRACT_START_DATE) - TRUNC(OIT.COVERAGE_START_DT) not in (29,30,31)
  and TRUNC(T1.CORRECTED_CONTRACT_START_DATE) - TRUNC(OIT.PURCHASE_DT) not in (30, 31)  --Assurant dates are based upon plan purchase date, which is good
--   and TRUNC(T1.CORRECTED_CONTRACT_START_DATE) - cd.CONTRACT_START_DT < 30   --QC check
;



grant select on OOW_CONTRACTS_V2_BOSH_1941_20251027 to BOSH;

DECLARE
        v_audit_key_cd INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_DESCRIPTIVE_TX => 'Manually populating data for contracts with date issue BOSH-1941', p_author_nm => 'iahmad',p_table_nm => 'CONTRACT_DIM');
        v_audit_key_COX INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_DESCRIPTIVE_TX => 'Manually populating data for contracts with date issue BOSH-1941', p_author_nm => 'iahmad', p_table_nm => 'CONTRACT_COVERAGE_XREF');
        v_audit_key_sid INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_DESCRIPTIVE_TX => 'Manually populating data for contracts with date issue BOSH-1941', p_author_nm => 'iahmad', p_table_nm => 'SERIALIZED_ITEM_DIM');

BEGIN

    MERGE INTO BOSH.CONTRACT_DIM tt
    USING (
              Select distinct CD.CONTRACT_KEY,T1.CORRECTED_CONTRACT_START_DATE,T1.CORRECT_CONTRACT_END_DATE
                  FROM BOSHSTG.OOW_CONTRACTS_V2_BOSH_1941_20251027 T1
                        JOIN bosh.ORDER_ITEM_TBL OIT ON 'BSH' || '-' || ORDER_KEY  || '-' || ORDER_LINE_KEY = T1.NAME
                        join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY
                        JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = OIT.ORDER_KEY and COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY
                        JOIN BOSH.CONTRACT_DIM CD on CD.CONTRACT_KEY = COT.CONTRACT_KEY
    ) st
    ON (tt.CONTRACT_KEY = st.CONTRACT_KEY)
    WHEN MATCHED THEN
        UPDATE SET tt.CONTRACT_START_DT = st.CORRECTED_CONTRACT_START_DATE
                   ,tt.CONTRACT_END_DT = st.CORRECT_CONTRACT_END_DATE
                    ,SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key_cd;

    DBMS_OUTPUT.PUT_LINE('CONTRACT_DIM');
    DBMS_OUTPUT.PUT_LINE(v_audit_key_cd);
    DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );



    --#########################################################################################----
    MERGE INTO BOSH.CONTRACT_COVERAGE_XREF tt
    USING (
              Select distinct CD.CONTRACT_KEY,OIT.SERIALIZED_ITEM_KEY ,T1.CORRECTED_CONTRACT_START_DATE,T1.CORRECT_CONTRACT_END_DATE
                  FROM BOSHSTG.OOW_CONTRACTS_V2_BOSH_1941_20251027 T1
                        JOIN bosh.ORDER_ITEM_TBL OIT ON 'BSH' || '-' || ORDER_KEY  || '-' || ORDER_LINE_KEY = T1.NAME
                        join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY
                        JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = OIT.ORDER_KEY and COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY
                        JOIN BOSH.CONTRACT_DIM CD on CD.CONTRACT_KEY = COT.CONTRACT_KEY
    ) st
    ON (tt.CONTRACT_KEY = st.CONTRACT_KEY  AND tt.SI_KEY = st.SERIALIZED_ITEM_KEY )
    WHEN MATCHED THEN
        UPDATE SET tt.COVERAGE_START_DT = st.CORRECTED_CONTRACT_START_DATE
                   ,tt.COVERAGE_END_DT = st.CORRECT_CONTRACT_END_DATE
                    ,SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key_COX;

    DBMS_OUTPUT.PUT_LINE('CONTRACT_COVERAGE_XREF');
    DBMS_OUTPUT.PUT_LINE(v_audit_key_COX);
    DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );

    --#########################################################################################----
    MERGE INTO BOSH.SERIALIZED_ITEM_DIM tt
    USING (
              Select distinct SID.SI_KEY,T1.CORRECTED_CONTRACT_START_DATE,T1.CORRECT_CONTRACT_END_DATE
                  FROM BOSHSTG.OOW_CONTRACTS_V2_BOSH_1941_20251027 T1
                        JOIN bosh.ORDER_ITEM_TBL OIT ON 'BSH' || '-' || ORDER_KEY  || '-' || ORDER_LINE_KEY = T1.NAME
                join bosh.SERIALIZED_ITEM_DIM SID on SID.SI_KEY = oit.SERIALIZED_ITEM_KEY
    ) st
    ON (tt.SI_KEY = st.SI_KEY)
    WHEN MATCHED THEN
        UPDATE SET  tt.LATEST_COVERAGE_EXP_DT = st.CORRECT_CONTRACT_END_DATE
                    ,SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key_sid;

       DBMS_OUTPUT.PUT_LINE('SERIALIZED_ITEM_DIM');
       DBMS_OUTPUT.PUT_LINE(v_audit_key_sid);
       DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );


       COMMIT;

END;

--description to use for ticket name [Manually populating data for contracts with date issue]
-- some details to addd
-- p_process_nm => 'BOSH-1941', replace with description

DECLARE
      -- v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update',  p_table_nm => 'RAW_CONTRACT_SALES_TBL');
        v_audit_key INTEGER := get_audit_key (p_program_nm => 'Manual update', p_DESCRIPTIVE_TX => 'Manually populating data for contracts with date issue BOSH-1941', p_table_nm => 'RAW_CONTRACT_SALES_TBL', p_author_nm => 'iahmad' );
BEGIN

        Insert into bosh.RAW_CONTRACT_SALES_TBL
            (UNIQUE_IDENTIFIER, P2_CONTRACT_NO, STATUS_CD,
             CONTRACT_START_DATE, CONTRACT_END_DATE,
             ERROR_TXT, FILE_NM, BILLING_UNIQUE_SEQ_NO, SHIPPING_UNIQUE_SEQ_NO, INSERT_AUDIT_KEY)
         select  RCST.UNIQUE_IDENTIFIER, P2_CONTRACT_NO, STATUS_CD,
                 TO_CHAR(CORRECTED_CONTRACT_START_DATE, 'MM/DD/YYYY'), TO_CHAR(CORRECT_CONTRACT_END_DATE, 'MM/DD/YYYY'),
                 ERROR_TXT, 'Bosch_OOW_Contracts_V2_BOSH_1941', NULL, NULL, v_audit_key
        from bosh.RAW_CONTRACT_SALES_TBL RCST
          JOIN BOSHSTG.OOW_CONTRACTS_V2_BOSH_1941_20251027 T1 ON 'BSH' || '-' || RCST.UNIQUE_IDENTIFIER = T1.NAME;

       DBMS_OUTPUT.PUT_LINE(v_audit_key);
       DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );


       COMMIT;

END;