


DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'POLICY EXP SET', p_table_nm => 'BOSH.1867');

BEGIN
        DBMS_OUTPUT.PUT_LINE(v_audit_key);

        --#1
       Update BOSH.POLICY_TBL
        SET EXP_DT = date '2025-07-20'
            ,UPDATE_AUDIT_KEY = v_audit_key
        where POLICY_KEY in (2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,4058,4069,4080,4091,4102,4113,4124,4135,6016,6017,6018,6019);
        DBMS_OUTPUT.PUT_LINE('POLICY_TBL');
        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);


         --#2
       Update BOSH.POLICY_FEE_XREF
        SET END_DT = date '2025-07-20'
            ,UPDATE_AUDIT_KEY = v_audit_key
        where POLICY_KEY in (2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,4058,4069,4080,4091,4102,4113,4124,4135,6016,6017,6018,6019);
        DBMS_OUTPUT.PUT_LINE('POLICY_FEE_XREF');
        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);

        --#3
       Update BOSH.POLICY_DISCOUNT_TBL
        SET END_DT = date '2025-07-20'
            ,UPDATE_AUDIT_KEY = v_audit_key
        where POLICY_KEY in (2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,4058,4069,4080,4091,4102,4113,4124,4135,6016,6017,6018,6019);
        DBMS_OUTPUT.PUT_LINE('POLICY_DISCOUNT_TBL');
        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);

        --#4
       Update BOSH.T_AND_C_CONTRACT_TEMPLATE_XREF
        SET END_DT = date '2025-07-20'
            ,UPDATE_AUDIT_KEY = v_audit_key
        where POLICY_KEY in (2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,4058,4069,4080,4091,4102,4113,4124,4135,6016,6017,6018,6019);
        DBMS_OUTPUT.PUT_LINE('T_AND_C_CONTRACT_TEMPLATE_XREF');
        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);


       COMMIT;

END;

-- 983331
-- POLICY_TBL
-- 27
-- POLICY_FEE_XREF
-- 54
-- POLICY_DISCOUNT_TBL
-- 27
-- T_AND_C_CONTRACT_TEMPLATE_XREF
-- 4284

--983109
select INSERT_AUDIT_KEY,ATT.CREATION_DT,COUNT(*)
from PRODUCT_PRICE_DIM PPD
JOIN AUDIT_TBL ATT on ATT.AUDIT_KEY = PPD.INSERT_AUDIT_KEY
group by INSERT_AUDIT_KEY,ATT.CREATION_DT  order by INSERT_AUDIT_KEY desc ;
-- +----------------+--------------------------+--------+
-- |INSERT_AUDIT_KEY|CREATION_DT               |COUNT(*)|
-- +----------------+--------------------------+--------+
-- |982987          |2025-07-22 02:41:47.000000|59381   |
-- +----------------+--------------------------+--------+

select * from PRODUCT_PRICE_DIM
where INSERT_AUDIT_KEY =  982987
and POLICY_KEY in (2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,4058,4069,4080,4091,4102,4113,4124,4135,6016,6017,6018,6019);

select POLICY_KEY,COUNT(*) from PRODUCT_PRICE_DIM
where INSERT_AUDIT_KEY =  982987
and POLICY_KEY in (2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,4058,4069,4080,4091,4102,4113,4124,4135,6016,6017,6018,6019)
group by POLICY_KEY
;
-- +----------+--------+
-- |POLICY_KEY|COUNT(*)|
-- +----------+--------+
-- |4058      |5       |
-- |4124      |5       |
-- |2066      |5       |
-- |2060      |5       |
-- |2063      |5       |
-- |2056      |5       |
-- |2061      |5       |
-- |6019      |5       |
-- |2068      |5       |
-- |6017      |5       |
-- |6018      |5       |
-- |2057      |5       |
-- |2055      |5       |
-- |4069      |5       |
-- |2065      |5       |
-- |2067      |5       |
-- |2059      |5       |
-- |4113      |5       |
-- |2064      |5       |
-- |4091      |5       |
-- |2069      |5       |
-- |4135      |5       |
-- |2058      |5       |
-- |6016      |5       |
-- |4080      |5       |
-- |2062      |5       |
-- |4102      |5       |
-- +----------+--------+


delete from PRODUCT_PRICE_DIM
where INSERT_AUDIT_KEY =  982987
and POLICY_KEY in (2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,4058,4069,4080,4091,4102,4113,4124,4135,6016,6017,6018,6019);

COMMIT;