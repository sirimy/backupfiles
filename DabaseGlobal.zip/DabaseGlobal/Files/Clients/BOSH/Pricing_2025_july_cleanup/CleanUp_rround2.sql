--
-- DECLARE
--        v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'POLICY EXP SET', p_table_nm => 'BOSH.1867');
--
-- BEGIN
--         DBMS_OUTPUT.PUT_LINE(v_audit_key);
--
--         --#1
--        Update BOSH.POLICY_TBL
--         SET EXP_DT = date '2025-07-20'
--             ,UPDATE_AUDIT_KEY = v_audit_key
--         where POLICY_KEY in (2070,2071,2072,2873,2874,2073,2074,2075);
--         DBMS_OUTPUT.PUT_LINE('POLICY_TBL');
--         DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
--
--
--          --#2
--        Update BOSH.POLICY_FEE_XREF
--         SET END_DT = date '2025-07-20'
--             ,UPDATE_AUDIT_KEY = v_audit_key
--         where POLICY_KEY in (2070,2071,2072,2873,2874,2073,2074,2075);
--         DBMS_OUTPUT.PUT_LINE('POLICY_FEE_XREF');
--         DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
--
--         --#3
--        Update BOSH.POLICY_DISCOUNT_TBL
--         SET END_DT = date '2025-07-20'
--             ,UPDATE_AUDIT_KEY = v_audit_key
--         where POLICY_KEY in (2070,2071,2072,2873,2874,2073,2074,2075);
--         DBMS_OUTPUT.PUT_LINE('POLICY_DISCOUNT_TBL');
--         DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
--
--         --#4
--        Update BOSH.T_AND_C_CONTRACT_TEMPLATE_XREF
--         SET END_DT = date '2025-07-20'
--             ,UPDATE_AUDIT_KEY = v_audit_key
--         where POLICY_KEY in (2070,2071,2072,2873,2874,2073,2074,2075);
--         DBMS_OUTPUT.PUT_LINE('T_AND_C_CONTRACT_TEMPLATE_XREF');
--         DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
--
--
--        COMMIT;
--
-- END;


select COUNT(*) from PRODUCT_PRICE_DIM
where INSERT_AUDIT_KEY =  982987
and POLICY_KEY in (2070,2071,2072,2873,2874,2073,2074,2075);--130

select POLICY_KEY,COUNT(*) from PRODUCT_PRICE_DIM
where INSERT_AUDIT_KEY =  982987
and POLICY_KEY in (2070,2071,2072,2873,2874,2073,2074,2075)
group by POLICY_KEY
;

-- 2072,10
-- 2874,10
-- 2073,40
-- 2075,10
-- 2074,30
-- 2071,10
-- 2070,10
-- 2873,10

delete from PRODUCT_PRICE_DIM
where INSERT_AUDIT_KEY =  982987
and POLICY_KEY in (2070,2071,2072,2873,2874,2073,2074,2075);
--[2025-07-23 17:00:44] 130 rows affected in 602 ms
COMMIT;