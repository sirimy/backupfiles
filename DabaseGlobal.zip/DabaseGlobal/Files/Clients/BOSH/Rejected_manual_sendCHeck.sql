
select * from BOSH.raw_contract_sales_tbl
         where UNIQUE_IDENTIFIER in (
                         select UNIQUE_IDENTIFIER from REJECTED_SALES_REPORT_20230704
                         )
         order by INSERT_AUDIT_KEY desc;

select * from BOSH.RAW_CONTRACT_SALES_ERROR_TBL
         where UNIQUE_IDENTIFIER in (
                         select UNIQUE_IDENTIFIER from REJECTED_SALES_REPORT_20230704
                         )
         order by INSERT_AUDIT_KEY desc;

select *  FROM BOSH.ORDER_EXTRACT_TBL where UNIQUE_IDENTIFIER in (
                         select UNIQUE_IDENTIFIER from REJECTED_SALES_REPORT_20230704
                         )
         order by INSERT_AUDIT_KEY desc;


select COUNT(*) from bosh.ORDER_ITEM_TBL
 where (ORDER_KEY, ORDER_LINE_KEY) in (
             select rej.ORDER_KEY, rej.ORDER_LINE_KEY from boshStg.v_rejected_sales rej
              where  (REJECTION_REASON like '%NO BUYER ACCOUNT INFORMATION RETRIEVED%'                     )
                and  ORDER_KEY || '-' || ORDER_LINE_KEY   in (
                         select UNIQUE_IDENTIFIER from REJECTED_SALES_REPORT_20230704
                         )
                );