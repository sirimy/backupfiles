 SELECT                 'Reference_id'  || '|' ||
                        'First_nm'  || '|' ||
                        'Middle_nm'  || '|' ||
                        'Last_nm'  || '|' ||
                        'Address_line1_tx'  || '|' ||
                        'Address_line2_tx'  || '|' ||
                        'City_nm'  || '|' ||
                        'State_cd'  || '|' ||
                        'Zip_code5_tx'  || '|' ||
                        'Zip_code4_tx'  || '|' ||
                       -- 'Phone_number'  || '|' ||
                        'Email_address'  || '|' ||
                        'Carrier_route_cd'  || '|' ||
                        'Line_of_travel'  || '|' ||
                        'Dpbc'  || '|' ||
                        'Dpbc_check_digit'  || '|' ||
                        'Guarantee_id'  || '|' ||
                        'Mail_drop_date'  || '|' ||
                        'Est_mail_in_home_date'  || '|' ||
                       -- 'Obtm_start_date'  || '|' ||
                        'Email_start_date'  || '|' ||
                      --  'Wave'  || '|' ||
                        'Offer_expire_date'  || '|' ||
                        'Contract_exp_date'  || '|' ||
                        'Copy_cd'  || '|' ||
                        'Form_cd'  || '|' ||
                        'Brochure1_cd'  || '|' ||
                        'Brochure2_cd'  || '|' ||
                        'Oe_cd'  || '|' ||
                        'Re_cd'  || '|' ||
                        --'Scan_line'  || '|' ||
                        'Purl'  || '|' ||
                        'Sec_code'  || '|' ||
                        'P1_Product_Desc'  || '|' ||
                        'P1_brand_dsc'  || '|' ||
                        'P1_model_no'  || '|' ||
                        'P1_serial_no'  || '|' ||
                        'P1_warranty_expiration_dt'  || '|' ||
                        'P1_coverage_start_dt'  || '|' ||
                        'Coverage_1yr_end_dt'  || '|' ||
                        'Retail_price_1yr_amt'  || '|' ||
                        'Tax_1yr_amt'  || '|' ||
                        'Net_price_1yr_amt'  || '|' ||
                        'Payment_plan_1yr_amt'  || '|' ||
                        'Coverage_2yr_end_dt'  || '|' ||
                        'Retail_price_2yr_amt'  || '|' ||
                        'Discount_2yr_pct'  || '|' ||
                        'Discount_2yr_amt'  || '|' ||
                        'Tax_2yr_amt'  || '|' ||
                        'Net_price_2yr_amt'  || '|' ||
                        'Payment_plan_2yr_amt'  || '|' ||
                        'Coverage_3yr_end_dt'  || '|' ||
                        'Retail_price_3yr_amt'  || '|' ||
                        'Discount_3yr_pct'  || '|' ||
                        'Discount_3yr_amt'  || '|' ||
                        'Tax_3yr_amt'  || '|' ||
                        'Net_price_3yr_amt'  || '|' ||
                        'Payment_plan_3yr_amt'  || '|' ||
                        'Total_price1'  || '|' ||
                        'Total_disc1'  || '|' ||
                        'Total_tax1'  || '|' ||
                        'Total_amnt1'  || '|' ||
                        'Total_multi1'  || '|' ||
                        'Coverage_4yr_end_dt'  || '|' ||
                        'Retail_price_4yr_amt'  || '|' ||
                        'Discount_4yr_pct'  || '|' ||
                        'Discount_4yr_amt'  || '|' ||
                        'Tax_4yr_amt'  || '|' ||
                        'Net_price_4yr_amt'  || '|' ||
                        'Payment_plan_4yr_amt'  || '|' ||
                        'P1_market_nm'  || '|' ||
                        --'P2_product_desc'  || '|' || --P1_Product_Desc_3
                        'P1_prod_unit_descriptor'  || '|' ||
                        --'Mailer_id'  || '|' ||
                        --'Imb_serial'  || '|' ||
                        'Firm_nm'  || '|' ||
                       -- 'Product_line'  || '|' ||
                        'Override_1yr_term_label'  || '|' ||
                        'Override_2yr_term_label'  || '|' ||
                        'Override_3yr_term_label'  || '|' ||
                        'Override_4yr_term_label'  || '|' ||
                        'Variable_text_1'  || '|' ||
                        'Variable_text_2'  || '|' ||
                        'Variable_text_3'  || '|' ||
                        'Variable_text_4'  || '|' ||
                        'Qr_cd'  || '|' ||
                        --'Variable_plan'  || '|' ||
                        'Warranty Term in months'  || '|' ||
                        'Product Purchase Date'  || '|' ||
                        --'Product Registration Date'  || '|' ||
                        --'CAMPAIGN_TYP'  || '|' ||
                        --'Primary_Use_Code'  || '|' ||
                        --'Dummy'  || '|' ||
                        'P2_Product_Desc'  || '|' ||
                        'P2_brand_dsc'  || '|' ||
                        'P2_model_no'  || '|' ||
                        --'P2_serial_no'  || '|' ||
                        'P2_warranty_expiration_dt'  || '|' ||
                        'P2_coverage_start_dt'  || '|' ||
                        'P2_Coverage_1yr_end_dt'  || '|' ||
                        'P2_Retail_price_1yr_amt'  || '|' ||
                        'P2_Tax_1yr_amt'  || '|' ||
                        'P2_Net_price_1yr_amt'  || '|' ||
                        'P2_payment_plan_1yr_amt'  || '|' ||
                        'P2_Coverage_2yr_end_dt'  || '|' ||
                        'P2_retail_price_2yr_amt'  || '|' ||
                        'P2_discount_2yr_pct'  || '|' ||
                        'P2_discount_2yr_amt'  || '|' ||
                        'P2_tax_2yr_amt'  || '|' ||
                        'P2_net_price_2yr_amt'  || '|' ||
                        'P2_payment_plan_2yr_amt'  || '|' ||
                        'P2_Coverage_3yr_end_dt'  || '|' ||
                        'P2_retail_price_3yr_amt'  || '|' ||
                        'P2_discount_3yr_pct'  || '|' ||
                        'P2_discount_3yr_amt'  || '|' ||
                        'P2_tax_3yr_amt'  || '|' ||
                        'P2_net_price_3yr_amt'  || '|' ||
                        'P2_payment_plan_3yr_amt'  || '|' ||
                        'P3_Product_Desc'  || '|' ||
                        'P3_brand_dsc'  || '|' ||
                        'P3_model_no'  || '|' ||
                        --'P3_serial_no'  || '|' ||
                        'P3_warranty_expiration_dt'  || '|' ||
                        'P3_coverage_start_dt'  || '|' ||
                        'P3_Coverage_1yr_end_dt'  || '|' ||
                        'P3_Retail_price_1yr_amt'  || '|' ||
                        'P3_Tax_1yr_amt'  || '|' ||
                        'P3_Net_price_1yr_amt'  || '|' ||
                        'P3_payment_plan_1yr_amt'  || '|' ||
                        'P3_Coverage_2yr_end_dt'  || '|' ||
                        'P3_retail_price_2yr_amt'  || '|' ||
                        'P3_discount_2yr_pct'  || '|' ||
                        'P3_discount_2yr_amt'  || '|' ||
                        'P3_tax_2yr_amt'  || '|' ||
                        'P3_net_price_2yr_amt'  || '|' ||
                        'P3_payment_plan_2yr_amt'  || '|' ||
                        'P3_Coverage_3yr_end_dt'  || '|' ||
                        'P3_retail_price_3yr_amt'  || '|' ||
                        'P3_discount_3yr_pct'  || '|' ||
                        'P3_discount_3yr_amt'  || '|' ||
                        'P3_tax_3yr_amt'  || '|' ||
                        'P3_net_price_3yr_amt'  || '|' ||
                        'P3_payment_plan_3yr_amt'  || '|' ||
                        'P4_Product_Desc'  || '|' ||
                        'P4_brand_dsc'  || '|' ||
                        'P4_model_no'  || '|' ||
                       -- 'P4_serial_no'  || '|' ||
                        'P4_warranty_expiration_dt'  || '|' ||
                        'P4_coverage_start_dt'  || '|' ||
                        'P4_Coverage_1yr_end_dt'  || '|' ||
                        'P4_Retail_price_1yr_amt'  || '|' ||
                        'P4_Tax_1yr_amt'  || '|' ||
                        'P4_Net_price_1yr_amt'  || '|' ||
                        'P4_payment_plan_1yr_amt'  || '|' ||
                        'P4_Coverage_2yr_end_dt'  || '|' ||
                        'P4_retail_price_2yr_amt'  || '|' ||
                        'P4_discount_2yr_pct'  || '|' ||
                        'P4_discount_2yr_amt'  || '|' ||
                        'P4_tax_2yr_amt'  || '|' ||
                        'P4_net_price_2yr_amt'  || '|' ||
                        'P4_payment_plan_2yr_amt'  || '|' ||
                        'P4_Coverage_3yr_end_dt'  || '|' ||
                        'P4_retail_price_3yr_amt'  || '|' ||
                        'P4_discount_3yr_pct'  || '|' ||
                        'P4_discount_3yr_amt'  || '|' ||
                        'P4_tax_3yr_amt'  || '|' ||
                        'P4_net_price_3yr_amt'  || '|' ||
                        'P4_payment_plan_3yr_amt'  AS Header1,
                        '|' AS H,
                        'P5_Product_Desc'  || '|' ||
                        'P5_brand_dsc'  || '|' ||
                        'P5_model_no'  || '|' ||
                        --'P5_serial_no'  || '|' ||
                        'P5_warranty_expiration_dt'  || '|' ||
                        'P5_coverage_start_dt'  || '|' ||
                        'P5_Coverage_1yr_end_dt'  || '|' ||
                        'P5_Retail_price_1yr_amt'  || '|' ||
                        'P5_Tax_1yr_amt'  || '|' ||
                        'P5_Net_price_1yr_amt'  || '|' ||
                        'P5_payment_plan_1yr_amt'  || '|' ||
                        'P5_Coverage_2yr_end_dt'  || '|' ||
                        'P5_retail_price_2yr_amt'  || '|' ||
                        'P5_discount_2yr_pct'  || '|' ||
                        'P5_discount_2yr_amt'  || '|' ||
                        'P5_tax_2yr_amt'  || '|' ||
                        'P5_net_price_2yr_amt'  || '|' ||
                        'P5_payment_plan_2yr_amt'  || '|' ||
                        'P5_Coverage_3yr_end_dt'  || '|' ||
                        'P5_retail_price_3yr_amt'  || '|' ||
                        'P5_discount_3yr_pct'  || '|' ||
                        'P5_discount_3yr_amt'  || '|' ||
                        'P5_tax_3yr_amt'  || '|' ||
                        'P5_net_price_3yr_amt'  || '|' ||
                        'P5_payment_plan_3yr_amt'  || '|' ||
                        --'DISC1R'  || '|' ||
                        --'TERM_DISCOUNT_PERCENTAGE2'  || '|' ||
                        --'TERM_DISCOUNT_PERCENTAGE3'  || '|' ||
                        'BUNDLE_DISCOUNT_PERCENTAGE'  || '|' ||
                        'WF_Single_Part_Number'  || '|' ||
                        'WF_Single_Filter_Price'  || '|' ||
                        'WF_Single_Tax'  || '|' ||
                        'WF_Single_Filter_Shipping'  || '|' ||
                        'WF_Single_Filter_Total_Price'  || '|' ||
                        'Insert_Code'  || '|' ||
                        'WF_Double_Part_Number'  || '|' ||
                        'Wf_Double_Filter_Price'  || '|' ||
                        'WF_Double_Tax'  || '|' ||
                        'Wf_Double_Filter_Shipping'  || '|' ||
                        'WF_Double_Filter_Total_Price'  || '|' ||
                        'WF_Triple_Part_Number'  || '|' ||
                        'WF_Triple_Filter_Price'  || '|' ||
                        'WF_Triple_Tax'  || '|' ||
                        'WF_Triple_Filter_Shipping'  || '|' ||
                        'WF_Triple_Filter_Total_Price'  || '|' ||
                        'WF_Single_Pack_Savings'  || '|' ||
                        'WF_Double_Pack_Savings'  || '|' ||
                        'WF_Triple_Pack_Savings'  || '|' ||
                        'WF_Percentage_savings'  || '|' ||
                        --'Web_Offer_Expires_date'  || '|' ||
                        'Variable_Text_5'  || '|' ||
                        'Variable_Text_6'  || '|' ||
                        'Variable_Text_7'  || '|' ||
                        'Variable_Text_8'  || '|' ||
                        'Variable_Text_9'  || '|' ||
                        'CAMPAIGN_DISCOUNT_PERCENTAGE'  || '|' ||
                        'YEAR2_TOTAL_PRICE2'  || '|' ||
                        'YEAR2_TOTAL_DISC2'  || '|' ||
                        'YEAR2_TOTAL_TAX2'  || '|' ||
                        'YEAR2_TOTAL_AMNT2'  || '|' ||
                        'YEAR2_TOTAL_MULTI2'  || '|' ||
                        'YEAR3_TOTAL_PRICE3'  || '|' ||
                        'YEAR3_TOTAL_DISC3'  || '|' ||
                        'YEAR3_TOTAL_TAX3'  || '|' ||
                        'YEAR3_TOTAL_AMNT3'  || '|' ||
                        'YEAR3_TOTAL_MULTI3'  || '|' ||
                        'YEAR4_TOTAL_PRICE4'  || '|' ||
                        'YEAR4_TOTAL_DISC4'  || '|' ||
                        'YEAR4_TOTAL_TAX4'  || '|' ||
                        'YEAR4_TOTAL_AMNT4'  || '|' ||
                        'YEAR4_TOTAL_MULTI4'  || '|' ||
                        'BRAND_FONT'  || '|' ||
                        'BRAND_LOGO'  || '|' ||
                        'BRAND_FULL_DESC'  || '|' ||
                        'P2_COVERAGE_4YR_END_DT'  || '|' ||
                        'P2_RETAIL_PRICE_4YR_AMT'  || '|' ||
                        'P2_discount_4yr_pct'  || '|' ||
                        'P2_DISCOUNT_4YR_AMT'  || '|' ||
                        'P2_TAX_4YR_AMT'  || '|' ||
                        'P2_NET_PRICE_4YR_AMT'  || '|' ||
                        'P2_PAYMENT_PLAN_4YR_AMT'  || '|' ||
                        'P3_COVERAGE_4YR_END_DT'  || '|' ||
                        'P3_RETAIL_PRICE_4YR_AMT'  || '|' ||
                        'P3_DISCOUNT_4YR_PCT'  || '|' ||
                        'P3_DISCOUNT_4YR_AMT'  || '|' ||
                        'P3_TAX_4YR_AMT'  || '|' ||
                        'P3_NET_PRICE_4YR_AMT'  || '|' ||
                        'P3_PAYMENT_PLAN_4YR_AMT'  || '|' ||
                        'P4_COVERAGE_4YR_END_DT'  || '|' ||
                        'P4_RETAIL_PRICE_4YR_AMT'  || '|' ||
                        'P4_DISCOUNT_4YR_PCT'  || '|' ||
                        'P4_DISCOUNT_4YR_AMT'  || '|' ||
                        'P4_TAX_4YR_AMT'  || '|' ||
                        'P4_NET_PRICE_4YR_AMT'  || '|' ||
                        'P4_PAYMENT_PLAN_4YR_AMT'  || '|' ||
                        'P5_COVERAGE_4YR_END_DT'  || '|' ||
                        'P5_RETAIL_PRICE_4YR_AMT'  || '|' ||
                        'P5_DISCOUNT_4YR_PCT'  || '|' ||
                        'P5_DISCOUNT_4YR_AMT'  || '|' ||
                        'P5_TAX_4YR_AMT'  || '|' ||
                        'P5_NET_PRICE_4YR_AMT'  || '|' ||
                        'P5_PAYMENT_PLAN_4YR_AMT'  || '|' ||
                        'QUICKREG_CODE' AS Header3
                 FROM DUAL
                Union ALl
                SELECT reference_id || '|' ||
                         first_nm || '|' ||
                         middle_nm || '|' ||
                         last_nm || '|' ||
                         address_line1_tx || '|' ||
                         address_line2_tx || '|' ||
                         city_nm || '|' ||
                         state_cd || '|' ||
                         zip_code5_tx || '|' ||
                         zip_code4_tx || '|' ||
                         --phone_number || '|' ||
                         email_address || '|' ||
                         carrier_route_cd || '|' ||
                         line_of_travel || '|' ||
                         dpbc || '|' ||
                         dpbc_check_digit || '|' ||
                         guarantee_id || '|' ||
                         TO_CHAR (mail_drop_date, 'YYYYMMDD') || '|' ||
                         TO_CHAR (est_mail_in_home_dt, 'YYYYMMDD') || '|' ||
                         --TO_CHAR (obtm_start_dt, 'YYYYMMDD') || '|' ||
                         TO_CHAR (email_start_dt, 'YYYYMMDD') || '|' ||
                        -- wave || '|' ||
                         TO_CHAR (offer_expire_dt, 'YYYYMMDD')  || '|' ||
                         TO_CHAR (contract_exp_dt, 'YYYYMMDD') || '|' ||
                         copy_cd || '|' ||
                         form_cd || '|' ||
                         brochure1_cd || '|' ||
                         brochure2_cd || '|' ||
                         oe_cd || '|' ||
                         re_cd || '|' ||
                         --scan_line || '|' ||
                         purl || '|' ||
                         sec_code || '|' ||
                         P1_Product_Desc || '|' ||
                         p1_brand_dsc || '|' ||
                         p1_model_no || '|' ||
                         p1_serial_no || '|' ||
                         TO_CHAR (p1_warranty_expiration_dt, 'YYYYMMDD') || '|' ||
                         TO_CHAR (p1_coverage_start_dt, 'YYYYMMDD') || '|' ||
                         TO_CHAR (coverage_1yr_end_dt, 'YYYYMMDD') || '|' ||
                         retail_price_1yr_amt || '|' ||
                         tax_1yr_amt || '|' ||
                         net_price_1yr_amt || '|' ||
                         payment_plan_1yr_amt || '|' ||
                         TO_CHAR (coverage_2yr_end_dt, 'YYYYMMDD') || '|' ||
                         retail_price_2yr_amt || '|' ||
                         discount_2yr_pct || '|' ||
                         discount_2yr_amt || '|' ||
                         tax_2yr_amt || '|' ||
                         net_price_2yr_amt || '|' ||
                         payment_plan_2yr_amt || '|' ||
                         TO_CHAR (coverage_3yr_end_dt, 'YYYYMMDD') || '|' ||
                         retail_price_3yr_amt || '|' ||
                         discount_3yr_pct || '|' ||
                         discount_3yr_amt || '|' ||
                         tax_3yr_amt || '|' ||
                         net_price_3yr_amt   || '|' ||
                         payment_plan_3yr_amt   || '|' ||
                         total_price1   || '|' ||
                         total_disc1   || '|' ||
                         total_tax1   || '|' ||
                         total_amnt1   || '|' ||
                         total_multi1   || '|' ||
                         TO_CHAR (coverage_4yr_end_dt, 'YYYYMMDD') || '|' ||
                         retail_price_4yr_amt   || '|' ||
                         discount_4yr_pct  || '|' ||
                         discount_4yr_amt   || '|' ||
                         tax_4yr_amt   || '|' ||
                         net_price_4yr_amt   || '|' ||
                         payment_plan_4yr_amt   || '|' ||
                         p1_market_nm || '|' ||
                         --''  || '|' || --P1_Product_Desc_3
                         p1_prod_unit_descriptor || '|' ||
                        -- mailer_id || '|' ||
                         --''  || '|' ||
                         firm_nm || '|' ||
                         --''  || '|' ||
                         term_1yr_label  || '|' ||
                         term_2yr_label  || '|' ||
                         term_3yr_label  || '|' ||
                         term_4yr_label  || '|' ||
                         var_text1  || '|' ||
                         var_text2  || '|' ||
                         var_text3  || '|' ||
                         var_text4  || '|' ||
                         qr_cd || '|' ||
                         --var_plan_nm  || '|' ||
                         warranty_term_months || '|' ||
                         TO_CHAR (prod_purchase_dt, 'YYYYMMDD') || '|' ||
                         --TO_CHAR (product_registration_dt, 'YYYYMMDD')      || '|' ||
                         --CAMPAIGN_TYP
                         --|| '|' ||Primary_Use_Cd
                         --Purchased_Oil_Ind
                         P2_Product_Desc
                         || '|' ||P2_brand_dsc
                         || '|' ||P2_model_no
                         --|| '|' ||P2_serial_no
                         || '|' ||TO_CHAR (P2_warranty_expiration_dt, 'YYYYMMDD')
                         || '|' ||TO_CHAR (P2_coverage_start_dt, 'YYYYMMDD')
                         || '|' ||TO_CHAR (P2_Coverage_1yr_end_dt, 'YYYYMMDD')
                         || '|' ||P2_Retail_price_1yr_amt
                         || '|' ||P2_Tax_1yr_amt
                         || '|' ||P2_Net_price_1yr_amt
                         || '|' ||P2_payment_plan_1yr_amt
                         || '|' ||TO_CHAR (P2_Coverage_2yr_end_dt, 'YYYYMMDD')
                         || '|' ||P2_retail_price_2yr_amt
                         || '|' ||P2_discount_2yr_pct
                         || '|' ||P2_discount_2yr_amt
                         || '|' ||P2_tax_2yr_amt
                         || '|' ||P2_net_price_2yr_amt
                         || '|' ||P2_payment_plan_2yr_amt
                         || '|' ||TO_CHAR (P2_Coverage_3yr_end_dt, 'YYYYMMDD')
                         || '|' ||P2_retail_price_3yr_amt
                         || '|' ||P2_discount_3yr_pct
                         || '|' ||P2_discount_3yr_amt
                         || '|' ||P2_tax_3yr_amt
                         || '|' ||P2_net_price_3yr_amt
                         || '|' ||P2_payment_plan_3yr_amt
                         || '|' ||P3_Product_Desc
                         || '|' ||P3_brand_dsc
                         || '|' ||P3_model_no
                         --|| '|' ||P3_serial_no
                         || '|' ||TO_CHAR (P3_warranty_expiration_dt, 'YYYYMMDD')
                         || '|' ||TO_CHAR (P3_coverage_start_dt, 'YYYYMMDD')
                         || '|' ||TO_CHAR (P3_Coverage_1yr_end_dt, 'YYYYMMDD')
                         || '|' ||P3_Retail_price_1yr_amt
                         || '|' ||P3_Tax_1yr_amt
                         || '|' ||P3_Net_price_1yr_amt
                         || '|' ||P3_payment_plan_1yr_amt
                         || '|' ||TO_CHAR (P3_Coverage_2yr_end_dt, 'YYYYMMDD')
                         || '|' ||P3_retail_price_2yr_amt
                         || '|' ||P3_discount_2yr_pct
                         || '|' ||P3_discount_2yr_amt
                         || '|' ||P3_tax_2yr_amt
                         || '|' ||P3_net_price_2yr_amt
                         || '|' ||P3_payment_plan_2yr_amt
                         || '|' ||TO_CHAR (P3_Coverage_3yr_end_dt, 'YYYYMMDD')
                         || '|' ||P3_retail_price_3yr_amt
                         || '|' ||P3_discount_3yr_pct
                         || '|' ||P3_discount_3yr_amt
                         || '|' ||P3_tax_3yr_amt
                         || '|' ||P3_net_price_3yr_amt
                         || '|' ||P3_payment_plan_3yr_amt
                         || '|' ||P4_Product_Desc
                         || '|' ||P4_brand_dsc
                         || '|' ||P4_model_no
                         --|| '|' ||P4_serial_no
                         || '|' ||TO_CHAR (P4_warranty_expiration_dt, 'YYYYMMDD')
                         || '|' ||TO_CHAR (P4_coverage_start_dt, 'YYYYMMDD')
                         || '|' ||TO_CHAR (P4_Coverage_1yr_end_dt, 'YYYYMMDD')
                         || '|' ||P4_Retail_price_1yr_amt
                         || '|' ||P4_Tax_1yr_amt
                         || '|' ||P4_Net_price_1yr_amt
                         || '|' ||P4_payment_plan_1yr_amt
                         || '|' ||TO_CHAR (P4_Coverage_2yr_end_dt, 'YYYYMMDD')
                         || '|' ||P4_retail_price_2yr_amt
                         || '|' ||P4_discount_2yr_pct
                         || '|' ||P4_discount_2yr_amt
                         || '|' ||P4_tax_2yr_amt
                         || '|' ||P4_net_price_2yr_amt
                         || '|' ||P4_payment_plan_2yr_amt
                         || '|' ||TO_CHAR (P4_Coverage_3yr_end_dt, 'YYYYMMDD')
                         || '|' ||P4_retail_price_3yr_amt
                         || '|' ||P4_discount_3yr_pct
                         || '|' ||P4_discount_3yr_amt
                         || '|' ||P4_tax_3yr_amt
                         || '|' ||P4_net_price_3yr_amt
                         || '|' ||P4_payment_plan_3yr_amt  AS Header1,
                         '|' AS H,
                         P5_Product_Desc
                         || '|' ||P5_brand_dsc
                         || '|' ||P5_model_no
                         --|| '|' ||P5_serial_no
                         || '|' ||TO_CHAR (P5_warranty_expiration_dt, 'YYYYMMDD')
                         || '|' ||TO_CHAR (P5_coverage_start_dt, 'YYYYMMDD')
                         || '|' ||TO_CHAR (P5_Coverage_1yr_end_dt, 'YYYYMMDD')
                         || '|' ||P5_Retail_price_1yr_amt
                         || '|' ||P5_Tax_1yr_amt
                         || '|' ||P5_Net_price_1yr_amt
                         || '|' ||P5_payment_plan_1yr_amt
                         || '|' ||TO_CHAR (P5_Coverage_2yr_end_dt, 'YYYYMMDD')
                         || '|' ||P5_retail_price_2yr_amt
                         || '|' ||P5_discount_2yr_pct
                         || '|' ||P5_discount_2yr_amt
                         || '|' ||P5_tax_2yr_amt
                         || '|' ||P5_net_price_2yr_amt
                         || '|' ||P5_payment_plan_2yr_amt
                         || '|' ||TO_CHAR (P5_Coverage_3yr_end_dt, 'YYYYMMDD')
                         || '|' ||P5_retail_price_3yr_amt
                         || '|' ||P5_discount_3yr_pct
                         || '|' ||P5_discount_3yr_amt
                         || '|' ||P5_tax_3yr_amt
                         || '|' ||P5_net_price_3yr_amt
                         || '|' ||P5_payment_plan_3yr_amt
                         --|| '|' ||DISC1R
                         --|| '|' ||TERM_DISCOUNT_PERCENTAGE2
                         --|| '|' ||TERM_DISCOUNT_PERCENTAGE3
                         || '|' ||BUNDLE_DISCOUNT_PERCENTAGE
                         || '|' ||WF_Single_Part_Number
                         || '|' ||WF_Single_Filter_Price
                         || '|' ||WF_Single_Tax
                         || '|' ||WF_Single_Filter_Shipping
                         || '|' ||WF_Single_Filter_Total_Price
                         || '|' ||Insert_Cd
                         || '|' ||WF_Double_Part_Number
                         || '|' ||Wf_Double_Filter_Price
                         || '|' ||WF_Double_Tax
                         || '|' ||Wf_Double_Filter_Shipping
                         || '|' ||WF_Double_Filter_Total_Price
                         || '|' ||WF_Triple_Part_Number
                         || '|' ||WF_Triple_Filter_Price
                         || '|' ||WF_Triple_Tax
                         || '|' ||WF_Triple_Filter_Shipping
                         || '|' ||WF_Triple_Filter_Total_Price
                         || '|' ||WF_Single_Pack_Savings
                         || '|' ||WF_Double_Pack_Savings
                         || '|' ||WF_Triple_Pack_Savings
                         || '|' ||WF_Percentage_savings
                         --|| '|' ||TO_CHAR (Web_Offer_Expires_date, 'YYYYMMDD')
                         || '|' ||Text_1
                         || '|' ||Text_2
                         || '|' ||Text_3
                         || '|' ||Text_4
                         || '|' ||Text_5
                         || '|' ||CAMPAIGN_DISCOUNT_PERCENTAGE
                         || '|' ||YEAR2_TOTAL_PRICE2
                         || '|' ||YEAR2_TOTAL_DISC2
                         || '|' ||YEAR2_TOTAL_TAX2
                         || '|' ||YEAR2_TOTAL_AMNT2
                         || '|' ||YEAR2_TOTAL_MULTI2
                         || '|' ||YEAR3_TOTAL_PRICE3
                         || '|' ||YEAR3_TOTAL_DISC3
                         || '|' ||YEAR3_TOTAL_TAX3
                         || '|' ||YEAR3_TOTAL_AMNT3
                         || '|' ||YEAR3_TOTAL_MULTI3
                         || '|' ||YEAR4_TOTAL_PRICE4
                         || '|' ||YEAR4_TOTAL_DISC4
                         || '|' ||YEAR4_TOTAL_TAX4
                         || '|' ||YEAR4_TOTAL_AMNT4
                         || '|' ||YEAR4_TOTAL_MULTI4
                         || '|' ||BRAND_FONT
                         || '|' ||BRAND_LOGO
                         || '|' ||BRAND_FULL_DESC
                         || '|' ||TO_CHAR (P2_COVERAGE_4YR_END_DT, 'YYYYMMDD')
                         || '|' ||P2_RETAIL_PRICE_4YR_AMT
                         || '|' ||P2_discount_4yr_pct
                         || '|' ||P2_DISCOUNT_4YR_AMT
                         || '|' ||P2_TAX_4YR_AMT
                         || '|' ||P2_NET_PRICE_4YR_AMT
                         || '|' ||P2_PAYMENT_PLAN_4YR_AMT
                         || '|' ||TO_CHAR (P3_COVERAGE_4YR_END_DT, 'YYYYMMDD')
                         || '|' ||P3_RETAIL_PRICE_4YR_AMT
                         || '|' ||P3_DISCOUNT_4YR_PCT
                         || '|' ||P3_DISCOUNT_4YR_AMT
                         || '|' ||P3_TAX_4YR_AMT
                         || '|' ||P3_NET_PRICE_4YR_AMT
                         || '|' ||P3_PAYMENT_PLAN_4YR_AMT
                         || '|' ||TO_CHAR (P4_COVERAGE_4YR_END_DT, 'YYYYMMDD')
                         || '|' ||P4_RETAIL_PRICE_4YR_AMT
                         || '|' ||P4_DISCOUNT_4YR_PCT
                         || '|' ||P4_DISCOUNT_4YR_AMT
                         || '|' ||P4_TAX_4YR_AMT
                         || '|' ||P4_NET_PRICE_4YR_AMT
                         || '|' ||P4_PAYMENT_PLAN_4YR_AMT
                         || '|' ||TO_CHAR (P5_COVERAGE_4YR_END_DT, 'YYYYMMDD')
                         || '|' ||P5_RETAIL_PRICE_4YR_AMT
                         || '|' ||P5_DISCOUNT_4YR_PCT
                         || '|' ||P5_DISCOUNT_4YR_AMT
                         || '|' ||P5_TAX_4YR_AMT
                         || '|' ||P5_NET_PRICE_4YR_AMT
                         || '|' ||P5_PAYMENT_PLAN_4YR_AMT
                         || '|' ||QUICKREG_CODE AS Header3
                     FROM (SELECT m.*
                            FROM BOSH.campaign_spool_file_tbl m WHERE CHANNEL_NM = 'MAIL' and ROWNUM < 5
                          UNION ALL
                          SELECT s.*
                            FROM BOSH.campaign_spool_seed_tbl s WHERE CHANNEL_NM = 'MAIL' and ROWNUM < 5
                          )
