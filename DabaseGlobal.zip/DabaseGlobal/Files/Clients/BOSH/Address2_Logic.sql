
select *  from bosh.raw_inwarranty_leads_tbl r join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
    where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and CREATION_DT >= date '2022-01-01';

select *
  from (
    SELECT ADDRESS, FIRST_NAME,
           COUNT(distinct coalesce(FIRST_NAME, 'xyz') || ADDRESS || MODEL_NUMBER || PURCHASE_DATE) as leads,
           COUNT(distinct case when ADDRESS not like '%#%' then coalesce(FIRST_NAME, 'xyz') || ADDRESS || MODEL_NUMBER || PURCHASE_DATE end) as leads_without_apt,
           min(CREATION_DT), max(CREATION_DT)
     from bosh.raw_inwarranty_leads_tbl r join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
    where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and CREATION_DT >= date '2022-01-01'
--     GROUP BY FIRST_NAME, ADDRESS
--     Order by ADDRESS, FIRST_NAME
    );

select  r.ADDRESS,pa.ADDRESS_LINE1_TX,
        Substr (pa.ADDRESS_LINE2_TX, 1,instr(pa.ADDRESS_LINE2_TX,' ') - 1) AS SUIT,
        pa.ADDRESS_LINE2_TX,r.FIRST_NAME,r.LAST_NAME,pa.FIRST_NM,pa.LAST_NM,pa.FIRM_NM
from P_ADDRESS_OUTPUT_TBL_ARCH pa join bosh.raw_inwarranty_leads_tbl r
        on pa.UNIQUE_SEQ_NO = r.UNIQUE_SEQ_NO
        join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
         where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and ADDRESS not like '%#%'
    and CREATION_DT >= date '2022-01-01'
    and pa.ADDRESS_LINE2_TX is not null;
+---------------------------------------+-----------------------+----+----------------+-------------------------------------+---------+----------+-------------+--------------------------+
|ADDRESS                                |ADDRESS_LINE1_TX       |SUIT|ADDRESS_LINE2_TX|FIRST_NAME                           |LAST_NAME|FIRST_NM  |LAST_NM      |FIRM_NM                   |
+---------------------------------------+-----------------------+----+----------------+-------------------------------------+---------+----------+-------------+--------------------------+
|301 WEST AVENUE UNIT 3805              |301 WEST AVE           |APT |APT 3805        |JENNY TEAGUE BSP (BLDG CONTACT)      |NULL     |JENNY     |TEAGUE       |NULL                      |
|44 EAST AVE UNIT 1301                  |44 EAST AVE            |UNIT|UNIT 1301       |ANDRES BARBOZA BSP (BLDG CONTACT)    |NULL     |ANDRES    |BARBOZA      |NULL                      |
|515 WEST 18TH STREET UNIT 1502         |515 W 18TH ST          |APT |APT 1502        |KARINA TAVERNAS BSP (BLDG CONTACT)   |NULL     |KARINA    |TAVERNAS     |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 617 |133 SEAPORT BLVD       |UNIT|UNIT 617        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 1102|133 SEAPORT BLVD       |UNIT|UNIT 1102       |ROBERT FORCE FACILITY MANAGER        |NULL     |ROBERT    |FORCE        |NULL                      |
|2000 SOUTH OCEAN DRIVE 26TH FLOOR      |2000 S OCEAN DR        |26TH|26TH FL         |CHARLES BRADFORD (BLDG CONTACT)      |NULL     |CHARLES   |BRADFORD     |NULL                      |
|211 N HARBOR DR 2803                   |211 N HARBOR DR        |APT |APT 2803        |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|7 SUNSET DR                            |12109 NE 171ST PL      |APT |APT B103        |KEITH ARMSTRONG BUILDING &           |NULL     |MICHAEL   |GRIMES       |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 817 |133 SEAPORT BLVD       |UNIT|UNIT 817        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD TOWER 2 UNIT 720 |133 SEAPORT BLVD       |UNIT|UNIT 720        |ROBERT FORCE (BLDG CONTACT           |NULL     |ROBERT    |FORCE        |NULL                      |
|211 N HARBOR DR 809                    |211 N HARBOR DR        |APT |APT 809         |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|133 SEAPORT BOULEVARD TOWER 1 UNIT 1102|133 SEAPORT BLVD       |UNIT|UNIT 1102       |ROBERT FORCE FACILITY MANAGER        |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD T2 UNIT 712      |133 SEAPORT BLVD       |UNIT|UNIT 712        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD TOWER 2 UNIT 720 |133 SEAPORT BLVD       |UNIT|UNIT 720        |ROBERT FORCE (BLDG CONTACT           |NULL     |ROBERT    |FORCE        |NULL                      |
|6560-1 MONTANA AVE                     |6560 MONTANA AVE       |NULL|1               |BUILDERS SOURCE                      |NULL     |NULL      |NULL         |BUILDERS SOURCE           |
|211 N HARBOR DR 809                    |211 N HARBOR DR        |APT |APT 809         |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|211 N HARBOR DR 404                    |211 N HARBOR DR        |APT |APT 404         |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|33. MARIGOLD AVE UNIT 9                |33. MARIGOLD AVE UNIT 9|UNIT|UNIT 9          |BUILDER WOODY COUCH                  |NULL     |NULL      |NULL         |BUILDER WOODY COUCH       |
|1059 3RD AVENUE UNIT 20A               |1059 3RD AVE           |APT |APT 20A         |JOHN CORBETT (BUILDER)               |NULL     |JOHN      |CORBETT      |NULL                      |
|1059 3RD AVENUE UNIT 17B               |1059 3RD AVE           |APT |APT 17B         |JOHN CORBETT (BUILDER)               |NULL     |JOHN      |CORBETT      |NULL                      |
|1059 3RD AVENUE UNIT 11A               |1059 3RD AVE           |APT |APT 11A         |JOHN CORBETT (BUILDER)               |NULL     |JOHN      |CORBETT      |NULL                      |
|645 WEST 59TH STREET 36A               |645 W 59TH ST          |NULL|36A             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|645 WEST 59TH STREET 36A               |645 W 59TH ST          |NULL|36A             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|645 WEST 59TH STREET 36B               |645 W 59TH ST          |NULL|36B             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|685 1ST AVENUE 40F                     |685 1ST AVE            |APT |APT 40F         |WELLINGTON CABRERA(BLDG CONTACT)     |NULL     |WELLINGTON|CABRERA      |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 718 |133 SEAPORT BLVD       |UNIT|UNIT 718        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|645 WEST 59TH STREET 36B               |645 W 59TH ST          |NULL|36B             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 718 |133 SEAPORT BLVD       |UNIT|UNIT 718        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|91 LEONARD STREET 9F                   |91 LEONARD ST          |APT |APT 9F          |MARTIN PALJUSTEVIC (BUILDING CONTACT)|NULL     |MARTIN    |PALJUSTEVIC  |NULL                      |
|555 WEST 22ND STREET 6FE               |555 W 22ND ST          |NULL|6FE             |ROGER BLDG CONTACT                   |NULL     |NULL      |NULL         |ROGER BLDG. CONTACT       |
|3939 WISCONSIN AVENUE NORTHWEST B2     |3939 WISCONSIN AVE NW  |NULL|B2              |MATT BLDG CONTACT                    |NULL     |NULL      |NULL         |MATT BLDG. CONTACT        |
|685 1ST AVENUE 30L                     |685 1ST AVE            |APT |APT 30L         |RYAN PALMER BUILDING CONTACT         |NULL     |RYAN      |PALMER       |NULL                      |
|645 WEST 59TH STREET 36B               |645 W 59TH ST          |NULL|36B             |ALEX VAN DOMSELAAR (BLDG CONTACT)    |NULL     |ALEX      |VAN DOMSELAAR|NULL                      |
|3939 WISCONSIN AVE NW E1-402           |3939 WISCONSIN AVE NW  |NULL|E1-402          |MATT (BLDG CONTACT)                  |NULL     |NULL      |NULL         |MATT (BLDG. CONTACT)      |
|3939 WISCONSIN AVENUE NORTHWEST B2     |167 E 61ST ST          |APT |APT 11A         |MATT BLDG CONTACT                    |NULL     |WAYNE     |TAUB         |NULL                      |
|3939 WISCONSIN AVENUE NORTHWEST B2     |3939 WISCONSIN AVE NW  |NULL|B2              |MATT BLDG CONTACT                    |NULL     |NULL      |NULL         |MATT BLDG. CONTACT        |
|211 N HARBOR DR 2803                   |211 N HARBOR DR        |APT |APT 2803        |LAKE SHORE EAST BUILDING J           |NULL     |NULL      |NULL         |LAKE SHORE EAST BUILDING J|
|7407-4 E MINNEZONA AVE                 |7407 E MINNEZONA AVE   |NULL|4               |HAWK BUILDERS                        |NULL     |NULL      |NULL         |HAWK BUILDERS             |
|527 WEST 27TH STREET 10A               |527 W 27TH ST          |NULL|10A             |EDWARD LYONS (BLDG CONTACT)          |NULL     |EDWARD    |LYONS        |NULL                      |
|685 1ST AVENUE 25G                     |685 1ST AVE            |APT |APT 25G         |WELLINGTON CABRERA(BLDG CONTACT)     |NULL     |WELLINGTON|CABRERA      |NULL                      |
|133 SEAPORT BOULEVARD T2 UNIT 712      |133 SEAPORT BLVD       |UNIT|UNIT 712        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|300 SOUTH UNION STREET BLDG 2 UNIT 208 |300 S UNION ST         |BLDG|BLDG 2          |ADAM THORMAHLEN (BUILDING CONTACT)   |NULL     |ADAM      |THORMAHLEN   |NULL                      |
|211 N HARBOR DR                        |12725 VININGS CREEK DR |APT |APT 725         |LAKE SHORE EAST BUILDING J           |NULL     |STEPHEN   |VANNOY       |NULL                      |
|527 WEST 27TH STREET 10A               |527 W 27TH ST          |NULL|10A             |EDWARD LYONS (BLDG CONTACT)          |NULL     |EDWARD    |LYONS        |NULL                      |
|99 HUDSON ST PH02 FLOOR 74             |99 HUDSON ST           |FL  |FL 74           |JOSEPH SUSCOVICH (BUILDING CONTACT)  |NULL     |JOSEPH    |SUSCOVICH    |NULL                      |
|211 N HARBOR DR 2002                   |211 N HARBOR DR        |APT |APT 2002        |O BUILDING J                         |NULL     |NULL      |NULL         |O BUILDING J              |
|33. MARIGOLD AVE UNIT 9                |33. MARIGOLD AVE UNIT 9|UNIT|UNIT 9          |BUILDER WOODY COUCH                  |NULL     |NULL      |NULL         |BUILDER WOODY COUCH       |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 802 |133 SEAPORT BLVD       |UNIT|UNIT 802        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|133 SEAPORT BOULEVARD TOWER 1 UNIT 802 |133 SEAPORT BLVD       |UNIT|UNIT 802        |ROBERT FORCE (BLDG CONTACT)          |NULL     |ROBERT    |FORCE        |NULL                      |
|100 BARROW STREET UNIT 4A              |100 BARROW ST          |APT |APT 4A          |MIKE BLDG MANAGER                    |NULL     |NULL      |NULL         |NULL                      |
|685 1ST AVENUE 25G                     |685 1ST AVE            |APT |APT 25G         |WELLINGTON CABRERA(BLDG CONTACT)     |NULL     |WELLINGTON|CABRERA      |NULL                      |
|210 BIRDSEYE LOT 77                    |210 BIRDSEYE           |LOT |LOT 77          |CALPAC BUILDER SCOTT                 |NULL     |NULL      |NULL         |NULL                      |
|133 SEAPORT BOULEVARD T2-803           |133 SEAPORT BLVD       |NULL|T2-803          |ROBERT FORCE BUILDING CONTACT        |NULL     |ROBERT    |FORCE        |NULL                      |
+---------------------------------------+-----------------------+----+----------------+-------------------------------------+---------+----------+-------------+--------------------------+


+---------------------------------------+----------------------+----+----------------+---------------------------------------+
|ADDRESS                                |ADDRESS_LINE1_TX      |SUIT|ADDRESS_LINE2_TX|FIRST_NAME                             |
+---------------------------------------+----------------------+----+----------------+---------------------------------------+
|50 BRIDGE PARK DRIVE #18E              |50 BRIDGE PARK DR     |APT |APT 18E         |IBRAN (RESIDENT MANAGER)               |
|131 BEVERLY STREET #11H                |131 BEVERLY ST        |STE |STE 11H         |DUPLICATE STEVE HEATH (BLDG CONTACT)   |
|301 WEST AVENUE UNIT 3805              |301 WEST AVE          |APT |APT 3805        |JENNY TEAGUE BSP (BLDG CONTACT)        |
|301 ALTARA AVENUE #816                 |301 ALTARA AVE        |APT |APT 816         |STEPHANIE HILZEN (RESIDENT MANAGER)    |
|18501 COLLINS AVENUE #1001             |18501 COLLINS AVE     |APT |APT 1001        |ROBERT MADERA (BLDG CONTACT)           |
|44 EAST AVE UNIT 1301                  |44 EAST AVE           |UNIT|UNIT 1301       |ANDRES BARBOZA BSP (BLDG CONTACT)      |
|100 SHAWMUT AVENUE #509                |100 SHAWMUT AVE       |UNIT|UNIT 509        |EMILY ANTONELLI BSP (BLDG CONTACT)     |
|11 HOYT STREET #10F                    |11 HOYT ST            |APT |APT 10F         |IZZY BUILDING CONTACT                  |
|3107 PEACHTREE RD N# #1202             |3107 PEACHTREE RD NE  |UNIT|UNIT 1202       |SCOTT SMITH (BLDG CONTACT)             |
|400 W 61ST STREET #1932                |400 W 61ST ST         |APT |APT 1932        |DARREN MANICKCHAND BSP BUILDING CONTACT|
|320 ADOLPHUS AVENUE #613               |320 ADOLPHUS AVE      |APT |APT 613         |JACKIE NOVOA (BLDG CONTACT)            |
|8310 SOUTHWESTERN BOULEVARD #BLDG G    |8310 SOUTHWESTERN BLVD|BLDG|BLDG G          |MIGUEL CASTRO (BLDG CONTACT)           |
|6803 CAMERON DRIVE NORTHWEST #115      |6803 CAMERON DR NW    |APT |APT 115         |JOE ALFONSO BSP (BLDG CONTACT)         |
|11 HOYT STREET #14H                    |11 HOYT ST            |APT |APT 14H         |IZZY GJONBALAJ - BLDG CONTACT          |
|11 HOYT STREET #5G                     |11 HOYT ST            |APT |APT 5G          |IZZY GJONBALAJ - BLDG CONTACT          |
|11 HOYT STREET #21K                    |11 HOYT ST            |APT |APT 21K         |IZZY GJONBALAJ - BLDG CONTACT          |
|18501 COLLINS AVENUE #702              |18501 COLLINS AVE     |APT |APT 702         |ROD CARRILLO BSP BUILDING CONTACT      |
|18501 COLLINS AVENUE #702              |18501 COLLINS AVE     |APT |APT 702         |ROD CARRILLO BSP BUILDING CONTACT      |
|1 BOERUM PLACE #7F                     |1 BOERUM PL           |APT |APT 7F          |DAVID BUILDING SUPER                   |
|1788 NORTH PIERCE STREET WEST TWR #2014|1788 N PIERCE ST      |APT |APT 2014        |LIANNE URODA - BLDG CONTACT            |
|1788 NORTH PIERCE STREET WEST TWR #2201|1788 N PIERCE ST      |APT |APT 2201        |LIANNE URODA - BLDG CONTACT            |
|212 5TH AVENUE #12B                    |212 5TH AVE           |APT |APT 12B         |CHRIS DOWER (BLDG CONTACT)             |
|685 1ST AVENUE #11G                    |685 1ST AVE           |APT |APT 11G         |WELLINGTON CABRERA (BLDG CONTACT)      |
|2510 6TH AVENUE #610                   |2510 6TH AVE          |UNIT|UNIT 610        |RACHEL JOHANSON (BLDG CONTACT)         |
|121 STEWART STREET FL 13 UNIT #1203    |121 STEWART ST        |FL  |FL 13           |DENISE BLDG CONTACT                    |
|1788 NORTH PIERCE STREET #2112         |1788 N PIERCE ST      |APT |APT 2112        |LIANNE URODA BSP (BLDG CONTACT)        |
|180 EAST 88TH STREET #14A              |180 E 88TH ST         |APT |APT 14A         |NORI POCESTA(BLDG CONTACT)             |
|180 EAST 88TH STREET #14A              |180 E 88TH ST         |APT |APT 14A         |NORI POCESTA(BLDG CONTACT)             |
|131-01 40TH ROAD #17Y                  |13101 40TH RD         |APT |APT 17Y         |LARRY LIN BSP (BLDG CONTACT)           |
|150 EAST 23RD STREET #10B              |150 E 23RD ST         |APT |APT 10B         |ENVER BUILDING MANAGER                 |
+---------------------------------------+----------------------+----+----------------+---------------------------------------+


select  COUNT(*)
from P_ADDRESS_OUTPUT_TBL_ARCH pa join bosh.raw_inwarranty_leads_tbl r
        on pa.UNIQUE_SEQ_NO = r.UNIQUE_SEQ_NO
        join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
         where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and ADDRESS like '%#%'
    and CREATION_DT >= date '2022-01-01'
    and pa.ADDRESS_LINE2_TX is not null;

select SUIT,COUNT(SUIT) from (
select  Substr (pa.ADDRESS_LINE2_TX, 1,instr(pa.ADDRESS_LINE2_TX,' ') - 1) AS SUIT
from P_ADDRESS_OUTPUT_TBL_ARCH pa join bosh.raw_inwarranty_leads_tbl r
        on pa.UNIQUE_SEQ_NO = r.UNIQUE_SEQ_NO
        join AUDIT_TBL ai on ai.AUDIT_KEY = r.INSERT_AUDIT_KEY
         where
        (1=2
         or   FIRST_NAME like '%BUILDER%'
        or FIRST_NAME like '%BLDG%'
        or FIRST_NAME like '%BUILDING%'
        or FIRST_NAME like '%CONTACT%'
        or FIRST_NAME like '%SUPER%'
        or FIRST_NAME like '%MANAGER%'
        )
    and ADDRESS is not null and MODEL_NUMBER is not null and PURCHASE_DATE is not null
    and CREATION_DT >= date '2022-01-01'
    and pa.ADDRESS_LINE2_TX is not null)
Group by SUIT
;
+----+-----------+
|SUIT|COUNT(SUIT)|
+----+-----------+
|APT |1731       |
|UNIT|565        |
|STE |30         |
|PH  |22         |
|FL  |12         |
|BLDG|11         |
|17TH|4          |
|5TH |2          |
|14TH|2          |
|26TH|1          |
|21ST|1          |
|LOT |1          |
|NULL|0          |
+----+-----------+




+-----------------------------------+----------------------+----------------+---------------------------------------+---------+---------+-----------+---------------------+
|ADDRESS                            |ADDRESS_LINE1_TX      |ADDRESS_LINE2_TX|FIRST_NAME                             |LAST_NAME|FIRST_NM |LAST_NM    |FIRM_NM              |
+-----------------------------------+----------------------+----------------+---------------------------------------+---------+---------+-----------+---------------------+
|50 BRIDGE PARK DRIVE #18E          |50 BRIDGE PARK DR     |APT 18E         |IBRAN (RESIDENT MANAGER)               |NULL     |NULL     |IBRAN      |NULL                 |
|131 BEVERLY STREET #11H            |131 BEVERLY ST        |STE 11H         |DUPLICATE STEVE HEATH (BLDG CONTACT)   |NULL     |STEVE    |HEATH      |NULL                 |
|301 ALTARA AVENUE #816             |301 ALTARA AVE        |APT 816         |STEPHANIE HILZEN (RESIDENT MANAGER)    |NULL     |STEPHANIE|HILZEN     |NULL                 |
|18501 COLLINS AVENUE #1001         |18501 COLLINS AVE     |APT 1001        |ROBERT MADERA (BLDG CONTACT)           |NULL     |ROBERT   |MADERA     |NULL                 |
|44 EAST AVE UNIT 1301              |44 EAST AVE           |UNIT 1301       |ANDRES BARBOZA BSP (BLDG CONTACT)      |NULL     |ANDRES   |BARBOZA    |NULL                 |
|100 SHAWMUT AVENUE #509            |100 SHAWMUT AVE       |UNIT 509        |EMILY ANTONELLI BSP (BLDG CONTACT)     |NULL     |EMILY    |ANTONELLI  |NULL                 |
|11 HOYT STREET #10F                |11 HOYT ST            |APT 10F         |IZZY BUILDING CONTACT                  |NULL     |NULL     |NULL       |IZZY BUILDING CONTACT|
|3107 PEACHTREE RD N# #1202         |3107 PEACHTREE RD NE  |UNIT 1202       |SCOTT SMITH (BLDG CONTACT)             |NULL     |SCOTT    |SMITH      |NULL                 |
|400 W 61ST STREET #1932            |400 W 61ST ST         |APT 1932        |DARREN MANICKCHAND BSP BUILDING CONTACT|NULL     |DARREN   |MANICKCHAND|NULL                 |
|320 ADOLPHUS AVENUE #613           |320 ADOLPHUS AVE      |APT 613         |JACKIE NOVOA (BLDG CONTACT)            |NULL     |JACKIE   |NOVOA      |NULL                 |
|8310 SOUTHWESTERN BOULEVARD #BLDG G|8310 SOUTHWESTERN BLVD|BLDG G          |MIGUEL CASTRO (BLDG CONTACT)           |NULL     |MIGUEL   |CASTRO     |NULL                 |
|6803 CAMERON DRIVE NORTHWEST #115  |6803 CAMERON DR NW    |APT 115         |JOE ALFONSO BSP (BLDG CONTACT)         |NULL     |JOE      |ALFONSO    |NULL                 |
|11 HOYT STREET #14H                |11 HOYT ST            |APT 14H         |IZZY GJONBALAJ - BLDG CONTACT          |NULL     |IZZY     |GJONBALAJ  |NULL                 |
|11 HOYT STREET #5G                 |11 HOYT ST            |APT 5G          |IZZY GJONBALAJ - BLDG CONTACT          |NULL     |IZZY     |GJONBALAJ  |NULL                 |
+-----------------------------------+----------------------+----------------+---------------------------------------+---------+---------+-----------+---------------------+
