


select * from COMMON_LOAD_HOLD_TBL;--88

select * from AUDIT_TBL where AUDIT_KEY in (
    select distinct INSERT_AUDIT_KEY from COMMON_LOAD_HOLD_TBL
    );
+---------+--------------------------+---------------------------+------------------+---------------------------+
|AUDIT_KEY|CREATION_DT               |PROGRAM_NM                 |PROGRAM_VERSION_NO|TABLE_NM                   |
+---------+--------------------------+---------------------------+------------------+---------------------------+
|807701   |2024-04-01 02:31:30.000000|sync_import_from_sync_table|1.0               |COMMON_LOAD_ADDRESS_TBL    |
|807702   |2024-04-01 02:31:41.000000|sync_import_from_sync_table|1.0               |COMMON_LOAD_PHONE_TBL      |
|807703   |2024-04-01 02:31:53.000000|sync_import_from_sync_table|1.0               |COMMON_LOAD_EMAIL_TBL      |
|807704   |2024-04-01 02:32:10.000000|sync_import_from_sync_table|1.0               |COMMON_LOAD_SERIAL_ITEM_TBL|
+---------+--------------------------+---------------------------+------------------+---------------------------+
BOSHSTG> Delete from COMMON_LOAD_HOLD_TBL
[2024-04-01 04:30:39] 88 rows affected in 238 ms
[2024-04-01 04:30:43] transaction committed: @console_205 [BOSH-STg-Prod]


select * from COMMON_ORDER_HOLD_TBL;--78

select * from AUDIT_TBL where AUDIT_KEY in (
    select distinct INSERT_AUDIT_KEY from COMMON_ORDER_HOLD_TBL
    );
+---------+--------------------------+---------------------------+------------------+---------------------+
|AUDIT_KEY|CREATION_DT               |PROGRAM_NM                 |PROGRAM_VERSION_NO|TABLE_NM             |
+---------+--------------------------+---------------------------+------------------+---------------------+
|807705   |2024-04-01 02:32:19.000000|sync_import_from_sync_table|1.0               |COMMON_ORDER_HOLD_TBL|
+---------+--------------------------+---------------------------+------------------+---------------------+

BOSHSTG> Delete from COMMON_ORDER_HOLD_TBL
[2024-04-01 04:31:13] 78 rows affected in 223 ms
[2024-04-01 04:31:18] transaction committed: @console_205 [BOSH-STg-Prod]

                                 