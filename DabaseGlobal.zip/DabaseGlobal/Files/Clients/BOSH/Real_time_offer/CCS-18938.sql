
SELECT *
                        FROM ( SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'
				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day', LOCALTIMESTAMP)
			          ELSE
				       date_trunc('day', LOCALTIMESTAMP)+interval '1 days'
			     END AS coverage_start_dt,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
			          THEN
			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
			         WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'                                  ELSE
				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
			     END AS coverage_end_dt,
			     ppt.BASE_PRICE_AMT,
			     ppt.TERM_MONTHS,
			     si.purchase_dt,
			     pol.age,
			     round(DATE_PART('day', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
			     pol.description as policy_description
			FROM
			(SELECT * from serialized_item where serialized_item_id=193739479) si
			LEFT JOIN pricing_scheme_lkp psl
			ON(si.latest_coverage_type_id=psl.latest_coverage_type_id and
			(EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
			between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
			LEFT JOIN product_price_tbl ppt ON
			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') -- BOSH-361
			LEFT JOIN policy pol ON
			(ppt.POLICY_ID=pol.POLICY_ID
			)
			LEFT JOIN product_ext PE ON
			(PE.product_id = ppt.product_id)
			LEFT join pricing_scheme_tbl pst
	                on pst.pricing_scheme_id = ppt.pricing_scheme_id
			WHERE
                            PE.PRODUCT_COVERAGE_END_DT  >= CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
                                      THEN
                                           date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
                                WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
                                      THEN
                                       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'                                  ELSE
                                      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
                                    END
                                    ---
                                and case when substr(pst.description, 1, 2) = 'RN' then
                                      round(DATE_PART('day', si.latest_coverage_exp_dt - si.purchase_dt)/365)
                                     else 0
                                end = coalesce (pol.age, 0)
			) t
           -- where (coverage_end_dt - purchase_dt)  <= interval '3650 day'    --total coverage must be less than 10 years for all brands
            ORDER BY TERM_MONTHS ASC;

select si.product_id,psl.pricing_scheme_id,ppt.policy_id FROM
			(SELECT * from serialized_item where serialized_item_id=193739479) si
			 JOIN pricing_scheme_lkp psl
			    ON(si.latest_coverage_type_id=psl.latest_coverage_type_id
			        and
                    (EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH

			        )
            Left JOIN product_price_tbl ppt ON
			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') -- BOSH-361

;

-- product_id,pricing_scheme_id
-- 11198544,200
-- 11198544,201
-- 11198544,220
-- 11198544,151

select * from pricing_scheme_tbl where pricing_scheme_id in (140,73,72,74);

select * from pricing_scheme_tbl where pricing_scheme_id in (200,201,220,151);


select * from product_price_tbl where product_id = 11198544 --and  pricing_scheme_id in (200,201,220,151) and coalesce(active_ind, 'Y') = 'Y' ;
