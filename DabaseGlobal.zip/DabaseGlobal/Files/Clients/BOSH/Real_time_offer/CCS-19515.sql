
SELECT *
                        FROM ( SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'
				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day', LOCALTIMESTAMP)
			          ELSE
				       date_trunc('day', LOCALTIMESTAMP)+interval '1 days'
			     END AS coverage_start_dt,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
			          THEN
			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
			         WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
			          THEN
				       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'                                  ELSE
				      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
			     END AS coverage_end_dt,
			     ppt.BASE_PRICE_AMT,
			     ppt.TERM_MONTHS,
			     si.purchase_dt,
			     pol.age,
			     round(DATE_PART('day', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
			     pol.description as policy_description
			FROM
			(SELECT * from serialized_item where serialized_item_id=8730668) si
			LEFT JOIN pricing_scheme_lkp psl
			ON(si.latest_coverage_type_id=psl.latest_coverage_type_id and
			(EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
			between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
			LEFT JOIN product_price_tbl ppt ON
			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') -- BOSH-361
			LEFT JOIN policy pol ON
			(ppt.POLICY_ID=pol.POLICY_ID
			)
			LEFT JOIN product_ext PE ON
			(PE.product_id = ppt.product_id)
			LEFT join pricing_scheme_tbl pst
	                on pst.pricing_scheme_id = ppt.pricing_scheme_id
			WHERE
                            PE.PRODUCT_COVERAGE_END_DT  >= CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
                                      THEN
                                           date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
                                WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= LOCALTIMESTAMP
                                      THEN
                                       date_trunc('day', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval '1 month'                                  ELSE
                                      date_trunc('day', LOCALTIMESTAMP) + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
                                    END
                                    ---
                                and case when substr(pst.description, 1, 2) = 'RN' then
                                      round(DATE_PART('day', si.latest_coverage_exp_dt - si.purchase_dt)/365)
                                     else 0
                                end = coalesce (pol.age, 0)
			) t
           -- where (coverage_end_dt - purchase_dt)  <= interval '3650 day'    --total coverage must be less than 10 years for all brands
            ORDER BY TERM_MONTHS ASC;


-- Model of Dishwasher: DWHD660WFP
-- Serial Number: 0000-FD000700420
-- Current Appliance Service Plan Contract (Internal Contract #12921534) Active Until: 9/11/20225

select si.product_id,-- 2030378
       LATEST_COVERAGE_EXP_DT,--
       (EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int  clt,--
       si.latest_coverage_type_id,
       psl.pricing_scheme_id,
       ppt.policy_id

FROM
			(SELECT * from serialized_item where serialized_item_id=8730668) si
			 left JOIN pricing_scheme_lkp psl
			    ON(si.latest_coverage_type_id=psl.latest_coverage_type_id
			        and
                    (EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH

			        )
            Left JOIN product_price_tbl ppt ON
			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, 'Y') = 'Y') --

;
-- +----------+--------------------------+---+-----------------------+-----------------+---------+
-- |product_id|latest_coverage_exp_dt    |clt|latest_coverage_type_id|pricing_scheme_id|policy_id|
-- +----------+--------------------------+---+-----------------------+-----------------+---------+
-- |2030378   |2025-07-17 00:00:00.000000|118|2                      |236              |NULL     |
-- |2030378   |2025-07-17 00:00:00.000000|118|2                      |237              |NULL     |
-- |2030378   |2025-07-17 00:00:00.000000|118|2                      |238              |NULL     |
-- |2030378   |2025-07-17 00:00:00.000000|118|2                      |239              |NULL     |
-- |2030378   |2025-07-17 00:00:00.000000|118|2                      |240              |NULL     |
-- |2030378   |2025-07-17 00:00:00.000000|118|2                      |241              |NULL     |
-- |2030378   |2025-07-17 00:00:00.000000|118|2                      |242              |NULL     |
-- +----------+--------------------------+---+-----------------------+-----------------+---------+

select count(*),count(distinct pricing_scheme_id ),count(distinct policy_id ) from product_price_tbl where product_id = 2030378 and pricing_scheme_id  in (236,237,238,239,240,241,242);
-- +-----+-----+-----+
-- |count|count|count|
-- +-----+-----+-----+
-- |0    |0    |0    |
-- +-----+-----+-----+

select * from pricing_scheme_lkp where latest_coverage_type_id = 2 and pricing_scheme_id in (236,237,238,239,240,241,242);
-- +-----------------------+-------------------+--------------------+-----------------+---------------+--------------------------+
-- |latest_coverage_type_id|days_from_covrg_low|days_from_covrg_high|pricing_scheme_id|last_updated_by|last_updated_ts           |
-- +-----------------------+-------------------+--------------------+-----------------+---------------+--------------------------+
-- |2                      |22                 |210                 |236              |BOSH-1880      |2025-08-19 10:36:37.832332|
-- |2                      |22                 |210                 |237              |BOSH-1880      |2025-08-19 10:36:37.832332|
-- |2                      |22                 |210                 |238              |BOSH-1880      |2025-08-19 10:36:37.832332|
-- |2                      |22                 |210                 |239              |BOSH-1880      |2025-08-19 10:36:37.832332|
-- |2                      |22                 |210                 |240              |BOSH-1880      |2025-08-19 10:36:37.832332|
-- |2                      |22                 |210                 |241              |BOSH-1880      |2025-08-19 10:36:37.832332|
-- |2                      |22                 |210                 |242              |BOSH-1880      |2025-08-19 10:36:37.832332|
-- +-----------------------+-------------------+--------------------+-----------------+---------------+--------------------------+

select count(*),count(distinct pricing_scheme_id ),count(distinct policy_id ) from product_price_tbl where product_id = 2030378  and coalesce(active_ind, 'Y') = 'Y' ;
-- +-----+-----+-----+
-- |count|count|count|
-- +-----+-----+-----+
-- |240  |97   |76   |
-- +-----+-----+-----+