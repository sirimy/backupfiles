
select DISTINCT CSD.NAME ,CSD.CONTRACT_STATUS_KEY,  CD.CONTRACT_KEY
      ,  SI_KEY ,  COT.ORDER_KEY
      ,CCD.CONTRACT_KEY,CREATED_TS
        from (
                select * from (
                    select  oit.ORDER_KEY,oit.ORDER_LINE_KEY,si.SI_KEY, si.PRODUCT_KEY, si.MODEL_NO, si.PURCHASE_DT_KEY, si.WARRANTY_EXPIRATION_DT, si.REGISTRATION_DT, si.LATEST_COVERAGE_EXP_DT, si.LATEST_COVERAGE_TYPE
                           ,oit.purchase_dt, oit.coverage_start_dt, oit.coverage_exp_dt
                           ,r.CONTRACT_START_DATE, r.CONTRACT_END_DATE, r.P2_CONTRACT_NO,o.CREATED_TS
                           ,row_number() over(partition by si.si_key order by oit.purchase_dt desc) as rno
                      from p_serialized_item_dim  si
                           join p_serialized_item_ext_dim six on six.si_key = si.si_key
                           JOIN p_order_item_tbl oit on oit.serialized_item_key = si.si_key
                           JOIN p_order_tbl o on (oit.order_key = o.order_key)
                           LEFT JOIN bosh.raw_contract_sales_tbl r on oit.order_key || '-' || oit.order_line_key = r.unique_identifier
                     where latest_coverage_type = 1
                --       and duplicate_ind = 'N'
                       and o.CREATED_TS <= SYSDATE - 10
                       and o.CREATED_TS >= TRUNC(SYSDATE) - 730
                       and si.si_key not in (
                              select  oit2.serialized_item_key
                                from   p_contract_dim con2
                                       JOIN p_contract_order_tbl cot2 on (cot2.contract_key = con2.contract_key)
                                       JOIN p_order_item_tbl  oit2 on (oit2.order_key = cot2.order_key and oit2.order_line_key = cot2.order_line_key)
                                WHERE  con2.contract_status_key IN (2, 3)   --canceled?
                              )
                     --and oit.ORDER_KEY in (449889,438363 ,439297 )
                )
                where rno = 1
            ) T2 LEFT Join BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = T2.ORDER_KEY AND COT.ORDER_LINE_KEY = T2.ORDER_LINE_KEY
                 LEFT JOIN BOSH.CONTRACT_DIM Cd on CD.CONTRACT_KEY = COT.CONTRACT_KEY
                 LEFT JOIN BOSH.CONTRACT_STATUS_DIM CSd on CSd.CONTRACT_STATUS_KEY= CD.CONTRACT_STATUS_KEY
                 LEFT Join BOSH.CONTRACT_CANCELLATION_DIM CCD on CCD.CONTRACT_KEY  =  COT.CONTRACT_KEY
--GROUP BY CSD.NAME,CSD.CONTRACT_STATUS_KEY
;

-- +----+-------------------+------------+-------+---------+------------+
-- |NAME|CONTRACT_STATUS_KEY|CONTRACT_KEY|SI_KEY |ORDER_KEY|CONTRACT_KEY|
-- +----+-------------------+------------+-------+---------+------------+
-- |NULL|NULL               |NULL        |3016374|NULL     |NULL        |
-- |NULL|NULL               |NULL        |3868443|NULL     |NULL        |
-- |NULL|NULL               |NULL        |3868444|NULL     |NULL        |
-- |NULL|NULL               |NULL        |4197809|NULL     |NULL        |
-- |ACTV|1                  |211163      |3835171|456153   |NULL        |
-- |ACTV|1                  |211561      |4042657|456615   |NULL        |
-- |ACTV|1                  |208491      |4296440|450603   |NULL        |
-- |ACTV|1                  |208527      |4296441|450603   |NULL        |
-- |ACTV|1                  |208518      |4296442|450603   |NULL        |
-- |ACTV|1                  |209948      |4308342|453459   |NULL        |
-- |ACTV|1                  |210850      |4312708|455515   |NULL        |
-- |ACTV|1                  |210861      |4312711|455515   |NULL        |
-- |ACTV|1                  |210906      |4312712|455515   |NULL        |
-- |ACTV|1                  |210862      |4312713|455515   |NULL        |
-- |ACTV|1                  |211072      |4312740|455795   |NULL        |
-- +----+-------------------+------------+-------+---------+------------+
Select Distinct LATEST_COVERAGE_TYPE from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in(3835171,4042657,4296440,4296441,4296442,4308342,4312708,4312711,4312712,4312713,4312740)
;-- Verified its duplicate SI_KEY marked type =2, so above need to mark type = 2


Select si_key,WARRANTY_EXPIRATION_DT, LATEST_COVERAGE_TYPE, LATEST_COVERAGE_EXP_DT,(LATEST_COVERAGE_EXP_DT - WARRANTY_EXPIRATION_DT)/365 diff from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in(3835171,4042657,4296440,4296441,4296442,4308342,4312708,4312711,4312712,4312713,4312740);
-- +-------+--------------------------+--------------------+----------------------+-------------------+
-- |SI_KEY |WARRANTY_EXPIRATION_DT    |LATEST_COVERAGE_TYPE|LATEST_COVERAGE_EXP_DT|DIFF               |
-- +-------+--------------------------+--------------------+----------------------+-------------------+
-- |3835171|2025-01-01 00:00:00.000000|2                   |2027-04-11            |2 6:34:31.232876712|
-- |4042657|2025-08-09 00:00:00.000000|2                   |2029-08-09            |4 0:3:56.712328767 |
-- |4296440|2025-06-12 00:00:00.000000|2                   |2031-06-12            |6 0:3:56.712328767 |
-- |4296441|2025-06-12 00:00:00.000000|2                   |2031-06-12            |6 0:3:56.712328767 |
-- |4296442|2025-06-12 00:00:00.000000|2                   |2031-06-12            |6 0:3:56.712328767 |
-- |4308342|2025-04-23 00:00:00.000000|2                   |2030-04-23            |5 0:3:56.712328767 |
-- |4312708|2025-04-19 00:00:00.000000|2                   |2030-04-19            |5 0:3:56.712328767 |
-- |4312711|2025-04-19 00:00:00.000000|2                   |2030-04-19            |5 0:3:56.712328767 |
-- |4312712|2025-04-19 00:00:00.000000|2                   |2030-04-19            |5 0:3:56.712328767 |
-- |4312713|2025-04-19 00:00:00.000000|2                   |2030-04-19            |5 0:3:56.712328767 |
-- |4312740|2025-04-27 00:00:00.000000|2                   |2030-04-27            |5 0:3:56.712328767 |
-- +-------+--------------------------+--------------------+----------------------+-------------------+

Select Distinct LATEST_COVERAGE_TYPE from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in(3835171,4042657,4296440,4296441,4296442,4312708,4312711,4312712,4312713);

-- need to check if update duplicate
Select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in (4308342,4308341);
-- +-------+-----------+---------+----------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
-- |SI_KEY |PRODUCT_KEY|SERIAL_NO|MODEL_NO  |PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |PURCHASE_AMT|CURRENCY_CD|LAST_UPDATED_LEADS_DT|REGISTRATION_DT    |QUALITY_SCORE|END_DT|DIM_STATUS_CD|LATEST_COVERAGE_EXP_DT|LATEST_COVERAGE_TYPE|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +-------+-----------+---------+----------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
-- |4308341|31848      |NULL     |T30IR905SP|12166          |2025-04-23 00:00:00.000000|NULL        |USD        |NULL                 |2025-03-25 18:14:41|0            |NULL  |A            |2030-04-23            |2                   |937709          |940914          |940914        |
-- |*4308342|31848      |NULL     |T30IR905SP|12166          |2025-04-23 00:00:00.000000|NULL        |USD        |NULL                 |2025-03-25 18:15:07|0            |NULL  |A            |2025-04-23            |1                   |937709          |NULL            |937731        |
-- +-------+-----------+---------+----------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
Select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in (4312740,4110366);
-- +-------+-----------+-------------------------+--------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
-- |SI_KEY |PRODUCT_KEY|SERIAL_NO                |MODEL_NO|PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |PURCHASE_AMT|CURRENCY_CD|LAST_UPDATED_LEADS_DT|REGISTRATION_DT    |QUALITY_SCORE|END_DT|DIM_STATUS_CD|LATEST_COVERAGE_EXP_DT|LATEST_COVERAGE_TYPE|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +-------+-----------+-------------------------+--------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
-- |4110366|31262      |000208-000000000000018800|MD24WS  |12170          |2025-04-26 00:00:00.000000|NULL        |USD        |NULL                 |2025-04-09 13:34:17|10           |NULL  |A            |2030-04-27            |2                   |886804          |948342          |948342        |
-- |*4312740|31262      |NULL                     |MD24WS  |12170          |2025-04-27 00:00:00.000000|NULL        |USD        |NULL                 |2025-04-09 14:34:34|0            |NULL  |A            |2025-04-27            |1                   |947370          |NULL            |947392        |
-- +-------+-----------+-------------------------+--------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+

Select DISTINCT LATEST_COVERAGE_TYPE from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in (4308341,4110366);

Select DISTINCT LATEST_COVERAGE_TYPE from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in (4308342,4312740);


-- +----+-------------------+------------+-------+---------+------------+
-- |NAME|CONTRACT_STATUS_KEY|CONTRACT_KEY|SI_KEY |ORDER_KEY|CONTRACT_KEY|
-- +----+-------------------+------------+-------+---------+------------+
-- |NULL|NULL               |NULL        |3016374|NULL     |NULL        |contract not created as failed and goes to RAW_CONTRACT_SALES_ERROR_TBL
-- |NULL|NULL               |NULL        |3868443|NULL     |NULL        |[2]3868443 raw contract comes but contract not created due to its not reached to CONTRACT_COMMON_LOAD
-- |NULL|NULL               |NULL        |3868444|NULL     |NULL        |[3] 3868444 raw contract comes but contract not created due to its not reached to CONTRACT_COMMON_LOAD
-- |NULL|NULL               |NULL        |4197809|NULL     |NULL        |[4] 4197809 raw contract comes but not reached to CONTRACT_COMMON_LOAD

SELECT * FROM bosh.SERIALIZED_ITEM_DIM WHERE SI_KEY IN(
    SELECT SI_KEY FROM bosh.SERIALIZED_ITEM_LKP SLP1 WHERE SI_XID IN (
        SELECT SLP.SI_XID FROM bosh.SERIALIZED_ITEM_LKP slp WHERE SI_KEY =4312713
    ) AND SI_KEY <> 4312713)
    ;