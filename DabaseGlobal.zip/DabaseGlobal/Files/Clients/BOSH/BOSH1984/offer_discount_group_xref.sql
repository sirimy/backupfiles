select COUNT(*) from offer_discount_group_xref where offer_id in ( select ot.offer_id from offer_tbl ot);--11874



SELECT indexname, indexdef FROM pg_indexes
WHERE tablename = 'offer_discount_group_xref' AND schemaname = 'boshbaplweb'; --
-- +------------------------------+------------------------------------------------------------------------------------------------------------------+
-- |indexname                     |indexdef                                                                                                          |
-- +------------------------------+------------------------------------------------------------------------------------------------------------------+
-- |offer_discount_group_xref_pkey|CREATE UNIQUE INDEX offer_discount_group_xref_pkey ON boshbaplweb.offer_discount_group_xref USING btree (offer_id)|
-- +------------------------------+------------------------------------------------------------------------------------------------------------------+

-- For trigger check.

SELECT trigger_name, event_manipulation AS event, action_timing AS timing, action_statement AS definition
FROM information_schema.triggers WHERE event_object_table = 'offer_discount_group_xref' AND trigger_schema = 'boshbaplweb';--0
-- Optionally filter by schema


-- For constraint check.

select * FROM
    information_schema.constraint_table_usage t1
             where table_name in ('offer_discount_group_xref')
;
-- +-------------+------------+-------------------------+------------------+-----------------+------------------------------+
-- |table_catalog|table_schema|table_name               |constraint_catalog|constraint_schema|constraint_name               |
-- +-------------+------------+-------------------------+------------------+-----------------+------------------------------+
-- |BOSH         |boshbaplweb |offer_discount_group_xref|BOSH              |boshbaplweb      |offer_discount_group_xref_pkey|
-- +-------------+------------+-------------------------+------------------+-----------------+------------------------------+


-- Improve the time DB function is taking to return
-- Steps are below

-- 1. New tables create

CREATE TABLE offer_discount_group_xref_new AS
SELECT * from offer_discount_group_xref where offer_id in ( select ot.offer_id from offer_tbl ot);
--commit;

--
-- 2. ANALYZE commands

ANALYZE offer_discount_group_xref_new;

--
-- 3. We drop all index and constraint for  offer_tbl

alter table offer_discount_group_xref drop constraint offer_discount_group_xref_pkey;

drop index offer_discount_group_xref_pkey;

-- 4. Rename Tables

alter table offer_discount_group_xref rename to offer_discount_group_xref_arch;

alter table offer_discount_group_xref_new rename to offer_discount_group_xref;


-- 5. For offer_discount_group_xref  new table adding index and constraint

alter table offer_discount_group_xref
add constraint offer_discount_group_xref_pkey primary key (offer_id);


--

-- 9. QC sql

select COUNT(*) from offer_discount_group_xref  ;--11874
select COUNT(*) from offer_discount_group_xref_arch  ;--11874

SELECT indexname, indexdef FROM pg_indexes
WHERE tablename = 'offer_discount_group_xref' AND schemaname = 'boshbaplweb'; --
-- +------------------------------+------------------------------------------------------------------------------------------------------------------+
-- |indexname                     |indexdef                                                                                                          |
-- +------------------------------+------------------------------------------------------------------------------------------------------------------+
-- |offer_discount_group_xref_pkey|CREATE UNIQUE INDEX offer_discount_group_xref_pkey ON boshbaplweb.offer_discount_group_xref USING btree (offer_id)|
-- +------------------------------+------------------------------------------------------------------------------------------------------------------+


-- For trigger check.
SELECT trigger_name, event_manipulation AS event, action_timing AS timing, action_statement AS definition
FROM information_schema.triggers WHERE event_object_table = 'offer_discount_group_xref' AND trigger_schema = 'boshbaplweb';--0
-- Optionally filter by schema


-- For constraint check.

select * FROM
    information_schema.constraint_table_usage t1
             where table_name in ('offer_discount_group_xref')
;
-- +-------------+------------+-------------------------+------------------+-----------------+------------------------------+
-- |table_catalog|table_schema|table_name               |constraint_catalog|constraint_schema|constraint_name               |
-- +-------------+------------+-------------------------+------------------+-----------------+------------------------------+
-- |BOSH         |boshbaplweb |offer_discount_group_xref|BOSH              |boshbaplweb      |offer_discount_group_xref_pkey|
-- +-------------+------------+-------------------------+------------------+-----------------+------------------------------+