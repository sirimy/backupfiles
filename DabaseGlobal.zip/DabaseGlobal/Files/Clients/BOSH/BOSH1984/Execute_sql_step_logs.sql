[2025-12-01 10:25:56] Connected to BOSH
BOSH: boshbaplweb, public> select COUNT(*) from offer_item_tbl
[2025-12-01 10:26:34] 1 row retrieved starting from 1 in 37 s 103 ms (execution: 37 s 84 ms, fetching: 19 ms)
BOSH: boshbaplweb, public> select COUNT(*) from offer_tbl
[2025-12-01 10:26:55] 1 row retrieved starting from 1 in 8 s 774 ms (execution: 8 s 754 ms, fetching: 20 ms)
BOSH: boshbaplweb, public> select date_part('year', offer_start_utc_ts), count(*)
                           from offer_tbl
                           group by date_part('year', offer_start_utc_ts)
                           order by 1
[2025-12-01 10:27:11] 11 rows retrieved starting from 1 in 5 s 962 ms (execution: 5 s 754 ms, fetching: 208 ms)
BOSH: boshbaplweb, public> SELECT indexname, indexdef FROM pg_indexes
                           WHERE tablename = 'offer_tbl' AND schemaname = 'boshbaplweb'
[2025-12-01 10:27:23] 6 rows retrieved starting from 1 in 416 ms (execution: 197 ms, fetching: 219 ms)
BOSH: boshbaplweb, public> SELECT indexname, indexdef FROM pg_indexes
                           WHERE tablename = 'offer_item_tbl'
                           AND schemaname = 'boshbaplweb'
[2025-12-01 10:27:33] 6 rows retrieved starting from 1 in 211 ms (execution: 194 ms, fetching: 17 ms)
BOSH: boshbaplweb, public> SELECT trigger_name, event_manipulation AS event, action_timing AS timing, action_statement AS definition
                           FROM information_schema.triggers WHERE event_object_table = 'offer_tbl' AND trigger_schema = 'boshbaplweb'
[2025-12-01 10:27:45] 0 rows retrieved in 415 ms (execution: 207 ms, fetching: 208 ms)
BOSH: boshbaplweb, public> SELECT trigger_name, event_manipulation AS event, action_timing AS timing, action_statement AS definition
                           FROM information_schema.triggers WHERE event_object_table = 'offer_item_tbl' AND trigger_schema = 'boshbaplweb'
[2025-12-01 10:27:54] 0 rows retrieved in 226 ms (execution: 203 ms, fetching: 23 ms)
BOSH: boshbaplweb, public> select * FROM
                               information_schema.constraint_table_usage t1
                                        where table_name in ('offer_tbl','offer_item_tbl')
[2025-12-01 10:28:02] 3 rows retrieved starting from 1 in 411 ms (execution: 197 ms, fetching: 214 ms)
BOSH: boshbaplweb, public> select date_part('year', ot.offer_start_utc_ts), count(*)
                           from offer_item_tbl oit
                               join offer_tbl ot on ot.offer_id = oit.offer_id
                           group by date_part('year', offer_start_utc_ts)
                           order by 1
[2025-12-01 10:39:54] 11 rows retrieved starting from 1 in 2 m 57 s 913 ms (execution: 2 m 57 s 690 ms, fetching: 223 ms)
[2025-12-02 13:26:09] Connected to BOSH
BOSH: boshbaplweb, public> set search_path = "boshbaplweb", "public"
[2025-12-02 13:26:10] completed in 193 ms
BOSH: boshbaplweb, public> select COUNT(*) from offer_item_tbl
[2025-12-02 13:26:47] 1 row retrieved starting from 1 in 36 s 796 ms (execution: 36 s 773 ms, fetching: 23 ms)
BOSH: boshbaplweb, public> select COUNT(*) from offer_tbl
[2025-12-02 13:30:34] 1 row retrieved starting from 1 in 8 s 871 ms (execution: 8 s 855 ms, fetching: 16 ms)
BOSH: boshbaplweb, public> select date_part('year', offer_start_utc_ts), count(*)
                           from offer_tbl
                           group by date_part('year', offer_start_utc_ts)
                           order by 1
[2025-12-02 13:30:51] 11 rows retrieved starting from 1 in 5 s 298 ms (execution: 5 s 93 ms, fetching: 205 ms)
BOSH: boshbaplweb, public> select date_part('year', ot.offer_start_utc_ts), count(*)
                           from offer_item_tbl oit
                               join offer_tbl ot on ot.offer_id = oit.offer_id
                           group by date_part('year', offer_start_utc_ts)
                           order by 1
[2025-12-02 13:39:13] 11 rows retrieved starting from 1 in 8 m 2 s 333 ms (execution: 8 m 2 s 74 ms, fetching: 259 ms)
BOSH: boshbaplweb, public> SELECT indexname, indexdef FROM pg_indexes
                           WHERE tablename = 'offer_tbl' AND schemaname = 'boshbaplweb'
[2025-12-02 13:39:58] 6 rows retrieved starting from 1 in 428 ms (execution: 208 ms, fetching: 220 ms)
[2025-12-02 14:05:52] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> CREATE TABLE offer_tbl_new AS
                           SELECT * FROM offer_tbl Where offer_start_utc_ts > '2024-11-01 00:00:00.306889'
[2025-12-02 14:14:04] 2,814,216 rows affected in 6 m 1 s 135 ms
BOSH: boshbaplweb, public> CREATE TABLE offer_item_tbl_new AS
                           SELECT * FROM offer_item_tbl
                              WHERE offer_id IN
                                  ( SELECT ot.offer_id FROM offer_tbl_new ot)
[2025-12-02 14:41:34] 11,180,416 rows affected in 25 m 52 s 377 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 14:41:53] completed in 2 s 395 ms
[2025-12-02 14:42:00] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> ANALYZE offer_tbl_new
[2025-12-02 14:44:03] completed in 809 ms
BOSH: boshbaplweb, public> ANALYZE offer_item_tbl_new
[2025-12-02 14:59:36] completed in 15 m 29 s 208 ms
[2025-12-02 14:59:40] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:00:07] completed in 194 ms
BOSH: boshbaplweb, public> alter table offer_tbl drop constraint offer_tbl_pkey
[2025-12-02 15:00:56] completed in 435 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:01:04] completed in 2 s 39 ms
BOSH: boshbaplweb, public> alter table offer_tbl drop constraint uniq_cons_new_offer_id
[2025-12-02 15:01:10] [25P02] ERROR: current transaction is aborted, commands ignored until end of transaction block
[2025-12-02 15:01:10] [3B001] ERROR: savepoint "jdbc_savepoint_8" does not exist
[2025-12-02 15:01:14] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl drop constraint uniq_cons_new_offer_id
[2025-12-02 15:01:25] completed in 206 ms
[2025-12-02 15:01:31] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl drop constraint fk_cust_offer
[2025-12-02 15:05:26] Cancelling…
[2025-12-02 15:05:27] [57014] ERROR: canceling statement due to user request
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:05:38] completed in 194 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:05:42] completed in 204 ms
[2025-12-02 15:05:44] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> drop index idx_offer_tbl_exp_utc_ts
[2025-12-02 15:07:57] completed in 1 s 848 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:08:16] completed in 256 ms
[2025-12-02 15:08:19] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> drop index idx_offer_tbl_start_utc_ts
[2025-12-02 15:08:46] completed in 192 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:08:51] completed in 382 ms
[2025-12-02 15:08:55] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> drop index off_new_offer_id
[2025-12-02 15:09:02] completed in 195 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:09:11] completed in 1 s 787 ms
[2025-12-02 15:09:14] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:16:12] completed in 194 ms
BOSH: boshbaplweb, public> alter table offer_tbl drop constraint fk_cust_offer
[2025-12-02 15:21:25] Cancelling…
[2025-12-02 15:21:26] [57014] ERROR: canceling statement due to user request
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 15:33:26] completed in 2 s 967 ms
[2025-12-02 15:33:30] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl drop constraint fk_cust_offer
[2025-12-02 15:38:21] Cancelling…
[2025-12-02 15:38:22] [57014] ERROR: canceling statement due to user request
[2025-12-02 15:38:33] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl drop constraint fk_cust_offer
[2025-12-02 16:10:01] completed in 45 s 566 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:10:18] completed in 220 ms
[2025-12-02 16:10:26] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> drop index idx_cust_offer
[2025-12-02 16:10:31] completed in 204 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:10:35] completed in 245 ms
[2025-12-02 16:10:38] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:12:13] completed in 203 ms
[2025-12-02 16:12:15] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl rename to offer_tbl_arch
[2025-12-02 16:12:20] completed in 204 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:12:24] completed in 239 ms
[2025-12-02 16:12:26] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl_new rename to offer_tbl
[2025-12-02 16:12:31] completed in 210 ms
[2025-12-02 16:12:36] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:12:41] completed in 204 ms
[2025-12-02 16:12:42] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl
                           add constraint offer_tbl_pkey primary key (offer_id)
[2025-12-02 16:14:25] completed in 1 m 10 s 668 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:14:37] completed in 237 ms
[2025-12-02 16:14:46] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl
                           add constraint uniq_cons_new_offer_id unique (new_offer_id)
[2025-12-02 16:16:21] completed in 1 m 11 s 10 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:16:22] completed in 213 ms
[2025-12-02 16:16:27] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> ALTER TABLE offer_tbl
                           ADD CONSTRAINT chk_ot__display_seq_num
                           CHECK ((display_seq_num IS NOT NULL)
                           		AND ((display_seq_num)::text <> ''::text))
[2025-12-02 16:17:26] completed in 1 s 656 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:17:27] completed in 307 ms
[2025-12-02 16:17:31] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> CREATE INDEX off_new_offer_id ON boshbaplweb.offer_tbl
                           USING btree (new_offer_id)
[2025-12-02 16:19:00] completed in 1 m 15 s 984 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:19:02] completed in 205 ms
[2025-12-02 16:19:06] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> CREATE INDEX idx_cust_offer ON boshbaplweb.offer_tbl
                           USING btree (customer_id)
[2025-12-02 16:20:09] completed in 47 s 58 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:20:10] completed in 253 ms
[2025-12-02 16:20:15] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_item_tbl drop constraint offer_item_tbl_pkey
[2025-12-02 16:22:18] completed in 206 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:22:20] completed in 698 ms
[2025-12-02 16:22:22] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> drop index idx_bix_ofit
[2025-12-02 16:22:35] completed in 190 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:22:37] completed in 284 ms
BOSH: boshbaplweb, public> drop index idx_oft_ofei
[2025-12-02 16:22:38] completed in 190 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:22:40] completed in 279 ms
BOSH: boshbaplweb, public> drop index idx_prod_dim_offer_item
[2025-12-02 16:22:42] completed in 190 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:22:44] completed in 240 ms
BOSH: boshbaplweb, public> drop index idk_si_ofei
[2025-12-02 16:22:45] completed in 192 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:22:47] completed in 242 ms
BOSH: boshbaplweb, public> drop index idx_policy_ofei
[2025-12-02 16:22:48] completed in 190 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:22:50] completed in 733 ms
[2025-12-02 16:22:54] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_item_tbl rename to offer_item_tbl_arch
[2025-12-02 16:23:14] completed in 192 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:23:16] completed in 216 ms
[2025-12-02 16:23:19] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_item_tbl_new rename to offer_item_tbl
[2025-12-02 16:23:28] completed in 191 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:23:29] completed in 238 ms
[2025-12-02 16:23:32] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_item_tbl
                           add constraint offer_item_tbl_pkey
                           primary key (offer_id, offer_line_id)
[2025-12-02 16:40:11] completed in 15 m 37 s 353 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:40:12] completed in 237 ms
BOSH: boshbaplweb, public> CREATE INDEX idx_policy_ofei ON boshbaplweb.offer_item_tbl
                           USING btree (policy_id)
[2025-12-02 16:44:28] completed in 4 m 14 s 34 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:44:29] completed in 270 ms
BOSH: boshbaplweb, public> CREATE INDEX idx_oft_ofei ON boshbaplweb.offer_item_tbl
                           USING btree (offer_id)
[2025-12-02 16:49:07] completed in 4 m 36 s 218 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:49:08] completed in 209 ms
BOSH: boshbaplweb, public> CREATE INDEX idk_si_ofei ON boshbaplweb.offer_item_tbl
                           USING btree (serialized_item_id)
[2025-12-02 16:51:44] completed in 2 m 34 s 365 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 16:51:46] completed in 212 ms
[2025-12-02 16:53:58] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> select COUNT(*) from offer_discount_group_xref where offer_id in ( select ot.offer_id from offer_tbl ot)
[2025-12-02 16:57:30] 1 row retrieved starting from 1 in 316 ms (execution: 303 ms, fetching: 13 ms)
BOSH: boshbaplweb, public> CREATE TABLE offer_discount_group_xref_arch AS
                           SELECT * from offer_discount_group_xref where offer_id not in ( select ot.offer_id from offer_tbl ot)
[2025-12-02 17:00:38] Cancelling…
[2025-12-02 17:00:40] [57014] ERROR: canceling statement due to user request
BOSH: boshbaplweb, public> CREATE TABLE offer_discount_group_xref_arch AS
                           SELECT * from offer_discount_group_xref
[2025-12-02 17:01:50] 11,874 rows affected in 303 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:02:06] completed in 277 ms
[2025-12-02 17:02:09] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> select COUNT(*) from offer_discount_group_xref_arch where offer_id   in ( select ot.offer_id from offer_tbl ot)
[2025-12-02 17:02:46] 1 row retrieved starting from 1 in 247 ms (execution: 221 ms, fetching: 26 ms)
BOSH: boshbaplweb, public> delete from offer_discount_group_xref_arch where offer_id   in ( select ot.offer_id from offer_tbl ot)
[2025-12-02 17:03:03] 176 rows affected in 246 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:03:08] completed in 218 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:03:20] completed in 204 ms
[2025-12-02 17:03:23] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> select COUNT(*) from offer_discount_group_xref where offer_id not in ( select ot.offer_id from offer_tbl ot)
[2025-12-02 17:03:54] Cancelling…
[2025-12-02 17:03:59] [57014] ERROR: canceling statement due to user request
[2025-12-02 17:03:59] An I/O error occurred while sending to the backend.
[2025-12-02 17:04:09] Connected to BOSH
BOSH: boshbaplweb, public> set search_path = "boshbaplweb", "public"
[2025-12-02 17:04:09] completed in 191 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:04:10] completed in 212 ms
BOSH: boshbaplweb, public> select COUNT(*) from offer_discount_group_xref where offer_id in ( select ot.offer_id from offer_discount_group_xref_arch ot)
[2025-12-02 17:04:26] 1 row retrieved starting from 1 in 312 ms (execution: 214 ms, fetching: 98 ms)
BOSH: boshbaplweb, public> delete from offer_discount_group_xref where offer_id in ( select ot.offer_id from offer_discount_group_xref_arch ot)
[2025-12-02 17:05:04] 11,698 rows affected in 206 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:05:06] completed in 217 ms
[2025-12-02 17:05:09] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> select COUNT(*) from offer_discount_group_xref
                           UNION ALL
                           select COUNT(*) from offer_discount_group_xref_arch
[2025-12-02 17:05:38] 2 rows retrieved starting from 1 in 219 ms (execution: 191 ms, fetching: 28 ms)
[2025-12-02 17:06:58] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> alter table offer_tbl
                           add constraint fk_cust_offer
                               foreign key (customer_id) references customer_tbl
[2025-12-02 17:07:10] completed in 3 s 617 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:07:11] completed in 223 ms
[2025-12-02 17:07:16] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> SELECT quickreg_code
                               FROM (
                                       select q.quickreg_code as quickreg_code from quickreg_realTime q
                                       except
                                       select ot.new_offer_id as quickreg_code from offer_tbl ot where ot.new_offer_id is not null
                                        except
                                       select ot.new_offer_id as quickreg_code from offer_tbl_arch ot where ot.new_offer_id is not null
                                    ) t
                               order by random()
                               limit 1
[2025-12-02 17:32:41] 1 row retrieved starting from 1 in 5 s 147 ms (execution: 5 s 134 ms, fetching: 13 ms)
BOSH: boshbaplweb, public> CREATE INDEX off_offer_id_arch ON boshbaplweb.offer_tbl_arch
                           USING btree (offer_id)
[2025-12-02 17:41:33] completed in 5 m 6 s 76 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:41:35] completed in 224 ms
BOSH: boshbaplweb, public> CREATE INDEX off_new_offer_id_arch ON boshbaplweb.offer_tbl_arch
                           USING btree (new_offer_id)
[2025-12-02 17:44:00] [25P02] ERROR: current transaction is aborted, commands ignored until end of transaction block
[2025-12-02 17:44:00] [3B001] ERROR: savepoint "jdbc_savepoint_5" does not exist
[2025-12-02 17:44:04] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:44:11] completed in 191 ms
BOSH: boshbaplweb, public> CREATE INDEX off_new_offer_id_arch ON boshbaplweb.offer_tbl_arch
                           USING btree (new_offer_id)
[2025-12-02 17:49:33] completed in 5 m 16 s 224 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 17:49:35] completed in 261 ms
[2025-12-02 17:50:11] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> CREATE INDEX idx_oft_ofei_arch ON boshbaplweb.offer_item_tbl_arch
                           USING btree (offer_id)
[2025-12-02 18:15:43] completed in 25 m 26 s 408 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 18:15:45] completed in 208 ms
BOSH: boshbaplweb, public> CREATE INDEX idk_si_ofei_arch ON boshbaplweb.offer_item_tbl_arch
                           USING btree (serialized_item_id)
[2025-12-02 18:17:23] [25P02] ERROR: current transaction is aborted, commands ignored until end of transaction block
[2025-12-02 18:17:23] [3B001] ERROR: savepoint "jdbc_savepoint_9" does not exist
[2025-12-02 18:17:26] transaction committed: @console_127 [BOSH-WEb-PROD]
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 18:17:34] completed in 454 ms
BOSH: boshbaplweb, public> CREATE INDEX idk_si_ofei_arch ON boshbaplweb.offer_item_tbl_arch
                           USING btree (serialized_item_id)
[2025-12-02 18:36:34] completed in 18 m 45 s 922 ms
BOSH: boshbaplweb, public> COMMIT
[2025-12-02 18:36:51] completed in 281 ms
