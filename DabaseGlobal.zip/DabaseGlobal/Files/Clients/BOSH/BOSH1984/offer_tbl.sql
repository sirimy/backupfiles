-- Improve the time DB function is taking to return
-- Steps are below

-- 1. New tables create

CREATE TABLE offer_tbl_new AS
SELECT * FROM offer_tbl Where offer_start_utc_ts > '2024-11-01 00:00:00.306889';

CREATE TABLE offer_item_tbl_new AS
SELECT * FROM offer_item_tbl
   WHERE offer_id IN
       ( SELECT ot.offer_id FROM offer_tbl_new ot);

--
-- 2. ANALYZE commands

ANALYZE offer_tbl_new;
ANALYZE offer_item_tbl_new;
--
-- 3. We drop all index and constraint for  offer_tbl

alter table offer_tbl drop constraint offer_tbl_pkey;
alter table offer_tbl drop constraint uniq_cons_new_offer_id;
alter table offer_tbl drop constraint fk_cust_offer;

drop index offer_tbl_pkey;
drop index uniq_cons_new_offer_id;
drop index idx_cust_offer;
drop index idx_offer_tbl_exp_utc_ts;
drop index idx_offer_tbl_start_utc_ts;
drop index off_new_offer_id;

-- 4. Rename Tables

alter table offer_tbl rename to offer_tbl_arch;

alter table offer_tbl_new rename to offer_tbl;


-- 5. For offer_tbl  new table adding index and constraint

alter table offer_tbl
add constraint offer_tbl_pkey primary key (offer_id);

alter table offer_tbl
add constraint uniq_cons_new_offer_id unique (new_offer_id);

alter table offer_tbl
add constraint fk_cust_offer
    foreign key (customer_id) references customer_tbl;

ALTER TABLE offer_tbl
ADD CONSTRAINT chk_ot__display_seq_num
CHECK ((display_seq_num IS NOT NULL)
		AND ((display_seq_num)::text <> ''::text));

CREATE INDEX off_new_offer_id ON boshbaplweb.offer_tbl
USING btree (new_offer_id);


CREATE INDEX idx_cust_offer ON boshbaplweb.offer_tbl
USING btree (customer_id);
--
-- 6. We drop all index and constraint for  offer_item_tbl

alter table offer_item_tbl drop constraint offer_item_tbl_pkey;

drop index idx_bix_ofit;
drop index idx_oft_ofei;
drop index idx_prod_dim_offer_item;
drop index idk_si_ofei;
drop index idx_policy_ofei;

-- 7. Rename Table   offer_item_tbl

alter table offer_item_tbl rename to offer_item_tbl_arch;

alter table offer_item_tbl_new rename to offer_item_tbl;

-- 8. For offer_item_tbl  new table adding index and constraint

alter table offer_item_tbl
add constraint offer_item_tbl_pkey
primary key (offer_id, offer_line_id);




CREATE INDEX idx_policy_ofei ON boshbaplweb.offer_item_tbl
USING btree (policy_id);

CREATE INDEX idx_oft_ofei ON boshbaplweb.offer_item_tbl
USING btree (offer_id) ;



CREATE INDEX idk_si_ofei ON boshbaplweb.offer_item_tbl
USING btree (serialized_item_id);


-- 9. QC sql

select COUNT(*) from offer_item_tbl;--
select COUNT(*) from offer_tbl;--

select date_part('year', offer_start_utc_ts), count(*)
from offer_tbl
group by date_part('year', offer_start_utc_ts)
order by 1;


select date_part('year', ot.offer_start_utc_ts), count(*)
from offer_item_tbl oit
    join offer_tbl ot on ot.offer_id = oit.offer_id
group by date_part('year', offer_start_utc_ts)
order by 1;

-- For Index check.

SELECT indexname, indexdef FROM pg_indexes
WHERE tablename = 'offer_tbl' AND schemaname = 'boshbaplweb'; --


SELECT indexname, indexdef FROM pg_indexes
WHERE tablename = 'offer_item_tbl'
AND schemaname = 'boshbaplweb'; --

-- For trigger check.

SELECT trigger_name, event_manipulation AS event, action_timing AS timing, action_statement AS definition
FROM information_schema.triggers WHERE event_object_table = 'offer_tbl' AND trigger_schema = 'boshbaplweb'; -- Optionally filter by schema

SELECT trigger_name, event_manipulation AS event, action_timing AS timing, action_statement AS definition
FROM information_schema.triggers WHERE event_object_table = 'offer_item_tbl' AND trigger_schema = 'boshbaplweb';
-- Optionally filter by schema


-- For constraint check.

select * FROM
    information_schema.constraint_table_usage t1
             where table_name in ('offer_tbl','offer_item_tbl')
;


-- Constraint and keys we can check by table tree expand view.
-- It list all keys and constraint and indexes.
-- Screen shot of original table listed below




--
-- New changes after process complete

--New table we add here offer_tbl_arch in routine fn_real_time_offer_bundled
 SELECT quickreg_code
    FROM (
            select q.quickreg_code as quickreg_code from quickreg_realTime q
            except
            select ot.new_offer_id as quickreg_code from offer_tbl ot where ot.new_offer_id is not null
            except
            select ot.new_offer_id as quickreg_code from offer_tbl_arch ot where ot.new_offer_id is not null

         ) t
    order by random()
    limit 1;


-- we will create archive data and we will use offer id
select COUNT(*) from offer_discount_group_xref
where offer_id in ( select ot.offer_id from offer_tbl ot);



