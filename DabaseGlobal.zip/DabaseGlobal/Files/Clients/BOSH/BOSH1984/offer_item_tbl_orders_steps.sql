create table offer_item_tbl_orders as
-- select count(*) from offer_item_tbl_arch where offer_id in (select oi.offer_id from order_item_tbl oi);  --498405
select * from offer_item_tbl_arch where offer_id in (select oi.offer_id from order_item_tbl oi);
commit;
alter table offer_item_tbl_orders owner to boshbaplweb;
analyse offer_item_tbl_orders;
CREATE INDEX offer_item_tbl_orders_offer_id ON boshbaplweb.offer_item_tbl_orders
USING btree (offer_id);
commit;


create table offer_tbl_orders as
-- select count(*) from offer_tbl_arch where offer_id in (select oi.offer_id from offer_item_tbl_orders oi);  127763
select * from offer_tbl_arch where offer_id in (select oi.offer_id from offer_item_tbl_orders oi);
commit;
alter table offer_tbl_orders owner to boshbaplweb;
commit;
analyse offer_tbl_orders;
CREATE INDEX offer_tbl_orders_offer_id ON boshbaplweb.offer_tbl_orders
USING btree (offer_id);
commit;



select COUNT(*) from offer_tbl_orders where offer_id in ( select t1.offer_id from offer_tbl t1);--23466
select COUNT(*) from offer_item_tbl_orders where offer_id in ( select t1.offer_id from offer_tbl t1);--98515



delete from offer_item_tbl_orders where offer_id in ( select t1.offer_id from offer_tbl t1);--98515
delete from offer_tbl_orders where offer_id in ( select t1.offer_id from offer_tbl t1);--23466


insert into offer_tbl
select * from offer_tbl_orders ;
COMMIT;
;



Insert into offer_item_tbl
select * from offer_item_tbl_orders ;
COMMIT;