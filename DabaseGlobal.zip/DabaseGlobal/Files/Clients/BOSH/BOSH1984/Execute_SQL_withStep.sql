-- 9. QC sql

select COUNT(*) from offer_item_tbl;-- 55619114

select COUNT(*) from offer_tbl;--14557567

select date_part('year', offer_start_utc_ts), count(*)
from offer_tbl
group by date_part('year', offer_start_utc_ts)
order by 1;
-- +---------+-------+
-- |date_part|count  |
-- +---------+-------+
-- |2016     |363271 |
-- |2017     |596433 |
-- |2018     |1037415|
-- |2019     |1159567|
-- |2020     |1608959|
-- |2021     |1906348|
-- |2022     |1569592|
-- |2023     |1916110|
-- |2024     |2096656|
-- |2025     |2226921|
-- |2026     |76295  |
-- +---------+-------+

select date_part('year', ot.offer_start_utc_ts), count(*)
from offer_item_tbl oit
    join offer_tbl ot on ot.offer_id = oit.offer_id
group by date_part('year', offer_start_utc_ts)
order by 1;
-- +---------+-------+
-- |date_part|count  |
-- +---------+-------+
-- |2016     |1336839|
-- |2017     |2178377|
-- |2018     |3544832|
-- |2019     |3768678|
-- |2020     |5182151|
-- |2021     |7539769|
-- |2022     |6333150|
-- |2023     |7568610|
-- |2024     |8631664|
-- |2025     |8946123|
-- |2026     |193556 |
-- +---------+-------+


-- For Index check.

SELECT indexname, indexdef FROM pg_indexes
WHERE tablename = 'offer_tbl' AND schemaname = 'boshbaplweb'; --
-- +--------------------------+-------------------------------------------------------------------------------------------------+
-- |indexname                 |indexdef                                                                                         |
-- +--------------------------+-------------------------------------------------------------------------------------------------+
-- |uniq_cons_new_offer_id    |CREATE UNIQUE INDEX uniq_cons_new_offer_id ON boshbaplweb.offer_tbl USING btree (new_offer_id)   |
-- |off_new_offer_id          |CREATE INDEX off_new_offer_id ON boshbaplweb.offer_tbl USING btree (new_offer_id)                |
-- |idx_offer_tbl_start_utc_ts|CREATE INDEX idx_offer_tbl_start_utc_ts ON boshbaplweb.offer_tbl USING btree (offer_start_utc_ts)|
-- |idx_offer_tbl_exp_utc_ts  |CREATE INDEX idx_offer_tbl_exp_utc_ts ON boshbaplweb.offer_tbl USING btree (offer_exp_utc_ts)    |
-- |idx_cust_offer            |CREATE INDEX idx_cust_offer ON boshbaplweb.offer_tbl USING btree (customer_id)                   |
-- |offer_tbl_pkey            |CREATE UNIQUE INDEX offer_tbl_pkey ON boshbaplweb.offer_tbl USING btree (offer_id)               |
-- +--------------------------+-------------------------------------------------------------------------------------------------+


SELECT indexname, indexdef FROM pg_indexes
WHERE tablename = 'offer_item_tbl'
AND schemaname = 'boshbaplweb'; --
-- +-----------------------+-----------------------------------------------------------------------------------------------------------+
-- |indexname              |indexdef                                                                                                   |
-- +-----------------------+-----------------------------------------------------------------------------------------------------------+
-- |idx_prod_dim_offer_item|CREATE INDEX idx_prod_dim_offer_item ON boshbaplweb.offer_item_tbl USING btree (product_id)                |
-- |idx_policy_ofei        |CREATE INDEX idx_policy_ofei ON boshbaplweb.offer_item_tbl USING btree (policy_id)                         |
-- |idx_oft_ofei           |CREATE INDEX idx_oft_ofei ON boshbaplweb.offer_item_tbl USING btree (offer_id)                             |
-- |idx_bix_ofit           |CREATE INDEX idx_bix_ofit ON boshbaplweb.offer_item_tbl USING btree (bundle_id)                            |
-- |idk_si_ofei            |CREATE INDEX idk_si_ofei ON boshbaplweb.offer_item_tbl USING btree (serialized_item_id)                    |
-- |offer_item_tbl_pkey    |CREATE UNIQUE INDEX offer_item_tbl_pkey ON boshbaplweb.offer_item_tbl USING btree (offer_id, offer_line_id)|
-- +-----------------------+-----------------------------------------------------------------------------------------------------------+

-- For trigger check.

SELECT trigger_name, event_manipulation AS event, action_timing AS timing, action_statement AS definition
FROM information_schema.triggers WHERE event_object_table = 'offer_tbl' AND trigger_schema = 'boshbaplweb'; -- 0

SELECT trigger_name, event_manipulation AS event, action_timing AS timing, action_statement AS definition
FROM information_schema.triggers WHERE event_object_table = 'offer_item_tbl' AND trigger_schema = 'boshbaplweb';--0
-- Optionally filter by schema


-- For constraint check.

select * FROM
    information_schema.constraint_table_usage t1
             where table_name in ('offer_tbl','offer_item_tbl')
;
-- +-------------+------------+--------------+------------------+-----------------+----------------------+
-- |table_catalog|table_schema|table_name    |constraint_catalog|constraint_schema|constraint_name       |
-- +-------------+------------+--------------+------------------+-----------------+----------------------+
-- |BOSH         |boshbaplweb |offer_item_tbl|BOSH              |boshbaplweb      |offer_item_tbl_pkey   |
-- |BOSH         |boshbaplweb |offer_tbl     |BOSH              |boshbaplweb      |offer_tbl_pkey        |
-- |BOSH         |boshbaplweb |offer_tbl     |BOSH              |boshbaplweb      |uniq_cons_new_offer_id|
-- +-------------+------------+--------------+------------------+-----------------+----------------------+

CREATE TABLE offer_tbl_new AS
SELECT * FROM offer_tbl Where offer_start_utc_ts > '2024-11-01 00:00:00.306889';
-- [2025-12-02 14:14:04] 2,814,216 rows affected in 6 m 1 s 135 ms

CREATE TABLE offer_item_tbl_new AS
SELECT * FROM offer_item_tbl
   WHERE offer_id IN
       ( SELECT ot.offer_id FROM offer_tbl_new ot);
-- [2025-12-02 14:41:34] 11,180,416 rows affected in 25 m 52 s 377 ms

COMMIT;

ANALYZE offer_tbl_new;
COMMIT;
ANALYZE offer_item_tbl_new;
--[2025-12-02 14:59:36] completed in 15 m 29 s 208 ms
COMMIT;

alter table offer_tbl drop constraint offer_tbl_pkey;
alter table offer_tbl drop constraint uniq_cons_new_offer_id;
alter table offer_tbl drop constraint fk_cust_offer;
COMMIT;
drop index offer_tbl_pkey;
drop index uniq_cons_new_offer_id;
drop index idx_cust_offer;
drop index idx_offer_tbl_exp_utc_ts;
COMMIT;
drop index idx_offer_tbl_start_utc_ts;
COMMIT;
drop index off_new_offer_id;
COMMIT;


alter table offer_tbl rename to offer_tbl_arch;

alter table offer_tbl_new rename to offer_tbl;


-- 5. For offer_tbl  new table adding index and constraint

alter table offer_tbl
add constraint offer_tbl_pkey primary key (offer_id);
COMMIT;

alter table offer_tbl
add constraint uniq_cons_new_offer_id unique (new_offer_id);
COMMIT;

alter table offer_tbl
add constraint fk_cust_offer
    foreign key (customer_id) references customer_tbl;
COMMIT;

ALTER TABLE offer_tbl
ADD CONSTRAINT chk_ot__display_seq_num
CHECK ((display_seq_num IS NOT NULL)
		AND ((display_seq_num)::text <> ''::text));
COMMIT;

CREATE INDEX off_new_offer_id ON boshbaplweb.offer_tbl
USING btree (new_offer_id);
COMMIT;


CREATE INDEX idx_cust_offer ON boshbaplweb.offer_tbl
USING btree (customer_id);
COMMIT;



alter table offer_item_tbl drop constraint offer_item_tbl_pkey;
COMMIT;

drop index idx_bix_ofit;
COMMIT;

drop index idx_oft_ofei;
COMMIT;

drop index idx_prod_dim_offer_item;
COMMIT;

drop index idk_si_ofei;
COMMIT;

drop index idx_policy_ofei;
COMMIT;
-- 7. Rename Table   offer_item_tbl

alter table offer_item_tbl rename to offer_item_tbl_arch;
COMMIT;

alter table offer_item_tbl_new rename to offer_item_tbl;
COMMIT;



-- 8. For offer_item_tbl  new table adding index and constraint

alter table offer_item_tbl
add constraint offer_item_tbl_pkey
primary key (offer_id, offer_line_id);
COMMIT;

CREATE INDEX idx_policy_ofei ON boshbaplweb.offer_item_tbl
USING btree (policy_id);
COMMIT;

CREATE INDEX idx_oft_ofei ON boshbaplweb.offer_item_tbl
USING btree (offer_id) ;
COMMIT;


CREATE INDEX idk_si_ofei ON boshbaplweb.offer_item_tbl
USING btree (serialized_item_id);
COMMIT;


------------------offer_discount_group_xref---------------------------------

select COUNT(*) from offer_discount_group_xref where offer_id in ( select ot.offer_id from offer_tbl ot);--176

CREATE TABLE offer_discount_group_xref_arch AS
SELECT * from offer_discount_group_xref ;
--[2025-12-02 17:01:50] 11,874 rows affected in 303 ms
COMMIT;

--delete from offer_discount_group_xref_arch where offer_id   in ( select ot.offer_id from offer_tbl ot);--176
COMMIT;

select COUNT(*) from offer_discount_group_xref where offer_id in ( select ot.offer_id from offer_discount_group_xref_arch ot);--11698

delete from offer_discount_group_xref where offer_id in ( select ot.offer_id from offer_discount_group_xref_arch ot);--11698
COMMIT;

select COUNT(*) from offer_discount_group_xref
UNION ALL
select COUNT(*) from offer_discount_group_xref_arch;
-- +-----+
-- |count|
-- +-----+
-- |176  |
-- |11698|
-- +-----+

 SELECT quickreg_code
    FROM (
            select q.quickreg_code as quickreg_code from quickreg_realTime q
            except
            select ot.new_offer_id as quickreg_code from offer_tbl ot where ot.new_offer_id is not null
             except
            select ot.new_offer_id as quickreg_code from offer_tbl_arch ot where ot.new_offer_id is not null
         ) t
    order by random()
    limit 1;--BJD27GW


CREATE INDEX idx_oft_ofei_arch ON boshbaplweb.offer_item_tbl_arch
USING btree (offer_id) ;
COMMIT;--done


CREATE INDEX idk_si_ofei_arch ON boshbaplweb.offer_item_tbl_arch
USING btree (serialized_item_id);
COMMIT;


CREATE INDEX off_new_offer_id_arch ON boshbaplweb.offer_tbl_arch
USING btree (new_offer_id);----done
COMMIT;


CREATE INDEX off_offer_id_arch ON boshbaplweb.offer_tbl_arch
USING btree (offer_id);--done
COMMIT;


ANALYZE offer_tbl;
ANALYZE offer_item_tbl;


ANALYZE offer_tbl_arch;
ANALYZE offer_item_tbl_arch;