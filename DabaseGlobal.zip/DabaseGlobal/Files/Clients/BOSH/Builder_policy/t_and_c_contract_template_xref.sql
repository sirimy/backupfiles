 DECLARE
              --4/14/2016 AJ
              v_audit_key NUMBER;
          BEGIN
              v_audit_key := get_audit_key (p_program_nm => 'POLICY', p_author_nm  => 'ajain', p_process_nm => 'POLICY Data Creation', p_descriptive_tx => 'POLICY T and C xref data Creation', p_table_nm => 'T_AND_C_CONTRACT_TEMPLATE_XREF');

             delete from T_AND_C_CONTRACT_TEMPLATE_XREF;
             commit;


             --------------------------------------------------------------------------------
             --Creating t_and_c_contract_template_xref data for...
             --------------------------------------------------------------------------------
             insert
               into t_and_c_contract_template_xref (

                    CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY,
                    EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY, TC_CONT_TEMP_XREF_KEY,
                    COUNTRY_KEY, SEQ_NO
                    )
             select CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY,
                  EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY,
                  p_t_and_c_xref_seq.nextval as TC_CONT_TEMP_XREF_KEY,
                  COUNTRY_KEY, SEQ_NO
             from (
                   select
                          CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, psd.POSTAL_STATE_KEY,
                          pol.EFFECTIVE_DT, pol.Exp_Dt AS END_DT, 'Y' AS ACTIVE_IND, NULL AS CHANNEL_PARTNER_KEY
                          , ct.COUNTRY_KEY
                          , ROW_NUMBER() OVER( PARTITION BY CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, pol.EFFECTIVE_DT
                                ORDER BY postal_state_key) as SEQ_NO
                     from
                            (select *
                               from
                                    (
                                     select tc.*, row_number() over(partition by tc.name order by tc.effective_dt desc ) as tc_rno
                                       from p_terms_and_conditions_dim tc
                                    ) tc
                              where tc_rno = 1
                            ) tc
                            cross join p_postal_state_dim psd
                            cross join p_contract_template_tbl ctl   --this will be a placeholder only for Bosch
                            join (
                                    select policy_key, pol.name, pex.brand, pol.EFFECTIVE_DT, pol.exp_dt
                                           ,(nvl(day, 0) + (nvl(month, 0) *30) + (nvl(year, 0) * 365))/365 AS Term_Year
                                           ,pex.PRODUCT_CAT_DESC
                                      from policy_tbl pol
                                           join policy_ext_tbl pex using (policy_key)
                                           join p_term_dim tr using (term_key)
                                    ) pol
                                ON UPPER(pol.brand) = UPPER(tc.name)
                            LEFT JOIN p_COUNTRY_TBL ct ON (ct.country_3byte_cd = psd.country_iso)
                    where
                          1=1
                      and pol.exp_dt >= date '2099-12-31'
                      and psd.country_iso IN ('en_US', 'USA')
                      and postal_state_cd NOT IN ('AE', 'AP', 'AA', 'NA', 'PR', 'VI')
                      and (terms_and_conditions_key, policy_key, postal_state_key) NOT IN
                              (select tcx.terms_and_conditions_key, tcx.policy_key, tcx.postal_state_key
                                 from p_t_and_c_xref tcx
                              )
                    order by TERMS_AND_CONDITIONS_KEY, POLICY_KEY
                    );

             COMMIT;

          END;