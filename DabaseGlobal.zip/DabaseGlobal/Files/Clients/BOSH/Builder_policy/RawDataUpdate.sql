DECLARE
              --Clean-up raw pricing data and populate any initial values like policy_key and effective_dt
              v_audit_key NUMBER;

          BEGIN
        v_audit_key := get_audit_key (p_program_nm => 'POLICY', p_author_nm  => 'iahmad', p_process_nm => 'POLICY Data Creation', p_descriptive_tx => 'POLICY raw_pricing_tbl data Creation', p_table_nm => 'raw_pricing_tbl');


               update raw_pricing_tbl
               set    --policy_key = policy_seq.nextval,
                      INSERT_AUDIT_KEY = v_audit_key,
                      effective_dt = date '2022-09-25';


                update raw_pricing_tbl set PRODUCT_CAT_DESC = 'BUILT-IN COFFEE MAKER' where PRODUCT_CAT_DESC = 'Built-In  Coffee Maker';
                update raw_pricing_tbl set PRODUCT_CAT_DESC = 'LAUNDRY-DRYER' where PRODUCT_CAT_DESC = 'Laundry - Dryer';
                update raw_pricing_tbl set PRODUCT_CAT_DESC = 'LAUNDRY-WASHER' where PRODUCT_CAT_DESC = 'Laundry - Washer';
                update raw_pricing_tbl set BRAND = 'Gaggenau' where BRAND = 'Gaggeneau';

               COMMIT;

          END;