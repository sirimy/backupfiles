-- Generate product_price_dim data for BUILDER (BUILDER)
      insert into product_price_dim
         (
         PRICING_SCHEME_KEY
        ,PRODUCT_KEY
        ,BASE_PRICE_AMT
        ,TERM_MONTHS
        ,TERM_DISCOUNT_AMT
        ,GREATEST_SAVINGS_AMT
        ,PREMIUM_AMT
        ,PRICE_BEFORE_DISCOUNT_AMT
        ,PRICE_LOW
        ,PRICE_HIGH
        ,POLICY_KEY
        ,INSERT_AUDIT_KEY
        ,UPDATE_AUDIT_KEY
        ,SYNC_AUDIT_KEY
        ,ACTIVE_IND
        )
        select
             PSD.PRICING_SCHEME_KEY AS PRICING_SCHEME_KEY
            ,PD.PRODUCT_KEY
            ,PFEE.RETAIL_PRICE_AMT  AS BASE_PRICE_AMT
            ,PL.TERM_COVERAGE_EXT   AS TERM_MONTHS
            ,0 TERM_DISCOUNT_AMT
            ,0 GREATEST_SAVINGS_AMT
            ,0 PREMIUM_AMT
            ,PFEE.RETAIL_PRICE_AMT  AS PRICE_BEFORE_DISCOUNT_AMT
            ,'' PRICE_LOW
            ,'' PRICE_HIGH
            ,PL.POLICY_KEY
            ,0            AS INSERT_AUDIT_KEY
            ,'' AS UPDATE_AUDIT_KEY
            ,'' AS SYNC_AUDIT_KEY
            ,'Y'
        from (select policy_key, brand, product_cat_desc, channels from POLICY_EXT_TBL r
              union
              select policy_key, brand, product_cat_desc, channels from p_POLICY_EXT_TBL r
             ) r
             join (select policy_key, policy_product_xid, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, age, tr.month as term_coverage_ext
                     from policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                    where pol.exp_dt > sysdate
                    union
                   select policy_key, policy_product_xid, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, age, tr.month as term_coverage_ext
                     from p_policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                    where pol.exp_dt > sysdate
                   ) pl on (r.policy_key = pl.policy_key)
             ---
             join ( SELECT *
                      FROM v_pricing_scheme_dim psd
                     WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd.PRICING_SCHEME_DESC, 1, 2), psd.load_dt) IN ( select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2), max(psd2.load_dt)
                                             from v_pricing_scheme_dim psd2
                                            WHERE psd2.PRICING_SCHEME_DESC LIKE 'BUILDER%'
                                            group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2)
                                          )
                       AND psd.PRICING_SCHEME_DESC LIKE 'BUILDER%'
                       AND psd.END_DT >= trunc(sysdate)
                   ) psd
             on ( PSD.PRICING_SCHEME_NAME = upper(r.channels))
             ---
             left join (select pfe.policy_key,
                               pfe.policy_fee_value * (1 - pdt.discount_percentage) as retail_price_amt
                          from P_POLICY_FEE_XREF  pfe
                          join P_POLICY_FEE_TYPE  pft
                            on ( PFE.POLICY_FEE_TYPE_KEY = PFT.POLICY_FEE_TYPE_KEY AND PFT.NAME = 'Retail amt')
                          join p_policy_discount_tbl pdt
                            on (pdt.policy_key = pfe.policy_key and pdt.policy_fee_type_key = pfe.policy_fee_type_key
                                and pdt.discount_key = 11 --hard coded for now
                                and trunc(sysdate) between pdt.effective_dt and pdt.end_dt
                                )
                          union all
                          select pfe.policy_key,
                               pfe.policy_fee_value * (1 - pdt.discount_percentage) as retail_price_amt
                          from POLICY_FEE_XREF  pfe
                          join P_POLICY_FEE_TYPE  pft
                            on ( PFE.POLICY_FEE_TYPE_KEY = PFT.POLICY_FEE_TYPE_KEY AND PFT.NAME = 'Retail amt')
                          join policy_discount_tbl pdt
                            on (pdt.policy_key = pfe.policy_key and pdt.policy_fee_type_key = pfe.policy_fee_type_key
                                and pdt.discount_key = 11 --hard coded for now
                                and trunc(sysdate) between pdt.effective_dt and pdt.end_dt
                               )
                   ) pfee
                   on ( pfee.policy_key = pl.policy_key)
             ---
             join p_brand_dim bd on ( CASE WHEN upper(r.brand) IN ('BSUS', 'BOSCH') THEN 'Bosch'
                                           WHEN upper(r.brand) IN ('THUS', 'THERMADOR') THEN 'Thermador'
                                           WHEN upper(r.brand) IN ('GGUS', 'GAGGENAU') THEN 'Gaggenau'
                                           ELSE r.brand
                                      END
                                           = bd.brand_nm)
             join (
                   select pd.product_key,model_no,product_nm, product_dsc, product_category_nm,
                           case when lower(product_category_nm) like 'refrig%' then 'Refrigerator With Food Loss'--'REFRIGERATION W LOSS'
                           when lower(product_category_nm) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                           when lower(product_category_nm) like '%dish%' then 'DISHWASHER'
                           when lower(product_dsc) like '%hood%' or lower(PRODUCT_CATEGORY_nm) like '%venti%'  then 'VENTILATION'
                           when lower(product_category_nm) like 'cooking' then 'COOKING'
                           when lower(product_category_nm) like '%laundry%' and lower(product_dsc) like '%dryer%' then 'LAUNDRY-DRYER'
                           when lower(product_category_nm) like '%laundry%' then 'LAUNDRY-WASHER'
                           else 'other'
                           end as bora_pricing_category,
                           brand_nm, price_amt, brand_key --, sku_no, upc_cd
                    from
                         bosh.v_product pd
                   where
                         NVL(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
                     and PRODUCT_COVERAGE_END_DT >= sysdate
                     and NVL( pd.price_amt, 0 ) <> 0
                 ) pd
                 on (bd.brand_key = pd.brand_key
                     and upper(r.product_cat_desc) = upper(pd.bora_pricing_category)
                     and pd.price_amt between  pl.min_product_price and pl.max_product_price
                    )
              ---
       where (upper(r.channels) LIKE 'BUILDER%')
         AND  (PSD.PRICING_SCHEME_KEY, PD.PRODUCT_KEY, pl.POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM p_product_price_dim
                         UNION ALL
                         SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        )
        ;