--We will create new pricing schemes to support RO terms based upon age

declare
  v_audit_key number;
begin
  v_audit_key := bosh.get_audit_key (p_program_nm => 'Campaign', p_descriptive_tx => 'BOSH-1048: Builder', p_table_nm => 'PRICING_SCHEME_DIM');
  DBMS_OUTPUT.put_line(v_audit_key);
      insert into PRICING_SCHEME_DIM (PRICING_SCHEME_KEY, PRICING_SCHEME_NAME, PRICING_SCHEME_DESC, LOAD_DT, END_DT,INSERT_AUDIT_KEY, PRICING_SCHEME_TYPE)
        values (140, 'BUILDER', 'BUILDER', date '2022-09-26',date '2099-12-31', v_audit_key, 'BUILDER');
--         update PRICING_SCHEME_DIM set PRICING_SCHEME_DIM.SYNC_AUDIT_KEY =   null,UPDATE_AUDIT_KEY =v_audit_key
--         where PRICING_SCHEME_KEY = 140;
  COMMIT;
end;
--569745






select * from PRICING_SCHEME_DIM where PRICING_SCHEME_KEY = 140;
commit;

-- begin
--     P_PK_CORE_UPDATE.INSERT_TBL('PRICING_SCHEME_DIM');
-- end;
