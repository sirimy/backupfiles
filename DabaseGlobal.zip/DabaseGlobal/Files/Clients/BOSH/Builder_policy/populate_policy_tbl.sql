DECLARE
              v_audit_key NUMBER;
          BEGIN
              v_audit_key := get_audit_key (p_program_nm => 'POLICY', p_author_nm  => 'ajain', p_process_nm => 'POLICY Data Creation', p_descriptive_tx => 'POLICY Data Creation', p_table_nm => 'POLICY_TBL');

             DELETE FROM policy_lkp;

             DELETE FROM policy_tbl;

             DELETE FROM policy_ext_tbl;

             DELETE FROM policy_fee_xref;

             DELETE FROM policy_discount_tbl;


             COMMIT;


             INSERT ALL
             INTO policy_lkp (
                  POLICY_XID, SOURCE_SYSTEM_CD, EXT_ID_TYPE_CD, POLICY_KEY, INSERT_AUDIT_KEY )
             VALUES (POLICY_LKP_XID, 0, 2, POLICY_KEY, v_audit_key )
             -------
             INTO policy_tbl
                 (POLICY_KEY, NAME, Description, POLICY_PRODUCT_XID, EFFECTIVE_DT, EXP_DT, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, CURRENCY_CD, POLICY_TYPE_KEY, TERM_KEY,
                  CONTRACT_SALES_CHANNEL_KEY, COVERAGE_TIMING_STRATEGY_KEY, INSERT_AUDIT_KEY, POLICY_GROUP_KEY, DEDUCTIBLE,
                  UNDERWRITER_KEY, NEW_USED_IND, Age)
             VALUES (Policy_key , NAME, Description, POLICY_PRODUCT_XID, EFFECTIVE_DT, EXP_DT, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, CURRENCY_CD, POLICY_TYPE_KEY, TERM_KEY,
                  CONTRACT_SALES_CHANNEL_KEY, COVERAGE_TIMING_STRATEGY_KEY, v_audit_key, POLICY_GROUP_KEY, DEDUCTIBLE,
                  UNDERWRITER_KEY, NEW_USED_IND, age)
             -------
             INTO policy_ext_tbl
                 (Policy_key, brand, PRODUCT_CAT_DESC, Channels, INSERT_AUDIT_KEY)
             VALUES (Policy_key, brand, PRODUCT_CAT_DESC, Channel, v_audit_key)
             -----
             INTO Policy_Fee_xref (POLICY_KEY, POLICY_FEE_TYPE_KEY, POLICY_FEE_VALUE, EFFECTIVE_DT, END_DT, INSERT_AUDIT_KEY)
             VALUES (Policy_key, 1, RETAIL_PRICE_AMT, effective_dt, exp_dt, v_audit_key)
             ----
             --INTO Policy_Fee_xref (POLICY_KEY, POLICY_FEE_TYPE_KEY, POLICY_FEE_VALUE, EFFECTIVE_DT, END_DT)
             --VALUES (Policy_key, 4111, DEALER_COST, effective_dt, exp_dt)
             ----
             INTO Policy_Fee_xref (POLICY_KEY, POLICY_FEE_TYPE_KEY, POLICY_FEE_VALUE, EFFECTIVE_DT, END_DT, INSERT_AUDIT_KEY)
             VALUES (Policy_key, 3, PREMIUM_AMT, effective_dt, exp_dt, v_audit_key)
             ----
             INTO Policy_Discount_Tbl (POLICY_KEY, POLICY_FEE_TYPE_KEY, DISCOUNT_KEY, EFFECTIVE_DT, END_DT, DISCOUNT_PERCENTAGE, INSERT_AUDIT_KEY)
             VALUES (Policy_key, 1, 11, EFFECTIVE_DT, EXP_DT, 0, v_audit_key)
             ----
             SELECT
                    policy_key
                   ,BRAND
                   ,pri.Name, pri.Description
                   , POLICY_PRODUCT_XID
                   ,POLICY_LKP_XID
                   ,RETAIL_PRICE_AMT, DEALER_COST, PREMIUM_AMT, tr.TERM_KEY
                   ,effective_dt, exp_dt, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE
                   ,uw.UNDERWRITER_KEY
                   ,CONTRACT_SALES_CHANNEL_Key, COVERAGE_TIMING_STRATEGY_Key, DEDUCTIBLE
                   ,NEW_USED_IND, CURRENCY_CD, 0 as insert_audit_key
                   ---
                   , POLICY_TYPE_KEY, POLICY_GROUP_KEY
                   ---
                   ,age
                   ,PRODUCT_CAT_DESC, channel
             FROM
               (SELECT
                        policy_key   --Policy_SEQ.nextval as
                        ,BRAND
                        ,BRAND || ' Appliance Service plan - '  || TERM_COVERAGE_EXT || ' Year' as name
                        ,TERM_COVERAGE_EXT || ' yr ' || BRAND || ' Appliance Service plan ' ||
                            case when upper(channel) IN ('RENEWAL', 'RENEWAL PROGRAM') THEN '(RN)'
                                 when upper(channel) IN ('AM EB', 'AFTERMARKET') THEN '(AM)'
                                 when upper(channel) IN ('OOW', 'AFTERMARKET SWEEP') THEN '(AO)'
                                else upper(channel)
                             END
                            as description
                        ,SKU AS POLICY_PRODUCT_XID
                        ,SKU || '-' || POLICY_KEY AS POLICY_LKP_XID --This is required/used when we are using existing SKUs to create new policy_keys
                        ,v.EFFECTIVE_DT, DATE '2099-12-31' AS EXP_DT
                        ,MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE
                        , 'USD' as CURRENCY_CD
                        , 1 AS POLICY_TYPE_KEY, 1 AS POLICY_GROUP_KEY
                        ,PRODUCT_CAT_DESC
                        ,RETAIL_PRICE_AMT
                        ,NULL as DEALER_COST
                        ,TWGIS_COST AS PREMIUM_AMT
                        , Age
                        ,TERM_COVERAGE_EXT * 365 AS Term_Days
                        ,3 AS CONTRACT_SALES_CHANNEL_Key
                        ,
                         case when upper(channel) IN ('RENEWAL', 'RENEWAL PROGRAM') THEN 1
                              when upper(channel) IN ('AM EB', 'AFTERMARKET') THEN 1
                              when upper(channel) IN ('OOW', 'AFTERMARKET SWEEP') THEN 3
                              else 1
                          END AS COVERAGE_TIMING_STRATEGY_Key

                        ,'REPAIR_AND_REPLACEMENT' AS RESOLUTION_TYPE
                        ,null as DEDUCTIBLE
                        ,'N' as NEW_USED_IND
                        ,'TWG' AS UNDERWRITER_NM
                        ,channel
                        ---
                   FROM RAW_PRICING_TBL v
                ) pri
                left join p_term_dim tr on (tr.day = pri.Term_Days)
                left join p_underwriter_tbl uw on (uw.name = pri.underwriter_nm);

             COMMIT;


          END;