select *
  from bosh.v_product
 where 1=1
--    and BRAND_NM = 'Bosch'
--    and PRODUCT_CATEGORY_NM = 'COOKING'
-- where product_dsc like '%24%Bar Handle Ascenta Series%'
--  where MODEL_NO like 'SH%'
--    and model_no = :model_no
and model_no IN (
''
    )
 order by MODEL_NO;

Select Distinct PRICING_SCHEME_DESC from P_PRICING_SCHEME_DIM;
--Select * from p_policy_tbl;
---======================================================================================--
select Distinct vpr.model_no,vpr.PRODUCT_CATEGORY_NM,vpr.BRAND_NM,vpr.PRODUCT_COVERAGE_END_DT,vpr.DO_NOT_SOLICIT_PRODUCT_IND,vpr.PRICE_AMT
    --, pol.MIN_PRODUCT_PRICE,  pol.MAX_PRODUCT_PRICE
--        vpr.PRICE_AMT, pol.age
--        , psd.PRICING_SCHEME_DESC, ppd.PRICING_SCHEME_KEY, ppd.PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, ACTIVE_IND, vpr.PRODUCT_COVERAGE_END_DT,
--        PRICE_BEFORE_DISCOUNT_AMT, ppd.POLICY_KEY, pol.POLICY_PRODUCT_XID as sku,  i.creation_dt, u.creation_dt as updated_dt,
--        psd.pricing_scheme_name, psd.pricing_scheme_desc, psd.load_dt, pol.exp_dt, pol.MIN_PRODUCT_PRICE,  pol.MAX_PRODUCT_PRICE,
--        vpr.PRICE_AMT, pol.age
  from P_product_price_dim ppd
       join P_PRICING_SCHEME_DIM psd on psd.pricing_scheme_key = ppd.pricing_scheme_key
       join bosh.v_product vpr on vpr.product_key = ppd.product_key
       left join audit_tbl i on (i.audit_key = ppd.insert_audit_key)
       left join audit_tbl u on (u.audit_key = ppd.update_audit_key)
       join p_policy_tbl pol on pol.policy_key = ppd.policy_key
 where 1=1
--     and psd.pricing_scheme_desc like 'AO%'
--    and term_months = 12
   and vpr.PRICE_AMT = 499
   --and vpr.BRAND_NM not in ('Gaggenau')
   and psd.PRICING_SCHEME_DESC Not like '%RN%'
   --and ppd.pricing_scheme_key >= 64
    --and PRODUCT_CATEGORY_NM like '%DISHWASHER%' -- 'COOKING'
      and PRODUCT_CATEGORY_NM NOT like '%OTHER%' -- 'COOKING'
--   and psd.pricing_scheme_name not like 'T%' and psd.pricing_scheme_desc not like '%Thermador'
--    and ppd.active_ind = 'N'
   and ppd.pricing_scheme_key IN (
            select distinct ccx.pricing_scheme_key
              from P_criteria_cell_xref ccx join P_criteria_dim cri using(criteria_key)
             where 1=1
               and cri.active_ind = 'Y' and ccx.POPULATION_PCT > 0
             )
 order by  MODEL_NO;
--ppd.pricing_scheme_key, term_months,

---======================================================================================--
--This sql is used to debug individual cases
select --distinct PRODUCT_CAT_DESC
        r.*, a.creation_dt
  from  bosh.raw_pricing_tbl r left join audit_tbl a on (audit_key = insert_audit_key)
 where 1=1
--  and file_nm = 'Bosch_Pricing_SKU_file-format_07.06.20v2_KZ.csv'
--  and (file_nm = 'BSH_SKU_Creation_Renewals_UPD_05_30_17.csv' or file_nm = 'Bosch_Renewal_Pricing_Adj_to_Match_Prior_Pricing_V3')
--  and trim(sku) IN (
--        'GAVTE48UR3'
-- )
  --and 500 between min_product_price and max_product_price
  and min_product_price >= 300 --and max_product_price < 8000
  and UPPER(PRODUCT_CAT_DESC)  like '%COOKING%'
--    and UPPER(PRODUCT_CAT_DESC)  =  'REFRIGERATOR WITH FOOD LOSS' --'BUILT-IN COFFEE MAKER'  --'COOKING'  -- 'COOKING'  --'LAUNDRY-WASHER' --LIKE 'LAUNDRY%' --'DISHWASHER' --'%FRI%'
--    and (brand like 'BSUS%' or brand = 'Bosch' )
  and brand like 'B%'
--   and brand like 'T%'
  and CHANNEL like 'R%'
  and brand not like '%CAN'
-- order by SKU, insert_audit_key
order by min_product_price, max_product_price,
         case when age >= 12 then age/12 else age end,
         TERM_COVERAGE_EXT;


Select PD.MODEL_NO,PD.PRODUCT_NM,PD.BRAND_NM ,PD.PRODUCT_CATEGORY_NM, PD.MATERIAL_GROUP
     ,PD.PRICE_AMT,PD.PRODUCT_KEY,PD.PRODUCT_COVERAGE_END_DT,PD.DO_NOT_SOLICIT_PRODUCT_IND from V_PRODUCT PD
    Where  PD.MODEL_NO in(
        'HMV5051U',
        'HMV5052U',
        'SHE3AR52UC',
        'SHE3AR56UC',
        'SHE3AR72UC',
        'SHE3AR76UC',
        'SHE3ARF2UC',
        'SHE3ARF6UC',
        'SHE3ARL2UC',
        'SHE3ARL6UC',
        'SHEM3AY52N',
        'SHEM3AY56N'
        )
Order by PD.MODEL_NO;


Select PD.MODEL_NO,PD.PRODUCT_NM,PD.BRAND_NM ,PD.PRODUCT_CATEGORY_NM, PD.MATERIAL_GROUP
     ,PD.PRICE_AMT,PD.PRODUCT_KEY,PD.PRODUCT_COVERAGE_END_DT,PD.DO_NOT_SOLICIT_PRODUCT_IND from V_PRODUCT PD
    Where  PD.MODEL_NO in (select Distinct vpr.model_no
                           from P_product_price_dim ppd
                                    join P_PRICING_SCHEME_DIM psd on psd.pricing_scheme_key = ppd.pricing_scheme_key
                                    join bosh.v_product vpr on vpr.product_key = ppd.product_key
                                    left join audit_tbl i on (i.audit_key = ppd.insert_audit_key)
                                    left join audit_tbl u on (u.audit_key = ppd.update_audit_key)
                                    join p_policy_tbl pol on pol.policy_key = ppd.policy_key
                           where 1 = 1
                             and vpr.PRICE_AMT = 499
                             and psd.PRICING_SCHEME_DESC Not like '%RN%'
                             and PRODUCT_CATEGORY_NM NOT like '%OTHER%' -- 'COOKING'
                             and ppd.pricing_scheme_key IN (select distinct ccx.pricing_scheme_key
                                                            from P_criteria_cell_xref ccx
                                                                     join P_criteria_dim cri using (criteria_key)
                                                            where 1 = 1
                                                              and cri.active_ind = 'Y'
                                                              and ccx.POPULATION_PCT > 0))
    order by  MODEL_NO;


select * from AUDIT_TBL where AUDIT_KEY = 247819;

Select * from BOSH.RAW_MODEL_MASTER_TBL
where MATERIAL in
('HMV5051U','HMV5052U','SHE3AR52UC','SHE3AR56UC','SHE3AR72UC','SHE3AR76UC',
'SHE3ARF2UC','SHE3ARF6UC','SHE3ARL2UC','SHE3ARL6UC','SHEM3AY52N','SHEM3AY56N') and
FILE_NM in ('20220713_040245_After_Inc-Bosch_.csv','20220713_040245_After_Inc-Thermador_20220704_083444.csv','20220713_040245_After_Inc.csv')
Order by RAW_MODEL_MASTER_TBL.INSERT_AUDIT_KEY DESC
;

