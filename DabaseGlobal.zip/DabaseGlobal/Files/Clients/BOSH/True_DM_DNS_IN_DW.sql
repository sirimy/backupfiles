
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'true DM DNS in DW', p_table_nm => 'CUSTOMER_DIM');
BEGIN

                update CUSTOMER_DIM
                    SET address_SUPPRESSION_CD = 'Y',UPDATE_AUDIT_KEY = v_audit_key
                 where CUSTOMER_KEY in (
                    select cust.CUSTOMER_KEY
                            from bosh.TRUE_DM_DNS_WEB w
                                 join visitor_lkp vlkp on vlkp.visitor_xid = to_char(w.customer_id)
                                 join visitor_dim vd on vd.visitor_key = vlkp.visitor_key
                                 join customer_dim cust on cust.customer_key = vd.customer_key
                           where
                                  w.do_not_mail = 'Y'
                             and nvl(cust.address_SUPPRESSION_CD, 'N') <> 'Y') and nvl(address_SUPPRESSION_CD, 'N') <> 'Y' ;

       DBMS_OUTPUT.PUT_LINE(v_audit_key);
        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );


       COMMIT;

END;