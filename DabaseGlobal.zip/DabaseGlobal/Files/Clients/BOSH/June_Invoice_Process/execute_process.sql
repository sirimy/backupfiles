

update assurant_cancel_detail
       set  REFUND_AMT = REFUND_AMT * -1
     where INVOICE_MONTH = 202606 AND AGREEMENT_TYPE = 'Customer Cancellation' ;

COMMIT;

select * from ASSURANT_CANCEL_DETAIL where AGREEMENT_TYPE = 'Customer Cancellation' order by DBMS_RANDOM.RANDOM();

+------------+
|AGMT_NUMBER | --> this column should not affect  process , we need to check how BSH is used to join tables
+------------+
|528601-1    |
|BSH-514785-1|
+------------+

+-----------+----------+
|DEALER_COST|REFUND_AMT|
+-----------+----------+
|-407.18    |-770      |
+-----------+----------+

-- +-------------------+----------+
-- |AGREEMENT_TYPE     |RETAIL_AMOUNT/REFUND_AMT
-- +-------------------+----------+
-- |Dealer Cancellation|-352      | --> This amount is blank before
-- +-------------------+----------+

+---------------------+----------+
|AGREEMENT_TYPE       |RETAIL_AMOUNT/REFUND_AMT
+---------------------+----------+
|Customer Cancellation|-770      | --> This amount will be positive
+---------------------+----------+



CREATE TABLE assurant_cancel_detail_june_2026_from_core_backup AS
 select *
    from   BOSH.assurant_cancel_detail t1
    where  invoice_month = 202606;
  ;--2343


CREATE TABLE process_qa_log_2026_backup AS
 select * from PROCESS_QA_LOG where PROCESS_NM ='invoice month: 202606' ;
  ;--

select * from process_qa_log_2026_backup;
commit;
-- There are 510 records in assurant_cancel_detail, which have been charged in previous months already : 202606
select * from PROCESS_QA_LOG where PROCESS_NM ='invoice month: 202606' ;


BEGIN P_PK_CORE_UPDATE.INSERT_TBL('ASSURANT_CANCEL_DETAIL'); END;


select Agreement_Type,COUNT(*) from assurant_cancel_detail_june_2026_from_core_backup
group by    Agreement_Type;
-- +---------------------+--------+
-- |AGREEMENT_TYPE       |COUNT(*)|
-- +---------------------+--------+
-- |Dealer Cancellation  |35      |
-- |New Business         |2277    |
-- |Customer Cancellation|31      |
-- +---------------------+--------+



select Agreement_Type,COUNT(*) from ASSURANT_CANCEL_DETAIL
group by    Agreement_Type;
+---------------------+--------+
|AGREEMENT_TYPE       |COUNT(*)|
+---------------------+--------+
|Dealer Cancellation  |387     |
|New Business         |2277    |
|Customer Cancellation|34      |
+---------------------+--------+



select * from ASSURANT_CANCEL_DETAIL   order by DBMS_RANDOM.RANDOM();

 begin BOSHSTG.ASSURANT_INVOICE_QA(202606); end;

  select COUNT(*)
    from   assurant_cancel_detail t1
    where  invoice_month = 202606
    and    exists (
               select 1 from BOSH.assurant_cancel_detail t2
               where  t2.invoice_month < t1.invoice_month
               and     replace(t2.AGMT_NUMBER , 'BSH-')   = replace(t1.AGMT_NUMBER , 'BSH-')
               and    t2.Agreement_Type = t1.Agreement_Type
              );--



  select invoice_month,COUNT(*)
    from   BOSH.assurant_cancel_detail t1
    where  invoice_month <> 202606
    and    exists (
               select 1 from assurant_cancel_detail t2
               where  t2.invoice_month = 202606
               and    replace(t2.AGMT_NUMBER , 'BSH-')   = replace(t1.AGMT_NUMBER , 'BSH-')
               and    t2.Agreement_Type = t1.Agreement_Type
              )
  group by invoice_month
  ;--



  select COUNT(*)
    from   BOSH.assurant_cancel_detail t1
    where  invoice_month = 202606
    and    exists (
               select 1 from BOSH.assurant_cancel_detail t2
               where  t2.invoice_month < t1.invoice_month
               and     replace(t2.AGMT_NUMBER , 'BSH-')   = replace(t1.AGMT_NUMBER , 'BSH-')
               and    t2.Agreement_Type = t1.Agreement_Type
              );--510



  select invoice_month,COUNT(*)
    from   BOSH.assurant_cancel_detail t1
    where  invoice_month <> 202606
    and    exists (
               select 1 from BOSH.assurant_cancel_detail t2
               where  t2.invoice_month = 202606
               and    replace(t2.AGMT_NUMBER , 'BSH-')   = replace(t1.AGMT_NUMBER , 'BSH-')
               and    t2.Agreement_Type = t1.Agreement_Type
              )
  group by invoice_month
  ;--
+-------------+--------+
|INVOICE_MONTH|COUNT(*)|
+-------------+--------+
|202605       |279     |
|202603       |231     |
+-------------+--------+



  select *
    from   BOSH.assurant_cancel_detail t1
    where  invoice_month <> 202606
    and    exists (
               select 1 from BOSH.assurant_cancel_detail t2
               where  t2.invoice_month = 202606
               and    t2.Agmt_Number   = t1.Agmt_Number
               and    t2.Agreement_Type = t1.Agreement_Type
              )

  ;-- BSH-514403-1

  +-------------+--------------+------------+-------------+---------+------------+----------+-----------+----+-----------+----------+----------------+
|INVOICE_MONTH|AGREEMENT_TYPE|AGMT_NUMBER |CUSTOMER_NAME|MODEL    |SERIALNUMBER|EFF_DATE  |CANCEL_DATE|TERM|DEALER_COST|REFUND_AMT|INSERT_AUDIT_KEY|
+-------------+--------------+------------+-------------+---------+------------+----------+-----------+----+-----------+----------+----------------+
|202603       |New Business  |BSH-514403-1|JOHN BUDD    |SHP78CM4N|null        |01/07/2027|01/07/2033 |72  |203.01     |396.76    |1080153         |
+-------------+--------------+------------+-------------+---------+------------+----------+-----------+----+-----------+----------+----------------+



+-------------+--------------+------------+-------------+---------+------------+----------+-----------+----+-----------+----------+----------------+
|INVOICE_MONTH|AGREEMENT_TYPE|AGMT_NUMBER |CUSTOMER_NAME|MODEL    |SERIALNUMBER|EFF_DATE  |CANCEL_DATE|TERM|DEALER_COST|REFUND_AMT|INSERT_AUDIT_KEY|
+-------------+--------------+------------+-------------+---------+------------+----------+-----------+----+-----------+----------+----------------+
|202603       |New Business  |BSH-514403-1|JOHN BUDD    |SHP78CM4N|null        |01/07/2027|01/07/2033 |72  |203.01     |396.76    |1080153         |
|202606       |New Business  |BSH-514403-1|JOHN BUDD    |null     |null        |null      |null       |null|203.01     |370.8     |1112829         |
+-------------+--------------+------------+-------------+---------+------------+----------+-----------+----+-----------+----------+----------------+

 select *
    from   BOSH.assurant_cancel_detail t1 where  AGMT_NUMBER ='BSH-514403-1';

