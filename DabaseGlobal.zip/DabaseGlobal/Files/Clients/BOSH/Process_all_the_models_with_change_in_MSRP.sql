
select COUNT(Distinct MATERIAL) from BOSH.RAW_MODEL_MASTER_TBL ;

SELECT COUNT(Distinct MATERIAL) FROM
( SELECT
    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
FROM
    BOSH.RAW_MODEL_MASTER_TBL  RMMT)
WHERE r = 1;




select * from RAW_MODEL_MASTER_TBL_LATEST;


insert into RAW_MODEL_MASTER_TBL_LATEST
SELECT * FROM
( SELECT
    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
FROM
    BOSH.RAW_MODEL_MASTER_TBL  RMMT  inner join AUDIT_TBL AT ON RMMT.INSERT_AUDIT_KEY = AT.AUDIT_KEY
Where AT.CREATION_DT  >= TO_DATE('01/MAR/2022 00:00:00', 'dd/mon/yyyy HH24:MI:SS'))
WHERE r = 1;


select AT.CREATION_DT,RMMT.FILE_NM,COUNT(RMMT.FILE_NM) from   BOSH.RAW_MODEL_MASTER_TBL RMMT
    inner join AUDIT_TBL AT ON RMMT.INSERT_AUDIT_KEY = AT.AUDIT_KEY
Where AT.CREATION_DT  >= TO_DATE('01/MAR/2022 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
Group by AT.CREATION_DT,RMMT.FILE_NM
Order by AT.CREATION_DT ;

--order by MATERIAL,r;
--WHERE r = 1;

select * from BOSH.PRODUCT_DIM;

select COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST where MATERIAL_GROUP <> 'Accessory' and MAP_UMRP is not null ;


Update RAW_MODEL_MASTER_TBL_LATEST
SET ERROR_DESC = 'Model exist with same price in core'
where TRIM(MATERIAL) not in (
select  TRIM(MATERIAL) from
RAW_MODEL_MASTER_TBL_LATEST tgt
    inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c
            where c.PRICE_AMT is not null) src
    on (TRIM(src.BRAND_NM) = TRIM(tgt.BRAND) and TRIM(src.MODEL_NO) = TRIM(tgt.MATERIAL) )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
        and TRIM(tgt.MATERIAL_GROUP) <> 'Accessory' and tgt.MAP_UMRP is not null );


Update RAW_MODEL_MASTER_TBL
      SET ERROR_DESC = NULL;

select Distinct ERROR_DESC from RAW_MODEL_MASTER_TBL;

insert into RAW_MODEL_MASTER_TBL
select  MATERIAL           ,
    MATERIAL_DESCRIPTION  ,
    BRAND       ,
    MATERIAL_GROUP     ,
    SALES_STATUS    ,
    VALID_FROM     ,
    EF_OUT_DATE     ,
    UPC_CODE       ,
    NEW_BUSINESS_FIELD  ,
    PRODUCT_TYPE    ,
    MAP_UMRP       ,
    SK_MARKETING_DESCRIPTION ,
    FILE_NM     ,
    INSERT_AUDIT_KEY  ,
    UNIQUE_SEQ_NO   ,
    ERROR_DESC      from RAW_MODEL_MASTER_TBL_LATEST Where ERROR_DESC is null;

select COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST Where ERROR_DESC is null;


select * from RAW_MODEL_MASTER_TBL_LATEST where TRIM(MATERIAL) in (
select  TRIM(MATERIAL) from
RAW_MODEL_MASTER_TBL_LATEST tgt
    inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c
            where c.PRICE_AMT is not null) src
    on (TRIM(src.BRAND_NM) = TRIM(tgt.BRAND) and TRIM(src.MODEL_NO) = TRIM(tgt.MATERIAL) )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
        and TRIM(tgt.MATERIAL_GROUP) <> 'Accessory' and tgt.MAP_UMRP is not null );

select COUNT(*) from
RAW_MODEL_MASTER_TBL_LATEST tgt
    inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c
            where c.PRICE_AMT is not null) src
    on (TRIM(src.BRAND_NM) = TRIM(tgt.BRAND) and TRIM(src.MODEL_NO) = TRIM(tgt.MATERIAL) )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
        and TRIM(tgt.MATERIAL_GROUP) <> 'Accessory' and tgt.MAP_UMRP is not null ;


select COUNT(*) from RAW_MODEL_MASTER_TBL;

BEGIN PK_MODELMASTER.s_001_load_product_category_price_change ; END;
select * from PRODUCT_CATALOG_TBL;

select COUNT(*) from PRODUCT_CATALOG_TBL; --414

select * from  brand_lkp;--0
select * from product_lkp;--0
select * from  product_category_lkp;--0
select COUNT(*) from product_dim; --414
select * from  brand_dim;--3
select * from  product_category_dim;--6
select COUNT(*) from  product_attribute_xref;--414X4=1656



--Core value is Y for DNS
select  s.DO_NOT_SOLICIT_PRODUCT_IND,  c.DO_NOT_SOLICIT_PRODUCT_IND
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.DO_NOT_SOLICIT_PRODUCT_IND <> c.DO_NOT_SOLICIT_PRODUCT_IND  --1
    ) and s.PRICE_AMT is not null ;
-- DO_NOT_SOLICIT_PRODUCT_IND,DO_NOT_SOLICIT_PRODUCT_IND
-- N                         ,Y


-- 109 product coverage date is changed
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt  --109
    )  ;


-- Here 103 rows have CORE value is = 2099-12-29
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt  --103
    )  and c.Product_Coverage_End_Dt = TO_DATE('2099-12-29 00:00:00', 'YYYY/MM/DD HH24:MI:SS') ;



--300 records have same dates and value also same this 2099-12-29
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt = c.Product_Coverage_End_Dt  --109
    )  and s.PRODUCT_COVERAGE_END_DT = TO_DATE('2099-12-29 00:00:00', 'YYYY/MM/DD HH24:MI:SS')  ;



-- All 414 same brand
select COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.BRAND_NM = c.BRAND_NM --0
    ) and s.BRAND_NM is not null and  c.BRAND_NM is not null  ;


--17  rows have  changed category
select COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRODUCT_CATEGORY_NM <>  c.PRODUCT_CATEGORY_NM --0
--      or s.PRICE_AMT <> c.PRICE_AMT --414
    ) and s.PRODUCT_CATEGORY_NM is not null and  c.PRODUCT_CATEGORY_NM is not null  ;
--
-- STG_PRODUCT_CATEGORY_NM, CORE_PRODUCT_CATEGORY_NM
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- VENTILATION          ,OTHER
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING
-- OTHER                ,COOKING



--Price changed for all 414 rows
select Count(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT <> c.PRICE_AMT --414
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;



-- 402 rows have new price increased
select Count(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT > c.PRICE_AMT --402
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;



-- 12 rows have less price new value
select s.PRICE_AMT , c.PRICE_AMT
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT < c.PRICE_AMT --402
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;

-- PRICE_AMT,PRICE_AMT
-- 1399.00,1499.00
-- 4799.00,4999.00
-- 7999.00,8399.00
-- 7499.00,7599.00
-- 7999.00,8399.00
-- 5999.00,6499.00
-- 6499.00,6949.00
-- 6999.00,7599.00
-- 3799.00,4199.00
-- 1649.00,1749.00
-- 7499.00,7599.00
-- 7499.00,7599.00


-- All coloumns with list of data with compare STG and Core
select s.BRAND_NM AS BRAND_NM_stg , c.BRAND_NM AS BRAND_NM_CORE
       ,s.PRODUCT_CATEGORY_NM AS PRODUCT_CATEGORY_NM_stg , c.PRODUCT_CATEGORY_NM AS PRODUCT_CATEGORY_NM_CORE
     ,s.PRICE_AMT AS PRICE_AMT_stg , c.PRICE_AMT AS PRICE_AMT_CORE
     ,s.DO_NOT_SOLICIT_PRODUCT_IND AS DNS_stg , c.DO_NOT_SOLICIT_PRODUCT_IND AS DNS_CORE
      ,s.Product_Coverage_End_Dt AS Product_Coverage_End_Dt_stg , c.Product_Coverage_End_Dt AS Product_Coverage_End_Dt_CORE
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.BRAND_NM <> c.BRAND_NM
      or s.PRICE_AMT <> c.PRICE_AMT
      or s.PRODUCT_CATEGORY_NM <>  c.PRODUCT_CATEGORY_NM --0
     or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt
     or s.DO_NOT_SOLICIT_PRODUCT_IND <> c.DO_NOT_SOLICIT_PRODUCT_IND
    )   ;
