
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'Update Key', p_table_nm => 'CONTRACT_CANCELLATION_DIM');

BEGIN

        update BOSH.CONTRACT_CANCELLATION_DIM
         SET UPDATE_AUDIT_KEY = v_audit_key,SYNC_AUDIT_KEY=null
        where CONTRACT_KEY in (
        select clp.CONTRACT_KEY from boshstg.v_rejected_cancellation vrc inner join bosh.CONTRACT_LKP clp
        on vrc.P2CONTRACT_NUMBER = CLP.CONTRACT_XID
        where TWG_REPORTED_REASON ='FIELD_CUSTOM_VALIDATION_EXCEPTION:Contract not eligible for Cancellation. There must be no Open Cases.:--'
        );

       COMMIT;

END;


