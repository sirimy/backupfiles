select BUNDLE_KEY from ESP_AM_SCR_OUTPUT_TBL
UNION ALL select BUNDLE_KEY from ESP_AM_SCR_VAR_TBL
UNION ALL select BUNDLE_KEY from ESP_AM_SCR_ERROR_TBL;


 COMMIT;
select distinct SCORE_DT from BOSHSTG.ESP_AM_SCR_OUTPUT_TBL;
--2025-05-21 13:07:36
--2025-05-22 04:32:48
select distinct SCORE_DT from BOSHSTG.ESP_AM_SCR_VAR_TBL  ;
-- 2025-05-21 13:07:36
--2025-05-22 04:32:48
select distinct SCORE_DT from BOSHSTG.ESP_AM_SCR_ERROR_TBL;
-- 2025-05-21 13:07:36

select AT.CREATION_DT,RD.LOAD_DT,COUNT(*) from BOSH.DEMOGRAPHIC_DIM RD join AUDIT_TBL AT on RD.INSERT_AUDIT_KEY = AT.AUDIT_KEY
GROUP BY AT.CREATION_DT,RD.LOAD_DT
ORDER BY AT.CREATION_DT DESC
;
-- +--------------------------+----------+--------+
-- |CREATION_DT               |LOAD_DT   |COUNT(*)|
-- +--------------------------+----------+--------+
-- |2025-05-21 13:14:13.000000|2025-05-21|31524   |
-- +--------------------------+----------+--------+


select * from DS_ACE_OUTPUT_TBL;
select * from COMMON_LOAD_TBL;

--
-- MERGE INTO DS_ACE_OUTPUT_TBL tgt
--     USING (SELECT * FROM COMMON_LOAD_TBL WHERE FILE_NM = 'v_sync_phone') src
--     ON (tgt.UNIQUE_SEQ_NO = src.UNIQUE_SEQ_NO)
--   WHEN MATCHED THEN
--     UPDATE SET tgt.CITY_NM = src.CITY_NM,
--                tgt.STATE_CD = src.STATE_CD
--   WHERE tgt.CITY_NM IS not NULL  OR tgt.STATE_CD IS NOT NULL;
--



--
--
-- CREATE TABLE boshstg_p_visitor_address_xref_bosh_1840
--   AS (
--     select distinct pvdx.VISITOR_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,pvdx.END_DT_KEY,pvdx.EFF_DT_KEY,pvdx.INSERT_AUDIT_KEY,ATT3.CREATION_DT,SD.SI_KEY from BOSH.DS_ACE_OUTPUT_TBL_ARCH DSACE
--                         join BOSH.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
--                         join BOSH.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
--                         join BOSH.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
--                         join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VL.VISITOR_KEY
--                         join BOSH.ADDRESS_DIM AD on AD.ADDRESS_KEY = pvdx.ADDRESS_KEY
--                         join BOSH.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY
--                         join BOSH.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
--                         join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
--                         join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
--                         join AUDIT_TBL ATT3 on pvdx.INSERT_AUDIT_KEY = ATT3.AUDIT_KEY
--                     where --DSACE.PROCESS_DT = '20250520' AND
--                           DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
--                           AND pvdx.PRIMARY_IND = 'Y' AND AD.FIRST_NM IS NULL AND AD.LAST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
--                           AND ATT.CREATION_DT >= date '2025-05-01'
--                           AND ATT2.CREATION_DT >= date '2025-05-01'
--      )
-- ;--1,796
--[2025-05-23 00:18:12] 1,796 rows affected in 6 s 507 ms
--COMMIT;

select COUNT(*) from boshstg_p_visitor_address_xref_bosh_1840;--1796

select COUNT(distinct VISITOR_KEY) from boshstg_p_visitor_address_xref_bosh_1840;--721


select COUNT(distinct VISITOR_KEY) from (
    select DISTINCT cvdx.VISITOR_KEY,gvdx.ADDRESS_KEY, cvdx.ADDRESS_KEY
           ,ATT.CREATION_DT,AD.FIRST_NM,AD.LAST_NM,AD.ADDRESS_LINE1_TX
           ,ATT2.CREATION_DT,AD1.FIRST_NM,AD1.LAST_NM,AD1.ADDRESS_LINE1_TX
        from boshstg_p_visitor_address_xref_bosh_1840 gvdx
            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
            join BOSH.ADDRESS_DIM AD on AD.ADDRESS_KEY = gvdx.ADDRESS_KEY
            join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cvdx.ADDRESS_KEY
            join BOSH.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = gvdx.VISITOR_KEY
            join BOSH.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
            join AUDIT_TBL ATT2 on AD1.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
        where cvdx.ADDRESS_KEY <> gvdx.ADDRESS_KEY
              and cvdx.VISITOR_KEY in (
                select cvdx.VISITOR_KEY
                 from boshstg_p_visitor_address_xref_bosh_1840 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                 group by cvdx.VISITOR_KEY
                 having COUNT(*)=2
                )
            and AD.ADDRESS_LINE1_TX IS NULL
            and AD1.ADDRESS_LINE1_TX IS NOT NULL
    order by cvdx.VISITOR_KEY,ATT.CREATION_DT
)t
;--300


select COUNT(distinct VISITOR_KEY) from (
    select DISTINCT cvdx.VISITOR_KEY,gvdx.ADDRESS_KEY, cvdx.ADDRESS_KEY
           ,ATT.CREATION_DT,AD.FIRST_NM,AD.LAST_NM,AD.ADDRESS_LINE1_TX
           ,ATT2.CREATION_DT,AD1.FIRST_NM,AD1.LAST_NM,AD1.ADDRESS_LINE1_TX
        from boshstg_p_visitor_address_xref_bosh_1840 gvdx
            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
            join BOSH.ADDRESS_DIM AD on AD.ADDRESS_KEY = gvdx.ADDRESS_KEY
            join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cvdx.ADDRESS_KEY
            join BOSH.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = gvdx.VISITOR_KEY
            join BOSH.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
            join AUDIT_TBL ATT2 on AD1.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
        where cvdx.ADDRESS_KEY <> gvdx.ADDRESS_KEY
              and cvdx.VISITOR_KEY in (
                select cvdx.VISITOR_KEY
                 from boshstg_p_visitor_address_xref_bosh_1840 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                 group by cvdx.VISITOR_KEY
                 having COUNT(*) > 2
                )
            and AD.ADDRESS_LINE1_TX IS NULL
            and AD1.ADDRESS_LINE1_TX IS NOT NULL
    order by cvdx.VISITOR_KEY,ATT.CREATION_DT
)t
;--421


Select * from (
    Select T.VISITOR_KEY,T.ADDRESS_KEY_1, T.ADDRESS_KEY_2
                   ,T.CREATION_DT_1,T.FIRST_NM_1,T.LAST_NM_1,T.ADDRESS_LINE1_TX_1
                   ,T.CREATION_DT_2
                    , ROW_NUMBER() OVER( PARTITION BY T.VISITOR_KEY ORDER BY T.CREATION_DT_2 DESC) as SEQ_NO
                    ,T.FIRST_NM_2,T.LAST_NM_2,T.ADDRESS_LINE1_TX_2--,T.SERIAL_NO
    from (
        select DISTINCT cvdx.VISITOR_KEY,gvdx.ADDRESS_KEY AS ADDRESS_KEY_1, cvdx.ADDRESS_KEY AS ADDRESS_KEY_2
                   ,ATT.CREATION_DT AS CREATION_DT_1,AD.FIRST_NM AS FIRST_NM_1,AD.LAST_NM AS LAST_NM_1,AD.ADDRESS_LINE1_TX AS ADDRESS_LINE1_TX_1
                   ,ATT2.CREATION_DT AS CREATION_DT_2,AD1.FIRST_NM AS FIRST_NM_2,AD1.LAST_NM AS LAST_NM_2,AD1.ADDRESS_LINE1_TX AS ADDRESS_LINE1_TX_2--,SD.SERIAL_NO
                from boshstg_p_visitor_address_xref_bosh_1840 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                    join BOSH.ADDRESS_DIM AD on AD.ADDRESS_KEY = gvdx.ADDRESS_KEY
                    join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cvdx.ADDRESS_KEY
                    join BOSH.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = gvdx.VISITOR_KEY and VOX.PRIMARY_IND = 'Y'
                    --join BOSH.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                    join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                    join AUDIT_TBL ATT2 on AD1.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
                where 1=1 AND cvdx.ADDRESS_KEY <> gvdx.ADDRESS_KEY
                      and cvdx.VISITOR_KEY in (
                        select cvdx.VISITOR_KEY
                         from boshstg_p_visitor_address_xref_bosh_1840 gvdx
                            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                         group by cvdx.VISITOR_KEY
                         having COUNT(*) > 2
                        )
                    and AD.ADDRESS_LINE1_TX IS NULL
                    and AD1.ADDRESS_LINE1_TX IS NOT NULL
                    and ATT2.CREATION_DT < date '2025-05-01'
           ) T
        order by T.VISITOR_KEY,T.CREATION_DT_2
)T2  where SEQ_NO =1
;




select COUNT(*) from BOSH.COMMON_LOAD_TBL_ARCH CL where PROCESS_DT = '20250524' and FILE_NM = 'v_sync_phone';--51

select AD.ADDRESS_KEY,AD.ADDRESS_LINE1_TX,AD.FIRST_NM,AOT.ADDRESS_KEY,CL.UNIQUE_SEQ_NO--,COUNT(*)
     ,Cl.FILE_NM,CL.CITY_NM,CL.STATE_CD,CL.ADDRESS_LINE1_TX,DSACE.CITY_NM,DSACE.STATE_CD
     ,AOT.FIRST_NM,AOT.LAST_NM,AOT.CITY_NM,AOT.STATE_CD from BOSH.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join BOSH.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join BOSH.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                    join BOSH.VISITOR_LKP VL on VL.VISITOR_XID = CL.VISITOR_XID
                    join BOSH.VISITOR_ADDRESS_XREF VAX on VAX.VISITOR_KEY = VL.VISITOR_KEY
                    join BOSH.VISITOR_DIM VD on VD.VISITOR_KEY = VAX.VISITOR_KEY

                             join BOSH.ADDRESS_DIM AD on AD.ADDRESS_KEY = VAX.ADDRESS_KEY and VAX.PRIMARY_IND = 'Y'
                where DSACE.PROCESS_DT = '20250524' AND DSACE.ADDRESS_LINE1_TX IS NULL;
                    --AND AOT.ADDRESS_KEY <> 2160008;
--GROUP BY AOT.ADDRESS_KEY,AOT.FIRST_NM,CL.UNIQUE_SEQ_NO,AOT.LAST_NM,Cl.FILE_NM,CL.CITY_NM,CL.STATE_CD,CL.ADDRESS_LINE1_TX,DSACE.CITY_NM,DSACE.STATE_CD,AOT.CITY_NM,AOT.STATE_CD;

-- +-----------+--------+------------+-------+--------+----------------+-------+--------+--------+-------+----------+--------+
-- |ADDRESS_KEY|COUNT(*)|FILE_NM     |CITY_NM|STATE_CD|ADDRESS_LINE1_TX|CITY_NM|STATE_CD|FIRST_NM|LAST_NM|CITY_NM   |STATE_CD|
-- +-----------+--------+------------+-------+--------+----------------+-------+--------+--------+-------+----------+--------+
-- |2160008    |51      |v_sync_phone|NULL   |NULL    |NULL            |NULL   |NULL    |NULL    |NULL   |NULL      |NULL    |
-- |13554148   |1       |v_sync_phone|NULL   |NULL    |NULL            |NULL   |NULL    |OTTO    |RUANO  |MAMARONECK|NY      |
-- +-----------+--------+------------+-------+--------+----------------+-------+--------+--------+-------+----------+--------+



select * from BOSH.ADDRESS_OUTPUT_TBL_ARCH AOT where ADDRESS_KEY <> 2160008 and LAST_NM = 'RUANO' and FIRST_NM = 'OTTO' and
                                                     PROCESS_DT = '20250524';

-- +-----------+-------------+--------+------------+-------+--------+----------------+-------+--------+--------+-------+----------+--------+
-- |ADDRESS_KEY|UNIQUE_SEQ_NO|COUNT(*)|FILE_NM     |CITY_NM|STATE_CD|ADDRESS_LINE1_TX|CITY_NM|STATE_CD|FIRST_NM|LAST_NM|CITY_NM   |STATE_CD|
-- +-----------+-------------+--------+------------+-------+--------+----------------+-------+--------+--------+-------+----------+--------+
-- |13554148   |11650388     |1       |v_sync_phone|NULL   |NULL    |NULL            |NULL   |NULL    |OTTO    |RUANO  |MAMARONECK|NY      |
-- +-----------+-------------+--------+------------+-------+--------+----------------+-------+--------+--------+-------+----------+--------+
select * from BOSH.COMMON_LOAD_TBL_ARCH CL where CL.UNIQUE_SEQ_NO = 11650388;

select * from BOSH.ADDRESS_OUTPUT_TBL_ARCH CL where CL.UNIQUE_SEQ_NO = 11650388;
-- +-------------+-------+--------+---------+-------+----------------+----------------+----------+--------+------------+------------+--------------------------------+-----------+----------+
-- |UNIQUE_SEQ_NO|FIRM_NM|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX|ADDRESS_LINE2_TX|CITY_NM   |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|ADDRESS_HASH_KEY                |ADDRESS_KEY|PROCESS_DT|
-- +-------------+-------+--------+---------+-------+----------------+----------------+----------+--------+------------+------------+--------------------------------+-----------+----------+
-- |11650388     |NULL   |OTTO    |NULL     |RUANO  |310 STANLEY AVE |NULL            |MAMARONECK|NY      |10543       |2532        |0278b9088c6286be6eb67ecc9018430d|13554148   |20240822  |
-- |11650388     |NULL   |NULL    |NULL     |NULL   |NULL            |NULL            |NULL      |NULL    |NULL        |NULL        |d41d8cd98f00b204e9800998ecf8427e|2160008    |20250524  |
-- +-------------+-------+--------+---------+-------+----------------+----------------+----------+--------+------------+------------+--------------------------------+-----------+----------+

Select * from (
    Select T.VISITOR_KEY,T.ADDRESS_KEY_1, T.ADDRESS_KEY_2
                   ,T.CREATION_DT_1,T.FIRST_NM_1,T.LAST_NM_1,T.ADDRESS_LINE1_TX_1
                   ,T.CREATION_DT_2
                    , ROW_NUMBER() OVER( PARTITION BY T.VISITOR_KEY ORDER BY T.CREATION_DT_2 DESC) as SEQ_NO
                    ,T.FIRST_NM_2,T.LAST_NM_2,T.ADDRESS_LINE1_TX_2--,T.SERIAL_NO
    from (
        select DISTINCT cvdx.VISITOR_KEY,gvdx.ADDRESS_KEY AS ADDRESS_KEY_1, cvdx.ADDRESS_KEY AS ADDRESS_KEY_2
                   ,ATT.CREATION_DT AS CREATION_DT_1,AD.FIRST_NM AS FIRST_NM_1,AD.LAST_NM AS LAST_NM_1,AD.ADDRESS_LINE1_TX AS ADDRESS_LINE1_TX_1
                   ,ATT2.CREATION_DT AS CREATION_DT_2,AD1.FIRST_NM AS FIRST_NM_2,AD1.LAST_NM AS LAST_NM_2,AD1.ADDRESS_LINE1_TX AS ADDRESS_LINE1_TX_2--,SD.SERIAL_NO
                from boshstg_p_visitor_address_xref_bosh_1840 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                    join BOSH.ADDRESS_DIM AD on AD.ADDRESS_KEY = gvdx.ADDRESS_KEY
                    join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cvdx.ADDRESS_KEY
                    join BOSH.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = gvdx.VISITOR_KEY and VOX.PRIMARY_IND = 'Y'
                    --join BOSH.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                    join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                    join AUDIT_TBL ATT2 on AD1.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
                where 1=1 AND cvdx.ADDRESS_KEY <> gvdx.ADDRESS_KEY
                      and cvdx.VISITOR_KEY in (
                        select cvdx.VISITOR_KEY
                         from boshstg_p_visitor_address_xref_bosh_1840 gvdx
                            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                         group by cvdx.VISITOR_KEY
                         having COUNT(*) > 2
                        )
                    and AD.ADDRESS_LINE1_TX IS NULL
                    and AD1.ADDRESS_LINE1_TX IS NOT NULL
                    and ATT2.CREATION_DT < date '2025-05-01'
           ) T
        order by T.VISITOR_KEY,T.CREATION_DT_2
)T2  where SEQ_NO =1
;
