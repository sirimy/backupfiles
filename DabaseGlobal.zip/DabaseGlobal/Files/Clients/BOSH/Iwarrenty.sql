
select * from address_output_tbl;
select * from DS_ACE_OUTPUT_TBL;
select * from p_address_lkp;
select * from CUSTOMER_OUTPUT_TBL;


Select * From visitor_dim;
Select * From visitor_lkp;
Select * From visitor_history_tbl;
Select * From address_dim;
Select * From address_lkp;
Select * From visitor_address_xref;
Select * From visitor_address_lkp;
Select * From serialized_item_dim;
Select * From serialized_item_lkp;
select * from serialized_item_ext_dim;
Select * From visitor_ownership_xref;
Select * From email_lkp;
Select * From email_dim;
Select * From visitor_email_xref;
Select * From visitor_email_lkp;
Select * From phone_dim;
Select * From phone_lkp;
Select * From visitor_phone_xref;
Select * From visitor_phone_lkp;
Select * From VISITOR_PREFERENCE_TBL;
Select * From purl_dim;
Select * From VISITOR_PURL_XREF;
Select * From CUSTOMER_DIM;
Select * From HOUSEHOLD_LKP;
Select * From CUSTOMER_LKP;


Select COUNT(*) From serialized_item_dim;