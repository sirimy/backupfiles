
select COUNT(*) from PRODUCT_CATALOG_TBL; --1295

select * from  brand_lkp;--0
select * from product_lkp;--0
select * from  product_category_lkp;--0
select COUNT(*) from product_dim; --1295
select * from  brand_dim;--3
select * from  product_category_dim;--7
select COUNT(*) from  product_attribute_xref;--1287X4=5148



--Core value is Y for DNS 20 records
select  s.DO_NOT_SOLICIT_PRODUCT_IND,  c.DO_NOT_SOLICIT_PRODUCT_IND
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.DO_NOT_SOLICIT_PRODUCT_IND <> c.DO_NOT_SOLICIT_PRODUCT_IND  --1
    ) and s.PRICE_AMT is not null ;
-- DO_NOT_SOLICIT_PRODUCT_IND,DO_NOT_SOLICIT_PRODUCT_IND
-- N                         ,Y


-- 306 product coverage date is changed
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt  --109
    )  ;


-- Here 241 rows have CORE value is = 2099-12-29
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt  --103
    )  and c.Product_Coverage_End_Dt = TO_DATE('2099-12-29 00:00:00', 'YYYY/MM/DD HH24:MI:SS') ;



--852 records have same dates and value also same this 2099-12-29
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt = c.Product_Coverage_End_Dt  --109
    )  and s.PRODUCT_COVERAGE_END_DT = TO_DATE('2099-12-29 00:00:00', 'YYYY/MM/DD HH24:MI:SS')  ;



-- All 1295 same brand
select COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.BRAND_NM = c.BRAND_NM --0
    ) and s.BRAND_NM is not null and  c.BRAND_NM is not null  ;


--11  rows have  changed category
select s.MODEL_NO,s.PRODUCT_CATEGORY_NM,c.PRODUCT_CATEGORY_NM
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRODUCT_CATEGORY_NM <>  c.PRODUCT_CATEGORY_NM --0
--      or s.PRICE_AMT <> c.PRICE_AMT --414
    ) and s.PRODUCT_CATEGORY_NM is not null and  c.PRODUCT_CATEGORY_NM is not null  ;
--
+----------+-------------------+-------------------+
|MODEL_NO  |PRODUCT_CATEGORY_NM|PRODUCT_CATEGORY_NM|
+----------+-------------------+-------------------+
|DHG6015NUC|OTHER              |VENTILATION        |
|PRG486WDG |OTHER              |COOKING            |
|PRG486WDH |OTHER              |COOKING            |
|HES3023C  |COOKING            |OTHER              |
|PODMCW31W |OTHER              |COOKING            |
|HES3053C  |COOKING            |OTHER              |
|DHL755BUC |VENTILATION        |OTHER              |
|DHG602DUC |OTHER              |VENTILATION        |
|PRG486WLG |OTHER              |COOKING            |
|PRG486WLH |OTHER              |COOKING            |
|MEDMCW31WS|OTHER              |COOKING            |
+----------+-------------------+-------------------+
+----------+-------------------+-------------------+
|MODEL_NO  |PRODUCT_CATEGORY_NM|PRODUCT_CATEGORY_NM|
+----------+-------------------+-------------------+
|DHG602DUC |OTHER              |VENTILATION        |
|PRG486WDG |OTHER              |COOKING            |
|PRG486WLH |OTHER              |COOKING            |
|MEDMCW31WS|OTHER              |COOKING            |
|PODMCW31W |OTHER              |COOKING            |
|HES3053C  |COOKING            |OTHER              |
|HES3023C  |COOKING            |OTHER              |
|DHG6015NUC|OTHER              |VENTILATION        |
|PRG486WDH |OTHER              |COOKING            |
|PRG486WLG |OTHER              |COOKING            |
|DHL755BUC |VENTILATION        |OTHER              |
+----------+-------------------+-------------------+

    -- 11 rows new phae out so price coming as NULL
    -- Pick last record which is not null from RAW latest
    --Last price is used in core
select distinct s.MODEL_NO,s.PRICE_AMT,c.PRICE_AMT,s.PRODUCT_CATEGORY_NM,c.PRODUCT_CATEGORY_NM,s.DO_NOT_SOLICIT_PRODUCT_IND,c.DO_NOT_SOLICIT_PRODUCT_IND
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or coalesce(s.PRICE_AMT,0) <> coalesce(c.PRICE_AMT,0) --
    )   and c.PRODUCT_CATEGORY_NM  <> 'OTHER' and s.PRICE_AMT is null ;


    -- 24 rows new phae out so price coming as NULL
select distinct s.BRAND_NM,s.MODEL_NO,s.PRICE_AMT,c.PRICE_AMT,s.PRICE_AMT-c.PRICE_AMT,s.PRODUCT_CATEGORY_NM,c.PRODUCT_CATEGORY_NM,s.DO_NOT_SOLICIT_PRODUCT_IND,c.DO_NOT_SOLICIT_PRODUCT_IND
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or coalesce(s.PRICE_AMT,0) <> coalesce(c.PRICE_AMT,0) --
    )
   and c.PRODUCT_CATEGORY_NM  <> 'OTHER'
   --and s.PRICE_AMT is not null
  --and  s.PRODUCT_CATEGORY_NM  <> 'OTHER'
Order by s.PRICE_AMT-c.PRICE_AMT;
--Product with Nodata so it not processed



select distinct s.BRAND_NM,s.MODEL_NO,s.PRICE_AMT,c.PRICE_AMT,s.PRICE_AMT-c.PRICE_AMT,s.PRODUCT_CATEGORY_NM,c.PRODUCT_CATEGORY_NM,s.DO_NOT_SOLICIT_PRODUCT_IND,c.DO_NOT_SOLICIT_PRODUCT_IND
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or coalesce(s.PRICE_AMT,0) <> coalesce(c.PRICE_AMT,0) --
    )
   and c.PRODUCT_CATEGORY_NM  <> 'OTHER'
   and s.PRICE_AMT is not null
  and  s.PRODUCT_CATEGORY_NM  <> 'OTHER'
Order by s.PRICE_AMT-c.PRICE_AMT;
--Product with Nodata so it not processed
+---------+----------+---------+---------+-----------------------+--------------------+--------------------+--------------------------+--------------------------+
|BRAND_NM |MODEL_NO  |PRICE_AMT|PRICE_AMT|S.PRICE_AMT-C.PRICE_AMT|PRODUCT_CATEGORY_NM |PRODUCT_CATEGORY_NM |DO_NOT_SOLICIT_PRODUCT_IND|DO_NOT_SOLICIT_PRODUCT_IND|
+---------+----------+---------+---------+-----------------------+--------------------+--------------------+--------------------------+--------------------------+
|Thermador|T30IF905SP|7999.00  |8499.00  |-500                   |REFRIGERATION W LOSS|REFRIGERATION W LOSS|N                         |N                         |
|Thermador|T30IR905SP|7999.00  |8499.00  |-500                   |REFRIGERATION W LOSS|REFRIGERATION W LOSS|N                         |N                         |
|Thermador|CET305TB  |1899.00  |1799.00  |100                    |COOKING             |COOKING             |N                         |N                         |
|Gaggenau |DV461710  |3799.00  |3599.00  |200                    |COOKING             |COOKING             |N                         |N                         |
|Gaggenau |DV463710  |3999.00  |3799.00  |200                    |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD484WCHU|13799.00 |12599.00 |1200                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD484WCGU|14949.00 |13649.00 |1300                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD486WLHU|13599.00 |12199.00 |1400                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD486WLGU|14849.00 |13349.00 |1500                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD48WCSGU|17899.00 |16099.00 |1800                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD486WDHU|14299.00 |12199.00 |2100                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD486WIGU|15999.00 |13899.00 |2100                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD486WDGU|15549.00 |13349.00 |2200                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD48WDSGU|18099.00 |15449.00 |2650                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD606WEG |20099.00 |17449.00 |2650                   |COOKING             |COOKING             |N                         |N                         |
|Thermador|PRD48WISGU|19149.00 |16399.00 |2750                   |COOKING             |COOKING             |N                         |N                         |
+---------+----------+---------+---------+-----------------------+--------------------+--------------------+--------------------------+--------------------------+



--Send mail of price variation
--But we process is same as other price change
+----------+---------+---------+-----------------------+--------------------+--------------------+--------------------------+--------------------------+
|MODEL_NO  |PRICE_AMT|PRICE_AMT|S.PRICE_AMT-C.PRICE_AMT|PRODUCT_CATEGORY_NM |PRODUCT_CATEGORY_NM |DO_NOT_SOLICIT_PRODUCT_IND|DO_NOT_SOLICIT_PRODUCT_IND|
+----------+---------+---------+-----------------------+--------------------+--------------------+--------------------------+--------------------------+
|T30IF905SP|7999.00  |8499.00  |-500                   |REFRIGERATION W LOSS|REFRIGERATION W LOSS|N                         |N                         |
|T30IR905SP|7999.00  |8499.00  |-500                   |REFRIGERATION W LOSS|REFRIGERATION W LOSS|N                         |N                         |
+----------+---------+---------+-----------------------+--------------------+--------------------+--------------------------+--------------------------+



--Price changed for all 27 rows for not null case
select distinct s.MODEL_NO,s.PRICE_AMT,c.PRICE_AMT
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT <> c.PRICE_AMT --414
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null

;
+----------+---------+---------+
|MODEL_NO  |PRICE_AMT|PRICE_AMT|
+----------+---------+---------+
|DHL755BUC |749.00   |649.00   |
|PRG486WLG |12849.00 |11549.00 |
|PRD484WCGU|14949.00 |13649.00 |
|T30IF905SP|7999.00  |8499.00  |
|DV461710  |3799.00  |3599.00  |
|PRD486WDGU|15549.00 |13349.00 |
|PRD606WEG |20099.00 |17449.00 |
|PODMCW31W |10499.00 |9099.00  |
|PRG486WLH |11499.00 |10399.00 |
|MEDMCW31WS|9799.00  |8499.00  |
|PRD48WISGU|19149.00 |16399.00 |
|PRD48WCSGU|17899.00 |16099.00 |
|PRD48WDSGU|18099.00 |15449.00 |
|PRD486WLGU|14849.00 |13349.00 |
|PRG486WDG |12299.00 |11549.00 |
|PRG486WDH |11499.00 |10399.00 |
|DV463710  |3999.00  |3799.00  |
|VTD600P   |849.00   |549.00   |
|PRD486WLHU|13599.00 |12199.00 |
|PRD486WDHU|14299.00 |12199.00 |
|CET305TB  |1899.00  |1799.00  |
|DHG602DUC |739.00   |499.00   |
|PRD486WIGU|15999.00 |13899.00 |
|VTN1090R  |899.00   |719.00   |
|DHG6015NUC|589.00   |519.00   |
|PRD484WCHU|13799.00 |12599.00 |
|T30IR905SP|7999.00  |8499.00  |
+----------+---------+---------+



-- 25 rows have new price increased
select Count(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT > c.PRICE_AMT --
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;



-- 12 rows have less price new value
select s.MODEL_NO,s.PRICE_AMT,c.PRICE_AMT
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT < c.PRICE_AMT --
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;

-- PRICE_AMT,PRICE_AMT
-- 1399.00,1499.00
-- 4799.00,4999.00
-- 7999.00,8399.00
-- 7499.00,7599.00
-- 7999.00,8399.00
-- 5999.00,6499.00
-- 6499.00,6949.00
-- 6999.00,7599.00
-- 3799.00,4199.00
-- 1649.00,1749.00
-- 7499.00,7599.00
-- 7499.00,7599.00


-- All coloumns with list of data with compare STG and Core--312
select s.BRAND_NM AS BRAND_NM_stg , c.BRAND_NM AS BRAND_NM_CORE
       ,s.PRODUCT_CATEGORY_NM AS PRODUCT_CATEGORY_NM_stg , c.PRODUCT_CATEGORY_NM AS PRODUCT_CATEGORY_NM_CORE
     ,s.PRICE_AMT AS PRICE_AMT_stg , c.PRICE_AMT AS PRICE_AMT_CORE
     ,s.DO_NOT_SOLICIT_PRODUCT_IND AS DNS_stg , c.DO_NOT_SOLICIT_PRODUCT_IND AS DNS_CORE
      ,s.Product_Coverage_End_Dt AS Product_Coverage_End_Dt_stg , c.Product_Coverage_End_Dt AS Product_Coverage_End_Dt_CORE
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.BRAND_NM <> c.BRAND_NM
      or s.PRICE_AMT <> c.PRICE_AMT
      or s.PRODUCT_CATEGORY_NM <>  c.PRODUCT_CATEGORY_NM --0
     or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt
     or s.DO_NOT_SOLICIT_PRODUCT_IND <> c.DO_NOT_SOLICIT_PRODUCT_IND
    )   ;
