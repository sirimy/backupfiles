


create table  RAW_MODEL_MASTER_TBL_LATEST_2024_APRIL as
SELECT * FROM( SELECT    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
    FROM    BOSH.RAW_MODEL_MASTER_TBL  RMMT
    where lower(FILE_NM) like '%_afterinc.csv%' OR lower(FILE_NM) like '%_afterinc-bosch.csv%' OR lower(FILE_NM) like '%_afterinc-thermador%' )
WHERE r = 1
Order by FILE_NM
;--1,291 rows affected in 370 ms


select COUNT(distinct MATERIAL) from RAW_MODEL_MASTER_TBL_LATEST_2024_APRIL;--1291


SELECT distinct FILE_NM FROM( SELECT    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
    FROM    BOSH.RAW_MODEL_MASTER_TBL  RMMT
    where FILE_NM like '%_AfterInc.csv%' OR FILE_NM like '%_AfterInc-Bosch.csv%' OR FILE_NM like '%_AfterInc-Thermador%'

            )
WHERE r = 1
Order by FILE_NM
;


select * from RAW_MODEL_MASTER_TBL;

-- insert into RAW_MODEL_MASTER_TBL
-- select * from RAW_MODEL_MASTER_TBL_LATEST_2024_APRIL;


DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'set update key change ticket number', p_table_nm => 'RAW_MODEL_MASTER_TBL');

BEGIN

        update  RAW_MODEL_MASTER_TBL
            SET  INSERT_AUDIT_KEY = v_audit_key,FILE_NM = FILE_NM || '_BOSH-1512';

       COMMIT;

END;


update RAW_MODEL_MASTER_TBL set ERROR_DESC = '';

select distinct ERROR_DESC from RAW_MODEL_MASTER_TBL;


BEGIN PK_MODELMASTER.s_001_load_product_category_price_change ; END;


select * from PRODUCT_CATALOG_TBL;--414