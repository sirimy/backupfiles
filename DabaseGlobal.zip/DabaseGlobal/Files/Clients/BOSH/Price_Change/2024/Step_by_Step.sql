--1
create table  RAW_MODEL_MASTER_TBL_LATEST_2024_MAY as
SELECT * FROM( SELECT    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
    FROM    BOSH.RAW_MODEL_MASTER_TBL  RMMT
    where lower(FILE_NM) like '%_afterinc.csv%' OR lower(FILE_NM) like '%_afterinc-bosch.csv%' OR lower(FILE_NM) like '%_afterinc-thermador%' )
WHERE r = 1
Order by FILE_NM
;--

select COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST_2024_MAY;--1299
--2

insert into RAW_MODEL_MASTER_TBL
select MATERIAL              ,
    MATERIAL_DESCRIPTION     ,
    BRAND                    ,
    MATERIAL_GROUP           ,
    SALES_STATUS             ,
    VALID_FROM               ,
    EF_OUT_DATE              ,
    UPC_CODE                 ,
    NEW_BUSINESS_FIELD       ,
    PRODUCT_TYPE             ,
    MAP_UMRP                 ,
    SK_MARKETING_DESCRIPTION ,
    FILE_NM                  ,
    INSERT_AUDIT_KEY          ,
    UNIQUE_SEQ_NO             ,
    ERROR_DESC               from RAW_MODEL_MASTER_TBL_LATEST_2024_MAY;


select ERROR_DESC,COUNT(*) from RAW_MODEL_MASTER_TBL group by ERROR_DESC;
+-----------------------------------------------------------------------------------------------------------------------------------------------+--------+
|ERROR_DESC                                                                                                                                     |COUNT(*)|
+-----------------------------------------------------------------------------------------------------------------------------------------------+--------+
|Model exists in core. Checking in bosh.PRODUCT_DIM based upon (BRAND, MATERIAL, coalesce(MAP_UMRP, '0')                                        |1087    |
|Model exists in core with a different price                                                                                                    |24      |
|Model exists in core with a not null price                                                                                                     |51      |
|NULL                                                                                                                                           |47      |
|Model has been received in the past. Checking in bosh.raw_model_master_tbl based upon (BRAND, MATERIAL, MATERIAL_GROUP, coalesce(MAP_UMRP, '0')|86      |
|MATERIAL_GROUP is missing                                                                                                                      |4       |
+-----------------------------------------------------------------------------------------------------------------------------------------------+--------+



DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'BOSH-1512', p_table_nm => 'RAW_MODEL_MASTER_TBL');

BEGIN

        update  RAW_MODEL_MASTER_TBL
            SET  INSERT_AUDIT_KEY = v_audit_key,FILE_NM = FILE_NM || '_BOSH-1512',ERROR_DESC = '';

       COMMIT;

END;


select ERROR_DESC,COUNT(*) from RAW_MODEL_MASTER_TBL group by ERROR_DESC;
+----------+--------+
|ERROR_DESC|COUNT(*)|
+----------+--------+
|NULL      |1299    |
+----------+--------+


--3
BEGIN PK_MODELMASTER.s_001_load_product_category_price_change ; END;

--Final models going to participate
select COUNT(*) from PRODUCT_CATALOG_TBL; --1295

select COUNT(*) from product_dim; --1295
select * from  brand_dim;--3
select * from  product_category_dim;--7
select COUNT(*) from  product_attribute_xref;--5180

select PRODUCT_KEY from product_dim where MODEL_NO not in ('T30IF905SP',
'T30IR905SP','CET305TB','DV461710','DV463710','PRD484WCHU','PRD484WCGU',
'PRD486WLHU','PRD486WLGU','PRD48WCSGU','PRD486WDHU','PRD486WIGU','PRD486WDGU',
'PRD48WDSGU','PRD606WEG','PRD48WISGU');

--delete from product_dim where MODEL_NO not in ('T30IF905SP',
-- 'T30IR905SP','CET305TB','DV461710','DV463710','PRD484WCHU','PRD484WCGU',
-- 'PRD486WLHU','PRD486WLGU','PRD48WCSGU','PRD486WDHU','PRD486WIGU','PRD486WDGU',
-- 'PRD48WDSGU','PRD606WEG','PRD48WISGU');
select * from product_dim  ;--16

--delete from product_attribute_xref where PRODUCT_KEY not in (select PRODUCT_KEY from product_dim);

select * from product_attribute_xref where PRODUCT_KEY not in (select PRODUCT_KEY from product_dim);

    select PRODUCT_KEY,COUNT(*) from product_attribute_xref where PRODUCT_KEY   in (select PRODUCT_KEY from product_dim)
GROUP BY PRODUCT_KEY;--16X4

--${HOME}/jobs/scripts/session_script_new.sh -j "modelmaster/process.job" -l "${HOME}/logs/modelmaster/modelmaster.log"

insert into PRICING_SCHEME_DIM
Select * from BOSH.PRICING_SCHEME_DIM where END_DT > sysdate
        --and (lower(PRICING_SCHEME_NAME) like '%thermador%'     or lower(PRICING_SCHEME_NAME) like '%gaggenau%'    )
        and  (lower(PRICING_SCHEME_NAME) not like '%bosch%'     and upper(PRICING_SCHEME_NAME) not like '%BUILDER%'    )
        order by PRICING_SCHEME_KEY;

select * from PRICING_SCHEME_DIM;--19

select MAX(PRICING_SCHEME_KEY) from BOSH.PRICING_SCHEME_DIM;--188

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'BOSh-1512', p_table_nm => 'PRICING_SCHEME_DIM');
BEGIN
        update  PRICING_SCHEME_DIM
            SET  SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key
                 ,LOAD_DT = date'2024-05-08';
       COMMIT;
END;
++------------------+-------------------+-------------------+-------------------+----------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NAME|PRICING_SCHEME_DESC|PRICING_SCHEME_TYPE|END_DT    |
+------------------+-------------------+-------------------+-------------------+----------+
|200               |AM Gaggenau        |AM Gaggenau        |AM                 |2099-12-31|
|201               |AM Thermador       |AM Thermador       |AM                 |2099-12-31|
|202               |EB Gaggenau        |EB Gaggenau        |EB                 |2099-12-31|
|203               |EB Thermador       |EB Thermador       |EB                 |2099-12-31|
|204               |AO Gaggenau        |AO Gaggenau        |OOW                |2099-12-31|
|205               |AO Thermador       |AO Thermador       |OOW                |2099-12-31|
|206               |RN Thermador       |RN 3 Thermador     |RN                 |2099-12-31|
|207               |RN Thermador       |RN 4 Thermador     |RN                 |2099-12-31|
|208               |RN Thermador       |RN 5 Thermador     |RN                 |2099-12-31|
|209               |RN Thermador       |RN 6 Thermador     |RN                 |2099-12-31|
|210               |RN Thermador       |RN 7 Thermador     |RN                 |2099-12-31|
|211               |RN Thermador       |RN 8 Thermador     |RN                 |2099-12-31|
|212               |RN Thermador       |RN 9 Thermador     |RN                 |2099-12-31|
|213               |RO Thermador       |RO 3 Thermador     |OOW                |2099-12-31|
|214               |RO Thermador       |RO 4 Thermador     |OOW                |2099-12-31|
|215               |RO Thermador       |RO 5 Thermador     |OOW                |2099-12-31|
|216               |RO Thermador       |RO 6 Thermador     |OOW                |2099-12-31|
|217               |RO Thermador       |RO 7 Thermador     |OOW                |2099-12-31|
|218               |RO Thermador       |RO 8 Thermador     |OOW                |2099-12-31|
+------------------+-------------------+-------------------+-------------------+----------+

-- 200,AM Gaggenau,AM Gaggenau,2024-05-08
-- 201,AM Thermador,AM Thermador,2024-05-08
-- 202,EB Gaggenau,EB Gaggenau,2024-05-08
-- 203,EB Thermador,EB Thermador,2024-05-08
-- 204,AO Gaggenau,AO Gaggenau,2024-05-08
-- 205,AO Thermador,AO Thermador,2024-05-08
-- 206,RN Thermador,RN 3 Thermador,2024-05-08
-- 207,RN Thermador,RN 4 Thermador,2024-05-08
-- 208,RN Thermador,RN 5 Thermador,2024-05-08
-- 209,RN Thermador,RN 6 Thermador,2024-05-08
-- 210,RN Thermador,RN 7 Thermador,2024-05-08
-- 211,RN Thermador,RN 8 Thermador,2024-05-08
-- 212,RN Thermador,RN 9 Thermador,2024-05-08
-- 213,RO Thermador,RO 3 Thermador,2024-05-08
-- 214,RO Thermador,RO 4 Thermador,2024-05-08
-- 215,RO Thermador,RO 5 Thermador,2024-05-08
-- 216,RO Thermador,RO 6 Thermador,2024-05-08
-- 217,RO Thermador,RO 7 Thermador,2024-05-08
-- 218,RO Thermador,RO 8 Thermador,2024-05-08

select * from PRICING_SCHEME_DIM;--19

select PRD.PRODUCT_KEY,vp.BRAND_NM,vp.PRICE_AMT,COUNT(*),vp.MODEL_NO,vp.PRODUCT_NM from PRODUCT_PRICE_DIM PRD
    join V_PRODUCT VP on vp.PRODUCT_KEY = prd.PRODUCT_KEY
where PRD.PRODUCT_KEY in (
    select PRODUCT_KEY from BOSH.product_dim where MODEL_NO in
('T30IF905SP','T30IR905SP','CET305TB','DV461710','DV463710',
'PRD484WCHU','PRD484WCGU','PRD486WLHU','PRD486WLGU','PRD48WCSGU',
'PRD486WDHU','PRD486WIGU','PRD486WDGU','PRD48WDSGU','PRD606WEG','PRD48WISGU')
    )
GROUP BY PRD.PRODUCT_KEY,vp.BRAND_NM,vp.PRICE_AMT,vp.MODEL_NO,vp.PRODUCT_NM
Order by vp.BRAND_NM;
+-----------+---------+---------+--------+----------+----------------------------------------+
|PRODUCT_KEY|BRAND_NM |PRICE_AMT|COUNT(*)|MODEL_NO  |PRODUCT_NM                              |
+-----------+---------+---------+--------+----------+----------------------------------------+
|33374      |Gaggenau |3799.00  |6       |DV461710  |DV461710, vacuum-sealing drawer         |
|33376      |Gaggenau |3999.00  |6       |DV463710  |DV463710, vacuum-sealing drawer         |
|27466      |Thermador|14949.00 |40      |PRD484WCGU|PRD484WCGU, Dual Fuel Professional Range|
|27468      |Thermador|13799.00 |40      |PRD484WCHU|PRD484WCHU, Dual Fuel Professional Range|
|27470      |Thermador|15549.00 |52      |PRD486WDGU|PRD486WDGU, Dual Fuel Professional Range|
|27472      |Thermador|14299.00 |52      |PRD486WDHU|PRD486WDHU, Dual Fuel Professional Range|
|27474      |Thermador|15999.00 |52      |PRD486WIGU|PRD486WIGU, Dual Fuel Professional Range|
|27476      |Thermador|14849.00 |40      |PRD486WLGU|PRD486WLGU, Dual Fuel Professional Range|
|27478      |Thermador|13599.00 |52      |PRD486WLHU|PRD486WLHU, Dual Fuel Professional Range|
|27620      |Thermador|1899.00  |40      |CET305TB  |CET305TB, Touch Control Electric Cooktop|
|31388      |Thermador|17899.00 |48      |PRD48WCSGU|PRD48WCSGU, Dual Fuel Professional Range|
|31390      |Thermador|18099.00 |48      |PRD48WDSGU|PRD48WDSGU, Dual Fuel Professional Range|
|31394      |Thermador|19149.00 |48      |PRD48WISGU|PRD48WISGU, Dual Fuel Professional Range|
|31846      |Thermador|7999.00  |51      |T30IF905SP|T30IF905SP, Built-in Freezer Column     |
|31848      |Thermador|7999.00  |51      |T30IR905SP|T30IR905SP, Built-in Refrigerator Column|
+-----------+---------+---------+--------+----------+----------------------------------------+


Select STG.PRICING_SCHEME_KEY,stg.POLICY_KEY,stg.PRICING_SCHEME_DESC,stg.PRODUCT_KEY,STG.TERM_MONTHS,stg.POLICY_PRODUCT_XID,core.PRICING_SCHEME_KEY,core.PRICING_SCHEME_DESC,core.PRODUCT_KEY,core.TERM_MONTHS,core.POLICY_PRODUCT_XID from (
    select PRD.PRICING_SCHEME_KEY,prd.POLICY_KEY,psd.PRICING_SCHEME_DESC,PRD.PRODUCT_KEY,PRD.TERM_MONTHS,vp.BRAND_NM,vp.PRICE_AMT,PL.POLICY_PRODUCT_XID,COUNT(*),vp.MODEL_NO,vp.PRODUCT_NM from PRODUCT_PRICE_DIM PRD
        join V_PRODUCT VP on vp.PRODUCT_KEY = prd.PRODUCT_KEY
        join BOSH.POLICY_TBL PL on PL.POLICY_KEY = prd.POLICY_KEY
        join PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = prd.PRICING_SCHEME_KEY
    where PRD.PRODUCT_KEY not in (
        select PRODUCT_KEY from BOSH.product_dim where MODEL_NO in
        ('T30IF905SP','T30IR905SP','CET305TB','DV461710','DV463710',
        'PRD484WCHU','PRD484WCGU','PRD486WLHU','PRD486WLGU','PRD48WCSGU',
        'PRD486WDHU','PRD486WIGU','PRD486WDGU','PRD48WDSGU','PRD606WEG','PRD48WISGU')
            )
    GROUP BY PRD.PRICING_SCHEME_KEY,prd.POLICY_KEY,PRD.PRODUCT_KEY,PSD.PRICING_SCHEME_DESC,PRD.TERM_MONTHS,vp.BRAND_NM,vp.PRICE_AMT,vp.MODEL_NO,vp.PRODUCT_NM,PL.POLICY_PRODUCT_XID
    ) STG
LEFT JOIN
 (
    select PRD.PRICING_SCHEME_KEY,prd.POLICY_KEY,PSD.PRICING_SCHEME_DESC,PRD.PRODUCT_KEY,PRD.TERM_MONTHS,vp.BRAND_NM,vp.PRICE_AMT,PL.POLICY_PRODUCT_XID,COUNT(*),vp.MODEL_NO,vp.PRODUCT_NM from BOSH.PRODUCT_PRICE_DIM PRD
        join V_PRODUCT VP on vp.PRODUCT_KEY = prd.PRODUCT_KEY
        join BOSH.POLICY_TBL PL on PL.POLICY_KEY = prd.POLICY_KEY
        join BOSH.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = prd.PRICING_SCHEME_KEY
    where PRD.PRODUCT_KEY not in (
        select PRODUCT_KEY from BOSH.product_dim where MODEL_NO in
        ('T30IF905SP','T30IR905SP','CET305TB','DV461710','DV463710',
        'PRD484WCHU','PRD484WCGU','PRD486WLHU','PRD486WLGU','PRD48WCSGU',
        'PRD486WDHU','PRD486WIGU','PRD486WDGU','PRD48WDSGU','PRD606WEG','PRD48WISGU')
            )
    and psd.END_DT > sysdate and pl.EXP_DT > sysdate
    GROUP BY PRD.PRICING_SCHEME_KEY,prd.POLICY_KEY,PSD.PRICING_SCHEME_DESC,PRD.PRODUCT_KEY,PRD.TERM_MONTHS,vp.BRAND_NM,vp.PRICE_AMT,vp.MODEL_NO,vp.PRODUCT_NM,PL.POLICY_PRODUCT_XID
    ) CORE
On STG.PRODUCT_KEY = CORE.PRODUCT_KEY AND STG.PRICING_SCHEME_DESC = CORE.PRICING_SCHEME_DESC AND stg.TERM_MONTHS = core.TERM_MONTHS
--where Stg.POLICY_PRODUCT_XID <> core.POLICY_PRODUCT_XID
    Where stg.POLICY_KEY <> core.POLICY_KEY
Order By stg.PRODUCT_KEY,stg.PRICING_SCHEME_DESC,stg.TERM_MONTHS,core.TERM_MONTHS
;

--    whole table minus with all main columns


select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms, count(distinct ppd.PRODUCT_KEY)
from   P_product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
where
    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'
and psd.PRICING_SCHEME_DESC not like '%Bosch%'
and psd.PRICING_SCHEME_DESC not like '%BUILDER%'
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;

+-------------------+------------------+-------------------+----+-----------------------+----------+------------------------------+
|PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE |COUNT(DISTINCTTERM_KEY)|TERMS     |COUNT(DISTINCTPPD.PRODUCT_KEY)|
+-------------------+------------------+-------------------+----+-----------------------+----------+------------------------------+
|AM                 |152               |AM Gaggenau        |NULL|2                      |1, 3      |220                           |
|AM                 |153               |AM Thermador       |NULL|4                      |1, 3, 4, 5|488                           |
|EB                 |155               |EB Gaggenau        |NULL|2                      |1, 3      |220                           |
|EB                 |156               |EB Thermador       |NULL|4                      |1, 3, 4, 5|488                           |
|OOW                |158               |AO Gaggenau        |NULL|2                      |1, 3      |220                           |
|OOW                |159               |AO Thermador       |2   |2                      |1, 3      |9                             |
|OOW                |159               |AO Thermador       |NULL|2                      |1, 3      |479                           |
|OOW                |183               |RO 3 Thermador     |2   |2                      |1, 3      |9                             |
|OOW                |183               |RO 3 Thermador     |NULL|2                      |1, 3      |479                           |
|OOW                |184               |RO 4 Thermador     |2   |1                      |1         |9                             |
|OOW                |184               |RO 4 Thermador     |NULL|1                      |1         |479                           |
|OOW                |185               |RO 5 Thermador     |2   |1                      |1         |9                             |
|OOW                |185               |RO 5 Thermador     |NULL|1                      |1         |479                           |
|OOW                |186               |RO 6 Thermador     |2   |2                      |1, 3      |9                             |
|OOW                |186               |RO 6 Thermador     |NULL|2                      |1, 3      |479                           |
|OOW                |187               |RO 7 Thermador     |2   |1                      |1         |9                             |
|OOW                |187               |RO 7 Thermador     |NULL|1                      |1         |479                           |
|OOW                |188               |RO 8 Thermador     |2   |1                      |1         |9                             |
|OOW                |188               |RO 8 Thermador     |NULL|1                      |1         |479                           |
|RN                 |168               |RN 3 Thermador     |3   |4                      |1, 2, 3, 4|488                           |
|RN                 |169               |RN 4 Thermador     |4   |4                      |1, 2, 3, 4|488                           |
|RN                 |170               |RN 5 Thermador     |5   |4                      |1, 2, 3, 4|493                           |
|RN                 |171               |RN 6 Thermador     |6   |4                      |1, 2, 3, 4|488                           |
|RN                 |172               |RN 7 Thermador     |7   |3                      |1, 2, 3   |493                           |
|RN                 |173               |RN 8 Thermador     |8   |2                      |1, 2      |493                           |
|RN                 |174               |RN 9 Thermador     |9   |1                      |1         |493                           |
+-------------------+------------------+-------------------+----+-----------------------+----------+------------------------------+



select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms, count(distinct ppd.PRODUCT_KEY)
from   product_price_dim ppd
       join pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
where
    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
+-------------------+------------------+-------------------+----+-----------------------+----------+------------------------------+
|PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE |COUNT(DISTINCTTERM_KEY)|TERMS     |COUNT(DISTINCTPPD.PRODUCT_KEY)|
+-------------------+------------------+-------------------+----+-----------------------+----------+------------------------------+
|AM                 |200               |AM Gaggenau        |NULL|2                      |1, 3      |220                           |
|AM                 |201               |AM Thermador       |NULL|4                      |1, 3, 4, 5|487                           |
|EB                 |202               |EB Gaggenau        |NULL|2                      |1, 3      |220                           |
|EB                 |203               |EB Thermador       |NULL|4                      |1, 3, 4, 5|487                           |
|OOW                |204               |AO Gaggenau        |NULL|2                      |1, 3      |220                           |
|OOW                |205               |AO Thermador       |2   |2                      |1, 3      |12                            |
|OOW                |205               |AO Thermador       |NULL|2                      |1, 3      |475                           |
|OOW                |213               |RO 3 Thermador     |2   |2                      |1, 3      |12                            |
|OOW                |213               |RO 3 Thermador     |NULL|2                      |1, 3      |475                           |
|OOW                |214               |RO 4 Thermador     |2   |1                      |1         |12                            |
|OOW                |214               |RO 4 Thermador     |NULL|1                      |1         |475                           |
|OOW                |215               |RO 5 Thermador     |2   |1                      |1         |12                            |
|OOW                |215               |RO 5 Thermador     |NULL|1                      |1         |475                           |
|OOW                |216               |RO 6 Thermador     |2   |2                      |1, 3      |12                            |
|OOW                |216               |RO 6 Thermador     |NULL|2                      |1, 3      |475                           |
|OOW                |217               |RO 7 Thermador     |2   |1                      |1         |12                            |
|OOW                |217               |RO 7 Thermador     |NULL|1                      |1         |475                           |
|OOW                |218               |RO 8 Thermador     |2   |1                      |1         |12                            |
|OOW                |218               |RO 8 Thermador     |NULL|1                      |1         |475                           |
|RN                 |206               |RN 3 Thermador     |3   |4                      |1, 2, 3, 4|487                           |
|RN                 |207               |RN 4 Thermador     |4   |4                      |1, 2, 3, 4|487                           |
|RN                 |208               |RN 5 Thermador     |5   |4                      |1, 2, 3, 4|492                           |
|RN                 |209               |RN 6 Thermador     |6   |4                      |1, 2, 3, 4|487                           |
|RN                 |210               |RN 7 Thermador     |7   |3                      |1, 2, 3   |492                           |
|RN                 |211               |RN 8 Thermador     |8   |2                      |1, 2      |492                           |
|RN                 |212               |RN 9 Thermador     |9   |1                      |1         |492                           |
+-------------------+------------------+-------------------+----+-----------------------+----------+------------------------------+

