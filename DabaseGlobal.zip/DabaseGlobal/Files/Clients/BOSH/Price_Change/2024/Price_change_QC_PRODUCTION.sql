
select BRAND_NM,COUNT(*) from V_PRODUCT group by BRAND_NM;
+---------+--------+
|BRAND_NM |COUNT(*)|
+---------+--------+
|Thermador|1527    |
|Gaggenau |566     |
|Bosch    |2157    |
+---------+--------+


select PRODUCT_KEY from V_PRODUCT where BRAND_NM in ('Thermador','Gaggenau');

select * from PRICING_SCHEME_DIM order by PRICING_SCHEME_KEY;--Start with 200 -- 19 records
select * from BOSH.PRICING_SCHEME_DIM order by PRICING_SCHEME_KEY DESC;--End with 188

select COUNT(*) from PRODUCT_PRICE_DIM ;--21229
--21229

select COUNT(*) from BOSH.PRODUCT_PRICE_DIM PPD
    inner join AUDIT_TBL AT on AT.AUDIT_KEY = PPD.INSERT_AUDIT_KEY
                where  AT.CREATION_DT > sysdate -1;--0

--STG PRODUCT_PRICE_DIM count CTIVE_IND= 'Y'  20282
select COUNT(*) from PRODUCT_PRICE_DIM where  ACTIVE_IND= 'Y' ;--20282

--CORE PRODUCT_PRICE_DIM count CTIVE_IND= 'Y' 19870
select  COUNT(PRD.PRODUCT_KEY) from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.POLICY_TBL PL on PRD.POLICY_KEY = PL.POLICY_KEY
         where  ACTIVE_IND= 'Y'
           AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau')) AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
           and PSD.END_DT > sysdate  and PL.EXP_DT > sysdate ;--19870


--*****************************---------------------------------*****************************---

--STG count ALL 21229
select COUNT(*) from PRODUCT_PRICE_DIM   ;--21229

--CORE count ALL  21449
select  COUNT(PD.MODEL_NO) from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT > sysdate
           AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau')) AND PSD.PRICING_SCHEME_DESC <> 'BUILDER';

--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
-- For  0 model pricing not created this time
Select COUNT(Distinct MODEL_NO) from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where   ACTIVE_IND= 'Y'
           AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau')) AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
         and PD.DO_NOT_SOLICIT_PRODUCT_IND ='Y' AND PSD.END_DT > sysdate

MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY where  ACTIVE_IND= 'Y' and PD.DO_NOT_SOLICIT_PRODUCT_IND ='Y'
         );
--*****************************---------------------------------*****************************---
-- Desc last date is 2025-01-28
select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  --ACTIVE_IND= 'Y' and
              PSD.END_DT > sysdate AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
         AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
       --  where  ACTIVE_IND= 'Y'

         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'
Order by PRODUCT_COVERAGE_END_DT DESC
;

--*****************************---------------------------------*****************************---

--Only 1 models which passed NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'

select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y' AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
           and PSD.END_DT > sysdate AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y';

+-----------+--------------------------+-----------------------+---------+
|PRODUCT_KEY|DO_NOT_SOLICIT_PRODUCT_IND|PRODUCT_COVERAGE_END_DT|MODEL_NO |
+-----------+--------------------------+-----------------------+---------+
|31322      |N                         |2099-12-29             |PRD606WEG|
+-----------+--------------------------+-----------------------+---------+
 select * from V_PRODUCT where MODEL_NO = 'PRD606WEG';
+---------------------------------------+---------+---------+
|PRODUCT_DSC                            |PRICE_AMT|BRAND_NM |
+---------------------------------------+---------+---------+
|PRD606WEG, Dual Fuel Professional Range|20099.00 |Thermador|
+-----Price range is out------------------------------------+---------+---------+



-- For 1 model new pricing is not created for each Terms its present before
Select COUNT(Distinct MODEL_NO) from (
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT > sysdate AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
         AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
MINUS
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y' );
--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
-- For 37 model new pricing is not created for each Terms its present before
Select COUNT(Distinct MODEL_NO) from (
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT > sysdate AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
         AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
MINUS
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         );
--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
-- For 7 model new pricing it created

select distinct PRICING_SCHEME_KEY from PRODUCT_PRICE_DIM;

Select * from V_PRODUCT where PRODUCT_KEY in(
        select PRODUCT_KEY from PRODUCT_PRICE_DIM
            minus
        select PRD.PRODUCT_KEY from BOSH.PRODUCT_PRICE_DIM  PRD
            inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
            inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
                 where  PSD.END_DT > sysdate
                AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
                AND PSD.PRICING_SCHEME_DESC <> 'BUILDER')

;
+-----------+--------+--------+----------------------------------------+---------+
|PRODUCT_KEY|BRAND_NM|MODEL_NO|PRODUCT_NM                              |PRICE_AMT|
+-----------+--------+--------+----------------------------------------+---------+
|41010      |Bosch   |TIU20109|TIU20109, Fully Automatic Coffee Machine|699.00   |
|41022      |Bosch   |TQU60307|TQU60307, Fully Automatic Coffee Machine|1999.00  |
|41018      |Bosch   |TPU60501|TPU60501, Fully Automatic Coffee Machine|1799.00  |
|41012      |Bosch   |TIU20307|TIU20307, Fully Automatic Coffee Machine|799.00   |
|41014      |Bosch   |TIU20508|TIU20508, Fully Automatic Coffee Machine|899.00   |
|41024      |Bosch   |TQU60703|TQU60703, Fully Automatic Coffee Machine|2299.00  |
|41016      |Bosch   |TPU60309|TPU60309, Fully Automatic Coffee Machine|1599.00  |
+-----------+--------+--------+----------------------------------------+---------+

select distinct PRODUCT_KEY from PRODUCT_PRICE_DIM where PRODUCT_KEY in
                                      ( select PRODUCT_KEY from V_PRODUCT where BRAND_NM = 'Bosch' );--7


select COUNT(PRODUCT_KEY) from PRODUCT_PRICE_DIM where PRODUCT_KEY in
                                      ( select PRODUCT_KEY from V_PRODUCT where BRAND_NM = 'Bosch' );--375

Delete from PRODUCT_PRICE_DIM where PRODUCT_KEY in
                                      ( select PRODUCT_KEY from V_PRODUCT where BRAND_NM = 'Bosch' );--375

--1 model
Select  Distinct MODEL_NO from (

select  PSD.PRICING_SCHEME_DESC ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT > sysdate AND ACTIVE_IND= 'Y'  AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
          and PD.DO_NOT_SOLICIT_PRODUCT_IND ='N' AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'

MINUS

select  PSD.PRICING_SCHEME_DESC ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
    where ACTIVE_IND= 'Y'  and PD.DO_NOT_SOLICIT_PRODUCT_IND ='N'

)
;


--That 2 model whose pricing created
Select * from RAW_MODEL_MASTER_TBL where MATERIAL in ('PRD606WEG' );
+---------+---------------------------------------+---------+--------+--------------+------------+----------+
|MATERIAL |MATERIAL_DESCRIPTION                   |BRAND    |MAP_UMRP|MATERIAL_GROUP|SALES_STATUS|VALID_FROM|
+---------+---------------------------------------+---------+--------+--------------+------------+----------+
|PRD606WEG|PRD606WEG, Dual Fuel Professional Range|Thermador|20099   |noData        |On market   |02/18/2019|
+---------+---------------------------------------+---------+--------+--------------+------------+----------+



--*****************************---------------------------------*****************************---
--Pricing created for 297 models from latest RAW table
Select COUNT(*) from RAW_MODEL_MASTER_TBL where MATERIAL in (
select  PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY)
    and ERROR_DESC is NULL;
--*****************************---------------------------------*****************************---

--*****************************---------------------------------*****************************---
--26 rows for each pricing scheme its created new pricing same as production
select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   product_price_dim ppd
       join pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
--*****************************---------------------------------*****************************---

--*****************************---------------------------------*****************************---
-- For 0 model pricing not created  with NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'
select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT   > sysdate AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))  AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y';




 --For these 0 model leads present in SERIALIZED_ITEM_DIM count is 439
 Select COUNT(*) from BOSH.SERIALIZED_ITEM_DIM where PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT > sysdate  AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
          AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y');
--*****************************---------------------------------*****************************---


 --For these 0 model leads present in SERIALIZED_ITEM_DIM this year count is 29
  Select COUNT(SID.PRODUCT_KEY) from BOSH.SERIALIZED_ITEM_DIM SID inner join AUDIT_TBL AT on SID.INSERT_AUDIT_KEY =AT.AUDIT_KEY
      where AT.CREATION_DT >= (SYSDATE -365 ) AND  SID.PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y' and
            PSD.END_DT > sysdate AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
          AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y');
--*****************************---------------------------------*****************************---

--For All No Price model witg all status of ACTIVE_IND model leads present in SERIALIZED_ITEM_DIM this year count is 29
   Select COUNT(SID.PRODUCT_KEY) from BOSH.SERIALIZED_ITEM_DIM SID inner join AUDIT_TBL AT on SID.INSERT_AUDIT_KEY =AT.AUDIT_KEY
      where AT.CREATION_DT >= (SYSDATE -365 ) AND  SID.PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (select MODEL_NO
  from BOSh.V_PRODUCT
  where MODEL_NO in (Select Distinct MODEL_NO
                     from (select PSD.PRICING_SCHEME_NAME, PD.MODEL_NO
                           from BOSH.PRODUCT_PRICE_DIM PRD
                                    inner join BOSH.PRICING_SCHEME_DIM PSD
                                               on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                                    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
                           where --ACTIVE_IND= 'Y' and
                                 PSD.END_DT > sysdate AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
                                 AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
                           MINUS
                           select PSD.PRICING_SCHEME_NAME, PD.MODEL_NO
                           from PRODUCT_PRICE_DIM PRD
                                    inner join PRICING_SCHEME_DIM PSD
                                               on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                                    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
                              --  where  ACTIVE_IND= 'Y'
                          ))
    and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'))
;


Select Distinct MODEL_NO
     from (select PSD.PRICING_SCHEME_NAME, PD.MODEL_NO
           from BOSH.PRODUCT_PRICE_DIM PRD
                    inner join BOSH.PRICING_SCHEME_DIM PSD
                               on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
           where ACTIVE_IND= 'Y' and
                 PSD.END_DT > sysdate AND PRD.PRODUCT_KEY in (select VP.PRODUCT_KEY from V_PRODUCT VP where VP.BRAND_NM in ('Thermador','Gaggenau'))
           AND PSD.PRICING_SCHEME_DESC <> 'BUILDER'
           MINUS
           select PSD.PRICING_SCHEME_NAME, PD.MODEL_NO
           from PRODUCT_PRICE_DIM PRD
                    inner join PRICING_SCHEME_DIM PSD
                               on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
                where  ACTIVE_IND= 'Y'
          );
--PRD606WEG
