
select * from RAW_MODEL_MASTER_TBL where MATERIAL in(
'NGM8058DD',
'SGV43B53UC',
'SHP865ZP5N',
'SHX84AAF5N',
'SHS843AF5N',
'SHP878ZP5N',
'WTG865H4UC',
'WTG86403UC',
'WTW87NH1UC',
'CG280210CA',
'CG280211CA',
'WT262700',
'WM262700',
'AA490711',
'T36IT903NP');


--BEGIN PK_MODELMASTER.s_001_load_product_category_price_change ; END


select * from PRODUCT_CATALOG_TBL where MODEL_NO in(
'NGM8058DD',
'SGV43B53UC',
'SHP865ZP5N',
'SHX84AAF5N',
'SHS843AF5N',
'SHP878ZP5N',
'WTG865H4UC',
'WTG86403UC',
'WTW87NH1UC',
'CG280210CA',
'CG280211CA',
'WT262700',
'WM262700',
'AA490711',
'T36IT903NP');


select * from product_dim where MODEL_NO in(
'NGM8058DD',
'SGV43B53UC',
'SHP865ZP5N',
'SHX84AAF5N',
'SHS843AF5N',
'SHP878ZP5N',
'WTG865H4UC',
'WTG86403UC',
'WTW87NH1UC',
'CG280210CA',
'CG280211CA',
'WT262700',
'WM262700',
'AA490711',
'T36IT903NP');



select COUNT(*) from PRODUCT_CATALOG_TBL;--1287

select * from  brand_lkp;--0
select * from product_lkp;--0
select * from  product_category_lkp;--0

select COUNT(*) from product_dim; --1287

select * from  brand_dim;--3

select * from  product_category_dim;--7

select COUNT(*) from  product_attribute_xref;--1287X4=5148