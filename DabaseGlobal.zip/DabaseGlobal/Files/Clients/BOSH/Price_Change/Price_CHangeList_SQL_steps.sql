

select MATERIAL_GROUP,COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST GROUP BY MATERIAL_GROUP;

select COUNT(distinct MATERIAL ) from RAW_MODEL_MASTER_TBL_LATEST   ;--5187

select distinct c.PRODUCT_CATEGORY_NM from bosh.V_PRODUCT c;
+---------------------+
|PRODUCT_CATEGORY_NM  |
+---------------------+
|LAUNDRY-DRYER        |
|REFRIGERATION W LOSS |
|DISHWASHER           |
|LAUNDRY-WASHER       |
|BUILT-IN COFFEE MAKER|
|VENTILATION          |
|OTHER                |
|COOKING              |
+---------------------+
-- [1] BRAND
-- [2] Category
-- [3] Material Group
-- [4] Model Number
-- [5] MSRP (old and new)
-- [6] DNS FLAG
-- [8] Sales Status
-- [7] Product Coverage end date

--Model group missing mail

select SRC.brand_nm,
        product_category_nm
        ,tgt.MATERIAL_GROUP
        , model_no,
        price_amt
        ,tgt.MAP_UMRP,(tgt.MAP_UMRP - SRC.PRICE_AMT) DIFF
        ,dns
        ,tgt.SALES_STATUS
        , product_coverage_end_dt
        ,AT2.CREATION_DT
from RAW_MODEL_MASTER_TBL_LATEST tgt
Inner join AUDIT_TBL AT2 on tgt.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
inner join (select c.BRAND_NM,c.PRODUCT_CATEGORY_NM, c.MODEL_NO,c.DO_NOT_SOLICIT_PRODUCT_IND DNS,c.PRODUCT_COVERAGE_END_DT, coalesce(c.PRICE_AMT, 0) as PRICE_AMT
from bosh.V_PRODUCT c   where c.PRODUCT_CATEGORY_NM  <> 'OTHER') src
 on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0) and AT2.CREATION_DT > date '2023-01-01'
     AND tgt.MATERIAL in(
         select distinct s.MODEL_NO
                  from V_PRODUCT_STG s
                       join bosh.V_PRODUCT c
                          on c.PRODUCT_KEY = s.PRODUCT_KEY
                 where (
                       1=2
                      or s.PRICE_AMT <> c.PRICE_AMT --414
                    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null
         )
Order by src.BRAND_NM,PRODUCT_CATEGORY_NM
;--40


select SRC.brand_nm,
        product_category_nm
        ,tgt.MATERIAL_GROUP
        , model_no,
        price_amt
        ,tgt.MAP_UMRP,(tgt.MAP_UMRP - SRC.PRICE_AMT) DIFF
        ,dns
        ,tgt.SALES_STATUS
        , product_coverage_end_dt
        ,AT2.CREATION_DT
from RAW_MODEL_MASTER_TBL_LATEST tgt
Inner join AUDIT_TBL AT2 on tgt.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
inner join (select c.BRAND_NM,c.PRODUCT_CATEGORY_NM, c.MODEL_NO,c.DO_NOT_SOLICIT_PRODUCT_IND DNS,c.PRODUCT_COVERAGE_END_DT, coalesce(c.PRICE_AMT, 0) as PRICE_AMT
from bosh.V_PRODUCT c   --where c.PRODUCT_CATEGORY_NM  <> 'OTHER'
                        ) src
 on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
     where --to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0) and AT2.CREATION_DT > date '2023-01-01' AND
      tgt.MATERIAL in(
                    'T36IT903NP',
                    'CG280210CA',
                    'AA490711',
                    'SHX84AAF5N',
                    'SGV43B53UC',
                    'NGM8058DD',
                    'SHS843AF5N',
                    'WM262700',
                    'SHP865ZP5N',
                    'CG280211CA',
                    'SHP878ZP5N'
         )
Order by src.BRAND_NM,PRODUCT_CATEGORY_NM
;--40


select * from   RAW_MODEL_MASTER_TBL_LATEST_2024_APRIL tgt  where --to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0) and AT2.CREATION_DT > date '2023-01-01' AND
      tgt.MATERIAL in(
                    'DHG6015NUC',
                    'DHG602DUC ',
                    'PRG486WDG ',
                    'PRG486WDH ',
                    'PRG486WLH ',
                    'MEDMCW31WS',
                    'PRG486WLG ',
                    'PODMCW31W '
         );

select SRC.brand_nm,
        product_category_nm
        ,tgt.MATERIAL_GROUP
     ,tgt.FILE_NM
     ,tgt.ERROR_DESC
        , model_no,
        price_amt
        ,tgt.MAP_UMRP,(tgt.MAP_UMRP - SRC.PRICE_AMT) DIFF
        ,dns
        ,tgt.SALES_STATUS
        , product_coverage_end_dt
        ,AT2.CREATION_DT
from RAW_MODEL_MASTER_TBL_LATEST tgt
Inner join AUDIT_TBL AT2 on tgt.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
inner join (select c.BRAND_NM,c.PRODUCT_CATEGORY_NM, c.MODEL_NO,c.DO_NOT_SOLICIT_PRODUCT_IND DNS,c.PRODUCT_COVERAGE_END_DT, coalesce(c.PRICE_AMT, 0) as PRICE_AMT
from bosh.V_PRODUCT c   where c.PRODUCT_CATEGORY_NM  <> 'OTHER') src
 on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0) and AT2.CREATION_DT > date '2023-01-01'
     AND tgt.MATERIAL not in(
         select distinct s.MODEL_NO
                  from V_PRODUCT_STG s
                       join bosh.V_PRODUCT c
                          on c.PRODUCT_KEY = s.PRODUCT_KEY
                 where (
                       1=2
                      or s.PRICE_AMT <> c.PRICE_AMT --414
                    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null
         )
   and  (lower(tgt.FILE_NM) like '%_afterinc.csv%' OR lower(FILE_NM) like '%_afterinc-bosch.csv%' OR lower(FILE_NM) like '%_afterinc-thermador%' )
Order by src.BRAND_NM,PRODUCT_CATEGORY_NM
;--40



select SRC.brand_nm,
        product_category_nm
        ,tgt.MATERIAL_GROUP
     ,tgt.FILE_NM
     ,tgt.ERROR_DESC
        , model_no,
        price_amt
        ,tgt.MAP_UMRP,(tgt.MAP_UMRP - SRC.PRICE_AMT) DIFF
        ,dns
        ,tgt.SALES_STATUS
        , product_coverage_end_dt
        ,AT2.CREATION_DT
from RAW_MODEL_MASTER_TBL_LATEST tgt
Inner join AUDIT_TBL AT2 on tgt.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
inner join (select c.BRAND_NM,c.PRODUCT_CATEGORY_NM, c.MODEL_NO,c.DO_NOT_SOLICIT_PRODUCT_IND DNS,c.PRODUCT_COVERAGE_END_DT, coalesce(c.PRICE_AMT, 0) as PRICE_AMT
from bosh.V_PRODUCT c   where c.PRODUCT_CATEGORY_NM  <> 'OTHER') src
 on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0) and AT2.CREATION_DT > date '2023-01-01'
     AND tgt.MATERIAL not in(
                select distinct s.MODEL_NO
                  from V_PRODUCT_STG s
                       join bosh.V_PRODUCT c
                          on c.PRODUCT_KEY = s.PRODUCT_KEY
                 where (
                       1=2
                      or coalesce(s.PRICE_AMT,0) <> coalesce(c.PRICE_AMT,0) --
                    )   and c.PRODUCT_CATEGORY_NM  <> 'OTHER'
         )
   and  (lower(tgt.FILE_NM) like '%_afterinc.csv%' OR lower(FILE_NM) like '%_afterinc-bosch.csv%' OR lower(FILE_NM) like '%_afterinc-thermador%' )
Order by src.BRAND_NM,PRODUCT_CATEGORY_NM
;--40


select FILE_NM,COUNT(*) from BOSH.RAW_MODEL_MASTER_TBL RMMT
    inner join AUDIT_TBL AT2 on AT2.AUDIT_KEY = RMMT.INSERT_AUDIT_KEY
    where RMMT.MATERIAL in ( SELECT t.MODEL FROM BOSHSTG.OLD_MODELS_MISSING_CSV t)
    GROUP BY FILE_NM
;
+---------------------------------------------------------------+--------+
|FILE_NM                                                        |COUNT(*)|
+---------------------------------------------------------------+--------+
|Product Material Status Updated_BOSCH-THD_Pricing_5-17-2019    |631     |
|Serv_Plan_Prog_Master_Data_Update-07-19-16.csv                 |477     |
|model_master_update_11_17_16_final_12_05_16_BOSH-247.txt       |414     |
|Product_Material_Status_Updated_9-2017.txt                     |538     |
|Adhoc_Models_Jan2019.txt                                       |3       |
|Product_Material_Status_Updated_GAGGENAU_Pricing-02-25-2020.csv|123     |
|Text4Specs_Prod_List_Thermador_US_en_20200908_110247           |1       |
|5-17-2021 JR - Missing Models Apr14-2021 V2                    |4       |
|After_Inc-Bosch.csv                                            |2       |
|After_Inc-Gaggenau.csv                                         |2       |
+---------------------------------------------------------------+--------+



select MAX(AT2.CREATION_DT),MIN(AT2.CREATION_DT),COUNT(distinct MATERIAL) from BOSH.RAW_MODEL_MASTER_TBL RMMT
    inner join AUDIT_TBL AT2 on AT2.AUDIT_KEY = RMMT.INSERT_AUDIT_KEY
    where RMMT.MATERIAL in ( SELECT t.MODEL FROM BOSHSTG.OLD_MODELS_MISSING_CSV t)
        AND
        (FILE_NM like '%_AfterInc-Bosch%' OR
         FILE_NM like '%_AfterInc-Thermador_%' OR
         FILE_NM like '%_AfterInc.csv' )
;
+--------------------------+--------------------------+-----------------------+
|MAX(AT2.CREATION_DT)      |MIN(AT2.CREATION_DT)      |COUNT(DISTINCTMATERIAL)|
+--------------------------+--------------------------+-----------------------+
|2022-05-13 14:31:41.000000|2016-07-20 15:56:40.000000|758                    |
+--------------------------+--------------------------+-----------------------+

+------------------------------------------------------+
|FILE_NM                                               |
+------------------------------------------------------+
|20221021_033904_AfterInc.csv                          |
|20221021_033904_AfterInc-Thermador_20221003_083344.csv|
|20221206_022357_AfterInc.csv                          |
+------------------------------------------------------+

select Distinct FILE_NM from BOSH.RAW_MODEL_MASTER_TBL ;--5187

SELECT COUNT(Distinct MATERIAL) FROM( SELECT    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
    FROM    BOSH.RAW_MODEL_MASTER_TBL  RMMT)
WHERE r = 1;--5187


select * from RAW_MODEL_MASTER_TBL_LATEST;

insert into RAW_MODEL_MASTER_TBL_LATEST
SELECT * FROM( SELECT    RMMT.*,
    ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) r
    FROM    BOSH.RAW_MODEL_MASTER_TBL  RMMT)
WHERE r = 1;


select COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST where MATERIAL_GROUP <> 'Accessory' and MAP_UMRP is not null ;--3168



select COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST tgt
Inner join AUDIT_TBL AT2 on tgt.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT
from bosh.V_PRODUCT c   where c.PRICE_AMT is not null) src
 on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
        and AT2.CREATION_DT > date '2023-01-01';--83


SELECT COUNT(*) FROM BOSHSTG.OLD_MODELS_MISSING_CSV t;--758

SELECT COUNT(*) FROM BOSHSTG.NEW_MODELS_MISSING_CSV t;--886


SELECT * FROM BOSHSTG.NEW_MODELS_MISSING_CSV t
    where t.MODEL in ( select PD.MODEL_NO from BOSH.PRODUCT_DIM PD );--0




SELECT COUNT(*) FROM BOSHSTG.OLD_MODELS_MISSING_CSV t
    where t.MODEL in ( select PD.MODEL_NO from BOSH.PRODUCT_DIM PD );--758


SELECT * FROM BOSHSTG.NEW_MODELS_MISSING_CSV t
    where t.MODEL in ( select RMMT.MATERIAL from BOSH.RAW_MODEL_MASTER_TBL RMMT );--0

SELECT COUNT(*) FROM BOSHSTG.OLD_MODELS_MISSING_CSV t
    where t.MODEL in ( select RMMT.MATERIAL from BOSH.RAW_MODEL_MASTER_TBL RMMT );--758


select MAX(AT2.CREATION_DT),MIN(AT2.CREATION_DT),COUNT(distinct MATERIAL) from BOSH.RAW_MODEL_MASTER_TBL RMMT
    inner join AUDIT_TBL AT2 on AT2.AUDIT_KEY = RMMT.INSERT_AUDIT_KEY
    where RMMT.MATERIAL in ( SELECT t.MODEL FROM BOSHSTG.OLD_MODELS_MISSING_CSV t)
;
+--------------------------+--------------------------+-----------------------+
|MAX(AT2.CREATION_DT)      |MIN(AT2.CREATION_DT)      |COUNT(DISTINCTMATERIAL)|
+--------------------------+--------------------------+-----------------------+
|2022-05-13 14:31:41.000000|2016-07-20 15:56:40.000000|758                    |
+--------------------------+--------------------------+-----------------------+


select MAX(AT2.CREATION_DT),MIN(AT2.CREATION_DT),COUNT(distinct MODEL_NO) from BOSH.SERIALIZED_ITEM_DIM SID
inner join AUDIT_TBL AT2 on AT2.AUDIT_KEY = SID.INSERT_AUDIT_KEY
where SID.MODEL_NO in ( SELECT t.MODEL FROM BOSHSTG.OLD_MODELS_MISSING_CSV t);

select to_char(AT2.CREATION_DT, 'YYYY') ,COUNT(distinct MODEL_NO) from BOSH.SERIALIZED_ITEM_DIM SID
inner join AUDIT_TBL AT2 on AT2.AUDIT_KEY = SID.INSERT_AUDIT_KEY
where SID.MODEL_NO in ( SELECT t.MODEL FROM BOSHSTG.OLD_MODELS_MISSING_CSV t)
Group by to_char(AT2.CREATION_DT, 'YYYY')
Order by to_char(AT2.CREATION_DT, 'YYYY')
;
+-------------------------------+-----------------------+
|TO_CHAR(AT2.CREATION_DT,'YYYY')|COUNT(DISTINCTMODEL_NO)|
+-------------------------------+-----------------------+
|2016                           |385                    |
|2017                           |535                    |
|2018                           |588                    |
|2019                           |593                    |
|2020                           |739                    |
|2021                           |725                    |
|2022                           |696                    |
|2023                           |745                    |
|2024                           |578                    |
+-------------------------------+-----------------------+



select INSERT_AUDIT_KEY,RMMT.MATERIAL,RMMT.MAP_UMRP,RMMT.SALES_STATUS,AT2.CREATION_DT from BOSH.RAW_MODEL_MASTER_TBL RMMT
    inner join AUDIT_TBL AT2 on AT2.AUDIT_KEY = RMMT.INSERT_AUDIT_KEY
    where RMMT.MATERIAL in (
--                            'SHP878ZP5N'
--'SGV43B53UC'
--'SHS843AF5N',
--                             'SHX84AAF5N'
                            'SHP865ZP5N'
                            )
    GROUP BY FILE_NM,INSERT_AUDIT_KEY,RMMT.MATERIAL,RMMT.MAP_UMRP,AT2.CREATION_DT,RMMT.SALES_STATUS
    ORDER BY RMMT.MATERIAL,INSERT_AUDIT_KEY;