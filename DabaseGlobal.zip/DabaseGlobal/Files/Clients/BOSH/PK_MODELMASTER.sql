create PACKAGE BODY         PK_MODELMASTER
IS

   --C_DB_NAME              CONSTANT VARCHAR2(30)  := SYS_CONTEXT ('USERENV', 'DB_NAME');
   --C_CORE_USER            CONSTANT VARCHAR2(30)  := SUBSTR(SYS_CONTEXT ('USERENV', 'SESSION_USER'), 1, 4);
   C_CRLF                 CONSTANT VARCHAR2(4)       := CHR(13) || CHR(10);


   PROCEDURE s_001_load_product_category
   IS
      L_INSERT_AUDIT_KEY   NUMBER := 0;
   BEGIN


      update RAW_MODEL_MASTER_TBL set unique_seq_no = unique_seq.nextval
      where unique_seq_no is null;

      COMMIT;


      UPDATE RAW_MODEL_MASTER_TBL SET
        MATERIAL                  = replace(MATERIAL,chr(13)),
        MATERIAL_DESCRIPTION      = replace(MATERIAL_DESCRIPTION,chr(13)),
        BRAND                     = replace(BRAND,chr(13)),
        MATERIAL_GROUP            = replace(MATERIAL_GROUP,chr(13)),
        SALES_STATUS              = replace(SALES_STATUS,chr(13)),
        VALID_FROM                = replace(VALID_FROM,chr(13)),
        EF_OUT_DATE               = replace(EF_OUT_DATE,chr(13)),
        UPC_CODE                  = replace(UPC_CODE,chr(13)),
        NEW_BUSINESS_FIELD        = replace(NEW_BUSINESS_FIELD,chr(13)),
        PRODUCT_TYPE              = replace(PRODUCT_TYPE,chr(13)),
        MAP_UMRP                  = replace(MAP_UMRP,chr(13)),
        SK_MARKETING_DESCRIPTION    = replace(SK_MARKETING_DESCRIPTION,chr(13));

      COMMIT;

      --UPDATE_FUNCTION('RAW_MODEL_MASTER_TBL','INITCAP');
      UPDATE_FUNCTION('RAW_MODEL_MASTER_TBL','TRIM');

      update RAW_MODEL_MASTER_TBL SET MATERIAL = UPPER(MATERIAL);

      update RAW_MODEL_MASTER_TBL set map_umrp = null where map_umrp = '#N/A';

      update RAW_MODEL_MASTER_TBL set map_umrp = replace(map_umrp,'$','');

      update RAW_MODEL_MASTER_TBL set map_umrp = replace(map_umrp,',','');


      update RAW_MODEL_MASTER_TBL set error_desc = 'MATERIAL_GROUP is missing' where trim(MATERIAL_GROUP) is null;
      update RAW_MODEL_MASTER_TBL set error_desc = 'Error' where trim(MATERIAL_GROUP) = 'Z- Obsolete' and trim(MATERIAL_DESCRIPTION) is null;
      update RAW_MODEL_MASTER_TBL set error_desc = 'Error' where trim(MATERIAL_GROUP) = 'Nodata';
      update RAW_MODEL_MASTER_TBL set error_desc = 'MATERIAL is missing' where trim(MATERIAL) is null;



      ----------------------------------------------------------
      --These were manual updates but moved these here in the package until we decide what to do with these records
      ----------------------------------------------------------
      --Here suppressing records if they have been received in new model masters ('After_Inc-%.csv') in the past already.
      --New check added if pricing for model exist or not
      --and MATERIAL in (select PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM PPD inner join BOSH.PRODUCT_DIM PD on PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
      --------------------------------------------------------------------
    update raw_model_master_tbl
       set ERROR_DESC = 'Model has been received in the past. Checking in bosh.raw_model_master_tbl based upon (BRAND, MATERIAL, MATERIAL_GROUP, coalesce(MAP_UMRP, ''0'')'
     where (BRAND, MATERIAL, MATERIAL_GROUP, coalesce(MAP_UMRP, '0')) in (
              select c.BRAND, c.MATERIAL, c.MATERIAL_GROUP, coalesce(c.MAP_UMRP, '0')
                from bosh.raw_model_master_tbl c where c.FILE_NM like 'After_Inc-%.csv'
           )
        and MATERIAL in (select PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM PPD
        inner join BOSH.PRODUCT_DIM PD on PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
       and ERROR_DESC is null;
    --557 rows
    commit;

      --Here suppressing records if they exists in core already...these may have been received in the old masters in the past
    update raw_model_master_tbl
       set ERROR_DESC = 'Model exists in core. Checking in bosh.PRODUCT_DIM based upon (BRAND, MATERIAL, coalesce(MAP_UMRP, ''0'')'
     where (BRAND, MATERIAL, to_number(coalesce(MAP_UMRP, '0'))) in (
              select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) from bosh.V_PRODUCT c
           )
--         and MATERIAL in (select PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM PPD
--         inner join BOSH.PRODUCT_DIM PD on PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
       and ERROR_DESC is null;
    -- 7 rows
    commit;


      --Suppressing models if they have been received with a difference price as we are not going to process such models on a monthly basis
      --We will process such models max once in a quarter basis or may be once in half year
    merge into raw_model_master_tbl tgt
    using (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c
            where c.PRICE_AMT is not null) src
    on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
    when matched then
    update
       set ERROR_DESC = 'Model exists in core with a different price'
     where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
              and tgt.MATERIAL in (select PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM PPD
                inner join BOSH.PRODUCT_DIM PD on PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
       and ERROR_DESC is null;
    -- 387 rows
    commit;
    ----------------------------------------------------------


      --it was added on 4/8/2022
      update RAW_MODEL_MASTER_TBL
      set SK_MARKETING_DESCRIPTION =
            case
                when lower(MATERIAL_GROUP) = 'accessory' then 'Accessory'
                when lower(MATERIAL_GROUP) = 'built-in coffee machine' then 'Coffee Machine'
                --when lower(MATERIAL_GROUP) = 'complementary products' and MATERIAL_DESCRIPTION like '%Drawer' then 'Warming Drawers'
                when lower(MATERIAL_GROUP) = 'complementary products' then 'Complementary Products'
                when lower(MATERIAL_GROUP) = 'cooker' then 'Range'
                when lower(MATERIAL_GROUP) = 'dishwasher' then 'Dishwasher'
                when lower(MATERIAL_GROUP) = 'double oven' then 'Double Oven'
                when lower(MATERIAL_GROUP) = 'food processor' then 'Small Appliances'
                when lower(MATERIAL_GROUP) = 'freezer' then 'Freezer'
                when lower(MATERIAL_GROUP) = 'refrigerator' then 'Refrigerator'
                when lower(MATERIAL_GROUP) = 'fridge/freezer combination' then 'Refrigerator/Freezer'
                when lower(MATERIAL_GROUP) = 'hob' then 'Cooktop'
                when lower(MATERIAL_GROUP) = 'hood' then 'Ventilation'
                when lower(MATERIAL_GROUP) = 'microwave' then 'Microwave'
                when lower(MATERIAL_GROUP) = 'modular grill' then 'Cooktop'
                when lower(MATERIAL_GROUP) = 'modular hob' then 'Cooktop'
                when lower(MATERIAL_GROUP) = 'oven' then 'Oven'
                when lower(MATERIAL_GROUP) = 'platewarmer' then 'Warming Drawers'
                when lower(MATERIAL_GROUP) = 'side-by-side' then 'Refrigerator/Freezer'
                when lower(MATERIAL_GROUP) = 'washing machine' then 'Washer'
                --when lower(MATERIAL_GROUP) = 'washing machine' then 'Dryer'
                when lower(MATERIAL_GROUP) = 'winestorage' then 'Wine Column'
            end
      where SK_MARKETING_DESCRIPTION is null;


      update RAW_MODEL_MASTER_TBL
         set SK_MARKETING_DESCRIPTION = 'Refrigerator'
       where SK_MARKETING_DESCRIPTION = 'Refrgerator';

      update raw_model_master_tbl
         set SK_MARKETING_DESCRIPTION = 'Dryer'
      where upper(SK_MARKETING_DESCRIPTION) = 'LAUNDRY' and lower(material_group) like '%dryers%';

      update raw_model_master_tbl
         set SK_MARKETING_DESCRIPTION = 'Dishwashers'
       where MATERIAL_GROUP = 'Gaggenau Dishwashers' and SK_MARKETING_DESCRIPTION = 'Hoods';

      COMMIT;

      /*
      -- update the sku_marketing_description from core if its null
      merge into raw_model_master_tbl a
      using (
            select * from p_product_dim
            ) b
         on ( upper(a.material) = upper(b.model_no))
       when matched then
      update
        set a.SK_MARKETING_DESCRIPTION = b.marketing_product_nm
      where TRIM(a.SK_MARKETING_DESCRIPTION) is null
        and b.marketing_product_nm is not null;

      COMMIT;
       */

      --Dates are received in DD.MM.YYYY format. Converting to MM/DD/YYYY
      -- select pax.VALID_FROM, to_char(to_date(pax.VALID_FROM, 'DD/MM/YYYY'), 'MM/DD/YYYY') from raw_model_master_tbl pax;

      update raw_model_master_tbl
         set VALID_FROM = to_char(to_date(VALID_FROM, 'DD.MM.YYYY'), 'MM.DD.YYYY')
       where VALID_FROM is not null and instr(VALID_FROM, '.') > 0;

      update raw_model_master_tbl
         set EF_OUT_DATE = to_char(to_date(EF_OUT_DATE, 'DD.MM.YYYY'), 'MM.DD.YYYY')
       where EF_OUT_DATE is not null and instr(EF_OUT_DATE, '.') > 0;

      update raw_model_master_tbl
         set VALID_FROM = replace(VALID_FROM, '.', '/')
       where VALID_FROM is not null and instr(VALID_FROM, '.') > 0;

      update raw_model_master_tbl
         set EF_OUT_DATE = replace(EF_OUT_DATE, '.', '/')
       where EF_OUT_DATE is not null and instr(EF_OUT_DATE, '.') > 0;

      commit;



      L_INSERT_AUDIT_KEY := p_get_audit_key (p_program_nm   => 'PK_MODELMASTER.S_001_LOAD_PRODUCT_CATEGORY', p_table_nm     => 'PRODUCT_CATALOG_TBL');


        DELETE FROM PRODUCT_CATALOG_TBL;
        COMMIT;

        INSERT INTO PRODUCT_CATALOG_TBL
        (
        MARKETING_PRODUCT_NM,
        Product_Category_XID,
        Marketing_Product_Category_Nm,
        BRAND_UNIQUE_ID,
        BRAND_NM,
        BRAND_DSC,
        PRODUCT_UNIQUE_ID,
        Product_Nm,
        Product_Dsc,
        --MARKETING_PRODUCT_NM,
        MODEL_NO,
        SKU_NO,
        UPC_CD,
        PRICE_AMT,
        Do_Not_Solicit_Product_IND,
        INSERT_AUDIT_KEY,
        SOURCE_SYSTEM_CD,
        UNIQUE_SEQ_NO,
        PRODUCT_CATEGORY_UNIQUE_ID,
        PRODUCT_CATEGORY_DSC,
        Product_Category_NM
        )
        with m_group as (
            select Material as Material_with,
                   case when lower(material_group) like '%refrig%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%sbs%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like 'freezer%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like 'built in/built under%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                        when lower(material_group) like '%dish%' then 'DISHWASHER'
                        when lower(material_group) like '%hood%' then 'VENTILATION'
                        when lower(material_group) like '%ventilation%' then 'VENTILATION'
                        when lower(material_group) like '%oven%' then 'COOKING'
                        when lower(material_group) like '%cook%' then 'COOKING'
                        when lower(material_group) like '%range%' then 'COOKING'
                        when lower(material_group) like '%hob%' then 'COOKING'
                        when lower(material_group) like '%microwave%' then 'COOKING'
                        when lower(material_group) like '%warming drawers%' then 'COOKING'
                        when lower(material_group) like '%dryer%' then 'LAUNDRY-DRYER'
                        when lower(material_group) like '%frontloader%' then 'LAUNDRY-WASHER'
                        when lower(material_description) like '%washing machine%' then 'LAUNDRY-WASHER'
                        when lower(material_description) like '%dryer%' then 'LAUNDRY-DRYER'
                        ---
                        --these cases were added on 6/6/2019 by AJ
                        when lower(material_group) like '%vents%blowers%' then 'VENTILATION'
                        when lower(material_group) like '%fuel slide in%' then 'COOKING'
                        when lower(material_group) like '%gas slide in%' then 'COOKING'
                        when lower(material_group) like '%convection%' then 'COOKING'
                        ---
                        --these cases were added on 2/3/2021 by AJ
                        when lower(material_group) like '%fridge%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%side%by%side%' then 'REFRIGERATION W LOSS'
                       --added on 5/19/2021 by AJ
                        when lower(material_group) like '%washing machine%' then 'LAUNDRY-WASHER'
                        when lower(material_group) like '%freezer%' then 'REFRIGERATION W LOSS'
                       --added on 4/12/2022 by AJ
                       when lower(material_group) like '%plate%warmer%' then 'COOKING'
                       when lower(material_group) like '%modular grill%' then 'COOKING'
                       when lower(material_group) like '%winestorage%' then 'REFRIGERATION W LOSS'
                        else 'OTHER'
                    end as material_group_derived
            from RAW_MODEL_MASTER_TBL
        )
        SELECT
                SK_MARKETING_DESCRIPTION AS MARKETING_PRODUCT_NM,
                SK_MARKETING_DESCRIPTION as product_category_description, --PRODUCT_TYPE AS Product_Category_Description,
                --NEW_BUSINESS_FIELD AS Marketing_Product_Category_Nm,
                material_group_derived  as marketing_product_category_nm,
                BRAND AS Brand_ID,
                BRAND AS Brand_Name,
                BRAND AS Brand_Description,
                MATERIAL AS Product_ID,
                Material_Description AS Product_Name,
                Material_Description as product_descrition,
                Material AS Model_Number,
                UPC_CODE AS SKU_Number,
                UPC_CODE AS UPC_CD,
                MAP_UMRP AS PRICE_AMT,
                'N' as DO_NOT_SOLICIT_PRODUCT_IND,  -- we are setting as 'N' . DNS handling will be done by Post step which calls procedure "PK_MODEL_MASTER.s_002_update_dns_indicator"
                L_INSERT_AUDIT_KEY,
                1 AS SOURCE_SYSTEM_CD,
                UNIQUE_SEQ_NO,
                material_group_derived as PRODUCT_CATEGORY_UNIQUE_ID,
                material_group_derived AS PRODUCT_CATEGORY_DSC,
                material_group_derived as Product_Category_NM
        FROM  RAW_MODEL_MASTER_TBL r join m_group m on m.Material_with = r.Material
        WHERE ERROR_DESC IS NULL;

        COMMIT;

        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a where PRODUCT_DSC IS NULL ) b
        on (trim(lower(a.marketing_product_nm)) = trim(lower(b.marketing_product_nm))
            AND trim(lower(a.brand_unique_id)) = trim(lower(b.brand_nm))
           )
        when matched then update set a.thumbnail_image_link = b.image_link
        where thumbnail_image_link is null;


      merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a where PRODUCT_DSC IS NOT NULL ) b
        on (trim(lower(a.marketing_product_nm)) = trim(lower(b.marketing_product_nm))
            AND trim(lower(a.brand_unique_id)) = trim(lower(b.brand_nm))
           )
        when matched then update set a.thumbnail_image_link = b.image_link
        --where thumbnail_image_link is null
        ;


        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a
                                                 where trim(lower(marketing_product_nm)) = 'default') b
        on ( trim(lower(a.brand_unique_id)) = trim(lower(b.brand_nm)))
        when matched then update set a.thumbnail_image_link = b.image_link
        where thumbnail_image_link is null;

--        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a, brand_dim b
--                                                 where trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))) b
--        on (trim(lower(a.marketing_product_nm)) = trim(lower(b.marketing_product_nm))
--            AND trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))
--            AND A.PRODUCT_DSC IS NULL
--           )
--        when matched then update set a.thumbnail_image_link = b.image_link
--        where thumbnail_image_link is null;
--
--
--
--        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a, brand_dim b
--                                                 where trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))) b
--        on (trim(lower(a.marketing_product_nm)) = trim(lower(b.marketing_product_nm))
--            AND trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))
--            AND trim(lower(a.product_dsc)) = trim(lower(b.product_dsc))
--            AND A.PRODUCT_DSC IS NOT NULL
--           )
--        when matched then update set a.thumbnail_image_link = b.image_link;
--
--        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a, brand_dim b
--                                                 where trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))
--                                                 and trim(lower(marketing_product_nm)) = 'default') b
--        on ( trim(lower(a.brand_nm)) = trim(lower(b.brand_nm)))
--        when matched then update set a.thumbnail_image_link = b.image_link
--        where thumbnail_image_link is null;

        COMMIT;

   END ;



   PROCEDURE s_001_load_product_category_price_change
   IS
      L_INSERT_AUDIT_KEY   NUMBER := 0;
   BEGIN


      update RAW_MODEL_MASTER_TBL set unique_seq_no = unique_seq.nextval
      where unique_seq_no is null;

      COMMIT;


      UPDATE RAW_MODEL_MASTER_TBL SET
        MATERIAL                  = replace(MATERIAL,chr(13)),
        MATERIAL_DESCRIPTION      = replace(MATERIAL_DESCRIPTION,chr(13)),
        BRAND                     = replace(BRAND,chr(13)),
        MATERIAL_GROUP            = replace(MATERIAL_GROUP,chr(13)),
        SALES_STATUS              = replace(SALES_STATUS,chr(13)),
        VALID_FROM                = replace(VALID_FROM,chr(13)),
        EF_OUT_DATE               = replace(EF_OUT_DATE,chr(13)),
        UPC_CODE                  = replace(UPC_CODE,chr(13)),
        NEW_BUSINESS_FIELD        = replace(NEW_BUSINESS_FIELD,chr(13)),
        PRODUCT_TYPE              = replace(PRODUCT_TYPE,chr(13)),
        MAP_UMRP                  = replace(MAP_UMRP,chr(13)),
        SK_MARKETING_DESCRIPTION    = replace(SK_MARKETING_DESCRIPTION,chr(13));

      COMMIT;

      --UPDATE_FUNCTION('RAW_MODEL_MASTER_TBL','INITCAP');
      UPDATE_FUNCTION('RAW_MODEL_MASTER_TBL','TRIM');

      update RAW_MODEL_MASTER_TBL SET MATERIAL = UPPER(MATERIAL);

      update RAW_MODEL_MASTER_TBL set map_umrp = null where map_umrp = '#N/A';

      update RAW_MODEL_MASTER_TBL set map_umrp = replace(map_umrp,'$','');

      update RAW_MODEL_MASTER_TBL set map_umrp = replace(map_umrp,',','');


      update RAW_MODEL_MASTER_TBL set error_desc = 'MATERIAL_GROUP is missing' where trim(MATERIAL_GROUP) is null;
      update RAW_MODEL_MASTER_TBL set error_desc = 'Error' where trim(MATERIAL_GROUP) = 'Z- Obsolete' and trim(MATERIAL_DESCRIPTION) is null;
      update RAW_MODEL_MASTER_TBL set error_desc = 'Error' where trim(MATERIAL_GROUP) = 'Nodata';
      update RAW_MODEL_MASTER_TBL set error_desc = 'MATERIAL is missing' where trim(MATERIAL) is null;



      ----------------------------------------------------------
      --These were manual updates but moved these here in the package until we decide what to do with these records
      ----------------------------------------------------------
      --Here suppressing records if they have been received in new model masters ('After_Inc-%.csv') in the past already.
      --New check added if pricing for model exist or not
      --and MATERIAL in (select PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM PPD inner join BOSH.PRODUCT_DIM PD on PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
      --------------------------------------------------------------------
--     update raw_model_master_tbl
--        set ERROR_DESC = 'Model has been received in the past. Checking in bosh.raw_model_master_tbl based upon (BRAND, MATERIAL, MATERIAL_GROUP, coalesce(MAP_UMRP, ''0'')'
--      where (BRAND, MATERIAL, MATERIAL_GROUP, coalesce(MAP_UMRP, '0')) in (
--               select c.BRAND, c.MATERIAL, c.MATERIAL_GROUP, coalesce(c.MAP_UMRP, '0')
--                 from bosh.raw_model_master_tbl c where c.FILE_NM like 'After_Inc-%.csv'
--            )
--         and MATERIAL in (select PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM PPD
--         inner join BOSH.PRODUCT_DIM PD on PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
--        and ERROR_DESC is null;
--     --557 rows
--     commit;

--       --Here suppressing records if they exists in core already...these may have been received in the old masters in the past
--     update raw_model_master_tbl
--        set ERROR_DESC = 'Model exists in core. Checking in bosh.PRODUCT_DIM based upon (BRAND, MATERIAL, coalesce(MAP_UMRP, ''0'')'
--      where (BRAND, MATERIAL, to_number(coalesce(MAP_UMRP, '0'))) in (
--               select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) from bosh.V_PRODUCT c
--            )
-- --         and MATERIAL in (select PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM PPD
-- --         inner join BOSH.PRODUCT_DIM PD on PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
--        and ERROR_DESC is null;
--     -- 7 rows
--     commit;


--       --Suppressing models if they have been received with a difference price as we are not going to process such models on a monthly basis
--       --We will process such models max once in a quarter basis or may be once in half year
--     merge into raw_model_master_tbl tgt
--     using (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c
--             where c.PRICE_AMT is not null) src
--     on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
--     when matched then
--     update
--        set ERROR_DESC = 'Model exists in core with a different price'
--      where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
--               and tgt.MATERIAL in (select PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM PPD
--                 inner join BOSH.PRODUCT_DIM PD on PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
--        and ERROR_DESC is null;
--     -- 387 rows
--     commit;
    ----------------------------------------------------------


      --it was added on 4/8/2022
      update RAW_MODEL_MASTER_TBL
      set SK_MARKETING_DESCRIPTION =
            case
                when lower(MATERIAL_GROUP) = 'accessory' then 'Accessory'
                when lower(MATERIAL_GROUP) = 'built-in coffee machine' then 'Coffee Machine'
                --when lower(MATERIAL_GROUP) = 'complementary products' and MATERIAL_DESCRIPTION like '%Drawer' then 'Warming Drawers'
                when lower(MATERIAL_GROUP) = 'complementary products' then 'Complementary Products'
                when lower(MATERIAL_GROUP) = 'cooker' then 'Range'
                when lower(MATERIAL_GROUP) = 'dishwasher' then 'Dishwasher'
                when lower(MATERIAL_GROUP) = 'double oven' then 'Double Oven'
                when lower(MATERIAL_GROUP) = 'food processor' then 'Small Appliances'
                when lower(MATERIAL_GROUP) = 'freezer' then 'Freezer'
                when lower(MATERIAL_GROUP) = 'refrigerator' then 'Refrigerator'
                when lower(MATERIAL_GROUP) = 'fridge/freezer combination' then 'Refrigerator/Freezer'
                when lower(MATERIAL_GROUP) = 'hob' then 'Cooktop'
                when lower(MATERIAL_GROUP) = 'hood' then 'Ventilation'
                when lower(MATERIAL_GROUP) = 'microwave' then 'Microwave'
                when lower(MATERIAL_GROUP) = 'modular grill' then 'Cooktop'
                when lower(MATERIAL_GROUP) = 'modular hob' then 'Cooktop'
                when lower(MATERIAL_GROUP) = 'oven' then 'Oven'
                when lower(MATERIAL_GROUP) = 'platewarmer' then 'Warming Drawers'
                when lower(MATERIAL_GROUP) = 'side-by-side' then 'Refrigerator/Freezer'
                when lower(MATERIAL_GROUP) = 'washing machine' then 'Washer'
                --when lower(MATERIAL_GROUP) = 'washing machine' then 'Dryer'
                when lower(MATERIAL_GROUP) = 'winestorage' then 'Wine Column'
            end
      where SK_MARKETING_DESCRIPTION is null;


      update RAW_MODEL_MASTER_TBL
         set SK_MARKETING_DESCRIPTION = 'Refrigerator'
       where SK_MARKETING_DESCRIPTION = 'Refrgerator';

      update raw_model_master_tbl
         set SK_MARKETING_DESCRIPTION = 'Dryer'
      where upper(SK_MARKETING_DESCRIPTION) = 'LAUNDRY' and lower(material_group) like '%dryers%';

      update raw_model_master_tbl
         set SK_MARKETING_DESCRIPTION = 'Dishwashers'
       where MATERIAL_GROUP = 'Gaggenau Dishwashers' and SK_MARKETING_DESCRIPTION = 'Hoods';

      COMMIT;

      /*
      -- update the sku_marketing_description from core if its null
      merge into raw_model_master_tbl a
      using (
            select * from p_product_dim
            ) b
         on ( upper(a.material) = upper(b.model_no))
       when matched then
      update
        set a.SK_MARKETING_DESCRIPTION = b.marketing_product_nm
      where TRIM(a.SK_MARKETING_DESCRIPTION) is null
        and b.marketing_product_nm is not null;

      COMMIT;
       */

      --Dates are received in DD.MM.YYYY format. Converting to MM/DD/YYYY
      -- select pax.VALID_FROM, to_char(to_date(pax.VALID_FROM, 'DD/MM/YYYY'), 'MM/DD/YYYY') from raw_model_master_tbl pax;

      update raw_model_master_tbl
         set VALID_FROM = to_char(to_date(VALID_FROM, 'DD.MM.YYYY'), 'MM.DD.YYYY')
       where VALID_FROM is not null and instr(VALID_FROM, '.') > 0;

      update raw_model_master_tbl
         set EF_OUT_DATE = to_char(to_date(EF_OUT_DATE, 'DD.MM.YYYY'), 'MM.DD.YYYY')
       where EF_OUT_DATE is not null and instr(EF_OUT_DATE, '.') > 0;

      update raw_model_master_tbl
         set VALID_FROM = replace(VALID_FROM, '.', '/')
       where VALID_FROM is not null and instr(VALID_FROM, '.') > 0;

      update raw_model_master_tbl
         set EF_OUT_DATE = replace(EF_OUT_DATE, '.', '/')
       where EF_OUT_DATE is not null and instr(EF_OUT_DATE, '.') > 0;

      commit;



      L_INSERT_AUDIT_KEY := p_get_audit_key (p_program_nm   => 'PK_MODELMASTER.S_001_LOAD_PRODUCT_CATEGORY', p_table_nm     => 'PRODUCT_CATALOG_TBL');


        DELETE FROM PRODUCT_CATALOG_TBL;
        COMMIT;

        INSERT INTO PRODUCT_CATALOG_TBL
        (
        MARKETING_PRODUCT_NM,
        Product_Category_XID,
        Marketing_Product_Category_Nm,
        BRAND_UNIQUE_ID,
        BRAND_NM,
        BRAND_DSC,
        PRODUCT_UNIQUE_ID,
        Product_Nm,
        Product_Dsc,
        --MARKETING_PRODUCT_NM,
        MODEL_NO,
        SKU_NO,
        UPC_CD,
        PRICE_AMT,
        Do_Not_Solicit_Product_IND,
        INSERT_AUDIT_KEY,
        SOURCE_SYSTEM_CD,
        UNIQUE_SEQ_NO,
        PRODUCT_CATEGORY_UNIQUE_ID,
        PRODUCT_CATEGORY_DSC,
        Product_Category_NM
        )
        with m_group as (
            select Material as Material_with,
                   case when lower(material_group) like '%refrig%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%sbs%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like 'freezer%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like 'built in/built under%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                        when lower(material_group) like '%dish%' then 'DISHWASHER'
                        when lower(material_group) like '%hood%' then 'VENTILATION'
                        when lower(material_group) like '%ventilation%' then 'VENTILATION'
                        when lower(material_group) like '%oven%' then 'COOKING'
                        when lower(material_group) like '%cook%' then 'COOKING'
                        when lower(material_group) like '%range%' then 'COOKING'
                        when lower(material_group) like '%hob%' then 'COOKING'
                        when lower(material_group) like '%microwave%' then 'COOKING'
                        when lower(material_group) like '%warming drawers%' then 'COOKING'
                        when lower(material_group) like '%dryer%' then 'LAUNDRY-DRYER'
                        when lower(material_group) like '%frontloader%' then 'LAUNDRY-WASHER'
                        when lower(material_description) like '%washing machine%' then 'LAUNDRY-WASHER'
                        when lower(material_description) like '%dryer%' then 'LAUNDRY-DRYER'
                        ---
                        --these cases were added on 6/6/2019 by AJ
                        when lower(material_group) like '%vents%blowers%' then 'VENTILATION'
                        when lower(material_group) like '%fuel slide in%' then 'COOKING'
                        when lower(material_group) like '%gas slide in%' then 'COOKING'
                        when lower(material_group) like '%convection%' then 'COOKING'
                        ---
                        --these cases were added on 2/3/2021 by AJ
                        when lower(material_group) like '%fridge%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%side%by%side%' then 'REFRIGERATION W LOSS'
                       --added on 5/19/2021 by AJ
                        when lower(material_group) like '%washing machine%' then 'LAUNDRY-WASHER'
                        when lower(material_group) like '%freezer%' then 'REFRIGERATION W LOSS'
                       --added on 4/12/2022 by AJ
                       when lower(material_group) like '%plate%warmer%' then 'COOKING'
                       when lower(material_group) like '%modular grill%' then 'COOKING'
                       when lower(material_group) like '%winestorage%' then 'REFRIGERATION W LOSS'
                        else 'OTHER'
                    end as material_group_derived
            from RAW_MODEL_MASTER_TBL
        )
        SELECT
                SK_MARKETING_DESCRIPTION AS MARKETING_PRODUCT_NM,
                SK_MARKETING_DESCRIPTION as product_category_description, --PRODUCT_TYPE AS Product_Category_Description,
                --NEW_BUSINESS_FIELD AS Marketing_Product_Category_Nm,
                material_group_derived  as marketing_product_category_nm,
                BRAND AS Brand_ID,
                BRAND AS Brand_Name,
                BRAND AS Brand_Description,
                MATERIAL AS Product_ID,
                Material_Description AS Product_Name,
                Material_Description as product_descrition,
                Material AS Model_Number,
                UPC_CODE AS SKU_Number,
                UPC_CODE AS UPC_CD,
                MAP_UMRP AS PRICE_AMT,
                'N' as DO_NOT_SOLICIT_PRODUCT_IND,  -- we are setting as 'N' . DNS handling will be done by Post step which calls procedure "PK_MODEL_MASTER.s_002_update_dns_indicator"
                L_INSERT_AUDIT_KEY,
                1 AS SOURCE_SYSTEM_CD,
                UNIQUE_SEQ_NO,
                material_group_derived as PRODUCT_CATEGORY_UNIQUE_ID,
                material_group_derived AS PRODUCT_CATEGORY_DSC,
                material_group_derived as Product_Category_NM
        FROM  RAW_MODEL_MASTER_TBL r join m_group m on m.Material_with = r.Material
        WHERE ERROR_DESC IS NULL;

        COMMIT;

        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a where PRODUCT_DSC IS NULL ) b
        on (trim(lower(a.marketing_product_nm)) = trim(lower(b.marketing_product_nm))
            AND trim(lower(a.brand_unique_id)) = trim(lower(b.brand_nm))
           )
        when matched then update set a.thumbnail_image_link = b.image_link
        where thumbnail_image_link is null;


      merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a where PRODUCT_DSC IS NOT NULL ) b
        on (trim(lower(a.marketing_product_nm)) = trim(lower(b.marketing_product_nm))
            AND trim(lower(a.brand_unique_id)) = trim(lower(b.brand_nm))
           )
        when matched then update set a.thumbnail_image_link = b.image_link
        --where thumbnail_image_link is null
        ;


        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a
                                                 where trim(lower(marketing_product_nm)) = 'default') b
        on ( trim(lower(a.brand_unique_id)) = trim(lower(b.brand_nm)))
        when matched then update set a.thumbnail_image_link = b.image_link
        where thumbnail_image_link is null;

--        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a, brand_dim b
--                                                 where trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))) b
--        on (trim(lower(a.marketing_product_nm)) = trim(lower(b.marketing_product_nm))
--            AND trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))
--            AND A.PRODUCT_DSC IS NULL
--           )
--        when matched then update set a.thumbnail_image_link = b.image_link
--        where thumbnail_image_link is null;
--
--
--
--        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a, brand_dim b
--                                                 where trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))) b
--        on (trim(lower(a.marketing_product_nm)) = trim(lower(b.marketing_product_nm))
--            AND trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))
--            AND trim(lower(a.product_dsc)) = trim(lower(b.product_dsc))
--            AND A.PRODUCT_DSC IS NOT NULL
--           )
--        when matched then update set a.thumbnail_image_link = b.image_link;
--
--        merge into product_catalog_tbl a using ( select a.* from marketing_product_link_tbl a, brand_dim b
--                                                 where trim(lower(a.brand_nm)) = trim(lower(b.brand_nm))
--                                                 and trim(lower(marketing_product_nm)) = 'default') b
--        on ( trim(lower(a.brand_nm)) = trim(lower(b.brand_nm)))
--        when matched then update set a.thumbnail_image_link = b.image_link
--        where thumbnail_image_link is null;

        COMMIT;

   END ;



   PROCEDURE s_002_update_dns_indicator
   IS
      v_audit_key       NUMBER := 0;
      l_count           NUMBER := 0;

      --l_today           CHAR(8)        := TO_CHAR(SYSDATE, 'YYYYMMDD');
      l_temp_text       VARCHAR2(1096) := NULL;
      --l_email_subject   VARCHAR2(512)  := NULL;

   BEGIN

      v_audit_key := p_get_audit_key (p_program_nm   => 'PK_MODELMASTER.S_002_UPDATE_DNS_INDICATOR', p_table_nm     => 'PRODUCT_DIM');

      -- NOTE - This must be run after the Model Master data is core merged ( As this assumes that latest models are core merged and also
      -- Product_attribute_xref data is created and core merged. ( v_product view is used in this procedure which is based on core tables).

      -- Rules to set DO_NOT_SOLICIT_PRODUCT_IND:
      -- (1)  set the DO_NOT_SOLICIT_PRODUCT_IND Indicator to 'Y. where difference between the PRODUCT_COVERAGE_END_DT and sysdate is <= 12 months.
      -- that is, we cannot solicit models where coverage is going to expire in next  12 months. --BOSH-380
      -- (2) All models which are not part of the current model master files needs to be  suppressed


      -- Bring all he product_dim data to staging with 'N' as DO_NOT_SOLICIT_PRODUCT_IND.( Lets say initially all are good to solicit).

      SELECT COUNT(1)
        INTO l_count
        FROM RAW_MODEL_MASTER_TBL;   --staging

      IF l_count = 0 THEN

         /***send an email***/
         l_temp_text := 'WARNING:PK_MODELMASTER.s_002_update_dns_indicator:: DNS flags not updated. RAW_MODEL_MASTER_TBL is empty in Staging ';

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_002_UPDATE_DNS_INDICATOR', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');

         l_temp_text := ' This procdure is used after the model master process and it assumes that there must be data in staging table raw_model_master_tbl;';

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_002_UPDATE_DNS_INDICATOR', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');

         COMMIT;


         RAISE_APPLICATION_ERROR (-20001, l_temp_text);


      END IF;


      INSERT INTO PRODUCT_DIM ( PRODUCT_KEY,
                                  PRODUCT_UNIQUE_ID,
                                  PRODUCT_NM,
                                  PRODUCT_DSC,
                                  SKU_NO,
                                  UPC_CD,
                                  MODEL_NO,
                                  IMAGE_LINK,
                                  THUMBNAIL_IMAGE_LINK,
                                  BRAND_KEY,
                                  PRODUCT_CATEGORY_KEY,
                                  CURRENT_POLICY_KEY,
                                  PRICE_AMT,
                                  UNIT_CNT,
                                  PACKAGE_WEIGHT_NO,
                                  DO_NOT_SOLICIT_PRODUCT_IND,
                                  MARKETING_PRODUCT_NM,
                                  INSERT_AUDIT_KEY,
                                  UPDATE_AUDIT_KEY
                                 )
                        SELECT PRODUCT_KEY,
                               PRODUCT_UNIQUE_ID,
                               PRODUCT_NM,
                               PRODUCT_DSC,
                               SKU_NO,
                               UPC_CD,
                               MODEL_NO,
                               IMAGE_LINK,
                               THUMBNAIL_IMAGE_LINK,
                               BRAND_KEY,
                               PRODUCT_CATEGORY_KEY,
                               CURRENT_POLICY_KEY,
                               PRICE_AMT,
                               UNIT_CNT,
                               PACKAGE_WEIGHT_NO,
                               'N' as DO_NOT_SOLICIT_PRODUCT_IND,
                               MARKETING_PRODUCT_NM,
                               INSERT_AUDIT_KEY,
                               v_audit_key as UPDATE_AUDIT_KEY
             FROM P_PRODUCT_DIM
            WHERE product_key NOT IN (
                     SELECT s.product_key FROM PRODUCT_DIM s);


      -- set the DO_NOT_SOLICIT_PRODUCT_IND Indicator to 'Y'. Where current_date - valid_from date > 109 months (do not solicit)
      -- NOTE - This must be run after the Model Master data is core merged as it reads PRODUCT_COVERAGE_END_DT from v_product/core
      update product_dim vpr
         set do_not_solicit_product_ind = 'Y',
             update_audit_key           = V_AUDIT_KEY,
             sync_audit_key             = NULL
       where product_key IN (
                select vpr.product_key from bosh.v_product vpr
                 where 1=1
                   --and NVL(do_not_solicit_product_ind, 'N') = 'N'
                   and months_between (VPR.PRODUCT_COVERAGE_END_DT, sysdate) <= 12    --BOSH-380
                )
         and nvl(do_not_solicit_product_ind, 'N') = 'N' ;


      -- All models, which are not part of the current model master file needs to be  suppressed
      -- Here it is important that the current raw model master file data resides in staging "raw_model_master_tbl"
      update product_dim vpr
         set do_not_solicit_product_ind = 'Y',
             update_audit_key           = V_AUDIT_KEY,
             sync_audit_key             = NULL
       where 1=1
         and vpr.model_no NOT IN (
                select upper(trim(material))
                  from raw_model_master_tbl   --staging
                )
         and nvl(do_not_solicit_product_ind, 'N') = 'N' ;


      COMMIT;


   END S_002_UPDATE_DNS_INDICATOR;



   PROCEDURE s_005_product_qa
   /*
   This procedure has sqls, which can be used to fetch detailed data for QA and to share with QA/client teams
   */
   IS
      l_count                       NUMBER := 0;
      l_qc_text                     VARCHAR2(10000):= NULL;
      l_temp_text                   VARCHAR2(1096) := NULL;

   BEGIN

      --Fetch New Vs. Existing pricing for mdoels with change in MSRP
      select count(*) into l_Count
        from (
            select distinct br.brand_nm, n.product_key, n.model_no, o.PRICE_AMT, n.PRICE_AMT as new_PRICE_AMT,
                   o.DO_NOT_SOLICIT_PRODUCT_IND, n.DO_NOT_SOLICIT_PRODUCT_IND as New_DO_NOT_SOLICIT_PRODUCT_IND,
                   o.PRODUCT_COVERAGE_END_DT, NVL (TO_DATE (px.product_attribute_value, 'MM/DD/YYYY'), DATE '2089-12-31') + (10 * 365) AS New_Product_Coverage_End_Dt,
                   o.product_category_nm, pcs.product_category_nm as new_product_category_nm
              from product_dim n left join product_category_dim pcs on pcs.product_category_key = n.product_category_key
                   left join (
                       select *
                         from product_attribute_xref px
                              join p_product_attribute_ref pr ON (px.product_attribute_key = pr.product_attribute_key and attribute_nm = 'EF_OUT_DATE')
                       ) px on px.product_key = n.product_key
                   left join brand_dim br on br.brand_key = n.brand_key
                   join
                   bosh.v_product o
                      on (o.product_key = n.product_key )
             where 1=1
               and (1=2
                    or o.PRICE_AMT <> n.PRICE_AMT
                   )
            order by n.product_key
        );


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' existing models with change in price_amt';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_005_PRODUCT_QA', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;


      --Fetch New Vs. Existing pricing for mdoels with change in product_category_nm
      select count(*) into l_Count
        from (
            select distinct br.brand_nm, n.product_key, n.model_no, o.PRICE_AMT, n.PRICE_AMT as new_PRICE_AMT,
                   o.DO_NOT_SOLICIT_PRODUCT_IND, n.DO_NOT_SOLICIT_PRODUCT_IND as New_DO_NOT_SOLICIT_PRODUCT_IND,
                   o.PRODUCT_COVERAGE_END_DT, NVL (TO_DATE (px.product_attribute_value, 'MM/DD/YYYY'), DATE '2089-12-31') + (10 * 365) AS New_Product_Coverage_End_Dt,
                   o.product_category_nm, pcs.product_category_nm as new_product_category_nm
              from product_dim n left join product_category_dim pcs on pcs.product_category_key = n.product_category_key
                   left join (
                       select *
                         from product_attribute_xref px
                              join p_product_attribute_ref pr ON (px.product_attribute_key = pr.product_attribute_key and attribute_nm = 'EF_OUT_DATE')
                       ) px on px.product_key = n.product_key
                   left join brand_dim br on br.brand_key = n.brand_key
                   join
                   bosh.v_product o
                      on (o.product_key = n.product_key )
             where 1=1
               and (1=2
                    or o.product_category_nm <> pcs.product_category_nm
                   )
            order by n.product_key
        );


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' existing models with change in product_category_nm';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_005_PRODUCT_QA', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;


      --Fetch New Vs. Existing pricing for mdoels with change in DNS
      select count(*) into l_Count
        from (
            select distinct br.brand_nm, n.product_key, n.model_no, o.PRICE_AMT, n.PRICE_AMT as new_PRICE_AMT,
                   o.DO_NOT_SOLICIT_PRODUCT_IND, n.DO_NOT_SOLICIT_PRODUCT_IND as New_DO_NOT_SOLICIT_PRODUCT_IND,
                   o.PRODUCT_COVERAGE_END_DT, NVL (TO_DATE (px.product_attribute_value, 'MM/DD/YYYY'), DATE '2089-12-31') + (10 * 365) AS New_Product_Coverage_End_Dt,
                   o.product_category_nm, pcs.product_category_nm as new_product_category_nm
              from product_dim n left join product_category_dim pcs on pcs.product_category_key = n.product_category_key
                   left join (
                       select *
                         from product_attribute_xref px
                              join p_product_attribute_ref pr ON (px.product_attribute_key = pr.product_attribute_key and attribute_nm = 'EF_OUT_DATE')
                       ) px on px.product_key = n.product_key
                   left join brand_dim br on br.brand_key = n.brand_key
                   join
                   bosh.v_product o
                      on (o.product_key = n.product_key )
             where 1=1
               and (1=2
                    or o.DO_NOT_SOLICIT_PRODUCT_IND <> n.DO_NOT_SOLICIT_PRODUCT_IND
                   )
            order by n.product_key
        );


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' existing models with change in DO_NOT_SOLICIT_PRODUCT_IND';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_005_PRODUCT_QA', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;


      --Fetch New Vs. Existing pricing for mdoels with change in brand_nm
      select count(*) into l_Count
        from (
            select distinct br.brand_nm, n.product_key, n.model_no, o.PRICE_AMT, n.PRICE_AMT as new_PRICE_AMT,
                   o.DO_NOT_SOLICIT_PRODUCT_IND, n.DO_NOT_SOLICIT_PRODUCT_IND as New_DO_NOT_SOLICIT_PRODUCT_IND,
                   o.PRODUCT_COVERAGE_END_DT, NVL (TO_DATE (px.product_attribute_value, 'MM/DD/YYYY'), DATE '2089-12-31') + (10 * 365) AS New_Product_Coverage_End_Dt,
                   o.product_category_nm, pcs.product_category_nm as new_product_category_nm
              from product_dim n left join product_category_dim pcs on pcs.product_category_key = n.product_category_key
                   left join (
                       select *
                         from product_attribute_xref px
                              join p_product_attribute_ref pr ON (px.product_attribute_key = pr.product_attribute_key and attribute_nm = 'EF_OUT_DATE')
                       ) px on px.product_key = n.product_key
                   left join brand_dim br on br.brand_key = n.brand_key
                   join
                   bosh.v_product o
                      on (o.product_key = n.product_key )
             where 1=1
               and (1=2
                    or o.brand_nm <> br.brand_nm  --no such rows --good
                   )
            order by n.product_key
        );


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' existing models with change in brand_nm';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_005_PRODUCT_QA', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;



      -- All models which are not part of the current model master file
      select count(*) into l_Count
        from (
             select * from p_product_dim vpr
              where 1=1
                and vpr.model_no NOT IN (
                       select s.model_no
                         from product_dim s   --staging
                       )
                and nvl(do_not_solicit_product_ind, 'N') = 'N'
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' existing and eligible models from core, which do not exist in latest model master in staging';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_005_PRODUCT_QA', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;


      -- New models in current model master file, which do not exist in core
      select count(*) into l_Count
        from (
             select distinct brand_nm, pcs.product_category_nm, n.product_key, n.model_no, n.PRICE_AMT, n.DO_NOT_SOLICIT_PRODUCT_IND,
                   NVL (TO_DATE (px.product_attribute_value, 'MM/DD/YYYY'), DATE '2089-12-31') + (10 * 365) AS Product_Coverage_End_Dt
              from product_dim n left join product_category_dim pcs on pcs.product_category_key = n.product_category_key
                   left join (
                       select *
                         from product_attribute_xref px
                              join p_product_attribute_ref pr ON (px.product_attribute_key = pr.product_attribute_key and attribute_nm = 'EF_OUT_DATE')
                       ) px on px.product_key = n.product_key
                   left join p_brand_dim br on br.brand_key = n.brand_key
             where 1=1
               and n.product_key not in (select o.product_key from p_product_dim o)
             order by brand_nm, pcs.product_category_nm, price_amt, model_no
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' new models in latest model master in staging';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_005_PRODUCT_QA', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;



     -- New and eligible models in current model master file, which do not exist in core and have leads in si_dim
      select count(*) into l_Count
        from (
             select brand_nm, pcs.product_category_nm, n.product_key, n.model_no, n.PRICE_AMT, n.DO_NOT_SOLICIT_PRODUCT_IND,
                    NVL (TO_DATE (px.product_attribute_value, 'MM/DD/YYYY'), DATE '2089-12-31') + (10 * 365) AS Product_Coverage_End_Dt
                   ,count(*)
               from product_dim n left join product_category_dim pcs on pcs.product_category_key = n.product_category_key
                    left join (
                       select *
                         from product_attribute_xref px
                              join p_product_attribute_ref pr ON (px.product_attribute_key = pr.product_attribute_key and attribute_nm = 'EF_OUT_DATE')
                       ) px on px.product_key = n.product_key
                    left join p_brand_dim br on br.brand_key = n.brand_key
                    join p_serialized_item_dim si on trim(si.model_no) = n.model_no
              where 1=1
                and n.product_key not in (select o.product_key from p_product_dim o
                       )
                and n.price_amt is not null
                and NVL (TO_DATE (px.product_attribute_value, 'MM/DD/YYYY'), DATE '2089-12-31') + (10 * 365) > sysdate + 365 + 60
              group by brand_nm, pcs.product_category_nm, n.product_key, n.model_no, n.PRICE_AMT, n.DO_NOT_SOLICIT_PRODUCT_IND
                    ,NVL (TO_DATE (px.product_attribute_value, 'MM/DD/YYYY'), DATE '2089-12-31') + (10 * 365)
              order by count(*) desc, brand_nm, pcs.product_category_nm, price_amt, model_no
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' new and eligible models in latest model master, which have leads in SI_DIM';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_005_PRODUCT_QA', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;



      -- DNS based upon EF_OUT_DT
      select count(*) into l_Count
        from (
              select * from V_PRODUCT_Stg vpr
               where months_between (VPR.PRODUCT_COVERAGE_END_DT, sysdate) <= 12
                 and nvl(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'N'
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' models, which will now be suppressed based upon EF_OUT_DT';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PK_MODELMASTER.S_005_PRODUCT_QA', 'Model Master', l_temp_text, l_count, SYSTIMESTAMP, 'RAW_MODEL_MASTER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;

      COMMIT;


      IF l_qc_text IS NOT NULL
      THEN
         dbms_output.put_line (l_qc_text);
         /***send an email***/
         NULL;

      END IF;


  END S_005_PRODUCT_QA;


END PK_MODELMASTER;
/

