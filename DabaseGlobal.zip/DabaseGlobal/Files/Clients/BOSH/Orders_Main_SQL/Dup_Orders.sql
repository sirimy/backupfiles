select *
  from (
	select oit.serialized_item_id, si.serial_num, si.purchase_dt::date as si_purchase_dt, pr.model_no, ot.created_by, ot.purchase_dt::date as order_purchase_dt,
	       contract_start_dt, contract_end_dt,
	       sales_source_cd, channels as Plan, oit.order_id, oit.order_line_id, pol.sku, tr.name as term, co.contract_id, cons.name as status
	       , oit.offer_id, oft.active_ind as Offer_active_ind, oit.price_amt, oit.tax_amt, flexpay_ind, tx.payment_type
	       , cust.first_nm, cust.last_nm, cust.firm_nm, address_line1_tx, locality_nm, s.code as State_code  --postal_code1_tx, postal_code2_tx,
	from order_tbl ot
		join ORDER_ITEM_TBL oit ON ( ot.order_id = oit.order_id )
		join serialized_item si on (si.serialized_item_id = oit.serialized_item_id)
		left join product pr on (pr.product_id = si.product_id)
		LEFT join customer_tbl cust using (customer_id) join address_tbl adr on (address_id = primary_address_id) join state s on (adr.state_id = s.state_id)
		left join (
			select *
			from (
			      select tx.order_id, tx.payment_type, row_number() over (partition by tx.order_id order by tx.created_ts) as rno
			       from payment_tx_tbl tx
			     ) tx
			where rno = 1
			) tx on tx.order_id  = ot.order_id
		left join offer_tbl oft on (oft.offer_id = oit.offer_id)
		left join contract_order co on (co.order_id = oit.order_id and co.order_line_id = oit.order_line_id)
		left join contract con on (con.contract_id = co.contract_id)
		left join contract_status cons on (cons.contract_status_id = con.contract_status_id)
		left join policy pol on pol.policy_id = oit.policy_id
		left join policy_ext pex ON (pex.policy_id = pol.policy_id)
		left join term tr on tr.term_id = pol.term_id
	where 1 = 1
	 and oit.price_amt > 1
         and ot.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
	 AND ( con.contract_status_id IS NULL OR con.contract_status_id NOT IN (2, 3, 4, 5) )  --cancelled/fulfilled/expired
	 AND exists (
		select oit3.serialized_item_id
		from    order_tbl ot3
                        join ORDER_ITEM_TBL oit3 ON ( ot3.order_id = oit3.order_id )
			left join contract_order co3 on (co3.order_id = oit3.order_id and co3.order_line_id = oit3.order_line_id)
			left join contract con3 on (con3.contract_id = co3.contract_id)
			left join contract_status cons3 on (cons3.contract_status_id = con3.contract_status_id)
			left join policy_ext pex3 ON (pex3.policy_id = oit3.policy_id)
		where 1 = 1
                and ot3.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
		and oit3.serialized_item_id  = oit.serialized_item_id
		and oit3.order_id <> oit.order_id
		and con3.contract_id <> con.contract_id
		and
                    (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
		     or
		     con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
		     or
		     con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
		     or
		     con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
		    )
		and oit3.price_amt > 1
		AND ( con3.contract_status_id IS NULL OR con3.contract_status_id NOT IN (2, 3, 4, 5) )  --cancelled/fulfilled/expired
		and pex3.channels = pex.channels
                and con3.contract_end_dt >= CURRENT_DATE - 30
	       )
	order by oit.serialized_item_id, oit.order_id, oit.purchase_dt
       ) O
;
