--1)	Check how many counts are past max product purchase date for this GID
select substr(GUARANTEE_ID, 17, 2) as effort, substr(GUARANTEE_ID, 19, 2) as cell_cd, count(distinct spl.BUNDLE_KEY) as BUNDLE_KEY,
        min(si.WARRANTY_EXPIRATION_DT) MIN_WARRANTY_EXPIRATION_DT, max(si.WARRANTY_EXPIRATION_DT) MAX_WARRANTY_EXPIRATION_DT
       ,min(si.LATEST_COVERAGE_EXP_DT) MIN_LATEST_COVERAGE_EXP_DT, max(si.LATEST_COVERAGE_EXP_DT) MAX_LATEST_COVERAGE_EXP_DT
--        si.LATEST_COVERAGE_TYPE, cri.REGISTRATION_DT as REGISTRATION_DT_Rule, si.REGISTRATION_DT, si.WARRANTY_EXPIRATION_DT, si.LATEST_COVERAGE_EXP_DT, spl.MAIL_DROP_DATE,
--        si.REGISTRATION_DT - spl.MAIL_DROP_DATE as diff, substr(GUARANTEE_ID, 10, 2), GUARANTEE_ID, bd.CRITERIA_KEY,
--        round((si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT)/365, 2) as term, (si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT) as diff2
--        ,si.REGISTRATION_DT, SERIAL_NO
from CAMPAIGN_SPOOL_FILE_TBL spl
       join V_BUNDLE_DIM bd on bd.BUNDLE_KEY = spl.BUNDLE_KEY
       join V_BUNDLE_ITEM_XREF bix on bix.BUNDLE_KEY = bd.BUNDLE_KEY
       join bosh.SERIALIZED_ITEM_DIM si on si.SI_KEY = bix.SI_KEY
       --left join bosh.SERIALIZED_ITEM_EXT_DIM six on six.SI_KEY = si.SI_KEY
       join bosh.CRITERIA_DIM cri on cri.CRITERIA_KEY = bd.CRITERIA_KEY
where  1=1
-- and    CHANNEL_NM = 'MAIL'
-- and    (spl.CONTRACT_EXP_DT - si.REGISTRATION_DT) > 732
and    (
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202628THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-20')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202644THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-09')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202627THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-13')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202637THMRI029B3' and si.LATEST_COVERAGE_EXP_DT > date '2026-09-21')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202637THMRI029B3' and si.LATEST_COVERAGE_EXP_DT > date '2026-09-21')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202644THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-09')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202646THMRI029M2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-23')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202645THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-16')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029M4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202632THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-17')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202632THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-17')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202626THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-06')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202645THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-16')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202643THMRI029M2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-02')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202549THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-12-15')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202546THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-11-24')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202534THMRW000M3' and si.LATEST_COVERAGE_EXP_DT > date '2025-09-01')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202547THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-12-01')

       )
and    spl.BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
and    spl.BUNDLE_KEY not in (select sup.BUNDLE_KEY from P_SUPPRESSION_TBL sup)
group by substr(GUARANTEE_ID, 17, 2), substr(GUARANTEE_ID, 19, 2)
order by 1;


/*+------+-------+-----------------------------+-----------------------------+------------------------------+------------------------------+------------------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
|EFFORT|CELL_CD|COUNT(DISTINCTSPL.BUNDLE_KEY)|COUNT(DISTINCTSPL.BUNDLE_KEY)|MIN(SI.WARRANTY_EXPIRATION_DT)|MAX(SI.WARRANTY_EXPIRATION_DT)|MIN(SI.LATEST_COVERAGE_EXP_DT)|MAX(SI.LATEST_COVERAGE_EXP_DT)--SI.LATEST_COVERAGE_TYPE,CRI.REGISTRATION_DTASREGISTRATION_DT_RULE,SI.REGISTRATION_DT,SI.WARRANTY_EXPIRATION_DT,SI.LATEST_COVERAGE_EXP_DT,SPL.MAIL_DROP_DATE,--SI.REGISTRATION_DT-SPL.MAIL_DROP_DATEASDIFF,SUBSTR(GUARANTEE_ID,1|
+------+-------+-----------------------------+-----------------------------+------------------------------+------------------------------+------------------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
|B4    |11     |1                            |1                            |2022-06-04 00:00:00.000000    |2022-06-04 00:00:00.000000    |2027-06-04                    |2027-06-04                                                                                                                                                                                                                                                     |
+------+-------+-----------------------------+-----------------------------+------------------------------+------------------------------+------------------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
*/



select distinct spl.BUNDLE_KEY,
       si.LATEST_COVERAGE_TYPE, cri.REGISTRATION_DT as REGISTRATION_DT_Rule, si.REGISTRATION_DT,
       si.WARRANTY_EXPIRATION_DT, si.LATEST_COVERAGE_EXP_DT, spl.MAIL_DROP_DATE,
       substr(GUARANTEE_ID, 10, 2), GUARANTEE_ID, bd.CRITERIA_KEY, si.SI_KEY
from CAMPAIGN_SPOOL_FILE_TBL spl
       join V_BUNDLE_DIM bd on bd.BUNDLE_KEY = spl.BUNDLE_KEY
       join V_BUNDLE_ITEM_XREF bix on bix.BUNDLE_KEY = bd.BUNDLE_KEY
       join bosh.SERIALIZED_ITEM_DIM si on si.SI_KEY = bix.SI_KEY
       --left join bosh.SERIALIZED_ITEM_EXT_DIM six on six.SI_KEY = si.SI_KEY
       join bosh.CRITERIA_DIM cri on cri.CRITERIA_KEY = bd.CRITERIA_KEY
where  1=1
-- and    CHANNEL_NM = 'MAIL'
-- and    si.REGISTRATION_DT > date '2021-04-04'
and    (
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202628THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-20')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202644THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-09')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202627THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-13')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202637THMRI029B3' and si.LATEST_COVERAGE_EXP_DT > date '2026-09-21')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202637THMRI029B3' and si.LATEST_COVERAGE_EXP_DT > date '2026-09-21')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202644THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-09')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202646THMRI029M2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-23')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202645THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-16')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029M4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202632THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-17')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202632THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-17')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202626THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-06')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202645THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-16')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202643THMRI029M2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-02')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202549THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-12-15')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202546THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-11-24')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202534THMRW000M3' and si.LATEST_COVERAGE_EXP_DT > date '2025-09-01')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202547THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-12-01')
       )
and    spl.BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
and    spl.BUNDLE_KEY not in (select sup.BUNDLE_KEY from P_SUPPRESSION_TBL sup);
-- +----------+--------------------+--------------------+-------------------+--------------------------+----------------------+--------------+-------------------------+--------------------+------------+-------+
-- |BUNDLE_KEY|LATEST_COVERAGE_TYPE|REGISTRATION_DT_RULE|REGISTRATION_DT    |WARRANTY_EXPIRATION_DT    |LATEST_COVERAGE_EXP_DT|MAIL_DROP_DATE|SUBSTR(GUARANTEE_ID,10,2)|GUARANTEE_ID        |CRITERIA_KEY|SI_KEY |
-- +----------+--------------------+--------------------+-------------------+--------------------------+----------------------+--------------+-------------------------+--------------------+------------+-------+
-- |12856224  |2                   |null                |2021-03-20 17:57:00|2022-07-13 00:00:00.000000|2027-07-13            |2026-06-02    |RI                       |202627THMRI07029M511|10469       |2422288|
-- |12952709  |2                   |null                |2021-04-03 19:45:26|2022-08-26 00:00:00.000000|2027-08-26            |2026-06-09    |RI                       |202634THMRI07029B411|10469       |2444251|
-- |12714905  |2                   |null                |2021-02-23 21:26:55|2022-07-02 00:00:00.000000|2027-07-02            |2026-05-26    |RI                       |202626THMRI07029M511|10469       |2428928|
-- |12925106  |2                   |null                |2021-06-01 19:03:18|2022-08-26 00:00:00.000000|2027-08-26            |2026-06-09    |RI                       |202634THMRI07029M411|10469       |2592657|
-- |13058655  |2                   |null                |2021-06-25 16:40:51|2022-11-06 00:00:00.000000|2027-11-06            |2026-05-26    |RI                       |202644THMRI07029B211|10469       |2502473|
-- |13220997  |2                   |null                |2021-06-01 16:12:41|2022-11-21 00:00:00.000000|2027-11-21            |2026-06-09    |RI                       |202646THMRI07029M211|10469       |2506202|
-- |13153970  |2                   |null                |2020-11-10         |2022-11-01 00:00:00.000000|2027-11-01            |2026-05-19    |RI                       |202643THMRI07029M211|10469       |2387694|
-- |12950117  |2                   |null                |2026-03-24 12:36:40|2022-08-13 00:00:00.000000|2027-08-13            |2026-05-26    |RI                       |202632THMRI07029B411|10469       |2365414|
-- |13042743  |2                   |null                |2021-03-23 16:16:00|2022-09-15 00:00:00.000000|2027-09-15            |2026-05-19    |RI                       |202637THMRI07029B311|10469       |2458505|
-- |13180794  |2                   |null                |2020-11-29         |2022-11-12 00:00:00.000000|2027-11-12            |2026-06-02    |RI                       |202645THMRI07029B211|10469       |2409689|
-- |12751775  |2                   |null                |2021-05-28 17:55:32|2022-07-14 00:00:00.000000|2027-07-14            |2026-06-09    |RI                       |202628THMRI07029M511|10469       |2405861|
-- |13107920  |2                   |null                |2021-04-09 14:08:40|2022-11-01 00:00:00.000000|2027-11-01            |2026-05-19    |RI                       |202643THMRI07029M211|10469       |2543540|
-- |13144625  |2                   |null                |2021-04-26 19:52:40|2022-11-01 00:00:00.000000|2027-11-01            |2026-05-19    |RI                       |202643THMRI07029M211|10469       |2461970|
-- |13170660  |2                   |null                |2021-05-14 14:46:36|2022-11-17 00:00:00.000000|2027-11-17            |2026-06-09    |RI                       |202646THMRI07029M211|10469       |2506198|
-- |12662922  |2                   |null                |2021-06-17 22:16:36|2022-07-01 00:00:00.000000|2027-07-01            |2026-05-26    |RI                       |202626THMRI07029M511|10469       |2431682|
-- +----------+--------------------+--------------------+-------------------+--------------------------+----------------------+--------------+-------------------------+--------------------+------------+-------+



--Suppressing
insert into SUPPRESSION_TBL (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
SELECT distinct spl.BUNDLE_KEY, 'M', sysdate, 'Past max contract exp date'
from CAMPAIGN_SPOOL_FILE_TBL spl
       join V_BUNDLE_DIM bd on bd.BUNDLE_KEY = spl.BUNDLE_KEY
       join V_BUNDLE_ITEM_XREF bix on bix.BUNDLE_KEY = bd.BUNDLE_KEY
       join bosh.SERIALIZED_ITEM_DIM si on si.SI_KEY = bix.SI_KEY
       --left join bosh.SERIALIZED_ITEM_EXT_DIM six on six.SI_KEY = si.SI_KEY
       join bosh.CRITERIA_DIM cri on cri.CRITERIA_KEY = bd.CRITERIA_KEY
where  1=1
-- and    CHANNEL_NM = 'MAIL'
-- and    si.REGISTRATION_DT > date '2021-04-04'
and    (
           (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202628THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-20')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202644THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-09')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202627THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-13')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202637THMRI029B3' and si.LATEST_COVERAGE_EXP_DT > date '2026-09-21')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202637THMRI029B3' and si.LATEST_COVERAGE_EXP_DT > date '2026-09-21')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202644THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-09')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202646THMRI029M2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-23')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202645THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-16')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029M4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202632THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-17')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202632THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-17')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202634THMRI029B4' and si.LATEST_COVERAGE_EXP_DT > date '2026-08-31')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202626THMRI029M5' and si.LATEST_COVERAGE_EXP_DT > date '2026-07-06')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202645THMRI029B2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-16')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202643THMRI029M2' and si.LATEST_COVERAGE_EXP_DT > date '2026-11-02')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202549THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-12-15')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202546THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-11-24')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202534THMRW000M3' and si.LATEST_COVERAGE_EXP_DT > date '2025-09-01')  OR
            (substr(guarantee_id, 1, 11) ||  substr(guarantee_id, 14, 5) =  '202547THMRW000M2' and si.LATEST_COVERAGE_EXP_DT > date '2025-12-01')
       )
and    spl.BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
and    spl.BUNDLE_KEY not in (select sup.BUNDLE_KEY from P_SUPPRESSION_TBL sup);
--1 rows
commit;


select * from CAMPAIGN_SPOOL_FILE_TBL where BUNDLE_KEY in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup);--4



select sup.SUPPRESSION_REASON, count(*)
  from CAMPAIGN_SPOOL_FILE_TBL spl join SUPPRESSION_TBL sup on sup.BUNDLE_KEY = spl.BUNDLE_KEY where CHANNEL_NM = 'MAIL'
 group by sup.SUPPRESSION_REASON order by sup.SUPPRESSION_REASON;
-- +------------------------------------------------------------------------+--------+
-- |SUPPRESSION_REASON                                                      |COUNT(*)|
-- +------------------------------------------------------------------------+--------+
-- |BOSH-1757: Gaggenau Leads Suppression: Product Purchase date >= 1/1/2025|2       |
-- |Past max contract exp date                                              |15      |
-- +------------------------------------------------------------------------+--------+



-- rollback;
select count(*), count(distinct BUNDLE_KEY) from CAMPAIGN_SPOOL_FILE_TBL where BUNDLE_KEY in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup);

delete from CAMPAIGN_SPOOL_FILE_TBL where BUNDLE_KEY in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup);
-- 118 rows including emails -- 64 unique bundles
commit;
