
select COUNT(*) from POLICY_TBL;--162

select COUNT(*) from PRODUCT_PRICE_DIM;--167

--Out of 162 for 32 SKU product pricing created
select  distinct POLICY_PRODUCT_XID from PRODUCT_PRICE_DIM PD join POLICY_TBL PL using(POLICY_KEY);--32

select distinct MODEL_NO --count(distinct POLICY_PRODUCT_XID), count(distinct MODEL_NO), count(distinct PRICING_SCHEME_KEY)
from PRODUCT_PRICE_DIM PD
        join POLICY_TBL PL using(POLICY_KEY)
        join V_PRODUCT VP using(PRODUCT_KEY)
        join BOSH.PRICING_SCHEME_DIM PSD using(PRICING_SCHEME_KEY)
;--
-- +---------------------------------+-----------------------+---------------------------------+
-- |COUNT(DISTINCTPOLICY_PRODUCT_XID)|COUNT(DISTINCTMODEL_NO)|COUNT(DISTINCTPRICING_SCHEME_KEY)|
-- +---------------------------------+-----------------------+---------------------------------+
-- |32                               |5                      |13                               |
-- +---------------------------------+-----------------------+---------------------------------+

-- There total 16 pricing scheme
 SELECT *
              FROM V_PRICING_SCHEME_DIM psd
             WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd.PRICING_SCHEME_DESC, 1, 2), psd.load_dt) IN (
                                   select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2), max(psd2.load_dt)
                                     from v_pricing_scheme_dim psd2
                                    where Upper(psd2.PRICING_SCHEME_DESC) LIKE '%THERMADOR%'
                                    group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2)
                                  )
               AND Upper(psd.PRICING_SCHEME_DESC) LIKE '%THERMADOR%'
               AND psd.END_DT >= trunc(sysdate);


-- for 13 pricing scheme is generated as RN7, Rn8 and R9 no SKU is present
select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$') as brand, pricing_scheme_type as type,
       PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY) as Terms
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms_list
       ,count(distinct PRODUCT_KEY) as Models, count(distinct ppd.POLICY_KEY) as Policies,
        count(*) as records, sum(BASE_PRICE_AMT) as BASE_PRICE_AMT
from   product_price_dim ppd
       join bosh.pricing_scheme_dim psd using (pricing_scheme_key)
       join policy_tbl pol on (pol.policy_key = ppd.policy_key)
       join P_PRODUCT_DIM pd using (product_key)
where 1=1
and   psd.END_DT > sysdate
and   pol.EXP_DT > sysdate
-- and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
and coalesce(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
--   and PRICING_SCHEME_DESC not like '%Bosch'
--   and PRICING_SCHEME_DESC not like '%BUILDER'
-- and PRICING_SCHEME_DESC like '%Thermador'
--   and pricing_scheme_type in ('AM', 'EB')
group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
-- +---------+----+------------------+-------------------+----+-----+----------+------+--------+-------+--------------+
-- |BRAND    |TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE |TERMS|TERMS_LIST|MODELS|POLICIES|RECORDS|BASE_PRICE_AMT|
-- +---------+----+------------------+-------------------+----+-----+----------+------+--------+-------+--------------+
-- |Thermador|AM  |201               |AM Thermador       |NULL|4    |1, 3, 4, 5|5     |8       |20     |23404.7       |
-- |Thermador|EB  |203               |EB Thermador       |NULL|4    |1, 3, 4, 5|5     |8       |20     |18723.76      |
-- |Thermador|OOW |205               |AO Thermador       |NULL|2    |1, 3      |5     |4       |10     |9995.3        |
-- |Thermador|OOW |213               |RO 3 Thermador     |NULL|2    |1, 3      |5     |4       |10     |9995.3        |
-- |Thermador|OOW |214               |RO 4 Thermador     |NULL|1    |1         |5     |2       |5      |2707.6        |
-- |Thermador|OOW |215               |RO 5 Thermador     |NULL|1    |1         |5     |2       |5      |2707.6        |
-- |Thermador|OOW |216               |RO 6 Thermador     |NULL|2    |1, 3      |5     |4       |10     |9995.3        |
-- |Thermador|OOW |217               |RO 7 Thermador     |NULL|1    |1         |5     |2       |5      |2707.6        |
-- |Thermador|OOW |218               |RO 8 Thermador     |NULL|1    |1         |5     |2       |5      |2707.6        |
-- |Thermador|RN  |206               |RN 3 Thermador     |3   |4    |1, 2, 3, 4|5     |8       |20     |23653.7       |
-- |Thermador|RN  |207               |RN 4 Thermador     |4   |3    |1, 2, 3   |5     |6       |15     |15674.4       |
-- |Thermador|RN  |208               |RN 5 Thermador     |5   |2    |1, 2      |5     |4       |10     |8562.4        |
-- |Thermador|RN  |209               |RN 6 Thermador     |6   |1    |1         |5     |2       |5      |3074.4        |
-- +---------+----+------------------+-------------------+----+-----+----------+------+--------+-------+--------------+

--Checking if any model eligible and its pricing not created
-- no rows comes so no eligible model left
Select * from (
        select   POLICY_PRODUCT_XID,name,CHANNELS,MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, PRICE_AMT, MODEL_NO,BRAND_NM,pd.DO_NOT_SOLICIT_PRODUCT_IND,UPPER(PRODUCT_CAT_DESC) AS PRODUCT_CAT_DESC,
                 Product_Coverage_End_Dt,
         case when lower(product_category_nm) like 'refrig%' then 'Refrigerator With Food Loss'--'REFRIGERATION W LOSS'
                                   when lower(product_category_nm) like '%counter top coffee machine' then 'Countertop Espresso Machine'
                                   when lower(product_category_nm) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                                   when lower(product_category_nm) like '%dish%' then 'DISHWASHER'
                                   when lower(product_dsc) like '%hood%' or lower(PRODUCT_CATEGORY_nm) like '%venti%'  then 'VENTILATION'
                                   when lower(product_category_nm) like 'cooking' then 'COOKING'
                                   when lower(product_category_nm) like '%laundry%' and lower(product_dsc) like '%dryer%' then 'LAUNDRY-DRYER'
                                   when lower(product_category_nm) like '%laundry%' then 'LAUNDRY-WASHER'
                                   else 'other'
                                   end as bora_pricing_category
          from POLICY_TBL   join bosh.v_product pd on pd.PRICE_AMT between MIN_PRODUCT_PRICE and MAX_PRODUCT_PRICE and pd.BRAND_NM = 'Thermador'
                               join POLICY_EXT_TBL on POLICY_EXT_TBL.POLICY_KEY = POLICY_TBL.POLICY_KEY
         where POLICY_PRODUCT_XID not  in (  select  distinct POLICY_PRODUCT_XID from PRODUCT_PRICE_DIM PD join POLICY_TBL PL using(POLICY_KEY) )
 )  where Upper(bora_pricing_category)  = PRODUCT_CAT_DESC
    and DO_NOT_SOLICIT_PRODUCT_IND = 'N'
    and Product_Coverage_End_Dt > sysdate + 365 + 42
 order by name;


select * from BOSH.PRODUCT_CATEGORY_DIM order by PRODUCT_CATEGORY_NM;

select count(distinct POLICY_KEY), count(distinct PRODUCT_KEY) from product_price_dim;

select count(distinct POLICY_KEY), count(distinct PRODUCT_KEY) from product_price_dim where POLICY_KEY < 6601;

select distinct POLICY_KEY, PRODUCT_KEY from product_price_dim where POLICY_KEY < 6601;
select * from BOSH.PRODUCT_DIM where PRODUCT_KEY =41036;
+--------+----------------------------------+---------+--------+
|MODEL_NO|PRODUCT_NM                        |PRICE_AMT|BRAND_NM|
+--------+----------------------------------+---------+--------+
|HMV8045U|HMV8045U, Over-The-Range Microwave|1049.00  |Bosch   |
+--------+----------------------------------+---------+--------+

    delete from PRODUCT_PRICE_DIM where PRODUCT_KEY = 41036 and POLICY_KEY < 6601;

select  * from PRODUCT_PRICE_DIM where PRODUCT_KEY = 41036 and POLICY_KEY < 6601;

    select * from AUDIT_TBL where AUDIT_KEY in (778318,840826);

-- for 13 pricing scheme is generated as RN7, Rn8 and R9 no SKU is present
select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$') as brand, pricing_scheme_type as type,
       PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY) as Terms
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms_list
       ,count(distinct PRODUCT_KEY) as Models, count(distinct ppd.POLICY_KEY) as Policies,
        count(*) as records, sum(BASE_PRICE_AMT) as BASE_PRICE_AMT
from   product_price_dim ppd
       join bosh.pricing_scheme_dim psd using (pricing_scheme_key)
       join bosh.policy_tbl pol on (pol.policy_key = ppd.policy_key)
       join P_PRODUCT_DIM pd using (product_key)
where 1=1
and   psd.END_DT > sysdate
and   pol.EXP_DT > sysdate
AND PRODUCT_KEY =41036
-- and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
and coalesce(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
--   and PRICING_SCHEME_DESC not like '%Bosch'
--   and PRICING_SCHEME_DESC not like '%BUILDER'
-- and PRICING_SCHEME_DESC like '%Thermador'
--   and pricing_scheme_type in ('AM', 'EB')
group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;


select count(distinct POLICY_KEY)
  from POLICY_TBL p join POLICY_EXT_TBL pe using (policy_key)
where POLICY_PRODUCT_XID in (
        select POLICY_PRODUCT_XID from PRODUCT_PRICE_DIM ppd join POLICY_TBL p using (policy_key)
    );