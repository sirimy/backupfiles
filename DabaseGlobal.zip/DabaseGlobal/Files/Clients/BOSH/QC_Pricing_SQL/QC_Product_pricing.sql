

select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$') as brand, pricing_scheme_type as type,
       PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY) as Terms
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms_list
       ,count(distinct PRODUCT_KEY) as Models, count(distinct ppd.POLICY_KEY) as Policies,
        count(*) as records, sum(BASE_PRICE_AMT) as BASE_PRICE_AMT
from   product_price_dim ppd
       join pricing_scheme_dim psd using (pricing_scheme_key)
       join policy_tbl pol on (pol.policy_key = ppd.policy_key)
       join P_PRODUCT_DIM pd using (product_key)
where 1=1
and   psd.END_DT > sysdate
and   pol.EXP_DT > sysdate
-- and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
and coalesce(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
--   and PRICING_SCHEME_DESC not like '%Bosch'
--   and PRICING_SCHEME_DESC not like '%BUILDER'
-- and PRICING_SCHEME_DESC like '%Thermador'
--   and pricing_scheme_type in ('AM', 'EB')
group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;