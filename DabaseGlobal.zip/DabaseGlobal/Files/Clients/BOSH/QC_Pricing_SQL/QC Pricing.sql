--Fetch pricing data by pricing scheme
--We got pricing created for 32 out of 48 policies, so no pricing for 16 SKUs
select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$') as brand, pricing_scheme_type as type,
       PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY) as Terms
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms_list
       ,count(distinct PRODUCT_KEY) as Models, count(distinct ppd.POLICY_KEY) as Policies,
        count(*) as records, sum(BASE_PRICE_AMT) as BASE_PRICE_AMT
from   product_price_dim ppd
       join pricing_scheme_dim psd using (pricing_scheme_key)
       join policy_tbl pol on (pol.policy_key = ppd.policy_key)
       join P_PRODUCT_DIM pd using (product_key)
where 1=1
and   psd.END_DT > sysdate
and   pol.EXP_DT > sysdate
-- and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
and coalesce(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
--   and PRICING_SCHEME_DESC not like '%Bosch'
--   and PRICING_SCHEME_DESC not like '%BUILDER'
-- and PRICING_SCHEME_DESC like '%Thermador'
--   and pricing_scheme_type in ('AM', 'EB')
group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
-- +---------+----+------------------+-------------------+---+-----+-------------+------+--------+-------+--------------+
-- |BRAND    |TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE|TERMS|TERMS_LIST   |MODELS|POLICIES|RECORDS|BASE_PRICE_AMT|
-- +---------+----+------------------+-------------------+---+-----+-------------+------+--------+-------+--------------+
-- |Bosch-ACM|AM  |220               |AM Bosch-ACM       |2  |5    |1, 2, 4, 5, 6|7     |20      |35     |6377.65       |
-- |Bosch-ACM|EB  |222               |EB Bosch-ACM       |2  |5    |1, 2, 4, 5, 6|7     |20      |35     |5102.12       |
-- |Bosch-ACM|OOW |221               |AO Bosch-ACM       |2  |3    |1, 2, 4      |7     |12      |21     |3789.79       |
-- +---------+----+------------------+-------------------+---+-----+-------------+------+--------+-------+--------------+
-- +---------+----+------------------+-------------------+---+-----+-------------+------+--------+-------+--------------+
-- |BRAND    |TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE|TERMS|TERMS_LIST   |MODELS|POLICIES|RECORDS|BASE_PRICE_AMT|
-- +---------+----+------------------+-------------------+---+-----+-------------+------+--------+-------+--------------+
-- |Bosch-ACM|AM  |220               |AM Bosch-ACM       |2  |5    |1, 2, 4, 5, 6|7     |20      |35     |6377.65       |
-- |Bosch-ACM|EB  |222               |EB Bosch-ACM       |2  |5    |1, 2, 4, 5, 6|7     |20      |35     |5102.12       |
-- |Bosch-ACM|OOW |221               |AO Bosch-ACM       |2  |3    |1, 2, 4      |7     |12      |21     |3789.79       |
-- +---------+----+------------------+-------------------+---+-----+-------------+------+--------+-------+--------------+




--Find SKU's which did not get created in PRODUCT_PRICE_DIM
select MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, count(*)
  from POLICY_TBL
where POLICY_PRODUCT_XID in (
        select POLICY_PRODUCT_XID from POLICY_TBL
        minus
        select POLICY_PRODUCT_XID from PRODUCT_PRICE_DIM ppd join POLICY_TBL p using (policy_key)
    )
group by MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE
order by MIN_PRODUCT_PRICE;
-- +-----------------+-----------------+--------+
-- |MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|COUNT(*)|
-- +-----------------+-----------------+--------+
-- |1000.00          |1499.99          |8       |
-- |2500.00          |2999.99          |8       |
-- +-----------------+-----------------+--------+
--So pricing did not get created for the above 16 SKUs
--
-- +-----------------+-----------------+--------+
-- |MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|COUNT(*)|
-- +-----------------+-----------------+--------+
-- |1000.00          |1499.99          |8       |
-- |2500.00          |2999.99          |8       |
-- +-----------------+-----------------+--------+

--Check if there are models for the MIN_PRODUCT_PRICE/MAX_PRODUCT_PRICE from above
select distinct MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, PRICE_AMT, MODEL_NO
  from POLICY_TBL
       join bosh.v_product pd on pd.PRICE_AMT between MIN_PRODUCT_PRICE and MAX_PRODUCT_PRICE
              and PRODUCT_CATEGORY_NM like 'COUNTER TOP COFFEE MACHINE'
 where POLICY_PRODUCT_XID in (
        select POLICY_PRODUCT_XID from POLICY_TBL
        minus
        select POLICY_PRODUCT_XID from PRODUCT_PRICE_DIM ppd join POLICY_TBL p using (policy_key)
    )
 order by MIN_PRODUCT_PRICE;
--no rows --no eligible models for these 16 SKUs
--this confirms why these SKUs did not get created in PRODUCT_PRICE_DIM


select MODEL_NO, PRODUCT_CATEGORY_NM, PRICE_AMT
  from bosh.v_product pd
 where PRODUCT_CATEGORY_NM like 'COUNTER TOP COFFEE MACHINE'
order by PRICE_AMT, MODEL_NO;
-- +--------+--------------------------+---------+
-- |MODEL_NO|PRODUCT_CATEGORY_NM       |PRICE_AMT|
-- +--------+--------------------------+---------+
-- |TIU20109|COUNTER TOP COFFEE MACHINE|699.00   |
-- |TIU20307|COUNTER TOP COFFEE MACHINE|799.00   |
-- |TIU20508|COUNTER TOP COFFEE MACHINE|899.00   |
-- |TPU60309|COUNTER TOP COFFEE MACHINE|1599.00  |
-- |TPU60501|COUNTER TOP COFFEE MACHINE|1799.00  |
-- |TQU60307|COUNTER TOP COFFEE MACHINE|1999.00  |
-- |TQU60703|COUNTER TOP COFFEE MACHINE|2299.00  |
-- |TPU60706|COUNTER TOP COFFEE MACHINE|null     |
-- |TQU60705|COUNTER TOP COFFEE MACHINE|null     |
-- +--------+--------------------------+---------+
+--------+--------------------------+---------+
|MODEL_NO|PRODUCT_CATEGORY_NM       |PRICE_AMT|
+--------+--------------------------+---------+
|TPU60706|COUNTER TOP COFFEE MACHINE|0.00     |
|TQU60705|COUNTER TOP COFFEE MACHINE|0.00     |
|TIU20109|COUNTER TOP COFFEE MACHINE|699.00   |
|TIU20307|COUNTER TOP COFFEE MACHINE|799.00   |
|TIU20508|COUNTER TOP COFFEE MACHINE|899.00   |
|TPU60309|COUNTER TOP COFFEE MACHINE|1599.00  |
|TPU60501|COUNTER TOP COFFEE MACHINE|1799.00  |
|TQU60307|COUNTER TOP COFFEE MACHINE|1999.00  |
|TQU60703|COUNTER TOP COFFEE MACHINE|2299.00  |
+--------+--------------------------+---------+
