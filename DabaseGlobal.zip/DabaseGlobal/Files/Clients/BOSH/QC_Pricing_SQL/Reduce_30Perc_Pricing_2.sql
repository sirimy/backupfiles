
select MAX(POLICY_KEY) from BOSH.POLICY_TBL;--6597

Select COUNT(*)  FROM policy_tbl;--162

Select COUNT(*)  FROM policy_lkp;--324

Select SOURCE_SYSTEM_CD,COUNT(*)  FROM policy_lkp group by SOURCE_SYSTEM_CD;--324
+----------------+--------+
|SOURCE_SYSTEM_CD|COUNT(*)|
+----------------+--------+
|0               |162     |
|2               |162     |
+----------------+--------+

Select COUNT(*)  FROM policy_item_tbl;--162

Select COUNT(*)  FROM  POLICY_COVERAGE_TBL;--324

Select COVERAGE_TYPE_KEY,COUNT(*)  FROM  POLICY_COVERAGE_TBL group by COVERAGE_TYPE_KEY;--324
+-----------------+--------+
|COVERAGE_TYPE_KEY|COUNT(*)|
+-----------------+--------+
|2                |162     |
|3                |162     |
+-----------------+--------+

Select COUNT(*)  FROM   T_AND_C_CONTRACT_TEMPLATE_XREF;--8262
Select TERMS_AND_CONDITIONS_KEY,POSTAL_STATE_KEY,COUNT(*)
FROM   T_AND_C_CONTRACT_TEMPLATE_XREF group by TERMS_AND_CONDITIONS_KEY,POSTAL_STATE_KEY;

Select COUNT(distinct  TERMS_AND_CONDITIONS_KEY),COUNT( distinct POLICY_KEY),COUNT( distinct POSTAL_STATE_KEY),COUNT(*)
FROM   T_AND_C_CONTRACT_TEMPLATE_XREF ;
+---------------------------------------+-------------------------+-------------------------------+--------+
|COUNT(DISTINCTTERMS_AND_CONDITIONS_KEY)|COUNT(DISTINCTPOLICY_KEY)|COUNT(DISTINCTPOSTAL_STATE_KEY)|COUNT(*)|
+---------------------------------------+-------------------------+-------------------------------+--------+
|1                                      |162                      |51                             |8262    |
+---------------------------------------+-------------------------+-------------------------------+--------+

select distinct B.BRAND,UPPER(B.CHANNELS),COUNT(*)
from BOSHSTG.policy_ext_tbl B
group by B.BRAND,UPPER(B.CHANNELS)
ORDER BY UPPER(B.CHANNELS)
;
+---------+-----------------+--------+
|BRAND    |UPPER(B.CHANNELS)|COUNT(*)|
+---------+-----------------+--------+
|THERMADOR|AM EB            |42      |
|THERMADOR|OOW              |20      |
|THERMADOR|RENEWAL PROGRAM  |100     |
+---------+-----------------+--------+



select POLICY_FEE_TYPE_KEY,DESCRIPTION,EFFECTIVE_DT
           ,COUNT(*) from policy_fee_xref join bosh.POLICY_FEE_TYPE using(POLICY_FEE_TYPE_KEY)
                     group by POLICY_FEE_TYPE_KEY,DESCRIPTION,EFFECTIVE_DT;
+-------------------+--------------------------+--------------------------+--------+
|POLICY_FEE_TYPE_KEY|DESCRIPTION               |EFFECTIVE_DT              |COUNT(*)|
+-------------------+--------------------------+--------------------------+--------+
|3                  |Underwriter Premium Amount|2024-07-19 00:00:00.000000|162     |
|1                  |ESP retail amount         |2024-07-19 00:00:00.000000|162     |
+-------------------+--------------------------+--------------------------+--------+



Select COUNT(*)  FROM policy_discount_tbl;--162

 select POLICY_FEE_TYPE_KEY,DESCRIPTION,EFFECTIVE_DT
           ,COUNT(*) from policy_discount_tbl join bosh.POLICY_FEE_TYPE using(POLICY_FEE_TYPE_KEY)
                     group by POLICY_FEE_TYPE_KEY,DESCRIPTION,EFFECTIVE_DT;
+-------------------+-----------------+------------+--------+
|POLICY_FEE_TYPE_KEY|DESCRIPTION      |EFFECTIVE_DT|COUNT(*)|
+-------------------+-----------------+------------+--------+
|1                  |ESP retail amount|2024-07-19  |162     |
+-------------------+-----------------+------------+--------+
