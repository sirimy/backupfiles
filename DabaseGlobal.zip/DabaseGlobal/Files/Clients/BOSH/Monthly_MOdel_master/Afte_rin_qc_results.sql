

select FILE_NM,COUNT(FILE_NM) from RAW_MODEL_MASTER_TBL
where MATERIAL_GROUP <> 'Accessory' AND  MAP_UMRP IS NOT NULL and ERROR_DESC is null
group by FILE_NM
order by FILE_NM;
-- +------------------------------------------------------+--------------+
-- |FILE_NM                                               |COUNT(FILE_NM)|
-- +------------------------------------------------------+--------------+
-- |20260511_073445_AfterInc-Bosch.csv                    |259           |
-- |20260511_073445_AfterInc-Thermador_20260504_033227.csv|179           |
-- |20260511_073445_AfterInc.csv                          |105           |
-- +------------------------------------------------------+--------------+


select ERROR_DESC,COUNT(FILE_NM) from RAW_MODEL_MASTER_TBL
where MATERIAL_GROUP <> 'Accessory'
group by ERROR_DESC
order by ERROR_DESC;

-- +-------------------------------------------------------------------------------------------------------+--------------+
-- |ERROR_DESC                                                                                             |COUNT(FILE_NM)|
-- +-------------------------------------------------------------------------------------------------------+--------------+
-- |Model exists in core with a different price                                                            |6             |
-- |Model exists in core with a not null price                                                             |15            |
-- |Model exists in core. Checking in bosh.PRODUCT_DIM based upon (BRAND, MATERIAL, coalesce(MAP_UMRP, '0')|428           |
-- |null                                                                                                   |94            |
-- +-------------------------------------------------------------------------------------------------------+--------------+


-- [1] Total 2 new product created
-- [2] Total 2 Gaggenau old product have Price Amount
-- [3] Total 1 new product have have 2 leads in SI_DIM |WGA14400UC|Bosch   |1249.00  |LAUNDRY-WASHER      |
--[4] Pricing generated for 5 models

select * from RAW_MODEL_MASTER_TBL
         where MATERIAL not in (select  MODEL_NO from BOSH.PRODUCT_DIM)
        and ERROR_DESC is null
and MAP_UMRP IS NOT NULL
and MATERIAL_GROUP <> 'Accessory'

;


select * from BOSH.RAW_MODEL_MASTER_TBL where MATERIAL in (
select MATERIAL from RAW_MODEL_MASTER_TBL
         where MATERIAL in (select  MODEL_NO from BOSH.PRODUCT_DIM)
        and ERROR_DESC is null)

order by MATERIAL
;




select * from PRODUCT_CATALOG_TBL where PRODUCT_CATEGORY_UNIQUE_ID <> 'OTHER';--4


select * from PRODUCT_CATALOG_TBL where PRODUCT_UNIQUE_ID in(
        select PRODUCT_DIM.MODEL_NO from BOSH.PRODUCT_DIM
    );--0

select * from PRODUCT_CATALOG_TBL where PRODUCT_UNIQUE_ID not in(
        select PRODUCT_DIM.MODEL_NO from BOSH.PRODUCT_DIM
    );--4

select * from PRODUCT_CATALOG_TBL where PRODUCT_UNIQUE_ID not in(
        select PRODUCT_DIM.MODEL_NO from BOSH.PRODUCT_DIM
    )
and PRODUCT_CATEGORY_UNIQUE_ID <> 'OTHER'
;--4





--nohup ${HOME}/jobs/scripts/session_script_new.sh -j "modelmaster/process.job" -l "${HOME}/logs/modelmaster/modelmaster.log" &

select * from PRODUCT_CATALOG_TBL where PRODUCT_UNIQUE_ID not in(
        select PRODUCT_DIM.MODEL_NO from BOSH.PRODUCT_DIM
    )
and PRODUCT_CATEGORY_UNIQUE_ID <> 'OTHER' AND PRICE_AMT is not null
;--1

-- +-----------------+---------+----------------------------------------------------------------+
-- |PRODUCT_UNIQUE_ID|PRICE_AMT|PRODUCT_NM                                                      |
-- +-----------------+---------+----------------------------------------------------------------+
-- |B36IT100NP       |9199.00  |B36IT100NP, Vario built-in fridge-freezer with freezer at bottom|
-- |B30BB130SS       |9199.00  |B30BB130SS, Vario built-in fridge-freezer with freezer at bottom|
-- |B36BT130NS       |10199.00 |B36BT130NS, Vario built-in fridge-freezer with freezer at bottom|
-- +-----------------+---------+----------------------------------------------------------------+


Select   AT.CREATION_DT,VPD.BRAND_NM,VPD.PRODUCT_CATEGORY_NM
     ,RD.MATERIAL, RD.MATERIAL_DESCRIPTION, RD.MATERIAL_GROUP, RD.SALES_STATUS, RD.VALID_FROM, RD.EF_OUT_DATE, RD.UPC_CODE, RD.NEW_BUSINESS_FIELD, RD.PRODUCT_TYPE, RD.MAP_UMRP, RD.SK_MARKETING_DESCRIPTION
        from V_PRODUCT VPD
            join BOSH.PRODUCT_DIM PD on PD.PRODUCT_KEY = VPD.PRODUCT_KEY
            join AUDIT_TBL AT on  PD.INSERT_AUDIT_KEY = AT.AUDIT_KEY
            join BOSH.RAW_MODEL_MASTER_TBL RD on RD.MATERIAL = VPD.MODEL_NO
Where TRUNC(AT.CREATION_DT) = date'2026-05-11'
Order by VPD.BRAND_NM,VPD.PRODUCT_CATEGORY_NM;


Select  PD.PRODUCT_KEY,PD.PRODUCT_NM,PD.MODEL_NO,VPD.BRAND_NM,PD.PRICE_AMT,VPD.PRODUCT_CATEGORY_NM,AT.CREATION_DT
        from V_PRODUCT VPD
            join BOSH.PRODUCT_DIM PD on PD.PRODUCT_KEY = VPD.PRODUCT_KEY
            join AUDIT_TBL AT on
            PD.INSERT_AUDIT_KEY = AT.AUDIT_KEY
Where AT.CREATION_DT > SYSDATE -2
--AND PRODUCT_CATEGORY_NM <> 'OTHER'
--and PD.PRICE_AMT IS   NULL
Order by VPD.BRAND_NM,VPD.PRODUCT_CATEGORY_NM;
-- 149

-- +-----------+----------+--------+---------+-------------------+--------------------------+
-- |PRODUCT_KEY|MODEL_NO  |BRAND_NM|PRICE_AMT|PRODUCT_CATEGORY_NM|CREATION_DT               |
-- +-----------+----------+--------+---------+-------------------+--------------------------+
-- |46002      |SHP65DC5N |Bosch   |NULL     |DISHWASHER         |2025-12-09 00:20:32.000000|
-- |46004      |SHX78DC5N |Bosch   |NULL     |DISHWASHER         |2025-12-09 00:20:32.000000|
-- |46006      |HEF3050MU |Bosch   |1899.00  |COOKING            |2025-12-09 00:20:32.000000|
-- |46008      |HGF3050MUC|Bosch   |1999.00  |COOKING            |2025-12-09 00:20:32.000000|
-- +-----------+----------+--------+---------+-------------------+--------------------------+

 Select  VP.PRODUCT_KEY,VP.BRAND_NM,VP.PRICE_AMT,VP.PRODUCT_NM,COUNT(PD.PRODUCT_KEY) from BOSH.PRODUCT_PRICE_DIM PD
     join AUDIT_TBL AT on
            PD.INSERT_AUDIT_KEY = AT.AUDIT_KEY
     JOIN V_PRODUCT VP ON
            VP.PRODUCT_KEY = PD.PRODUCT_KEY
    Where AT.CREATION_DT > SYSDATE -1
group by  VP.PRODUCT_KEY,VP.BRAND_NM,VP.PRICE_AMT,VP.PRODUCT_NM
;
+-----------+--------+---------+---------------------------------------+---------------------+
|PRODUCT_KEY|BRAND_NM|PRICE_AMT|PRODUCT_NM                             |COUNT(PD.PRODUCT_KEY)|
+-----------+--------+---------+---------------------------------------+---------------------+
|46574      |Bosch   |2349.00  |HIF5050MU, Induction Freestanding Range|60                   |
+-----------+--------+---------+---------------------------------------+---------------------+




select VP.PRODUCT_KEY,VP.BRAND_NM,VP.PRODUCT_NM,COUNT(SID.SI_KEY) AS Lead_Counts
from V_PRODUCT VP  LEFT join BOSH.SERIALIZED_ITEM_DIM SID
  on VP.PRODUCT_KEY = SID.PRODUCT_KEY
where VP.PRODUCT_KEY in (
    Select PD.PRODUCT_KEY from BOSH.PRODUCT_PRICE_DIM PD join AUDIT_TBL AT on
            PD.INSERT_AUDIT_KEY = AT.AUDIT_KEY
    Where AT.CREATION_DT > SYSDATE -2)
Group By VP.PRODUCT_KEY,VP.PRODUCT_NM,VP.BRAND_NM
;


select VP.PRODUCT_KEY,VP.BRAND_NM,VP.PRODUCT_NM,COUNT(SID.SI_KEY) AS Lead_Counts
from V_PRODUCT VP  LEFT join BOSH.SERIALIZED_ITEM_DIM SID
  on VP.PRODUCT_KEY = SID.PRODUCT_KEY
where VP.PRODUCT_KEY in (
    Select PD.PRODUCT_KEY from BOSH.PRODUCT_PRICE_DIM PD join AUDIT_TBL AT on
            PD.INSERT_AUDIT_KEY = AT.AUDIT_KEY
    Where AT.CREATION_DT > SYSDATE -2)
Group By VP.PRODUCT_KEY,VP.PRODUCT_NM,VP.BRAND_NM
;
-- +-----------+--------+---------------------------------------+-----------+
-- |PRODUCT_KEY|BRAND_NM|PRODUCT_NM                             |LEAD_COUNTS|
-- +-----------+--------+---------------------------------------+-----------+
-- |46574      |Bosch   |HIF5050MU, Induction Freestanding Range|0          |
-- +-----------+--------+---------------------------------------+-----------+


-- check range of pricing with brand and cat
select max( MAX_PRODUCT_PRICE),min(MIN_PRODUCT_PRICE) ,pex.PRODUCT_CAT_DESC,pex.BRAND
    from BOSH.POLICY_TBL pl
    join BOSH.POLICY_EXT_TBL pex on pl.POLICY_KEY = pex.POLICY_KEY
where EXP_DT > sysdate
GROUP BY pex.PRODUCT_CAT_DESC,pex.BRAND
order by pex.BRAND,pex.PRODUCT_CAT_DESC

;
-- +----------------------+----------------------+---------------------------+-----+
-- |MAX(MAX_PRODUCT_PRICE)|MIN(MIN_PRODUCT_PRICE)|PRODUCT_CAT_DESC           |BRAND|
-- +----------------------+----------------------+---------------------------+-----+
-- |8999.99               |1500                  |REFRIGERATOR WITH FOOD LOSS|Bosch|
-- |9999.99               |1500                  |Refrigerator With Food Loss|Bosch|
-- +----------------------+----------------------+---------------------------+-----+

select * from V_PRODUCT where PRODUCT_KEY = 44620;
select * from BOSH.PRODUCT_PRICE_DIM where PRODUCT_KEY = 44620;

Select PD.PRODUCT_KEY,PD.MODEL_NO,VPD.BRAND_NM,PD.PRICE_AMT,VPD.PRODUCT_CATEGORY_NM,AT.CREATION_DT
        from V_PRODUCT VPD
            join BOSH.PRODUCT_DIM PD on PD.PRODUCT_KEY = VPD.PRODUCT_KEY
            join AUDIT_TBL AT on
            PD.UPDATE_AUDIT_KEY = AT.AUDIT_KEY
Where AT.CREATION_DT > SYSDATE -1
--AND PRODUCT_CATEGORY_NM <> 'OTHER' --and PD.PRICE_AMT IS NULL
Order by VPD.BRAND_NM;





select * from BOSH.RAW_MODEL_MASTER_TBL where MATERIAL = 'TPU40109' order by INSERT_AUDIT_KEY desc;

select MODEL_NO,COUNT(*) from BOSH.SERIALIZED_ITEM_DIM where MODEL_NO in(
    Select  PD.MODEL_NO
            from V_PRODUCT VPD
                join BOSH.PRODUCT_DIM PD on PD.PRODUCT_KEY = VPD.PRODUCT_KEY
                join AUDIT_TBL AT on
                PD.INSERT_AUDIT_KEY = AT.AUDIT_KEY
    Where AT.CREATION_DT > SYSDATE -1)
GROUP BY MODEL_NO
;--
-- +----------+--------+
-- |MODEL_NO  |COUNT(*)|
-- +----------+--------+
-- |SHV53EM3N |1       |
-- |PXV875DV1E|1       |
-- |HEF3050MC |1       |
-- |HMV8045C  |3       |
-- |HMV3055C  |3       |
-- |SHP53EM5N |3       |
-- |HEF1050MC |6       |
-- |SHP55DM5N |6       |
-- |PRI36LBHC |12      |
-- |HMV3054C  |15      |
-- |PRI30LBHC |15      |
-- |SHE5AEH5N |17      |
-- |HIS8655C  |28      |
-- |SHS53CM5N |33      |
-- |SHS53C75N |34      |
-- |HMV1055C  |45      |
-- |HIIP057C  |51      |
-- |HIS8055C  |52      |
-- |HII8057C  |60      |
-- |SHP55CM5N |79      |
-- |HDS8045C  |252     |
-- +----------+--------+

Select  PD.PRODUCT_KEY ,VPD.MODEL_NO,VPD.PRICE_AMT,VPD.BRAND_NM,COUNT(*)
    from BOSH.PRODUCT_PRICE_DIM PD
        join AUDIT_TBL AT on  PD.INSERT_AUDIT_KEY = AT.AUDIT_KEY
        join BOSH.V_PRODUCT VPD on PD.PRODUCT_KEY = VPD.PRODUCT_KEY
                    Where AT.CREATION_DT > SYSDATE -1
group by PD.PRODUCT_KEY ,VPD.MODEL_NO,VPD.PRICE_AMT,VPD.BRAND_NM;--



select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   P_product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
where
    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
and ppd.PRODUCT_KEY = 46574
--and AT.CREATION_DT > SYSDATE -1
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
-- +-------------------+------------------+-------------------+----+-----------------------+----------+
-- |PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE |COUNT(DISTINCTTERM_KEY)|TERMS     |
-- +-------------------+------------------+-------------------+----+-----------------------+----------+
-- |AM                 |279               |AM Bosch           |1   |4                      |1, 2, 4, 6|
-- |BUILDER            |175               |BUILDER            |null|4                      |1, 2, 3, 4|
-- |EB                 |280               |EB Bosch           |1   |4                      |1, 2, 4, 6|
-- |OOW                |281               |AO Bosch           |1   |3                      |1, 2, 4   |
-- |OOW                |290               |RO 2 Bosch         |1   |3                      |1, 2, 4   |
-- |OOW                |291               |RO 3 Bosch         |1   |2                      |1, 2      |
-- |OOW                |292               |RO 4 Bosch         |1   |2                      |1, 2      |
-- |OOW                |293               |RO 5 Bosch         |1   |1                      |1         |
-- |OOW                |294               |RO 6 Bosch         |1   |2                      |1, 2      |
-- |OOW                |295               |RO 7 Bosch         |1   |2                      |1, 2      |
-- |OOW                |296               |RO 8 Bosch         |1   |1                      |1         |
-- |RN                 |282               |RN 2 Bosch         |2   |4                      |2, 3, 4, 5|
-- |RN                 |283               |RN 3 Bosch         |3   |4                      |2, 3, 4, 5|
-- |RN                 |284               |RN 4 Bosch         |4   |4                      |2, 3, 4, 5|
-- |RN                 |285               |RN 5 Bosch         |5   |4                      |2, 3, 4, 5|
-- |RN                 |286               |RN 6 Bosch         |6   |4                      |1, 2, 3, 4|
-- |RN                 |287               |RN 7 Bosch         |7   |3                      |1, 2, 3   |
-- |RN                 |288               |RN 8 Bosch         |8   |2                      |1, 2      |
-- |RN                 |289               |RN 9 Bosch         |9   |1                      |1         |
-- +-------------------+------------------+-------------------+----+-----------------------+----------+


Select
       T1.PRODUCT_CAT_DESC ,
       BRAND_NM ,
       min(MIN_PRODUCT_PRICE),
       max(MAX_PRODUCT_PRICE),
       listagg(distinct PRICE_AMT, ', ') WITHIN GROUP (ORDER BY PRICE_AMT) as PRICE_AMTs
from (
    select distinct pl.POLICY_PRODUCT_XID,DESCRIPTION,pex.PRODUCT_CAT_DESC,pex.BRAND_FAMILY_CD, pl.MIN_PRODUCT_PRICE,pl.MAX_PRODUCT_PRICE  from P_POLICY_TBL PL
                            join P_POLICY_EXT_TBL Pex on pl.POLICY_KEY = Pex.POLICY_KEY

)T1 join  (
              select bora_pricing_category,BRAND_FAMILY_CD,BRAND_NM,PRICE_AMT from (
                    select pd.product_key,model_no,product_nm, product_dsc, product_category_nm,
                                             case when lower(product_category_nm) like 'refrig%' then 'Refrigerator With Food Loss'--'REFRIGERATION W LOSS'
                                             when lower(product_category_nm) like '%counter top coffee machine' then 'Countertop Espresso Machine'
                                             when lower(product_category_nm) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                                             when lower(product_category_nm) like '%dish%' then 'DISHWASHER'
                                             when lower(product_dsc) like '%hood%' or lower(PRODUCT_CATEGORY_nm) like '%venti%'  then 'VENTILATION'
                                             when lower(product_category_nm) like 'cooking' then 'COOKING'
                                             when lower(product_category_nm) like '%laundry%' and lower(product_dsc) like '%dryer%' then 'LAUNDRY-DRYER'
                                             when lower(product_category_nm) like '%laundry%' then 'LAUNDRY-WASHER'
                                             else 'other' end as bora_pricing_category,
                                             brand_nm, price_amt, brand_key,BRAND_FAMILY_CD --,sku_no, upc_cd
                                      from
                                           bosh.v_product pd
                                     where PRODUCT_KEY in (42022,42020,42018,31324,31324) AND
                                           NVL(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
                                       and PRODUCT_COVERAGE_END_DT >= sysdate
                                       and NVL( pd.price_amt, 0 ) <> 0) T3
                       GROUP BY bora_pricing_category,BRAND_FAMILY_CD,BRAND_NM,PRICE_AMT
)T2 on T2.bora_pricing_category = T1.PRODUCT_CAT_DESC and T2.BRAND_FAMILY_CD = T1.BRAND_FAMILY_CD
--where PRICE_AMT between min_product_price and max_product_price
GROUP BY
       T1.PRODUCT_CAT_DESC ,
       BRAND_NM
order by BRAND_NM,PRODUCT_CAT_DESC;


select PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_DESC,PEX.BRAND_FAMILY_CD,COUNT(distinct VP.PRODUCT_KEY ) PRODUCT_KEY_CNT,COUNT(distinct PRD.POLICY_KEY ) POLICY_KEY_CNT
    , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
    , listagg(distinct pl.age,', ') WITHIN GROUP (ORDER BY pl.POLICY_KEY) as Age
    , listagg(distinct pex.CHANNELS,', ') WITHIN GROUP (ORDER BY pl.POLICY_KEY) as CHANNELS
    , listagg(distinct pl.POLICY_KEY,', ') WITHIN GROUP (ORDER BY pl.POLICY_KEY) as POLICY_KEY
    from PRODUCT_PRICE_DIM PRD
                    JOIN V_PRODUCT VP on PRD.PRODUCT_KEY = VP.PRODUCT_KEY
                    JOIN BOSH.PRICING_SCHEME_DIM PSD on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                    JOIN BOSH.POLICY_TBL PL on PL.POLICY_KEY = PRD.POLICY_KEY
                    JOIN BOSH.POLICY_EXT_TBL PEX on PEX.POLICY_KEY = PL.POLICY_KEY
    Where PSD.END_DT > sysdate
               AND DO_NOT_SOLICIT_PRODUCT_IND = 'N'
    GROUP BY PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_DESC,PEX.BRAND_FAMILY_CD;




