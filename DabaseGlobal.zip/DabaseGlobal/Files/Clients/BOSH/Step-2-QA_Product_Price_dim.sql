--Checking if any policies with applicable/available models are missing from product_price_dim
select distinct pex.brand, product_cat_desc, min_product_price, max_product_price --policy_product_xid, policy_key, age, tr.name
  from POLICY_EXT_TBL pex join policy_tbl pol using (policy_key) join bosh.term_dim tr using (term_key)
 where 1=1
   and policy_key IN (
        select policy_key from policy_tbl where name not like 'Gaggenau%' --and DESCRIPTION like '%(AO)'
        minus
        select policy_key from product_price_dim
        )
   and EXISTS(
         select distinct product_category_nm, material_group, marketing_product_nm, brand_nm
           from v_product vpr
          where 1=1
            and vpr.do_not_solicit_product_ind = 'N'
            and vpr.product_coverage_end_dt >= sysdate + 365
            and vpr.price_amt is not null
            and case when upper(vpr.product_category_nm) = 'REFRIGERATION W LOSS' then replace('REFRIGERATOR WITH FOOD LOSS', ' ')
                     else replace(upper(vpr.product_category_nm), ' ')
                end =
                      replace(upper(pex.product_cat_desc), ' ')
            and vpr.price_amt between min_product_price and max_product_price
            and upper(vpr.brand_nm) = upper(pex.brand)
          )
 order by brand, product_cat_desc, min_product_price, max_product_price --, age, tr.name
 ;
--no rows --good
--No coffee makers for Gaggenau

------------------------------------------------------------------


--Checking how many policies don't have corresponding/eligible  models and hence are missing from product_price_dim
--This sql is opposite of the one above
select distinct brand, product_cat_desc, min_product_price, max_product_price --policy_product_xid, policy_key, age, tr.name
  from POLICY_EXT_TBL pex join policy_tbl pol using (policy_key) join bosh.term_dim tr using (term_key)
 where policy_key IN (
        select policy_key from policy_tbl where name not like 'Gaggenau%' --and DESCRIPTION like '%(AO)'
        minus
        select policy_key from product_price_dim
        )
   and NOT EXISTS(
         select distinct vpr.product_category_nm, vpr.material_group, vpr.marketing_product_nm, vpr.brand_nm
           from v_product vpr
          where 1=1
            and vpr.do_not_solicit_product_ind = 'N'
            and vpr.product_coverage_end_dt >= sysdate
            and case when upper(vpr.product_category_nm) = 'REFRIGERATION W LOSS' then replace('REFRIGERATOR WITH FOOD LOSS', ' ')
                     else replace(upper(vpr.product_category_nm), ' ')
                end =
                      replace(upper(pex.product_cat_desc), ' ')
            and vpr.price_amt between min_product_price and max_product_price
            and upper(vpr.brand_nm) = upper(pex.brand)
          )
 order by brand, product_cat_desc, min_product_price, max_product_price --, age, tr.name
 ;
/*
BRAND,PRODUCT_CAT_DESC,MIN_PRODUCT_PRICE,MAX_PRODUCT_PRICE
Bosch,Built-In Coffee Maker,500.00,749.99        --no bosch model in this range. Minimum MSRP is 2349.00 in Product_Dim
Bosch,Built-In Coffee Maker,750.00,999.99        --no bosch model in this range.
Bosch,Built-In Coffee Maker,1000.00,1499.99      --no bosch model in this range.
Bosch,Built-In Coffee Maker,1500.00,1999.99      --no bosch model in this range.
Bosch,Built-In Coffee Maker,2500.00,2999.99      --no bosch model in this range.
Bosch,Cooking,5000.00,5499.99                    --no Bosch model in this range.
Bosch,Laundry-Dryer,500.00,749.99                --no Bosch model in this range.
Bosch,Laundry-Dryer,2000.00,2499.99              --no Bosch model in this range.
Bosch,Laundry-Washer,500.00,749.99               --no Bosch model in this range.
Bosch,Laundry-Washer,2000.00,2499.99             --no Bosch model in this range.
Bosch,Refrigerator With Food Loss,9000.00,9999.99      --no Bosch model in this range.
Thermador,Built-In Coffee Maker,1000.00,1499.99   --no Thermador model in this range.
Thermador,Built-In Coffee Maker,1500.00,1999.99   --no Thermador model in this range.
Thermador,Built-In Coffee Maker,2000.00,2499.99   --no Thermador model in this range.
Thermador,Built-In Coffee Maker,3000.00,3499.99   --no Thermador model in this range.
Thermador,Cooking,500.00,749.99                   --no Thermador model in this range. Minimum MSRP is 799.00
Thermador,Dishwasher,500.00,749.99                --no Thermador model in this range.
Thermador,Dishwasher,750.00,999.99                --no Thermador model in this range.
Thermador,Refrigerator With Food Loss,1500.00,1999.99    --no Thermador model in this range.
Thermador,Refrigerator With Food Loss,12500.00,14999.99  --no Thermador model in this range. Maximum MSRP is 10349.00
Thermador,Refrigerator With Food Loss,15000.00,17499.99  --no Thermador model in this range. Maximum MSRP is 10349.00
Thermador,Ventilation,500.00,749.99                      --no Thermador model in this range. Minimum MSRP is 799.00
*/
/*
 -- Cooking models this time not coming in list
 BRAND,PRODUCT_CAT_DESC,MIN_PRODUCT_PRICE,MAX_PRODUCT_PRICE
Bosch,Built-In Coffee Maker,500.00,749.99 -- 2349.00
Bosch,Built-In Coffee Maker,750.00,999.99
Bosch,Built-In Coffee Maker,1000.00,1499.99
Bosch,Built-In Coffee Maker,1500.00,1999.99
Bosch,Built-In Coffee Maker,2500.00,2999.99
Bosch,Laundry-Dryer,500.00,749.99 --150.00
Bosch,Laundry-Dryer,2000.00,2499.99
Bosch,Laundry-Washer,500.00,749.99
Bosch,Laundry-Washer,2000.00,2499.99
Bosch,Refrigerator With Food Loss,9000.00,9999.99
Thermador,Built-In Coffee Maker,1000.00,1499.99 -- 2599.00
Thermador,Built-In Coffee Maker,1500.00,1999.99
Thermador,Built-In Coffee Maker,2000.00,2499.99
Thermador,Built-In Coffee Maker,3000.00,3499.99
Thermador,Dishwasher,500.00,749.99
Thermador,Dishwasher,750.00,999.99
Thermador,Refrigerator With Food Loss,1500.00,1999.99
Thermador,Refrigerator With Food Loss,12500.00,14999.99
Thermador,Refrigerator With Food Loss,15000.00,17499.99
Thermador,Ventilation,500.00,749.99


 */
select Distinct  product_category_nm from V_PRODUCT;
select * from V_PRODUCT where product_category_nm = 'LAUNDRY-DRYER' order by  V_PRODUCT.PRICE_AMT asc;




--these missing SKUs correspond to findings above
select pex.brand, product_cat_desc, min_product_price, max_product_price, policy_product_xid, pol.DESCRIPTION, policy_key, age, tr.name
  from POLICY_EXT_TBL pex join policy_tbl pol using (policy_key) join bosh.term_dim tr using (term_key)
 where 1=1
   and policy_key IN (
        select policy_key from policy_tbl
        minus
        select policy_key from product_price_dim
        )
--    and pol.DESCRIPTION not like '%(RN)'  --as we did not process RN policies in this round
order by pex.brand, product_cat_desc, min_product_price, max_product_price;
/*BRAND    PRODUCT_CAT_DESC    MIN_PRODUCT_PRICE    MAX_PRODUCT_PRICE    POLICY_PRODUCT_XID    POLICY_KEY    AGE    NAME
--total 44 rows
*/

select PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, count(*), count(distinct POLICY_KEY) as policies,
       count(distinct PRODUCT_KEY) as models, count(distinct TERM_MONTHS) as terms
from   product_price_dim ppd join PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY)
group by PRICING_SCHEME_KEY, PRICING_SCHEME_DESC order by PRICING_SCHEME_KEY;
/*PRICING_SCHEME_KEY,PRICING_SCHEME_DESC,COUNT(*),POLICIES,MODELS,TERMS
75,AM Thermador,1692,148,423,4
76,AM Bosh,3190,185,642,5
77,EB Thermador,1692,148,423,4
78,EB Bosh,3190,185,642,5
*/
-- out of total  policies/SKUs got created in product_price_dim


--Verifying that all existing plans/terms/models against existing pricing schemes got created against new PRICING_SCHEME_KEYs in stg also
select POLICY_KEY, PRODUCT_KEY, TERM_MONTHS
from   bosh.product_price_dim ppd join bosh.PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY) where PRICING_SCHEME_KEY = 57
minus
select POLICY_KEY, PRODUCT_KEY, TERM_MONTHS
from   product_price_dim ppd join PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY) where PRICING_SCHEME_KEY = 75;
--no rows --good

select POLICY_KEY, PRODUCT_KEY, TERM_MONTHS
from   bosh.product_price_dim ppd join bosh.PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY) where PRICING_SCHEME_KEY = 58
minus
select POLICY_KEY, PRODUCT_KEY, TERM_MONTHS
from   product_price_dim ppd join PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY) where PRICING_SCHEME_KEY = 76;
--no rows --good

select POLICY_KEY, PRODUCT_KEY, TERM_MONTHS
from   bosh.product_price_dim ppd join bosh.PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY) where PRICING_SCHEME_KEY = 59
minus
select POLICY_KEY, PRODUCT_KEY, TERM_MONTHS
from   product_price_dim ppd join PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY) where PRICING_SCHEME_KEY = 77;
--no rows --good

select POLICY_KEY, PRODUCT_KEY, TERM_MONTHS
from   bosh.product_price_dim ppd join bosh.PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY) where PRICING_SCHEME_KEY = 60
minus
select POLICY_KEY, PRODUCT_KEY, TERM_MONTHS
from   product_price_dim ppd join PRICING_SCHEME_DIM using (PRICING_SCHEME_KEY) where PRICING_SCHEME_KEY = 78;
--no rows --good



Select PRODUCT_KEY,bora_pricing_category,brand_nm, price_amt ,
(Select  MIN(TO_NUMBER(RPT.MIN_PRODUCT_PRICE)) From RAW_PRICING_TBL RPT Where  RPT.BRAND = brand_nm and lower(bora_pricing_category) = lower(RPT.PRODUCT_CAT_DESC)) AS MIN_PRODUCT_PRICE,
(Select  MAX(TO_NUMBER(RPT.MAX_PRODUCT_PRICE)) From RAW_PRICING_TBL RPT Where  RPT.BRAND = brand_nm and lower(bora_pricing_category) = lower(RPT.PRODUCT_CAT_DESC)) AS MAX_PRODUCT_PRICE
from (
select pd.product_key,model_no,product_nm, product_dsc, product_category_nm,
                             case when lower(product_category_nm) like 'refrig%' then 'Refrigerator With Food Loss'--'REFRIGERATION W LOSS'
                             when lower(product_category_nm) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                             when lower(product_category_nm) like '%dish%' then 'DISHWASHER'
                             when lower(product_dsc) like '%hood%' or lower(PRODUCT_CATEGORY_nm) like '%venti%'  then 'VENTILATION'
                             when lower(product_category_nm) like 'cooking' then 'COOKING'
                             when lower(product_category_nm) like '%laundry%' and lower(product_dsc) like '%dryer%' then 'LAUNDRY-DRYER'
                             when lower(product_category_nm) like '%laundry%' then 'LAUNDRY-WASHER'
                             else 'other' end as bora_pricing_category,
                             brand_nm, price_amt, brand_key --,sku_no, upc_cd
                      from
                           bosh.v_product pd
                     where
                           NVL(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
                       and PRODUCT_COVERAGE_END_DT >= sysdate
                       and NVL( pd.price_amt, 0 ) <> 0
                        and pd.BRAND_NM <> 'Gaggenau'
                        AND  pd.PRODUCT_CATEGORY_NM <> 'OTHER'
                        and PRODUCT_KEY not in (select PRODUCT_KEY from PRODUCT_PRICE_DIM))
Order by BRAND_NM;