--We will create new pricing schemes to support RO terms based upon age

declare
  v_audit_key number;
begin
  v_audit_key := bosh.get_audit_key (p_program_nm => 'Campaign', p_descriptive_tx => 'BOSH-1024: Renewal Win-back BAU Campaign', p_table_nm => 'PRICING_SCHEME_DIM');
  DBMS_OUTPUT.put_line(v_audit_key);
  COMMIT;
end;
--569745


insert into PRICING_SCHEME_DIM (PRICING_SCHEME_KEY, PRICING_SCHEME_NAME, PRICING_SCHEME_DESC, LOAD_DT, INSERT_AUDIT_KEY, PRICING_SCHEME_TYPE)
values (116, 'RO Thermador', 'RO 3 Thermador', date '2022-07-18', 569745, 'OOW');

insert into PRICING_SCHEME_DIM (PRICING_SCHEME_KEY, PRICING_SCHEME_NAME, PRICING_SCHEME_DESC, LOAD_DT, INSERT_AUDIT_KEY, PRICING_SCHEME_TYPE)
values (117, 'RO Thermador', 'RO 4 Thermador', date '2022-07-18', 569745, 'OOW');

insert into PRICING_SCHEME_DIM (PRICING_SCHEME_KEY, PRICING_SCHEME_NAME, PRICING_SCHEME_DESC, LOAD_DT, INSERT_AUDIT_KEY, PRICING_SCHEME_TYPE)
values (118, 'RO Thermador', 'RO 5 Thermador', date '2022-07-18', 569745, 'OOW');

select * from PRICING_SCHEME_DIM;
commit;

-- begin
--     P_PK_CORE_UPDATE.INSERT_TBL('PRICING_SCHEME_DIM');
-- end;
