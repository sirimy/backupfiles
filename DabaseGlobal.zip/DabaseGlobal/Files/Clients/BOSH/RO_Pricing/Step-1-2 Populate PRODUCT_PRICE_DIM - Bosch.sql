
select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), psd.*   from p_pricing_scheme_dim psd
where  1=1
 and PRICING_SCHEME_KEY >= 60
order by PRICING_SCHEME_KEY;

select * from PRODUCT_PRICE_DIM;

insert into PRODUCT_PRICE_DIM
select * from bosh.PRODUCT_PRICE_DIM where PRICING_SCHEME_KEY = 62;
--2148
commit ;


select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
/*
 +-------------------+------------------+-------------------+----+-----------------------+-------+
|PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE |COUNT(DISTINCTTERM_KEY)|TERMS  |
+-------------------+------------------+-------------------+----+-----------------------+-------+
|OOW                |62                |AO Bosch           |NULL|3                      |1, 2, 4|
+-------------------+------------------+-------------------+----+-----------------------+-------+
 */

declare
  v_audit_key number;
begin
  v_audit_key := bosh.get_audit_key (p_program_nm => 'Campaign', p_descriptive_tx => 'BOSH-1024: Renewal Win-back BAU Campaign', p_table_nm => 'PRODUCT_PRICE_DIM');
  DBMS_OUTPUT.put_line(v_audit_key);
  COMMIT;
end;
--569746

--RO-2
update PRODUCT_PRICE_DIM set PRICING_SCHEME_KEY = 111, INSERT_AUDIT_KEY = 569746, UPDATE_AUDIT_KEY = null, SYNC_AUDIT_KEY = null
 where PRICING_SCHEME_KEY = 62;  --'RO 2 Bosch' and 'RO 3 Bosch'
 --2148 rows
commit;


--RO-3
insert into PRODUCT_PRICE_DIM (
        PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND)
select 112 as PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND
  from PRODUCT_PRICE_DIM
 where PRICING_SCHEME_KEY = 111
   and TERM_MONTHS <= 36;
--1432
commit;


--RO-4
insert into PRODUCT_PRICE_DIM (
        PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND)
select 113 as PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND
  from PRODUCT_PRICE_DIM
 where PRICING_SCHEME_KEY = 111
  and TERM_MONTHS <= 24;
--1432
commit;


--RO-5
insert into PRODUCT_PRICE_DIM (
        PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND)
select 114 as PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND
  from PRODUCT_PRICE_DIM
 where PRICING_SCHEME_KEY = 111
  and TERM_MONTHS <= 12;
--716
commit;



select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms, count(*)
from   product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
/*
+-------------------+------------------+-------------------+----+-----------------------+-------+--------+
|PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE |COUNT(DISTINCTTERM_KEY)|TERMS  |COUNT(*)|
+-------------------+------------------+-------------------+----+-----------------------+-------+--------+
|OOW                |111               |RO 2 Bosch         |NULL|3                      |1, 2, 4|1790    |
|OOW                |112               |RO 3 Bosch         |NULL|2                      |1, 2   |1252    |
|OOW                |113               |RO 4 Bosch         |NULL|2                      |1, 2   |1252    |
|OOW                |114               |RO 5 Bosch         |NULL|1                      |1      |669     |
+-------------------+------------------+-------------------+----+-----------------------+-------+--------+
 */

-- begin
--     P_PK_CORE_UPDATE.INSERT_TBL('PRODUCT_PRICE_DIM');
-- end;