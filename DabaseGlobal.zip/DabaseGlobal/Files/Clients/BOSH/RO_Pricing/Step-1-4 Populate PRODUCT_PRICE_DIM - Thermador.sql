select * from PRODUCT_PRICE_DIM;

insert into PRODUCT_PRICE_DIM
select * from bosh.PRODUCT_PRICE_DIM where PRICING_SCHEME_KEY = 101;
--998
commit ;


select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
-- where  pricing_scheme_key = 78
-- where  PRICING_SCHEME_KEY in ( 61, 62, 74)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
/*
+-------------------+------------------+-------------------+----+-----------------------+-----+
|PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE |COUNT(DISTINCTTERM_KEY)|TERMS|
+-------------------+------------------+-------------------+----+-----------------------+-----+
|OOW                |101               |AO Thermador       |NULL|2                      |1, 3 |
+-------------------+------------------+-------------------+----+-----------------------+-----+
*/

declare
  v_audit_key number;
begin
  v_audit_key := bosh.get_audit_key (p_program_nm => 'Campaign', p_descriptive_tx => 'BOSH-1024: Renewal Win-back BAU Campaign', p_table_nm => 'PRODUCT_PRICE_DIM');
  DBMS_OUTPUT.put_line(v_audit_key);
  COMMIT;
end;
--569750

--RO-3
update PRODUCT_PRICE_DIM set PRICING_SCHEME_KEY = 116, INSERT_AUDIT_KEY = 569750, UPDATE_AUDIT_KEY = null, SYNC_AUDIT_KEY = null
 where PRICING_SCHEME_KEY = 101;  --'RO 3 Thermador'
 --998 rows
commit;


--RO-4
insert into PRODUCT_PRICE_DIM (
        PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND)
select 117 as PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND
  from PRODUCT_PRICE_DIM
 where PRICING_SCHEME_KEY = 116
  and TERM_MONTHS <= 24;
--499
commit;


--RO-5
insert into PRODUCT_PRICE_DIM (
        PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND)
select 118 as PRICING_SCHEME_KEY, PRODUCT_KEY, BASE_PRICE_AMT, TERM_MONTHS, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT, PREMIUM_AMT, PRICE_BEFORE_DISCOUNT_AMT, PRICE_LOW, PRICE_HIGH, POLICY_KEY, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY, SYNC_AUDIT_KEY, ACTIVE_IND
  from PRODUCT_PRICE_DIM
 where PRICING_SCHEME_KEY = 116
  and TERM_MONTHS <= 12;
--499
commit;



select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
/*
+-------------------+------------------+-------------------+----+-----------------------+-----+
|PRICING_SCHEME_TYPE|PRICING_SCHEME_KEY|PRICING_SCHEME_DESC|AGE |COUNT(DISTINCTTERM_KEY)|TERMS|
+-------------------+------------------+-------------------+----+-----------------------+-----+
|OOW                |116               |RO 3 Thermador     |NULL|2                      |1, 3 |
|OOW                |117               |RO 4 Thermador     |NULL|1                      |1    |
|OOW                |118               |RO 5 Thermador     |NULL|1                      |1    |
+-------------------+------------------+-------------------+----+-----------------------+-----+
 */

-- begin
--     P_PK_CORE_UPDATE.INSERT_TBL('PRODUCT_PRICE_DIM');
-- end;
