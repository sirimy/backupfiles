
select DISTINCT
            AO_RO.DESTINATION_PRICING_SCHEME ,
            pol.NAME,
            AO_RO.D_PRICING_SCHEME_KEY AS PRICING_SCHEME_KEY
            ,pd.PRODUCT_KEY
            ,pfee.retail_price_amt as BASE_PRICE_AMT
            ,pl.TERM_COVERAGE_EXT as TERM_MONTHS
            ,0 TERM_DISCOUNT_AMT
            ,0 GREATEST_SAVINGS_AMT
            ,0 PREMIUM_AMT
            ,pfee.retail_price_amt as PRICE_BEFORE_DISCOUNT_AMT
            ,'' PRICE_LOW
            ,'' PRICE_HIGH
            ,pl.POLICY_KEY
            ,'v_audit_key' as INSERT_AUDIT_KEY
            ,'' UPDATE_AUDIT_KEY
            ,'' SYNC_AUDIT_KEY
            ,'Y'
       from (select policy_key, brand, product_cat_desc, channels from POLICY_EXT_TBL r
             union
             select policy_key, brand, product_cat_desc, channels from p_POLICY_EXT_TBL r
            ) r
            join (
                 select policy_key, policy_product_xid, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, age, tr.month as term_coverage_ext
                   from policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                  where pol.exp_dt > sysdate
                 union
                 select policy_key, policy_product_xid, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE, age, tr.month as term_coverage_ext
                   from p_policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                  where pol.exp_dt > sysdate
                 ) pl on (r.policy_key = pl.policy_key)
            ---
            join ( SELECT *
                      FROM V_PRICING_SCHEME_DIM psd
                     WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), psd.load_dt) IN ( select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), max(psd2.load_dt)
                                             from v_pricing_scheme_dim psd2
                                            WHERE psd2.PRICING_SCHEME_DESC LIKE 'AO%'
                                            group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$')
                                          )
                       AND psd.PRICING_SCHEME_DESC LIKE 'AO%'
                       AND psd.END_DT >= trunc(sysdate)
                  ) psd
              on ( PSD.PRICING_SCHEME_DESC = case
                                                  when upper(r.brand) IN ('BSUS', 'BOSCH') and upper(r.channels) IN ('OOW', 'AFTERMARKET SWEEP') then 'AO Bosch'
                                                  when upper(r.brand) IN ('THUS', 'THERMADOR') and upper(r.channels) IN ('OOW', 'AFTERMARKET SWEEP') then 'AO Thermador'
                                                  --when upper(r.brand) IN ('GGUS', 'GAGGENAU')  and upper(r.channels) IN ('OOW', 'AFTERMARKET SWEEP') THEN 'AO Gaggenau'
                                               end )
            ---
            left join (select pfe.policy_key,
                               pfe.policy_fee_value * (1 - pdt.discount_percentage) as retail_price_amt
                               --pfe.policy_fee_value as retail_orig_price_amt, --debug
                               --pdt.discount_percentage,                       --debug
                          from P_POLICY_FEE_XREF  pfe
                          join P_POLICY_FEE_TYPE  pft
                            on ( PFE.POLICY_FEE_TYPE_KEY = PFT.POLICY_FEE_TYPE_KEY AND PFT.NAME = 'Retail amt')
                          join p_policy_discount_tbl pdt
                            on (pdt.policy_key = pfe.policy_key and pdt.policy_fee_type_key = pfe.policy_fee_type_key
                                and pdt.discount_key = 11 --hard coded for now
                                and trunc(sysdate) between pdt.effective_dt and pdt.end_dt
                               )
                        union all
                          select pfe.policy_key,
                               pfe.policy_fee_value * (1 - pdt.discount_percentage) as retail_price_amt
                               --pfe.policy_fee_value as retail_orig_price_amt, --debug
                               --pdt.discount_percentage,                       --debug
                          from POLICY_FEE_XREF  pfe
                          join P_POLICY_FEE_TYPE  pft
                            on ( PFE.POLICY_FEE_TYPE_KEY = PFT.POLICY_FEE_TYPE_KEY AND PFT.NAME = 'Retail amt')
                          join policy_discount_tbl pdt
                            on (pdt.policy_key = pfe.policy_key and pdt.policy_fee_type_key = pfe.policy_fee_type_key
                                and pdt.discount_key = 11 --hard coded for now
                                and trunc(sysdate) between pdt.effective_dt and pdt.end_dt
                               )
                   ) pfee
            on ( pfee.policy_key = pl.policy_key)

            join p_brand_dim bd on (CASE WHEN upper(r.brand) IN ('BSUS', 'BOSCH') THEN 'Bosch'
                                         WHEN upper(r.brand) IN ('THUS', 'THERMADOR') THEN 'Thermador'
                                         WHEN upper(r.brand) IN ('GGUS', 'GAGGENAU') THEN 'Gaggenau'
                                         ELSE r.brand
                                     END  = bd.brand_nm)
            join (
                   select pd.product_key, model_no, product_nm, product_dsc, product_category_nm,
                         case when lower(product_category_nm) like 'refrig%' then 'Refrigerator With Food Loss'--'REFRIGERATION W LOSS'
                         when lower(product_category_nm) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                         when lower(product_category_nm) like '%dish%' then 'DISHWASHER'
                         when lower(product_dsc) like '%hood%' or lower(PRODUCT_CATEGORY_nm) like '%venti%'  then 'VENTILATION'
                         when lower(product_category_nm) like 'cooking' then 'COOKING'
                         when lower(product_category_nm) like '%laundry%' and lower(product_dsc) like '%dryer%' then 'LAUNDRY-DRYER'
                         when lower(product_category_nm) like '%laundry%' then 'LAUNDRY-WASHER'
                         else 'other'
                         end as bora_pricing_category,
                         brand_nm, price_amt, brand_key --,sku_no, upc_cd
                    from
                         bosh.v_product pd
                   where
                         NVL(pd.DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'
                     and PRODUCT_COVERAGE_END_DT >= sysdate
                     and NVL( pd.price_amt, 0 ) <> 0
                     --and pd.product_key = 27686   --debug only
                  ) pd
                  on (bd.brand_key = pd.brand_key
                      and upper(r.PRODUCT_CAT_DESC) = upper(pd.bora_pricing_category)
                      and pd.price_amt between pl.min_product_price and pl.max_product_price
                      )
            inner join --AO_RO_PRICING_SCHEME_MAPPING RO_P on RO_P.AO_KEY = PSD.PRICING_SCHEME_KEY and RO_P.RO_TERM = pl.TERM_COVERAGE_EXT
                (
                   Select NPSM.SOURCE_PRICING_SCHEME,NPSM.DESTINATION_PRICING_SCHEME,NPSM.PRICING_SCHEME_KEY  AS S_PRICING_SCHEME_KEY,V_PSD.PRICING_SCHEME_KEY  AS D_PRICING_SCHEME_KEY,V_PSD.PRICING_SCHEME_DESC,NPSM.RO_TERM   from
                    (select PSM.SOURCE_PRICING_SCHEME,PSM.DESTINATION_PRICING_SCHEME,VPSD.PRICING_SCHEME_KEY,PSM.RO_TERM  from AO_RO_PRICING_SCHEME_MAPPING PSM
                    Inner join V_PRICING_SCHEME_DIM VPSD on PSM.SOURCE_PRICING_SCHEME = VPSD.PRICING_SCHEME_DESC
                    where VPSD.END_DT > sysdate) NPSM inner join  V_PRICING_SCHEME_DIM V_PSD on NPSM.DESTINATION_PRICING_SCHEME = V_PSD.PRICING_SCHEME_DESC
                ) AO_RO
                ON AO_RO.S_PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY and AO_RO.RO_TERM = pl.TERM_COVERAGE_EXT
       join p_policy_tbl pol on (pol.policy_key = pl.policy_key)
      where UPPER(r.channels) IN ('OOW', 'AFTERMARKET SWEEP')
        AND    pd.PRODUCT_KEY in('19658','22118')
        Order by D_PRICING_SCHEME_KEY ,TERM_MONTHS ASC
;
