

select * from contract_order where order_id = 335691 and order_line_id = 1;
+-----------+--------+-------------+---------------+--------------------------+
|contract_id|order_id|order_line_id|last_updated_by|last_updated_ts           |
+-----------+--------+-------------+---------------+--------------------------+
|18460788   |335691  |1            |bosh           |2022-12-25 08:22:24.290496|
+-----------+--------+-------------+---------------+--------------------------+

select * from contract where contract_id = 18460788;
+-----------+-------------------+--------------------------+--------------------------+--------------------------+------------------+
|contract_id|client_contract_num|contract_sale_dt          |contract_start_dt         |contract_end_dt           |contract_status_id|
+-----------+-------------------+--------------------------+--------------------------+--------------------------+------------------+
|18460788   |BSH-335691-1       |2022-12-22 00:00:00.000000|2023-03-01 00:00:00.000000|2027-03-01 00:00:00.000000|1                 |
+-----------+-------------------+--------------------------+--------------------------+--------------------------+------------------+


select * from order_item_tbl where order_id = 335691;
select * from serialized_item_audit where serialized_item_id = 5067242
order by last_updated_ts
;


select ot.order_id,ot.created_ts,oit.serialized_item_id,lc.coverage_type_id type,lc.name si_status,co.contract_id,ct.contract_end_dt,cs.name cont_status,cc.cancel_effective_dt
from order_tbl ot
            join order_item_tbl oit on ot.order_id = oit.order_id
            join contract_order co on co.order_id = oit.order_id and co.order_line_id = oit.order_line_id
            join serialized_item si on si.serialized_item_id = oit.serialized_item_id
            join contract ct on ct.contract_id = co.contract_id
            join contract_status cs on cs.contract_status_id = ct.contract_status_id
            join latest_coverage_type lc on lc.coverage_type_id = si.latest_coverage_type_id
            left join contract_cancellation cc on cc.contract_id = ct.contract_id
         where ot.customer_id =271996
order by ot.order_id
;
+--------+--------------------------+------------------+---------+-----------+--------------------------+-----------+--------------------------+
|order_id|created_ts                |serialized_item_id|si_status|contract_id|contract_end_dt           |cont_status|cancel_effective_dt       |
+--------+--------------------------+------------------+---------+-----------+--------------------------+-----------+--------------------------+
|199137  |null                      |5067242           |Cancel   |6355410    |2023-02-28 00:00:00.000000|EXP        |null                      |
|335691  |2022-12-22 17:15:24.175000|5067242           |Cancel   |18460788   |2027-03-01 00:00:00.000000|ACTV       |null                      |
|536227  |2026-08-17 11:54:33.093000|5067242           |Cancel   |30437774   |2028-03-01 00:00:00.000000|CNCL       |2026-08-18 00:00:00.000000|
+--------+--------------------------+------------------+---------+-----------+--------------------------+-----------+--------------------------+

--
-- select distinct cc.contract_key, cc.contract_status_key, si.si_key, si.latest_coverage_type
--     from p_contract_dim cc
--         join p_contract_coverage_xref ccx
--           ON (cc.contract_key = ccx.contract_key)
--         join p_serialized_item_dim si
--           ON (si.si_key = ccx.si_key)
--    where
--          (cc.contract_status_key = 1 and si.latest_coverage_type not in (2, 9, 22))


select ot.order_id,ot.created_ts,oit.serialized_item_id,lc.name si_status,co.contract_id,ct.contract_end_dt,cs.name cont_status,cc.cancel_effective_dt
from order_tbl ot
            join order_item_tbl oit on ot.order_id = oit.order_id
            join contract_order co on co.order_id = oit.order_id and co.order_line_id = oit.order_line_id
            join serialized_item si on si.serialized_item_id = oit.serialized_item_id
            join contract ct on ct.contract_id = co.contract_id
            join contract_status cs on cs.contract_status_id = ct.contract_status_id
            join latest_coverage_type lc on lc.coverage_type_id = si.latest_coverage_type_id
            left join contract_cancellation cc on cc.contract_id = ct.contract_id
where ct.contract_status_id = 1 and si.latest_coverage_type_id not in (2, 9, 22)
        --and ot.customer_id = 1369080
order by ot.customer_id
;


select ot.customer_id ,ot.order_id,ot.created_ts,oit.serialized_item_id,lc.coverage_type_id type,lc.name si_status,co.contract_id,ct.contract_end_dt,cs.name cont_status,cc.cancel_effective_dt
from order_tbl ot
            join order_item_tbl oit on ot.order_id = oit.order_id
            join contract_order co on co.order_id = oit.order_id and co.order_line_id = oit.order_line_id
            join serialized_item si on si.serialized_item_id = oit.serialized_item_id
            join contract ct on ct.contract_id = co.contract_id
            join contract_status cs on cs.contract_status_id = ct.contract_status_id
            join latest_coverage_type lc on lc.coverage_type_id = si.latest_coverage_type_id
            left join contract_cancellation cc on cc.contract_id = ct.contract_id
where   ot.customer_id  in (
                            select ct.customer_id from order_tbl ot
                                join order_item_tbl oit on ot.order_id = oit.order_id
                                join contract_order co on co.order_id = oit.order_id and co.order_line_id = oit.order_line_id
                                join serialized_item si on si.serialized_item_id = oit.serialized_item_id
                                join contract ct on ct.contract_id = co.contract_id
                           where ct.contract_status_id = 1 and si.latest_coverage_type_id not in (2, 9, 22)
            )
and lc.coverage_type_id = 3
order by ot.customer_id,serialized_item_id,   created_ts
;

select ot.customer_id ,ot.order_id,ot.created_ts,ot.purchase_dt,oit.serialized_item_id,lc.coverage_type_id type,lc.name si_status,co.contract_id,ct.contract_end_dt,cs.name cont_status,cc.cancel_effective_dt
from order_tbl ot
            join order_item_tbl oit on ot.order_id = oit.order_id
            join contract_order co on co.order_id = oit.order_id and co.order_line_id = oit.order_line_id
            join serialized_item si on si.serialized_item_id = oit.serialized_item_id
            join contract ct on ct.contract_id = co.contract_id
            join contract_status cs on cs.contract_status_id = ct.contract_status_id
            join latest_coverage_type lc on lc.coverage_type_id = si.latest_coverage_type_id
            left join contract_cancellation cc on cc.contract_id = ct.contract_id
where   ot.customer_id  in (
                            select ct.customer_id from order_tbl ot
                                join order_item_tbl oit on ot.order_id = oit.order_id
                                join contract_order co on co.order_id = oit.order_id and co.order_line_id = oit.order_line_id
                                join serialized_item si on si.serialized_item_id = oit.serialized_item_id
                                join contract ct on ct.contract_id = co.contract_id
                           where ct.contract_status_id = 1 and si.latest_coverage_type_id not in (2, 9, 22)
            )
    and lc.coverage_type_id in (1,2)
order by ot.customer_id,serialized_item_id
;



select * from contract_cancellation where contract_id = 18460788;

+-------------------+------------+---------+--------------+--------------------+
|CONTRACT_STATUS_KEY|CONTRACT_KEY|ORDER_KEY|ORDER_LINE_KEY|LATEST_COVERAGE_TYPE|
+-------------------+------------+---------+--------------+--------------------+
|1                  |149157      |335691   |1             |3                   |
|1                  |164310      |360525   |3             |3                   |
|1                  |193431      |418423   |1             |3                   |
|1                  |164300      |360525   |4             |3                   |
|1                  |164317      |360525   |2             |3                   |
+-------------------+------------+---------+--------------+--------------------+
