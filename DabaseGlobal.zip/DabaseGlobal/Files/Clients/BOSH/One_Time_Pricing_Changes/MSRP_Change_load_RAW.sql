

--COUNT 473
Select COUNT(distinct MATERIAL) from (
select tgt.*,ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) as rn from BOSH.RAW_MODEL_MASTER_TBL tgt
        inner join AUDIT_TBL AT ON tgt.INSERT_AUDIT_KEY = AT.AUDIT_KEY
        inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c   where c.PRICE_AMT is not null) src
                    on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
      and AT.CREATION_DT  >= TO_DATE('01/MAR/2022 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
      and tgt.MAP_UMRP is not null
      and TRIM(tgt.MATERIAL_GROUP) <> 'Accessory'
) where rn =1
;

--Final select list check for MATERIAL_GROUP <> 'Accessory' , MSRP changed , comes after 1st march, MSRP not null
Select MATERIAL,
    MATERIAL_DESCRIPTION,
    BRAND,
    MATERIAL_GROUP,
    SALES_STATUS,
    VALID_FROM,
    EF_OUT_DATE,
    UPC_CODE,
    NEW_BUSINESS_FIELD,
    PRODUCT_TYPE,
    MAP_UMRP,
    SK_MARKETING_DESCRIPTION,
    FILE_NM || '-BOSH-1117',
    INSERT_AUDIT_KEY,
    '' AS UNIQUE_SEQ_NO,
    '' AS ERROR_DESC from (
select tgt.*,ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) as rn from BOSH.RAW_MODEL_MASTER_TBL tgt
        inner join AUDIT_TBL AT ON tgt.INSERT_AUDIT_KEY = AT.AUDIT_KEY
        inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c   where c.PRICE_AMT is not null) src
                    on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
      and AT.CREATION_DT  >= TO_DATE('01/MAR/2022 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
      and tgt.MAP_UMRP is not null
      and TRIM(tgt.MATERIAL_GROUP) <> 'Accessory'
) where rn =1
;


--Including that two model related coffe to other changed ('CM450712','CM470712')
Select MATERIAL,
    MATERIAL_DESCRIPTION,
    BRAND,
    MATERIAL_GROUP,
    SALES_STATUS,
    VALID_FROM,
    EF_OUT_DATE,
    UPC_CODE,
    NEW_BUSINESS_FIELD,
    PRODUCT_TYPE,
    MAP_UMRP,
    SK_MARKETING_DESCRIPTION,
    FILE_NM || '-BOSH-1117',
    INSERT_AUDIT_KEY,
    '' AS UNIQUE_SEQ_NO,
    '' AS ERROR_DESC from (
select tgt.*,ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) as rn from BOSH.RAW_MODEL_MASTER_TBL tgt
        inner join AUDIT_TBL AT ON tgt.INSERT_AUDIT_KEY = AT.AUDIT_KEY
where  AT.CREATION_DT  >= TO_DATE('01/MAR/2022 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
      and tgt.MAP_UMRP is not null
      and TRIM(tgt.MATERIAL) in ('CM450712','CM470712')
) where rn =1
;




declare
      v_audit_key number;
begin
      v_audit_key := get_audit_key (p_program_nm => 'MSRP_CHANGE_PROCESS', p_table_nm  => 'RAW_MODEL_MASTER_TBL', p_author_nm => 'iahamd' );

    --Insert for MATERIAL_GROUP <> 'Accessory' , MSRP changed , comes after 1st march, MSRP not null
      insert into BOSHSTG.RAW_MODEL_MASTER_TBL
      Select MATERIAL,
        MATERIAL_DESCRIPTION,
        BRAND,
        MATERIAL_GROUP,
        SALES_STATUS,
        VALID_FROM,
        EF_OUT_DATE,
        UPC_CODE,
        NEW_BUSINESS_FIELD,
        PRODUCT_TYPE,
        MAP_UMRP,
        SK_MARKETING_DESCRIPTION,
        FILE_NM || '-BOSH-1117',
        v_audit_key,
        '' AS UNIQUE_SEQ_NO,
        '' AS ERROR_DESC from (
    select tgt.*,ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) as rn from BOSH.RAW_MODEL_MASTER_TBL tgt
            inner join AUDIT_TBL AT ON tgt.INSERT_AUDIT_KEY = AT.AUDIT_KEY
            inner join (select c.BRAND_NM, c.MODEL_NO, coalesce(c.PRICE_AMT, 0) as PRICE_AMT from bosh.V_PRODUCT c   where c.PRICE_AMT is not null) src
                        on (src.BRAND_NM = tgt.BRAND and src.MODEL_NO = tgt.MATERIAL )
    where to_number(coalesce(MAP_UMRP, '0'))  <> coalesce(src.PRICE_AMT, 0)
          and AT.CREATION_DT  >= TO_DATE('01/MAR/2022 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
          and tgt.MAP_UMRP is not null
          and TRIM(tgt.MATERIAL_GROUP) <> 'Accessory'
    ) where rn =1
    ;


    -- Insert for ('CM450712','CM470712')
    insert into BOSHSTG.RAW_MODEL_MASTER_TBL
    Select MATERIAL,
        MATERIAL_DESCRIPTION,
        BRAND,
        MATERIAL_GROUP,
        SALES_STATUS,
        VALID_FROM,
        EF_OUT_DATE,
        UPC_CODE,
        NEW_BUSINESS_FIELD,
        PRODUCT_TYPE,
        MAP_UMRP,
        SK_MARKETING_DESCRIPTION,
        FILE_NM || '-BOSH-1117',
        v_audit_key,
        '' AS UNIQUE_SEQ_NO,
        '' AS ERROR_DESC from (
    select tgt.*,ROW_NUMBER() OVER (partition by MATERIAL order by INSERT_AUDIT_KEY DESC) as rn from BOSH.RAW_MODEL_MASTER_TBL tgt
            inner join AUDIT_TBL AT ON tgt.INSERT_AUDIT_KEY = AT.AUDIT_KEY
    where  AT.CREATION_DT  >= TO_DATE('01/MAR/2022 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
          and tgt.MAP_UMRP is not null
          and TRIM(tgt.MATERIAL) in ('CM450712','CM470712')
    ) where rn =1
    ;

      DBMS_OUTPUT.put_line(v_audit_key);
      COMMIT;
end;



--BEGIN PK_MODELMASTER.S_001_LOAD_PRODUCT_CATEGORY_PRICE_CHANGE() ; END;

SELECT count(DISTINCT MATERIAL) FROM RAW_MODEL_MASTER_TBL;--465
select count(*) from PRODUCT_CATALOG_TBL;--465
select * from  brand_lkp;--0
select * from product_lkp;--0
select * from  product_category_lkp;--0
select COUNT(*) from product_dim; --465
select * from  brand_dim;--3
select * from  product_category_dim;--6
select COUNT(*) from  product_attribute_xref;--465X4=1860