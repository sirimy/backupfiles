
select COUNT(*) from PRODUCT_CATALOG_TBL; --465

select * from  brand_lkp;--0
select * from product_lkp;--0
select * from  product_category_lkp;--0
select COUNT(*) from product_dim; --465
select * from  brand_dim;--3
select * from  product_category_dim;--7
-- PRODUCT_CATEGORY_KEY,PRODUCT_CATEGORY_UNIQUE_ID
-- 1596,REFRIGERATION W LOSS
-- 1614,OTHER
-- 1599,BUILT-IN COFFEE MAKER
-- 1595,VENTILATION
-- 1597,COOKING
-- 1600,LAUNDRY-WASHER
-- 1598,DISHWASHER
select COUNT(*) from  product_attribute_xref;--465X4=1860




--1 Core value is Y for DNS
select  s.DO_NOT_SOLICIT_PRODUCT_IND,  c.DO_NOT_SOLICIT_PRODUCT_IND,c.MODEL_NO,c.PRODUCT_CATEGORY_NM,c.MARKETING_PRODUCT_NM
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.DO_NOT_SOLICIT_PRODUCT_IND <> c.DO_NOT_SOLICIT_PRODUCT_IND  --1
    ) and s.PRICE_AMT is not null ;
-- DO_NOT_SOLICIT_PRODUCT_IND,DO_NOT_SOLICIT_PRODUCT_IND,MODEL_NO,PRODUCT_CATEGORY_NM,MARKETING_PRODUCT_NM
-- N,Y,DHL755BUC,OTHER,ACCESSORIES


-- 114 product coverage date is changed
select s.Product_Coverage_End_Dt , c.Product_Coverage_End_Dt
    --COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt  --109
    )  ;


-- Here 108 rows have CORE value is = 2099-12-29
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt  --103
    )  and c.Product_Coverage_End_Dt = TO_DATE('2099-12-29 00:00:00', 'YYYY/MM/DD HH24:MI:SS') ;



--346 records have same dates and value also same this 2099-12-29
select  COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.Product_Coverage_End_Dt = c.Product_Coverage_End_Dt  --109
    )  and s.PRODUCT_COVERAGE_END_DT = TO_DATE('2099-12-29 00:00:00', 'YYYY/MM/DD HH24:MI:SS')  ;



-- All 465 same brand
select COUNT(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.BRAND_NM = c.BRAND_NM --0
    ) and s.BRAND_NM is not null and  c.BRAND_NM is not null  ;


--21  rows have  changed category
select --COUNT(*)
    s.PRODUCT_CATEGORY_NM ,  c.PRODUCT_CATEGORY_NM,c.MODEL_NO,c.MARKETING_PRODUCT_NM,c.PRODUCT_NM,s.PRODUCT_NM
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRODUCT_CATEGORY_NM <>  c.PRODUCT_CATEGORY_NM --0
--      or s.PRICE_AMT <> c.PRICE_AMT --414
    ) and s.PRODUCT_CATEGORY_NM is not null and  c.PRODUCT_CATEGORY_NM is not null  ;
--
-- PRODUCT_CATEGORY_NM,PRODUCT_CATEGORY_NM,MODEL_NO
-- VENTILATION,OTHER,       DHL755BUC
-- OTHER,COOKING,           HSD5051UC
-- OTHER,COOKING,           PRD484WCGU
-- OTHER,COOKING,           PRD484WCHU
-- OTHER,COOKING,           PRD486WDGU
-- OTHER,COOKING,           PRD486WDHU
-- OTHER,COOKING,           PRD486WIGU
-- OTHER,COOKING,           PRD486WLGU
-- OTHER,COOKING,           PRD486WLHU
-- OTHER,COOKING,           PRG486WDG
-- OTHER,COOKING,           PRG486WDH
-- OTHER,COOKING,           PRG486WLH
-- OTHER,COOKING,           MEDMCW31WS
-- OTHER,COOKING,           PRD48WDSGU
-- OTHER,COOKING,           PRD606WEG
-- OTHER,COOKING,           PRD48WISGU
-- OTHER,COOKING,           PODMCW31W
-- OTHER,COOKING,           DV463710
-- BUILT-IN COFFEE MAKER,   OTHER, CM470712
-- OTHER,COOKING,               DV461710
-- BUILT-IN COFFEE MAKER,   OTHER,     CM450712




--Price changed for all 464 rows
select Count(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT <> c.PRICE_AMT --414
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;


--Price same for one Model CM470712 we added it to update category
select *
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT = c.PRICE_AMT --1
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;

-- 460 rows have new price increased
select Count(*)
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT > c.PRICE_AMT --402
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;


--It will list those pricing
select s.PRICE_AMT , c.PRICE_AMT
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT > c.PRICE_AMT --402
    )   and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;

-- 4 rows have less price new value
select s.PRICE_AMT , c.PRICE_AMT
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.PRICE_AMT < c.PRICE_AMT --402
    ) and s.PRICE_AMT is not null and  c.PRICE_AMT is not null  ;
-- PRICE_AMT,PRICE_AMT
-- 1449.00,1499.00
-- 4799.00,4999.00
-- 1699.00,1749.00
-- 3899.00,4199.00




-- All coloumns with list of data with compare STG and Core
select s.BRAND_NM AS BRAND_NM_stg , c.BRAND_NM AS BRAND_NM_CORE
       ,s.PRODUCT_CATEGORY_NM AS PRODUCT_CATEGORY_NM_stg , c.PRODUCT_CATEGORY_NM AS PRODUCT_CATEGORY_NM_CORE
     ,s.PRICE_AMT AS PRICE_AMT_stg , c.PRICE_AMT AS PRICE_AMT_CORE
     ,s.DO_NOT_SOLICIT_PRODUCT_IND AS DNS_stg , c.DO_NOT_SOLICIT_PRODUCT_IND AS DNS_CORE
      ,s.Product_Coverage_End_Dt AS Product_Coverage_End_Dt_stg , c.Product_Coverage_End_Dt AS Product_Coverage_End_Dt_CORE
  from V_PRODUCT_STG s
       join bosh.V_PRODUCT c
          on c.PRODUCT_KEY = s.PRODUCT_KEY
 where (
       1=2
      or s.BRAND_NM <> c.BRAND_NM
      or s.PRICE_AMT <> c.PRICE_AMT
      or s.PRODUCT_CATEGORY_NM <>  c.PRODUCT_CATEGORY_NM --0
     or s.Product_Coverage_End_Dt <> c.Product_Coverage_End_Dt
     or s.DO_NOT_SOLICIT_PRODUCT_IND <> c.DO_NOT_SOLICIT_PRODUCT_IND
    )   ;
