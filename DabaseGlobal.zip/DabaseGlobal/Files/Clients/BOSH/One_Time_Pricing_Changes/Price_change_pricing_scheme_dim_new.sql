
-- Generate pricing_scheme_dim data for After Market (AM)
insert into pricing_scheme_dim
SELECT *
                      FROM bosh.pricing_scheme_dim psd
                     WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd.PRICING_SCHEME_DESC, 1, 2), psd.load_dt) IN ( select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2), max(psd2.load_dt)
                                             from v_pricing_scheme_dim psd2
                                            WHERE psd2.PRICING_SCHEME_DESC LIKE 'AM%'
                                            group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2)
                                          )
                       AND psd.PRICING_SCHEME_DESC LIKE 'AM%'
                       AND psd.END_DT >= trunc(sysdate);


-- Generate pricing_scheme_dim data for EARLY BIRD (EB)
insert into pricing_scheme_dim
 SELECT *
                      FROM bosh.pricing_scheme_dim psd
                     WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd.PRICING_SCHEME_DESC, 1, 2), psd.load_dt) IN (
                                           select REGEXP_SUBSTR(psd2.PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2), max(psd2.load_dt)
                                             from v_pricing_scheme_dim psd2
                                            WHERE psd2.PRICING_SCHEME_DESC LIKE 'EB%'
                                            group by REGEXP_SUBSTR(psd2.PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2)
                                          )
                       AND psd.PRICING_SCHEME_DESC LIKE 'EB%'
                       AND psd.END_DT >= trunc(sysdate);


-- Generate pricing_scheme_dim data for OUT OF WARRANTY (OOW)
insert into pricing_scheme_dim
SELECT *
                      FROM bosh.pricing_scheme_dim psd
                     WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd.PRICING_SCHEME_DESC, 1, 2), psd.load_dt) IN ( select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2), max(psd2.load_dt)
                                             from v_pricing_scheme_dim psd2
                                            WHERE psd2.PRICING_SCHEME_DESC LIKE 'AO%'
                                            group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2)
                                          )
                       AND psd.PRICING_SCHEME_DESC LIKE 'AO%'
                       AND psd.END_DT >= trunc(sysdate);

-- Generate pricing_scheme_dim data for RENEWAL PROGRAM (RN)
insert into pricing_scheme_dim
SELECT *
                      FROM bosh.pricing_scheme_dim psd
                     WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd.PRICING_SCHEME_DESC, 1, 2), psd.load_dt) IN ( select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2), max(psd2.load_dt)
                                             from v_pricing_scheme_dim psd2
                                            WHERE psd2.PRICING_SCHEME_DESC LIKE 'RN%'
                                            group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2)
                                          )
                       AND psd.PRICING_SCHEME_DESC LIKE 'RN%'
                       AND psd.END_DT >= trunc(sysdate);



-- Generate pricing_scheme_dim data for BUILDER (BUILDER)
insert into pricing_scheme_dim
SELECT *
                      FROM bosh.pricing_scheme_dim psd
                     WHERE (REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd.PRICING_SCHEME_DESC, 1, 2), psd.load_dt) IN ( select REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2), max(psd2.load_dt)
                                             from v_pricing_scheme_dim psd2
                                            WHERE psd2.PRICING_SCHEME_DESC LIKE 'BUILDER%'
                                            group by REGEXP_SUBSTR(PRICING_SCHEME_DESC, '\S+$'), SUBSTR(psd2.PRICING_SCHEME_DESC, 1, 2)
                                          )
                       AND psd.PRICING_SCHEME_DESC LIKE 'BUILDER%'
                       AND psd.END_DT >= trunc(sysdate);




-- Generate pricing_scheme_dim data for BUILDER (RO)
insert into pricing_scheme_dim
select * from BOSH.pricing_scheme_dim where PRICING_SCHEME_NAME like '%RO%'
AND END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS') order by PRICING_SCHEME_KEY desc;


select * from pricing_scheme_dim --where PRICING_SCHEME_NAME like '%RO%'
                                 order by PRICING_SCHEME_KEY;--13 records

select PRICING_SCHEME_TYPE,COUNT(PRICING_SCHEME_TYPE) from pricing_scheme_dim GROUP BY PRICING_SCHEME_TYPE;--25 records
-- PRICING_SCHEME_TYPE,COUNT(PRICING_SCHEME_TYPE)
-- AM           ,3
-- RN           ,15
-- OOW          ,3
-- EB           ,3
-- BUILDER      ,1
--

declare
      v_audit_key number;
begin
      v_audit_key := get_audit_key (p_program_nm => 'PROC_PRODUCT_PRICING', p_table_nm  => 'PRICING_SCHEME_DIM', p_author_nm => 'iahamd' );

      UPDATE pricing_scheme_dim
          SET INSERT_AUDIT_KEY = v_audit_key,SYNC_AUDIT_KEY = NULL,UPDATE_AUDIT_KEY=NULL
            ,LOAD_DT = TO_DATE('21/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
            ,END_DT =  TO_DATE('31/DEC/2099 00:00:00', 'dd/mon/yyyy HH24:MI:SS');

      DBMS_OUTPUT.put_line(v_audit_key);
      COMMIT;
end;
--569745

--Core pricing end date set
declare
      v_audit_key number;
begin
      v_audit_key := get_audit_key (p_program_nm => 'PROC_PRODUCT_PRICING', p_table_nm  => 'PRICING_SCHEME_DIM', p_author_nm => 'iahamd' );

      UPDATE BOSH.pricing_scheme_dim
          SET INSERT_AUDIT_KEY = NULL,SYNC_AUDIT_KEY = NULL,UPDATE_AUDIT_KEY=v_audit_key
            ,END_DT =  TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS');

      DBMS_OUTPUT.put_line(v_audit_key);
      COMMIT;
end;



commit;



select COUNT(*) from PRODUCT_PRICE_DIM;




select * from  pricing_scheme_dim   order by PRICING_SCHEME_KEY;


select distinct PRODUCT_KEY from PRODUCT_PRICE_DIM where PRODUCT_KEY in (
    Select PRODUCT_KEY from V_PRODUCT where MODEL_NO in (
        select MATERIAL from   RAW_MODEL_MASTER_TBL where ERROR_DESC is null
        )
    );


select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
-- where  pricing_scheme_key = 78
-- where  PRICING_SCHEME_KEY in ( 61, 62, 74)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;

select * from pricing_scheme_dim order by PRICING_SCHEME_KEY;

select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   product_price_dim ppd
       join pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;



 select count(distinct pd.product_key)
         from bosh.V_PRODUCT pd
         join (select *
                from
                   (select  psd.product_key, psd.policy_key, psd.pricing_scheme_key, pricing_scheme_name,
                            ROW_NUMBER() OVER ( PARTITION BY psd.product_key ORDER BY psd.INSERT_AUDIT_KEY DESC) as rno
                      from  p_product_price_dim psd
                      join (select distinct pricing_scheme_key, pricing_scheme_name, pricing_scheme_desc, load_dt
                              from P_criteria_cell_xref join P_criteria_dim using(criteria_key)
                                   join P_PRICING_SCHEME_DIM using (pricing_scheme_key)
                             where active_ind = 'Y'
                           ) pps
                        ON ( pps.pricing_scheme_key = psd.pricing_scheme_key)
                    )
               where rno = 1) ppd
           ON ( PPD.PRODUCT_KEY = PD.PRODUCT_KEY)
         join P_POLICY_TBL pt
           ON (PT.POLICY_KEY = PPD.POLICY_KEY)
        where  PD.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
          and PD.PRICE_AMT IS NOT NULL
          and NVL(PD.PRICE_AMT,0) not between  PT.MIN_PRODUCT_PRICE and PT.MAX_PRODUCT_PRICE
        order by pd.product_key;