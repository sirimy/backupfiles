
--STG PRODUCT_PRICE_DIM count CTIVE_IND= 'Y'  52569
select COUNT(*) from PRODUCT_PRICE_DIM where  ACTIVE_IND= 'Y' ;--52569

--CORE PRODUCT_PRICE_DIM count CTIVE_IND= 'Y' 53226
select  COUNT(PD.MODEL_NO) from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS');--53226


--*****************************---------------------------------*****************************---

--STG count ALL 58747
select COUNT(*) from PRODUCT_PRICE_DIM   ;--58747

--CORE count ALL  62079
select  COUNT(PD.MODEL_NO) from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS');--62079

--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
-- For  108 model pricing not created this time
-- For  37 model pricing not created this time
Select COUNT(Distinct MODEL_NO) from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where   ACTIVE_IND= 'Y' AND  PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY where  ACTIVE_IND= 'Y'
         );
--*****************************---------------------------------*****************************---

select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  --ACTIVE_IND= 'Y' and
            PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
       --  where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'
Order by PRODUCT_COVERAGE_END_DT DESC
;

--*****************************---------------------------------*****************************---

--Only 5 models which passed NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'

select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y';
-- PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO
-- 20544,N,2099-12-29,HSLP751UC
-- 33288,N,2099-12-29,CM450712
-- 33294,N,2099-12-29,CM470712
-- 31868,N,2099-12-29,HPIN42WS
-- 22902,N,2024-01-04,HSB36BS

--*****************************---------------------------------*****************************---

--Model 'HSLP751UC' Price =6899.00 and Old Ploicy price range is 5500.00,6499.99 its due to range issue
--Model 'CM450712' Price =4299.00 and Old Ploicy price range is 3500.00,4999.99 due to bora_pricing_category as other
--Model 'CM470712' Price =4999.00 and Old Ploicy price range is 3500.00,4999.99 due to bora_pricing_category as other
--Model 'HPIN42WS' Price =3699.00 and Old Ploicy price range is 2500.00,3499.99  its due to range issue
--Model 'HSB36BS' Price =899.00 and Old Ploicy price range is 750.00,999.99 its ACTIVE_IND= 'N'

--*****************************---------------------------------*****************************---

-- For 244 model new pricing is not created for each Terms its present before
Select COUNT(Distinct MODEL_NO) from (
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y' );
--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
-- For 108 model new pricing is not created for each Terms its present before
Select COUNT(Distinct MODEL_NO) from (
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         );
--*****************************---------------------------------*****************************---

--*****************************---------------------------------*****************************---
-- For 108 model new pricing is not created for each Terms its present before
Select COUNT(Distinct MODEL_NO) from (
select  PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select  PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         );
--*****************************---------------------------------*****************************---

--*****************************---------------------------------*****************************---
-- For 2 model new pricing it created
Select Distinct MODEL_NO from (
select  PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY

MINUS
select  PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
)
;

--Cross check SQL same 2 models comes
select  Distinct PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
where PD.MODEL_NO not in
      (
         select  PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
) ;




--That 2 model whose pricing created
Select * from RAW_MODEL_MASTER_TBL_LATEST where MATERIAL in ('DUH30152UC','DUH36152UC');
-- MATERIAL,MATERIAL_DESCRIPTION,BRAND,MAP_UMRP,MATERIAL_GROUP
-- DUH30152UC,"DUH30152UC, Undercabinet Hood",Bosch,519,Hood
-- DUH36152UC,"DUH36152UC, Undercabinet Hood",Bosch,579,Hood
--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
--Pricing created for 411 models from latest RAW table
Select COUNT(*) from RAW_MODEL_MASTER_TBL_LATEST where MATERIAL in (
select  PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY)
    and ERROR_DESC is NULL;
--*****************************---------------------------------*****************************---

--*****************************---------------------------------*****************************---
--38 rows for each pricing scheme its created new pricing same as production
select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   bosh.product_price_dim ppd
       join bosh.pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
--*****************************---------------------------------*****************************---

--*****************************---------------------------------*****************************---
-- For 32 model pricing not created  with NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'
select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y';
--*****************************---------------------------------*****************************---

select * from RAW_MODEL_MASTER_TBL_LATEST where MATERIAL in (
select  MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y');


select * from BOSH.RAW_MODEL_MASTER_TBL where MATERIAL in (
select  MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y') order by INSERT_AUDIT_KEY desc;



 --For these 32 model leads present in SERIALIZED_ITEM_DIM count is 1242
 Select COUNT(*) from BOSH.SERIALIZED_ITEM_DIM where PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y');
--*****************************---------------------------------*****************************---


 --For these 32 model leads present in SERIALIZED_ITEM_DIM this year count is 40
  Select COUNT(SID.PRODUCT_KEY) from BOSH.SERIALIZED_ITEM_DIM SID inner join AUDIT_TBL AT on SID.INSERT_AUDIT_KEY =AT.AUDIT_KEY
      where AT.CREATION_DT >= (SYSDATE -365 ) AND  SID.PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  --ACTIVE_IND= 'Y' and
            PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         --where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y');
--*****************************---------------------------------*****************************---
   Select COUNT(SID.PRODUCT_KEY) from BOSH.SERIALIZED_ITEM_DIM SID inner join AUDIT_TBL AT on SID.INSERT_AUDIT_KEY =AT.AUDIT_KEY
      where AT.CREATION_DT >= (SYSDATE -365 ) AND  SID.PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (select MODEL_NO
  from BOSh.V_PRODUCT
  where MODEL_NO in (Select Distinct MODEL_NO
                     from (select PSD.PRICING_SCHEME_NAME, PD.MODEL_NO
                           from BOSH.PRODUCT_PRICE_DIM PRD
                                    inner join BOSH.PRICING_SCHEME_DIM PSD
                                               on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                                    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
                           where --ACTIVE_IND= 'Y' and
                                 PSD.END_DT = TO_DATE('20/JAN/2023 00:00:00', 'dd/mon/yyyy HH24:MI:SS')
                           MINUS
                           select PSD.PRICING_SCHEME_NAME, PD.MODEL_NO
                           from PRODUCT_PRICE_DIM PRD
                                    inner join PRICING_SCHEME_DIM PSD
                                               on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                                    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
                              --  where  ACTIVE_IND= 'Y'
                          ))
    and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'))
;