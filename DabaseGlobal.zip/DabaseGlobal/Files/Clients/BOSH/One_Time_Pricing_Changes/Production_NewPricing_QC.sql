
select COUNT(*) from product_dim; --465
select * from PRICING_SCHEME_DIM order by PRICING_SCHEME_KEY;--Start with 200 -- 19 records
select * from BOSH.PRICING_SCHEME_DIM order by PRICING_SCHEME_KEY DESC;--End with 188

select COUNT(*) from PRODUCT_PRICE_DIM ;--21229

select COUNT(*) from BOSH.PRODUCT_PRICE_DIM PPD
    inner join AUDIT_TBL AT on AT.AUDIT_KEY = PPD.INSERT_AUDIT_KEY
                where AT.CREATION_DT > sysdate -1;--0

--STG PRODUCT_PRICE_DIM count CTIVE_IND= 'Y'  54614
select COUNT(*) from PRODUCT_PRICE_DIM where  ACTIVE_IND= 'Y' ;--20282

--CORE PRODUCT_PRICE_DIM count CTIVE_IND= 'Y' 53226
select  COUNT(PD.MODEL_NO) from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT > sysdate;--53226


--*****************************---------------------------------*****************************---

--STG count ALL 21229
select COUNT(*) from PRODUCT_PRICE_DIM   ;--21229

--CORE count ALL  66577
select  COUNT(PD.MODEL_NO) from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT > sysdate;--66577

--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
-- For  38 model pricing not created this time
Select COUNT(Distinct MODEL_NO) from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where   ACTIVE_IND= 'Y' AND  PSD.END_DT > sysdate
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY where  ACTIVE_IND= 'Y'
         );
--*****************************---------------------------------*****************************---
-- Desc last date is 2023-12-29
select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  --ACTIVE_IND= 'Y' and
              PSD.END_DT > sysdate
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
       --  where  ACTIVE_IND= 'Y'

         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'
Order by PRODUCT_COVERAGE_END_DT DESC
;

--*****************************---------------------------------*****************************---

--Only 6 models which passed NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y'

select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT > sysdate
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') <> 'Y';
-- PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO
-- 20544,N,2099-12-29,HSLP751UC
-- 33240,N,2099-12-29,BX480612
-- 33246,N,2099-12-29,BX481612
-- 31416,N,2099-12-29,HPCN48WS
-- 31868,N,2099-12-29,HPIN42WS
-- 22902,N,2024-01-04,HSB36BS


--*****************************---------------------------------*****************************---

--Model 'HSLP751UC' Price =6899.00 and Old Ploicy price range is 5500.00,6499.99 its due to range issue
--Model 'BX480612'
--Model 'BX481612'
--Model 'HPCN48WS'
--Model 'HPIN42WS' Price =3699.00 and Old Ploicy price range is 2500.00,3499.99  its due to range issue
--Model 'HSB36BS' Price =899.00 and Old Ploicy price range is 750.00,999.99 its ACTIVE_IND= 'N'

--*****************************---------------------------------*****************************---

-- For 245 model new pricing is not created for each Terms its present before
Select COUNT(Distinct MODEL_NO) from (
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT > sysdate
MINUS
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y' );
--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
-- For 109 model new pricing is not created for each Terms its present before
Select COUNT(Distinct MODEL_NO) from (
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT > sysdate
MINUS
select PRD.TERM_MONTHS,PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         );
--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
-- For 4 model new pricing it created
Select Distinct MODEL_NO from (
select  PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY

MINUS
select  PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT > sysdate
)
;
-- MODEL_NO
-- CM470712
-- DUH30152UC
-- CM450712
-- DUH36152UC

--Cross check SQL same 2 models comes
select  Distinct PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
where PD.MODEL_NO not in
      (
         select  PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  PSD.END_DT > sysdate
) ;
--
-- MODEL_NO
-- DUH30152UC
-- DUH36152UC



--That 2 model whose pricing created
Select * from RAW_MODEL_MASTER_TBL where MATERIAL in ('DUH30152UC','DUH36152UC');
-- MATERIAL,MATERIAL_DESCRIPTION,BRAND,MAP_UMRP,MATERIAL_GROUP
-- DUH30152UC,"DUH30152UC, Undercabinet Hood",Bosch,519,Hood
-- DUH36152UC,"DUH36152UC, Undercabinet Hood",Bosch,579,Hood
--*****************************---------------------------------*****************************---


--*****************************---------------------------------*****************************---
--Pricing created for 459 models from latest RAW table
Select COUNT(*) from RAW_MODEL_MASTER_TBL where MATERIAL in (
select  PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY)
    and ERROR_DESC is NULL;
--*****************************---------------------------------*****************************---

--*****************************---------------------------------*****************************---
--38 rows for each pricing scheme its created new pricing same as production
select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   product_price_dim ppd
       join pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
and    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;
--*****************************---------------------------------*****************************---

--*****************************---------------------------------*****************************---
-- For 32 model pricing not created  with NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'
select PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT   > sysdate
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y';
--*****************************---------------------------------*****************************---
-- PRODUCT_KEY,DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,MODEL_NO
-- 33172,Y,2023-11-10,BS281611
-- 33232,Y,2023-11-27,BX281611
-- 20722,Y,2023-09-11,DIE165RUC
-- 23066,Y,2023-12-29,ME302JPZ
-- 23068,Y,2023-12-29,ME302JSZ
-- 24196,Y,2023-12-29,MED301JSZ
-- 23082,Y,2023-12-29,MED302JPZ
-- 23084,Y,2023-12-29,MED302JSZ
-- 24198,Y,2023-12-29,MEDMC301SZ
-- 23086,Y,2023-12-29,MEDMCW31SZ
-- 23660,Y,2023-12-29,POD301JZ
-- 23666,Y,2023-12-29,PODC302JZ
-- 23670,Y,2023-12-29,PODM301JZ
-- 23674,Y,2023-12-29,PODMW301JZ
-- 33404,Y,2023-09-28,RB491700
-- 33412,Y,2023-09-28,RC462700
-- 33420,Y,2023-09-28,RC472700
-- 33432,Y,2023-09-28,RF411700
-- 33452,Y,2023-09-28,RF461700
-- 33460,Y,2023-09-28,RF463700
-- 33462,Y,2023-09-28,RF463701
-- 33476,Y,2023-09-28,RF471700
-- 33494,Y,2023-09-28,RW414760
-- 33440,Y,2023-09-28,RW464760
-- 33500,Y,2023-09-28,RY491701
-- 21004,Y,2023-09-28,SHE23R52UC
-- 21006,Y,2023-09-28,SHE23R55UC
-- 21684,Y,2023-09-02,SHE7ER55UC
-- 24106,Y,2023-09-02,SHV7ER53UC
-- 21862,Y,2023-10-29,WAE20060UC
-- 21990,Y,2023-10-29,WTC82100US
-- 21992,Y,2023-10-09,WTE86300US




 --For these 32 model leads present in SERIALIZED_ITEM_DIM count is 1238
 Select COUNT(*) from BOSH.SERIALIZED_ITEM_DIM where PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
           and PSD.END_DT > sysdate
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y');
--*****************************---------------------------------*****************************---


 --For these 32 model leads present in SERIALIZED_ITEM_DIM this year count is 36
  Select COUNT(SID.PRODUCT_KEY) from BOSH.SERIALIZED_ITEM_DIM SID inner join AUDIT_TBL AT on SID.INSERT_AUDIT_KEY =AT.AUDIT_KEY
      where AT.CREATION_DT >= (SYSDATE -365 ) AND  SID.PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (
Select Distinct MODEL_NO from (
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from BOSH.PRODUCT_PRICE_DIM  PRD
    inner join BOSH.PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y' and
            PSD.END_DT > sysdate
MINUS
select PSD.PRICING_SCHEME_NAME ,PD.MODEL_NO from PRODUCT_PRICE_DIM  PRD
    inner join PRICING_SCHEME_DIM PSD     on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
         where  ACTIVE_IND= 'Y'
         )) and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y');
--*****************************---------------------------------*****************************---

--For All No Price model witg all status of ACTIVE_IND model leads present in SERIALIZED_ITEM_DIM this year count is 212
   Select COUNT(SID.PRODUCT_KEY) from BOSH.SERIALIZED_ITEM_DIM SID inner join AUDIT_TBL AT on SID.INSERT_AUDIT_KEY =AT.AUDIT_KEY
      where AT.CREATION_DT >= (SYSDATE -365 ) AND  SID.PRODUCT_KEY in (
select PRODUCT_KEY from BOSh.V_PRODUCT where MODEL_NO in (select MODEL_NO
  from BOSh.V_PRODUCT
  where MODEL_NO in (Select Distinct MODEL_NO
                     from (select PSD.PRICING_SCHEME_NAME, PD.MODEL_NO
                           from BOSH.PRODUCT_PRICE_DIM PRD
                                    inner join BOSH.PRICING_SCHEME_DIM PSD
                                               on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                                    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
                           where --ACTIVE_IND= 'Y' and
                                 PSD.END_DT > sysdate
                           MINUS
                           select PSD.PRICING_SCHEME_NAME, PD.MODEL_NO
                           from PRODUCT_PRICE_DIM PRD
                                    inner join PRICING_SCHEME_DIM PSD
                                               on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                                    inner join BOSH.PRODUCT_DIM PD on PRD.PRODUCT_KEY = PD.PRODUCT_KEY
                              --  where  ACTIVE_IND= 'Y'
                          ))
    and NVL(DO_NOT_SOLICIT_PRODUCT_IND, 'N') = 'Y'))
;