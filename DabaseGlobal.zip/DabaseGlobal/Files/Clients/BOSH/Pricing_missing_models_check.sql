
select
           PD.PRODUCT_KEY,PD.MODEL_NO,pd.price_amt ,MIN(pl.min_product_price) , MAX(pl.max_product_price),DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,upper(r.product_cat_desc),pd.bora_pricing_category,pl.exp_dt
        from (select policy_key, brand, product_cat_desc, channels from POLICY_EXT_TBL r
              union
              select policy_key, brand, product_cat_desc, channels from p_POLICY_EXT_TBL r
             ) r
             join (select policy_key, policy_product_xid, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE,pol.exp_dt, age, tr.month as term_coverage_ext
                     from policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                    where pol.exp_dt > sysdate
                    union
                   select policy_key, policy_product_xid, MIN_PRODUCT_PRICE, MAX_PRODUCT_PRICE,pol.exp_dt, age, tr.month as term_coverage_ext
                     from p_policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                    where pol.exp_dt > sysdate
                   ) pl on (r.policy_key = pl.policy_key)
             join p_brand_dim bd on ( CASE WHEN upper(r.brand) IN ('BSUS', 'BOSCH') THEN 'Bosch'
                                           WHEN upper(r.brand) IN ('THUS', 'THERMADOR') THEN 'Thermador'
                                           WHEN upper(r.brand) IN ('GGUS', 'GAGGENAU') THEN 'Gaggenau'
                                           ELSE r.brand
                                      END
                                           = bd.brand_nm)
            join
            (select pd.product_key,model_no,product_nm, product_dsc, product_category_nm,
                           case when lower(product_category_nm) like 'refrig%' then 'Refrigerator With Food Loss'--'REFRIGERATION W LOSS'
                           when lower(product_category_nm) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                           when lower(product_category_nm) like '%dish%' then 'DISHWASHER'
                           when lower(product_dsc) like '%hood%' or lower(PRODUCT_CATEGORY_nm) like '%venti%'  then 'VENTILATION'
                           when lower(product_category_nm) like 'cooking' then 'COOKING'
                           when lower(product_category_nm) like '%laundry%' and lower(product_dsc) like '%dryer%' then 'LAUNDRY-DRYER'
                           when lower(product_category_nm) like '%laundry%' then 'LAUNDRY-WASHER'
                           else 'other'
                           end as bora_pricing_category,
                           brand_nm, price_amt, brand_key, DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT--, sku_no, upc_cd
                    from
                         bosh.v_product pd
                   where
                      pd.MODEL_NO in ('BCM8450UC','HPIN54WS','PH60GWS',
                                        'PRD606RCSG','PRD606RESG','PRD606WCSG',
                                        'TCM24PS','TCM24RS','TCM24TS','WM262700','WT262700'
                                        )
                     ) pd
                 on (bd.brand_key = pd.brand_key
                    and upper(r.product_cat_desc) = upper(pd.bora_pricing_category)
                     --and pd.price_amt between  pl.min_product_price and pl.max_product_price
                    )
        Group by PD.PRODUCT_KEY,PD.MODEL_NO,pd.price_amt ,pd.DO_NOT_SOLICIT_PRODUCT_IND,PRODUCT_COVERAGE_END_DT,pd.bora_pricing_category,pl.exp_dt,upper(r.product_cat_desc)
Order by MODEL_NO