alter table RAW_INWARRANTY_LEADS_TBL
    add ACCOUNT_ID NVARCHAR2(100)
/

alter table RAW_INWARRANTY_LEADS_TBL
    add CLAIM_REPAIR_DATE NVARCHAR2(100)
/


alter table RAW_INWARRANTY_LEADS_TBL
    add CONSECUTIVE_NUMBER_N NVARCHAR2(100)
/

alter table RAW_INWARRANTY_LEADS_TBL
    modify STATE VARCHAR2(50)
/

alter table RAW_INWARRANTY_LEADS_TBL
    modify ZIPCODE VARCHAR2(30)
/


alter table RAW_INWARRANTY_LEADS_TBL
    modify MODEL_NUMBER VARCHAR2(100)
/

alter table RAW_INWARRANTY_LEADS_TBL
    modify BRAND VARCHAR2(50)
/

alter table RAW_INWARRANTY_LEADS_TBL
    modify LOCATION_PHONE VARCHAR2(30)
/




alter table RAW_INWARRANTY_LEADS_TBL_NEW
    modify MODEL_NUMBER VARCHAR2(100)
/

alter table RAW_INWARRANTY_LEADS_TBL_NEW
    modify BRAND VARCHAR2(50)
/

alter table RAW_INWARRANTY_LEADS_TBL_NEW
    modify LOCATION_PHONE VARCHAR2(30)
/

alter table RAW_INWARRANTY_LEADS_TBL_NEW
    modify LOCATION_PHONE VARCHAR2(30)
/

--       - Oracle error (repeated 1 times): ORA-12899: value too large for column "BOSHSTG"."RAW_INWARRANTY_LEADS_TBL_NEW"."BRAND" (actual: 36, maximum: 30)
--       - Oracle error (repeated 2 times): ORA-12899: value too large for column "BOSHSTG"."RAW_INWARRANTY_LEADS_TBL_NEW"."LOCATION_PHONE" (actual: 21, maximum: 20)


-- Oracle error (repeated 1 times): ORA-12899: value too large for column "BOSHSTG"."RAW_INWARRANTY_LEADS_TBL"."ZIPCODE" (actual: 21, maximum: 20)
-- Oracle error (repeated 1 times): ORA-12899: value too large for column "BOSHSTG"."RAW_INWARRANTY_LEADS_TBL"."ZIPCODE" (actual: 27, maximum: 20)

          update RAW_INWARRANTY_LEADS_TBL
          set    LOCATION_PHONE = REPLACE(REPLACE(REPLACE(LOCATION_PHONE,' ',''),')',''),'(','')
          where     ltrim(trim(LOCATION_PHONE), '0') is not null;

        update RAW_INWARRANTY_LEADS_TBL
        set    STATE = (select POSTAL_STATE_CD from BOSH.postal_state_dim where UPPER(POSTAL_STATE_NM) = UPPER(STATE))
        where  UPPER(STATE) in (select UPPER(POSTAL_STATE_NM) from BOSH.postal_state_dim );


select Distinct SUBSTR(FIRST_NAME,0,4)
from RAW_INWARRANTY_LEADS_TBL
    where  FIRST_NAME like '%.%'
and (SUBSTR(FIRST_NAME,3,1) = '.' Or  SUBSTR(FIRST_NAME,4,1) = '.' Or  SUBSTR(FIRST_NAME,5,1) = '.' );


select  CLAIM_REPAIR_DATE,to_char((TO_DATE(nvl(CLAIM_REPAIR_DATE, '01.01.1900'),'MM.DD.YYYY')),'MM/YYYY')
from RAW_INWARRANTY_LEADS_TBL;--13444




select distinct PURCHASE_DATE,LENGTH(PURCHASE_DATE),SUBSTR(PURCHASE_DATE,3,1),SUBSTR(PURCHASE_DATE,6,1)
from RAW_INWARRANTY_LEADS_TBL
    where
        LENGTH(TRIM(replace(PURCHASE_DATE,CHR(13),''))) <> 10
        or
        SUBSTR(PURCHASE_DATE,3,1) <> '.'
       Or
        SUBSTR(PURCHASE_DATE,6,1) <> '.'
 ;


select distinct CLAIM_REPAIR_DATE,LENGTH(CLAIM_REPAIR_DATE),SUBSTR(CLAIM_REPAIR_DATE,3,1),SUBSTR(CLAIM_REPAIR_DATE,6,1)
from RAW_INWARRANTY_LEADS_TBL
    where
        LENGTH(TRIM(replace(CLAIM_REPAIR_DATE,CHR(13),''))) <> 10
        or
        SUBSTR(CLAIM_REPAIR_DATE,3,1) <> '.'
       Or
        SUBSTR(CLAIM_REPAIR_DATE,6,1) <> '.'
 ;



Select RIS_NR  ,
       FIRST_NAME,
    substr(FIRST_NAME, 1, instr(FIRST_NAME, ' ') - 1)   AS  FIRST_NM  ,
    substr(FIRST_NAME, instr(FIRST_NAME, ' ') + 1)    AS  LAST_NM   ,
    ADDRESS     ,
    CITY        ,
    STATE       ,
    (select POSTAL_STATE_CD from BOSH.postal_state_dim where UPPER(POSTAL_STATE_NM) = UPPER(STATE)) AS STATE,
    ZIPCODE     ,
    LOCATION_PHONE ,
    REPLACE(REPLACE(REPLACE(LOCATION_PHONE,' ',''),')',''),'(','') AS LOCATION_PHONE ,
    EMAIL           ,
    BRAND            ,
    MODEL_NUMBER     ,
    substr(MODEL_NUMBER, 1, instr(MODEL_NUMBER, '-') - 1)   AS  Model,
    substr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),1,instr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),'-')-1)    AS  BRAND,
    substr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),instr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),'-')+1)    AS  Type,
    FD                ,
    SERIAL_NR          ,
    PURCHASE_DATE       ,
    --to_char((TO_DATE(nvl(PURCHASE_DATE, '01.01.1900'),'DD.MM.YYYY')),'MM/DD/YYYY') AS PURCHASE_DATE,
    APPLIANCE_TYPE       ,
    REGION               ,
    RIS_STATUS            ,
    SPECIAL_PROCESS_TYPE  ,
    FISCAL_MONTH          ,
    FILE_NM               ,
    INSERT_AUDIT_KEY      ,
    UNIQUE_SEQ_NO         ,
    ERROR_DESC            ,
    NAME_ADDRESS_HASH     ,
    ACCOUNT_ID            ,
    CLAIM_REPAIR_DATE     ,
    to_char((TO_DATE(nvl(CLAIM_REPAIR_DATE, '01.01.1900'),'DD.MM.YYYY')),'MM/DD/YYYY') AS CLAIM_REPAIR_DATE,
    CONSECUTIVE_NUMBER_N   from RAW_INWARRANTY_LEADS_TBL_NEW
    where --FILE_NM = 'bsh_after_cdb_iw_asp_20220201.txt' and FIRST_NAME like '%.%'
        LENGTH(TRIM(replace(PURCHASE_DATE,CHR(13),''))) <> 10
    order by DBMS_RANDOM.RANDOM();