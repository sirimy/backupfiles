select source, count(*)
  from P_serialized_item_dim si
       join P_audit_tbl pa1 on (pa1.audit_key = insert_audit_key)
       left join P_audit_tbl pa2 on (pa2.audit_key = sync_audit_key)
       left join P_serialized_item_ext_dim six on six.si_key = si.si_key
 where 1=1
   and pa1.creation_dt >= date '2023-08-15'
 and si.SI_KEY in ( select sid.SI_KEY from serialized_item_dim sid)
 group by source order by source;
+------+--------+
|SOURCE|COUNT(*)|
+------+--------+
|WEB   |3       |
|NULL  |3437    |
+------+--------+


select COUNT(FILE_NM) from raw_inwarranty_leads_tbl where
      MODEL_NUMBER is null and ACCOUNT_ID is null and
      RIS_NR is null  and FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null
;--11463

select FILE_NM,COUNT(FILE_NM) from raw_inwarranty_leads_tbl where
      MODEL_NUMBER is null and ACCOUNT_ID is null and
      RIS_NR is null  and FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null
Group by FILE_NM;

+---------------------------------+--------+
|FILE_NM                          |COUNT(*)|
+---------------------------------+--------+
|bsh_after_cdb_iw_asp_20231101.txt|9494    |
|bsh_after_cdb_iw_asp_20231001.txt|9841    |
+---------------------------------+--------+


select FILE_NM,COUNT(FILE_NM) from COMMON_LOAD_HOLD_TBL
Group by FILE_NM;
+---------------------------------+--------------+
|FILE_NM                          |COUNT(FILE_NM)|
+---------------------------------+--------------+
|bsh_after_cdb_iw_asp_20231201.txt|9450          |
+---------------------------------+--------------+

select FILE_NM,COUNT(FILE_NM) from raw_inwarranty_leads_tbl
Group by FILE_NM;
+---------------------------------+--------------+
|FILE_NM                          |COUNT(FILE_NM)|
+---------------------------------+--------------+
|bsh_after_cdb_iw_asp_20231201.txt|9864          |
+---------------------------------+--------------+



select COUNT(*) from raw_inwarranty_leads_tbl ;--9864

Select COUNT(*) from COMMON_LOAD_HOLD_TBL;--9450
Select COUNT(*) from COMMON_LOAD_TBL;--9450
select COUNT(*) from ADDRESS_OUTPUT_TBL;--9450
select COUNT(*) from SI_OUTPUT_TBL;--9450
select COUNT(*) from CUSTOMER_OUTPUT_TBL;--0
select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--0
select COUNT(*) from SERIALIZED_ITEM_LKP;--0


select * from SI_OUTPUT_TBL;



select COUNT(*) from visitor_dim;--0
select COUNT(*) from visitor_lkp;--0
select COUNT(*) from visitor_history_tbl;--0
select COUNT(*) from address_dim;--0
select COUNT(*) from address_lkp;--0
select COUNT(*) from visitor_address_xref;--0
select COUNT(*) from visitor_address_lkp;--0
select COUNT(*) from serialized_item_dim;--0
select COUNT(*) from serialized_item_lkp;--0
select COUNT(*) from visitor_ownership_xref;--0


select COUNT(*) from email_lkp;--0
select COUNT(*) from email_dim;--0
select COUNT(*) from visitor_email_xref;--0
select COUNT(*) from visitor_email_lkp;--0
select COUNT(*) from phone_dim;--0
select COUNT(*) from phone_lkp;--0
select COUNT(*) from visitor_phone_xref;--0
 select COUNT(*) from VISITOR_PREFERENCE_TBL;--0
select COUNT(*) from VISITOR_PURL_XREF;--0
select COUNT(*) from CUSTOMER_DIM;--0
select COUNT(*) from HOUSEHOLD_LKP;--0
select COUNT(*) from CUSTOMER_LKP;--0


select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--0

select source, count(*) from serialized_item_ext_dim group by source;
+----------+--------+
|SOURCE    |COUNT(*)|
+----------+--------+
|INWARRANTY|12465   |
+----------+--------+

select source, count(*) from serialized_item_ext_dim group by source;
+-------------+--------+
|SOURCE       |COUNT(*)|
+-------------+--------+
|HOME CONNECT |146     |
|CDB - CATCHUP|209     |
|WEB          |3       |
|CDB          |483     |
|INWARRANTY   |11624   |
+-------------+--------+


    select distinct FILE_NM,INSERT_AUDIT_KEY from BOSH.RAW_INWARRANTY_LEADS_TBL where FILE_NM in
('bsh_after_cdb_iw_asp_20230601.txt','bsh_after_cdb_iw_asp_20230501.txt')
+---------------------------------+--------------+
|FILE_NM                          |COUNT(FILE_NM)|
+---------------------------------+--------------+
|bsh_after_cdb_iw_asp_20230601.txt|4224          |
|bsh_after_cdb_iw_asp_20230501.txt|9806          |
+---------------------------------+--------------+

select max(to_date(PURCHASE_DATE, 'MM/DD/YYYY')) from BOSH.RAW_INWARRANTY_LEADS_TBL
 where INSERT_AUDIT_KEY in (717649,717650) and ERROR_DESC is null;

--Before core merge
select latest_coverage_type, name, count(*), max(registration_dt)
  from P_serialized_item_dim si left join P_latest_coverage_type_dim on coverage_type_key = latest_coverage_type
 group by latest_coverage_type, name
 order by 1;
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2567258 |2107-10-01          |
|2                   |Extended WARRANTY              |86622   |2023-08-18 17:29:55 |
|22                  |Duplicate data                 |123593  |2023-08-20 18:57:01 |
+--------------------+-------------------------------+--------+--------------------+

    --after core merge

+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2574290 |2107-10-01          |
|2                   |Extended WARRANTY              |86658   |2023-08-20 04:46:41 |
|22                  |Duplicate data                 |123593  |2023-08-20 18:57:01 |
+--------------------+-------------------------------+--------+--------------------+

    -- After duplicate run

+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2573314 |2107-10-01          |
|2                   |Extended WARRANTY              |86658   |2023-08-20 04:46:41 |
|22                  |Duplicate data                 |124569  |2023-08-20 18:57:01 |
+--------------------+-------------------------------+--------+--------------------+
