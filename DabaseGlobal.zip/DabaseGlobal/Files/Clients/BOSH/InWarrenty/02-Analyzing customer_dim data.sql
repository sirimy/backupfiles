 select count(*) from customer_dim
 union all
 select count(*) from customer_dim where customer_key in (select c.customer_key from bosh.customer_dim c)
 union all
 select count(*) from customer_dim where customer_key not in (select c.customer_key from bosh.customer_dim c);




--Most imp data element in customer_dim are DNS flags so checking change in DNS flags in this table
--only phone suppression change here for 6 records STG in N and Core it Y
select c.phone_suppression_cd, s.phone_suppression_cd,
       count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
 where 1=2
--     or (c.email_suppression_cd <> s.email_suppression_cd )      --
--     or (c.address_suppression_cd <> s.address_suppression_cd )  --
    or (c.phone_suppression_cd <> s.phone_suppression_cd )      --
 group by c.phone_suppression_cd, s.phone_suppression_cd
;
--  PHONE_SUPPRESSION_CD,PHONE_SUPPRESSION_CD,COUNT(*)
-- N,Y,6
+--------------------+--------------------+--------+
|PHONE_SUPPRESSION_CD|PHONE_SUPPRESSION_CD|COUNT(*)|
+--------------------+--------------------+--------+
|Y                   |N                   |20      |
+--------------------+--------------------+--------+
+--------------------+--------------------+--------+
|PHONE_SUPPRESSION_CD|PHONE_SUPPRESSION_CD|COUNT(*)|
+--------------------+--------------------+--------+
|Y                   |N                   |23      |
+--------------------+--------------------+--------+



select c.email_suppression_cd, s.email_suppression_cd, 
       count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
 where 1=2
    or (c.email_suppression_cd <> s.email_suppression_cd )      --
--     or (c.address_suppression_cd <> s.address_suppression_cd )  --
--     or (c.phone_suppression_cd <> s.phone_suppression_cd )      --
 group by c.email_suppression_cd, s.email_suppression_cd    
;
--zero records
+--------------------+--------------------+--------+
|EMAIL_SUPPRESSION_CD|EMAIL_SUPPRESSION_CD|COUNT(*)|
+--------------------+--------------------+--------+
|Y                   |N                   |950     |
+--------------------+--------------------+--------+
+--------------------+--------------------+--------+
|EMAIL_SUPPRESSION_CD|EMAIL_SUPPRESSION_CD|COUNT(*)|
+--------------------+--------------------+--------+
|Y                   |N                   |919     |
+--------------------+--------------------+--------+



select c.address_suppression_cd, s.address_suppression_cd,
       count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
 where 1=2
--     or (c.email_suppression_cd <> s.email_suppression_cd )      --
    or (c.address_suppression_cd <> s.address_suppression_cd )  --
--     or (c.phone_suppression_cd <> s.phone_suppression_cd )      --
 group by c.address_suppression_cd, s.address_suppression_cd
;
-- ADDRESS_SUPPRESSION_CD,ADDRESS_SUPPRESSION_CD,COUNT(*)
+----------------------+----------------------+--------+
|ADDRESS_SUPPRESSION_CD|ADDRESS_SUPPRESSION_CD|COUNT(*)|
+----------------------+----------------------+--------+
|Y                     |N                     |4       |
+----------------------+----------------------+--------+

+----------------------+----------------------+--------+
|ADDRESS_SUPPRESSION_CD|ADDRESS_SUPPRESSION_CD|COUNT(*)|
+----------------------+----------------------+--------+
|Y                     |N                     |6       |
+----------------------+----------------------+--------+




--We will be concerned about customers, which were being suppressed in core and now they will become eligible for solicitation
--most probably we will retain/update these customers as suppressed to avoid any issues
 select count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
 where (c.email_suppression_cd <> s.email_suppression_cd and c.email_suppression_cd = 'Y')
    or (c.address_suppression_cd <> s.address_suppression_cd and c.address_suppression_cd = 'Y')
    or (c.phone_suppression_cd <> s.phone_suppression_cd and c.phone_suppression_cd = 'Y')
;
--total 0 such customers --
+--------+
|COUNT(*)|
+--------+
|965     |
+--------+

941


--Now suppress these customers again in stg
merge into customer_dim s
using (select * from bosh.customer_dim c ) c  
   on (c.customer_key = s.customer_key)
when matched then   
update 
   set s.email_suppression_cd = c.email_suppression_cd   
 where (c.email_suppression_cd <> s.email_suppression_cd and c.email_suppression_cd = 'Y');
--0 rows

merge into customer_dim s
using (select * from bosh.customer_dim c ) c  
   on (c.customer_key = s.customer_key)
when matched then   
update 
   set s.address_suppression_cd = c.address_suppression_cd   
 where (c.address_suppression_cd <> s.address_suppression_cd and c.address_suppression_cd = 'Y');
--0 rows

merge into customer_dim s
using (select * from bosh.customer_dim c ) c  
   on (c.customer_key = s.customer_key)
when matched then   
update 
   set s.phone_suppression_cd = c.phone_suppression_cd   
 where (c.phone_suppression_cd <> s.phone_suppression_cd and c.phone_suppression_cd = 'Y');
--0 rows
 
commit; 


--cross checking after merge above:
 select *
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
 where (c.email_suppression_cd <> s.email_suppression_cd and c.email_suppression_cd = 'Y')
    or (c.address_suppression_cd <> s.address_suppression_cd and c.address_suppression_cd = 'Y')
    or (c.phone_suppression_cd <> s.phone_suppression_cd and c.phone_suppression_cd = 'Y')
;
--no rows --good




-----------------------------------------------------------------------
--   customer_brand_email_dns_dim
--   in case of inwarranty leads, we populate customer_brand_email_dns_dim in stg with new customers only
--   so following sqls will not return any data for inwarranty leads
-----------------------------------------------------------------------
--Checking customers with change in email dns flag between core and stg
select *
  from customer_brand_email_dns_dim s
       join bosh.customer_brand_email_dns_dim c
          on c.customer_key = s.customer_key and c.brand_key = s.brand_key
 where (c.email_suppression_cd <> s.email_suppression_cd
       );
--no rows


--checking customers, which are suppressed in core and have become eligible for emails in staging
select * 
  from customer_brand_email_dns_dim s
       join bosh.customer_brand_email_dns_dim c
          on c.customer_key = s.customer_key and c.brand_key = s.brand_key
 where (c.email_suppression_cd <> s.email_suppression_cd and c.email_suppression_cd = 'Y' 
       );
--no rows

--we will suppress these again as we are not going to convert from DNS to no-DNS based upon historical file
merge into customer_brand_email_dns_dim s
using (select * from bosh.customer_brand_email_dns_dim c 
      ) c  
   on (c.customer_key = s.customer_key and c.brand_key = s.brand_key)
when matched then   
update 
   set s.email_suppression_cd = c.email_suppression_cd,
       s.updated_by_source    = c.updated_by_source,
       s.last_email_pref_dt   = c.last_email_pref_dt
 where (c.email_suppression_cd <> s.email_suppression_cd and c.email_suppression_cd = 'Y');
--no rows

commit;

--practically it meant deleting these rows from staging as there is nothing to be updated, if we want to retain DNS flag from core
delete from customer_brand_email_dns_dim eDNS
where (customer_key, brand_key, email_suppression_cd) IN (
           select c.customer_key, c.brand_key, c.email_suppression_cd
             from bosh.customer_brand_email_dns_dim c
          );
--no rows
commit;

select * from customer_brand_email_dns_dim where rownum <= 5 ;
select count(*) from customer_brand_email_dns_dim;
--7327 rows
select brand_key, email_suppression_cd, count(*) from customer_brand_email_dns_dim group by brand_key, email_suppression_cd order by brand_key, email_suppression_cd;
--
-- BRAND_KEY,EMAIL_SUPPRESSION_CD,COUNT(*)
-- 76,Y,5085
-- 77,Y,2104
-- 78,Y,138



--Customers with change in address
 select count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
        join ADDRESS_DIM sad on sad.ADDRESS_KEY = s.PRIMARY_ADDRESS_KEY
        join bosh.ADDRESS_DIM cad on cad.ADDRESS_KEY = c.PRIMARY_ADDRESS_KEY
 where (c.PRIMARY_ADDRESS_KEY <> s.PRIMARY_ADDRESS_KEY);
--294

 select
        sad.FIRST_NM, sad.LAST_NM,
        cad.FIRST_NM, cad.LAST_NM,
        sad.ADDRESS_LINE1_TX, sad.ADDRESS_LINE2_TX,
        cad.ADDRESS_LINE1_TX, cad.ADDRESS_LINE2_TX,
        sad.CITY_NM,
        sad.STATE_CD,
        sad.ZIP_CODE5_TX,
        sad.ZIP_CODE4_TX,

        cad.CITY_NM,
        cad.STATE_CD,
        cad.ZIP_CODE5_TX,
        cad.ZIP_CODE4_TX
        ,sad.ADDRESS_KEY, sad.FIRM_NM, sad.MIDDLE_NM, sad.SOURCE_CD, sad.SUPPRESSION_CD, sad.ACE_ERROR_CD
        ,cad.ADDRESS_KEY, cad.FIRM_NM, cad.MIDDLE_NM, cad.SOURCE_CD, cad.SUPPRESSION_CD, cad.ACE_ERROR_CD
 from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
        join ADDRESS_DIM sad on sad.ADDRESS_KEY = s.PRIMARY_ADDRESS_KEY
        join bosh.ADDRESS_DIM cad on cad.ADDRESS_KEY = c.PRIMARY_ADDRESS_KEY
 where (c.PRIMARY_ADDRESS_KEY <> s.PRIMARY_ADDRESS_KEY)
   and cad.SOURCE_CD = 'NCOA'
;
--29 rows


merge into CUSTOMER_DIM tgt
using ( select c.CUSTOMER_KEY, c.PRIMARY_ADDRESS_KEY
       from customer_dim s
            join bosh.customer_dim c
               on c.customer_key = s.customer_key
            join ADDRESS_DIM sad on sad.ADDRESS_KEY = s.PRIMARY_ADDRESS_KEY
            join bosh.ADDRESS_DIM cad on cad.ADDRESS_KEY = c.PRIMARY_ADDRESS_KEY
     where (c.PRIMARY_ADDRESS_KEY <> s.PRIMARY_ADDRESS_KEY)
           and cad.SOURCE_CD = 'NCOA'  --29 rows
      ) src
on (src.CUSTOMER_KEY = tgt.CUSTOMER_KEY)
when matched then
update set tgt.PRIMARY_ADDRESS_KEY = src.PRIMARY_ADDRESS_KEY
where tgt.PRIMARY_ADDRESS_KEY <> src.PRIMARY_ADDRESS_KEY;
--29 rows
commit;



 select sad.EMAIL_ADDRESS_TX, cad.EMAIL_ADDRESS_TX
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
        join EMAIL_DIM sad on sad.EMAIL_KEY = s.PRIMARY_EMAIL_KEY
        join bosh.EMAIL_DIM cad on cad.EMAIL_KEY = c.PRIMARY_EMAIL_KEY
 where (c.PRIMARY_EMAIL_KEY <> s.PRIMARY_EMAIL_KEY);
--81 rows