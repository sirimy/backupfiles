
select COUNT(*) from raw_inwarranty_leads_tbl where FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null order by DBMS_RANDOM.RANDOM(); --1639


select * from RAW_INWARRANTY_LEADS_TBL;

select COUNT(*) from RAW_INWARRANTY_LEADS_TBL;--14745

select COUNT(*) from RAW_INWARRANTY_LEADS_TBL where ERROR_DESC is null;--14745

-- select * from RAW_INWARRANTY_LEADS_TBL where STATE is null;--1640

Select COUNT(*) From RAW_INWARRANTY_LEADS_TBL
where  UPPER(STATE) in (select UPPER(POSTAL_STATE_CD) from BOSH.postal_state_dim );--0



Select * From RAW_INWARRANTY_LEADS_TBL
where  UPPER(STATE)   in (select UPPER(POSTAL_STATE_NM) from BOSH.postal_state_dim );--3

Select COUNT(*) From RAW_INWARRANTY_LEADS_TBL
where  UPPER(STATE)   in (select UPPER(POSTAL_STATE_NM) from BOSH.postal_state_dim );--14743

Update RAW_INWARRANTY_LEADS_TBL
SET STATE = (select POSTAL_STATE_CD from BOSH.postal_state_dim where UPPER(POSTAL_STATE_NM) = UPPER(STATE))
where  UPPER(STATE) in (select UPPER(POSTAL_STATE_NM) from BOSH.postal_state_dim );--

Select COUNT(*) From RAW_INWARRANTY_LEADS_TBL
where  UPPER(STATE) in (select UPPER(POSTAL_STATE_CD) from BOSH.postal_state_dim );--14743

select UPPER(POSTAL_STATE_NM),POSTAL_STATE_CD from BOSH.postal_state_dim;

select  Distinct UPPER(STATE) from RAW_INWARRANTY_LEADS_TBL;

update RAW_INWARRANTY_LEADS_TBL
set    LOCATION_PHONE = REPLACE(REPLACE(REPLACE(LOCATION_PHONE,' ',''),')',''),'(','')
where     ltrim(trim(LOCATION_PHONE), '0') is not null;


SELECT
            UNIQUE_SEQ_NO AS  UNIQUE_SEQ_NO
            ,1            AS  SOURCE_SYSTEM_CD
            ,substr(FIRST_NAME, 1, instr(FIRST_NAME, ' ') - 1)    AS  FIRST_NM
            ,''           AS  MIDDLE_NM
            ,substr(FIRST_NAME, instr(FIRST_NAME, ' ') + 1)     AS  LAST_NM
            ,''           AS  FIRM_NM
            ,SUBSTR(ADDRESS, 1, 60)      AS  ADDRESS_LINE1_TX
            ,NULL         AS  ADDRESS_LINE2_TX
            ,CITY         AS  CITY_NM
            ,STATE        AS  STATE_CD
            ,ZIPCODE      AS  ZIP_CD_TX
            ,''           AS  COUNTRY_CD
            ,'Y'          AS  PRIMARY_PHONE_IND
            --,W_PKG_UTILS.PHONE_CLEAN(SUBSTR(TELEPHONE_NO,1,20)) AS  PRIMARY_PHONE_NO
            ,CASE WHEN LENGTH(LOCATION_PHONE) = 12 AND SUBSTR(LOCATION_PHONE,1,2) = '+1' THEN (SUBSTR(LOCATION_PHONE,3,10))
                  WHEN LENGTH(LOCATION_PHONE) = 11 AND SUBSTR(LOCATION_PHONE,1,1) = '1' THEN (SUBSTR(LOCATION_PHONE,2,10))
                  ELSE SUBSTR(LOCATION_PHONE,1,10)
             END AS  PRIMARY_PHONE_NO
            ,EMAIL        AS  EMAIL_ADDRESS_TX
            ,CASE WHEN MODEL_NUMBER LIKE '%/%' THEN SUBSTR(MODEL_NUMBER,1,INSTR(MODEL_NUMBER,'/') -1) ELSE MODEL_NUMBER END AS MODEL_NO
            ,case when ltrim(SERIAL_NR, '0') is not null then FD || '-' || SERIAL_NR end as serial_no
            ---
            --there is no external customer_id with inwarranty leads data so we will use NAME_ADDRESS_HASH for that
            ,case when instr(MODEL_NUMBER,'/') > 0 then MODEL_NUMBER else MODEL_NUMBER||'/xx' end
                    ||'-'|| to_char(to_date(PURCHASE_DATE, 'MM/DD/YYYY'), 'YYYYMMDD')
                    ||'-'|| 'IW' || NAME_ADDRESS_HASH
               AS  SI_UNIQUE_ID
            ---
            ,TO_DATE(nvl(purchase_Date, '01/01/1900'),'MM/DD/YYYY') AS PURCHASE_DATE
            ---
            ,'IW' ||  NAME_ADDRESS_HASH  AS  VISITOR_XID
            ---
            ,NULL AS  PRIMARY_ADDRESS_IND
            ,NULL AS  MAIL_PREF_IND
            ,NULL AS  EMAIL_PREF_IND
            ,NULL AS  PHONE_PREF_IND
            ,CASE WHEN UPPER(C.BRAND_NM) = 'THERMADOR' THEN chk_date(purchase_date) + 730
                  WHEN UPPER(C.BRAND_NM) = 'BOSCH'     THEN chk_date(purchase_date) + 365
                  WHEN UPPER(C.BRAND_NM) = 'GAGGENAU'  THEN chk_date(purchase_date) + 730
             END AS WARRANTY_EXPIRATION_DT
            ,TO_DATE(nvl(purchase_Date, '01/01/1900'),'MM/DD/YYYY') AS REGISTRATION_DT
            ,'' AS  ADDRESS_XID
            ,'' AS  EMAIL_XID
            --,case when instr(E_NUMBER,'/') > 0 then E_NUMBER else E_NUMBER||'/xx' end||'-'||nvl(registration_Dt,nvl(purchase_Dt,'19000101'))||'-'||account_id AS  SI_XID
            ,'' AS  PURCHASE_AMT
            ,'' AS  ADDRESS_UNIQUE_ID
            ,FILE_NM AS FILE_NM
            ,'L_INSERT_AUDIT_KEY' AS INSERT_AUDIT_KEY
            ,CASE WHEN MODEL_NUMBER LIKE '%/%' THEN SUBSTR(MODEL_NUMBER, 1, INSTR(MODEL_NUMBER, '/') -1) ELSE MODEL_NUMBER END AS  PRODUCT_UNIQUE_ID
            ,'' AS  VISITOR_MATCH_IND
            ,'' AS  SERIAL_MATCH_IND
            ,'' AS  ADDR_MATCH_IND
            ,'' AS  FIRM_MATCH_IND
            ,'N' AS  EMAIL_MATCH_IND
            ,'N' AS  PHONE_MATCH_IND
      FROM
             RAW_INWARRANTY_LEADS_TBL a
             LEFT JOIN BOSH.BRAND_DIM c ON ( upper(a.brand) = upper(c.brand_dsc))
      where  not exists (
                         select 1 from COMMON_LOAD_HOLD_TBL B
                         where  a.unique_seq_no = b.unique_seq_no
                        )
      AND    a.error_desc is  NULL -- Bosh -406
      ;


Select * from COMMON_LOAD_HOLD_TBL where FIRST_NM = 'YOU';
+-------------+----------------+------------+-----------------+-----------+-------------------+-----------------+--------+---------+-------+-------+-----------------+----------------+----------------+----------------+--------+--------+---------+----------+--------+---------+-----------------+---------+---------------+-----------------+---------+-----------------+---------------+-----------------------------------+------+-----------+-----------------+----------+-----------+--------------------------+---------------+------------+-----------+-----------------+--------------------------+----------------------+-----------------------+-----------+----------------------+------------------+-------------+--------------+--------------+-----------------+----------------+--------------+--------------+---------------+---------------+-------+----------------+-----------------+----------------+------------------------+------------------+------------+-------------------+-------------+
|UNIQUE_SEQ_NO|SOURCE_SYSTEM_CD|VISITOR_XID |ADDRESS_UNIQUE_ID|ADDRESS_XID|PRIMARY_ADDRESS_IND|ADDRESS_ROLE_TYPE|FIRST_NM|MIDDLE_NM|LAST_NM|FIRM_NM|ADDRESS_LINE1_TX |ADDRESS_LINE2_TX|ADDRESS_LINE3_TX|CITY_NM         |CITY_NM2|STATE_CD|ZIP_CD_TX|COUNTRY_CD|PHONE_NO|PHONE_XID|PRIMARY_PHONE_IND|PHONE_EXT|PHONE_ROLE_TYPE|EMAIL_ADDRESS_TX |EMAIL_XID|PRIMARY_EMAIL_IND|EMAIL_ROLE_TYPE|SI_UNIQUE_ID                       |SI_XID|PRODUCT_XID|PRODUCT_UNIQUE_ID|MODEL_NO  |SERIAL_NO  |PURCHASE_DT               |REGISTRATION_DT|PURCHASE_AMT|CURRENCY_CD|WARRANTY_START_DT|WARRANTY_EXPIRATION_DT    |LATEST_COVERAGE_EXP_DT|LATEST_COVERAGE_TYPE_CD|PACKAGE_XID|PACKAGE_TYPE_UNIQUE_ID|PACKAGE_CREATED_TS|MAIL_PREF_IND|EMAIL_PREF_IND|PHONE_PREF_IND|VISITOR_MATCH_IND|SERIAL_MATCH_IND|ADDR_MATCH_IND|FIRM_MATCH_IND|EMAIL_MATCH_IND|PHONE_MATCH_IND|FILE_NM|INSERT_AUDIT_KEY|PACKAGE_UNIQUE_ID|PACKAGE_TYPE_XID|PACKAGE_TYPE_DESCRIPTION|CUSTOMER_UNIQUE_ID|CUSTOMER_XID|HOUSEHOLD_UNIQUE_ID|HOUSEHOLD_XID|
+-------------+----------------+------------+-----------------+-----------+-------------------+-----------------+--------+---------+-------+-------+-----------------+----------------+----------------+----------------+--------+--------+---------+----------+--------+---------+-----------------+---------+---------------+-----------------+---------+-----------------+---------------+-----------------------------------+------+-----------+-----------------+----------+-----------+--------------------------+---------------+------------+-----------+-----------------+--------------------------+----------------------+-----------------------+-----------+----------------------+------------------+-------------+--------------+--------------+-----------------+----------------+--------------+--------------+---------------+---------------+-------+----------------+-----------------+----------------+------------------------+------------------+------------+-------------------+-------------+
|8231417      |1               |IW2157171509|NULL             |NULL       |NULL               |NULL             |YOU     |NULL     |MEE CHO|NULL   |2416 QUEENS PLZ S|NULL            |NULL            |LONG ISLAND CITY|NULL    |NY      |11101    |NULL      |NULL    |NULL     |Y                |NULL     |NULL           |LEEH782@GMAIL.COM|NULL     |NULL             |NULL           |WTG86400UC/08-20210719-IW2157171509|NULL  |NULL       |WTG86400UC       |WTG86400UC|9904-200328|2021-07-19 00:00:00.000000|2021-07-19     |NULL        |NULL       |NULL             |2022-07-19 00:00:00.000000|NULL                  |NULL                   |NULL       |NULL                  |NULL              |NULL         |NULL          |NULL          |NULL             |NULL            |NULL          |NULL          |N              |N              |NULL   |658529          |NULL             |NULL            |NULL                    |NULL              |NULL        |NULL               |NULL         |
+-------------+----------------+------------+-----------------+-----------+-------------------+-----------------+--------+---------+-------+-------+-----------------+----------------+----------------+----------------+--------+--------+---------+----------+--------+---------+-----------------+---------+---------------+-----------------+---------+-----------------+---------------+-----------------------------------+------+-----------+-----------------+----------+-----------+--------------------------+---------------+------------+-----------+-----------------+--------------------------+----------------------+-----------------------+-----------+----------------------+------------------+-------------+--------------+--------------+-----------------+----------------+--------------+--------------+---------------+---------------+-------+----------------+-----------------+----------------+------------------------+------------------+------------+-------------------+-------------+
select * from ADDRESS_OUTPUT_TBL where FIRST_NM = 'YOU';--
+-------------+-------+--------+---------+-------+-----------------+----------------+----------------+--------+------------+------------+--------------------------------+-----------+
|UNIQUE_SEQ_NO|FIRM_NM|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX |ADDRESS_LINE2_TX|CITY_NM         |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|ADDRESS_HASH_KEY                |ADDRESS_KEY|
+-------------+-------+--------+---------+-------+-----------------+----------------+----------------+--------+------------+------------+--------------------------------+-----------+
|8231417      |NULL   |YOU     |MEE      |CHO    |2416 QUEENS PLZ S|NULL            |LONG ISLAND CITY|NY      |11101       |4607        |6f7dd931111d232089564869a33df21d|11311126   |
+-------------+-------+--------+---------+-------+-----------------+----------------+----------------+--------+------------+------------+--------------------------------+-----------+

Select COUNT(*) from COMMON_LOAD_HOLD_TBL;--11803

Select COUNT(*) from COMMON_LOAD_TBL;--11803
select COUNT(*) from ADDRESS_OUTPUT_TBL;--11803
select COUNT(*) from SI_OUTPUT_TBL;--11803
select * from SI_OUTPUT_TBL;--11803
select COUNT(*) from CUSTOMER_OUTPUT_TBL;--11803

select COUNT(*) from visitor_dim;--11199
select COUNT(*) from visitor_lkp;--11197
select COUNT(*) from visitor_history_tbl;--11197
select COUNT(*) from address_dim;--10740
select COUNT(*) from address_lkp;--15062
select COUNT(*) from visitor_address_xref;--11197
select COUNT(*) from visitor_address_lkp;--8078
select COUNT(*) from serialized_item_dim;--11562
select COUNT(*) from serialized_item_lkp;--11562
select COUNT(*) from visitor_ownership_xref;--11562
select COUNT(*) from email_lkp;--6468
select COUNT(*) from email_dim;--6206
select COUNT(*) from visitor_email_xref;--6587
select COUNT(*) from visitor_email_lkp;--3349
select COUNT(*) from phone_dim;--9495
select COUNT(*) from phone_lkp;--11050
select COUNT(*) from visitor_phone_xref;--9966
select COUNT(*) from visitor_phone_lkp;--5850
select COUNT(*) from VISITOR_PREFERENCE_TBL;--27750
select COUNT(*) from purl_dim;--8067
select COUNT(*) from VISITOR_PURL_XREF;--8067
select COUNT(*) from CUSTOMER_DIM;--10669
select COUNT(*) from HOUSEHOLD_LKP;--0
select COUNT(*) from CUSTOMER_LKP;--7334

select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--11562

select * from p_raw_inwarranty_leads_tbl where unique_seq_no is not NULL order by INSERT_AUDIT_KEY desc;

-- update serialized_item_ext_dim
-- set source = 'INWARRANTY';

select source, count(*) from serialized_item_ext_dim group by source;

select latest_coverage_type, name, count(*), max(registration_dt)
  from P_serialized_item_dim si left join P_latest_coverage_type_dim on coverage_type_key = latest_coverage_type
 group by latest_coverage_type, name
 order by 1;
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2292257 |2107-10-01          |
|2                   |Extended WARRANTY              |78793   |2023-03-07 19:36:38 |
|3                   |Cancelled WARRANTY             |1377    |2023-03-06 17:24:14 |
|6                   |Data Issues                    |25474   |2023-01-19 14:41:07 |
|20                  |Data Errors                    |2       |2020-04-30 20:03:48 |
|21                  |Gaggenau Ambassador Suppression|465     |2022-09-30          |
|22                  |Duplicate data                 |99161   |2023-03-07 21:05:32 |
|23                  |Gaggenau DNS List              |1928    |2022-12-10          |
|50                  |Temp Builder Suppression       |15009   |2022-01-12 18:57:08 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
+--------------------+-------------------------------+--------+--------------------+

--after merge

+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2303819 |2107-10-01          |
|2                   |Extended WARRANTY              |78793   |2023-03-07 19:36:38 |
|3                   |Cancelled WARRANTY             |1377    |2023-03-06 17:24:14 |
|6                   |Data Issues                    |25474   |2023-01-19 14:41:07 |
|20                  |Data Errors                    |2       |2020-04-30 20:03:48 |
|21                  |Gaggenau Ambassador Suppression|465     |2022-09-30          |
|22                  |Duplicate data                 |99161   |2023-03-07 21:05:32 |
|23                  |Gaggenau DNS List              |1928    |2022-12-10          |
|50                  |Temp Builder Suppression       |15009   |2022-01-12 18:57:08 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
+--------------------+-------------------------------+--------+--------------------+
