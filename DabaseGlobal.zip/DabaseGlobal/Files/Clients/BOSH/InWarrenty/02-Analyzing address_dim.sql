 select count(*) from address_dim
 union all
 select count(*) from address_dim where ADDRESS_KEY in (select c.ADDRESS_KEY from bosh.address_dim c)
 union all
 select count(*) from address_dim where ADDRESS_KEY not in (select c.ADDRESS_KEY from bosh.address_dim c);
-- +--------+
-- |COUNT(*)|
-- +--------+
-- |54819   |
-- |49372   |
-- |5447    |
-- +--------+




-- select adr.*, creation_dt
select count(*)
  from address_dim adr join audit_tbl dd on dd.audit_key = adr.insert_audit_key 
 where 1=1
   --and address_line1_tx is null
--   and address_line2_tx is not null
   and substr(ACE_ERROR_CD, 1, 1) = 'E'
--   and creation_dt >= date '2020-04-22' 
 order by dbms_random.random;
--order by ADDRESS_LINE1_TX, ADDRESS_LINE2_TX, ADDRESS_KEY;

  --ADDRESS_LINE1_TX,ADDRESS_LINE2_TX,CITY_NM,STATE_CD,ZIP_CODE5_TX
--1327 OVERLOOK RD,,GREENSBORO,VT,05841
--276
--237


--records are with address and ACE_ERROR_CD is good
--data looks good

select --s.primary_address_key, c.primary_address_key
       count(*)
   from customer_dim  ;
--10669
--11189


--customers with change in address
select --s.primary_address_key, c.primary_address_key 
       count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key           
 where s.primary_address_key <> c.primary_address_key;
--246
--279


--further checking how many of these may have a sale as in that case the address in core should be used
select --s.primary_address_key, c.primary_address_key 
       count(*)
   from customer_dim s
        join bosh.customer_dim c
           on c.customer_key = s.customer_key
        join visitor_dim vd on vd.customer_key = s.customer_key
        join visitor_ownership_xref vox on vox.visitor_key = vd.visitor_key
        join serialized_item_dim si_stg on si_stg.si_key = vox.si_key
        join bosh.serialized_item_dim si_core on si_core.si_key = si_stg.si_key
 where s.primary_address_key <> c.primary_address_key
  and   si_core.latest_coverage_type in (2, 3);
--0 --good
--0--



--update in stg same addreskey as in cor if sales exist against him
merge into customer_dim tgt
using (
        select s.customer_key, c.primary_address_key
           from customer_dim s
                join bosh.customer_dim c
                   on c.customer_key = s.customer_key
                join visitor_dim vd on vd.customer_key = s.customer_key
                join visitor_ownership_xref vox on vox.visitor_key = vd.visitor_key
                join serialized_item_dim si_stg on si_stg.si_key = vox.si_key
                join bosh.serialized_item_dim si_core on si_core.si_key = si_stg.si_key
         where s.primary_address_key <> c.primary_address_key
          and   si_core.latest_coverage_type in (2, 3)
     ) src
     on (src.customer_key = tgt.customer_key)
when matched then
update 
set    tgt.primary_address_key = src.primary_address_key
where  tgt.primary_address_key <> src.primary_address_key;
--0 rows

commit;
