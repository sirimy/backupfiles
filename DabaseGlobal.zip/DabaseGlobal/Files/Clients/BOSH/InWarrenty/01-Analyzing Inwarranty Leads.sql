---------------------------------------------------------------------------
--- raw_inwarranty_leads_tbl
---------------------------------------------------------------------------

select * from (select * from raw_inwarranty_leads_tbl r order by dbms_random.random) where rownum <= 100;


delete from raw_inwarranty_leads_tbl where FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null;
commit;

select BRAND, MODEL_NO, count(*)
  from (
        select BRAND,
               case when MODEL_NUMBER like '%/%' then substr(MODEL_NUMBER,1,instr(MODEL_NUMBER,'/') -1)
                    when MODEL_NUMBER like '%(%' then substr(MODEL_NUMBER,1,instr(MODEL_NUMBER,'(') -1)
                    else MODEL_NUMBER end AS MODEL_NO
        from raw_inwarranty_leads_tbl)
 where MODEL_NO not in (select pd.model_no from bosh.PRODUCT_DIM pd where pd.model_no is not null)
group by BRAND, MODEL_NO
order by BRAND, MODEL_NO;

select * from (select * from raw_inwarranty_leads_tbl r order by dbms_random.random) where BRAND like '%/%';

select ERROR_DESC, count(*) from raw_inwarranty_leads_tbl r group by ERROR_DESC order by ERROR_DESC;


select file_nm, count(*),
       count(case when ERROR_DESC = 'ZIPCODE has invalid data' then 1 end) zipcode_error,
       count(case when length(FD) <> 4 then 1 end) fd_length,
       count(case when trim(ADDRESS) is null and ERROR_DESC is null then 1 end) address_missing,
       count(case when ERROR_DESC is null and length(FD) = 4 and trim(ADDRESS) is not null then 1 end) OK
from raw_inwarranty_leads_tbl r
group by file_nm order by file_nm;
-------------------------------------------------------------------------------------------------------



-------------------------------------------------------------------------------------------------------
---   raw_inwarranty_leads_tbl_new
-------------------------------------------------------------------------------------------------------

select file_nm, ERROR_DESC, count(*) from raw_inwarranty_leads_tbl r group by file_nm, ERROR_DESC order by file_nm, ERROR_DESC;

update raw_inwarranty_leads_tbl_new set error_desc = 'ZIPCODE has invalid data' where ZIPCODE like '%.%';
--23670
commit;

select * from (select * from raw_inwarranty_leads_tbl r where ZIPCODE like '%.%' order by dbms_random.random);

select * from raw_inwarranty_leads_tbl where FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null
order by dbms_random.random;
--1256
delete from raw_inwarranty_leads_tbl_new where FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null;
--1256
commit;

select * from (select * from raw_inwarranty_leads_tbl r order by dbms_random.random) where BRAND like '%/%';
select * from (select * from raw_inwarranty_leads_tbl r order by dbms_random.random) where MODEL_NUMBER like '%.%';
update raw_inwarranty_leads_tbl_new set error_desc = 'MODEL_NUMBER has invalid data' where MODEL_NUMBER like '%.%';
--1
update raw_inwarranty_leads_tbl_new set error_desc = 'MODEL_NUMBER has invalid data' where ERROR_DESC is null and BRAND like '%/%';
--1 row
commit;


select * from (select * from raw_inwarranty_leads_tbl_new r where error_desc is null order by dbms_random.random);


select BRAND, MODEL_NO, count(*)
  from (
        select BRAND,
               case when MODEL_NUMBER like '%/%' then substr(MODEL_NUMBER,1,instr(MODEL_NUMBER,'/') -1)
                    when MODEL_NUMBER like '%(%' then substr(MODEL_NUMBER,1,instr(MODEL_NUMBER,'(') -1)
                    else MODEL_NUMBER end AS MODEL_NO
        from raw_inwarranty_leads_tbl
        where ERROR_DESC is null)
 where MODEL_NO not in (select pd.model_no from bosh.PRODUCT_DIM pd where pd.model_no is not null)
group by BRAND, MODEL_NO
order by BRAND, MODEL_NO;


UPDATE raw_inwarranty_leads_tbl_new
 set FD = ltrim(FD, '0')
WHERE length(FD) > 4 and  length(ltrim(FD, '0')) = 4;
--4729
commit;

select length(FD), count(*) from raw_inwarranty_leads_tbl r where ERROR_DESC is null group by length(FD) order by length(FD);
/*
LENGTH(FD),COUNT(*)
1,8029
2,6833
3,27126
4,8216
6,1731
 */

select * from (select * from raw_inwarranty_leads_tbl_new r where error_desc is null and length(FD) <> 4 order by dbms_random.random);
------------------------------------------------------------------------------------------------------------------------

select FILE_NM, length(FD), count(*) from raw_inwarranty_leads_tbl_new r where ERROR_DESC is null
 group by FILE_NM, length(FD) order by length(FD);



select file_nm, count(*) as total,
       count(case when ERROR_DESC = 'ZIPCODE has invalid data' then 1 end) zipcode_error,
       count(case when length(FD) <> 4 then 1 end) fd_length,
       count(case when trim(ADDRESS) is null and ERROR_DESC is null then 1 end) address_missing,
       count(case when ERROR_DESC is null and length(FD) = 4 and trim(ADDRESS) is not null then 1 end) OK
from raw_inwarranty_leads_tbl_new r
group by file_nm order by file_nm;