delete
from raw_inwarranty_leads_tbl where
      MODEL_NUMBER is null and ACCOUNT_ID is null and
      RIS_NR is null  and FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null;--6,377

rollback;


select COUNT(FILE_NM) from raw_inwarranty_leads_tbl where
      MODEL_NUMBER is null and ACCOUNT_ID is null and
      RIS_NR is null  and FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null
;

select FILE_NM,COUNT(FILE_NM) from raw_inwarranty_leads_tbl where
      MODEL_NUMBER is null and ACCOUNT_ID is null and
      RIS_NR is null  and FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null
Group by FILE_NM;--6,377

+---------------------------------+--------------+
|FILE_NM                          |COUNT(FILE_NM)|
+---------------------------------+--------------+
|bsh_after_cdb_iw_asp_20230601.txt|8685          |
|bsh_after_cdb_iw_asp_20230501.txt|2778          |
+---------------------------------+--------------+



select FILE_NM,COUNT(FILE_NM)
from RAW_INWARRANTY_LEADS_TBL
Group by FILE_NM
;--26000
+---------------------------------+--------------+
|FILE_NM                          |COUNT(FILE_NM)|
+---------------------------------+--------------+
|bsh_after_cdb_iw_asp_20230601.txt|13066         |
|bsh_after_cdb_iw_asp_20230501.txt|12934         |
+---------------------------------+--------------+


select COUNT(*) from raw_inwarranty_leads_tbl where
  MODEL_NUMBER is null and ACCOUNT_ID is null and
  RIS_NR is null  and FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null order by DBMS_RANDOM.RANDOM(); --0


select * from raw_inwarranty_leads_tbl where
  MODEL_NUMBER is null and ACCOUNT_ID is null and
  RIS_NR is null  and FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null order by DBMS_RANDOM.RANDOM(); --874

select * from raw_inwarranty_leads_tbl where FIRST_NAME is null and ADDRESS is null and MODEL_NUMBER is null and PURCHASE_DATE is null order by DBMS_RANDOM.RANDOM(); --0

select * from raw_inwarranty_leads_tbl;

select * from raw_inwarranty_leads_tbl  where  UPPER(STATE) not in (select UPPER(POSTAL_STATE_CD) from BOSH.postal_state_dim )
and STATE is not null;--2

--# correction 1
          update RAW_INWARRANTY_LEADS_TBL
          set    LOCATION_PHONE = REPLACE(REPLACE(REPLACE(LOCATION_PHONE,' ',''),')',''),'(','')
          where     ltrim(trim(LOCATION_PHONE), '0') is not null;

         update RAW_INWARRANTY_LEADS_TBL
          set    LOCATION_PHONE = REPLACE(REPLACE(REPLACE(LOCATION_PHONE,'-',''),'*',''),'.','')
          where     ltrim(trim(LOCATION_PHONE), '0') is not null;

--# correction 2

        update RAW_INWARRANTY_LEADS_TBL
        set    STATE = (select POSTAL_STATE_CD from BOSH.postal_state_dim where UPPER(POSTAL_STATE_NM) = UPPER(STATE))
        where  UPPER(STATE) in (select UPPER(POSTAL_STATE_NM) from BOSH.postal_state_dim );

select Distinct SUBSTR(FIRST_NAME,0,4)
from RAW_INWARRANTY_LEADS_TBL
    where  FIRST_NAME like '%. %'
and (SUBSTR(FIRST_NAME,3,1) = '.' Or  SUBSTR(FIRST_NAME,4,1) = '.' Or  SUBSTR(FIRST_NAME,5,1) = '.' )
AND UPPER(SUBSTR(FIRST_NAME,0,2)) IN ('MR','DR','MS') ;



select   SUBSTR(FIRST_NAME,0,4), TRIM(Replace(FIRST_NAME,SUBSTR(FIRST_NAME,0,4),'')),FIRST_NAME
from RAW_INWARRANTY_LEADS_TBL
    where  FIRST_NAME like '%. %'
and (SUBSTR(FIRST_NAME,3,1) = '.' Or  SUBSTR(FIRST_NAME,4,1) = '.' Or  SUBSTR(FIRST_NAME,5,1) = '.' )
AND UPPER(SUBSTR(FIRST_NAME,0,2)) IN ('MR','DR','MS') ;

--# correction 3
Update RAW_INWARRANTY_LEADS_TBL
SET FIRST_NAME = TRIM(Replace(FIRST_NAME,SUBSTR(FIRST_NAME,0,4),''))
    where  FIRST_NAME like '%. %'
and (SUBSTR(FIRST_NAME,3,1) = '.' Or  SUBSTR(FIRST_NAME,4,1) = '.' Or  SUBSTR(FIRST_NAME,5,1) = '.' )
AND UPPER(SUBSTR(FIRST_NAME,0,2)) IN ('MR','DR','MS') ;
--COMMIT;

--# correction 4
Update RAW_INWARRANTY_LEADS_TBL
SET CLAIM_REPAIR_DATE = to_char((TO_DATE(nvl(CLAIM_REPAIR_DATE, '01/01/1900'),'MM/DD/YYYY')),'MM/DD/YYYY')
where CLAIM_REPAIR_DATE is not null ;
-- COMMIT;

--#correction 5
Update RAW_INWARRANTY_LEADS_TBL
SET      PURCHASE_DATE = to_char((TO_DATE(nvl(PURCHASE_DATE, '01/01/1900'),'MM/DD/YYYY')),'MM/DD/YYYY')
where PURCHASE_DATE  not like '%#%'
and PURCHASE_DATE not like '000000000000%'
AND PURCHASE_DATE is not null  ;
-- ;
COMMIT;

--#correction 6
update RAW_INWARRANTY_LEADS_TBL
SET APPLIANCE_TYPE = TRIM(substr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),instr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),'-')+1)) ;
COMMIT;

select * from RAW_INWARRANTY_LEADS_TBL;

--#correction 7
update RAW_INWARRANTY_LEADS_TBL
SET MODEL_NUMBER = TRIM(substr(MODEL_NUMBER, 1, instr(MODEL_NUMBER, '-') - 1)) ;
-- COMMIT;


select a.BRAND,COUNT(*)  from  BOSH.RAW_INWARRANTY_LEADS_TBL a
    join AUDIT_TBL AT on a.INSERT_AUDIT_KEY = at.AUDIT_KEY
--where at.CREATION_DT > sysdate - 2
Group by a.BRAND;

select * from  BOSH.RAW_INWARRANTY_LEADS_TBL where BRAND not in ('BOSCH','THERMADOR','GAGGENAU') and error_desc is null;

Update  BOSH.RAW_INWARRANTY_LEADS_TBL
SET ERROR_DESC = 'bad/unexpected brand'
where UPPER(BRAND) not in ('BOSCH','THERMADOR','GAGGENAU') and error_desc is null;
COMMIT;

 SQL%ROWCOUNT
--
--         commenting this as new file have different type data this is pre executed as one file have mix case
--         #correction 6 Fetch APPLIANCE_TYPE value from Model_number
        update RAW_INWARRANTY_LEADS_TBL
        SET APPLIANCE_TYPE = TRIM(substr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),instr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),'-')+1))
        where   ERROR_DESC is null and MODEL_NUMBER like '%-%';
        COMMIT;


        --#correction 7 Fetch MODEL_NUMBER value from combined value of MODEL_NUMBER
        update RAW_INWARRANTY_LEADS_TBL
        SET MODEL_NUMBER = TRIM(substr(MODEL_NUMBER, 1, instr(MODEL_NUMBER, '-') - 1))
        where   ERROR_DESC is null and MODEL_NUMBER like '%-%';;
        COMMIT;

--         #correction 6 Fetch APPLIANCE_TYPE value from Model_number
        update RAW_INWARRANTY_LEADS_TBL
        SET APPLIANCE_TYPE = TRIM(substr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '?') + 1),instr(substr(MODEL_NUMBER, instr(MODEL_NUMBER, '-') + 1),'?')+1))
        where   ERROR_DESC is null and MODEL_NUMBER like '%?%';
        COMMIT;


        --#correction 7 Fetch MODEL_NUMBER value from combined value of MODEL_NUMBER
        update RAW_INWARRANTY_LEADS_TBL
        SET MODEL_NUMBER = TRIM(substr(MODEL_NUMBER, 1, instr(MODEL_NUMBER, '?') - 1))
        where   ERROR_DESC is null and MODEL_NUMBER like '%?%';;
        COMMIT;


-- select * from RAW_INWARRANTY_LEADS_TBL where STATE is null;--1640

Select COUNT(*) From RAW_INWARRANTY_LEADS_TBL
where  UPPER(STATE) in (select UPPER(POSTAL_STATE_CD) from BOSH.postal_state_dim );--13143



Select * From RAW_INWARRANTY_LEADS_TBL
where  UPPER(STATE) not in (select UPPER(POSTAL_STATE_CD) from BOSH.postal_state_dim );--2


select UPPER(POSTAL_STATE_NM),POSTAL_STATE_CD from BOSH.postal_state_dim;

select  Distinct UPPER(STATE) from RAW_INWARRANTY_LEADS_TBL;





select * from BOSH.RAW_INWARRANTY_LEADS_TBL where LOCATION_PHONE like '%-%' order by INSERT_AUDIT_KEY desc;

select COUNT(*) from BOSH.RAW_INWARRANTY_LEADS_TBL where LOCATION_PHONE like '%-%';--235

select * from RAW_INWARRANTY_LEADS_TBL where LOCATION_PHONE like '%-%';

select COUNT(*) from RAW_INWARRANTY_LEADS_TBL where LOCATION_PHONE like '%-%';--235

--#correction 5

+16232621277

select distinct BRAND  from RAW_INWARRANTY_LEADS_TBL;
select distinct  MODEL_NUMBER  from RAW_INWARRANTY_LEADS_TBL;
select distinct  APPLIANCE_TYPE from RAW_INWARRANTY_LEADS_TBL;

select * from RAW_INWARRANTY_LEADS_TBL where FIRST_NAME like '%FAIRFIELD%';

-- delete from COMMON_LOAD_HOLD_TBL ;

BEGIN PK_RAW_LEADS.s_005_load_common_hold; END;


Select * from COMMON_LOAD_HOLD_TBL where PHONE_NO like '%-%';--13068



Select COUNT(*) from COMMON_LOAD_HOLD_TBL;--10797
Select COUNT(*) from COMMON_LOAD_TBL;--10797

select COUNT(*) from ADDRESS_OUTPUT_TBL;--10797
select COUNT(*) from SI_OUTPUT_TBL;--10797
select COUNT(*) from CUSTOMER_OUTPUT_TBL;--10797
select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--0


select COUNT(*) from visitor_dim;--11094
select COUNT(*) from visitor_lkp;--6206
select COUNT(*) from visitor_history_tbl;--11738
select COUNT(*) from address_dim;--11002
select COUNT(*) from address_lkp;--11796
select COUNT(*) from visitor_address_xref;--11382
select COUNT(*) from visitor_address_lkp;--6364
select COUNT(*) from serialized_item_dim;--12242
select COUNT(*) from serialized_item_lkp;--9113
select COUNT(*) from visitor_ownership_xref;--12253


select COUNT(*) from email_lkp;--5424
select COUNT(*) from email_dim;--7140
select COUNT(*) from visitor_email_xref;--7364
select COUNT(*) from visitor_email_lkp;--2798
select COUNT(*) from phone_dim;--9174
select COUNT(*) from phone_lkp;--8640
select COUNT(*) from visitor_phone_xref;--9499
 select COUNT(*) from VISITOR_PREFERENCE_TBL;--27676
select COUNT(*) from VISITOR_PURL_XREF;--5869
select COUNT(*) from CUSTOMER_DIM;--10919
select COUNT(*) from HOUSEHOLD_LKP;--0
select COUNT(*) from CUSTOMER_LKP;--5505

select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--0

select * from p_raw_inwarranty_leads_tbl where unique_seq_no is not NULL order by INSERT_AUDIT_KEY desc;

-- update serialized_item_ext_dim
-- set source = 'INWARRANTY';

select source, count(*) from serialized_item_ext_dim group by source;

select * from serialized_item_ext_dim;


select latest_coverage_type, name, count(*), max(registration_dt)
  from P_serialized_item_dim si left join P_latest_coverage_type_dim on coverage_type_key = latest_coverage_type
 group by latest_coverage_type, name
 order by 1;
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2292257 |2107-10-01          |
|2                   |Extended WARRANTY              |78793   |2023-03-07 19:36:38 |
|3                   |Cancelled WARRANTY             |1377    |2023-03-06 17:24:14 |
|6                   |Data Issues                    |25474   |2023-01-19 14:41:07 |
|20                  |Data Errors                    |2       |2020-04-30 20:03:48 |
|21                  |Gaggenau Ambassador Suppression|465     |2022-09-30          |
|22                  |Duplicate data                 |99161   |2023-03-07 21:05:32 |
|23                  |Gaggenau DNS List              |1928    |2022-12-10          |
|50                  |Temp Builder Suppression       |15009   |2022-01-12 18:57:08 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
+--------------------+-------------------------------+--------+--------------------+

--after merge

+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2303819 |2107-10-01          |
|2                   |Extended WARRANTY              |78793   |2023-03-07 19:36:38 |
|3                   |Cancelled WARRANTY             |1377    |2023-03-06 17:24:14 |
|6                   |Data Issues                    |25474   |2023-01-19 14:41:07 |
|20                  |Data Errors                    |2       |2020-04-30 20:03:48 |
|21                  |Gaggenau Ambassador Suppression|465     |2022-09-30          |
|22                  |Duplicate data                 |99161   |2023-03-07 21:05:32 |
|23                  |Gaggenau DNS List              |1928    |2022-12-10          |
|50                  |Temp Builder Suppression       |15009   |2022-01-12 18:57:08 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
+--------------------+-------------------------------+--------+--------------------+
