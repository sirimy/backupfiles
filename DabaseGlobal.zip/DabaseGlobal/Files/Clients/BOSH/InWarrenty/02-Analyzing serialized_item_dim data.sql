
select * from (select * from serialized_item_dim  order by dbms_random.random ) where rownum <= 20 ;
select * from serialized_item_dim where LATEST_COVERAGE_TYPE <> 1;

select count(*) from serialized_item_dim
union all
select count(*) from serialized_item_dim where si_key IN (select si.si_key from bosh.serialized_item_dim si )
union all
select count(*) from serialized_item_dim where si_key NOT IN (select si.si_key from bosh.serialized_item_dim si );
--11564     --total leads in stg
--  706     --leads, which exist in core already
--10858     --new leads

+--------+
|COUNT(*)|
+--------+
|12242   |--total leads in stg
|3129    |--leads, which exist in core already
|9113    |--new leads
+--------+

+--------+
|COUNT(*)|
+--------+
|12009   |--total leads in stg
|3075    |--leads, which exist in core already
|8934    |--new leads
+--------+


select  SOURCE,COUNT(SOURCE) from serialized_item_ext_dim group BY SOURCE;

select  distinct SOURCE from bosh.serialized_item_ext_dim;
select  distinct registration_dt from serialized_item_dim;



select  -- s.latest_coverage_type , c.latest_coverage_type
    count(*)
  from serialized_item_dim s
       join bosh.serialized_item_dim c
          on c.si_key = s.si_key
       left join serialized_item_ext_dim      sx  on sx.si_key = s.si_key
       left join bosh.serialized_item_ext_dim cx  on cx.si_key = c.si_key
 where (
       1=2
     or s.purchase_dt_key <> c.purchase_dt_key  --0
     or nvl(s.product_key, 1) <> nvl(c.product_key, 1)   --0
     or s.warranty_expiration_dt <> c.warranty_expiration_dt --0
     or s.registration_dt <> c.registration_dt               --0
      or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --0
      or s.latest_coverage_type <> c.latest_coverage_type     --0
     or nvl(sx.duplicate_ind, 'N') <> nvl(cx.duplicate_ind, 'N')  --0
        or sx.source <> cx.source                                 --0
    )  ;

--From existing leads, checking how many are showing up with change in critical columns 
--Very few are showing change in imp columns, which is good
select -- sx.registration_dt,cx.registration_dt,cx.registration_dt - sx.registration_dt
    --count(*)
    sx.source , cx.source
  from serialized_item_dim s
       join bosh.serialized_item_dim c
          on c.si_key = s.si_key 
       left join serialized_item_ext_dim      sx  on sx.si_key = s.si_key
       left join bosh.serialized_item_ext_dim cx  on cx.si_key = c.si_key
 where (
       1=2
--     or s.purchase_dt_key <> c.purchase_dt_key  --0
  --   or nvl(s.product_key, 1) <> nvl(c.product_key, 1)   --0
 --    or s.warranty_expiration_dt <> c.warranty_expiration_dt --0
  --   or s.registration_dt <> c.registration_dt               --914
 --    or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --65
   --    or s.latest_coverage_type <> c.latest_coverage_type     --247
   or nvl(sx.duplicate_ind, 'N') <> nvl(cx.duplicate_ind, 'N')  --194
        or sx.source <> cx.source                                 --924
    ) and cx.registration_dt - sx.registration_dt > 14 and c.latest_coverage_type in (2,3);
--924 when compared on all the above columns together excluding duplicate_ind
--total 924 including diff in duplicate_ind


select tgt.insert_audit_key      , src.insert_audit_key,
                    tgt.DUPLICATE_IND ,src.DUPLICATE_IND,
                    tgt.SOURCE        ,src.SOURCE,
                    tgt.REGISTRATION_DT , src.REGISTRATION_DT
from serialized_item_ext_dim tgt join
     (
         select * from bosh.serialized_item_ext_dim src
                       where    si_key IN (
                                     select posted_serial_item_key
                                       from
                                            si_output_tbl ar
                                            join bosh.raw_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
                                            --join audit_tbl a on (audit_key = si.insert_audit_key)
                                      where 1=1
                                        and (lower(r.file_nm) like '%%catchup%%' or lower(r.file_nm) like '%%iw_asp%%')
                                     )
    ) src
                      on (src.si_key = tgt.si_key);

select * from serialized_item_ext_dim;

select * from bosh.serialized_item_ext_dim src
           where    si_key IN (
                         select posted_serial_item_key
                           from
                                si_output_tbl ar
                                join bosh.raw_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
                                --join audit_tbl a on (audit_key = si.insert_audit_key)
                          where 1=1
                            and (lower(r.file_nm) like '%%catchup%%' or lower(r.file_nm) like '%%iw_asp%%')
                         );



select posted_serial_item_key
   from si_output_tbl ar join bosh.raw_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
  where 1=1  and (lower(r.file_nm) like '%%catchup%%' or lower(r.file_nm) like '%%iw_asp%%');




select distinct INSERT_AUDIT_KEY from serialized_item_ext_dim;
select * from AUDIT_TBL where AUDIT_KEY =679140;

 merge into serialized_item_ext_dim tgt
                using (
                       select * from bosh.serialized_item_ext_dim src
                       where    si_key IN (
                                     select posted_serial_item_key
                                       from
                                            si_output_tbl ar
                                            join bosh.raw_leads_tbl r on r.unique_seq_no = ar.unique_seq_no
                                            --join audit_tbl a on (audit_key = si.insert_audit_key)
                                      where 1=1
                                        and (lower(r.file_nm) like '%%catchup%%' or lower(r.file_nm) like '%%iw_asp%%')
                                     )

                      ) src
                      on (src.si_key = tgt.si_key)
                when matched then
                update
                set tgt.insert_audit_key        = src.insert_audit_key,
                    tgt.DUPLICATE_IND = src.DUPLICATE_IND,
                    tgt.SOURCE        = src.SOURCE,
                    tgt.REGISTRATION_DT = src.REGISTRATION_DT
                ;


--Comparing diff in data between stg and core
--Main diff is in registration_dt but difficult to say, which one is correct.   
select s.warranty_expiration_dt, c.warranty_expiration_dt, s.registration_dt, trunc(c.registration_dt)
       ,s.latest_coverage_exp_dt, c.latest_coverage_exp_dt
       ,s.latest_coverage_type, c.latest_coverage_type
  from serialized_item_dim s
       join bosh.serialized_item_dim c
          on c.si_key = s.si_key 
 where (1=2
--     or s.purchase_dt_key <> c.purchase_dt_key  --0
--     or s.product_key <> c.product_key   --0
--     or s.warranty_expiration_dt <> c.warranty_expiration_dt --
--     or s.registration_dt <> c.registration_dt               --
--     or s.latest_coverage_exp_dt <> c.latest_coverage_exp_dt --
    or s.latest_coverage_type <> c.latest_coverage_type     --
    );    
    


 
select * from (select * from serialized_item_ext_dim  order by dbms_random.random ) where rownum <= 20 ;

select source, count(*) from serialized_item_ext_dim group by source;
/*SOURCE    COUNT(*)
INWARRANTY	11564
*/
-- SOURCE,COUNT(*)
-- INWARRANTY,12635

--Count of new leads     
select count(*), count(distinct si.si_key) --si.si_key, r.*
  from  
       serialized_item_dim si 
       join si_output_tbl ar on si.si_key = posted_serial_item_key
       join P_RAW_INWARRANTY_LEADS_TBL r on r.unique_seq_no = ar.unique_seq_no
       --join audit_tbl a on (audit_key = si.insert_audit_key)
       left join bosh.serialized_item_dim sic on sic.si_key = si.si_key  
 where 1=1
   and sic.si_key is null
--   and r.file_nm in ('bsh_after_cdb_asp_20200407_hist.txt', 'bsh_after_cdb_asp_hc_20200407_hist.txt')
--   and r.error_desc is null 
   ;
-- +--------+---------------------------------------+
-- |COUNT(*)|COUNT(DISTINCTSI.SI_KEY)--SI.SI_KEY,R.*|
-- +--------+---------------------------------------+
-- |8796    |8402                                   |
-- +--------+---------------------------------------+


-- COUNT(*),"COUNT(DISTINCTSI.SI_KEY)--SI.SI_KEY,R.*"
-- 11879,11357



-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
    --Updating serial data
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

--set insert_audit_key from core for existing records
merge into serialized_item_dim tgt
using (
       select * from bosh.serialized_item_dim src 
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set tgt.insert_audit_key        = src.insert_audit_key
where tgt.insert_audit_key      <> src.insert_audit_key;
--706

--update serialized_item_dim to match with core (for existing records) 
merge into serialized_item_dim tgt
using (
       select * from bosh.serialized_item_dim src 
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set
    tgt.purchase_dt_key         = src.purchase_dt_key,
    tgt.product_key             = src.product_key,
    tgt.MODEL_NO                = src.MODEL_NO,
    tgt.warranty_expiration_dt  = src.warranty_expiration_dt,
    tgt.registration_dt         = src.registration_dt,
    tgt.latest_coverage_exp_dt  = src.latest_coverage_exp_dt, 
    tgt.latest_coverage_type    = src.latest_coverage_type
where (
       1=2
    or src.purchase_dt_key          <> tgt.purchase_dt_key  --0
    or src.product_key              <> tgt.product_key   --0
    or src.warranty_expiration_dt   <> tgt.warranty_expiration_dt --1
    or src.registration_dt          <> tgt.registration_dt               --666
    or src.latest_coverage_exp_dt   <> tgt.latest_coverage_exp_dt --814
    or src.latest_coverage_type     <> tgt.latest_coverage_type     --813
    );    
--706 rows
commit;    


select insert_audit_key, creation_dt, update_audit_key, count(*)
from serialized_item_dim si left join audit_tbl on audit_key = insert_audit_key
group by insert_audit_key, creation_dt, update_audit_key
order by insert_audit_key desc, update_audit_key;

select * from serialized_item_dim;

-----------------------------------------------------------
-----------------------------------------------------------
--  Updating serialized_item_ext_dim
-----------------------------------------------------------
-----------------------------------------------------------
merge into serialized_item_ext_dim tgt
using (
       select * from bosh.serialized_item_ext_dim src 
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set
    tgt.insert_audit_key  = src.insert_audit_key,
    tgt.DUPLICATE_IND     = src.DUPLICATE_IND,
    tgt.SOURCE            = src.SOURCE,
    tgt.REGISTRATION_DT   = src.REGISTRATION_DT
;
--127 rows
--755 rows affected in 2 s 487 ms
commit;


select tgt.MANUFACTURING_DATE_FD, src.MANUFACTURING_DATE_FD, tgt.CONSECUTIVE_NUMBER, src.CONSECUTIVE_NUMBER
  from bosh.serialized_item_ext_dim src join serialized_item_ext_dim tgt on tgt.SI_KEY = src.SI_KEY
 where  src.MANUFACTURING_DATE_FD is not null and src.CONSECUTIVE_NUMBER is not null
   and  (nvl(tgt.MANUFACTURING_DATE_FD, '0000')  <> nvl(src.MANUFACTURING_DATE_FD, 0000)
         or nvl(tgt.CONSECUTIVE_NUMBER, '0000') <> src.CONSECUTIVE_NUMBER
        );
--113 rows

merge into serialized_item_ext_dim tgt
using (
       select * from bosh.serialized_item_ext_dim src
       where  src.MANUFACTURING_DATE_FD is not null and src.CONSECUTIVE_NUMBER is not null
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set
    tgt.MANUFACTURING_DATE_FD   = src.MANUFACTURING_DATE_FD,
    tgt.CONSECUTIVE_NUMBER      = src.CONSECUTIVE_NUMBER
where
      nvl(tgt.MANUFACTURING_DATE_FD, '-1234')  <> src.MANUFACTURING_DATE_FD
      or nvl(tgt.CONSECUTIVE_NUMBER, '-1234') <> src.CONSECUTIVE_NUMBER
;
--113
--640 rows affected in 395 ms
commit;

select * from serialized_item_ext_dim;

select SOURCE, count(*)  from serialized_item_ext_dim si group by SOURCE;
/*
HOME CONNECT	76
CDB - CATCHUP	17
CDB	613
INWARRANTY	10858
*/
-----------------------------------------------------------

+-------------+--------+
|SOURCE       |COUNT(*)|
+-------------+--------+
|HOME CONNECT |324     |
|CDB - CATCHUP|701     |
|COSMOS       |1       |
|CDB          |2074    |
|INWARRANTY   |41025   |
+-------------+--------+


-----------------------------------------------------------
--  Serialized_item_lkp
-----------------------------------------------------------
select * from serialized_item_lkp order by DBMS_RANDOM.RANDOM();

select * from p_serialized_item_lkp;

select count(*) from serialized_item_lkp where SI_XID in (
        select c.SI_XID from bosh.serialized_item_lkp c where c.SOURCE_SYSTEM_CD = 0);
-----------------------------------------------------------
