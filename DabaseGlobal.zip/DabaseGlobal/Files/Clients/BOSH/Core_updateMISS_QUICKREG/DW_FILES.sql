select ATB.CREATION_DT,COUNT(distinct REFERENCE_ID) from BOSH.CAMPAIGN_SPOOL_FILE_TBL QFX JOIN AUDIT_TBL ATB
on ATB.AUDIT_KEY = QFX.INSERT_AUDIT_KEY
GROUP BY ATB.CREATION_DT
Order by ATB.CREATION_DT desc;
-- +--------------------------+---------------------------+
-- |CREATION_DT               |COUNT(DISTINCTREFERENCE_ID)|
-- +--------------------------+---------------------------+
-- |2025-09-26 13:26:27.000000|156398                     |
-- |2025-08-19 09:30:43.000000|562910                     |
-- |2025-08-05 23:14:52.000000|166853                     |
-- +--------------------------+---------------------------+

select sysdate from dual;

select COUNT(distinct spl.QUICKREG_CODE) from bosh.CAMPAIGN_SPOOL_FILE_TBL spl
     where QUICKREG_CODE in (select spl.QUICKREG_CODE from bosh.CAMPAIGN_SPOOL_FILE_TBL spl)
            and QUICKREG_CODE not in (select oqx.QUICKREG_CODE from bosh.OFFER_QUICKREG_XREF oqx);-- 156398


select COUNT(*) from OFFER_QUICKREG_XREF;--154303

select DISTINCT SOURCE_TABLE_NAME,SOURCE_SYSTEM_NAME from bosh.SYNC_PROCESS_MAPPING_TBL where UPPER(TARGET_TABLE_NAME) in (
                            'OFFER_QUICKREG_XREF'
    )
ORDER BY SOURCE_SYSTEM_NAME;
-- +---------------------+------------------+
-- |SOURCE_TABLE_NAME    |SOURCE_SYSTEM_NAME|
-- +---------------------+------------------+
-- |V_SYNC_OFFER_QUICKREG|BOSH              |
-- +---------------------+------------------+
select * from bosh.SYNC_PROCESS_MAPPING_TBL where UPPER(TARGET_TABLE_NAME) in (
                            'OFFER_QUICKREG_XREF'
    )
ORDER BY SOURCE_SYSTEM_NAME;

-- create table OFFER_QUICKREG_XREF_BACKUP_OCT_2025 as
--     (
--         select * from OFFER_QUICKREG_XREF
--     );
--delete from OFFER_QUICKREG_XREF;
COMMIT;




DECLARE
        v_audit_key_cd INTEGER := get_audit_key ( p_program_nm => 'Manual insert', p_DESCRIPTIVE_TX => 'Manually adding September 2025 OFFER_QUICKREG_XREF', p_author_nm => 'iahmad',p_table_nm => 'OFFER_QUICKREG_XREF');
BEGIN

        insert into OFFER_QUICKREG_XREF (OFFER_KEY, QUICKREG_CODE, INSERT_AUDIT_KEY)
        select distinct spl.REFERENCE_ID as offer_key, spl.QUICKREG_CODE,v_audit_key_cd from bosh.CAMPAIGN_SPOOL_FILE_TBL spl
         where QUICKREG_CODE in (select spl.QUICKREG_CODE from bosh.CAMPAIGN_SPOOL_FILE_TBL spl)
            and QUICKREG_CODE not in (select oqx.QUICKREG_CODE from bosh.OFFER_QUICKREG_XREF oqx);

          DBMS_OUTPUT.PUT_LINE('OFFER_QUICKREG_XREF');
       DBMS_OUTPUT.PUT_LINE(v_audit_key_cd);
       DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
       COMMIT;

END;
-- OFFER_QUICKREG_XREF
-- 1021432
-- 156398


select * from V_QUICKREG_EXTRACT;

  select COUNT(*) from OFFER_QUICKREG_XREF;--156398
-- Logs check
-- this table not in sync job
-- Sync using table to reach data in web
-- then we merge in offer table this QUICKREG_CODE values in
-- Then offer need to check which are in issue all brands
-- also need to check in email link if it allow to open
-- QC in this campaign we will check bundle key is present in all main tables
-- Logs check


select * from BOSH.GUARD_CONDITION_TBL where UPPER(SQL_TX) like '%BUNDLE_SUMMARY%';

select bundle_key from v_sm_score_transition2 where score <= 0;

select COUNT(distinct BUNDLE_KEY) from bundle_summary_tbl;-- 77167
select COUNT(distinct BUNDLE_KEY) from BUNDLE_DIM T1 join BOSH.CRITERIA_DIM t2 on t1.CRITERIA_KEY = t2.CRITERIA_KEY
where SCORING_FILE_CD IS NOT NULL
;-- 77172



select * from BOSH.V_SYNC_OFFER_QUICKREG
    where LAST_UPDATED_TS =  TO_DATE('2025-09-26 13:14:56', 'yyyy-mm-dd HH24:MI:SS');
--156396


select LAST_UPDATED_TS,COUNT(*) from BOSH.V_SYNC_OFFER_QUICKREG
group by LAST_UPDATED_TS
--having COUNT(*) > 100
order by LAST_UPDATED_TS DESC ;
-- +--------------------------+--------+
-- |LAST_UPDATED_TS           |COUNT(*)|
-- +--------------------------+--------+
-- |2025-09-26 13:14:56.000000|156396  |
-- |2025-08-19 08:40:35.000000|562893  |
-- |2025-08-05 22:39:27.000000|166832  |
-- |2025-06-26 02:45:38.000000|153971  |
-- +--------------------------+--------+

+--------------------------+--------+
|LAST_UPDATED_TS           |COUNT(*)|
+--------------------------+--------+
|2025-09-26 13:14:56.000000|156396  |
+--------------------------+--------+





select * from V_SYNC_OFFER_XREF;