
Select offer_tbl.offer_id,offer_tbl.new_offer_id,t2.quickreg_code,offer_tbl.last_updated_ts
from offer_tbl  inner join bosh_v_sync_offer_quickreg t2 on
    offer_tbl.offer_id = CAST (t2.offer_key AS numeric)
    where COALESCE(offer_tbl.new_offer_id,'') = '' ;


Select count(offer_tbl.offer_id)  from offer_tbl  inner join bosh_v_sync_offer_quickreg on
        offer_tbl.offer_id = CAST (bosh_v_sync_offer_quickreg.offer_key AS numeric)
        where COALESCE(offer_tbl.new_offer_id,'') = ''  ;
-- 156306

with t as (
    Select offer_tbl.offer_id AS id,bosh_v_sync_offer_quickreg.quickreg_code from offer_tbl  inner join bosh_v_sync_offer_quickreg on
        offer_tbl.offer_id = CAST (bosh_v_sync_offer_quickreg.offer_key AS numeric)
        where COALESCE(offer_tbl.new_offer_id,'') = ''
)
update offer_tbl
    set new_offer_id = t.quickreg_code,last_updated_ts = now(),last_updated_by = 'BOSH-1971'
from t
where offer_id = t.id;
-- [2025-10-30 17:01:40] 156,306 rows affected in 1 m 59 s 457 ms
commit;