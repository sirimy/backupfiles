
SELECT OFFER_ID,
          CUSTOMER_ID,
          OFFER_EXP_DT,
          DISCOUNT1_AMT,
          DISCOUNT1_PCT,
          DISCOUNT2_AMT,
          DISCOUNT2_PCT,
          ACTIVE_IND,
          DISPLAY_SEQ_NUM,
          last_updated_ts,
          rn,
          SOURCE_SYSTEM_CD,
          BUNDLE_IND,
          OFFER_START_DT AS OFFER_START_UTC_TS,
          OFFER_EXP_DT AS OFFER_EXP_UTC_TS,

          QUICKREG_CODE
     FROM (SELECT /*+ use_hash (off, cd, vlkp, vlkp1)     */
                 DISTINCT
                  off.OFFER_KEY as OFFER_ID,
                  vlkp.VISITOR_XID AS CUSTOMER_ID,
                  OFFER_EXP_DT,
                  NULL DISCOUNT1_AMT,
                  NULL DISCOUNT1_PCT,
                  NULL DISCOUNT2_AMT,
                  NULL DISCOUNT2_PCT,
                  CASE WHEN OFFER_EXP_DT < TRUNC(SYSDATE) THEN 'N' ELSE 'Y' END AS ACTIVE_IND,
                  1 AS DISPLAY_SEQ_NUM,
                  aud.CREATION_DT AS last_updated_ts,
                  vlkp.SOURCE_SYSTEM_CD,
                  DECODE (bundle.OFFER_KEY, NULL, 'N', 'Y') AS BUNDLE_IND,
                  OFFER_START_DT,
                  ROW_NUMBER ()
                  OVER (PARTITION BY off.OFFER_KEY
                        ORDER BY OFFER_EXP_DT DESC)
                     rn,
                  oqf.QUICKREG_CODE
             FROM (
             SELECT vlkp.visitor_xid,
                          vlkp.source_system_cd,
                          vlkp.INSERT_AUDIT_KEY,
                          vlkp.UPDATE_AUDIT_KEY
                     FROM visitor_lkp vlkp
                    WHERE VLKP.EXT_ID_TYPE_CD = 1 ) vlkp
                  JOIN CUSTOMER_DIM cd
                     ON (vlkp.visitor_xid = TO_CHAR (cd.CUSTOMER_KEY)  )
                  JOIN campaign_participation_fct CP
                     ON (CD.CUSTOMER_KEY = CP.CUSTOMER_KEY)
                  JOIN OFFER_XREF off ON (CP.OFFER_KEY = off.OFFER_KEY)
                  LEFT JOIN
                  (SELECT DISTINCT OFFER_KEY
                     FROM (SELECT COUNT (DISTINCT si_key)
                                     OVER (PARTITION BY OFFER_KEY)
                                     AS bundle_cnt,
                                  OFFER_KEY
                             FROM OFFER_ITEM_XREF)
                    WHERE bundle_cnt > 1  ) bundle
                     ON (off.OFFER_KEY = bundle.OFFER_KEY)
                 LEFT JOIN OFFER_QUICKREG_XREF oqf on (CP.OFFER_KEY = oqf.OFFER_KEY)
                  JOIN
                  audit_tbl aud
                     ON (NVL (
                            off.SYNC_AUDIT_KEY,
                            GREATEST (off.insert_audit_key,
                                      NVL (off.update_audit_key, -1))) =
                            aud.audit_key)
            WHERE vlkp.visitor_xid IS NOT NULL AND off.suppression_cd IS NULL)
    WHERE rn = 1 and
          OFFER_ID = '011984880073961' AND
          CUSTOMER_ID =5389916 and SOURCE_SYSTEM_CD = 2;
/
-- +---------------+-----------+------------+-------------+-------------+-------------+-------------+----------+---------------+--------------------------+----------------+----------+------------------+----------------+-------------+
-- |OFFER_ID       |CUSTOMER_ID|OFFER_EXP_DT|DISCOUNT1_AMT|DISCOUNT1_PCT|DISCOUNT2_AMT|DISCOUNT2_PCT|ACTIVE_IND|DISPLAY_SEQ_NUM|LAST_UPDATED_TS           |SOURCE_SYSTEM_CD|BUNDLE_IND|OFFER_START_UTC_TS|OFFER_EXP_UTC_TS|QUICKREG_CODE|
-- +---------------+-----------+------------+-------------+-------------+-------------+-------------+----------+---------------+--------------------------+----------------+----------+------------------+----------------+-------------+
-- |011230808071446|5389916    |2025-04-28  |NULL         |NULL         |NULL         |NULL         |N         |1              |2025-02-21 15:14:37.000000|1               |N         |2025-03-18        |2025-04-28      |BV4JAZT      |
-- |010536522073063|5389916    |2024-10-28  |NULL         |NULL         |NULL         |NULL         |N         |1              |2024-08-30 11:42:06.000000|1               |N         |2024-09-17        |2024-10-28      |B857UQT      |
-- |011230808071554|5389916    |2025-07-17  |NULL         |NULL         |NULL         |NULL         |N         |1              |2025-05-19 13:58:48.000000|1               |N         |2025-06-10        |2025-07-17      |BLWEYSS      |
-- |010536522073119|5389916    |2024-12-09  |NULL         |NULL         |NULL         |NULL         |N         |1              |2024-09-26 09:35:53.000000|1               |N         |2024-10-29        |2024-12-09      |BZ8LCNN      |
-- |011230808071484|5389916    |2025-06-09  |NULL         |NULL         |NULL         |NULL         |N         |1              |2025-04-04 14:59:55.000000|1               |N         |2025-04-29        |2025-06-09      |BQHLDJG      |
-- |011984880073961|5389916    |2025-11-24  |NULL         |NULL         |NULL         |NULL         |Y         |1              |2025-09-23 12:54:37.000000|1               |N         |2025-10-14        |2025-11-24      |BCQ2ZSE      |
-- +---------------+-----------+------------+-------------+-------------+-------------+-------------+----------+---------------+--------------------------+----------------+----------+------------------+----------------+-------------+