Select * from (
    select * from (
    select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from BOSH.RAW_LEADS_TBL RL join AUDIT_TBL AT2 on RL.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
                                 where AT2.CREATION_DT > SYSDATE -2
                                       group by FILE_NM,INSERT_AUDIT_KEY order by INSERT_AUDIT_KEY) A
    UNION
    Select * from (
    select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from BOSH.RAW_INWARRANTY_LEADS_TBL RL join AUDIT_TBL AT2 on RL.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
                                 where AT2.CREATION_DT > SYSDATE -2
                                       group by FILE_NM,INSERT_AUDIT_KEY order by INSERT_AUDIT_KEY) B
   UNION
    Select * from (
    select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from BOSH.RAW_GGN_DNS_TBL RL join AUDIT_TBL AT2 on RL.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
                                 where AT2.CREATION_DT > SYSDATE -2
                                       group by FILE_NM,INSERT_AUDIT_KEY order by INSERT_AUDIT_KEY) C
) C
ORDER BY INSERT_AUDIT_KEY;


select vp.BRAND_NM, count(*)
from BOSH.SERIALIZED_ITEM_DIM  si
    join AUDIT_TBL AT2 on si.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
    join V_PRODUCT vp on vp.PRODUCT_KEY = si.PRODUCT_KEY
where AT2.CREATION_DT > SYSDATE -2
      group by vp.BRAND_NM;