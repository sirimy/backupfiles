select * from RAW_LEADS_TBL where ERROR_DESC is null Order By DBMS_RANDOM.RANDOM();
select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from RAW_LEADS_TBL --where ERROR_DESC is null
--                              where FILE_NM = 'bsh_after_cdb_hc_20240918.txt'
--                                    and UNIQUE_SEQ_NO in (select UNIQUE_SEQ_NO from COMMON_LOAD_HOLD_TBL )
                                           group by FILE_NM,INSERT_AUDIT_KEY order by FILE_NM;
+-----------------------------+----------------+--------+
|FILE_NM                      |INSERT_AUDIT_KEY|COUNT(*)|
+-----------------------------+----------------+--------+
|bsh_after_cdb_hc_20240918.txt|877767          |7909    |
|bsh_after_cdb_hc_20240918.txt|877787          |7915    |
+-----------------------------+----------------+--------+

-- delete from COMMON_LOAD_HOLD_TBL  where UNIQUE_SEQ_NO in(
--     select UNIQUE_SEQ_NO from RAW_LEADS_TBL --where ERROR_DESC is null
--                              where FILE_NM = 'bsh_after_cdb_hc_20240918.txt' and INSERT_AUDIT_KEY =877767
--         );
-- delete from RAW_LEADS_TBL --where ERROR_DESC is null
--                              where FILE_NM = 'bsh_after_cdb_hc_20240918.txt' and INSERT_AUDIT_KEY =877767;


    select  COUNT(*) from COMMON_LOAD_HOLD_TBL  where UNIQUE_SEQ_NO in(
    select UNIQUE_SEQ_NO from RAW_LEADS_TBL --where ERROR_DESC is null
                             where FILE_NM = 'bsh_after_cdb_hc_20240918.txt' and INSERT_AUDIT_KEY =877767
)
;


select FILE_NM,COUNT(*) from COMMON_LOAD_HOLD_TBL   group by FILE_NM order by FILE_NM;

select ERROR_DESC,FILE_NM,COUNT(*) from RAW_LEADS_TBL where ERROR_DESC is not null  --where FILE_NM = 'bsh_after_cdb_20240918.txt'
                                           group by ERROR_DESC ,FILE_NM order by ERROR_DESC;


select * from COMMON_LOAD_HOLD_TBL   Order By DBMS_RANDOM.RANDOM();
select FILE_NM,COUNT(*) from COMMON_LOAD_HOLD_TBL group by FILE_NM order by FILE_NM;
+-----------------------------+--------+
|FILE_NM                      |COUNT(*)|
+-----------------------------+--------+
|bsh_after_cdb_20240911.txt   |1302    |
|bsh_after_cdb_hc_20240911.txt|2249    |
|bsh_after_cdb_hc_20240918.txt|2286    |
|bsh_after_cdb_hc_20240925.txt|2151    |
|bsh_after_cdb_re_20240904.txt|3649    |
|bsh_after_cdb_re_20240911.txt|4148    |
|bsh_after_cdb_re_20240918.txt|4066    |
+-----------------------------+--------+




select distinct ERROR_DESC from RAW_LEADS_TBL where ERROR_DESC is not null ;--

select count(*) from COMMON_LOAD_HOLD_TBL;--29752

select count(*) from COMMON_LOAD_HOLD_TBL order by DBMS_RANDOM.RANDOM();--29752

select count(*) from COMMON_LOAD_TBL;--29752

select count(*) from DS_ACE_OUTPUT_TBL;--29752
select count(*) from ADDRESS_OUTPUT_TBL;--29752
select count(*) from SI_OUTPUT_TBL;--29752
select count(*) from CUSTOMER_OUTPUT_TBL;--29752


select count(*) from visitor_dim;--20738
select count(*) from visitor_lkp;--16967
select count(*) from visitor_history_tbl;--22194
select count(*) from  address_dim;--20690
select count(*) from  address_lkp where SOURCE_SYSTEM_CD = 0;--16863

select count(*) from  serialized_item_dim;--27736
select count(*) from  serialized_item_lkp;--27085
select count(*) from  visitor_ownership_xref;--27740

select count(*) from  CUSTOMER_DIM;--20644

select count(*) from  CUSTOMER_LKP;--16464

select * from  serialized_item_dim;--
select * from  ADDRESS_DIM;--

select SOURCE, count(*)  from serialized_item_ext_dim si group by SOURCE;
+-------------+--------+
|SOURCE       |COUNT(*)|
+-------------+--------+
|HOME CONNECT |7751    |
|CDB          |4687    |
|CDB-REGISTRIA|15298   |
+-------------+--------+

select latest_coverage_type, name, count(*), max(registration_dt)
  from P_serialized_item_dim si left join P_latest_coverage_type_dim on coverage_type_key = latest_coverage_type
 group by latest_coverage_type, name
 order by 1;
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |3004908 |2107-10-01          |
|2                   |Extended WARRANTY              |109066  |2024-10-19 05:22:52 |
|3                   |Cancelled WARRANTY             |2122    |2024-10-11 13:37:48 |
|6                   |Data Issues                    |25477   |2024-09-27 13:39:22 |
|17                  |NULL                           |1       |2024-06-17 17:03:37 |
|20                  |Data Errors                    |13      |2022-12-22          |
|21                  |Gaggenau Ambassador Suppression|769     |2024-06-24          |
|22                  |Duplicate data                 |163855  |2024-10-18 21:15:52 |
|23                  |Gaggenau DNS List              |3865    |2024-08-06          |
|50                  |Temp Builder Suppression       |15009   |2023-03-29 15:13:03 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
|52                  |Inwarranty Builder Suppression |2776    |2023-07-19 16:39:31 |
+--------------------+-------------------------------+--------+--------------------+
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |3030396 |2107-10-01          |
|2                   |Extended WARRANTY              |109063  |2024-10-19 05:22:52 |
|3                   |Cancelled WARRANTY             |2122    |2024-10-11 13:37:48 |
|6                   |Data Issues                    |25477   |2024-09-27 13:39:22 |
|17                  |NULL                           |1       |2024-06-17 17:03:37 |
|20                  |Data Errors                    |13      |2022-12-22          |
|21                  |Gaggenau Ambassador Suppression|769     |2024-09-11          |
|22                  |Duplicate data                 |165455  |2024-10-18 21:15:52 |
|23                  |Gaggenau DNS List              |3865    |2024-09-11          |
|50                  |Temp Builder Suppression       |15009   |2023-03-29 15:13:03 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
|52                  |Inwarranty Builder Suppression |2776    |2023-07-19 16:39:31 |
+--------------------+-------------------------------+--------+--------------------+
