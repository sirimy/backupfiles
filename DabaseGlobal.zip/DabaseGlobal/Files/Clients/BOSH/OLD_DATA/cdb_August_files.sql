select * from RAW_LEADS_TBL where ERROR_DESC is null Order By DBMS_RANDOM.RANDOM();
select FILE_NM,COUNT(*) from RAW_LEADS_TBL group by FILE_NM order by FILE_NM;
+-----------------------------+--------+
|FILE_NM                      |COUNT(*)|
+-----------------------------+--------+
|bsh_after_cdb_20240807.txt   |1729    |
|bsh_after_cdb_20240814.txt   |1502    |
|bsh_after_cdb_20240821.txt   |1429    |
|bsh_after_cdb_20240828.txt   |1232    |
|bsh_after_cdb_hc_20240807.txt|7309    |
|bsh_after_cdb_hc_20240814.txt|7069    |
|bsh_after_cdb_hc_20240821.txt|7007    |
|bsh_after_cdb_hc_20240828.txt|6978    |
|bsh_after_cdb_re_20240807.txt|3581    |
|bsh_after_cdb_re_20240814.txt|4052    |
|bsh_after_cdb_re_20240821.txt|3697    |
|bsh_after_cdb_re_20240828.txt|3526    |
+-----------------------------+--------+
select * from COMMON_LOAD_HOLD_TBL   Order By DBMS_RANDOM.RANDOM();
select FILE_NM,COUNT(*) from COMMON_LOAD_HOLD_TBL group by FILE_NM order by FILE_NM;
+-----------------------------+--------+
|FILE_NM                      |COUNT(*)|
+-----------------------------+--------+
|bsh_after_cdb_20240807.txt   |1727    |
|bsh_after_cdb_20240814.txt   |1499    |
|bsh_after_cdb_20240821.txt   |1427    |
|bsh_after_cdb_20240828.txt   |1232    |
|bsh_after_cdb_hc_20240807.txt|2092    |
|bsh_after_cdb_hc_20240814.txt|2080    |
|bsh_after_cdb_hc_20240821.txt|1951    |
|bsh_after_cdb_hc_20240828.txt|2028    |
|bsh_after_cdb_re_20240807.txt|3579    |
|bsh_after_cdb_re_20240814.txt|4049    |
|bsh_after_cdb_re_20240821.txt|3694    |
|bsh_after_cdb_re_20240828.txt|3523    |
+-----------------------------+--------+


select distinct ERROR_DESC from RAW_LEADS_TBL where ERROR_DESC is not null ;--

select count(*) from COMMON_LOAD_HOLD_TBL;--28881

select * from COMMON_LOAD_HOLD_TBL order by DBMS_RANDOM.RANDOM();--28881

select count(*) from COMMON_LOAD_TBL;--28881

select count(*) from DS_ACE_OUTPUT_TBL;--28881
select count(*) from ADDRESS_OUTPUT_TBL;--28881
select count(*) from SI_OUTPUT_TBL;--28881
select count(*) from CUSTOMER_OUTPUT_TBL;--28881


select count(*) from visitor_dim;--19611
select count(*) from visitor_lkp;--14534
select count(*) from visitor_history_tbl;--20979
select count(*) from  address_dim;--19564
select count(*) from  address_lkp where SOURCE_SYSTEM_CD = 0;--14491
select count(*) from  visitor_address_xref;--20145
select count(*) from  visitor_address_lkp;--15165
select count(*) from  serialized_item_dim;--26741
select count(*) from  serialized_item_lkp;--24143
select count(*) from  visitor_ownership_xref;--26742
select count(*) from  email_lkp;--27628
select count(*) from  email_dim;--19272
select count(*) from  visitor_email_xref;--19415
select count(*) from  visitor_email_lkp;--14013
select count(*) from  phone_dim;--15800
select count(*) from  phone_lkp;--22216
select count(*) from  visitor_phone_xref;--15997
select count(*) from  visitor_phone_lkp;--11324
select count(*) from  VISITOR_PREFERENCE_TBL;--54765
select count(*) from  purl_dim;--14234
select count(*) from  VISITOR_PURL_XREF;--14395
select count(*) from  CUSTOMER_DIM;--19499
select count(*) from  HOUSEHOLD_LKP;--
select count(*) from  CUSTOMER_LKP;--14071

select * from  serialized_item_dim;--
select * from  ADDRESS_DIM;--

select SOURCE, count(*)  from serialized_item_ext_dim si group by SOURCE;

select SOURCE, count(*)  from BOSH.serialized_item_ext_dim si group by SOURCE;


select latest_coverage_type, name, count(*), max(registration_dt)
  from P_serialized_item_dim si left join P_latest_coverage_type_dim on coverage_type_key = latest_coverage_type
 group by latest_coverage_type, name
 order by 1;
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2977682 |2107-10-01          |
|2                   |Extended WARRANTY              |109014  |2024-10-18 20:47:21 |
|3                   |Cancelled WARRANTY             |2125    |2024-10-11 13:37:48 |
|6                   |Data Issues                    |25477   |2024-09-27 13:39:22 |
|17                  |NULL                           |1       |2024-06-17 17:03:37 |
|20                  |Data Errors                    |13      |2022-12-22          |
|21                  |Gaggenau Ambassador Suppression|769     |2024-06-24          |
|22                  |Duplicate data                 |161990  |2024-10-18 21:15:52 |
|23                  |Gaggenau DNS List              |3865    |2024-07-06          |
|50                  |Temp Builder Suppression       |15009   |2023-03-29 15:13:03 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
|52                  |Inwarranty Builder Suppression |2776    |2023-07-19 16:39:31 |
+--------------------+-------------------------------+--------+--------------------+
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |3001825 |2107-10-01          |
|2                   |Extended WARRANTY              |109014  |2024-10-18 20:47:21 |
|3                   |Cancelled WARRANTY             |2125    |2024-10-11 13:37:48 |
|6                   |Data Issues                    |25477   |2024-09-27 13:39:22 |
|17                  |NULL                           |1       |2024-06-17 17:03:37 |
|20                  |Data Errors                    |13      |2022-12-22          |
|21                  |Gaggenau Ambassador Suppression|769     |2024-06-24          |
|22                  |Duplicate data                 |161990  |2024-10-18 21:15:52 |
|23                  |Gaggenau DNS List              |3865    |2024-08-06          |
|50                  |Temp Builder Suppression       |15009   |2023-03-29 15:13:03 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
|52                  |Inwarranty Builder Suppression |2776    |2023-07-19 16:39:31 |
+--------------------+-------------------------------+--------+--------------------+
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |3000498 |2107-10-01          |
|2                   |Extended WARRANTY              |109016  |2024-10-18 20:47:21 |
|3                   |Cancelled WARRANTY             |2125    |2024-10-11 13:37:48 |
|6                   |Data Issues                    |25477   |2024-09-27 13:39:22 |
|17                  |NULL                           |1       |2024-06-17 17:03:37 |
|20                  |Data Errors                    |13      |2022-12-22          |
|21                  |Gaggenau Ambassador Suppression|769     |2024-06-24          |
|22                  |Duplicate data                 |163315  |2024-10-18 21:15:52 |
|23                  |Gaggenau DNS List              |3865    |2024-08-06          |
|50                  |Temp Builder Suppression       |15009   |2023-03-29 15:13:03 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
|52                  |Inwarranty Builder Suppression |2776    |2023-07-19 16:39:31 |
+--------------------+-------------------------------+--------+--------------------+
