select * from RAW_INWARRANTY_LEADS_TBL;
select count(*) from RAW_INWARRANTY_LEADS_TBL;--12263
select distinct ERROR_DESC from RAW_INWARRANTY_LEADS_TBL where ERROR_DESC is not null ;--69149
select count(*) from COMMON_LOAD_HOLD_TBL;--11774
select * from COMMON_LOAD_HOLD_TBL order by DBMS_RANDOM.RANDOM();--11774

select count(*) from COMMON_LOAD_TBL;--11774
select count(*) from DS_ACE_OUTPUT_TBL;--11774
select count(*) from ADDRESS_OUTPUT_TBL;--11774
select count(*) from SI_OUTPUT_TBL;--11774
select count(*) from CUSTOMER_OUTPUT_TBL;--11774


select count(*) from visitor_dim;--9763
select count(*) from visitor_lkp;--4943
select count(*) from visitor_history_tbl;--56541
select count(*) from  address_dim;--54819
select count(*) from  address_lkp where SOURCE_SYSTEM_CD = 0;--5447
select count(*) from  visitor_address_xref;--56123
select count(*) from  visitor_address_lkp;--6531
select count(*) from  serialized_item_dim;--10859
select count(*) from  serialized_item_lkp;--8467
select count(*) from  visitor_ownership_xref;--64780
select count(*) from  email_lkp;--9202
select count(*) from  email_dim;--54013
select count(*) from  visitor_email_xref;--54382
select count(*) from  visitor_email_lkp;--4854
select count(*) from  phone_dim;--46353
select count(*) from  phone_lkp;--8548
select count(*) from  visitor_phone_xref;--46794
select count(*) from  visitor_phone_lkp;--4610
select count(*) from  VISITOR_PREFERENCE_TBL;--155516
select count(*) from  purl_dim;--0
select count(*) from  VISITOR_PURL_XREF;--0
select count(*) from  CUSTOMER_DIM;--9697
select count(*) from  HOUSEHOLD_LKP;--0
select count(*) from  CUSTOMER_LKP;--5126

select * from  serialized_item_dim;--64676
select * from  CUSTOMER_DIM;--54719

select SOURCE, count(*)  from serialized_item_ext_dim si group by SOURCE;

select SOURCE, count(*)  from BOSH.serialized_item_ext_dim si group by SOURCE;


select latest_coverage_type, name, count(*), max(registration_dt)
  from P_serialized_item_dim si left join P_latest_coverage_type_dim on coverage_type_key = latest_coverage_type
 group by latest_coverage_type, name
 order by 1;
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |2978695 |2107-10-01          |
|2                   |Extended WARRANTY              |108929  |2024-10-18 20:47:21 |
|3                   |Cancelled WARRANTY             |2125    |2024-10-11 13:37:48 |
|6                   |Data Issues                    |25477   |2024-09-27 13:39:22 |
|17                  |NULL                           |1       |2024-06-17 17:03:37 |
|20                  |Data Errors                    |13      |2022-12-22          |
|21                  |Gaggenau Ambassador Suppression|769     |2024-06-24          |
|22                  |Duplicate data                 |161062  |2024-10-18 21:15:52 |
|23                  |Gaggenau DNS List              |3865    |2024-07-06          |
|50                  |Temp Builder Suppression       |15009   |2023-03-29 15:13:03 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
|52                  |Inwarranty Builder Suppression |2776    |2023-07-19 16:39:31 |
+--------------------+-------------------------------+--------+--------------------+

