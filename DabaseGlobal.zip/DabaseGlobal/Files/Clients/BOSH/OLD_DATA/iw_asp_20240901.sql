select distinct FILE_NM from RAW_INWARRANTY_LEADS_TBL;

select to_char((TO_DATE(nvl(CLAIM_REPAIR_DATE, '01.01.1900'),'DD.MM.YYYY')),'MM/DD/YYYY') from RAW_INWARRANTY_LEADS_TBL
 where  CLAIM_REPAIR_DATE  not like '%#%' AND ERROR_DESC is null
order by DBMS_RANDOM.RANDOM()
;--12263

 SELECT distinct SUBSTR(SUBSTR(CLAIM_REPAIR_DATE, 1, Instr(CLAIM_REPAIR_DATE, '.', -1, 1) -1), 1, Instr(SUBSTR(CLAIM_REPAIR_DATE, 1, Instr(CLAIM_REPAIR_DATE, '.', -1, 1) -1), '.', -1, 1) -1) part1

--         , SUBSTR(SUBSTR(CLAIM_REPAIR_DATE, 1, Instr(CLAIM_REPAIR_DATE, '.', -1, 1) -1), Instr(SUBSTR(CLAIM_REPAIR_DATE, 1, Instr(CLAIM_REPAIR_DATE, '.', -1, 1) -1), '.', -1, 1) +1) part2,
--
--         SUBSTR(CLAIM_REPAIR_DATE, 1, Instr(CLAIM_REPAIR_DATE, '.', -1, 1) -1) part1,
--
--         SUBSTR(CLAIM_REPAIR_DATE, Instr(CLAIM_REPAIR_DATE, '.', -1, 1) +1) part3
 FROM RAW_INWARRANTY_LEADS_TBL;


select COUNT(*) FROM RAW_INWARRANTY_LEADS_TBL where SUBSTR(SUBSTR(CLAIM_REPAIR_DATE, 1, Instr(CLAIM_REPAIR_DATE, '.', -1, 1) -1), 1, Instr(SUBSTR(CLAIM_REPAIR_DATE, 1, Instr(CLAIM_REPAIR_DATE, '.', -1, 1) -1), '.', -1, 1) -1)  is null;


select count(*) from RAW_INWARRANTY_LEADS_TBL;--15288
select distinct ERROR_DESC from RAW_INWARRANTY_LEADS_TBL where ERROR_DESC is not null ;--2
select count(*) from COMMON_LOAD_HOLD_TBL;--14882
select * from COMMON_LOAD_HOLD_TBL order by DBMS_RANDOM.RANDOM();--12214

select count(*) from COMMON_LOAD_TBL;--14882
select count(*) from DS_ACE_OUTPUT_TBL;--0
select count(*) from ADDRESS_OUTPUT_TBL;--0
select count(*) from SI_OUTPUT_TBL;--0
select count(*) from CUSTOMER_OUTPUT_TBL;--0


select count(*) from visitor_dim;--0
select count(*) from visitor_lkp;--0
select count(*) from visitor_history_tbl;--0
select count(*) from  address_dim;--0
select count(*) from  address_lkp where SOURCE_SYSTEM_CD = 0;--0
select count(*) from  visitor_address_xref;--0
select count(*) from  visitor_address_lkp;--0
select count(*) from  serialized_item_dim;--0
select count(*) from  serialized_item_lkp;--0
select count(*) from  visitor_ownership_xref;--0
select count(*) from  email_lkp;--0
select count(*) from  email_dim;--0
select count(*) from  visitor_email_xref;--0
select count(*) from  visitor_email_lkp;--0
select count(*) from  phone_dim;--0
select count(*) from  phone_lkp;--0
select count(*) from  visitor_phone_xref;--0
select count(*) from  visitor_phone_lkp;--0
select count(*) from  VISITOR_PREFERENCE_TBL;--0
select count(*) from  purl_dim;--0
select count(*) from  VISITOR_PURL_XREF;--0
select count(*) from  CUSTOMER_DIM;--9697
select count(*) from  HOUSEHOLD_LKP;--0
select count(*) from  CUSTOMER_LKP;--5126

select * from  serialized_item_dim;--0
select * from  CUSTOMER_DIM;--0

select SOURCE, count(*)  from serialized_item_ext_dim si group by SOURCE;

select SOURCE, count(*)  from BOSH.serialized_item_ext_dim si group by SOURCE;


select latest_coverage_type, name, count(*), max(registration_dt)
  from P_serialized_item_dim si left join P_latest_coverage_type_dim on coverage_type_key = latest_coverage_type
 group by latest_coverage_type, name
 order by 1;
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |3000498 |2107-10-01          |
|2                   |Extended WARRANTY              |109016  |2024-10-18 20:47:21 |
|3                   |Cancelled WARRANTY             |2125    |2024-10-11 13:37:48 |
|6                   |Data Issues                    |25477   |2024-09-27 13:39:22 |
|17                  |NULL                           |1       |2024-06-17 17:03:37 |
|20                  |Data Errors                    |13      |2022-12-22          |
|21                  |Gaggenau Ambassador Suppression|769     |2024-06-24          |
|22                  |Duplicate data                 |163315  |2024-10-18 21:15:52 |
|23                  |Gaggenau DNS List              |3865    |2024-08-06          |
|50                  |Temp Builder Suppression       |15009   |2023-03-29 15:13:03 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
|52                  |Inwarranty Builder Suppression |2776    |2023-07-19 16:39:31 |
+--------------------+-------------------------------+--------+--------------------+
+--------------------+-------------------------------+--------+--------------------+
|LATEST_COVERAGE_TYPE|NAME                           |COUNT(*)|MAX(REGISTRATION_DT)|
+--------------------+-------------------------------+--------+--------------------+
|1                   |MNF WARRANTY                   |3036705 |2107-10-01          |
|2                   |Extended WARRANTY              |109063  |2024-10-19 05:22:52 |
|3                   |Cancelled WARRANTY             |2122    |2024-10-11 13:37:48 |
|6                   |Data Issues                    |25477   |2024-09-27 13:39:22 |
|17                  |NULL                           |1       |2024-06-17 17:03:37 |
|20                  |Data Errors                    |13      |2022-12-22          |
|21                  |Gaggenau Ambassador Suppression|769     |2024-09-11          |
|22                  |Duplicate data                 |165455  |2024-10-18 21:15:52 |
|23                  |Gaggenau DNS List              |3865    |2024-09-11          |
|50                  |Temp Builder Suppression       |15009   |2023-03-29 15:13:03 |
|51                  |Temp Builder Suppression       |367     |2020-03-01          |
|52                  |Inwarranty Builder Suppression |2776    |2023-07-19 16:39:31 |
+--------------------+-------------------------------+--------+--------------------+


