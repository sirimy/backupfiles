
select tgt.BRAND,tgt.MATERIAL,tgt.MATERIAL_GROUP,tgt.MATERIAL_DESCRIPTION,MAP_UMRP,tgt.ERROR_DESC
from bosh.RAW_MODEL_MASTER_TBL tgt
    inner join bosh.V_PRODUCT src
on (src.BRAND_NM =tgt.BRAND and src.MODEL_NO = tgt.MATERIAL)
where to_number(coalesce(MAP_UMRP,'0')) <> coalesce(src.PRICE_AMT,0)
and src.PRICE_AMT is not null
and src.PRODUCT_KEY not in (select ppd.PRODUCT_KEY from bosh.PRODUCT_PRICE_DIM ppd)
and src.MODEL_NO in ( select c.MATERIAL from bosh.RAW_MODEL_MASTER_TBL c
                               where lower(c.ERROR_DESC) = lower('Model exists in core with a different price'))
and tgt.FILE_NM like '%20220803%';