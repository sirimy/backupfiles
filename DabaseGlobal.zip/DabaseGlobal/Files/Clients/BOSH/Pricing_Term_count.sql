

select pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   P_product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
where  pricing_scheme_key in (
62,
101,
111,
112,
113,
114,
116,
117,
118
) and
-- where  PRICING_SCHEME_KEY in ( 61, 62, 74)
--   and PRODUCT_KEY in (
-- 20324
--     )
    psd.END_DT > sysdate
and   ppd.ACTIVE_IND = 'Y'   --check active vs inactive
group by pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC, age
order by pricing_scheme_type, PRICING_SCHEME_DESC, PRICING_SCHEME_KEY, age;


select ppd.PRODUCT_KEY ,pricing_scheme_type, PRICING_SCHEME_KEY, PRICING_SCHEME_DESC,pol.NAME , age,TERM_KEY,ppd.BASE_PRICE_AMT ,ppd.POLICY_KEY,ppd.TERM_MONTHS
from   P_product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
Where PRICING_SCHEME_DESC  like 'RO%' AND ppd.PRODUCT_KEY in('19658','22118')
Order by PRICING_SCHEME_KEY,PRODUCT_KEY,TERM_KEY
;