

SELECT FILE_NM,COUNT(FILE_NM)  from BOSHSTG.RAW_MODEL_MASTER_TBL
group by FILE_NM;

SELECT *  from BOSHSTG.RAW_MODEL_MASTER_TBL WHERE MATERIAL in (
    select MODEL_NO from PRODUCT_CATALOG_TBL where PRODUCT_CATEGORY_UNIQUE_ID = 'OTHER' AND PRODUCT_DSC not like '%Blower%' AND PRICE_AMT > 400
                                             AND PRICE_AMT <= 500
    );

SELECT *  from bosh.RAW_MODEL_MASTER_TBL WHERE MATERIAL in ('TCM24PS', 'TCM24TS' ) order by INSERT_AUDIT_KEY;

-- Insert into RAW_MODEL_MASTER_TBL
-- SELECT *  from bosh.RAW_MODEL_MASTER_TBL WHERE MATERIAL in (  'CM450710' );


SELECT *  from BOSH.RAW_MODEL_MASTER_TBL WHERE MATERIAL in ('CM470711') order by INSERT_AUDIT_KEY;



select COUNT(*) from PRODUCT_CATALOG_TBL where PRODUCT_CATEGORY_UNIQUE_ID = 'OTHER' ;

select * from PRODUCT_CATALOG_TBL where PRODUCT_CATEGORY_UNIQUE_ID = 'OTHER' AND PRODUCT_DSC not like '%Blower%' AND PRICE_AMT > 1000 ;


select * from PRODUCT_CATALOG_TBL  where
--PRODUCT_CATEGORY_UNIQUE_ID = 'OTHER' and
MODEL_NO in ('TCM24PS', 'TCM24TS', 'CM450710', 'CM470711')
;


select * from BOSH.PRODUCT_DIM where MODEL_NO in   ('CM450710', 'CM470711') ;
select * from BOSH.V_PRODUCT where MODEL_NO in   ('CM450710', 'CM470711') ;

select * from bosh.product_attribute_xref WHERE PRODUCT_KEY IN
(select PRODUCT_KEY from BOSH.PRODUCT_DIM where MODEL_NO in   ('CM450710', 'CM470711'))
ORDER BY PRODUCT_KEY ;

INSERT INTO PRODUCT_CATALOG_TBL
        (
        MARKETING_PRODUCT_NM,
        Product_Category_XID,
        Marketing_Product_Category_Nm,
        BRAND_UNIQUE_ID,
        BRAND_NM,
        BRAND_DSC,
        PRODUCT_UNIQUE_ID,
        Product_Nm,
        Product_Dsc,
        --MARKETING_PRODUCT_NM,
        MODEL_NO,
        SKU_NO,
        UPC_CD,
        PRICE_AMT,
        Do_Not_Solicit_Product_IND,
        INSERT_AUDIT_KEY,
        SOURCE_SYSTEM_CD,
        UNIQUE_SEQ_NO,
        PRODUCT_CATEGORY_UNIQUE_ID,
        PRODUCT_CATEGORY_DSC,
        Product_Category_NM
        )
        with m_group as (
            select Material as Material_with,
                   case when lower(material_group) like '%refrig%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%sbs%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like 'freezer%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like 'built in/built under%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%coffee%' then 'BUILT-IN COFFEE MAKER'
                        when lower(material_group) like '%dish%' then 'DISHWASHER'
                        when lower(material_group) like '%hood%' then 'VENTILATION'
                        when lower(material_group) like '%ventilation%' then 'VENTILATION'
                        when lower(material_group) like '%oven%' then 'COOKING'
                        when lower(material_group) like '%cook%' then 'COOKING'
                        when lower(material_group) like '%range%' then 'COOKING'
                        when lower(material_group) like '%hob%' then 'COOKING'
                        when lower(material_group) like '%microwave%' then 'COOKING'
                        when lower(material_group) like '%warming drawers%' then 'COOKING'
                        when lower(material_group) like '%dryer%' then 'LAUNDRY-DRYER'
                        when lower(material_group) like '%frontloader%' then 'LAUNDRY-WASHER'
                        when lower(material_description) like '%washing machine%' then 'LAUNDRY-WASHER'
                        when lower(material_description) like '%dryer%' then 'LAUNDRY-DRYER'
                        ---
                        --these cases were added on 6/6/2019 by AJ
                        when lower(material_group) like '%vents%blowers%' then 'VENTILATION'
                        when lower(material_group) like '%fuel slide in%' then 'COOKING'
                        when lower(material_group) like '%gas slide in%' then 'COOKING'
                        when lower(material_group) like '%convection%' then 'COOKING'
                        ---
                        --these cases were added on 2/3/2021 by AJ
                        when lower(material_group) like '%fridge%' then 'REFRIGERATION W LOSS'
                        when lower(material_group) like '%side%by%side%' then 'REFRIGERATION W LOSS'
                       --added on 5/19/2021 by AJ
                        when lower(material_group) like '%washing machine%' then 'LAUNDRY-WASHER'
                        when lower(material_group) like '%freezer%' then 'REFRIGERATION W LOSS'
                       --added on 4/12/2022 by AJ
                       when lower(material_group) like '%plate%warmer%' then 'COOKING'
                       when lower(material_group) like '%modular grill%' then 'COOKING'
                       when lower(material_group) like '%winestorage%' then 'REFRIGERATION W LOSS'
                        else 'OTHER'
                    end as material_group_derived
            from RAW_MODEL_MASTER_TBL
        )
        SELECT
                SK_MARKETING_DESCRIPTION AS MARKETING_PRODUCT_NM,
                SK_MARKETING_DESCRIPTION as product_category_description, --PRODUCT_TYPE AS Product_Category_Description,
                --NEW_BUSINESS_FIELD AS Marketing_Product_Category_Nm,
                material_group_derived  as marketing_product_category_nm,
                BRAND AS Brand_ID,
                BRAND AS Brand_Name,
                BRAND AS Brand_Description,
                MATERIAL AS Product_ID,
                Material_Description AS Product_Name,
                Material_Description as product_descrition,
                Material AS Model_Number,
                UPC_CODE AS SKU_Number,
                UPC_CODE AS UPC_CD,
                MAP_UMRP AS PRICE_AMT,
                'N' as DO_NOT_SOLICIT_PRODUCT_IND,  -- we are setting as 'N' . DNS handling will be done by Post step which calls procedure "PK_MODEL_MASTER.s_002_update_dns_indicator"
                0,
                1 AS SOURCE_SYSTEM_CD,
                UNIQUE_SEQ_NO,
                material_group_derived as PRODUCT_CATEGORY_UNIQUE_ID,
                material_group_derived AS PRODUCT_CATEGORY_DSC,
                material_group_derived as Product_Category_NM
        FROM  RAW_MODEL_MASTER_TBL r join m_group m on m.Material_with = r.Material;

--delete from RAW_MODEL_MASTER_TBL where MATERIAL not in   ('CM470711') ;
--
-- update RAW_MODEL_MASTER_TBL
-- SET UNIQUE_SEQ_NO='7703229';

select * from RAW_MODEL_MASTER_TBL;

select * from PRODUCT_CATALOG_TBL ;


Select * from PRODUCT_DIM where PRODUCT_KEY = '33292'
UNION
Select * from BOSH.PRODUCT_DIM where PRODUCT_KEY = '33292';

SELECT * FROM  BOSH.product_attribute_xref where PRODUCT_KEY = '33292';--count =4


select policy_key, brand, product_cat_desc, channels from POLICY_EXT_TBL r where r.CHANNELS like '%EB'
union
select policy_key, brand, product_cat_desc, channels from p_POLICY_EXT_TBL r
where r.CHANNELS like '%EB';











