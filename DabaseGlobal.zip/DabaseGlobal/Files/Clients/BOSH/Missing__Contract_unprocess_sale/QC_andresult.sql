


Select slkp.SI_KEY,slkp.SI_XID,substr(slkp.si_xid,instr(slkp.si_xid,'-',1,2)+1) Expected_visitor_xid,vlkp.visitor_xid
 FROM  BOSH.RAW_CONTRACT_SALES_TBL a
                   JOIN p_order_item_Tbl oi on ( SUBSTR(UNIQUE_IDENTIFIER,1,INSTR(UNIQUE_IDENTIFIER,'-')-1) = OI.ORDER_KEY AND SUBSTR(UNIQUE_IDENTIFIER,INSTR(UNIQUE_IDENTIFIER,'-')+1) = ORDER_LINE_KEY)
                   LEFT join p_ORDER_ITEM_DISC_INFO_LKP oid on (oi.ORDER_KEY = oid.order_key and OID.ORDER_LINE_KEY = oi.order_line_key)
                   JOIN p_order_tbl ot on ( oi.order_key = ot.order_key)
                   JOIN P_VISITOR_LKP VLKP ON ( OT.VISITOR_KEY = VLKP.VISITOR_KEY AND VLKP.SOURCE_SYSTEM_CD = 1)
                   LEFT JOIN P_SERIALIZED_ITEM_LKP SLKP ON ( SLKP.SI_KEY = OI.SERIALIZED_ITEM_KEY )--AND SLKP.SOURCE_SYSTEM_CD = 0
                                                        --and substr(slkp.si_xid,instr(slkp.si_xid,'-',1,2)+1) = vlkp.visitor_xid
where UNIQUE_IDENTIFIER like '%435839%';

-- +-------+-------------------------------+--------------------+-----------+
-- |SI_KEY |SI_XID                         |EXPECTED_VISITOR_XID|VISITOR_XID|
-- +-------+-------------------------------+--------------------+-----------+
-- |3749147|22108200                       |22108200            |T8185507   |
-- |3749147|SHVM63W53N/20-20230826-T8193123|T8193123            |T8185507   |
-- +-------+-------------------------------+--------------------+-----------+

select * from bosh.ORDER_TBL oit where ORDER_KEY = 435839;
-- +-----------+---------+---------+
-- |VISITOR_KEY|ORDER_KEY|ORDER_XID|
-- +-----------+---------+---------+
-- |2717837    |435839   |3391136  |
-- +-----------+---------+---------+
select * from BOSH.VISITOR_LKP where VISITOR_XID in ('T8193123','T8185507');

select * from BOSH.VISITOR_DIM where VISITOR_KEY in (2717837,2788935);
-- +-----------+------------+-------------+
-- |VISITOR_KEY|CUSTOMER_KEY|HOUSEHOLD_KEY|
-- +-----------+------------+-------------+
-- |2717837    |5004528     |2400685      |
-- |2788935    |5004528     |2400685      |
-- +-----------+------------+-------------+



