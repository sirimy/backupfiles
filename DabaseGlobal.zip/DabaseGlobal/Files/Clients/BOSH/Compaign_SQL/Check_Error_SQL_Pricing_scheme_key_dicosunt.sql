SELECT DISTINCT
          ppd.pricing_scheme_key,
          PPD.policy_key,
          TRD.term_key,
          si_cnt,
          product_key,
          price_before_discount_amt,
          discount_type_cd,criteria_cd,
          CASE
             WHEN si_cnt > 1 AND discount_type_cd = 'Bundle'
             THEN
                discount_key
             WHEN     discount_type_cd = 'Item'
                  AND criteria_cd IN ('E1000', 'E2000')
             THEN
                discount_key
             ELSE
                NULL
          END
             discount_key
         ,trd.month as term_months_no
         ,trd.day as term_day
         ,ctst.delay_days
     FROM p_product_price_dim ppd
          LEFT JOIN p_criteria_celL_xref ccx
             ON (ppd.pricing_scheme_key = ccx.PRICING_SCHEME_KEY)
          LEFT JOIN p_criteria_dim cd ON (ccx.criteria_key = cd.criteria_key)
          LEFT JOIN p_term_dim trd ON (ppd.term_months = month)
          LEFT JOIN p_POLICY_TBL PL ON (PPD.POLICY_KEY = PL.POLICY_KEY)
          LEFT JOIN p_discount_dim ON (1 = 1)
          LEFT JOIN si_cnt_tbl ON (1 = 1)
          LEFT JOIN p_coverage_timing_strategy_tbl ctst on ctst.coverage_timing_strategy_key = pl.coverage_timing_strategy_key
    WHERE ppd.active_ind = 'Y' and  si_cnt             = 1
            AND ppd.pricing_scheme_key = 156
            AND product_key        = 27480 AND discount_type_cd     = 'Item' and TRD.term_key=3;
+------------------+----------+--------+------+-----------+-------------------------+----------------+------------+--------------+--------+----------+
|PRICING_SCHEME_KEY|POLICY_KEY|TERM_KEY|SI_CNT|PRODUCT_KEY|PRICE_BEFORE_DISCOUNT_AMT|DISCOUNT_TYPE_CD|DISCOUNT_KEY|TERM_MONTHS_NO|TERM_DAY|DELAY_DAYS|
+------------------+----------+--------+------+-----------+-------------------------+----------------+------------+--------------+--------+----------+
|156               |3012      |3       |1     |27480      |617.40                   |Item            |1           |36            |1095    |60        |
|156               |3012      |3       |1     |27480      |617.40                   |Item            |NULL        |36            |1095    |60        |
+------------------+----------+--------+------+-----------+-------------------------+----------------+------------+--------------+--------+----------+
select * from V_PRICE_LKP p
            where  p.si_cnt             = 1
            AND p.pricing_scheme_key = 156
            AND p.product_key        = 27480
            AND discount_type_cd     = 'Item'
            AND TERM_KEY=3 order by TERM_KEY;



SELECT DISTINCT
          ppd.pricing_scheme_key,
          PPD.policy_key,
          TRD.term_key,
          si_cnt,
          product_key,
          price_before_discount_amt,
          discount_type_cd,criteria_cd,
          CASE
             WHEN si_cnt > 1 AND discount_type_cd = 'Bundle'
             THEN
                discount_key
             WHEN     discount_type_cd = 'Item'
                  AND criteria_cd IN ('E1000', 'E2000')
             THEN
                discount_key
             ELSE
                NULL
          END
             discount_key
         ,trd.month as term_months_no
         ,trd.day as term_day
         ,ctst.delay_days
     FROM p_product_price_dim ppd
          LEFT JOIN p_criteria_celL_xref ccx
             ON (ppd.pricing_scheme_key = ccx.PRICING_SCHEME_KEY)
          LEFT JOIN p_criteria_dim cd ON (ccx.criteria_key = cd.criteria_key)
          LEFT JOIN p_term_dim trd ON (ppd.term_months = month)
          LEFT JOIN p_POLICY_TBL PL ON (PPD.POLICY_KEY = PL.POLICY_KEY)
          LEFT JOIN p_discount_dim ON (1 = 1)
          LEFT JOIN si_cnt_tbl ON (1 = 1)
          LEFT JOIN p_coverage_timing_strategy_tbl ctst on ctst.coverage_timing_strategy_key = pl.coverage_timing_strategy_key
    WHERE ppd.active_ind = 'Y' and  si_cnt             = 2
            AND ppd.pricing_scheme_key = 159
            AND product_key        = 31860 AND discount_type_cd     = 'Item' and TRD.term_key=3;
+------------------+----------+--------+------+-----------+-------------------------+----------------+------------+--------------+--------+----------+
|PRICING_SCHEME_KEY|POLICY_KEY|TERM_KEY|SI_CNT|PRODUCT_KEY|PRICE_BEFORE_DISCOUNT_AMT|DISCOUNT_TYPE_CD|DISCOUNT_KEY|TERM_MONTHS_NO|TERM_DAY|DELAY_DAYS|
+------------------+----------+--------+------+-----------+-------------------------+----------------+------------+--------------+--------+----------+
|159               |3128      |3       |2     |31860      |1001.70                  |Item            |NULL        |36            |1095    |0         |
+------------------+----------+--------+------+-----------+-------------------------+----------------+------------+--------------+--------+----------+

select * from V_PRICE_LKP p
            where  p.si_cnt             = 2
            AND p.pricing_scheme_key = 159
            AND p.product_key        = 31860
            AND discount_type_cd     = 'Item'
            AND TERM_KEY=3 order by TERM_KEY;


select CRITERIA_XID,CRITERIA_CD,COUNT(*) from  p_criteria_celL_xref ccx
             JOIN AUDIT_TBL ATB on CCX.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
             LEFT JOIN p_criteria_dim cd ON (ccx.criteria_key = cd.criteria_key)
Where ATB.CREATION_DT > date '2024-03-06'
Group by CRITERIA_XID,CRITERIA_CD
Order by CRITERIA_XID,CRITERIA_CD
;
+-----------+--------+
|CRITERIA_CD|COUNT(*)|
+-----------+--------+
|AI010      |2       |
|AI030      |2       |
|AI040      |2       |
|AO030      |2       |
|AO090      |2       |
|E1000      |2       |
|E2000      |2       |
|RI010      |16      |
|RI030      |16      |
|RI040      |16      |
|RW000      |12      |
+-----------+--------+

select * from BOSH.PRICING_SCHEME_DIM where PRICING_SCHEME_KEY = 156;
+------------------+-------------------+-------------------+----------+----------------+----------------+--------------+-------------------+----------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NAME|PRICING_SCHEME_DESC|LOAD_DT   |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|PRICING_SCHEME_TYPE|END_DT    |
+------------------+-------------------+-------------------+----------+----------------+----------------+--------------+-------------------+----------+
|156               |EB Thermador       |EB Thermador       |2023-01-24|642737          |NULL            |642935        |EB                 |2099-12-31|
+------------------+-------------------+-------------------+----------+----------------+----------------+--------------+-------------------+----------+

    select PSD.PRICING_SCHEME_KEY ,PSD.PRICING_SCHEME_NAME,CRITERIA_XID,CRITERIA_CD,COUNT(*) from  p_criteria_celL_xref ccx
             JOIN AUDIT_TBL ATB on CCX.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
             LEFT JOIN p_criteria_dim cd ON (ccx.criteria_key = cd.criteria_key)
             LEFT JOIN BOSH.PRICING_SCHEME_DIM PSD ON (PSD.PRICING_SCHEME_KEY = ccx.PRICING_SCHEME_KEY)
Where ATB.CREATION_DT > date '2024-03-06'
Group by CRITERIA_XID,CRITERIA_CD,PSD.PRICING_SCHEME_NAME,PSD.PRICING_SCHEME_KEY
Order by CRITERIA_XID,CRITERIA_CD
;