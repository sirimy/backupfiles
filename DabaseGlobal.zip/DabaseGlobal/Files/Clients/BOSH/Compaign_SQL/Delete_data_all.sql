
delete FROM bundle_dim ;
delete FROM bundle_item_xref ;
delete FROM cell_selection_fct ;
delete FROM base_offer_xref ;
delete FROM base_offer_item_xref ;
delete FROM base_offer_item_discount_xref ;
delete FROM base_offer_discount_xref
;
delete FROM bundle_state_tbl  ;
delete FROM bundle_transition_hist
;
delete FROM campaign_participation_fct
;
delete FROM offer_xref ;
delete FROM offer_item_xref ;
delete FROM offer_discount_xref ;
delete FROM offer_item_discount_xref ;
delete FROM offer_quickreg_xref
;
delete FROM campaign_spool_file_tbl
; delete FROM campaign_spool_seed_tbl
;
delete FROM tax_input_tbl_vertax ;
delete FROM tax_output_tbl_vertax
;
delete FROM ESP_AM_SCR_INPUT_TBL ;
delete FROM ESP_AM_SCR_OUTPUT_TBL ;
delete FROM ESP_AM_SCR_ERROR_TBL ;
delete FROM ESP_AM_SCR_VAR_TBL ;
delete FROM BUNDLE_SUMMARY_TBL
;