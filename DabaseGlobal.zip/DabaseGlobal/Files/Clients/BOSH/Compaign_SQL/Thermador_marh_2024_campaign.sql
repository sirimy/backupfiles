
select T2.CREATION_DT,T1.* from BOSH.CAMPAIGN_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by T2.CREATION_DT DESC
;-- No new add

select  t1.CELL_GROUP_KEY,T1.CELL_GROUP_XID,T1.CELL_GROUP_NM from BOSH.CELL_GROUP_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by t1.CELL_GROUP_KEY;

select T2.CREATION_DT,T1.* from BOSH.CELL_GROUP_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by T2.CREATION_DT DESC
;-- No new add

select T2.CREATION_DT,T1.* from BOSH.CELL_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by T2.CREATION_DT DESC,CELL_KEY
;-- 22 new add here 11 B and 11 T for same set
+--------------------------+--------+-----------+---------------------------------------------------------------------+-------+-----------+
|CREATION_DT               |CELL_KEY|CELL_XID   |CELL_NM                                                              |CELL_CD|CONTROL_IND|
+--------------------------+--------+-----------+---------------------------------------------------------------------+-------+-----------+
|2024-03-06 02:38:07.000000|21020   |AI01-THR-C2|Aftermarket 1 Effort - Thermador - Bundle Discount Control           |14     |B          |
|2024-03-06 02:38:07.000000|21021   |AI02-THR-C2|Aftermarket 2 Effort - Thermador - Bundle Discount Control           |14     |B          |
|2024-03-06 02:38:07.000000|21022   |AI03-THR-C2|Aftermarket 3 Effort - Thermador - Bundle Discount Control           |14     |B          |
|2024-03-06 02:38:07.000000|21023   |AO01-THR-C2|Aftermarket OOW INITIAL Effort - Thermador - Bundle Discount Control |14     |B          |
|2024-03-06 02:38:07.000000|21024   |AO02-THR-C2|Aftermarket OOW FINAL Effort - Thermador - Bundle Discount Control   |14     |B          |
|2024-03-06 02:38:07.000000|21025   |EB01-THR-C2|Early Bird 1 Effort - Thermador - Bundle Discount Control            |14     |B          |
|2024-03-06 02:38:07.000000|21026   |EB02-THR-C2|Early Bird 2 Effort - Thermador - Bundle Discount Control            |14     |B          |
|2024-03-06 02:38:07.000000|21027   |RI01-THR-C2|Renewal 1 Effort - Thermador - Bundle Discount Control               |14     |B          |
|2024-03-06 02:38:07.000000|21028   |RI02-THR-C2|Renewal 2 Effort - Thermador - Bundle Discount Control               |14     |B          |
|2024-03-06 02:38:07.000000|21029   |RI03-THR-C2|Renewal 3 Effort - Thermador - Bundle Discount Control               |14     |B          |
|2024-03-06 02:38:07.000000|21030   |RW03-THR-C2|Renewal Winback OOW - Thermador - 3 efforts - Bundle Discount Control|14     |B          |
|2024-03-06 02:38:07.000000|21031   |AI01-THR-T2|Aftermarket 1 Effort - Thermador - Bundle Discount Test              |15     |T          |
|2024-03-06 02:38:07.000000|21032   |AI02-THR-T2|Aftermarket 2 Effort - Thermador - Bundle Discount Test              |15     |T          |
|2024-03-06 02:38:07.000000|21033   |AI03-THR-T2|Aftermarket 3 Effort - Thermador - Bundle Discount Test              |15     |T          |
|2024-03-06 02:38:07.000000|21034   |AO01-THR-T2|Aftermarket OOW INITIAL Effort - Thermador - Bundle Discount Test    |15     |T          |
|2024-03-06 02:38:07.000000|21035   |AO02-THR-T2|Aftermarket OOW FINAL Effort - Thermador - Bundle Discount Test      |15     |T          |
|2024-03-06 02:38:07.000000|21036   |EB01-THR-T2|Early Bird 1 Effort - Thermador - Bundle Discount Test               |15     |T          |
|2024-03-06 02:38:07.000000|21037   |EB02-THR-T2|Early Bird 2 Effort - Thermador - Bundle Discount Test               |15     |T          |
|2024-03-06 02:38:07.000000|21038   |RI01-THR-T2|Renewal 1 Effort - Thermador - Bundle Discount Test                  |15     |T          |
|2024-03-06 02:38:07.000000|21039   |RI02-THR-T2|Renewal 2 Effort - Thermador - Bundle Discount Test                  |15     |T          |
|2024-03-06 02:38:07.000000|21040   |RI03-THR-T2|Renewal 3 Effort - Thermador - Bundle Discount Test                  |15     |T          |
|2024-03-06 02:38:07.000000|21041   |RW03-THR-T2|Renewal Winback OOW - Thermador - 3 efforts - Bundle Discount Test   |15     |T          |
+--------------------------+--------+-----------+---------------------------------------------------------------------+-------+-----------+
select T2.CREATION_DT,T1.* from BOSH.COHORT_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by T2.CREATION_DT DESC
;-- no new add
select T2.CREATION_DT,T1.* from BOSH.TIMING_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by T2.CREATION_DT DESC
;-- no new add
select T2.CREATION_DT,T1.* from BOSH.PRICING_SCHEME_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by T2.CREATION_DT DESC
;-- no new add
select T2.CREATION_DT,T1.* from BOSH.CRITERIA_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by T2.CREATION_DT DESC
;-- no new add
select T2.CREATION_DT,T3.CRITERIA_XID,T4.CELL_XID,T4.CONTROL_IND,T5.PRICING_SCHEME_DESC,T1.POPULATION_PCT from BOSH.CRITERIA_CELL_XREF T1
                           join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
                           join BOSH.CRITERIA_DIM T3 on T3.CRITERIA_KEY =T1.CRITERIA_KEY
                           join BOSH.CELL_DIM T4 on T4.CELL_KEY =T1.CELL_KEY
                           join BOSH.PRICING_SCHEME_DIM T5 on T5.PRICING_SCHEME_KEY =T1.PRICING_SCHEME_KEY
where 1=1
Order by T2.CREATION_DT DESC,t4.CELL_KEY
;-- 74 new add
+--------------------------+------------+-----------+-----------+-------------------+--------------+
|CREATION_DT               |CRITERIA_XID|CELL_XID   |CONTROL_IND|PRICING_SCHEME_DESC|POPULATION_PCT|
+--------------------------+------------+-----------+-----------+-------------------+--------------+
|2024-03-06 02:40:26.000000|AI01-THR    |AI01-THR-C2|B          |AM Thermador       |0.50          |
|2024-03-06 02:40:26.000000|AI02-THR    |AI02-THR-C2|B          |AM Thermador       |0.50          |
|2024-03-06 02:40:26.000000|AI03-THR    |AI03-THR-C2|B          |AM Thermador       |0.50          |
|2024-03-06 02:40:26.000000|AO2-THR     |AO02-THR-C2|B          |AO Thermador       |0.50          |
|2024-03-06 02:40:26.000000|AO1-THR     |AO02-THR-C2|B          |AO Thermador       |0.50          |
|2024-03-06 02:40:26.000000|E1-THR      |EB01-THR-C2|B          |EB Thermador       |0.50          |
|2024-03-06 02:40:26.000000|E2-THR      |EB02-THR-C2|B          |EB Thermador       |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-2   |RI01-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-4   |RI01-THR-C2|B          |RN 4 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-5   |RI01-THR-C2|B          |RN 5 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-6   |RI01-THR-C2|B          |RN 6 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-7   |RI01-THR-C2|B          |RN 7 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-8   |RI01-THR-C2|B          |RN 8 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-3   |RI01-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-9   |RI01-THR-C2|B          |RN 9 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-6   |RI02-THR-C2|B          |RN 6 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-9   |RI02-THR-C2|B          |RN 9 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-8   |RI02-THR-C2|B          |RN 8 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-7   |RI02-THR-C2|B          |RN 7 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-5   |RI02-THR-C2|B          |RN 5 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-4   |RI02-THR-C2|B          |RN 4 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-3   |RI02-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-2   |RI02-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-2   |RI03-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-8   |RI03-THR-C2|B          |RN 8 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-7   |RI03-THR-C2|B          |RN 7 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-6   |RI03-THR-C2|B          |RN 6 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-5   |RI03-THR-C2|B          |RN 5 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-4   |RI03-THR-C2|B          |RN 4 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-9   |RI03-THR-C2|B          |RN 9 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-3   |RI03-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-8   |RW03-THR-C2|B          |RO 8 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-3   |RW03-THR-C2|B          |RO 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-4   |RW03-THR-C2|B          |RO 4 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-5   |RW03-THR-C2|B          |RO 5 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-6   |RW03-THR-C2|B          |RO 6 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-7   |RW03-THR-C2|B          |RO 7 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|AI01-THR    |AI01-THR-T2|T          |AM Thermador       |0.50          |
|2024-03-06 02:40:26.000000|AI02-THR    |AI02-THR-T2|T          |AM Thermador       |0.50          |
|2024-03-06 02:40:26.000000|AI03-THR    |AI03-THR-T2|T          |AM Thermador       |0.50          |
|2024-03-06 02:40:26.000000|AO2-THR     |AO02-THR-T2|T          |AO Thermador       |0.50          |
|2024-03-06 02:40:26.000000|AO1-THR     |AO02-THR-T2|T          |AO Thermador       |0.50          |
|2024-03-06 02:40:26.000000|E1-THR      |EB01-THR-T2|T          |EB Thermador       |0.50          |
|2024-03-06 02:40:26.000000|E2-THR      |EB02-THR-T2|T          |EB Thermador       |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-4   |RI01-THR-T2|T          |RN 4 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-5   |RI01-THR-T2|T          |RN 5 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-9   |RI01-THR-T2|T          |RN 9 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-6   |RI01-THR-T2|T          |RN 6 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-7   |RI01-THR-T2|T          |RN 7 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-2   |RI01-THR-T2|T          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-8   |RI01-THR-T2|T          |RN 8 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-3   |RI01-THR-T2|T          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-8   |RI02-THR-T2|T          |RN 8 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-9   |RI02-THR-T2|T          |RN 9 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-2   |RI02-THR-T2|T          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-3   |RI02-THR-T2|T          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-4   |RI02-THR-T2|T          |RN 4 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-5   |RI02-THR-T2|T          |RN 5 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-6   |RI02-THR-T2|T          |RN 6 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-7   |RI02-THR-T2|T          |RN 7 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-2   |RI03-THR-T2|T          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-3   |RI03-THR-T2|T          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-4   |RI03-THR-T2|T          |RN 4 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-5   |RI03-THR-T2|T          |RN 5 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-6   |RI03-THR-T2|T          |RN 6 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-7   |RI03-THR-T2|T          |RN 7 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-8   |RI03-THR-T2|T          |RN 8 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-9   |RI03-THR-T2|T          |RN 9 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-3   |RW03-THR-T2|T          |RO 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-4   |RW03-THR-T2|T          |RO 4 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-5   |RW03-THR-T2|T          |RO 5 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-6   |RW03-THR-T2|T          |RO 6 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-7   |RW03-THR-T2|T          |RO 7 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RW3-THR-8   |RW03-THR-T2|T          |RO 8 Thermador     |0.50          |
+--------------------------+------------+-----------+-----------+-------------------+--------------+
select T2.CREATION_DT,T3.CRITERIA_XID,T4.CELL_XID,T4.CONTROL_IND,T5.PRICING_SCHEME_DESC,T1.POPULATION_PCT from BOSH.CRITERIA_CELL_XREF T1
                           join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
                           join BOSH.CRITERIA_DIM T3 on T3.CRITERIA_KEY =T1.CRITERIA_KEY
                           join BOSH.CELL_DIM T4 on T4.CELL_KEY =T1.CELL_KEY
                           join BOSH.PRICING_SCHEME_DIM T5 on T5.PRICING_SCHEME_KEY =T1.PRICING_SCHEME_KEY
where 1=1 and CRITERIA_XID like '%-THR-2%'
Order by T2.CREATION_DT DESC,t4.CELL_KEY
;-- 06 removed add
+--------------------------+------------+-----------+-----------+-------------------+--------------+
|CREATION_DT               |CRITERIA_XID|CELL_XID   |CONTROL_IND|PRICING_SCHEME_DESC|POPULATION_PCT|
+--------------------------+------------+-----------+-----------+-------------------+--------------+
|2024-03-06 02:40:26.000000|RI1-THR-2   |RI01-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-2   |RI02-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-2   |RI03-THR-C2|B          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI1-THR-2   |RI01-THR-T2|T          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI2-THR-2   |RI02-THR-T2|T          |RN 3 Thermador     |0.50          |
|2024-03-06 02:40:26.000000|RI3-THR-2   |RI03-THR-T2|T          |RN 3 Thermador     |0.50          |
+--------------------------+------------+-----------+-----------+-------------------+--------------+
delete from CRITERIA_CELL_XREF where CRITERIA_KEY in(
    select T3.CRITERIA_KEY from BOSH.CRITERIA_CELL_XREF T1
                           join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
                           join BOSH.CRITERIA_DIM T3 on T3.CRITERIA_KEY =T1.CRITERIA_KEY
                           join BOSH.CELL_DIM T4 on T4.CELL_KEY =T1.CELL_KEY
                           join BOSH.PRICING_SCHEME_DIM T5 on T5.PRICING_SCHEME_KEY =T1.PRICING_SCHEME_KEY
where 1=1 and CRITERIA_XID like '%-THR-2%'
    );

select T2.CREATION_DT,T1.* from BOSH.MESSAGE_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1
Order by T2.CREATION_DT DESC
;-- no new add

select T2.CREATION_DT,T3.STATE_NM,T4.CELL_XID,T5.OUTER_ENV_CD,T5.COPY_CD,T1.* from BOSH.state_message_xref T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
                            join BOSH.STATE_TBL T3 on T3.STATE_KEY =T1.STATE_KEY
                           join BOSH.CELL_DIM T4 on T4.CELL_KEY =T1.CELL_KEY
                           join BOSH.MESSAGE_DIM T5 on T5.MESSAGE_KEY =T1.MESSAGE_KEY
where 1=1
Order by T2.CREATION_DT DESC,T4.CELL_KEY
;--


