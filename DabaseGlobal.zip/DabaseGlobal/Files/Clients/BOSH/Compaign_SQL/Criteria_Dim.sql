select cri.*, ai.creation_dt, au.CREATION_DT as last_updated_dt
  from P_criteria_dim cri left join audit_tbl ai on ai.audit_key = insert_audit_key
       left join audit_tbl au on au.audit_key = UPDATE_AUDIT_KEY
 where 1=1
   and active_ind = 'Y'
--   and creation_dt >= date '2020-07-01'
   and SELECTION_TBL <> 'v_outbound_universe'
--    and (criteria_xid LIKE 'AO%'  or criteria_xid LIKE 'AV%' or criteria_xid LIKE 'OG%' or criteria_xid LIKE 'AS%')
--    and ADDITIONAL_SQL_TXT not like '%Solicited_Ind%'
--    and CRITERIA_CD like 'E%'
--    and CRITERIA_CD like 'AS%' --and CRITERIA_XID like 'AV%'
--    and (criteria_cd like 'RI06%' or criteria_cd like 'RI07%')
--    and criteria_xid like 'RI%' --and STREAM_LENGTH_DAYS > 126
--    and (criteria_xid like 'RI3%' or criteria_xid like 'RS3%')
--   and regexp_like(criteria_cd, 'A[GSTOSV]+')
--    and (criteria_xid LIKE 'AI%THR'   or criteria_xid LIKE 'A%GGN%')
--    and (criteria_xid LIKE 'E%THR'   or criteria_xid LIKE 'E%GGN%')
--   and additional_sql_txt LIKE '%and Age = 4'
    --and criteria_xid LIKE 'AO%'
--    and criteria_xid LIKE '%BSH%'
   --and criteria_xid LIKE '%THR%'
   and criteria_xid LIKE '%GGN%'
--   and criteria_xid LIKE 'RW%'
--   and registration_dt is not null
--   and criteria_key = 5953   
--   and WARRANTY_MONTHS = 24
--    and SCORING_FILE_CD is not null
--     and ai.CREATION_DT >= date '2020-01-01'
  order by criteria_cd, criteria_xid, insert_audit_key desc, LATEST_COVERAGE_EXP_DT, criteria_key;
 



select criteria_key,CELL_KEY,criteria_xid, criteria_cd,cell_key, pricing_scheme_key, pricing_scheme_name, POPULATION_PCT, cell_cd, cell_xid, cell_nm, cell_group_xid, cell_group_nm,
       pricing_scheme_desc, CAMPAIGN_NM
       , warranty_months, additional_sql_txt, cell_group_key, state_machine_key, state_machine_nm
  from P_criteria_cell_xref join P_criteria_dim using(criteria_key) 
       join P_cell_dim using (cell_key) 
       join P_cell_group_dim using (cell_group_key)
       join P_campaign_dim cmp using (campaign_key) 
       left join p_pricing_scheme_dim psd using (pricing_scheme_key)
       left join P_STATE_CELL_GROUP_XREF using (cell_group_key)
       left join P_STATE_MACHINE_TBL sm using (state_machine_key)
 where 1=1
   and active_ind = 'Y'
   --and POPULATION_PCT > 0
    and CRITERIA_KEY IN (20801,20802,20803)
--    and CELL_KEY = 19120
--    and CRITERIA_CD like 'AS%' --and CRITERIA_XID like 'AV%'
--    and (cmp.campaign_xid = 'AU' or cmp.campaign_xid = 'SG')
--    and (CRITERIA_CD like 'AO%' or CRITERIA_CD  like 'RO%')
--    and (criteria_cd like 'RI06%' or criteria_cd like 'RI07%')
--    and criteria_cd like 'R%'
--    and criteria_xid like '%BSH%'
   and criteria_xid LIKE '%THR%'
--   and criteria_xid LIKE '%GGN%'
--    and (criteria_xid like '%BSH%' or criteria_xid like '%THR%')
      --and CRITERIA_XID  like 'RI%'
--    and pricing_scheme_desc  like 'RN%'
--    and pricing_scheme_desc  like '%Bosch%'
--    and pricing_scheme_desc  like '%Thermador%'
--    and pricing_scheme_desc  like '%Gaggenau%'
--   and pricing_scheme_key in (115, 116)
--    and (upper(CAMPAIGN_DSC) like '%BUILDER%' or upper(CELL_DSC) like '%BUILDER%' or upper(CELL_NM) like '%BUILDER%')
--     and coalesce(STREAM_LENGTH_DAYS, 0) = 0
 order by criteria_xid, criteria_cd;

update BOSH.CRITERIA_CELL_XREF
SET POPULATION_PCT = 0
Where (CELL_KEY, CRITERIA_KEY) in (
            select CELL_KEY,criteria_key
              from P_criteria_cell_xref join AUDIT_TBL T2 on P_criteria_cell_xref.INSERT_AUDIT_KEY =T2.AUDIT_KEY
                  join P_criteria_dim using(criteria_key)
                   join P_cell_dim using (cell_key)
                   join P_cell_group_dim using (cell_group_key)
                   join P_campaign_dim cmp using (campaign_key)
                   left join p_pricing_scheme_dim psd using (pricing_scheme_key)
                   left join P_STATE_CELL_GROUP_XREF using (cell_group_key)
                   left join P_STATE_MACHINE_TBL sm using (state_machine_key)
             where 1=1
               and active_ind = 'Y'
               and POPULATION_PCT > 0
               and T2.CREATION_DT < date '2024-03-01'
              and criteria_xid LIKE '%THR%'
             );
+------------+--------+------------+-----------+--------------+
|CRITERIA_KEY|CELL_KEY|CRITERIA_XID|CRITERIA_CD|POPULATION_PCT|
+------------+--------+------------+-----------+--------------+
|10456       |10443   |RI4-THR-3   |RI060      |1.00          |
|10457       |10443   |RI4-THR-4   |RI060      |1.00          |
|10458       |10443   |RI4-THR-5   |RI060      |1.00          |
|10459       |10443   |RI4-THR-6   |RI060      |1.00          |
|20843       |10443   |RI4-THR-7   |RI060      |1.00          |
|20844       |10443   |RI4-THR-8   |RI060      |1.00          |
|20845       |10443   |RI4-THR-9   |RI060      |1.00          |
|10466       |10445   |RI5-THR-3   |RI070      |1.00          |
|10467       |10445   |RI5-THR-4   |RI070      |1.00          |
|10468       |10445   |RI5-THR-5   |RI070      |1.00          |
|10469       |10445   |RI5-THR-6   |RI070      |1.00          |
|20840       |10445   |RI5-THR-7   |RI070      |1.00          |
|20841       |10445   |RI5-THR-8   |RI070      |1.00          |
|20842       |10445   |RI5-THR-9   |RI070      |1.00          |
+------------+--------+------------+-----------+--------------+

    select * from BOSH.CRITERIA_CELL_XREF Where (CELL_KEY, CRITERIA_KEY) in (
            select CELL_KEY,criteria_key
              from P_criteria_cell_xref join AUDIT_TBL T2 on P_criteria_cell_xref.INSERT_AUDIT_KEY =T2.AUDIT_KEY
                  join P_criteria_dim using(criteria_key)
                   join P_cell_dim using (cell_key)
                   join P_cell_group_dim using (cell_group_key)
                   join P_campaign_dim cmp using (campaign_key)
                   left join p_pricing_scheme_dim psd using (pricing_scheme_key)
                   left join P_STATE_CELL_GROUP_XREF using (cell_group_key)
                   left join P_STATE_MACHINE_TBL sm using (state_machine_key)
             where 1=1
               and active_ind = 'Y'
               and POPULATION_PCT > 0
               and T2.CREATION_DT < date '2024-03-01'
              and criteria_xid LIKE '%THR%'
             );

select distinct pricing_scheme_key, pricing_scheme_name, pricing_scheme_desc, psd.END_DT, pol.exp_dt
  from P_criteria_cell_xref ccx join P_criteria_dim cri on (cri.criteria_key = ccx.criteria_key) join P_PRICING_SCHEME_DIM psd using (pricing_scheme_key)
       join p_product_price_dim ppt using (pricing_scheme_key) 
       join p_policy_tbl pol using (policy_key)
       --join POLICY_ext_tbl pex using (policy_key)
 where 1=1
   and cri.active_ind = 'Y'
   and ccx.POPULATION_PCT > 0
--   and criteria_xid like 'RI%'  
   and pricing_scheme_name LIKE 'RO%'
--   and additional_sql_txt LIKE '%HONEYWELL%'
--    and pol.exp_dt >= sysdate
 order by pricing_scheme_key, pricing_scheme_desc;


