
select   DISCOUNT_KEY,COUNT(*) from  BASE_OFFER_DISCOUNT_XREF
Group by  DISCOUNT_KEY;
+------------+--------+
|DISCOUNT_KEY|COUNT(*)|
+------------+--------+
|2           |25071   |
|3           |6292    |
+------------+--------+


 select   DISCOUNT_KEY,COUNT(*) from  BASE_OFFER_DISCOUNT_XREF
    where BUNDLE_KEY in (
            select  BUNDLE_KEY
                  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                       join BUNDLE_DIM bd using (bundle_key)
                       join P_CRITERIA_DIM cri using (criteria_key)
                       join p_campaign_dim using (campaign_key)
                where 1=1
                  and CELL_NM  like '%Thermador%'
--                    and CONTROL_IND = 'T'
--                    and BUNDLE_KEY in (select bix.BUNDLE_KEY from BUNDLE_ITEM_XREF bix
--                                        group by bix.BUNDLE_KEY having count(distinct bix.SI_KEY) >= 2)
            )
Group by  DISCOUNT_KEY
;
+------------+--------+
|DISCOUNT_KEY|COUNT(*)|
+------------+--------+
|2           |6381    |
|3           |6292    |
+------------+--------+

 select  cell_key,CELL_XID,CELL_GROUP_XID,CONTROL_IND,COUNT(*)
                  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                       join BUNDLE_DIM bd using (bundle_key)
                       join P_CRITERIA_DIM cri using (criteria_key)
                       join p_campaign_dim using (campaign_key)
                where 1=1
                  and CELL_NM  like '%Thermador%'
Group by cell_key,CELL_XID,CELL_GROUP_XID,CONTROL_IND
Order by cell_key,CELL_XID;
+--------+-----------+--------------+-----------+--------+
|CELL_KEY|CELL_XID   |CELL_GROUP_XID|CONTROL_IND|COUNT(*)|
+--------+-----------+--------------+-----------+--------+
|1012    |AI01-THR   |AI-THR-01     |N          |158     |
|1014    |AI02-THR   |AI-THR-02     |N          |352     |
|1016    |AI03-THR   |AI-THR-03     |N          |2856    |
|1018    |EB02-THR   |EB-THR-02     |N          |4295    |
|1020    |EB01-THR   |EB-THR-01     |N          |217     |
|6852    |RI03-THR   |RI-THR-03     |N          |1       |
|9764    |AO01-THR   |AO-THR-01     |N          |6019    |
|10443   |RI04-THR   |RI-THR-04     |N          |1       |
|10445   |RI05-THR   |RI-THR-05     |N          |187     |
|19143   |RW03-THR   |RW-THR-03     |N          |74      |
|20907   |AI01-THR-C2|AI-THR-01     |B          |12      |
|20908   |AI02-THR-C2|AI-THR-02     |B          |30      |
|20909   |AI03-THR-C2|AI-THR-03     |B          |325     |
|20910   |AO01-THR-C2|AO-THR-01     |B          |368     |
|20911   |EB01-THR-C2|EB-THR-01     |B          |21      |
|20912   |EB02-THR-C2|EB-THR-02     |B          |808     |
|20917   |RI05-THR-C2|RI-THR-05     |B          |27      |
|20919   |AI01-THR-T2|AI-THR-01     |T          |11      |
|20920   |AI02-THR-T2|AI-THR-02     |T          |28      |
|20921   |AI03-THR-T2|AI-THR-03     |T          |338     |
|20922   |AO01-THR-T2|AO-THR-01     |T          |405     |
|20923   |EB01-THR-T2|EB-THR-01     |T          |21      |
|20924   |EB02-THR-T2|EB-THR-02     |T          |771     |
|20929   |RI05-THR-T2|RI-THR-05     |T          |36      |
|20931   |AO02-THR-C2|AO-THR-01     |B          |380     |
|20932   |AO02-THR-T2|AO-THR-01     |T          |351     |
+--------+-----------+--------------+-----------+--------+



 select  CELL_XID,CELL_GROUP_XID,CONTROL_IND,COUNT(*)
                  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                       join BUNDLE_DIM bd using (bundle_key)
                       join P_CRITERIA_DIM cri using (criteria_key)
                       join p_campaign_dim using (campaign_key)
                where 1=1
                  and CELL_NM  like '%Thermador%' and CELL_KEY > 20000
Group by CELL_XID,CELL_GROUP_XID,CONTROL_IND
Order by CELL_XID;
+-----------+--------------+-----------+--------+
|CELL_XID   |CELL_GROUP_XID|CONTROL_IND|COUNT(*)|
+-----------+--------------+-----------+--------+
|AI01-THR-C2|AI-THR-01     |B          |12      |
|AI01-THR-T2|AI-THR-01     |T          |11      |
|AI02-THR-C2|AI-THR-02     |B          |30      |
|AI02-THR-T2|AI-THR-02     |T          |28      |
|AI03-THR-C2|AI-THR-03     |B          |325     |
|AI03-THR-T2|AI-THR-03     |T          |338     |
|AO01-THR-C2|AO-THR-01     |B          |368     |
|AO01-THR-T2|AO-THR-01     |T          |405     |
|AO02-THR-C2|AO-THR-01     |B          |380     |
|AO02-THR-T2|AO-THR-01     |T          |351     |
|EB01-THR-C2|EB-THR-01     |B          |21      |
|EB01-THR-T2|EB-THR-01     |T          |21      |
|EB02-THR-C2|EB-THR-02     |B          |808     |
|EB02-THR-T2|EB-THR-02     |T          |771     |
|RI05-THR-C2|RI-THR-05     |B          |27      |
|RI05-THR-T2|RI-THR-05     |T          |36      |
+-----------+--------------+-----------+--------+


select  CELL_XID,CELL_GROUP_XID,CONTROL_IND,COUNT(*)
                  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                       join BUNDLE_DIM bd using (bundle_key)
                       join P_CRITERIA_DIM cri using (criteria_key)
                       join p_campaign_dim using (campaign_key)
                where 1=1
                  and CELL_NM  like '%Thermador%' and CELL_KEY < 20000
Group by CELL_XID,CELL_GROUP_XID,CONTROL_IND
Order by CELL_XID;
+--------+--------------+-----------+--------+
|CELL_XID|CELL_GROUP_XID|CONTROL_IND|COUNT(*)|
+--------+--------------+-----------+--------+
|AI01-THR|AI-THR-01     |N          |158     |
|AI02-THR|AI-THR-02     |N          |352     |
|AI03-THR|AI-THR-03     |N          |2856    |
|AO01-THR|AO-THR-01     |N          |6019    |
|EB01-THR|EB-THR-01     |N          |217     |
|EB02-THR|EB-THR-02     |N          |4295    |
|RI03-THR|RI-THR-03     |N          |1       |
|RI04-THR|RI-THR-04     |N          |1       |
|RI05-THR|RI-THR-05     |N          |187     |
|RW03-THR|RW-THR-03     |N          |74      |
+--------+--------------+-----------+--------+
