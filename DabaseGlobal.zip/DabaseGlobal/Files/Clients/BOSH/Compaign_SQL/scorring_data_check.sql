
--Process 1

--preparedatabase():
--clean_esa_table
-- ESP_AM_SCR_INPUT_TBL
-- DEMO_DRIVER_TBL
-- ESP_AM_SCR_OUTPUT_TBL
-- ESP_AM_SCR_VAR_TBL
--ESP_AM_SCR_ERROR_TBL
select COUNT(distinct BUNDLE_KEY ),COUNT(*) from esp_am_scr_input_tbl;--78107
+-------------------------+--------+
|COUNT(DISTINCTBUNDLE_KEY)|COUNT(*)|
+-------------------------+--------+
|78107                    |78107   |
+-------------------------+--------+

 --demoappend_in(ts)
select * from demo_driver_tbl;
select COUNT(*) from demo_driver_tbl;--29731

--Process 2

--demoappend_out(
select * from BOSH.RAW_DEMO_APPEND_TBL where FILE_NM = 'EXPRESS_DATA_APPEND_bosh_esa_202411201438.CSV' order by  DBMS_RANDOM.RANDOM();--29731
select COUNT(*) from BOSH.DEMOGRAPHIC_DIM where LOAD_DT > date '2024-11-10';--29731

--Process3
select COUNT(distinct BUNDLE_KEY ) from BUNDLE_SUMMARY_TBL;--63793

select COUNT(distinct BUNDLE_KEY ) from v_sm_score_transition2;--2596307

select COUNT(distinct BUNDLE_KEY ),COUNT(*) from ESP_AM_SCR_OUTPUT_TBL;--78105
select COUNT(distinct BUNDLE_KEY ),COUNT(*) from ESP_AM_SCR_VAR_TBL;--63793
-- +-------------------------+--------+
-- |COUNT(DISTINCTBUNDLE_KEY)|COUNT(*)|
-- +-------------------------+--------+
-- |63793                    |1275860 |
-- +-------------------------+--------+

select COUNT(distinct BUNDLE_KEY ),COUNT(*) from ESP_AM_SCR_ERROR_TBL;--2

select * from ESP_AM_SCR_ERROR_TBL;--14314

select COUNT(distinct BUNDLE_KEY ),COUNT(*) from ESP_AM_SCR_OUTPUT_TBL;--78105
select REASON_TX,COUNT(*) from ESP_AM_SCR_ERROR_TBL group by REASON_TX;--2
+---------------------------------+--------+
|REASON_TX                        |COUNT(*)|
+---------------------------------+--------+
|Scoring error / missing predictor|2       |
+---------------------------------+--------+

select * from  esp_am_scr_input_tbl
where BUNDLE_KEY   in (select BUNDLE_KEY  from ESP_AM_SCR_ERROR_TBL) order by  DBMS_RANDOM.RANDOM();
--


