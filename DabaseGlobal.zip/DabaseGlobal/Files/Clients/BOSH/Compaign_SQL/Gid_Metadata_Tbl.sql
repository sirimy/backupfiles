select * from gid_metadata_tbl order by criteria_cd;

select cri.CRITERIA_XID, gid.* from gid_metadata_tbl gid left join p_CRITERIA_DIM cri on cri.CRITERIA_CD = gid.CRITERIA_CD;

select * from gid_metadata_tbl where criteria_cd LIKE 'RI%' order by 1;

SELECT distinct criteria_cd, 
        state_xid,
        CASE
            WHEN max_no_of_mailings   = SUBSTR(state_xid, instr(state_xid, '-', 1) + 1, instr(state_xid, '-', 1,2) -(instr(state_xid, '-', 1) + 1))
            AND scored_no_of_mailings = SUBSTR(state_xid, instr(state_xid, '-', 2) + 1, instr(state_xid, '-', 1,3) -(instr(state_xid, '-', 1,2) + 1))
                THEN gid_scored_append_cd
        END gid_append
FROM bundle_dim
JOIN p_criteria_dim USING (criteria_key)
JOIN gid_metadata_tbl USING (criteria_cd)
JOIN bundle_state_tbl USING (bundle_key)
JOIN p_state_tbl USING (state_machine_key, state_key)
where criteria_cd LIKE '%AI%'
;


select cri.CRITERIA_XID, gid.* from gid_metadata_tbl gid left join p_CRITERIA_DIM cri on cri.CRITERIA_CD = gid.CRITERIA_CD
where  gid.criteria_cd like 'AS%'
-- and    regexp_like(gid.criteria_cd, 'A[OGST]+')
and    cri.active_ind = 'Y';

select * from gid_metadata_tbl where criteria_cd LIKE 'AS%' and CRITERIA_CD in (select cri.CRITERIA_CD from p_CRITERIA_DIM cri where active_ind = 'Y')
order by 1;


