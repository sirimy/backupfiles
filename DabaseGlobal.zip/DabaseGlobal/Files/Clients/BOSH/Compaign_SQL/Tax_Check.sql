

select *
from (select OFFER_KEY, min(Tax_perc) as min_Tax_perc, max(Tax_perc) as max_Tax_perc
      from (select OFFER_KEY,
                   PRICE_BEFORE_DISCOUNT_AMT,
                   round(TAX_AMT, 5)                   as TAX_AMT,
                   round((TAX_AMT / PRICE_BEFORE_DISCOUNT_AMT)*100, 2) as Tax_perc
            from OFFER_ITEM_XREF
            )
       where coalesce(TAX_AMT, 0) <> 0
      group by OFFER_KEY
        )T
where  max_Tax_perc - min_Tax_perc > 0.2
ORDER BY DBMS_RANDOM.RANDOM()