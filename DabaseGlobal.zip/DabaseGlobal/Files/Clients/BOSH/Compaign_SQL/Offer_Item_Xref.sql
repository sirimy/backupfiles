select * from offer_item_xref where rownum <= 10 ;
select * from bosh.offer_xref where rownum <= 10 ;

select * from bosh.offer_item_xref where POLICY_KEY = 2900 ;

select oix.*, tr.name from bosh.offer_item_xref oix join P_POLICY_TBL pol on pol.POLICY_KEY = oix.POLICY_KEY join P_TERM_DIM tr on tr.TERM_KEY = pol.TERM_KEY
-- where OFFER_KEY IN (2481035008323)
where SI_KEY in (
2927933,
2981906,
3349341
    )
-- where OFFER_KEY in (select cp.offer_key from bosh.CAMPAIGN_PARTICIPATION_FCT cp where cp.BUNDLE_KEY = 6404928)
order by OFFER_KEY, pol.TERM_KEY nulls last, PRICE_BEFORE_DISCOUNT_AMT;

select BRAND_NM,policy_product_xid,age,tr.year,tr.name,vpr.model_no,vpr.price_amt,vpr.product_category_nm,
       trunc(creation_dt) as si_creation_dt,dd.full_dt as purchase_dt,ox.offer_start_dt,
       oix.OFFER_KEY,
       OFFER_LINE_KEY,
       oix.BUNDLE_KEY,
       SEQ_NO,
       oix.SI_KEY,
       oix.POLICY_KEY,

       COVERAGE_START_DT,
       COVERAGE_END_DT,
       PRICE_BEFORE_DISCOUNT_AMT,
       oix.TAX_AMT,
       oix.DISCOUNT_AMT,
       si.SERIAL_NO, pol.DESCRIPTION
from   P_offer_item_xref oix --join bosh.campaign_participation_fct cp  on cp.offer_key = oix.offer_key
       join p_policy_tbl pol on pol.policy_key = oix.policy_key
       join p_term_dim   tr  on tr.term_key    = pol.term_key
       join p_serialized_item_dim si on si.si_key = oix.si_key
       join fas.date_dim dd on dd.date_key = si.purchase_dt_key
       left join P_audit_tbl a on (audit_key = si.insert_audit_key)
       left join bosh.v_product vpr on vpr.product_key = si.product_key
       join P_offer_xref ox on ox.offer_key = oix.offer_key
--  where oix.offer_key = lpad(ltrim(:offer_key, '0'), '15', '0')
 where oix.offer_key IN ( 8538130006080 )
--    and vpr.MODEL_NO = 'HBL8743UC'
-- where  oix.SI_KEY = 896578
--   where ox.BUNDLE_KEY = 9148901
 order by oix.offer_key, seq_no, offer_line_key;
 
select * from P_offer_xref where offer_key = :reference_id order by offer_key; 

select * from P_offer_item_xref where offer_key = :reference_id order by offer_key;
 
 
select min(offer_start_dt),  min(offer_exp_dt), count(distinct offer_key) AS Offers, count(*) as offer_items
  from bosh.offer_xref ot join bosh.offer_item_xref oit using (offer_key)
 where 1=1
   and offer_start_dt >= date '2019-05-01' --and  > date '2016-12-01'
--   and policy_key between 2055 and 2075
   and policy_key < 500 
   --and ot.last_updated_ts >= date '2018-09-01'
 group by offer_start_dt,  offer_exp_dt  
-- having count(*) > 3
 order by offer_start_dt,  offer_exp_dt ;
 
 
 select min(offer_start_dt), count(distinct offer_key) AS Offers, count(distinct offer_key || offer_line_key) as offer_items
  from bosh.offer_xref ot join bosh.offer_item_xref using (offer_key) join bosh.campaign_participation_fct cp using (offer_key)
-- where offer_exp_dt between date '2018-11-01' and date '2018-11-30';   --9/25/2018    88748    300829
-- where offer_exp_dt between date '2018-12-01' and date '2018-12-31';   --10/23/2018    96201    321883
-- where offer_exp_dt between date '2019-01-01' and date '2019-01-31';   --11/27/2018    77197    258162
-- where offer_exp_dt between date '2019-02-01' and date '2019-02-28';   --12/25/2018    68095    228791
-- where offer_exp_dt between date '2019-03-01' and date '2019-03-31';     --0
;

select distinct oix.policy_key, tr.TERM_KEY, price_before_discount_amt,  SI_KEY, oidx.*, oix.OFFER_KEY
from   offer_item_xref oix --join v_policy_fee fee on fee.policy_key = oix.policy_key
       left join offer_item_discount_xref oidx on oidx .offer_key = oix.offer_key
       join p_policy_tbl pol on pol.POLICY_KEY = oix.POLICY_KEY
       join P_TERM_DIM tr on tr.TERM_KEY = pol.TERM_KEY
where  1=1
--and    oix.policy_key in (131)
and    bundle_key in (6602641)
-- and    oix.offer_key = '005385944001964'
order by oix.policy_key;

select * from v_offer_item_discount where OFFER_KEY = 005112278000963;
select * from v_offer_item_discount where OFFER_KEY = 005095253001747 and SI_KEY = 2334282 order by SEQ_NO, OFFER_LINE_KEY;


select * from offer_item_xref oix where oix.offer_key = '004305943001006';


select oix.policy_key, min(price_before_discount_amt), max(price_before_discount_amt)
from   offer_item_xref oix join v_policy_fee fee on fee.policy_key = oix.policy_key
       left join offer_item_discount_xref oidx on oidx .offer_key = oix.offer_key
group by oix.policy_key
having min(price_before_discount_amt) <> max(price_before_discount_amt)
or     min(discount_key) <> max(discount_key)
order by oix.policy_key;

select * from offer_item_discount_xref where rownum <= 10; 


select distinct oix.bundle_key, oix.si_key, vpr.model_no, vpr.product_category_nm, substr(GUARANTEE_ID_9, 10, 2) as campaign,
                oix.POLICY_KEY, oix.PRICE_BEFORE_DISCOUNT_AMT, tr.NAME
--        dd.full_dt as purchase_dt, si.latest_coverage_exp_dt,
--        trunc(COVERAGE_START_DT) as COVERAGE_START_DT, trunc(COVERAGE_END_DT) as COVERAGE_END_DT
--        ,trunc(oix.COVERAGE_END_DT) - dd.full_dt, six.SOURCE
from   offer_item_xref oix join OFFER_XREF ox on ox.OFFER_KEY = oix.OFFER_KEY
       join v_policy_fee fee on fee.policy_key = oix.policy_key
       join p_serialized_item_dim si on si.si_key = oix.si_key
       left join P_SERIALIZED_ITEM_EXT_DIM six on six.SI_KEY = si.SI_KEY
       join fas.date_dim dd on dd.date_key = si.purchase_dt_key
       left join P_audit_tbl a on (audit_key = si.insert_audit_key)
       left join bosh.v_product vpr on vpr.product_key = si.product_key
       join BUNDLE_DIM bd on bd.BUNDLE_KEY = ox.BUNDLE_KEY
       join p_policy_tbl pol on pol.POLICY_KEY = oix.POLICY_KEY
       join p_term_dim tr on tr.TERM_KEY = pol.TERM_KEY
where  1=1
--and    oix.policy_key in (131)
--  and oix.BUNDLE_KEY in (5112278)
-- and oix.OFFER_KEY = 005385944001964
  and vpr.MODEL_NO = 'HBL8453UC'
  and substr(GUARANTEE_ID_9, 10, 2) = 'AO'
  and oix.POLICY_KEY not in (
810,
820,
830
)
--   and  (
--         (BRAND_NM = 'Bosch' and trunc(oix.COVERAGE_END_DT) - dd.full_dt > (365*7) + 2)
--          or
--         (BRAND_NM = 'Thermador' and trunc(oix.COVERAGE_END_DT) - dd.full_dt > (365*7) + 2)
--        )
-- order by oix.bundle_key, oix.si_key
;



--one si_key should not appear in more han 1 bundle in a given pull
select si_key, count(distinct bundle_key) from offer_item_xref group by si_key having count(distinct bundle_key) >= 2;


--checking offers, which were updated/suppressed by dupe leads process
select distinct creation_dt, oit.si_key, duplicate_ind, latest_coverage_type, substr(guarantee_id_9, 10, 2) as campaign, substr(guarantee_id_9, 7, 3) as brand, ot.*, a.DESCRIPTIVE_TX
  from bosh.offer_xref ot join bosh.offer_item_xref oit on (oit.offer_key = ot.offer_key)
       join P_audit_tbl a on (audit_key = ot.update_audit_key)
       join bosh.serialized_item_dim si on si.si_key = oit.si_key
       join bosh.serialized_item_ext_dim six on six.si_key = si.si_key
       join bosh.bundle_dim bd on bd.bundle_key = ot.bundle_key
 where 1=1
   and creation_dt >= date '2020-03-01'
order by a.creation_dt desc;


select pricing_scheme_key, pricing_scheme_desc,  count(distinct boix.term_key), count(*)
from   offer_item_xref oix join bosh.BASE_OFFER_ITEM_XREF boix
          on boix.BUNDLE_KEY = oix.BUNDLE_KEY and boix.SI_KEY = oix.SI_KEY and boix.POLICY_KEY = oix.POLICY_KEY
       join p_pricing_scheme_dim psd using (pricing_scheme_key)
 group by pricing_scheme_key, pricing_scheme_desc
 order by pricing_scheme_key;
/*PRICING_SCHEME_KEY,PRICING_SCHEME_DESC,COUNT(DISTINCTBOIX.TERM_KEY),COUNT(*)
57,AM Thermador,2,10984
58,AM Bosh,3,101634
59,EB Thermador,2,12114
60,EB Bosh,3,43804
*/

select pricing_scheme_key, pricing_scheme_desc,  count(distinct boix.term_key), count(*)
from   offer_item_xref oix join BASE_OFFER_ITEM_XREF boix
          on boix.BUNDLE_KEY = oix.BUNDLE_KEY and boix.SI_KEY = oix.SI_KEY and boix.POLICY_KEY = oix.POLICY_KEY
       join p_pricing_scheme_dim psd using (pricing_scheme_key)
 group by pricing_scheme_key, pricing_scheme_desc
 order by pricing_scheme_key;
/*PRICING_SCHEME_KEY,PRICING_SCHEME_DESC,COUNT(DISTINCTBOIX.TERM_KEY),COUNT(*)
75,AM Thermador,4,13529
76,AM Bosh,4,84921
77,EB Thermador,4,6844
78,EB Bosh,4,50544
*/


select * from bosh.V_SYNC_OFFER_ITEM_XREF where OFFER_ID = 005234100001792;
select * from bosh.V_OFFER_ITEM_DISCOUNT where OFFER_KEY = 005234100001792;

select * from p_discount_dim;
select * from bosh.offer_item_discount_xref where OFFER_KEY = 005234100001792;

select distinct psd.PRICING_SCHEME_DESC, v.PRICING_SCHEME_KEY,
       POLICY_KEY,
       TERM_KEY,
       SI_CNT,
       PRICE_BEFORE_DISCOUNT_AMT,
       DISCOUNT_TYPE_CD,
       DISCOUNT_KEY,
       TERM_MONTHS_NO,
       TERM_DAY,
       DELAY_DAYS
from V_PRICE_LKP v join bosh.PRICING_SCHEME_DIM psd on psd.PRICING_SCHEME_KEY = v.PRICING_SCHEME_KEY
where v.PRICING_SCHEME_KEY > 60 and POLICY_KEY = 443
order by TERM_KEY, SI_CNT, DISCOUNT_TYPE_CD, v.PRICING_SCHEME_KEY;


select distinct substr(GUARANTEE_ID_9, 10, 2) as campaign, pol.TERM_KEY, oix.*, ox.*
from   offer_item_xref oix --join v_policy_fee fee on fee.policy_key = oix.policy_key
       join OFFER_XREF ox on ox .offer_key = oix.offer_key
       join p_policy_tbl pol on pol.POLICY_KEY = oix.POLICY_KEY
       join P_TERM_DIM tr on tr.TERM_KEY = pol.TERM_KEY
       join p_bundle_dim bd on bd.BUNDLE_KEY = oix.BUNDLE_KEY
where  1=1
--and    oix.policy_key in (131)
-- and    oix.bundle_key in (6602641)
and substr(GUARANTEE_ID_9, 10, 2) not in ('AO', 'RS', 'RW')
and COVERAGE_START_DT is null;
-- order by pol.TERM_KEY

select CAMPAIGN_NM, CAMPAIGN_DSC, CELL_NM, OFFER_START_DT, six.source, six.REGISTRATION_DT

from   p_offer_item_xref oix join p_offer_xref using (offer_key)

       join p_CAMPAIGN_PARTICIPATION_FCT cp using (offer_key)

--        join BUNDLE_DIM bd using (bundle_key)

       join p_CELL_DIM cl using (cell_key)

       join p_cell_group_dim using (cell_group_key)

       join P_CAMPAIGN_DIM using (campaign_key)

       join P_SERIALIZED_ITEM_EXT_DIM six on six.SI_KEY = oix.SI_KEY

where OFFER_START_DT >= date '2025-04-16';