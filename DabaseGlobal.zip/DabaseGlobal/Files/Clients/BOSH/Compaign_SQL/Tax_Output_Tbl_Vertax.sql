select * from (select * from VERTEX_OUTPUT_TBL order by DBMS_RANDOM.RANDOM()) where rownum <= 20 ;

select * from (select * from bosh.tax_output_tbl_vertax order by DBMS_RANDOM.RANDOM()) where rownum <= 10 ;

select 'Input', count(*), count(distinct UNIQUE_ROW_IDENTIFIER), max(TAX_DT) from TAX_INPUT_TBL_VERTAX
union all
select 'Input', count(*), count(distinct UNIQUE_ROW_IDENTIFIER), max(to_date(TAX_DT, 'MM/DD/YYYY')) from v_vertex_input
union all
select 'Output', count(*), count(distinct "Document Number"), max(to_date("Document Date", 'MM/DD/YYYY')) from VERTEX_OUTPUT_TBL
union all
select 'Output', count(*), count(distinct DOCUMENT_NUMBER), max(DOCUMENT_DATE) from TAX_OUTPUT_TBL_VERTAX ;

select "Results", count(*) from VERTEX_OUTPUT_TBL group by "Results";

select Results, count(*) from TAX_OUTPUT_TBL_VERTAX group by Results;

select Results, count(*) from P_TAX_OUTPUT_TBL_VERTAX group by Results;

select Results, PHYS_ORIGIN_TAID, count(*) from P_TAX_OUTPUT_TBL_VERTAX group by Results, PHYS_ORIGIN_TAID order by Results;


select * from v_tax_output_tbl_vertax
 where 1=1
   and offer_key in (
        '007937917071392',
        '008239432073064',
        '008173154001017')
--     and SI_KEY = 3027586
 order by si_key, DOCUMENT_DATE, term_key;

select * from tax_output_tbl_vertax where Results <> 'Success';

select DESTINATION_COUNTRY, psd.COUNTRY_ISO, DESTINATION_STATE, psd.postal_state_cd, count(tx.document_number) 
from   TAX_OUTPUT_TBL_VERTAX tx
       LEFT JOIN p_postal_state_dim psd on psd.postal_state_cd = tx.DESTINATION_STATE 
--where  
--       psd.postal_state_cd is null       
group by DESTINATION_COUNTRY, psd.COUNTRY_ISO, DESTINATION_STATE, psd.postal_state_cd
order by DESTINATION_COUNTRY, psd.COUNTRY_ISO, DESTINATION_STATE;



select DESTINATION_COUNTRY, DESTINATION_STATE, count(tx.document_number), count(case when nvl(TOTAL_TAX_AMOUNT, 0) > 0 then 1 end) as tax_counts
       ,round((TOTAL_TAX_AMOUNT/UNIT_PRICE)*100, 2) as "Tax%"
from   TAX_OUTPUT_TBL_VERTAX tx
       LEFT JOIN p_postal_state_dim psd on psd.postal_state_cd = tx.DESTINATION_STATE 
where  
       Results = 'Success'
group by DESTINATION_COUNTRY, DESTINATION_STATE, round((TOTAL_TAX_AMOUNT/UNIT_PRICE)*100, 2)
order by DESTINATION_COUNTRY, DESTINATION_STATE;

select DESTINATION_COUNTRY, count(*) from TAX_OUTPUT_TBL_VERTAX group by DESTINATION_COUNTRY;

select count(*) from TAX_INPUT_TBL_VERTAX
union all
select count(*) from TAX_OUTPUT_TBL_VERTAX;
/*376865
376865
*/

select * from TAX_INPUT_TBL_VERTAX
where UNIQUE_ROW_IDENTIFIER not in (select DOCUMENT_NUMBER from TAX_OUTPUT_TBL_VERTAX o)
order by UNIQUE_ROW_IDENTIFIER;

select * from tax_output_tbl where rownum <= 5 ;

select * from v_base_offer_item_discount where rownum <= 5 ;
select * from v_base_offer_item_xref where rownum <= 5 ;
select * from v_base_offer_item_disc_xref where rownum <= 5 ;

select count(*) from v_base_offer_item_xref;
--3980054



select min(Tax_rate), max(Tax_rate)
  from (
        select distinct DESTINATION_STATE, DESTINATION_CITY                
               ,DESTINATION_STREET_ADDRESS, DESTINATION_ZIP
               ,STATE_TAX, COUNTY_TAX, CITY_TAX, OTHER_TAXES
               ,round((TOTAL_TAX_AMOUNT/UNIT_PRICE)*100, 2) as Tax_rate
        from   TAX_OUTPUT_TBL_VERTAX tx
               LEFT JOIN p_postal_state_dim psd on psd.postal_state_cd = tx.DESTINATION_STATE 
        where  
               Results = 'Success'
          and DESTINATION_STATE in ('CT', 'NY')
        --order by DESTINATION_STATE, DESTINATION_CITY 
)
where 
--       (DESTINATION_STATE = 'CT' and Tax_rate <> 6.35)
--       or
       DESTINATION_STATE = 'NY'
--order by DESTINATION_STATE, DESTINATION_CITY       
order by dbms_random.random;     



select distinct DESTINATION_STATE, DESTINATION_CITY                
       ,DESTINATION_STREET_ADDRESS, DESTINATION_ZIP
       ,UNIT_PRICE, STATE_TAX, COUNTY_TAX, CITY_TAX, OTHER_TAXES
       ,round((TOTAL_TAX_AMOUNT/UNIT_PRICE)*100, 2) as Tax_rate
from   TAX_OUTPUT_TBL_VERTAX tx
       LEFT JOIN p_postal_state_dim psd on psd.postal_state_cd = tx.DESTINATION_STATE 
where  
       Results = 'Success'
  and DESTINATION_STATE = 'NY' 
order by dbms_random.random;     



select count(*), count(distinct offer_key) from (
        select offer_key, term_key, si_key from v_TAX_INPUT_TBL_VERTAX
        minus
        select offer_key, term_key, si_key from v_tax_output_tbl_vertax
        );
        

select * from v_TAX_INPUT_TBL_VERTAX where offer_key in (
        select offer_key from v_TAX_INPUT_TBL_VERTAX
        minus
        select offer_key from v_tax_output_tbl_vertax
        )
order by offer_key, si_key, term_key;


select six.source, count(*), count(distinct ti.si_key) --ti.* 
from v_TAX_INPUT_TBL_VERTAX ti
         left join P_serialized_item_ext_dim six on six.si_key = ti.si_key 
where (offer_key, term_key, ti.si_key) in (
        select offer_key, term_key, si_key from v_TAX_INPUT_TBL_VERTAX
        minus
        select offer_key, term_key, si_key from v_tax_output_tbl_vertax
        ) 
group by six.source        
--order by offer_key, ti.si_key, term_key
;

select six.source, ti.* 
from v_TAX_INPUT_TBL_VERTAX ti
         left join P_serialized_item_ext_dim six on six.si_key = ti.si_key 
where (offer_key, term_key, ti.si_key) in (
        select offer_key, term_key, si_key from v_TAX_INPUT_TBL_VERTAX
        minus
        select offer_key, term_key, si_key from v_tax_output_tbl_vertax
        ) 
order by offer_key, ti.si_key, term_key
;


select distinct vti.ADDRESS_LINE1_TX, vti.ADDRESS_LINE2_TX, adr.source_cd
from v_TAX_INPUT_TBL_VERTAX vti join CAMPAIGN_PARTICIPATION_FCT cp on cp.OFFER_KEY = vti.OFFER_KEY
       join bosh.ADDRESS_DIM adr on adr.ADDRESS_KEY = cp.ADDRESS_KEY
where vti.offer_key in (
        select offer_key from v_TAX_INPUT_TBL_VERTAX
        minus
        select offer_key from v_tax_output_tbl_vertax
        )
order by vti.ADDRESS_LINE1_TX;


-- delete from boshStg.tax_output_tbl_vertax;
-- commit;


                   --State tax mismatch - USA
                   insert into SUPPRESSION_TBL (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
                   select distinct BUNDLE_KEY, 'T', sysdate, 'Tax exceptions - USA'
                      FROM  campaign_spool_file_tbl spl
                            join p_state_tax_status_dim stx on stx.STATE_CD = spl.STATE_CD
                     WHERE (
                          (stx.Taxable_Status in ('Taxable') and coalesce(TAX_1YR_AMT, 0) = 0)    --'Partially taxable (local tax only)'
                           or
                          (stx.Taxable_Status = 'Non-Taxable' and coalesce(TAX_1YR_AMT, 0) > 0)
                           )
                     AND   stx.COUNTRY_CD = 'USA'
                     and   spl.BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup);


--Clean-up dupes
/*
 delete from VERTEX_OUTPUT_TBL
 where ("Document Number") IN (
            select t1."Document Number"
              from VERTEX_OUTPUT_TBL t1
             group by t1."Document Number"
             having count(*) >= 2
            )
   and rowid NOT IN (
            select min(rowid)
            from VERTEX_OUTPUT_TBL t2
             group by t2."Document Number"
             having count(*) >= 2
            );
--607656
commit ;
 */
select * from v_TAX_INPUT_TBL_VERTAX vt;
select * from V_TAX_OUTPUT_TBL_VERTAX vt;
select *
from v_TAX_INPUT_TBL_VERTAX vi join V_TAX_OUTPUT_TBL_VERTAX vo on vo.OFFER_KEY = vi.OFFER_KEY
where (vi.STATE_CD <> vo.DESTINATION_STATE or vi.CITY_NM <> vo.DESTINATION_CITY or vi.ADDRESS_LINE1_TX <> vo.DESTINATION_STREET_ADDRESS);
--242 rows