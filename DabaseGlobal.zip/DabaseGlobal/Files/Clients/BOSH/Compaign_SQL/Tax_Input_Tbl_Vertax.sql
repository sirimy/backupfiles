select * from (select * from tax_input_tbl_vertax order by DBMS_RANDOM.RANDOM()) where rownum <= 10 ;
select * from (select * from bosh.tax_input_tbl_vertax order by DBMS_RANDOM.RANDOM()) where rownum <= 10 ;

select * from v_tax_input_tbl_vertax where offer_key in (
        '007937917071392',
        '008239432073064',
        '008173154001017'
    ) order by si_key, term_key;


select * from tax_input_tbl_vertax where replace(ADDRESS_LINE1_TX, '-') is null and rownum <= 50 ;
select count(*) from tax_input_tbl_vertax where replace(ADDRESS_LINE1_TX, '-') is null or CITY_NM is null;

select * from v_tax_input_tbl_vertax where rownum <= 5 ;

select * from P_TAX_INPUT_TBL_VERTAX where rownum <= 5 ;
select count(*) from P_TAX_INPUT_TBL_VERTAX where TAX_DT >= date '2020-11-01';
--535166

select count(*) from campaign_participation_fct 
union all
select count(*) from tax_input_tbl_vertax
union all
select count(distinct offer_key) from v_tax_input_tbl_vertax;;
/*167163
334060
*/


--rename tax_input_tbl to tax_input_tbl_o;
--
--rename tax_output_tbl to tax_output_tbl_o;


select count(*), count(distinct UNIQUE_ROW_IDENTIFIER) from tax_input_tbl_vertax
union all
select count(*), count(distinct Document_Number)  from TAX_OUTPUT_TBL_VERTAX;
--records were missing in 1st pull and thats because a large number of records failed during file load and that has been fixed now. 


select UNIQUE_ROW_IDENTIFIER from tax_input_tbl_vertax where UNIQUE_ROW_IDENTIFIER is not null
minus
select Document_Number from TAX_OUTPUT_TBL_VERTAX where Document_Number is not null;
--no rows --good

select Document_Number from TAX_OUTPUT_TBL_VERTAX where Document_Number is not null
minus
select UNIQUE_ROW_IDENTIFIER from tax_input_tbl_vertax where UNIQUE_ROW_IDENTIFIER is not null;


select Document_Number, count(*) from TAX_OUTPUT_TBL_VERTAX group by Document_Number having count(*) >= 2;

select * from v_tax_input_tbl_vertax where ADDRESS_LINE1_TX like '%,%' or nvl(ADDRESS_LINE2_TX, 'x') like '%,%';

select 'Input', count(*) from TAX_INPUT_TBL_VERTAX
union all
select 'Output', count(*) from TAX_OUTPUT_TBL_VERTAX ;


--Verify input address as sometimes address is blank
select distinct ADDRESS_LINE1_TX, ADDRESS_LINE2_TX
--         , six.source
from v_tax_input_tbl_vertax vto join bosh.SERIALIZED_ITEM_EXT_DIM six on six.SI_KEY = vto.SI_KEY
where ADDRESS_LINE1_TX like '%,%' or nvl(ADDRESS_LINE2_TX, 'x') like '%,%';