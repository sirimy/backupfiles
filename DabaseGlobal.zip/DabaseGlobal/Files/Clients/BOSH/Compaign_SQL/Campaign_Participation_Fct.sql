select t.*, round((t.cell_total/t.criteria_total), 2) as "%"  from
(select cell_group_nm, bd.CRITERIA_KEY, cri.CRITERIA_XID, cell_nm, cell_key, CONTROL_IND
       ,count(distinct cp.bundle_key) as Bundles, state_machine_nm, EFFORT_NO, STATE_CATEGORY_CD,
       sum(count(distinct cp.BUNDLE_KEY)) over(partition by CELL_KEY) as cell_total,
       sum(count(distinct cp.BUNDLE_KEY)) over(partition by bd.criteria_key) as criteria_total
  from campaign_participation_fct cp join p_cell_dim c using (cell_key) join p_state_tbl s using (state_key)
       JOIN p_state_machine_tbl s using (state_machine_key)
       JOIN p_cell_group_dim cgd ON (cgd.cell_group_key = c.cell_group_key)
       JOIN p_message_dim m ON (m.message_key = cp.message_key --and m.channel_key = 1
           )
       JOIN BUNDLE_DIM bd on bd.BUNDLE_KEY = cp.BUNDLE_KEY
       JOIN P_CRITERIA_DIM cri on cri.CRITERIA_KEY = bd.CRITERIA_KEY
 where 1=1
--   and cell_nm not like '%Gaggenau' --and CELL_GROUP_NM not like 'R%'
--   and cell_nm like '%Thermador%'
--   and cell_nm like '%Bosch%'
--   and state_machine_key >= 17122
--    and CRITERIA_XID like 'AS%'
--   and CONTROL_IND in ('B', 'T')
   and cri.ACTIVE_IND = 'Y'
   and bd.CRITERIA_KEY IN (--this condition is reqd if we want to check test/control split
                      select ccx.CRITERIA_KEY from P_CRITERIA_CELL_XREF ccx
                      where  nvl(ccx.POPULATION_PCT, 1) <> 0
                      --group by ccx.CRITERIA_KEY having count(*) >= 2
                 )
   and cp.BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
 group by cell_group_nm, bd.CRITERIA_KEY, CRITERIA_XID, cell_nm, cell_key, CONTROL_IND, state_machine_nm, EFFORT_NO, STATE_CATEGORY_CD
) t
 order by cell_group_nm, CRITERIA_XID, CRITERIA_KEY, EFFORT_NO, cell_nm, CONTROL_IND, STATE_CATEGORY_CD;


select cell_group_nm, cell_nm, CONTROL_IND, count(*), count(distinct bundle_key), state_machine_nm
  from campaign_participation_fct cp join p_cell_dim c using (cell_key) join p_state_tbl s using (state_key)
    join p_state_machine_tbl s using (state_machine_key)
       JOIN p_cell_group_dim cgd ON (cgd.cell_group_key = c.cell_group_key)
       JOIN p_message_dim m ON (m.message_key = cp.message_key and m.channel_key = 1)
       join BUNDLE_ITEM_XREF using (bundle_key)
 where cell_nm like '%Gaggenau'
 group by cell_group_nm, cell_nm, CONTROL_IND, state_machine_nm
 order by cell_group_nm, cell_nm, CONTROL_IND;


--select * from  bundle_state_tbl;
select count(distinct bundle_key), state_nm, full_dt
  from p_bundle_state_tbl bs join p_state_tbl s using (state_key)
       join fas.date_dim dd on (dd.date_key = bs.date_key)
 where bundle_key IN 
          (select cp.bundle_key
             from p_campaign_participation_fct cp join p_cell_dim c using (cell_key)
            where cell_nm like '%Sweep%'
          minus
          select cp2.bundle_key
             from campaign_participation_fct cp2 join p_cell_dim c using (cell_key)
            where cell_nm like '%Sweep%'  
          )  
--   and bundle_key IN 
--          (select cp.bundle_key
--             from campaign_participation_fct cp join p_cell_dim c using (cell_key)
--            where cell_nm like '%Sweep%'
--          )            
 group by state_nm, full_dt;


select cmp.CAMPAIGN_KEY, CAMPAIGN_NM, cell_group_nm, cell_nm, CONTROL_IND, count(*), count(distinct bundle_key), state_machine_nm
  from p_campaign_participation_fct cp join p_cell_dim c using (cell_key) join p_state_tbl s using (state_key)
    join p_state_machine_tbl s using (state_machine_key)
       JOIN p_cell_group_dim cgd ON (cgd.cell_group_key = c.cell_group_key)
       JOIN p_message_dim m ON (m.message_key = cp.message_key and m.channel_key = 1)
       JOIN P_campaign_dim cmp on cmp.CAMPAIGN_KEY = cgd.CAMPAIGN_KEY
       join date_dim dd on dd.DATE_KEY = cp.DATE_KEY
 where cell_nm like '%Bosch'
   and dd.FULL_DT >= date '2021-12-16'
 group by cmp.CAMPAIGN_KEY, CAMPAIGN_NM, cell_group_nm, cell_nm, CONTROL_IND, state_machine_nm
 order by cmp.CAMPAIGN_KEY, CAMPAIGN_NM, cell_group_nm, cell_nm, CONTROL_IND;


select cmp.CAMPAIGN_KEY, CAMPAIGN_NM, cell_group_nm, cell_nm, CONTROL_IND, state_machine_nm, DROP_DT, EFFORT_NO, CELL_KEY
  from p_campaign_participation_fct cp join p_cell_dim c using (cell_key) join p_state_tbl s using (state_key)
    join p_state_machine_tbl s using (state_machine_key)
       JOIN p_cell_group_dim cgd ON (cgd.cell_group_key = c.cell_group_key)
       JOIN p_message_dim m ON (m.message_key = cp.message_key and m.channel_key = 2)
       JOIN P_campaign_dim cmp on cmp.CAMPAIGN_KEY = cgd.CAMPAIGN_KEY
       JOIN P_TIMING_DIM tm on tm.TIMING_KEY = cp.TIMING_KEY
 where CELL_KEY = 1011 and s.EFFORT_NO = 1
   and DROP_DT >= date '2021-02-01';


select count(*), count(distinct BUNDLE_KEY) from campaign_participation_fct;

select CAMPAIGN_NM, CAMPAIGN_DSC, CELL_NM, OFFER_START_DT, six.source, six.REGISTRATION_DT

from   p_offer_item_xref oix join p_offer_xref using (offer_key)

       join p_CAMPAIGN_PARTICIPATION_FCT cp using (offer_key)

--        join BUNDLE_DIM bd using (bundle_key)

       join p_CELL_DIM cl using (cell_key)

       join p_cell_group_dim using (cell_group_key)

       join P_CAMPAIGN_DIM using (campaign_key)

       join P_SERIALIZED_ITEM_EXT_DIM six on six.SI_KEY = oix.SI_KEY

where OFFER_START_DT >= date '2025-04-16';