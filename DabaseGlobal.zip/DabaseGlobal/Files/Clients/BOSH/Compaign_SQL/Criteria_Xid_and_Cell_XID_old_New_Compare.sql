
Select * from (
            Select CR.CRITERIA_XID AS CR_XID,CD.CONTROL_IND  AS CNI ,cd.CELL_XID,PSD.PRICING_SCHEME_DESC AS TYPE,ccX.POPULATION_PCT AS PCT from BOSH.CRITERIA_CELL_XREF CCX
                 JOIN AUDIT_TBL ATB on CCX.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                 JOIN BOSH.CELL_DIM cd ON CD.CELL_KEY = CCX.CELL_KEY
                 JOIN v_criteria_lkp CR ON CR.CRITERIA_KEY = CCX.CRITERIA_KEY
                 JOIN BOSH.PRICING_SCHEME_DIM PSD ON PSD.PRICING_SCHEME_KEY = CCX.PRICING_SCHEME_KEY
        where ATB.CREATION_DT > date '2024-03-06'
        ) T1
   LEFT JOIN  (
            Select CR.CRITERIA_XID AS CR_XID ,CD.CONTROL_IND AS CNI ,cd.CELL_XID,PSD.PRICING_SCHEME_DESC AS TYPE,ccX.POPULATION_PCT AS PCT  from
                            ( Select CCX1.POPULATION_PCT,CCX1.INSERT_AUDIT_KEY,CCX1.CELL_KEY,CCX1.CRITERIA_KEY ,CCX1.PRICING_SCHEME_KEY
                                , ROW_NUMBER() OVER( PARTITION BY CR1.CRITERIA_XID ORDER BY CCX1.CRITERIA_KEY desc) as SEQ_NO
                              from BOSH.CRITERIA_CELL_XREF CCX1
                                  JOIN AUDIT_TBL ATB1 on CCX1.INSERT_AUDIT_KEY = ATB1.AUDIT_KEY
                                  JOIN v_criteria_lkp CR1 ON CR1.CRITERIA_KEY = CCX1.CRITERIA_KEY
                                   where ATB1.CREATION_DT < date '2024-03-06'
                              )
                            CCX
                             JOIN AUDIT_TBL ATB on CCX.INSERT_AUDIT_KEY = ATB.AUDIT_KEY
                             JOIN BOSH.CELL_DIM cd ON CD.CELL_KEY = CCX.CELL_KEY
                             JOIN v_criteria_lkp CR ON CR.CRITERIA_KEY = CCX.CRITERIA_KEY
                             JOIN BOSH.PRICING_SCHEME_DIM PSD ON PSD.PRICING_SCHEME_KEY = CCX.PRICING_SCHEME_KEY
                    where ATB.CREATION_DT < date '2024-03-06' AND CCX.SEQ_NO = 1
        ) T2 ON T1.CR_XID =T2.CR_XID
ORDER BY T1.CR_XID
;