

SELECT COUNT (*) ct, 'bundle_dim' FROM bundle_dim UNION ALL
SELECT COUNT (*) ct, 'bundle_item_xref' FROM bundle_item_xref UNION ALL
SELECT COUNT (*) ct, 'cell_selection_fct' FROM cell_selection_fct UNION ALL
SELECT COUNT (*) ct, 'base_offer_xref' FROM base_offer_xref UNION ALL
SELECT COUNT (*) ct, 'base_offer_item_xref' FROM base_offer_item_xref UNION ALL
SELECT COUNT (*) ct, 'base_offer_item_discount_xref' FROM base_offer_item_discount_xref UNION ALL
SELECT COUNT (*) ct, 'base_offer_discount_xref' FROM base_offer_discount_xref
UNION ALL
SELECT COUNT (*) ct, 'bundle_state_tbl' FROM bundle_state_tbl UNION ALL
SELECT COUNT (*) ct, 'bundle_transition_hist' FROM bundle_transition_hist
UNION ALL
SELECT COUNT (*) ct, 'campaign_participation_fct' FROM campaign_participation_fct
UNION ALL
SELECT COUNT (*) ct, 'offer_xref' FROM offer_xref UNION ALL
SELECT COUNT (*) ct, 'offer_item_xref' FROM offer_item_xref UNION ALL
SELECT COUNT (*) ct, 'offer_discount_xref' FROM offer_discount_xref UNION ALL
SELECT COUNT (*) ct, 'offer_item_discount_xref' FROM offer_item_discount_xref UNION ALL
SELECT COUNT (*) ct, 'offer_quickreg_xref' FROM offer_quickreg_xref
UNION ALL
SELECT COUNT (*) ct, 'campaign_spool_file_tbl' FROM campaign_spool_file_tbl UNION ALL
SELECT COUNT (*) ct, 'campaign_spool_seed_tbl' FROM campaign_spool_seed_tbl
UNION ALL
SELECT COUNT (*) ct, 'tax_input_tbl_vertax' FROM tax_input_tbl_vertax UNION ALL
SELECT COUNT (*) ct, 'tax_output_tbl_vertax' FROM tax_output_tbl_vertax
UNION ALL
SELECT COUNT(*) ct, 'ESP_AM_SCR_INPUT_TBL' FROM ESP_AM_SCR_INPUT_TBL UNION ALL
SELECT COUNT(*) ct, 'ESP_AM_SCR_OUTPUT_TBL' FROM ESP_AM_SCR_OUTPUT_TBL UNION ALL
SELECT COUNT(*) ct, 'ESP_AM_SCR_ERROR_TBL' FROM ESP_AM_SCR_ERROR_TBL UNION ALL
SELECT COUNT(*) ct, 'ESP_AM_SCR_VAR_TBL' FROM ESP_AM_SCR_VAR_TBL UNION ALL
SELECT COUNT(*) ct, 'BUNDLE_SUMMARY_TBL' FROM BUNDLE_SUMMARY_TBL
;