select t.*, round((t.cell_total/t.criteria_total), 2) as "%"  from
(select campaign_xid, cell_group_key, cell_group_nm, criteria_key, CRITERIA_XID, CELL_KEY, CELL_XID, cell_nm, --replace(replace(CELL_NM, 'Control'), 'Test') as cell_nm,
        CONTROL_IND, count(*) as cell_total, sum(count(*)) over(partition by criteria_key) as criteria_total
  from cell_selection_fct
      join p_cell_dim using (cell_key)
      join p_cell_group_dim using (cell_group_key)
       join BUNDLE_DIM bd using (bundle_key)
       join P_CRITERIA_DIM cri using (criteria_key)
       join p_campaign_dim using (campaign_key)
where 1=1 AND cell_nm like '%Thermador%' --and CONTROL_IND = 'T'
--  and CELL_GROUP_NM like '%Aftermarket OOW Sweep 1 Effort%'
-- and CELL_GROUP_XID like 'AS%'
--  where CELL_NM not like '%Gaggenau'
--    and CAMPAIGN_XID like 'RI%'
--    and (criteria_cd like 'RI06%' or criteria_cd like 'RI07%')
--  where cri.SCORING_FILE_CD is not null
--   and CRITERIA_KEY IN (
--                       select ccx.CRITERIA_KEY from P_CRITERIA_CELL_XREF ccx
--                       where  nvl(ccx.POPULATION_PCT, 1) <> 0
--                       --group by ccx.CRITERIA_KEY having count(*) >= 2
--                  )
--    and BUNDLE_KEY not in (select sup.BUNDLE_KEY from SUPPRESSION_TBL sup)
 group by campaign_xid, cell_group_key, cell_group_nm, criteria_key, CRITERIA_XID, CELL_KEY, CELL_XID, cell_nm, CONTROL_IND
) t
-- where CRITERIA_XID like 'AO%BSH%'
 order by campaign_xid, CRITERIA_XID, criteria_key, cell_nm, CELL_KEY, CONTROL_IND;  --cell_group_nm, cell_group_key,
 

select campaign_xid, count(*), sum(count(*)) over() as total
  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
       --left join fas.date_dim using (date_key)
       join p_campaign_dim using (campaign_key)
 group by campaign_xid
 order by campaign_xid;
 
 
select cell_group_key, cell_group_nm, CELL_KEY, replace(replace(CELL_NM, 'Control'), 'Test'), CONTROL_IND, count(*)
       ,sum(count(*)) over(partition by  cell_group_key ) as grp_cnt
  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
       left join fas.date_dim using (date_key)
 group by cell_group_key, cell_group_nm, CELL_KEY, replace(replace(CELL_NM, 'Control'), 'Test'), CONTROL_IND
 order by cell_group_nm, replace(replace(CELL_NM, 'Control'), 'Test'), CELL_KEY, CONTROL_IND; 
 
 
select cell_group_key, cell_group_nm, CONTROL_IND, count(*)
       ,sum(count(*)) over(partition by  cell_group_key ) as grp_cnt
  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
       left join fas.date_dim using (date_key)
 group by cell_group_key, cell_group_nm, CONTROL_IND
 order by cell_group_nm, CONTROL_IND; 

select DATE_KEY, full_dt, count(*) from CELL_SELECTION_FCT cs join DATE_DIM dd using (DATE_KEY)
 group by  DATE_KEY, full_dt order by DATE_KEY;


select CRITERIA_CD, CRITERIA_XID, count(*)
  from bundle_dim bd
       join bundle_item_xref bix
          on bix.bundle_key = bd.bundle_key
       join bosh.criteria_dim cri on cri.CRITERIA_KEY = bd.CRITERIA_KEY
       --join CELL_SELECTION_FCT cs on cs.BUNDLE_KEY = bd.BUNDLE_KEY
 where 1=1
--    and drop_dt >= date '2020-03-01'
   and bd.suppression_cd is null
--    and bix.suppression_cd is null
--    and criteria_cd like 'R%'
   and criteria_xid like '%BSH%'
group by CRITERIA_CD, CRITERIA_XID
order by CRITERIA_CD, CRITERIA_XID;