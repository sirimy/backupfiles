select * from bosh.guard_condition_tbl order by guard_condition_key;

select * from bosh.guard_condition_tbl where upper(guard_condition_nm) like '%EMAIL%' order by guard_condition_nm;
select * from bosh.guard_condition_tbl where guard_condition_nm like 'STREAM%' order by guard_condition_nm;
select * from bosh.guard_condition_tbl where guard_condition_nm like 'SCORE%' order by guard_condition_nm;

select * from bosh.guard_condition_tbl 
 where guard_condition_key IN ( --1002, 1027, 1039, 1036
         1039
       );

select * from p_guard_condition_tbl where guard_condition_nm IN ('Mail and Email', 'Mail', 'Email');
select * from guard_condition_tbl where guard_condition_nm = 'Exit' and upper(sql_tx) not like '%FLEX%';


select bundle_key from v_sm_stream_transition ;
select bundle_key from v_sm_suppress_tansition;
select * from v_suppressioN_tbl;


select * from user_views 
 where view_name like 'V_SM%';
 
select * from V_SM_WAIT_TRANSITION;
select * from V_SM_SUPPRESS_TANSITION;
select * from V_SM_STREAM_TRANSITION;
select * from V_SM_SCORE_TRANSITION;
select bundle_key from v_sm_score_transition2;
select * from V_SM_MAIL_TANSITION;
select * from V_SM_MAIL_EMAIL_TANSITION;
select * from V_SM_EMAIL_TANSITION ;
;

select 0 as bundle_key from dual where 1 = 2;   


select * from guard_condition_tbl where guard_condition_nm = 'Email';

select  1 as bundle_key from dual where 1 = 2;

--update guard_condition_tbl set GUARD_CONDITION_NM = 'Dummy Condition ' where guard_condition_key = 1040;
--commit;

SELECT * FROM V_GUARD_110003_FLEXPAY_EXIT ;

