select * from bundle_transition_hist;
select * from p_state_tbl s1 ;

SELECT 
         
       from_state_key, s1.state_nm, s1.state_type_cd, to_state_key, s2.state_nm, s2.state_type_cd, t1.date_key + date '1989-12-31' as bs_dt, 
       t1.guard_condition_key, GUARD_CONDITION_NM, s2.state_category_cd, t1.STATE_MACHINE_KEY
  from p_bundle_transition_hist t1
       join p_state_tbl s1 on (t1.from_state_key = s1.state_key)     
       join p_state_tbl s2 on (s2.state_key = t1.to_state_key)
       left join p_guard_condition_tbl gc on (gc.guard_condition_key = t1.guard_condition_key)
--          left join p_suppression_tbl sup
--            on (sup.bundle_key = t1.bundle_key and sup.SUPPRESSION_CD is null) 
 WHERE 
       1 = 1
   and bundle_key = 9676618    --5453262
   --AND s2.state_category_cd NOT IN ('W', 'H', 'S')
   --AND s2.effort_no is not null
 order by s1.rank_no, from_state_key, to_state_key
 ;


--Staging
SELECT 
         
       from_state_key, s1.state_nm, s1.state_type_cd, to_state_key, s2.state_nm, s2.state_type_cd, --t1.date_key + date '1989-12-31' as bs_dt, 
       t1.guard_condition_key, GUARD_CONDITION_NM, s2.state_category_cd, count(*), count(distinct bst.bundle_key) as bundles
  from bundle_dim bd
       join bundle_state_tbl bst on bst.bundle_key = bd.bundle_key
       join bundle_transition_hist t1 on bst.bundle_key = t1.bundle_key 
       join p_state_tbl s1 on (t1.from_state_key = s1.state_key)     
       join p_state_tbl s2 on (s2.state_key = t1.to_state_key)
       left join p_guard_condition_tbl gc on (gc.guard_condition_key = t1.guard_condition_key)
--          left join p_suppression_tbl sup
--            on (sup.bundle_key = t1.bundle_key and sup.SUPPRESSION_CD is null) 
 WHERE 
       1 = 1
  and bst.state_machine_key = 10093
group by from_state_key, s1.state_nm, s1.state_type_cd, to_state_key, s2.state_nm, s2.state_type_cd, 
       t1.guard_condition_key, GUARD_CONDITION_NM, s2.state_category_cd
order by from_state_key, s1.state_nm, s1.state_type_cd, to_state_key, s2.state_nm, s2.state_type_cd,
       t1.guard_condition_key, GUARD_CONDITION_NM, s2.state_category_cd         
;


--core
SELECT

       from_state_key, s1.state_nm, s1.state_type_cd, to_state_key, s2.state_nm, s2.state_type_cd, dd.full_dt,
       t1.guard_condition_key, GUARD_CONDITION_NM, s2.state_category_cd
  from p_bundle_dim bd
       join p_bundle_state_tbl bst on bst.bundle_key = bd.bundle_key
       join p_bundle_transition_hist t1 on bst.bundle_key = t1.bundle_key
       join p_state_tbl s1 on (t1.from_state_key = s1.state_key)
       join p_state_tbl s2 on (s2.state_key = t1.to_state_key)
       left join p_guard_condition_tbl gc on (gc.guard_condition_key = t1.guard_condition_key)
       left join date_dim dd on dd.date_key = t1.DATE_KEY
--          left join p_suppression_tbl sup
--            on (sup.bundle_key = t1.bundle_key and sup.SUPPRESSION_CD is null)
 WHERE
       1 = 1
--   and bst.state_machine_key = 10093
   and bd.BUNDLE_KEY = :bundle_key
order by from_state_key, s1.state_nm, s1.state_type_cd, to_state_key, s2.state_nm, s2.state_type_cd,
       t1.guard_condition_key, GUARD_CONDITION_NM, s2.state_category_cd
;


select bundle_key from v_sm_stream_transition where stream = 1;

SELECT bundle_key,
          CASE
             WHEN cell_group_xid LIKE '%01%' THEN 1
             WHEN cell_group_xid LIKE '%02%' THEN 2
             WHEN cell_group_xid LIKE '%03%' THEN 3
             WHEN cell_group_xid LIKE '%04%' THEN 4
             WHEN cell_group_xid LIKE '%05%' THEN 5
          END
             stream
     FROM v_bundle_dim
          JOIN cell_selection_fct USING (bundle_key)
          JOIN p_cell_dim USING (cell_key)
          JOIN p_cell_group_dim USING (cell_group_key)
WHERE bundle_key = :bundle_key;   --5453262


select * from V_SM_STREAM_TRANSITION where BUNDLE_KEY = 5453262;
select * from v_sm_score_transition where BUNDLE_KEY = 5453262;