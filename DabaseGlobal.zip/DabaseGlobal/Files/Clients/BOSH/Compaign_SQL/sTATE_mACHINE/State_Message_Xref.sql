select distinct --creation_dt
        campaign_xid, cell_group_nm, cell_group_xid, x.cell_key, cell_nm, cell_xid, effort_no 
       ,copy_cd, case when channel_key = 1 then 'DM' when channel_key = 2 then 'EM' end as channel   
       ,s.state_category_cd, state_nm 
       ,s.state_xid, x.state_key, x.message_key, x.cell_key, x.EXPIRATION_DAYS
  from bosh.state_message_xref x left join audit_tbl a on (audit_key = insert_audit_key)
       join bosh.state_tbl s on s.state_key = x.state_key
       join bosh.message_dim m on m.message_key = x.message_key
       join bosh.cell_dim cl on cl.cell_key = x.cell_key
       join bosh.cell_group_dim cg on cg.cell_group_key = cl.cell_group_key
       join bosh.campaign_dim cmp on cmp.campaign_key = cg.campaign_key
       
 where 1=1
  and x.cell_key IN (10444)
--    and x.message_key in (10166, 10161)
--  and cg.cell_group_key = 9761 
--   and creation_dt >= date '2018-08-01'
--   and campaign_xid = 'AI'
--   and m.copy_cd IN ('BSEEMAI2a')
--    and copy_cd like 'GCD%'
--    and cell_xid LIKE 'AI%BSH'
--    and m.channel_key = 2
--     and cell_nm like '%1 Effort%' --and cell_nm not like '%Creative%' --and cell_nm not like '%NCOA%'
--    and state_nm like 'Missed POS Canada  - Email%'
--    and s.STATE_MACHINE_KEY = 5582
--   and s.STATE_KEY in ( 6102, 6175)
--    and s.effort_no = 1
--    and x.CELL_KEY in (select ccx.cell_key from p_CRITERIA_CELL_XREF ccx join p_CRITERIA_DIM cri using (criteria_key)
--                      where ccx.POPULATION_PCT > 0 and cri.ACTIVE_IND = 'Y'
--                    )
-- order by x.state_key, x.cell_key
 order by campaign_xid, cell_group_xid, effort_no;
 



select creation_dt, x.state_key, x.message_key, x.cell_key, state_nm, effort_no, message_nm, cell_nm
  from bosh.state_message_xref x join audit_tbl a on (audit_key = insert_audit_key)
       join bosh.state_tbl s on s.state_key = x.state_key
       join bosh.message_dim m on m.message_key = x.message_key
       join bosh.cell_dim cl on cl.cell_key = x.cell_key
       join bosh.state_machine_tbl sm on sm.state_machine_key = s.state_machine_key
 where 1=1
--   and creation_dt < date '2018-08-01'
--   and cell_nm not like '%POR%' 
--   and cell_nm not like '%Honeywell%' 
--   and cell_nm NOT LIKE '%Outbound%' 
--   and cell_nm NOT LIKE '%NCOA%'
   and x.CELL_KEY IN (17044, 17051, 17058, 17065) --(17044, 17051)
--   and m.copy_cd IN ('BSEEMAO1b', '')
--  and UPPER(state_machine_nm) not like '%CANADA%' and UPPER(state_machine_nm) not like '%SWEEP%'
--   and s.state_key = 12921
--   and STATE_MACHINE_NM like 'Aftermarke%'
   ;
   

select * from bosh.cell_dim c join audit_tbl a on a.audit_key = c.insert_audit_key and creation_dt >= date '2019-06-10'
where cell_key not in (
         select x.cell_key from bosh.state_message_xref x )