select sm.STATE_MACHINE_KEY, STATE_MACHINE_XID, STATE_MACHINE_NM,  s.*
       --,sgx.cell_group_key 
  from 
        bosh.state_machine_tbl sm
        left join bosh.state_tbl s on (s.state_machine_key = sm.state_machine_key )
        --left join bosh.state_machine_cell_group_xref sgx on sm.state_machine_key = sgx.state_machine_key
        --left join bosh.cell_dim c on c.cell_group_key = sgx.cell_group_key                
where 1=1
--and UPPER(state_machine_nm) not like '%CANADA%' and UPPER(state_machine_nm) not like '%SWEEP%'
--and UPPER(state_machine_nm) not like '%OB%'
-- and STATE_MACHINE_NM like 'Aftermarket OOW%'
and sm.STATE_MACHINE_KEY = 17300
-- and state_category_cd in ('B', 'M')
-- and state_type_cd       <> 'X'
-- AND state_category_cd NOT IN ('W', 'H', 'S')
order by sm.STATE_MACHINE_KEY, state_xid;


select sm.STATE_MACHINE_KEY,
       STATE_MACHINE_XID,
       STATUS_CD,
       STATE_MACHINE_NM, STATE_MACHINE_DSC,
       min_state_key, max_effot_no, ENTRY_STATE_KEY, CREATION_DT, max_DELAY_DAYS_NO
from
       bosh.state_machine_tbl sm
       left join (select s.state_machine_key, max(EFFORT_NO) as max_effot_no, min(s.state_key) as min_state_key from bosh.state_tbl s group by s.state_machine_key) s
       on (s.state_machine_key = sm.state_machine_key )
       left join AUDIT_TBL ai on ai.AUDIT_KEY = sm.INSERT_AUDIT_KEY
       left join (select tt.state_machine_key, max(DELAY_DAYS_NO) as max_DELAY_DAYS_NO from bosh.TRANSITION_TBL tt
                  group by tt.state_machine_key) tt
       on (tt.STATE_MACHINE_KEY = sm.STATE_MACHINE_KEY)
where UPPER(state_machine_nm) like 'A%'
-- where max_effot_no >= 3
order by state_machine_nm
;