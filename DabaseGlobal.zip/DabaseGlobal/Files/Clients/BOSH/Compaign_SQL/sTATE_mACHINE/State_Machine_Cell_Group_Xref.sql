
select x.state_machine_key, x.cell_group_key, sm.state_machine_xid, state_machine_nm, effort_no, cg.cell_group_xid, cell_group_nm, cg.campaign_key, cmp.campaign_xid
       , cl.CELL_NM, CELL_XID, ai.CREATION_DT
  from bosh.state_machine_cell_group_xref x left join AUDIT_TBL ai on ai.AUDIT_KEY = x.INSERT_AUDIT_KEY
       join bosh.state_machine_tbl sm on sm.state_machine_key = x.state_machine_key
       join bosh.cell_group_dim cg on cg.cell_group_key = x.cell_group_key
       join bosh.campaign_dim cmp on cmp.campaign_key = cg.campaign_key
       join (select s.state_machine_key, max(effort_no) as effort_no from bosh.state_tbl s group by s.state_machine_key) s
          on s.STATE_MACHINE_KEY = x.STATE_MACHINE_KEY
       join bosh.CELL_DIM cl on cl.CELL_GROUP_KEY = cg.CELL_GROUP_KEY
 where 
       1=1
--     and cell_group_xid like 'AO%'
    and cell_group_xid like 'AS%'
--     and (cell_group_xid like 'AI%' or cell_group_xid like 'AG%')
--    and cell_group_xid like 'R%'
--     and regexp_like(cell_group_xid, 'A[OSG]+')
--    and x.CELL_GROUP_KEY in (17080)
--    and regexp_like(state_machine_xid, 'A[OSG]+')
--    and x.STATE_MACHINE_KEY in (17122, 6089)
--    and cl.CELL_KEY IN (
--                       select ccx.CELL_KEY from P_CRITERIA_CELL_XREF ccx join P_CRITERIA_DIM cri using (CRITERIA_KEY)
--                        where  nvl(ccx.POPULATION_PCT, 1) <> 0 and cri.ACTIVE_IND = 'Y'
--                       )
 order by 
       x.insert_audit_key desc, 
       cmp.campaign_xid, x.state_machine_key, cg.cell_group_xid          
      ;