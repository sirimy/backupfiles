SELECT t.* FROM (
    SELECT
       distinct from_state_key, s1.STATE_XID, s1.state_nm as from_state_nm, s1.state_type_cd as from_state_type_cd, s1.state_category_cd as from_state_category_cd, s1.effort_no as from_effort_no,
       to_state_key, s2.state_nm as to_state_nm, s2.state_type_cd as to_state_type_cd, s2.state_category_cd as to_state_category_cd, s2.effort_no as to_effort_no,
       TRANSITION_SEQ_NO, DELAY_DAYS_NO, t1.STATE_MACHINE_KEY, GUARD_CONDITION_TX
       , gc.sql_tx, guard_condition_nm, t1.GUARD_CONDITION_KEY, t1.TRANSITION_KEY, s1.rank_no
  from bosh.transition_tbl t1    --AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '9' HOUR) 
       join bosh.state_tbl s1 on (t1.from_state_key = s1.state_key)   --AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '9' HOUR)      
       join bosh.state_tbl s2 on (s2.state_key = t1.to_state_key)     --AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '9' HOUR) 
       left join bosh.guard_condition_tbl gc on (gc.guard_condition_key = t1.guard_condition_key)
--          left join bosh.suppression_tbl sup
--            on (sup.bundle_key = t1.bundle_key and sup.SUPPRESSION_CD is null) 
 WHERE 
       1=1
   AND t1.STATE_MACHINE_KEY = :STATE_MACHINE_KEY
--   and t1.from_state_key =  10095 --5674  --5684
--   and t1.to_state_key =  25624
--   and (t1.from_state_key IN (select s.state_key from bosh.state_tbl s where s.state_key >= 25621 )
--       or
--       t1.to_state_key IN (select s.state_key from bosh.state_tbl s where s.state_key >= 25572 )
--       )
--   and s2.state_nm like 'Missed POS Canada  - Email%';
--   and t1.guard_condition_key = 118

START WITH t1.from_state_key =   :from_state_key   --, 201529, 201530, 200570  --201237, 201234, 201235, 201236
CONNECT BY --NOCYCLE
   PRIOR t1.to_state_key = t1.from_state_key
              ) t
 order by rank_no, from_state_key, TRANSITION_SEQ_NO, to_state_key
 ;
 
 select * from v_sm_suppress_tansition;
 
 select * from v_sm_stream_transition where stream = 1;
 select * from v_sm_stream_transition where stream = 1;
 
 select * from bosh.transition_tbl  where delay_days_no > 7;