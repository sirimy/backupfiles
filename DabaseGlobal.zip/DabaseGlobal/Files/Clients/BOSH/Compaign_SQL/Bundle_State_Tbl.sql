select * from bundle_state_tbl  join bosh.state_machine_tbl using (state_machine_key) where bundle_key = :bundle_key;
 
 select * from p_bundle_state_tbl  join bosh.state_machine_tbl using (state_machine_key) where bundle_key = :bundle_key;

select * from p_bundle_state_tbl  join bosh.state_tbl using (state_key) where bundle_key = :bundle_key;

--CELL_GROUP_KEY, CELL_GROUP_XID,
select state_machine_key, state_machine_nm, min(EFFORT_NO), max(EFFORT_NO), count(*), count(distinct BUNDLE_KEY)
  from bundle_state_tbl  join bosh.state_machine_tbl using (state_machine_key)
       join p_state_tbl using (state_key, state_machine_key)
       join cell_selection_fct using (bundle_key)
       join p_cell_dim cl using (cell_key)
       join bosh.state_machine_cell_group_xref using (CELL_GROUP_KEY, state_machine_key)
       join p_cell_group_dim cg using (CELL_GROUP_KEY)
 where state_type_cd <> 'X'
--    AND state_category_cd NOT IN ('W', 'H', 'S', 'R')
--    and bundle_key NOT IN (select bundle_key from v_suppression_tbl sup )
--    and STATE_MACHINE_KEY = 10093
--    and CELL_GROUP_XID like 'R%'
group by state_machine_key, state_machine_nm
order by state_machine_nm, state_machine_key;


select bst.date_key + date '1989-12-31' as bs_dt, count(*),
       count(case when s.state_category_cd IN ('M', 'B') then bundle_key end) as active_DM_counts,
       count(case when s.state_category_cd IN ('E') then bundle_key end) as active_EM_counts,
       count(case when s.state_category_cd IN ('R') then bundle_key end) as Scoring_counts,
       min(ai.creation_dt), max(ai.creation_dt),
       min(au.creation_dt) as min_updated_dt, max(au.creation_dt) as max_updated_dt
  from bundle_state_tbl  --AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '1' HOUR)
                    bst
       join BUNDLE_DIM using (bundle_key)   --staging bundles
       join p_state_tbl s on s.state_key = bst.state_key
       left join audit_tbl ai on ai.audit_key = bst.INSERT_AUDIT_KEY
       left join audit_tbl au on au.audit_key = bst.update_AUDIT_KEY
where state_type_cd <> 'X'
--   and GUARANTEE_ID_9 like '%RI07%'
-- and   s.state_category_cd = 'R'
-- and   s.state_category_cd IN ('M', 'B', 'E')
group by bst.date_key order by bst.date_key;

select * from BOSH.STATE_CATEGORY_REF order by STATE_CATEGORY_CD;
+-----------------+------------------+
|STATE_CATEGORY_CD|STATE_CATEGORY_DSC|
+-----------------+------------------+
|B                |Mail and Email    |
|C                |Completed         |
|D                |Default           |
|E                |Email             |
|H                |Transitional Hold |
|M                |Mail              |
|N                |Entry             |
|R                |Stream Hold       |
|S                |Scoring           |
|W                |Wait              |
|X                |Exit              |
+-----------------+------------------+
    +-----------------+----------------+-----------+--------+-------------------------+-----------------+------------------------------------------+---------+
|STATE_MACHINE_KEY|STATE_MACHINE_NM|CRITERIA_CD|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|STATE_CATEGORY_CD|STATE_NM                                  |STATE_KEY|
+-----------------+----------------+-----------+--------+-------------------------+-----------------+------------------------------------------+---------+
|6167             |Early Bird      |E1000      |5       |5                        |H                |Early Bird  - 1 Effort - 1 Mailings - Hold|6193     |
|10093            |Aftermarket OOW |AO030      |3713    |3713                     |S                |Aftermarket OOW  - Score                  |10095    |
|10093            |Aftermarket OOW |AO090      |3681    |3681                     |S                |Aftermarket OOW  - Score                  |10095    |
|10480            |Renewal         |RI070      |11      |11                       |H                |Renewal  - 5 Effort - 5 Mailings - Hold   |10484    |
|17122            |Aftermarket     |AI010      |1104    |1104                     |R                |Aftermarket  - 1 Effort Entry Hold        |17193    |
|17122            |Aftermarket     |AI030      |5279    |5279                     |R                |Aftermarket  - 2 Effort Entry Hold        |17171    |
|17122            |Aftermarket     |AI040      |15827   |15827                    |R                |Aftermarket  - 3 Effort Entry Hold        |17125    |
|17300            |Early Bird      |E1000      |3114    |3114                     |R                |Early Bird  - 1 Effort Entry Hold         |17325    |
|17300            |Early Bird      |E2000      |21658   |21658                    |R                |Early Bird  - 2 Effort Entry Hold         |17303    |
|17390            |Aftermarket OOW |AO030      |13475   |13475                    |R                |Aftermarket OOW  - 1 Effort Entry Hold    |17393    |
|17390            |Aftermarket OOW |AO090      |15582   |15582                    |R                |Aftermarket OOW  - 1 Effort Entry Hold    |17393    |
+-----------------+----------------+-----------+--------+-------------------------+-----------------+------------------------------------------+---------+
+-----------------+----------------+-----------+--------+-------------------------+-----------------+-------------------------------------+---------+
|STATE_MACHINE_KEY|STATE_MACHINE_NM|CRITERIA_CD|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|STATE_CATEGORY_CD|STATE_NM                             |STATE_KEY|
+-----------------+----------------+-----------+--------+-------------------------+-----------------+-------------------------------------+---------+
|6167             |Early Bird      |E1000      |208     |208                      |M                |Early Bird  - Mail - 1               |6196     |
|6167             |Early Bird      |E1000      |79      |79                       |B                |Early Bird  - Mail and Email - 1     |6195     |
|9820             |Renewal         |RI030      |9       |9                        |B                |Renewal  - Mail and Email - 1        |9872     |
|9820             |Renewal         |RI040      |4       |4                        |B                |Renewal  - Mail and Email - 1        |9826     |
|10093            |Aftermarket OOW |AO030      |105     |105                      |M                |Aftermarket OOW  - Mail - 1          |10100    |
|10093            |Aftermarket OOW |AO030      |37      |37                       |B                |Aftermarket OOW  - Mail and Email - 1|10099    |
|10480            |Renewal         |RI060      |5       |5                        |M                |Renewal  - Mail - 1                  |10608    |
|10480            |Renewal         |RI060      |5       |5                        |B                |Renewal  - Mail and Email - 1        |10607    |
|10480            |Renewal         |RI070      |16      |16                       |E                |Renewal  - Email - 1                 |10488    |
|10480            |Renewal         |RI070      |671     |671                      |M                |Renewal  - Mail - 1                  |10487    |
|10480            |Renewal         |RI070      |714     |714                      |B                |Renewal  - Mail and Email - 1        |10486    |
|16920            |Aftermarket     |AI010      |27      |27                       |M                |Aftermarket  - Mail - 1              |16949    |
|16920            |Aftermarket     |AI010      |7       |7                        |B                |Aftermarket  - Mail and Email - 1    |16948    |
|16920            |Aftermarket     |AI060      |67      |67                       |M                |Aftermarket  - Mail - 1              |16927    |
|16920            |Aftermarket     |AI060      |29      |29                       |B                |Aftermarket  - Mail and Email - 1    |16926    |
|20596            |Renewal Winback |RW000      |283     |283                      |M                |Renewal Winback  - Mail - 3          |20603    |
|20596            |Renewal Winback |RW000      |217     |217                      |B                |Renewal Winback  - Mail and Email - 3|20602    |
+-----------------+----------------+-----------+--------+-------------------------+-----------------+-------------------------------------+---------+


select  state_machine_key, state_machine_nm, criteria_cd, count(*), count(distinct BUNDLE_KEY), s.state_category_cd,s.STATE_NM, STATE_KEY
  from bundle_state_tbl bs join p_state_machine_tbl using (state_machine_key)
       join p_state_tbl s using (state_key, state_machine_key)
       join bundle_dim bd using (bundle_key)
       join p_criteria_dim c on (bd.criteria_key = c.criteria_key)
--        join p_cell_selection_fct cs using (bundle_key)
--        join elux.CELL_DIM cl using (cell_key)
--        join bundle_lkp using (bundle_key)
--        join elux.bundle_lkp using (bundle_xid)   --old WQ-WP leads
--        join elux.STATE_MACHINE_CELL_GROUP_XREF xx using (state_machine_key, cell_group_key)
--        join elux.CELL_GROUP_DIM cg using ( cell_group_key)
 where 1=1
 and state_type_cd <> 'X'
--  and   s.state_category_cd = 'R'
--  and   s.state_category_cd = 'H'
 and   s.state_category_cd   IN ('M', 'B', 'E')
--  and   c.criteria_cd like 'W%'
--  and   (c.criteria_cd like 'WP%')   --or c.criteria_cd like 'WQ%'
--  and   c.criteria_cd like 'E%'
--  and   c.criteria_cd like 'RO%'
--    and state_machine_key >= 17000  --New SMs used for scoring (Bosch branded)
--  and EFFORT_NO = 1   --this is not reqd if we are joining on bundle_dim in stg
-- and    cell_group_key in (701, 6200)
--  and (upper(STATE_NM) like '%EMAIL%' or upper(STATE_NM) like '%[E]%')
group by  state_machine_key, state_machine_nm, criteria_cd, s.state_category_cd, state_nm, state_key
having count(*) > 2
order by state_machine_key, state_machine_nm, criteria_cd, s.STATE_NM;



select bs.state_machine_key, state_machine_nm, cl.cell_group_key, cl.cell_key, cell_nm, count(*)  
  from bundle_state_tbl bs  join bosh.state_machine_tbl sm on (sm.state_machine_key = bs.state_machine_key)
      join p_state_tbl s on (s.state_key  = bs.state_key)
       join bosh.cell_selection_fct cs using (bundle_key)
       join bosh.cell_dim cl on (cl.cell_key = cs.cell_key)
 where state_type_cd <> 'X'
   and bundle_key NOT IN (select bundle_key from v_suppression_tbl sup ) 
 group by bs.state_machine_key, state_machine_nm, cl.cell_group_key, cl.cell_key, cell_nm
 order by cl.cell_group_key, bs.state_machine_key, state_machine_nm, cl.cell_key, cell_nm;

+-----------------+----------------+--------------+--------+-------------------------------------------+--------+
|STATE_MACHINE_KEY|STATE_MACHINE_NM|CELL_GROUP_KEY|CELL_KEY|CELL_NM                                    |COUNT(*)|
+-----------------+----------------+--------------+--------+-------------------------------------------+--------+
|6089             |Aftermarket     |1006          |1014    |Aftermarket 2 Effort – Thermador           |207     |
|6089             |Aftermarket     |1007          |1016    |Aftermarket 3 Effort – Thermador           |6244    |
|6167             |Early Bird      |1008          |1020    |Early Bird 1 Effort – Thermador            |1       |
|6167             |Early Bird      |1009          |1018    |Early Bird 2 Effort – Thermador            |2499    |
|9820             |Renewal         |6844          |6851    |Renewal 3 Effort - Bosch                   |2       |
|10480            |Renewal         |10440         |10442   |Renewal 4 Effort - Bosch                   |4       |
|10480            |Renewal         |10440         |10443   |Renewal 4 Effort - Thermador               |5       |
|10480            |Renewal         |10441         |10444   |Renewal 5 Effort - Bosch                   |3417    |
|10480            |Renewal         |10441         |10445   |Renewal 5 Effort - Thermador               |500     |
|16920            |Aftermarket     |11123         |11126   |Aftermarket 2 Effort - Gaggenau            |107     |
|17122            |Aftermarket     |17201         |1013    |Aftermarket 2 Effort – Bosch               |2882    |
|17122            |Aftermarket     |17202         |1015    |Aftermarket 3 Effort – Bosch               |20085   |
|17300            |Early Bird      |17333         |1017    |Early Bird 2 Effort – Bosch                |20684   |
|17390            |Aftermarket OOW |17400         |9763    |Aftermarket OOW INITIAL Effort - Bosch     |63      |
|20596            |Renewal Winback |19141         |19142   |Renewal Winback OOW - Bosch - 3 efforts    |863     |
|20596            |Renewal Winback |19141         |19143   |Renewal Winback OOW - Thermador - 3 efforts|148     |
+-----------------+----------------+--------------+--------+-------------------------------------------+--------+

 
select * from p_state_machine_ext_tbl sme join P_state_machine_tbl using (state_machine_key);

SELECT DISTINCT transition_seq_no, trans.state_machine_key,
        CASE
          WHEN guard_condition_key = 0
          THEN NULL
          ELSE guard_condition_key
        END AS guard_condition_key
        ,from_state_key, to_state_key
  FROM p_transition_tbl trans
  JOIN bosh.bundle_state_tbl bund
  ON (state_key                   = from_state_key
  AND trans.state_machine_key =  bund.state_machine_key)
  JOIN p_state_machine_tbl sm
  ON sm.state_machine_key =  bund.state_machine_key
--  LEFT JOIN p_state_machine_ext_tbl sme
--  ON sme.state_machine_key =  sm.state_machine_key              
  WHERE 1=1
--    and date_key + delay_days_no <= date '2017-11-30' - date '1989-12-31' 
--  AND CASE WHEN NVL('ALL', 'ALL') = 'ALL' THEN NVL(sme.state_machine_type, 'ALL')
--           ELSE 'ALL'
--      END = NVL(sme.state_machine_type, 'ALL')  
  --and bundle_key = 7241873
  ORDER BY transition_seq_no,
    guard_condition_key;
    
    
select full_dt, count(*) 
  from bundle_state_tbl  join date_dim dd using (date_key)
  join p_state_tbl
        using (state_key, state_machine_key)
 where 1=1
   and state_type_cd <> 'X' AND state_category_cd NOT IN ('W', 'H', 'S')
   and bundle_key NOT IN (select bundle_key from v_suppression_tbl sup )
group by full_dt
order by full_dt;

+----------+--------+
|FULL_DT   |COUNT(*)|
+----------+--------+
|2024-03-19|44694   |
|2024-03-26|24666   |
|2024-04-02|43136   |
|2024-04-09|22628   |
+----------+--------+
