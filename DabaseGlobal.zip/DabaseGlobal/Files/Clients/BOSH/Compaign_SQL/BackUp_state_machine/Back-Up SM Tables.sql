create table BUNDLE_STATE_TBL_20241122 as select * from BUNDLE_STATE_TBL;
comment on table BUNDLE_STATE_TBL_20241122 is 'Back-up of BUNDLE_STATE_TBL prior to running SM round-2 as we are waiting for scoring approval';


select count(*) from BUNDLE_STATE_TBL
union all
select count(*) from BUNDLE_STATE_TBL_20241122;
-- +--------+
-- |COUNT(*)|
-- +--------+
-- |406328  |
-- |406328  |
-- +--------+




create table BUNDLE_TRANSITION_HIST_20241122 as select * from BUNDLE_TRANSITION_HIST;
comment on table BUNDLE_TRANSITION_HIST_20241122 is 'Back-up of BUNDLE_TRANSITION_HIST prior to running SM round-2 as we are waiting for scoring approval';

select count(*) from BUNDLE_TRANSITION_HIST
union all
select count(*) from BUNDLE_TRANSITION_HIST_20241122;
-- +--------+
-- |COUNT(*)|
-- +--------+
-- |654620  |
-- |654620  |
-- +--------+

COMMIT;