--This is a creative test on existing campaigns so there will be no metadata for campaigns/cell groups/cohorts/timing
--Only metadata will be created/changed for cells/criteria/criteria cell xref/message_dim/SMX

-------------------------------------------------------------------
rollback;
--Clean-up Staging
delete from gnrcStg.CELL_DIM where CELL_KEY in (select CELL_KEY from gnrc.cell_dim);
delete from gnrcStg.CELL_group_DIM where CELL_group_key in (select CELL_group_key from gnrc.CELL_group_DIM);
delete from gnrcStg.CAMPAIGN_DIM where CAMPAIGN_KEY in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_DIM);
delete from gnrcStg.CAMPAIGN_EXT_DIM where CAMPAIGN_KEY in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_EXT_DIM);
delete from gnrcStg.criteria_dim where CRITERIA_KEY in (select CRITERIA_KEY from gnrc.criteria_dim);
commit;
----------------------------------------------------------------------
--Populate staging with required campaign and cell groups
insert into CAMPAIGN_DIM select * from gnrc.CAMPAIGN_DIM where CAMPAIGN_XID in ('A6', 'RW', 'AN', 'RX', 'M6')
   and CAMPAIGN_KEY not in (select c.CAMPAIGN_KEY from CAMPAIGN_DIM c);
--4 rows
commit;

select * from gnrc.CELL_GROUP_DIM where CAMPAIGN_KEY in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_DIM where CAMPAIGN_XID in ('A6', 'RW'));
insert into CELL_GROUP_DIM
select * from gnrc.CELL_GROUP_DIM where CAMPAIGN_KEY in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_DIM
                                                          where CAMPAIGN_XID in ('A6', 'RW', 'AN', 'RX', 'M6'))
  and CELL_GROUP_KEY not in (select cg.CELL_GROUP_KEY from CELL_GROUP_DIM cg);
--4 rows
commit;
----------------------------------------------------------------------
--Only AN is the new campaign as so far we have been using same campaign xid for both A6 and A6-NCOA...though not sure why?
--create new campaign, cohort and timing data for for Mid-Warranty
begin
    pk_campaign_utilities.prc_create_campaign('ESP','AN','Aftermarket Sweep 6th Year NCOA');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2016','31-DEC-2099','AN','Tuesday');
    pk_campaign_utilities.prc_populate_timing_dim('01-JUN-2016','31-DEC-2099','AN','Tuesday');
end;

select * from CAMPAIGN_DIM left join AUDIT_TBL on AUDIT_KEY = INSERT_AUDIT_KEY;
-- delete from CAMPAIGN_DIM where CAMPAIGN_KEY in (90999, 91000);
-- commit;
select * from TIMING_DIM;
select * from COHORT_DIM;

begin
    --A6-07N has to be created as other groups are there in core already
    pk_campaign_utilities.prc_create_cell_group('AN','A6-07N','Aftermarket Sweep 7 Effort 6th Year NCOA Ongoing');
end;

select * from CELL_GROUP_DIM order by CELL_GROUP_XID;
select * from CELL_DIM cl order by cell_xid;

begin
    pk_campaign_utilities.prc_create_cell('RW-02','RW02HSBGENO','01','B','Recently Expired 2 Effort HSB Generac Ongoing');
    pk_campaign_utilities.prc_create_cell('RW-02N','RW02HSBGENNO','30','B','Recently Expired 2 Effort HSB Generac NCOA Ongoing');
    pk_campaign_utilities.prc_create_cell('A6-07','A607HSBGENO','01','B','Aftermarket Sweep HSB Generac 6th Year Ongoing');
    pk_campaign_utilities.prc_create_cell('A6-07N','A607HSBGENNO','30','B','Aftermarket Sweep HSB Generac NCOA 6th Year Ongoing');
end;
/* --These sqls can be used if we want to change cell group to drop more efforts, e.g., changing from 2 effort to 5 effort
--Updated cell_xid to reflect 5 efforts as while plan is to drop 2 efforts but we want to be prepared to drop more if reqd
select CELL_XID, substr(CELL_XID, 1, 3) || '5' || substr(CELL_XID, 5) from gnrc.cell_dim cl where substr(CELL_XID, 1, 4) in ('LC02', 'LS02');

update gnrc.cell_dim cl
   set CELL_XID = substr(CELL_XID, 1, 3) || '5' || substr(CELL_XID, 5)
where substr(CELL_XID, 1, 4) in ('LC02', 'LS02');
--16 rows

commit;
*/

select * from CELL_GROUP_DIM order by CELL_GROUP_XID;
select * from CELL_DIM cl order by cell_xid;
Update CELL_DIM set CELL_GROUP_KEY = (select cg.CELL_GROUP_KEY from CELL_GROUP_DIM cg where CELL_GROUP_XID = 'RW-02N')
  where CELL_XID = 'RW02HSBGENNO';
commit;
update CELL_DIM set CELL_GROUP_KEY = 46150 where CELL_XID = 'A607HSBGENNO';
commit;

select * from gnrc.CAMPAIGN_EXT_DIM ;
select * from gnrc.CAMPAIGN_EXT_DIM cex join gnrc.CAMPAIGN_DIM cd on cd.CAMPAIGN_KEY = cex.CAMPAIGN_KEY where upper(CAMPAIGN_DSC) like '%SWEEP%';

insert into CAMPAIGN_EXT_DIM
select CAMPAIGN_KEY, 'DM', INSERT_AUDIT_KEY, null, 'PURCHASE_DT' from CAMPAIGN_DIM
where CAMPAIGN_KEY not in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_EXT_DIM);
--1 row
commit;
select * from CAMPAIGN_EXT_DIM;

-- delete from gnrcStg.CRITERIA_DIM;
-- commit;
begin
     pk_campaign_utilities.prc_populate_criteria('RW02-HSBGENO' , 'RW000', '', '', 'between drop_dt -468 and drop_dt -462', '','24' ,'', 'v_available_universe', 'brand_family_cd= ''GNH'' and NCOA_Ind= ''N'' and Country_Cd= ''USA''' );
     pk_campaign_utilities.prc_populate_criteria('RW02-HSBGENNO' , 'RW000N', '', '', 'between drop_dt -468 and drop_dt -462', '','24' ,'', 'v_available_universe', 'brand_family_cd= ''GNH'' and NCOA_Ind= ''Y'' and Country_Cd= ''USA''' );
     pk_campaign_utilities.prc_populate_criteria('A607-HSBGENO' , 'A6000', '', '', 'between drop_dt -832 and drop_dt -826', '','24' ,'', 'v_available_universe', 'brand_family_cd= ''GNH'' and NCOA_Ind= ''N'' and Country_Cd= ''USA''' );
     pk_campaign_utilities.prc_populate_criteria('A607-HSBGENNO' , 'A6000N', '', '', 'between drop_dt -832 and drop_dt -826', '','24' ,'', 'v_available_universe', 'brand_family_cd= ''GNH'' and NCOA_Ind= ''Y'' and Country_Cd= ''USA''' );
end;

select * from CRITERIA_DIM order by CRITERIA_XID, LATEST_COVERAGE_TYPE;
select * from CRITERIA_DIM where CRITERIA_XID in (select c.CRITERIA_XID from gnrc.CRITERIA_DIM c);  --no overlap --good
--3 rows as expected
select substr(CRITERIA_XID, 3, 2), cri.* from CRITERIA_DIM cri where STREAM_LENGTH_DAYS is null order by CRITERIA_XID;
update CRITERIA_DIM set STREAM_LENGTH_DAYS = 42 * substr(CRITERIA_XID, 3, 2)  where STREAM_LENGTH_DAYS is null;
-- update CRITERIA_DIM set STREAM_LENGTH_DAYS = 42 * 2  where STREAM_LENGTH_DAYS is null;
--4 rows
commit;


--We are using custom calculation for Upgrade Mid as not all efforts are 7 weeks apart
--Number of weeks multiplied by 7 (number of days in a week)
-- update CRITERIA_DIM set STREAM_LENGTH_DAYS =  7 * 7  where STREAM_LENGTH_DAYS is null and substr(CRITERIA_XID, 3, 2) = '01';
-- update CRITERIA_DIM set STREAM_LENGTH_DAYS = 14 * 7  where STREAM_LENGTH_DAYS is null and substr(CRITERIA_XID, 3, 2) = '02';
-- update CRITERIA_DIM set STREAM_LENGTH_DAYS = 36 * 7  where STREAM_LENGTH_DAYS is null and substr(CRITERIA_XID, 3, 2) = '03';
-- update CRITERIA_DIM set STREAM_LENGTH_DAYS = 42 * 7  where STREAM_LENGTH_DAYS is null and substr(CRITERIA_XID, 3, 2) = '04';
-- update CRITERIA_DIM set STREAM_LENGTH_DAYS = 48 * 7  where STREAM_LENGTH_DAYS is null and substr(CRITERIA_XID, 3, 2) = '05';

select substr(CRITERIA_XID, 3, 2), STREAM_LENGTH_DAYS, cri.CRITERIA_XID, CRITERIA_CD from CRITERIA_DIM cri order by CRITERIA_CD, CRITERIA_XID;
--looks good
commit;

--we don't need to use '=' operator in conditions as that is used by default if there are no <=, >=, IN, NOT IN etc are there
select * from CRITERIA_DIM where WARRANTY_MONTHS like '=%';
update CRITERIA_DIM set WARRANTY_MONTHS = replace (WARRANTY_MONTHS, '=')
where WARRANTY_MONTHS like '=%';
--16 rows
commit;

update CRITERIA_DIM set latest_coverage_type = 1
 where (CRITERIA_XID like 'A6%'  or CRITERIA_XID like 'RW%')
   and latest_coverage_type is null;
commit;

update CRITERIA_DIM set brand_nm = 'GENERAC'
 where (CRITERIA_XID like 'A6%'  or CRITERIA_XID like 'RW%')
   and brand_nm is null;
commit;


delete from gnrcStg.criteria_cell_xref;
commit;

begin
    pk_campaign_utilities.prc_populate_criteria_cell('RW02-HSBGENO','RW02HSBGENO','34','1');
    pk_campaign_utilities.prc_populate_criteria_cell('RW02-HSBGENNO','RW02HSBGENNO','34','1');
    pk_campaign_utilities.prc_populate_criteria_cell('A607-HSBGENO','A607HSBGENO','33','1');
    pk_campaign_utilities.prc_populate_criteria_cell('A607-HSBGENNO','A607HSBGENNO','33','1');
end ;

select * from gnrcStg.criteria_cell_xref;

--Now populate ccx with criteria_keys where LATEST_COVERAGE_TYPE = 5
-- insert into CRITERIA_CELL_XREF (CRITERIA_KEY, CELL_KEY, PRICING_SCHEME_KEY, POPULATION_PCT)
select cr2.CRITERIA_KEY, CELL_KEY, pricing_scheme_key, POPULATION_PCT
--        cell_group_xid, cr.criteria_xid, cr.criteria_cd, cr.LATEST_COVERAGE_TYPE, cell_xid,
--        cr.CRITERIA_KEY, cr2.LATEST_COVERAGE_TYPE, cr.warranty_months
--        pricing_scheme_nm, cell_nm,  cell_group_nm  --population_pct
  from criteria_cell_xref ccx
       join criteria_dim cr on(cr.criteria_key = ccx.criteria_key)
       join (
       select * from cell_dim
       ) cl
       using (cell_key)
       join cell_group_dim using (cell_group_key)
       join campaign_dim cmp using (campaign_key)
       left join (
            select PRICING_SCHEME_KEY, PRICING_SCHEME_NM, EFFECTIVE_DT, END_DT from pricing_scheme_dim
            union all
            select PRICING_SCHEME_KEY, PRICING_SCHEME_NM, EFFECTIVE_DT, END_DT from p_pricing_scheme_dim
            --order by pricing_scheme_key
            ) psd using (pricing_scheme_key)
       join gnrc.CRITERIA_DIM cr2 on cr2.CRITERIA_XID = cr.CRITERIA_XID and cr2.CRITERIA_KEY <> cr.CRITERIA_KEY
 where 1=1
 and POPULATION_PCT <> 0
 order by cell_group_xid, cr.criteria_xid, cell_xid --, CONTROL_IND
 ;
--5 rows
commit;


/*
delete from gnrcStg.criteria_cell_xref;
--Since we have dupes on CRITERIA_XID (one record for latest coverage 2 and another for latest coverage 5)
--so pk_campaign_utilities.prc_populate_criteria_cell will not work and raise error (ORA-01422: exact fetch returns more than requested number of rows)
--So we will use custom insert to populate criteria_cell_xref
insert into criteria_cell_xref (CRITERIA_KEY, CELL_KEY, PRICING_SCHEME_KEY, POPULATION_PCT, INSERT_AUDIT_KEY)
select CRITERIA_KEY, CELL_KEY,
       case when warranty_months = 60 then 37 when warranty_months = 84 then 36 end as PRICING_SCHEME_KEY,
       1 as POPULATION_PCT
       ,831327
       --,CRITERIA_XID, CELL_XID   --debug columns
 from  (
        select CRITERIA_KEY, CRITERIA_XID, substr(CRITERIA_XID, -2, 2) as warranty_months
          from CRITERIA_DIM cri ) cri
       left join
       (select CELL_KEY, CELL_XID --, substr(CELL_XID, -2, 2) as warranty_months
          from cell_dim  cl) cl
       on cl.CELL_XID = replace(cri.CRITERIA_XID, '-');
--20 rows
commit;
 */

select * from criteria_cell_xref order by INSERT_AUDIT_KEY desc;

--------------------------------------------------------------------------------------------------
--De-Activate existing criteria, which are being replaced with new ones above
--AJ on 12/11/2020: It was a mistake to do this...we should have used these criteria to pull leads, which were part of prior creative test
--New criteria should have been used for those leads only, which were not part of prior creative test
-- update CRITERIA_DIM set ACTIVE_IND = 'N', UPDATE_AUDIT_KEY = 713363 where CRITERIA_DIM.CRITERIA_XID in ( 'MP01-PORGEN');
-- commit;


-------------------------------------------------------------------------------------------------
--deleting unnecessary records from staging
delete from gnrcStg.cell_group_dim where CELL_GROUP_KEY not in (select cl.CELL_GROUP_KEY from gnrcStg.cell_dim cl);
--107 rows
commit;

select * from cell_group_dim order by CELL_GROUP_XID;
----------------------------------------------------------------------------------------------

select * from campaign_dim;
select * from campaign_ext_dim;
select * from cell_group_dim cg ;
select * from cell_dim cl order by CELL_XID;
select * from cohort_dim order by COHORT_CD ;
select * from timing_dim t order by DROP_DT;
select * from criteria_dim order by CRITERIA_XID;
select * from criteria_cell_xref order by CRITERIA_KEY, CELL_KEY;
select * from state_machine_cell_group_xref;
select * from state_machine_tbl;
select * from state_tbl;
select * from transition_tbl;

select distinct cell_group_xid, criteria_xid, criteria_cd, LATEST_COVERAGE_TYPE, warranty_months, REGISTRATION_DT, cell_xid,  --cell_key, cell_cd, control_ind,
       pricing_scheme_key, pricing_scheme_nm, cell_nm,  cell_group_nm, population_pct --, CRITERIA_KEY
  from criteria_cell_xref
       join criteria_dim using(criteria_key)
       join (
       select * from cell_dim
--        union all
--        select * from p_cell_dim
       ) cl
       using (cell_key) 
       join cell_group_dim using (cell_group_key)
       join campaign_dim cmp using (campaign_key) 
       left join (
            select PRICING_SCHEME_KEY, PRICING_SCHEME_NM, EFFECTIVE_DT, END_DT from pricing_scheme_dim
            union all
            select PRICING_SCHEME_KEY, PRICING_SCHEME_NM, EFFECTIVE_DT, END_DT from p_pricing_scheme_dim
            --order by pricing_scheme_key
            ) psd using (pricing_scheme_key)
 where 1=1
--   and cmp.campaign_xid = 'AI'
--   and active_ind = 'Y'
--and cell_nm like '%Resi%'
--and cell_group_xid like 'MP-05%'
   and POPULATION_PCT <> 0
 order by cell_group_xid, criteria_xid, cell_xid --, CONTROL_IND
 ;
-- +--------------+-------------+-----------+--------------------+---------------+---------------+------------+------------------+---------------------------+-------------------------------------------------------------------------+-------------------------------------------------+--------------+
-- |CELL_GROUP_XID|CRITERIA_XID |CRITERIA_CD|LATEST_COVERAGE_TYPE|WARRANTY_MONTHS|REGISTRATION_DT|CELL_XID    |PRICING_SCHEME_KEY|PRICING_SCHEME_NM          |CELL_NM                                                                  |CELL_GROUP_NM                                    |POPULATION_PCT|
-- +--------------+-------------+-----------+--------------------+---------------+---------------+------------+------------------+---------------------------+-------------------------------------------------------------------------+-------------------------------------------------+--------------+
-- |MU-05         |MU05-HSBGEN60|MU000      |11                  |>= 24          |null           |MU05HSBGEN60|37                |UP HSB USA - 5 Year Upgrade|Missing Models Leads Upgrade Early Sweep 5 Effort - =60 Month HSB Generac|Missing Models Leads Upgrade Early Sweep 5 Effort|1.00          |
-- |MU-05         |MU05-HSBGEN84|MU000      |11                  |>= 24          |null           |MU05HSBGEN84|36                |UP HSB USA - 3 Year Upgrade|Missing Models Leads Upgrade Early Sweep 5 Effort - =84 Month HSB Generac|Missing Models Leads Upgrade Early Sweep 5 Effort|1.00          |
-- +--------------+-------------+-----------+--------------------+---------------+---------------+------------+------------------+---------------------------+-------------------------------------------------------------------------+-------------------------------------------------+--------------+


select * from criteria_cell_xref join cell_dim using (cell_key) order by cell_nm, cell_key;

select distinct pricing_scheme_key from criteria_cell_xref order by pricing_scheme_key;

begin
    pk_campaign_utilities.prc_build_state_cell_group('A6-07','A6-07N');
end;


--DON'T FORGET TO POPULATE GID_METADATA_TBL
select CRITERIA_CD from gnrc.CRITERIA_DIM where CRITERIA_CD not like 'O%'
minus
select CRITERIA_CD from GID_METADATA_TBL;


begin
    p_pk_core_update.merge_tbl('campaign_dim');
    p_pk_core_update.merge_tbl('campaign_ext_dim');
    p_pk_core_update.insert_tbl('cohort_dim');
    p_pk_core_update.insert_tbl('timing_dim');
end;


begin
    p_pk_core_update.MERGE_TBL('criteria_dim');
    p_pk_core_update.MERGE_TBL('cell_group_dim');
    p_pk_core_update.merge_tbl('cell_dim');
    p_pk_core_update.merge_tbl('criteria_cell_xref');
end;

begin
    null;
--     p_pk_core_update.insert_tbl('state_machine_cell_group_xref');
end;


select * from gnrc.campaign_dim  order by campaign_key desc;
select * from gnrc.campaign_ext_dim  order by campaign_key desc;
select * from gnrc.cell_group_dim cg order by cell_group_key desc;
select * from gnrc.cell_dim cl   order by greatest(nvl(update_audit_key, -99), insert_audit_key) desc, cell_nm, control_ind;
select * from (select * from gnrc.cohort_dim    order by cohort_key desc) where rownum <= 5 ;
select * from (select * from gnrc.timing_dim t  order by timing_key desc) where rownum <= 5 ;
select * from gnrc.criteria_dim  order by greatest(nvl(update_audit_key, -99), insert_audit_key) desc;
select * from gnrc.criteria_cell_xref order by greatest(nvl(update_audit_key, -99), insert_audit_key) desc;
select * from gnrc.state_machine_cell_group_xref order by cell_group_key desc;


-------------------------------------------------------------------------------

--gid_metadata_tbl changes were not applicable for 1 piece test

select count(*), count(distinct criteria_cd) from gid_metadata_tbl order by 1; 

select * from gid_metadata_tbl order by 1;
select * from gid_metadata_tbl where criteria_cd like 'MU%' order by 1;
select * from gid_metadata_tbl where criteria_cd like 'A6%'  or CRITERIA_cd like 'RW%';
select * from gid_metadata_tbl order by INSERT_AUDIT_KEY desc nulls last ;

-- delete from gid_metadata_tbl where criteria_cd like 'LC%';
-- delete from gid_metadata_tbl where criteria_cd like 'LS%';
-- commit;
select CRITERIA_CD from gnrc.CRITERIA_DIM where CRITERIA_CD not like 'O%'
minus
select CRITERIA_CD from GID_METADATA_TBL;
--no rows  --no new criteria_cd  --good


declare
    v_audit_key NUMBER;
begin
    v_audit_key := gnrc.get_audit_key (p_program_nm => 'Campaign', p_descriptive_tx => 'Campaign metadata - GNRC-1351', p_table_nm => 'GID_METADATA_TBL');
    DBMS_OUTPUT.PUT_LINE(v_audit_key);
    COMMIT;
end;
--
select * from audit_tbl where creation_dt >= trunc(sysdate) order by creation_dt desc;
--893026

select * from gid_metadata_tbl where criteria_cd like 'MA%' order by 1;

--GID_SCORED_APPEND_CD is used as stream in gid (this is represented by 15th and 16th char of gid)
--Cohort table is using drop week as cohort week of gid
insert into gid_metadata_tbl (
   CRITERIA_CD, MAX_NO_OF_MAILINGS, SCORED_NO_OF_MAILINGS, GID_TYPE_CD,
   GID_SCORED_APPEND_CD, GID_CRITERIA_CD, PULL_FROM_DATE_TYPE, INSERT_AUDIT_KEY )
select 'MU000' as CRITERIA_CD,
       MAX_NO_OF_MAILINGS, SCORED_NO_OF_MAILINGS,
       GID_TYPE_CD, GID_SCORED_APPEND_CD, 'MU000' as GID_CRITERIA_CD,  PULL_FROM_DATE_TYPE, 893026 as INSERT_AUDIT_KEY
from GID_METADATA_TBL where CRITERIA_CD = 'MA000';
--1 row
commit;

insert into gid_metadata_tbl (
   CRITERIA_CD, MAX_NO_OF_MAILINGS, SCORED_NO_OF_MAILINGS, GID_TYPE_CD,
   GID_SCORED_APPEND_CD, GID_CRITERIA_CD, PULL_FROM_DATE_TYPE, INSERT_AUDIT_KEY )
select distinct criteria_cd, NO_OF_MAILINGS as MAX_NO_OF_MAILINGS, NO_OF_MAILINGS as SCORED_NO_OF_MAILINGS, 'PURCHASE_WEEK' as GID_TYPE_CD,
      '00' as GID_SCORED_APPEND_CD, criteria_cd as GID_CRITERIA_CD, 'PURCHASE_WEEK' as pull_drom_date_type, 846794
  from  ( 
        select cri.criteria_cd,
               --substr(CRITERIA_XID, 3, 2) as NO_OF_MAILINGS
               '05' as NO_OF_MAILINGS    --while criteria_xid is based upon 2 effort but we are preparing to drop up to 5 efforts if reqd
          from criteria_cell_xref ccx join criteria_dim cri using(criteria_key)
               join cell_dim using (cell_key) join cell_group_dim cg using (cell_group_key)
--          where cell_nm like '%Upgrade Mid Sweep%'
        )
order by criteria_cd;
--6 rows
commit;
 
select * from gid_metadata_tbl order by insert_audit_key desc nulls last, criteria_cd, GID_TYPE_CD;

 
select * from gid_metadata_tbl where substr(criteria_cd, 1, 2) in ('RW') ;
select * from gid_metadata_tbl where regexp_like(criteria_cd, 'A[O6QC]+') order by criteria_cd;

 
select * from gnrc.criteria_dim where regexp_like(criteria_cd, 'A[O6QC]+'); 
-------------------------------------------------------------------------------

--now we will use PULL_FROM_DATE_TYPE from gid_metadata_tbl instead of campaign_ext_dim
--as gid_metadata_tbl  is meant to handle gids specifically

update gid_metadata_tbl
set    PULL_FROM_DATE_TYPE = 'DROP_WEEK', GID_TYPE_CD = 'DROP_WEEK'
where  substr(criteria_cd, 1, 1) = 'L' ;   --Honeywell sweep pull in June 2023
commit;

--2/8/2022  --we changed SM from 9 effort to 2 effort but didn't gid_metadata_tbl and was causing gid issues
update gid_metadata_tbl
set    MAX_NO_OF_MAILINGS = 2, SCORED_NO_OF_MAILINGS = 2
where  substr(criteria_cd, 1, 2) in ('RW') ;
commit;

select distinct GID_TYPE_CD, PULL_FROM_DATE_TYPE from gid_metadata_tbl order by PULL_FROM_DATE_TYPE;
--------------------------------------------------------------------------------
--deleting dupes
select * from gid_metadata_tbl where substr(criteria_cd, 1, 2) in ('RW') ;

select CRITERIA_CD, MAX_NO_OF_MAILINGS, SCORED_NO_OF_MAILINGS, GID_TYPE_CD, GID_SCORED_APPEND_CD, GID_CRITERIA_CD, PULL_FROM_DATE_TYPE
 from gid_metadata_tbl where substr(criteria_cd, 1, 2) in ('RW') 
group by CRITERIA_CD, MAX_NO_OF_MAILINGS, SCORED_NO_OF_MAILINGS, GID_TYPE_CD, GID_SCORED_APPEND_CD, GID_CRITERIA_CD, PULL_FROM_DATE_TYPE
having count(*) >= 2;

delete from  gid_metadata_tbl where criteria_cd = 'RW000' and rownum <= 1;
delete from  gid_metadata_tbl where criteria_cd = 'RW000N' and rownum <= 1;

commit;
--------------------------------------------------------------------------------