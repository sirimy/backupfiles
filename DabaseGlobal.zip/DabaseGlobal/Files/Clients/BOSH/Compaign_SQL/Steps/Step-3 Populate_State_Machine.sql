-------------------------------------------------------------------------------
create table state_tbl_20230404 as select * from gnrc.STATE_TBL;
select count(*) from state_tbl_20230404;  --7522
create table TRANSITION_TBL_20230404 as select * from gnrc.TRANSITION_TBL;
select count(*) from TRANSITION_TBL_20230404;  --9966
-------------------------------------------------------------------------------
select * from state_tbl order by state_xid, order_no;
select * from transition_tbl ;
select * from state_machine_cell_group_xref;
select * from state_machine_tbl;
--
delete from gnrcStg.state_tbl where STATE_KEY in (select s.state_key from gnrc.state_tbl s);
delete from transition_tbl where TRANSITION_KEY in (select t.TRANSITION_KEY from gnrc.transition_tbl t);;
delete from gnrcStg.state_machine_tbl where STATE_MACHINE_KEY in (select t.STATE_MACHINE_KEY from gnrc.state_machine_tbl t);
commit;

--delete from gnrcStg.state_tbl;
-- delete from gnrcStg.state_machine_tbl;
-- select * from transition_tbl ;
delete from gnrcStg.state_machine_cell_group_xref;
--
commit;
-------------------------------------------------------------------------------

select smcgx.*, cg.CELL_GROUP_XID, CELL_GROUP_NM, sm.STATE_MACHINE_XID, STATE_MACHINE_NM
from   state_machine_cell_group_xref smcgx join gnrc.cell_group_dim cg on cg.cell_group_key = smcgx.cell_group_key
       join gnrc.state_machine_tbl sm on sm.state_machine_key = smcgx.state_machine_key;


-- begin
--     --pk_campaign_utilities.prc_build_state_machine('UN-5','5','MAIL_LAST','42','Upgrade Mid');
--
--     pk_campaign_utilities.prc_build_state_cell_group('MP-5','MA-05');
--     pk_campaign_utilities.prc_build_state_cell_group('RR-2','MB-02');
-- end;

select * from state_tbl order by state_xid, order_no;
select * from transition_tbl ;
select * from state_machine_cell_group_xref;
select * from state_machine_tbl;

begin
    pk_campaign_utilities.prc_build_state_cell_group('UP-5','MU-05');
end;

select * from state_machine_cell_group_xref where (STATE_MACHINE_KEY, CELL_GROUP_KEY) in
                                                  (select STATE_MACHINE_KEY, CELL_GROUP_KEY from gnrc.state_machine_cell_group_xref);

select smcgx.*, cg.CELL_GROUP_XID, CELL_GROUP_NM, sm.STATE_MACHINE_XID, STATE_MACHINE_NM
from   state_machine_cell_group_xref smcgx join cell_group_dim cg on cg.cell_group_key = smcgx.cell_group_key
       join gnrc.state_machine_tbl sm on sm.state_machine_key = smcgx.state_machine_key;

select * from gnrc.state_machine_ext_tbl order by STATE_MACHINE_KEY desc;
-- insert into state_machine_ext_tbl select STATE_MACHINE_KEY, 'AM', INSERT_AUDIT_KEY from STATE_MACHINE_TBL sm;
-- commit;
select * from state_machine_ext_tbl ;

-- begin
--     P_PK_CORE_UPDATE.INSERT_TBL('state_machine_tbl');
--     P_PK_CORE_UPDATE.INSERT_TBL('state_tbl');
--     P_PK_CORE_UPDATE.INSERT_TBL('state_machine_ext_tbl');
-- end;

--bring state_tbl back to stg as it will be referred by transition_tbl
insert into state_tbl select * from gnrc.state_tbl where STATE_MACHINE_KEY = 87121;
--277 rows
commit ;

--now build transitions
--We updated delay days for certain transitions manually as required by the CR
-- begin
--     pk_campaign_utilities.prc_build_transitions (87121, p_days_between_efforts => 42);
-- end;

select * from transition_tbl ;
-- begin
--     P_PK_CORE_UPDATE.INSERT_TBL('transition_tbl');
-- end;


select smcgx.STATE_MACHINE_KEY, smcgx.CELL_GROUP_KEY,  cg.CELL_GROUP_XID, CELL_GROUP_NM, sm.STATE_MACHINE_XID, STATE_MACHINE_NM
from   state_machine_cell_group_xref smcgx join cell_group_dim cg on cg.cell_group_key = smcgx.cell_group_key
       join gnrc.state_machine_tbl sm on sm.state_machine_key = smcgx.state_machine_key;

--following can be core updated only after we have moved new cell groups to core
begin
    P_PK_CORE_UPDATE.INSERT_TBL('state_machine_cell_group_xref');
end;
-------------------------------------------------------------------------------
