select * from bundle_state_tbl  join p_state_machine_tbl using (state_machine_key)
 where bundle_key = 1857661;
 
select state_machine_key, state_machine_nm, count(*) 
  from bundle_state_tbl  join p_state_machine_tbl using (state_machine_key)
group by state_machine_key, state_machine_nm
order by state_machine_key, state_machine_nm;

select date_key, full_dt, count(*)
  from bundle_state_tbl  join date_dim using (date_key)
group by date_key, full_dt
order by date_key, full_dt;

select bs.state_machine_key, state_machine_nm, cl.cell_group_key, cl.cell_key, cell_nm, EFFORT_NO, count(*)
  from bundle_state_tbl bs  join bosh.state_machine_tbl sm on (sm.state_machine_key = bs.state_machine_key)
       join p_state_tbl s on (s.state_key  = bs.state_key)
       join (select * from cell_selection_fct cs
             union all
             select * from bosh.cell_selection_fct cs
            ) cs using (bundle_key)
       join bosh.cell_dim cl on (cl.cell_key = cs.cell_key)
 where 1=1
--    and state_type_cd <> 'X'
--    and STATE_CATEGORY_CD <> 'H'
--    and bundle_key NOT IN (select bundle_key from v_suppression_tbl sup )
--    and CELL_NM like '%POR%'
--    and CELL_XID like '%2'
   and s.EFFORT_NO = 1
 group by bs.state_machine_key, state_machine_nm, cl.cell_group_key, cl.cell_key, cell_nm, EFFORT_NO
 order by cl.cell_group_key, bs.state_machine_key, state_machine_nm, cell_nm, cl.cell_key, EFFORT_NO;


SELECT bd.*, s.state_nm
 FROM v_bundle_dim bd join P_customer_dim cust on (cust.customer_key = bd.customer_key) 
      join bosh.bundle_state_tbl bs on bs.bundle_key = bd.bundle_key  join p_state_tbl s on s.state_key = bs.state_key 
 WHERE NVL(derived_suppression_cd, 'N') = 'Y'
   and cust.customer_key IN (671408, 2609870)
   and bd.bundle_key not in (select sup.bundle_key from v_suppressioN_tbl sup);


select STATE_MACHINE_NM, STATE_CATEGORY_CD, min(creation_dt), max(creation_dt), count(*)
  from bundle_state_tbl bs join p_state_machine_tbl using (state_machine_key)
       join p_state_tbl using (state_key, state_machine_key)
       join date_dim dd on dd.date_key = bs.date_key
       join audit_tbl ai on audit_key = bs.insert_audit_key
       join bundle_dim bd using (bundle_key)
where  state_type_cd <> 'X'
and bundle_key NOT IN (select bundle_key from v_suppression_tbl sup )
-- and substr(GUARANTEE_ID_9, 7, 3) = 'BSH'        --Only Bosch leads get scored
group by STATE_MACHINE_NM, STATE_CATEGORY_CD
order by STATE_MACHINE_NM, STATE_CATEGORY_CD;