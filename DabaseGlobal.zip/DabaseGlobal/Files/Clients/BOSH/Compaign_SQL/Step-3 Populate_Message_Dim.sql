
select * from tmp_messages

;


-- select * from tmp_messages where MESSAGE_XID IN ('');

--  delete from tmp_messages;
--  commit;

delete from tmp_messages where trim(cell_xid) is null; 
--0 rows 
commit;

select distinct dm_copy_code from tmp_messages order by dm_copy_code;

-- select distinct dm_copy_code from tmp_messages where cell_xid like 'A610%' order by dm_copy_code;

select cell_xid from tmp_messages
minus
select cell_xid from BOSH.cell_dim cl ;
--no rows --good

-- delete from message_dim;
-- commit;
select * from message_dim;


-- delete from boshStg.message_dim;
-- commit;
--This is for DM_Copy_Code 
-- insert into message_dim (
--        MESSAGE_KEY, MESSAGE_XID, MESSAGE_NM, MESSAGE_DSC, CREATIVE_CD, CAMPAIGN_KEY, PROGRAM_KEY, CHANNEL_KEY, DIM_STATUS_CD,
--        COPY_CD, FORM_CD, OUTER_ENV_CD, BRE_CD, BROCHURE1_CD, BROCHURE2_CD,
--        VAR_TEXT1, VAR_TEXT2, VAR_TEXT3, VAR_TEXT4, VAR_TEXT5, VAR_TEXT6, VAR_TEXT7, VAR_TEXT8, VAR_TEXT9
--        ) --VENDOR_KEY,
select --campaign_seq.nextval,
       dm_copy_code as message_xid, dm_copy_code as message_nm, null, null, campaign_key, program_key, 1 AS CHANNEL_KEY, null,   
       dm_copy_code, form_cd, oe_cd, re_cd, brochure1_cd, BROCHURE2_CD, 
       VAR_TEXT1, VAR_TEXT2, VAR_TEXT3, VAR_TEXT4, VAR_TEXT5, VAR_TEXT6, VAR_TEXT7, VAR_TEXT8, VAR_TEXT9
  from (
         select distinct dm_copy_code, campaign_key, cmp.program_key, 1, null,   
               form_cd, oe_cd, re_cd, brochure1_cd, BROCHURE2_CD, 
               VAR_TEXT1, VAR_TEXT2, VAR_TEXT3, VAR_TEXT4, VAR_TEXT5, VAR_TEXT6, VAR_TEXT7, VAR_TEXT8, VAR_TEXT9
               --,-99 as insert_audit_key        
          from TMP_MESSAGES m join p_cell_dim c on (c.cell_xid = m.cell_xid)
               join p_cell_group_dim cg using (cell_group_key)
               join p_campaign_dim cmp using (campaign_key)
         where
               dm_copy_code NOT IN (
                  select m.message_xid from bosh.message_dim m)
       );
--2 rows
commit;

select distinct em_copy_code from tmp_messages order by em_copy_code;

--Emails
insert into message_dim (
       MESSAGE_KEY, MESSAGE_XID, MESSAGE_NM, MESSAGE_DSC, CREATIVE_CD, CAMPAIGN_KEY, PROGRAM_KEY, CHANNEL_KEY, DIM_STATUS_CD,
       COPY_CD
       ) --VENDOR_KEY,
select campaign_seq.nextval,
       em_copy_code as message_xid, em_copy_code as message_nm, null, null, campaign_key, program_key, 2 AS CHANNEL_KEY, 'Y',   
       em_copy_code       
  from (
         select distinct em_copy_code, campaign_key, cmp.program_key, 2, null,   
               form_cd, oe_cd, re_cd, brochure1_cd, BROCHURE2_CD, 
               VAR_TEXT1, VAR_TEXT2, VAR_TEXT3, VAR_TEXT4, VAR_TEXT5, VAR_TEXT6, VAR_TEXT7, VAR_TEXT8, VAR_TEXT9
               --,-99 as insert_audit_key        
          from TMP_MESSAGES m join cell_dim c on (c.cell_xid = m.cell_xid)
               join cell_group_dim cg using (cell_group_key)
               join campaign_dim cmp using (campaign_key)
         where 
               em_copy_code NOT IN (
                  select m.message_xid from bosh.message_dim m)      
       );
--2 rows
commit;


select * from message_dim;

select * from message_dim where message_xid  IN (select m.message_xid from bosh.message_dim m);
--no rows  --good

select * from state_message_xref;

delete from boshStg.state_message_xref;





select * from tmp_messages;

--DM
--insert into state_message_xref ( state_key, cell_key, message_key )
select 
       distinct 
        tmp, state_xid, effort_no,         --debug
       state_key, cell_key, message_key
        , cell_nm, state_nm, message_xid,cell_xid   --debug
  from ( 
        select distinct state_key, 
               cell_key,
               message_key,  
               state_xid, 
               ---
               sgx.state_machine_key || '-' || 
               case when cell_xid like '%01%' then '1'
                    when cell_xid like '%02%' then '2'
                    when cell_xid like '%03%' then '3' 
                    when cell_xid like '%04%' then '4'
                    when cell_xid like '%05%' then '5'
                    when cell_xid like '%06%' then '6'
                    when cell_xid like '%07%' then '7'
                end|| '-' ||                 
                case when cell_xid like '%01%' then '1'
                    when cell_xid like '%02%' then '2'
                    when cell_xid like '%03%' then '3' 
                    when cell_xid like '%04%' then '4'
                    when cell_xid like '%05%' then '5'
                    when cell_xid like '%06%' then '6'
                    when cell_xid like '%07%' then '7'
               end || '-' || 
                case when cell_xid not like '%10%' and s.effort_no <= 9 then to_char(s.effort_no)
                 end  || '-' || state_category_cd   AS  tmp, 
                s.effort_no,
                cell_xid, cell_nm
                ,state_nm, m.message_xid
           from tmp_messages t
                join p_cell_dim c
                using (cell_xid)
                left join bosh.state_machine_cell_group_xref sgx
                using (cell_group_key)
                left join bosh.state_tbl s
                on (s.state_machine_key = sgx.state_machine_key ) 
                left join p_message_dim m
                on t.dm_copy_code = m.copy_cd --and t.form_cd = m.form_cd   --form_cd was not available during initial setup
          where 1=1
            and (t.dm_copy_code is not null and t.dm_copy_code != '(blank)')
            and state_category_cd in ('B', 'M')
            and m.channel_key = 1
            and t.effort = s.effort_no
            --and NVL(c.control_ind, 'N') NOT IN ('C', 'Y')
--            and lower(cell_nm) like '%creative%'
            --and cell_nm like '%CANADA%'
--            and c.cell_key IN (25740)  --1086
     )
     where  1=1
       and state_xid = tmp
       and (state_key, cell_key, message_key) NOT IN (
            select state_key, cell_key, message_key from state_message_xref
            UNION ALL
            select state_key, cell_key, message_key from p_state_message_xref
           )
       --and cell_xid like 'AI01%'
-- order by tmp, state_xid desc
-- order by cell_nm, state_nm, message_xid
;   
--12 rows
commit;



--EMAIL 
insert into state_message_xref (
       state_key, cell_key, message_key )
select 
       distinct 
--        tmp, state_xid, effort_no,         --debug
       state_key, cell_key, message_key
--        , cell_nm, state_nm, message_xid   --debug
  from ( 
        select distinct state_key, 
               cell_key,
               message_key,  
               state_xid, 
               ---
               sgx.state_machine_key || '-' || 
               case when cell_xid like '%01%' then '1'
                    when cell_xid like '%02%' then '2'
                    when cell_xid like '%03%' then '3' 
                    when cell_xid like '%04%' then '4'
                    when cell_xid like '%05%' then '5'
                    when cell_xid like '%06%' then '6'
                    when cell_xid like '%07%' then '7'
                end|| '-' ||                 
                case when cell_xid like '%01%' then '1'
                    when cell_xid like '%02%' then '2'
                    when cell_xid like '%03%' then '3' 
                    when cell_xid like '%04%' then '4'
                    when cell_xid like '%05%' then '5'
                    when cell_xid like '%06%' then '6'
                    when cell_xid like '%07%' then '7'
               end || '-' || 
                case when cell_xid not like '%10%' and s.s.effort_no <= 9 then to_char(s.effort_no)
                    when cell_xid like '%10%' and s.effort_no <= 9 then to_char(s.effort_no)
                 end  || '-' || state_category_cd   AS  tmp, 
                s.effort_no,
                cell_xid, cell_nm
                ,state_nm, m.message_xid
           from tmp_messages t
                join p_cell_dim c
                using (cell_xid)
                left join bosh.state_machine_cell_group_xref sgx
                using (cell_group_key)
                left join bosh.state_tbl s
                on (s.state_machine_key = sgx.state_machine_key ) 
                left join p_message_dim m
                on t.em_copy_code = m.copy_cd 
          where 1=1
            and (t.em_copy_code is not null and t.em_copy_code != '(blank)')
            and state_category_cd in ('B', 'E')
            and m.channel_key = 2
            and t.effort = s.effort_no
            --and NVL(c.control_ind, 'N') NOT IN ('C', 'Y')
--            and lower(cell_nm) like '%creative%'
            --and cell_nm like '%CANADA%'
--            and c.cell_key IN (25740)  --1086
     )
     where  1=1
       and state_xid = tmp
       and (state_key, cell_key, message_key) NOT IN (
            select state_key, cell_key, message_key from state_message_xref
            UNION ALL
            select state_key, cell_key, message_key from p_state_message_xref
           )
-- order by tmp, state_xid desc
-- order by cell_nm, state_nm, message_xid
;
--12 rows
commit;   


select * from state_message_xref;
update state_message_xref set EXPIRATION_DAYS = 42;
commit;

select x.state_key, x.message_key, x.cell_key, state_nm, effort_no, message_nm, cell_nm, creation_dt
  from state_message_xref x left join audit_tbl a on (audit_key = insert_audit_key) 
       join p_state_tbl s on s.state_key = x.state_key 
       join (select * from message_dim m
             union all
             select * from bosh.message_dim m where m.MESSAGE_KEY not in (select s.MESSAGE_key from message_dim s)
          ) m on m.message_key = x.message_key
       join p_cell_dim cl on cl.cell_key = x.cell_key
 order by effort_no, message_nm, state_nm, cell_nm;
--24 rows --good

select * from state_message_xref;
select * from message_dim;

-- begin
--     p_pk_core_update.insert_tbl('message_dim');
--     p_pk_core_update.insert_tbl('state_message_xref');
-- end;


select distinct dm_copy_code from tmp_messages
 where dm_copy_code  IN (select m.message_xid from bosh.message_dim m);
--6 rows  --good


select creation_dt, x.state_key, x.message_key, x.cell_key, state_nm, effort_no, message_nm, cell_nm
  from bosh.state_message_xref x join audit_tbl a on (audit_key = insert_audit_key)
       join bosh.state_tbl s on s.state_key = x.state_key
       join bosh.message_dim m on m.message_key = x.message_key
       join bosh.cell_dim cl on cl.cell_key = x.cell_key
 where creation_dt >= date '2024-03-01'
 order by x.state_key, x.cell_key     
       ;
--24 rows --good



------------------------------------------------------------------------------
--Updating var texts for copy_cd  --this section may not be applicable all the time
------------------------------------------------------------------------------

select * from tmp_messages;
select * from tmp_messages where message_xid = '';

select * from message_dim;
delete from boshStg.message_dim;

insert into message_dim 
select * from bosh.message_dim m 
-- where copy_cd = '';
--  where copy_cd like 'G%RW%';
 where copy_cd in (select DM_COPY_CODE from tmp_messages);
--4 rows
commit; 

merge into message_dim tgt
using (
        select distinct 
               MESSAGE_XID, DM_COPY_CODE, EM_COPY_CODE, OB_COPY_CODE, VAR_TEXT1, VAR_TEXT2, 
               VAR_TEXT3, VAR_TEXT4, VAR_TEXT5, VAR_TEXT6, VAR_TEXT7, VAR_TEXT8, VAR_TEXT9, 
               FORM_CD, BROCHURE1_CD, BROCHURE2_CD, OE_CD, RE_CD, OFFER_EXPIRES_DATE 
          from tmp_messages
         --where message_xid = ''
         --where message_xid like 'G%RW%'
      ) src
 on (src.message_xid = tgt.copy_cd)
when matched then  
update
   set    tgt.VAR_TEXT1 = src.VAR_TEXT1
         ,tgt.VAR_TEXT2 = src.VAR_TEXT2
         ,tgt.VAR_TEXT3 = src.VAR_TEXT3
         ,tgt.VAR_TEXT4 = src.VAR_TEXT4
         ,tgt.VAR_TEXT5 = src.VAR_TEXT5
         ,tgt.VAR_TEXT6 = src.VAR_TEXT6
         ,tgt.VAR_TEXT7 = src.VAR_TEXT7
         ,tgt.VAR_TEXT8 = src.VAR_TEXT8
         ,tgt.VAR_TEXT9 = src.VAR_TEXT9 
         ,tgt.FORM_CD       = src.form_cd
         ,tgt.OUTER_ENV_CD  = src.oe_cd
         ,tgt.BRE_CD        = src.re_cd
         ,tgt.BROCHURE1_CD  = src.brochure1_cd
         ,tgt.BROCHURE2_CD  = src.BROCHURE2_CD;
         
select * from message_dim;

-- delete from message_dim m
--  where copy_cd like 'GEMRW%N';
--1 row

commit;

update MESSAGE_DIM tgt
set       tgt.VAR_TEXT1 = '''' || VAR_TEXT1 || ''''
         ,tgt.VAR_TEXT2 = '''' || VAR_TEXT2 || ''''
         ,tgt.VAR_TEXT4 = '''' || VAR_TEXT4 || ''''
         ,tgt.VAR_TEXT6 = '''' || VAR_TEXT6 || ''''
         ,tgt.VAR_TEXT7 = '''' || VAR_TEXT7 || ''''
;

commit;

--since some var texts had comma in the text so converted commands to semicolon ";" and then saved as csv using comma delimiter
-- and enclosed all values/columns with double quotes
--Imported this csv into TMP_MESSAGES and then removed double quotes and replaced ";" with comma
update TMP_MESSAGES tgt
set       tgt.VAR_TEXT1 = replace(VAR_TEXT1 , '"', '')
         ,tgt.VAR_TEXT2 = replace(VAR_TEXT2 , '"', '')
         ,tgt.VAR_TEXT4 = replace(VAR_TEXT4 , '"', '')
         ,tgt.VAR_TEXT6 = replace(VAR_TEXT6 , '"', '')
         ,tgt.VAR_TEXT7 = replace(VAR_TEXT7 , '"', '')
         ,tgt.CELL_XID = replace(CELL_XID , '"', '')
         ,tgt.MESSAGE_XID = replace(MESSAGE_XID , '"', '')
         ,tgt.DM_COPY_CODE = replace(DM_COPY_CODE , '"', '')
         ,tgt.FORM_CD = replace(FORM_CD , '"', '')
         ,tgt.BROCHURE1_CD = replace(BROCHURE1_CD , '"', '')
         ,tgt.OE_CD = replace(OE_CD , '"', '')
         ,tgt.RE_CD = replace(RE_CD , '"', '')
         ,tgt.OFFER_EXPIRES_DATE = replace(OFFER_EXPIRES_DATE , '"', '')
;

update TMP_MESSAGES tgt
set       tgt.VAR_TEXT1 = replace(VAR_TEXT1 , ';', ',')
         ,tgt.VAR_TEXT2 = replace(VAR_TEXT2 , ';', ',')
         ,tgt.VAR_TEXT4 = replace(VAR_TEXT4 , ';', ',')
         ,tgt.VAR_TEXT6 = replace(VAR_TEXT6 , ';', ',')
         ,tgt.VAR_TEXT7 = replace(VAR_TEXT7 , ';', ',')
;

select * from TMP_MESSAGES;

commit;

select * from message_dim;

merge into MESSAGE_DIM tgt
using (select * from bosh.MESSAGE_DIM src) src
on (src.MESSAGE_XID = tgt.MESSAGE_XID)
when matched then
update set tgt.MESSAGE_KEY = src.MESSAGE_KEY
where tgt.MESSAGE_KEY <> src.MESSAGE_KEY;
commit ;

--VAR_TEXT2 got truncated for all 3 copy codes of MPS and got fixed now
select  MESSAGE_XID, COPY_CD, VAR_TEXT1, VAR_TEXT2,
               VAR_TEXT3, VAR_TEXT4, VAR_TEXT5, VAR_TEXT6, VAR_TEXT7, VAR_TEXT8, VAR_TEXT9,
               FORM_CD, BROCHURE1_CD, BROCHURE2_CD, OUTER_ENV_CD, BRE_CD
from message_dim
    minus
--     union all
select  MESSAGE_XID, COPY_CD, VAR_TEXT1, VAR_TEXT2,
               VAR_TEXT3, VAR_TEXT4, VAR_TEXT5, VAR_TEXT6, VAR_TEXT7, VAR_TEXT8, VAR_TEXT9,
               FORM_CD, BROCHURE1_CD, BROCHURE2_CD, OUTER_ENV_CD, BRE_CD
from bosh.message_dim
where MESSAGE_XID in (select MESSAGE_XID from message_dim)
order by 1;
--3 rows

-- begin
--     p_pk_core_update.merge_tbl('message_dim');
-- end;

select * from MESSAGE_DIM
union all
select * from bosh.MESSAGE_DIM where MESSAGE_XID in (select m.message_xid from MESSAGE_DIM m)
order by 2;

-------------------------------------------------------------------------------

--We had created a copy_cd for NCOA Emails by mistake as we don;t need. Cleaning-up the same 

select * from bosh.message_dim m 
-- where copy_cd = '';
 where copy_cd like 'GEMRW%N';
 

select * from bosh.state_message_xref smx
where  message_key in ( 
           select message_key from bosh.message_dim m 
            -- where copy_cd = '';
           where  copy_cd like 'GEMRW%N'
           and    channel_key = 2
           );
/*STATE_KEY    CELL_KEY    MESSAGE_KEY    INSERT_AUDIT_KEY
57780    60965    64163    482061
57787    60965    64163    482061
57785    60965    64163    482061
57782    60965    64163    482061
*/

delete from bosh.state_message_xref smx
where  message_key in ( 
           select message_key from bosh.message_dim m 
            -- where copy_cd = '';
           where  copy_cd like 'GEMRW%N'
           and    channel_key = 2
           );           
--4 rows
commit;           


delete from bosh.message_dim m 
 where copy_cd like 'GEMRW%N';
--1 row
commit;
-------------------------------------------------------------------------------

select creation_dt, x.state_key, x.message_key, x.cell_key, state_nm, effort_no, message_nm, cell_nm
  from bosh.state_message_xref x join audit_tbl a on (audit_key = insert_audit_key)
       join bosh.state_tbl s on s.state_key = x.state_key
       join bosh.message_dim m on m.message_key = x.message_key
       join bosh.cell_dim cl on cl.cell_key = x.cell_key
 where creation_dt >= date '2020-01-20'       
 order by x.state_key, x.cell_key     
       ;   
--12 rows after having removed NCOA email message_key --good
