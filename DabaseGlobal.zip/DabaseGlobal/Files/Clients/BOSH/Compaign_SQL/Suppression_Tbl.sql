
select sup.suppression_cd, suppression_reason, count(*), count(distinct BUNDLE_KEY), sum(count(*)) over() as total
  from suppression_tbl sup --join BUNDLE_DIM using (bundle_key)
--  where inserted_dt >= trunc(sysdate)
--  where inserted_dt >= trunc(sysdate) - 2
 group by sup.suppression_cd, suppression_reason
 order by sup.suppression_cd, suppression_reason;

--delete from suppression_tbl;
--commit;
select * from suppression_tbl where bundle_key = 7214892;
select * from v_suppression_tbl where bundle_key = 8495532;
select * from v_suppression_tbl where SUPPRESSION_REASON = 'Invalid State Suppression';

select sup.suppression_cd, suppression_reason, count(*)
       --latest_coverage_type 
  from bosh.suppression_tbl sup left join bosh.audit_tbl a on (audit_key = insert_audit_key) 
       join bosh.bundle_dim bd using (bundle_key)
       join bosh.bundle_item_xref bix using (bundle_key)
       join bosh.serialized_item_dim si using (si_key)
 where nvl(inserted_dt, creation_dt) >= date '2022-08-20'
--   and lower(suppression_reason) like '%tax%'
 group by sup.suppression_cd, suppression_reason --, latest_coverage_type
 order by sup.suppression_cd, suppression_reason;

select suppression_cd, suppression_reason, count(*), sum(count(*)) over() as total 
  from v_suppression_tbl
 where bundle_key IN
        (SELECT bundle_key FROM campaign_participation_fct --join offer_xref using (offer_key)
        )
 group by suppression_cd, suppression_reason
 order by suppression_cd, suppression_reason;

select suppression_cd, suppression_reason, count(distinct bundle_key), sum(count(distinct bundle_key)) over() as total 
  from v_suppression_tbl
 where bundle_key IN
        (SELECT cp.bundle_key FROM bosh.campaign_participation_fct cp
        )
 group by suppression_cd, suppression_reason
 order by suppression_cd, suppression_reason;
 
  
select * from suppression_tbl
 where bundle_key not in (
           select bundle_key from bundle_dim
           union all
           select bundle_key from bosh.bundle_dim
           );
           
--delete from suppression_tbl
-- where bundle_key  in (
--           select bundle_key from suppression_tbl where bundle_key is not null 
--           minus
--           select bundle_key from bundle_dim
--           minus
--           select bundle_key from bosh.bundle_dim
--           );

select offer_key from campaign_participation_fct
 WHERE bundle_key NOT IN
        (SELECT bundle_key FROM V_SUPPRESSION_TBL)
minus
select offer_key from offer_xref;


select * from suppression_tbl where bundle_key  in ( select c.bundle_key from suppression_tbl c group by c.bundle_key having count(*) >= 2);


SELECT * FROM campaign_spool_file_tbl WHERE BUNDLE_KEY IN (SELECT BUNDLE_KEY FROM suppression_tbl);

select * from suppression_tbl where bundle_key  in ( select c.bundle_key from bosh.suppression_tbl c);
           
           
select sup.suppression_cd, suppression_reason, latest_coverage_type, count(*) 
  from bosh.suppression_tbl sup join bosh.audit_tbl a on (a.audit_key = sup.insert_audit_key) 
       join bosh.bundle_dim bd using (bundle_key)
       join bosh.bundle_item_xref bix using (bundle_key)
       join bosh.serialized_item_dim si using (si_key)
 where creation_dt >= date '2017-06-01'
--   and suppression_reason = 'Change of Coverage Type'
 group by sup.suppression_cd, suppression_reason , latest_coverage_type
 order by sup.suppression_cd, suppression_reason;


select suppression_cd, suppression_reason, to_char(inserted_dt, 'YYYYMM') as Yr_Month, count(*), sum(count(*)) over() as total
  from p_suppression_tbl
 where inserted_dt >= trunc(sysdate) - 365
-- where inserted_dt < trunc(sysdate) - 2
   and suppression_reason = 'Ace error stat' --'DPBC IS NULL'
 group by suppression_cd, suppression_reason, to_char(inserted_dt, 'YYYYMM')
 order by suppression_cd, suppression_reason, to_char(inserted_dt, 'YYYYMM');


-- begin
--     P_PK_CORE_UPDATE.INSERT_TBL('suppression_tbl');
-- end;