--effort_no,
select BRAND_FULL_DESC, criteria_cd, criteria_xid, substr(guarantee_id, 18, 1)  as effort, substr(guarantee_id, 10, 2) as campaign, count(*)
       ,count(case when CHANNEL_NM = 'MAIL' then BUNDLE_KEY end) as DMs
       ,count(case when CHANNEL_NM = 'EMAIL' then BUNDLE_KEY end) as EMs
  from campaign_spool_file_tbl
       join bundle_dim using (bundle_key)
       join p_criteria_dim using (criteria_key)
--       join campaign_participation_fct cp on reference_id = offer_key
--       join bosh.message_dim m on m.message_key = cp.message_key and m.channel_key = 1
--       join bosh.state_tbl s on s.state_key = cp.state_key
 where 1=1
--    and upper(channel_nm) = 'MAIL'
--    and substr(guarantee_id, 10, 2) = 'AS'
--    and BRAND_FULL_DESC <> 'Gaggenau'
--    and EMAIL_ADDRESS = 'ARCHANANALLA@GMAIL.COM'
--    and (p1_model_no IN ( 'HSLP751UC' ) or coalesce(p2_model_no, 'xyz') IN ( 'HSLP751UC' ) or
--         coalesce(p3_model_no, 'xyz') IN ( 'HSLP751UC' ) or coalesce(p4_model_no, 'xyz') IN ( 'HSLP751UC' ) or
--         coalesce(p5_model_no, 'xyz') IN ( 'HSLP751UC' )
--        )
group by BRAND_FULL_DESC, criteria_cd, criteria_xid, substr(guarantee_id, 18, 1), substr(guarantee_id, 10, 2)
order by BRAND_FULL_DESC, criteria_cd, criteria_xid;

select REFERENCE_ID, FIRST_NM, LAST_NM, STATE_CD, address_line1_tx, address_line2_tx, city_nm, EMAIL_ADDRESS, MIDDLE_NM
       ,MAIL_DROP_DATE, EMAIL_START_DT, channel_nm
       ,P1_serial_no, GUARANTEE_ID, P1_market_nm, P1_MODEL_NO, trunc(creation_dt) as Campaign_Pulled_Dt,
       CONTRACT_EXP_DT, RETAIL_PRICE_1YR_AMT, RETAIL_PRICE_2YR_AMT, RETAIL_PRICE_3YR_AMT, Customer_key
  from campaign_spool_file_tbl spl left join audit_tbl a on (audit_key = insert_audit_key)
 where 1=1
--   and reference_id = lpad(ltrim(:reference_id, '0'), '15', '0')
  and reference_id IN (
'008130119001969'
     )
--   and LAST_NM = 'CORBETT'
--   and customer_key = 1132338
--   and customer_key = :customer_key
--   and ( P1_SERIAL_NO IN
--         --('3007080586', '3007090582', '')
-- --     ('3010956741', '3007676932')
--     '3006681645'
--     )
-- and EMAIL_ADDRESS = 'ARCHANANALLA@GMAIL.COM'
-- and    channel_nm = 'MAIL'
-- and mail_drop_date >= date '2020-07-01'
order by P1_SERIAL_NO, mail_drop_date, p1_model_no, REFERENCE_ID, CHANNEL_NM;



select mail_drop_date, count(*) 
  from campaign_spool_file_tbl  
 where channel_nm = 'MAIL'
 group by mail_drop_date order by mail_drop_date;
 
SELECT brand_full_desc, CHANNEL_NM, count(*), count(distinct bundle_key)
  FROM campaign_spool_file_tbl
--  where CHANNEL_NM = 'MAIL'
 GROUP BY brand_full_desc, CHANNEL_NM order by 1, 2;


select distinct p1_product_desc, P1_MARKET_NM from campaign_spool_file_tbl;

select P1_MARKET_NM, count(*) from campaign_spool_file_tbl group by P1_MARKET_NM order by P1_MARKET_NM;

select distinct BRAND_FONT, BRAND_logo, brand_full_desc from campaign_spool_file_tbl;

select FIRM_NM, FIRST_NM, LAST_NM,  PURL, PURL_LINK_TXT, QR_CD 
  from campaign_spool_file_tbl
WHERE 1=1
  --AND firm_nm     IS NOT NULL
  and CHANNEL_NM = 'MAIL'
  AND ( first_nm      LIKE '%*%' OR first_nm      LIKE '%"%' OR first_nm      LIKE '%)%' OR REGEXP_LIKE (first_nm, '[[:digit:]]') );


select BRAND_FONT, FIRM_NM, FIRST_NM, LAST_NM, PURL, PURL_LINK_TXT, QR_CD
  from campaign_spool_file_tbl
 where last_nm = 'Customer'
 order by dbms_random.random;

 
select BRAND_FONT, FIRM_NM, FIRST_NM, LAST_NM, PURL, PURL_LINK_TXT, QR_CD
  from campaign_spool_file_tbl
 where last_nm <> 'Customer'
 order by dbms_random.random;  

 
select distinct substr(guarantee_id, 12, 3) as Months, substr(guarantee_id, 14, 2) as Weeks, substr(guarantee_id, 17, 2) as Efforts
  from campaign_spool_file_tbl
 where guarantee_id like '%AS%'
-- order by guarantee_id
order by 1, 2;

--FORM_CD
select distinct BRAND_Font, COPY_CD, VAR_TEXT1, VAR_TEXT2, VAR_TEXT3, VAR_TEXT4, TEXT_1 AS VAR_TEXT5, TEXT_2 AS VAR_TEXT6, TEXT_3 AS VAR_TEXT7, TEXT_4 AS VAR_TEXT8, TEXT_5 AS VAR_TEXT9
  from campaign_spool_file_tbl
 where BRAND_Font = 'Gaggenau'
 order by COPY_CD, VAR_TEXT1, VAR_TEXT2, VAR_TEXT3, VAR_TEXT4, TEXT_1, TEXT_2, TEXT_3, TEXT_4, TEXT_5;
 
select COPY_CD, Channel_nm, VAR_TEXT1 as variable1, VAR_TEXT2 as variable2, VAR_TEXT3 as variable3, VAR_TEXT4 as variable4, 
       TEXT_1 as variable5, TEXT_2 as variable6, TEXT_3 as variable7, TEXT_4 as variable8, TEXT_5 as variable9
       ,count(*) 
  from campaign_spool_file_tbl 
 group by COPY_CD, Channel_nm, VAR_TEXT1, VAR_TEXT2, VAR_TEXT3, VAR_TEXT4, TEXT_1, TEXT_2, TEXT_3, TEXT_4, TEXT_5  
order by COPY_CD, Channel_nm, VAR_TEXT1, VAR_TEXT2, VAR_TEXT3, VAR_TEXT4, TEXT_1, TEXT_2, TEXT_3, TEXT_4, TEXT_5;


select MAIL_DROP_DATE, copy_cd, form_cd, count(*) from campaign_spool_file_tbl
 group by MAIL_DROP_DATE, copy_cd, form_cd
 order by MAIL_DROP_DATE, copy_cd, form_cd;


select *  from campaign_spool_file_tbl 
 where 1=1
   and email_start_dt is not null and email_start_dt <> mail_drop_date + 8;
   

--dupes in campaign   
select * from campaign_spool_file_tbl
 where p1_serial_no IN (
        select i.p1_serial_no from campaign_spool_file_tbl i
        group by i.p1_serial_no, copy_cd
        having count(*) >= 2
        )
 order by p1_serial_no;     
    

--Per conversation on call 3/1/17, agreed to only solicit 1 & 2 year warranty terms for launch. 
--Suppress all not = 12 or 24 mo min. warranty term.  All terms are allowed for AO campaign.
select *  from campaign_spool_file_tbl
-- where guarantee_id like '%GNP%' 
 where 1 = 1
   and p1_warranty_expiration_dt - product_purchase_dt > 731     --p1_coverage_start_dt
   and (guarantee_id not like '%HNHAO%' and guarantee_id not like '%GNHAO%');
   
   
select p1_serial_no, p1_warranty_expiration_dt, product_purchase_dt, p1_warranty_expiration_dt - product_purchase_dt
  from campaign_spool_file_tbl
-- where guarantee_id like '%GNP%' 
 where 1=1
   and p1_warranty_expiration_dt - product_purchase_dt > 731 --< 365     --p1_coverage_start_dt
   and (guarantee_id not like '%HNHAO%' and guarantee_id not like '%GNHAO%')
   ;   
        

--DPBC should be not null for all mails   
SELECT count(*) 
  FROM campaign_spool_file_tbl
 WHERE dpbc         IS NULL
   AND UPPER(channel_nm) = 'MAIL';

--ace_error_cd should not be E (Error) for mails
SELECT count(*) 
  FROM campaign_participation_fct cpf
       JOIN campaign_spool_file_tbl csft
          ON reference_id = offer_key
       JOIN p_address_dim ad USING (address_key)
 WHERE substr(ace_error_cd,1,1) = 'E'
   AND UPPER(channel_nm) = 'MAIL';


--Do we expect blank sec_codes? => Joan confirmed this is correct
--Sec_code will be blank for firms
select * from campaign_spool_file_tbl where sec_code is null;
 
 
SELECT count(*)  FROM campaign_spool_file_tbl WHERE UPPER(channel_nm) = 'MAIL';
--154759
 
select count(*) from campaign_spool_seed_tbl  WHERE UPPER(channel_nm) = 'MAIL';
--30 


select reference_id from campaign_spool_file_tbl
minus
select offer_key from offer_xref;
-- no rows --good

select count(*) from (
    select reference_id from campaign_spool_file_tbl
    intersect
    select offer_key from offer_xref);
--154759 --good

select count(*) from (
    select bundle_key from campaign_spool_file_tbl
    intersect
    select bundle_key from campaign_participation_fct );
--268971  --good    

select MAIL_DROP_DATE, EST_MAIL_IN_HOME_DT, EMAIL_START_DT, OFFER_EXPIRE_DT, channel_nm, count(*)  
  from campaign_spool_file_tbl
group by MAIL_DROP_DATE, EST_MAIL_IN_HOME_DT, EMAIL_START_DT, OFFER_EXPIRE_DT, channel_nm
order by MAIL_DROP_DATE, EST_MAIL_IN_HOME_DT, EMAIL_START_DT, OFFER_EXPIRE_DT, channel_nm; 



select suppression_cd, suppression_reason, count(*), sum(count(*)) over() as total 
  from v_suppression_tbl
 where bundle_key IN
        (SELECT bundle_key FROM campaign_participation_fct --join offer_xref using (offer_key)
        )
 group by suppression_cd, suppression_reason
 order by suppression_cd, suppression_reason;

--This QC should return NO records
select bundle_key, si_key from campaign_spool_file_tbl spl join bundle_item_xref using (bundle_key)
       join bosh.serialized_item_dim using (si_key)
 where latest_coverage_type <> 1;  
 
select latest_coverage_type, count(*) 
 from campaign_spool_file_tbl spl --join bundle_item_xref using (bundle_key)
       join bosh.serialized_item_dim si on si.serial_no = p1_serial_no
 group by latest_coverage_type;       
        
 select distinct P1_MARKET_NM from campaign_spool_file_tbl;

   
select P1_MARKET_NM, substr(guarantee_id, -3, 1) as effort   
       ,count(distinct serial_no)
  from campaign_spool_file_tbl spl --join bundle_item_xref using (bundle_key)
       join bosh.serialized_item_dim si on si.serial_no = p1_serial_no
       join bosh.serialized_item_ext_dim six on six.si_key = si.si_key
 where substr(guarantee_id, 10, 2) = 'AO'   
 group by P1_MARKET_NM, substr(guarantee_id, -3, 1)
 order by P1_MARKET_NM, substr(guarantee_id, -3, 1); 


--Following sql should return NO rows
 select channel_nm, mail_drop_date, email_start_dt, p1_serial_no 
  from 
       campaign_spool_file_tbl spl join bosh.customer_dim cust on cust.customer_key = spl.customer_key
 where ( NVL(DERIVED_SUPPRESSION_CD, 'N') = 'Y'        )
;

select * from (select * from campaign_spool_file_tbl order by dbms_random.random) where rownum <= 50 ;


--at effort level
select BRAND_FULL_DESC, cell_group_key, criteria_key, cp.cell_key, cell_nm, control_ind, effort_no, count(*)
  from campaign_spool_file_tbl spl
       join bosh.message_dim m on m.copy_cd = spl.copy_cd
       join campaign_participation_fct cp on cp.offer_key = spl.reference_id and cp.MESSAGE_KEY = m.message_key
       join bosh.state_tbl s ON (s.state_key = cp.state_key)
       join bosh.cell_dim cl on cl.cell_key = cp.cell_key
       left join bosh.criteria_cell_xref ccx on (ccx.cell_key = cp.cell_key)
       left join bosh.criteria_dim cri using(criteria_key)
where CHANNEL_NM = 'MAIL'
--and   cell_nm not like '%%'
group by BRAND_FULL_DESC,cell_group_key, criteria_key, effort_no, cp.cell_key, cell_nm, control_ind
order by BRAND_FULL_DESC,cell_group_key, criteria_key, effort_no, cp.cell_key, cell_nm, control_ind
;

select * from (select * from campaign_spool_file_tbl where BRAND_FULL_DESC = 'Gaggenau' order by dbms_random.random) where rownum <= 10 ;



SELECT BRAND_FULL_DESC, BRAND_LOGO, spl.* FROM campaign_spool_file_tbl spl;

SELECT BRAND_FULL_DESC, BRAND_LOGO, spl.* FROM campaign_spool_file_tbl spl
 WHERE ( first_nm      LIKE '%*%' OR first_nm      LIKE '%"%' OR first_nm      LIKE '%)%' OR REGEXP_LIKE (first_nm, '[[:digit:]]') )
   AND   CHANNEL_NM = 'MAIL';
--15 rows


--new model QA
select spl.BRAND_FULL_DESC, pr.MARKETING_PRODUCT_NM, spl.model_no,  count(distinct BUNDLE_KEY) as Bundles
from   (
        select model_no, REFERENCE_ID, BUNDLE_KEY, BRAND_FULL_DESC
          from campaign_spool_file_tbl spl
               unpivot(model_no for (p_model_no) in (P1_MODEL_NO, P2_MODEL_NO, P3_MODEL_NO, P4_MODEL_NO, P5_MODEL_NO))
               --join bundle_item_xref using (bundle_key)
               --join bosh.serialized_item_dim si on si.serial_no = p1_serial_no
               --join bosh.serialized_item_ext_dim six on six.si_key = si.si_key
              ) spl
        join bosh.PRODUCT_DIM pr on pr.MODEL_NO = spl.model_no
        join AUDIT_TBL ai on ai.AUDIT_KEY = pr.INSERT_AUDIT_KEY
where  ai.CREATION_DT >= date '2022-04-01'
group by spl.model_no, spl.BRAND_FULL_DESC, pr.MARKETING_PRODUCT_NM
order by spl.BRAND_FULL_DESC, spl.model_no;


SELECT source, count(distinct oix.BUNDLE_KEY)
  FROM campaign_spool_file_tbl spl
       join OFFER_ITEM_XREF oix on oix.OFFER_KEY = spl.REFERENCE_ID
       join P_SERIALIZED_ITEM_ext_DIM six using (si_key)
 where 1=1 and CHANNEL_NM = 'MAIL'
group by source order by source;


select substr(guarantee_id, 10, 2) as campaign
       ,count(distinct BUNDLE_KEY)
  from campaign_spool_file_tbl spl --join bundle_item_xref using (bundle_key)
--  where substr(guarantee_id, 10, 2) = 'RW'
 group by substr(guarantee_id, 10, 2)
 order by substr(guarantee_id, 10, 2);


select BRAND_FULL_DESC, P1_MARKET_NM
  from bosh.CAMPAIGN_SPOOL_FILE_TBL where MAIL_DROP_DATE >= date '2022-01-01'
group by BRAND_FULL_DESC, P1_MARKET_NM
order by BRAND_FULL_DESC, P1_MARKET_NM;