select count(*) from bundle_state_tbl;--230826
select count(*) from BUNDLE_TRANSITION_HIST;--230826

-- CREATE TABLE bundle_state_tbl_march_2024 AS (SELECT * FROM bundle_state_tbl);
select count(*) from bundle_state_tbl_march_2024;--230826

--CREATE TABLE BUNDLE_TRANSITION_HIST_march_2024 AS (SELECT * FROM BUNDLE_TRANSITION_HIST);
select count(*) from BUNDLE_TRANSITION_HIST_march_2024;--230826


--insert into v_sm_score_transition2 (bundle_key, score)
select COUNT(bs.bundle_key) --, bs.value_no as score
  from v_bundle_summary_tbl bs join v_bundle_dim bd on bd.bundle_key = bs.bundle_key
 where --bs.variable_key = 1
  bd.bundle_key in (  select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                               join BUNDLE_DIM bd using (bundle_key)
                               join P_CRITERIA_DIM cri using (criteria_key)
                               join p_campaign_dim using (campaign_key)
                        where 1=1  and CELL_NM  like '%Thermador%');--0


select COUNT(*) from v_sm_score_transition2 ;--1848976

-- TRUNCATE TABLE v_sm_score_transition2;
-- COMMIT;

insert into v_sm_score_transition2 (bundle_key, score)
    select  BUNDLE_KEY,1  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                               join BUNDLE_DIM bd using (bundle_key)
                               join P_CRITERIA_DIM cri using (criteria_key)
                               join p_campaign_dim using (campaign_key)
                        where 1=1  and CELL_NM  like '%Thermador%';
--         select bs.bundle_key, bs.value_no as score
--           from v_bundle_summary_tbl bs join v_bundle_dim bd on bd.bundle_key = bs.bundle_key
--          where bs.variable_key = 1
--COMMIT;


select * from v_sm_score_transition2 where BUNDLE_KEY  in (  select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                               join BUNDLE_DIM bd using (bundle_key)
                               join P_CRITERIA_DIM cri using (criteria_key)
                               join p_campaign_dim using (campaign_key)
                        where 1=1  and CELL_NM  like '%Thermador%');--0


select count(*) from v_sm_score_transition2 where BUNDLE_KEY   in ( SELECT   bundle_key FROM v_base_offer_item_discount where bundle_discount_key= 3 );--1824

----------------------------------------------------------
--------------------BUNDLE_SUMMARY_TBL-------------------
----------------------------------------------------------
-- INSERT ALL
--        INTO   BUNDLE_SUMMARY_TBL (BUNDLE_KEY, MONTH_KEY, VARIABLE_KEY, VALUE_NO, EFFORT_NO)
--        VALUES (bundle_key, drop_month, 1, no_of_mailings, effort_no)
--        INTO   BUNDLE_SUMMARY_TBL (BUNDLE_KEY, MONTH_KEY, VARIABLE_KEY, VALUE_NO, EFFORT_NO)
--        VALUES (bundle_key, drop_month, 2, profit_score, effort_no)
       SELECT BUNDLE_KEY, no_of_mailings, PROFIT_SCORE, effort_no, drop_month
       FROM  (
             select b.bundle_key,
                     CASE WHEN trunc(profit_score,3) between trunc(low_score_value,3) and trunc(high_score_Value,3)
                           and drop_month between start_month_key and end_month_key
                           and rno <=nvl(quantity_amt, 100000000000000000000)  THEN
                               sc.no_of_mailings
                      END no_of_mailings,
                    profit_score,
                    effort_no,
                    drop_month
             from
                  (select tmp.*, row_number() over (partition by no_of_mailings order by dbms_random.random()) rno
                   from
                         (select distinct a.bundle_key,
                                  profit_score,
                                  CASE WHEN trunc(profit_score,3) between trunc(low_score_value,3) and trunc(high_score_Value,3)
                                        AND to_number(to_char(DROP_DT, 'YYYYMM')) between start_month_key and end_month_key THEN
                                            sc.no_of_mailings
                                  END no_of_mailings,
                                  c.criteria_key,
                                  to_number(to_char(b.DROP_DT, 'YYYYMM')) as drop_month
                          from
                                 (select * from esp_AM_Scr_output_tbl r
                                                   UNPIVOT((SI_KEY) for n in ( (SI_KEY1) AS 1,(SI_KEY2) AS 2,(SI_KEY3) AS 3,(SI_KEY4) AS 4,(SI_KEY5) AS 5))
                                  ) a
                                 left join bundle_dim b on (a.bundle_key = b.bundle_key)
                                 left join p_criteria_dim c on (b.criteria_key = c.criteria_key)
                                 left join p_score_metadata_Tbl sc on (campaign_cd = scoring_file_cd)
                                 join p_serialized_item_dim s on (a.si_key = s.si_key)
                                 join p_product_dim p on (s.product_key = p.product_key)
                          where 1=1
                         ) tmp
                   where 1=1
                   and   no_of_mailings is not null
                  ) a
                  left join bundle_dim b on (a.bundle_key = b.bundle_key)
                  left join p_criteria_dim c on (b.criteria_key = c.criteria_key)
                  left join p_score_metadata_Tbl sc on (campaign_cd = scoring_file_cd)
           )
       WHERE  no_of_mailings is not null;


SELECT state_key
      FROM bundle_state_tbl
      JOIN p_state_tbl USING (state_key)
      WHERE state_type_cd       <> 'X'
      AND state_category_cd NOT IN ('W', 'H', 'S', 'R')
      MINUS
      SELECT state_key FROM p_state_message_xref;


SELECT state_key, cell_key
         FROM bundle_state_tbl bs
              JOIN p_state_tbl USING (state_key)
              JOIN (select cs.bundle_key, cs.cell_key from p_cell_selection_fct cs
                    union all
                    select cs.bundle_key, cs.cell_key from cell_selection_fct cs
                    ) cs
                    using (bundle_key)
              JOIN p_cell_dim cl USING (cell_key)

        WHERE state_type_cd       <> 'X'
          AND state_category_cd NOT IN ('W', 'H', 'S', 'R')
          AND NVL(cl.control_ind, 'N') NOT IN ('C')
          --we are forced to exclude suppressed bundles here as there is some bug in state machine and bundles are not exiting from there
          AND bundle_key NOT IN (select sup.bundle_key from v_suppression_tbl sup)
       MINUS
       SELECT state_key, cell_key FROM p_state_message_xref    ;

select * from p_message_dim cl where  cl.copy_cd ='THEEMEs1a';

select * from tmp_messages where CELL_XID = 'EB02-THR-C2';

--Inserted this set to make it move forwaord
+---------+--------+
|STATE_KEY|CELL_KEY|
+---------+--------+
|17159    |21022   |6818|
|17159    |21033   |6818|
|17185    |21021   |6818|
|17185    |21032   |6818|
|17318    |21026   |6823|
|17318    |21037   |6823|
|17319    |21026   |6823|
+---------+--------+

+--------+-----------+----------------------------------------------------------+-----------+-------++---------+-------------+------------------------+------------------------+
|CELL_KEY|CELL_XID   |CELL_NM                                                   |CONTROL_IND|CELL_CD||STATE_KEY|STATE_XID    |STATE_NM                |STATE_DSC               |
+--------+-----------+----------------------------------------------------------+-----------+-------++---------+-------------+------------------------+------------------------+
|21021   |AI02-THR-C2|Aftermarket 2 Effort - Thermador - Bundle Discount Control|B          |14     ||17185    |17122-2-1-1-E|Aftermarket  - Email - 1|Aftermarket  - Email - 1|
|21022   |AI03-THR-C2|Aftermarket 3 Effort - Thermador - Bundle Discount Control|B          |14     ||17159    |17122-3-1-1-E|Aftermarket  - Email - 1|Aftermarket  - Email - 1|
|21026   |EB02-THR-C2|Early Bird 2 Effort - Thermador - Bundle Discount Control |B          |14     ||17318    |17300-2-1-1-M|Early Bird  - Mail - 2  |Early Bird  - Mail - 2  |
|21026   |EB02-THR-C2|Early Bird 2 Effort - Thermador - Bundle Discount Control |B          |14     ||17319    |17300-2-1-1-E|Early Bird  - Email - 2 |Early Bird  - Email - 2 |
|21032   |AI02-THR-T2|Aftermarket 2 Effort - Thermador - Bundle Discount Test   |T          |15     ||17185    |17122-2-1-1-E|Aftermarket  - Email - 1|Aftermarket  - Email - 1|
|21033   |AI03-THR-T2|Aftermarket 3 Effort - Thermador - Bundle Discount Test   |T          |15     ||17159    |17122-3-1-1-E|Aftermarket  - Email - 1|Aftermarket  - Email - 1|
|21037   |EB02-THR-T2|Early Bird 2 Effort - Thermador - Bundle Discount Test    |T          |15     ||17318    |17300-2-1-1-M|Early Bird  - Mail - 2  |Early Bird  - Mail - 2  |
+--------+-----------+----------------------------------------------------------+-----------+-------+
select * from BOSH.STATE_TBL where STATE_KEY =     17176;
+--------------------------+---------------------------------+-----------+------------+---------+---------+--------+-----------+----------------+----------------+---------------+
|CREATION_DT               |STATE_NM                         |CELL_XID   |OUTER_ENV_CD|COPY_CD  |STATE_KEY|CELL_KEY|MESSAGE_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|EXPIRATION_DAYS|
+--------------------------+---------------------------------+-----------+------------+---------+---------+--------+-----------+----------------+----------------+---------------+
|2024-03-06 06:41:38.000000|Aftermarket  - Mail - 2          |AI02-THR-C2|BTOE0217.1  |THEDMAI2a|17180    |21021   |6763       |779935          |NULL            |42             |
|2024-03-06 06:41:38.000000|Aftermarket  - Mail and Email - 1|AI02-THR-C2|BTOE0217.1  |THEDMAI1a|17174    |21021   |6756       |779935          |NULL            |42             |
|2024-03-06 06:41:38.000000|Aftermarket  - Email - 2         |AI02-THR-C2|NULL        |THEEMAI2a|17181    |21021   |6821       |779935          |NULL            |42             |
|2024-03-06 06:41:38.000000|Aftermarket  - Mail and Email - 1|AI02-THR-C2|NULL        |THEEMAI1a|17174    |21021   |6818       |779935          |NULL            |42             |
|2024-03-06 06:41:38.000000|Aftermarket  - Mail and Email - 2|AI02-THR-C2|BTOE0217.1  |THEDMAI2a|17179    |21021   |6763       |779935          |NULL            |42             |
|2024-03-06 06:41:38.000000|Aftermarket  - Email - 1         |AI02-THR-C2|NULL        |THEEMAI1a|17176    |21021   |6818       |779935          |NULL            |42             |
|2024-03-06 06:41:38.000000|Aftermarket  - Mail - 1          |AI02-THR-C2|BTOE0217.1  |THEDMAI1a|17175    |21021   |6756       |779935          |NULL            |42             |
|2024-03-06 06:41:38.000000|Aftermarket  - Mail and Email - 2|AI02-THR-C2|NULL        |THEEMAI2a|17179    |21021   |6821       |779935          |NULL            |42             |
+--------------------------+---------------------------------+-----------+------------+---------+---------+--------+-----------+----------------+----------------+---------------+

--EMAIL
-- insert into state_message_xref (
--        state_key, cell_key, message_key )
select
       distinct
        tmp, state_xid, effort_no,         --debug
       state_key, cell_key, message_key
        , cell_nm, state_nm, message_xid   --debug
  from (
        select distinct state_key,
               cell_key,
               message_key,
               state_xid,
               ---
               sgx.state_machine_key || '-' ||
               case when cell_xid like '%01%' then '1'
                    when cell_xid like '%02%' then '2'
                    when cell_xid like '%03%' then '3'
                    when cell_xid like '%04%' then '4'
                    when cell_xid like '%05%' then '5'
                    when cell_xid like '%06%' then '6'
                    when cell_xid like '%07%' then '7'
                end|| '-' ||
                case when cell_xid like '%01%' then '1'
                    when cell_xid like '%02%' then '2'
                    when cell_xid like '%03%' then '3'
                    when cell_xid like '%04%' then '4'
                    when cell_xid like '%05%' then '5'
                    when cell_xid like '%06%' then '6'
                    when cell_xid like '%07%' then '7'
               end || '-' ||
                case when cell_xid not like '%10%' and s.s.effort_no <= 9 then to_char(s.effort_no)
                    when cell_xid like '%10%' and s.effort_no <= 9 then to_char(s.effort_no)
                 end  || '-' || state_category_cd   AS  tmp,
                s.effort_no,
                cell_xid, cell_nm
                ,state_nm, m.message_xid
           from tmp_messages t
                join p_cell_dim c
                using (cell_xid)
                left join bosh.state_machine_cell_group_xref sgx
                using (cell_group_key)
                left join bosh.state_tbl s
                on (s.state_machine_key = sgx.state_machine_key )
                left join p_message_dim m
                on t.em_copy_code = m.copy_cd
          where 1=1
            and (t.em_copy_code is not null and t.em_copy_code != '(blank)')
            and state_category_cd in ('B', 'E')
            and m.channel_key = 2
            and t.effort = s.effort_no
            --and NVL(c.control_ind, 'N') NOT IN ('C', 'Y')
--            and lower(cell_nm) like '%creative%'
            --and cell_nm like '%CANADA%'
--            and c.cell_key IN (25740)  --1086
     )
     where  1=1
       and state_xid = tmp
       and (state_key, cell_key, message_key) NOT IN (
            select state_key, cell_key, message_key from state_message_xref
            UNION ALL
            select state_key, cell_key, message_key from p_state_message_xref
           )
        and CELL_KEY in (
            21022,
            21033,
            21021,
            21032,
            21026,
            21037,
            21026
                );

select * from  tmp_messages t
    where t.em_copy_code not in (  Select m.copy_cd from p_message_dim m);

select T2.CREATION_DT,T1.* from BOSH.CELL_DIM T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
where 1=1 and CELL_KEY in (
21022,
21033,
21021,
21032,
21026,
21037,
21026
    )
Order by T2.CREATION_DT DESC,CELL_KEY
;-- 22 new add here 11 B and 11 T for same set
select * from BOSH.STATE_TBL where STATE_KEY in (17159,
17159,
17185,
17185,
17318,
17318,
17319
);
+---------+-------------+------------------------+------------------------+
|STATE_KEY|STATE_XID    |STATE_NM                |STATE_DSC               |
+---------+-------------+------------------------+------------------------+
|17159    |17122-3-1-1-E|Aftermarket  - Email - 1|Aftermarket  - Email - 1|
|17185    |17122-2-1-1-E|Aftermarket  - Email - 1|Aftermarket  - Email - 1|
|17318    |17300-2-1-1-M|Early Bird  - Mail - 2  |Early Bird  - Mail - 2  |
|17319    |17300-2-1-1-E|Early Bird  - Email - 2 |Early Bird  - Email - 2 |
+---------+-------------+------------------------+------------------------+


select T2.CREATION_DT,T3.STATE_NM,T4.CELL_XID,T5.OUTER_ENV_CD,T5.COPY_CD,T1.* from BOSH.state_message_xref T1 join AUDIT_TBL T2 on T1.INSERT_AUDIT_KEY =T2.AUDIT_KEY
                            join BOSH.STATE_TBL T3 on T3.STATE_KEY =T1.STATE_KEY
                           join BOSH.CELL_DIM T4 on T4.CELL_KEY =T1.CELL_KEY
                           join BOSH.MESSAGE_DIM T5 on T5.MESSAGE_KEY =T1.MESSAGE_KEY
where 1=1 and T4.CELL_KEY in (
21022,
21033,
21021,
21032,
21026,
21037,
21026
    )
Order by T2.CREATION_DT DESC,T4.CELL_KEY

SELECT COUNT (*)

    from  P_STATE_TBL
    where (EFFORT_NO is not null and gid_effort_no is null) or (EFFORT_NO is null and gid_effort_no is not null);