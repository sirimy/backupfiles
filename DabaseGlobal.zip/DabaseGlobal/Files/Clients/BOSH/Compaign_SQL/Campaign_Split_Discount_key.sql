

select cell_group_key, cell_group_nm, CELL_KEY, replace(replace(CELL_NM, 'Control'), 'Test'), CONTROL_IND, count(*)
       ,sum(count(*)) over(partition by  cell_group_key ) as grp_cnt
  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
       left join fas.date_dim using (date_key)
  where CELL_NM like '%Thermador%'
 group by cell_group_key, cell_group_nm, CELL_KEY, replace(replace(CELL_NM, 'Control'), 'Test'), CONTROL_IND
 order by cell_group_nm, replace(replace(CELL_NM, 'Control'), 'Test'), CELL_KEY, CONTROL_IND;
+--------------+-----------------------------+--------+--------------------------------------------------------------+-----------+--------+-------+
|CELL_GROUP_KEY|CELL_GROUP_NM                |CELL_KEY|REPLACE(REPLACE(CELL_NM,'CONTROL'),'TEST')                    |CONTROL_IND|COUNT(*)|GRP_CNT|
+--------------+-----------------------------+--------+--------------------------------------------------------------+-----------+--------+-------+
|19141         |Renewal Winback OOW 3 Efforts|21030   |Renewal Winback OOW - Thermador - 3 efforts - Bundle Discount |B          |40      |80     |
|19141         |Renewal Winback OOW 3 Efforts|21041   |Renewal Winback OOW - Thermador - 3 efforts - Bundle Discount |T          |40      |80     |
+--------------+-----------------------------+--------+--------------------------------------------------------------+-----------+--------+-------+


select * from p_cell_group_dim where CELL_GROUP_KEY in (19141);
+--------------+--------------+-----------------------------+------------+-------------+
|CELL_GROUP_KEY|CELL_GROUP_XID|CELL_GROUP_NM                |CAMPAIGN_KEY|DIM_STATUS_CD|
+--------------+--------------+-----------------------------+------------+-------------+
|19141         |RW-03         |Renewal Winback OOW 3 Efforts|19140       |Y            |
+--------------+--------------+-----------------------------+------------+-------------+

select * from p_cell_dim where CELL_KEY in (21030,21041);
+--------+-----------+---------------------------------------------------------------------+-------+-----------+--------------+
|CELL_KEY|CELL_XID   |CELL_NM                                                              |CELL_CD|CONTROL_IND|CELL_GROUP_KEY|
+--------+-----------+---------------------------------------------------------------------+-------+-----------+--------------+
|21030   |RW03-THR-C2|Renewal Winback OOW - Thermador - 3 efforts - Bundle Discount Control|14     |B          |19141         |
|21041   |RW03-THR-T2|Renewal Winback OOW - Thermador - 3 efforts - Bundle Discount Test   |15     |T          |19141         |
+--------+-----------+---------------------------------------------------------------------+-------+-----------+--------------+


select * from cell_selection_fct where CELL_KEY in (21030,21041);--80
select CELL_KEY,COUNT(CELL_KEY) from cell_selection_fct where CELL_KEY in (21030,21041) group by CELL_KEY;
+--------+---------------+
|CELL_KEY|COUNT(CELL_KEY)|
+--------+---------------+
|21030   |40             |
|21041   |40             |
+--------+---------------+
Select distinct CRITERIA_KEY,CRITERIA_XID from BUNDLE_DIM join BOSH.CRITERIA_DIM using (CRITERIA_KEY) where BUNDLE_KEY in (
    select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
    where CELL_KEY in (21030,21041) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
    ) order by CRITERIA_KEY;
+------------+------------+
|CRITERIA_KEY|CRITERIA_XID|
+------------+------------+
|20586       |RW3-THR-3   |
|20587       |RW3-THR-4   |
|20588       |RW3-THR-5   |
|20789       |RW3-THR-6   |
|20790       |RW3-THR-7   |
|20791       |RW3-THR-8   |
+------------+------------+

select CELL_KEY,BUNDLE_KEY,CONTROL_IND  from cell_selection_fct join p_cell_dim using (cell_key)
where CELL_KEY in (21030,21041) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND;--40


--=================cell_selection_fct===========================------

select distinct BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
where CELL_KEY in (21030,21041) and CONTROL_IND = 'T'  ;--40


select distinct BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
where CELL_KEY in (21030,21041) and CONTROL_IND = 'B'  ;--40

--=================base_offer_discount_xref===========================------

select COUNT(*),COUNT( distinct BUNDLE_KEY),max(DISCOUNT_KEY),min(DISCOUNT_KEY) from base_offer_discount_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--17
--DISCOUNT_KEY = 2
+--------+-------------------------+-----------------+-----------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|MAX(DISCOUNT_KEY)|MIN(DISCOUNT_KEY)|
+--------+-------------------------+-----------------+-----------------+
|17      |11                       |2                |2                |
+--------+-------------------------+-----------------+-----------------+



select COUNT(*),COUNT( distinct BUNDLE_KEY),max(DISCOUNT_KEY),min(DISCOUNT_KEY) from base_offer_discount_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--13
--DISCOUNT_KEY = 2
+--------+-------------------------+-----------------+-----------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|MAX(DISCOUNT_KEY)|MIN(DISCOUNT_KEY)|
+--------+-------------------------+-----------------+-----------------+
|13      |9                        |2                |2                |
+--------+-------------------------+-----------------+-----------------+



Select * from BOSH.DISCOUNT_DIM;
+------------+-----------+----------------+------------+------------+
|DISCOUNT_KEY|DISCOUNT_NM|DISCOUNT_TYPE_CD|DISCOUNT_AMT|DISCOUNT_PCT|
+------------+-----------+----------------+------------+------------+
|1           |Early Bird |Item            |NULL        |0.2000      |
|2           |Bundle     |Bundle          |NULL        |0.1000      |
|3           |Bundle20   |Bundle20        |NULL        |0.2000      |
+------------+-----------+----------------+------------+------------+


--==============base_offer_xref===========================------

select COUNT(*),COUNT( distinct BUNDLE_KEY) from base_offer_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--57
+--------+-------------------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
+--------+-------------------------+
|57      |40                       |
+--------+-------------------------+


select COUNT(*),COUNT( distinct BUNDLE_KEY) from base_offer_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--59
+--------+-------------------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
+--------+-------------------------+
|59      |40                       |
+--------+-------------------------+

select * from base_offer_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        )) order by BUNDLE_KEY, TERM_KEY;
;--59

--==============base_offer_item_xref===========================------

select COUNT(*),COUNT( distinct BUNDLE_KEY) from base_offer_item_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--85
+--------+-------------------------+
|COUNT(*)|COUNT(DISTINCT BUNDLE_KEY)|
+--------+-------------------------+
|85      |40                       |
+--------+-------------------------+


select COUNT(*),COUNT( distinct BUNDLE_KEY) from base_offer_item_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--83
+--------+-------------------------+
|COUNT(*)|COUNT(DISTINCT BUNDLE_KEY)|
+--------+-------------------------+
|83      |40                       |
+--------+-------------------------+

    select * from base_offer_item_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        )) order BY  BUNDLE_KEY,SI_KEY,TERM_KEY;


--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
CELL_GROUP_KEY,CELL_GROUP_NM,CELL_KEY,"REPLACE(REPLACE(CELL_NM,'CONTROL'),'TEST')",CONTROL_IND,COUNT(*),GRP_CNT
17333,Early Bird 2 Effort,21026,Early Bird 2 Effort - Thermador - Bundle Discount ,B,3085,6185
17333,Early Bird 2 Effort,21037,Early Bird 2 Effort - Thermador - Bundle Discount ,T,3100,6185


select * from p_cell_dim where CELL_KEY in (21026,21037);
+--------+-----------+---------------------------------------------------------+-------+-----------+
|CELL_KEY|CELL_XID   |CELL_NM                                                  |CELL_CD|CONTROL_IND|
+--------+-----------+---------------------------------------------------------+-------+-----------+
|21026   |EB02-THR-C2|Early Bird 2 Effort - Thermador - Bundle Discount Control|14     |B          |
|21037   |EB02-THR-T2|Early Bird 2 Effort - Thermador - Bundle Discount Test   |15     |T          |
+--------+-----------+---------------------------------------------------------+-------+-----------+



select * from cell_selection_fct where CELL_KEY in (21026,21037);--80
select CELL_KEY,COUNT(CELL_KEY) from cell_selection_fct where CELL_KEY in (21026,21037) group by CELL_KEY;
+--------+---------------+
|CELL_KEY|COUNT(CELL_KEY)|
+--------+---------------+
|21037   |3100           |
|21026   |3085           |
+--------+---------------+

Select distinct CRITERIA_KEY,CRITERIA_XID from BUNDLE_DIM join BOSH.CRITERIA_DIM using (CRITERIA_KEY) where BUNDLE_KEY in (
    select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
    where CELL_KEY in (21026,21037) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
    ) order by CRITERIA_KEY;
+------------+------------+
|CRITERIA_KEY|CRITERIA_XID|
+------------+------------+
|5361        |E2-THR      |
+------------+------------+



--=================cell_selection_fct===========================------

select COUNT(distinct BUNDLE_KEY)  from cell_selection_fct join p_cell_dim using (cell_key)
where CELL_KEY in (21026,21037) and CONTROL_IND = 'T'  ;--3100


select COUNT(distinct BUNDLE_KEY)  from cell_selection_fct join p_cell_dim using (cell_key)
where CELL_KEY in (21026,21037) and CONTROL_IND = 'B'  ;--3085

--=================base_offer_discount_xref===========================------

select COUNT(*),COUNT( distinct BUNDLE_KEY),max(DISCOUNT_KEY),min(DISCOUNT_KEY) from base_offer_discount_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21026,21037) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--17
--DISCOUNT_KEY = 2
+--------+-------------------------+-----------------+-----------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|MAX(DISCOUNT_KEY)|MIN(DISCOUNT_KEY)|
+--------+-------------------------+-----------------+-----------------+
|2894    |726                      |2                |2                |
+--------+-------------------------+-----------------+-----------------+

select COUNT(*),COUNT( distinct BUNDLE_KEY),max(DISCOUNT_KEY),min(DISCOUNT_KEY) from base_offer_discount_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21026,21037) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--13
--DISCOUNT_KEY = 2
+--------+-------------------------+-----------------+-----------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|MAX(DISCOUNT_KEY)|MIN(DISCOUNT_KEY)|
+--------+-------------------------+-----------------+-----------------+
|2967    |743                      |2                |2                |
+--------+-------------------------+-----------------+-----------------+

+-----------+--------+-----------+--------+-----------------------------+-----------------+-----------------+
|CELL_XID   |CELL_KEY|CONTROL_IND|COUNT(*)|COUNT(DISTINCTCFT.BUNDLE_KEY)|MAX(DISCOUNT_KEY)|MIN(DISCOUNT_KEY)|
+-----------+--------+-----------+--------+-----------------------------+-----------------+-----------------+
|EB02-THR-C2|21026   |B          |2967    |743                          |2                |2                |
+-----------+--------+-----------+--------+-----------------------------+-----------------+-----------------+
+-----------+--------+-----------+--------+-----------------------------+-----------------+-----------------+
|CELL_XID   |CELL_KEY|CONTROL_IND|COUNT(*)|COUNT(DISTINCTCFT.BUNDLE_KEY)|MAX(DISCOUNT_KEY)|MIN(DISCOUNT_KEY)|
+-----------+--------+-----------+--------+-----------------------------+-----------------+-----------------+
|EB02-THR-T2|21037   |T          |2894    |726                          |2                |2                |
+-----------+--------+-----------+--------+-----------------------------+-----------------+-----------------+
select  cd.CELL_GROUP_KEY,cd.CELL_XID,cd.CELL_KEY,cd.CONTROL_IND ,COUNT(*) CNT_BUNDLE,COUNT( distinct cft.BUNDLE_KEY) CNT_BUNDLE_DISCOUNT_KEY,max(DISCOUNT_KEY),min(DISCOUNT_KEY)
        from base_offer_discount_xref bodx
            join   BUNDLE_DIM bd    on bodx.BUNDLE_KEY = bd.BUNDLE_KEY
            join   cell_selection_fct cft on cft.BUNDLE_KEY = bd.BUNDLE_KEY
            join   p_cell_dim cd on cd.CELL_KEY = cft.CELL_KEY
            Where  cd.CELL_KEY in (21026,21037) and cd.CONTROL_IND = 'T'
        Group by cd.CONTROL_IND,cd.CELL_KEY,cd.CELL_XID,cd.CELL_GROUP_KEY

select T1.CELL_GROUP_KEY,T1.CELL_XID,T2.CELL_XID,T1.CONTROL_IND,T2.CONTROL_IND,T1.CNT_BUNDLE,T2.CNT_BUNDLE ,T1.CNT_BUNDLE_DISCOUNT_KEY,T2.CNT_BUNDLE_DISCOUNT_KEY
    ,round(((T1.CNT_BUNDLE/(T2.CNT_BUNDLE+T1.CNT_BUNDLE))*100), 2) AS CELL_PERCT_B  ,round(((T1.CNT_BUNDLE_DISCOUNT_KEY/(T2.CNT_BUNDLE_DISCOUNT_KEY+T1.CNT_BUNDLE_DISCOUNT_KEY))*100), 2) AS DISC_PERCT_B
    ,round(((T2.CNT_BUNDLE/(T2.CNT_BUNDLE+T1.CNT_BUNDLE))*100), 2) AS CELL_PERCT_T  ,round(((T2.CNT_BUNDLE_DISCOUNT_KEY/(T2.CNT_BUNDLE_DISCOUNT_KEY+T1.CNT_BUNDLE_DISCOUNT_KEY))*100), 2) AS DISC_PERCT_T
from (
    select  cd.CELL_GROUP_KEY,cd.CELL_XID,cd.CELL_KEY,cd.CONTROL_IND ,COUNT(*) CNT_BUNDLE,COUNT( distinct cft.BUNDLE_KEY) CNT_BUNDLE_DISCOUNT_KEY,max(DISCOUNT_KEY),min(DISCOUNT_KEY)
        from base_offer_discount_xref bodx
            join   BUNDLE_DIM bd    on bodx.BUNDLE_KEY = bd.BUNDLE_KEY
            join   cell_selection_fct cft on cft.BUNDLE_KEY = bd.BUNDLE_KEY
            join   p_cell_dim cd on cd.CELL_KEY = cft.CELL_KEY
            Where  --cd.CELL_KEY in (21026,21037) and
                   cd.CONTROL_IND = 'B'
        Group by cd.CONTROL_IND,cd.CELL_KEY,cd.CELL_XID,cd.CELL_GROUP_KEY
    ) T1 JOIN (
    select  cd.CELL_GROUP_KEY,cd.CELL_XID,cd.CELL_KEY,cd.CONTROL_IND ,COUNT(*) CNT_BUNDLE,COUNT( distinct cft.BUNDLE_KEY) CNT_BUNDLE_DISCOUNT_KEY,max(DISCOUNT_KEY),min(DISCOUNT_KEY)
        from base_offer_discount_xref bodx
            join   BUNDLE_DIM bd    on bodx.BUNDLE_KEY = bd.BUNDLE_KEY
            join   cell_selection_fct cft on cft.BUNDLE_KEY = bd.BUNDLE_KEY
            join   p_cell_dim cd on cd.CELL_KEY = cft.CELL_KEY
            Where  --cd.CELL_KEY in (21026,21037) and
                   cd.CONTROL_IND = 'T'
        Group by cd.CONTROL_IND,cd.CELL_KEY,cd.CELL_XID,cd.CELL_GROUP_KEY
    ) T2 ON T1.CELL_GROUP_KEY = T2.CELL_GROUP_KEY;


select  cd.CELL_XID,cd.CELL_KEY,cd.CONTROL_IND ,COUNT(*),COUNT( distinct cft.BUNDLE_KEY),max(DISCOUNT_KEY),min(DISCOUNT_KEY)
from base_offer_discount_xref bodx
    join   BUNDLE_DIM bd    on bodx.BUNDLE_KEY = bd.BUNDLE_KEY
    join   cell_selection_fct cft on cft.BUNDLE_KEY = bd.BUNDLE_KEY
    join   p_cell_dim cd on cd.CELL_KEY = cft.CELL_KEY
    Where  cd.CELL_KEY in (21026,21037) and cd.CONTROL_IND = 'B'
Group by cd.CONTROL_IND,cd.CELL_KEY,cd.CELL_XID
;
+--------+-----------------------------+-----------------+-----------------+
|COUNT(*)|COUNT(DISTINCTCFT.BUNDLE_KEY)|MAX(DISCOUNT_KEY)|MIN(DISCOUNT_KEY)|
+--------+-----------------------------+-----------------+-----------------+
|2967    |743                          |2                |2                |
+--------+-----------------------------+-----------------+-----------------+

--group by cd.CELL_KEY,cft.BUNDLE_KEY,CONTROL_IND

Select * from BOSH.DISCOUNT_DIM;
+------------+-----------+----------------+------------+------------+
|DISCOUNT_KEY|DISCOUNT_NM|DISCOUNT_TYPE_CD|DISCOUNT_AMT|DISCOUNT_PCT|
+------------+-----------+----------------+------------+------------+
|1           |Early Bird |Item            |NULL        |0.2000      |
|2           |Bundle     |Bundle          |NULL        |0.1000      |
|3           |Bundle20   |Bundle20        |NULL        |0.2000      |
+------------+-----------+----------------+------------+------------+


--==============base_offer_xref===========================------

select COUNT(*),COUNT( distinct BUNDLE_KEY) from base_offer_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21026,21037) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--57
+--------+-------------------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
+--------+-------------------------+
|12275   |3100                     |
+--------+-------------------------+



select COUNT(*),COUNT( distinct BUNDLE_KEY) from base_offer_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21026,21037) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--59
+--------+-------------------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
+--------+-------------------------+
|12225   |3085                     |
+--------+-------------------------+


select * from base_offer_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21026,21037) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        )) order by BUNDLE_KEY, TERM_KEY;
;--59

--==============base_offer_item_xref===========================------

select COUNT(*),COUNT( distinct BUNDLE_KEY) from base_offer_item_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21026,21037) and CONTROL_IND = 'T' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--85
+--------+-------------------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
+--------+-------------------------+
|17663   |3100                     |
+--------+-------------------------+



select COUNT(*),COUNT( distinct BUNDLE_KEY) from base_offer_item_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21026,21037) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--83
+--------+-------------------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
+--------+-------------------------+
|17824   |3085                     |
+--------+-------------------------+


    select * from base_offer_item_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where CELL_KEY in (21030,21041) and CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        )) order BY  BUNDLE_KEY,SI_KEY,TERM_KEY;

 select t.*, round((t.cell_total/t.criteria_total), 2) as "%"  from
(select campaign_xid, cell_group_key, cell_group_nm, criteria_key, CRITERIA_XID, CELL_KEY, CELL_XID, cell_nm, --replace(replace(CELL_NM, 'Control'), 'Test') as cell_nm,
        CONTROL_IND, count(*) as cell_total, sum(count(*)) over(partition by criteria_key) as criteria_total
  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
       join BUNDLE_DIM bd using (bundle_key)
       join P_CRITERIA_DIM cri using (criteria_key)
       join p_campaign_dim using (campaign_key)
where 1=1
  and CELL_NM  like '%Thermador%'
--    and CAMPAIGN_XID like '%%'
--    and (criteria_cd like '%%')
   and BUNDLE_KEY in (select bix.BUNDLE_KEY from BUNDLE_ITEM_XREF bix
                       group by bix.BUNDLE_KEY having count(distinct bix.SI_KEY) >= 2)
 group by campaign_xid, cell_group_key, cell_group_nm, criteria_key, CRITERIA_XID, CELL_KEY, CELL_XID, cell_nm, CONTROL_IND
) t
 order by campaign_xid, CRITERIA_XID, criteria_key, cell_nm, CELL_KEY, CONTROL_IND;

select campaign_xid, cell_group_key, cell_group_nm, criteria_key, CRITERIA_XID, CELL_KEY, CELL_XID, cell_nm, --replace(replace(CELL_NM, 'Control'), 'Test') as cell_nm,
        CONTROL_IND, count(*) as cell_total, sum(count(*)) over(partition by criteria_key) as criteria_total
  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
       join BUNDLE_DIM bd using (bundle_key)
       join P_CRITERIA_DIM cri using (criteria_key)
       join p_campaign_dim using (campaign_key)
where 1=1
  and CELL_NM  like '%Thermador%'
--    and CAMPAIGN_XID like '%%'
--    and (criteria_cd like '%%')
   and CONTROL_IND = 'T'
   and BUNDLE_KEY in (select bix.BUNDLE_KEY from BUNDLE_ITEM_XREF bix
                       group by bix.BUNDLE_KEY having count(distinct bix.SI_KEY) >= 2)
 group by campaign_xid, cell_group_key, cell_group_nm, criteria_key, CRITERIA_XID, CELL_KEY, CELL_XID, cell_nm, CONTROL_IND

---Final SQL


select  Count(BUNDLE_KEY),COUNT(Distinct BUNDLE_KEY)
  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
       join BUNDLE_DIM bd using (bundle_key)
       join P_CRITERIA_DIM cri using (criteria_key)
       join p_campaign_dim using (campaign_key)
where 1=1
  and CELL_NM  like '%Thermador%'
--    and CAMPAIGN_XID like '%%'
--    and (criteria_cd like '%%')
   and CONTROL_IND = 'T'
   and BUNDLE_KEY in (select bix.BUNDLE_KEY from BUNDLE_ITEM_XREF bix
                       group by bix.BUNDLE_KEY having count(distinct bix.SI_KEY) >= 2);
+-----------------+-------------------------+
|COUNT(BUNDLE_KEY)|COUNT(DISTINCTBUNDLE_KEY)|
+-----------------+-------------------------+
|1824             |1824                     |
+-----------------+-------------------------+

select Count(BUNDLE_KEY),COUNT(Distinct BUNDLE_KEY) from BASE_OFFER_DISCOUNT_XREF where BUNDLE_KEY in (
        select  BUNDLE_KEY
              from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                   join BUNDLE_DIM bd using (bundle_key)
                   join P_CRITERIA_DIM cri using (criteria_key)
                   join p_campaign_dim using (campaign_key)
            where 1=1
              and CELL_NM  like '%Thermador%'
               and CONTROL_IND = 'T'
               and BUNDLE_KEY in (select bix.BUNDLE_KEY from BUNDLE_ITEM_XREF bix
                                   group by bix.BUNDLE_KEY having count(distinct bix.SI_KEY) >= 2)
    )    ;
+-----------------+-------------------------+
|COUNT(BUNDLE_KEY)|COUNT(DISTINCTBUNDLE_KEY)|
+-----------------+-------------------------+
|5772             |1824                     |
+-----------------+-------------------------+


select COUNT(*),COUNT( distinct BUNDLE_KEY),max(DISCOUNT_KEY),min(DISCOUNT_KEY) from base_offer_discount_xref where BUNDLE_KEY in (
    Select BUNDLE_KEY from BUNDLE_DIM where BUNDLE_KEY in (
        select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key)
        where --CELL_KEY in (21030,21041) and
              CONTROL_IND = 'B' group by CELL_KEY,BUNDLE_KEY,CONTROL_IND
        ))
;--17
+--------+-------------------------+-----------------+-----------------+
|COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|MAX(DISCOUNT_KEY)|MIN(DISCOUNT_KEY)|
+--------+-------------------------+-----------------+-----------------+
|5772    |1824                     |2                |2                |
+--------+-------------------------+-----------------+-----------------+
-----------update command------------------

Update BASE_OFFER_DISCOUNT_XREF
    SET DISCOUNT_KEY = 3
where BUNDLE_KEY in (
        select  BUNDLE_KEY
              from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                   join BUNDLE_DIM bd using (bundle_key)
                   join P_CRITERIA_DIM cri using (criteria_key)
                   join p_campaign_dim using (campaign_key)
            where 1=1
              and CELL_NM  like '%Thermador%'
               and CONTROL_IND = 'T'
               and BUNDLE_KEY in (select bix.BUNDLE_KEY from BUNDLE_ITEM_XREF bix
                                   group by bix.BUNDLE_KEY having count(distinct bix.SI_KEY) >= 2)
    )    ;
-----------update command------------------

Select DISCOUNT_KEY,COUNT(*), round(((COUNT(*)/11900)*100),2) as pct  from BASE_OFFER_DISCOUNT_XREF
         where BUNDLE_KEY in (
                    select  BUNDLE_KEY  from cell_selection_fct join p_cell_dim using (cell_key) join p_cell_group_dim using (cell_group_key)
                               join BUNDLE_DIM bd using (bundle_key)
                               join P_CRITERIA_DIM cri using (criteria_key)
                               join p_campaign_dim using (campaign_key)
                        where 1=1  and CELL_NM  like '%Thermador%'
                           and BUNDLE_KEY in (select bix.BUNDLE_KEY from BUNDLE_ITEM_XREF bix
                                               group by bix.BUNDLE_KEY having count(distinct bix.SI_KEY) >= 2))
    group by DISCOUNT_KEY;

+------------+--------+----+
|DISCOUNT_KEY|COUNT(*)|PCT |
+------------+--------+----+
|2           |6128    |51.5|
|3           |5772    |48.5|
+------------+--------+----+



Select * from BOSH.SYNC_PROCESS_MAPPING_TBL where MODULE_NAME = 'OFFER';

select * from BOSH.V_SYNC_OFFER_ITEM_XREF;