create view V_SYNC_OFFER_ITEM_XREF as
SELECT OFFER_ID,
          OFFER_LINE_ID,
          OFFER_TYPE_CD,
          POLICY_ID,
          PRODUCT_ID,
          SERIALIZED_ITEM_ID,
          COVERAGE_START_DT,
          COVERAGE_EXP_DT,
          PRICE_AMT,
          TAX_AMT,
          PROMO_ID,
          SHIPPING_ID,
          DISCOUNT1_AMT,
          '' DISCOUNT1_PCT,
          '' DISCOUNT2_AMT,
          '' DISCOUNT2_PCT,
          ACTIVE_IND,
          BUNDLE_ID,
          DISPLAY_SEQ_NUM,
          DISPLAY_GROUP_NUM,
          LAST_UPDATED_TS,
          SOURCE_SYSTEM_CD,
          FLEXPAYABLE_IND
     FROM (SELECT t2.OFFER_KEY OFFER_ID,
                  t2.OFFER_LINE_KEY OFFER_LINE_ID,
                  OFFER_TYPE_CD,
                  T2.POLICY_KEY POLICY_ID,
                  PRODUCT_XID PRODUCT_ID,
                  T4.SI_XID SERIALIZED_ITEM_ID,
                  t2.COVERAGE_START_DT,
                  t2.COVERAGE_END_DT AS COVERAGE_EXP_DT,
                  t2.PRICE_AFTER_ITEM_DISCOUNT_AMT PRICE_AMT,
                  t2.TAX_AMT TAX_AMT,
                  NULL AS PROMO_ID,
                  NULL AS SHIPPING_ID,
                  t2.ITEM_DISCOUNT_AMT DISCOUNT1_AMT,
                  'Y' AS ACTIVE_IND,
                  NULL BUNDLE_ID,
                  T2.SEQ_NO AS DISPLAY_GROUP_NUM,
                  ROW_NUMBER ()
                  OVER (PARTITION BY t2.OFFER_KEY, T2.SEQ_NO
                        ORDER BY t2.OFFER_LINE_KEY)
                     DISPLAY_SEQ_NUM,
                  t5.CREATION_DT AS last_updated_ts,
                  NVL (T4.SOURCE_SYSTEM_CD, PROD_DIM.SOURCE_SYSTEM_CD)
                     SOURCE_SYSTEM_CD,
                  CASE
                     WHEN t2.policy_key IS NOT NULL AND t2.policy_key != 0
                     THEN
                        'Y'
                     WHEN t2.product_key IS NOT NULL ---Added By Ashish for ticket FAP-783
                     THEN
                        'N'
                     ELSE
                        'N'
                  END
                     AS FLEXPAYABLE_IND,
                  ROW_NUMBER ()
                  OVER (PARTITION BY t2.OFFER_KEY, t2.OFFER_LINE_KEY
                        ORDER BY t5.CREATION_DT DESC)
                     rn
             FROM V_OFFER_ITEM_DISCOUNT t2
                  LEFT JOIN POLICY_TBL PT ON PT.POLICY_KEY = t2.policy_key
                  LEFT JOIN
                  (SELECT DISTINCT
                          MIN (PRODUCT_XID)
                          OVER (PARTITION BY PRODUCT_KEY, SOURCE_SYSTEM_CD)
                             AS PRODUCT_XID,
                          PRODUCT_KEY,
                          source_system_cd
                     FROM product_lkp
                    WHERE source_system_cd = 2) PROD_DIM
                     ON T2.PRODUCT_KEY = PROD_DIM.PRODUCT_KEY
                  LEFT JOIN SERIALIZED_ITEM_DIM t3 ON (T2.SI_KEY = t3.si_key)
                  LEFT JOIN
                  (SELECT DISTINCT
                          MIN (SI_XID)
                             OVER (PARTITION BY SI_KEY, SOURCE_SYSTEM_CD)
                             AS SI_XID,
                          SI_KEY,
                          SOURCE_SYSTEM_CD
                     FROM serialized_item_lkp
                    WHERE ext_id_type_cd = 1) t4
                     ON (T3.SI_KEY = T4.SI_KEY)
                  JOIN
                  audit_tbl t5
                     ON (NVL (REPLACE(t2.SYNC_AUDIT_KEY, -1), GREATEST (t2.insert_audit_key, NVL (t2.update_audit_key, -1))) = t5.audit_key))
    WHERE rn = 1
/

