
 select distinct si_key
     -- into l_count
        from (
              select si.si_key, count(distinct ccx.contract_key)
                from p_serialized_item_dim si
                     join (
                         select distinct CD.CONTRACT_KEY,OIT.ORDER_KEY,COTX.SI_KEY AS si_key ,2 coverage_type_key,SALES_SOURCE_CD  ,ot.PURCHASE_DT OT_Purchase_DT
                         from BOSH.CONTRACT_DIM  CD
                          JOIN BOSH.CONTRACT_COVERAGE_XREF  COTX on COTX.CONTRACT_KEY = CD.CONTRACT_KEY
                          JOIN BOSH.CONTRACT_ORDER_TBL  COT on COT.CONTRACT_KEY = CD.CONTRACT_KEY
                         JOIN BOSH.ORDER_ITEM_TBL OIT on OIT.ORDER_KEY = COT.ORDER_KEY and OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY
                         join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY
                    ) ccx on ccx.si_key = si.si_key
                     join p_contract_lkp clkp on clkp.contract_key = ccx.contract_key
                     join p_contract_dim con on con.contract_key = clkp.contract_key
                     left join p_policy_ext_tbl pex ON (pex.policy_key = con.policy_key)

              where ccx.coverage_type_key = 2
                and con.retail_amt > 1
                --AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                and con.contract_status_key NOT IN (2, 3, 4, 5)
                AND exists (
                        select ccx3.si_key
                        from
                                (
                                    select distinct CD.CONTRACT_KEY,OIT.ORDER_KEY,COTX.SI_KEY AS si_key ,2 coverage_type_key,SALES_SOURCE_CD ,ot.PURCHASE_DT OT_Purchase_DT
                                    from BOSH.CONTRACT_DIM  CD
                                      JOIN BOSH.CONTRACT_COVERAGE_XREF  COTX on COTX.CONTRACT_KEY = CD.CONTRACT_KEY
                                      JOIN BOSH.CONTRACT_ORDER_TBL  COT on COT.CONTRACT_KEY = CD.CONTRACT_KEY
                                     JOIN BOSH.ORDER_ITEM_TBL OIT on OIT.ORDER_KEY = COT.ORDER_KEY and OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY
                                      join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY

                                ) ccx3
                                join p_contract_lkp clkp3 on clkp3.contract_key = ccx3.contract_key
                                join p_contract_dim con3 on con3.contract_key = clkp3.contract_key
                                left join p_contract_status_dim cons3 on (cons3.contract_status_key = con3.contract_status_key)
                                join p_policy_ext_tbl pex3 ON (pex3.policy_key = con3.policy_key)
                        where
                              ccx3.coverage_type_key = 2
                        and ccx3.si_key  = ccx.si_key
                        and con3.contract_key <> con.contract_key
                        and
                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                             or
                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                            )
                        and con3.retail_amt > 1
                        AND con3.contract_status_key NOT IN (2, 3, 4, 5)   --canceled/fulfilled/expired
                        and pex3.channels = pex.channels
                        and con3.contract_end_dt >= trunc(sysdate) - 30
                        and NOT  (ccx.SALES_SOURCE_CD = 'OUTLET_SALES'  and ccx3.SALES_SOURCE_CD = 'OUTLET_SALES')
                        and NOT  (ccx.OT_Purchase_DT < SYSDATE - 730  and ccx3.OT_Purchase_DT < SYSDATE - 730)
                       )

              group by si.si_key
             having count(distinct ccx.contract_key) >= 2
            );--46

 select --COUNT(distinct con.CONTRACT_KEY )--distinct CCOT.CONTRACT_KEY,OIT.ORDER_KEY,oit.SERIALIZED_ITEM_KEY
        distinct CCOT.CONTRACT_KEY,OIT.ORDER_KEY,oit.SERIALIZED_ITEM_KEY,ccot.SI_KEY,COTX.CONTRACT_KEY,COTX.SI_KEY,SIL.SI_XID,SIL2.SI_XID
       -- COUNT( distinct con.CONTRACT_KEY )
                    FROM bosh.CONTRACT_COMMON_LOAD_TBL_ARCH CCLT
                        JOIN BOSH.CONTRACT_OUTPUT_TBL_ARCH CCOT
                            ON(CCLT.UNIQUE_SEQ_NO=CCOT.UNIQUE_SEQ_NO)
                        LEFT JOIN P_ORDER_ITEM_TBL oit
                            ON(CCOT.ORDER_KEY=OIT.ORDER_KEY and CCLT.ORDER_LINE_ID=OIT.ORDER_LINE_KEY)
                        join BOSH.CONTRACT_DIM con on con.CONTRACT_KEY = CCOT.CONTRACT_KEY
                        join BOSH.SERIALIZED_ITEM_LKP SIL on SIL.SI_KEY = ccot.SI_KEY and SIL.SOURCE_SYSTEM_CD = 0
                        join BOSH.SERIALIZED_ITEM_LKP SIL2 on SIL2.SI_KEY = OIT.SERIALIZED_ITEM_KEY and SIL.SOURCE_SYSTEM_CD = 0
                        JOIN BOSH.CONTRACT_COVERAGE_XREF  COTX on COTX.CONTRACT_KEY = con.CONTRACT_KEY
                    Where ccot.SI_KEY <> OIT.SERIALIZED_ITEM_KEY and sil.SI_XID = SIL2.SI_XID
                        and con.retail_amt > 1
                        and con.contract_status_key NOT IN (2, 3,5)
                        and cotx.SI_KEY in (
1260317,2109828,3177095,3187484,3280284,3294443,3369966,3418962,3481716,3504146,3538649,3556246,3556247,3556255,
3584504,3597019,3660023,3660107,3679634,3703138,3728551,3732729,3740645,3821097,3821132,3823516,3824853,3867095,
3885012,3919749,3924900,3940149,3940180,3940188,3977184,3996432,4047085,4096915,4106871,4121941,4165313,4165358,
4174718,4220895,4296517,4308341)
;--51


Select Distinct CCX.CONTRACT_KEY,CCX.SI_KEY ,OIT.ORDER_KEY,OIT.ORDER_LINE_KEY,OIT.SERIALIZED_ITEM_KEY
    from BOSH.CONTRACT_COVERAGE_XREF CCX
         JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.CONTRACT_KEY = CCX.CONTRACT_KEY
         JOIN BOSH.ORDER_ITEM_TBL OIT on OIT.ORDER_KEY = COT.ORDER_KEY AND OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY
    where CCX.CONTRACT_KEY in (
    select  COTX.CONTRACT_KEY
           -- COUNT( distinct con.CONTRACT_KEY )
                        FROM bosh.CONTRACT_COMMON_LOAD_TBL_ARCH CCLT
                            JOIN BOSH.CONTRACT_OUTPUT_TBL_ARCH CCOT
                                ON(CCLT.UNIQUE_SEQ_NO=CCOT.UNIQUE_SEQ_NO)
                            LEFT JOIN P_ORDER_ITEM_TBL oit
                                ON(CCOT.ORDER_KEY=OIT.ORDER_KEY and CCLT.ORDER_LINE_ID=OIT.ORDER_LINE_KEY)
                            join BOSH.CONTRACT_DIM con on con.CONTRACT_KEY = CCOT.CONTRACT_KEY
                            join BOSH.SERIALIZED_ITEM_LKP SIL on SIL.SI_KEY = ccot.SI_KEY and SIL.SOURCE_SYSTEM_CD = 0
                            join BOSH.SERIALIZED_ITEM_LKP SIL2 on SIL2.SI_KEY = OIT.SERIALIZED_ITEM_KEY and SIL.SOURCE_SYSTEM_CD = 0
                            JOIN BOSH.CONTRACT_COVERAGE_XREF  COTX on COTX.CONTRACT_KEY = con.CONTRACT_KEY
                        Where ccot.SI_KEY <> OIT.SERIALIZED_ITEM_KEY and sil.SI_XID = SIL2.SI_XID
                            and con.retail_amt > 1
                            and con.contract_status_key NOT IN (2, 3,5)
                            and cotx.SI_KEY in (
    1260317,2109828,3177095,3187484,3280284,3294443,3369966,3418962,3481716,3504146,3538649,3556246,3556247,3556255,
    3584504,3597019,3660023,3660107,3679634,3703138,3728551,3732729,3740645,3821097,3821132,3823516,3824853,3867095,
    3885012,3919749,3924900,3940149,3940180,3940188,3977184,3996432,4047085,4096915,4106871,4121941,4165313,4165358,
    4174718,4220895,4296517,4308341))
    and CCX.SI_KEY = OIT.SERIALIZED_ITEM_KEY
;--0

select COUNT(*),COUNT(distinct CONTRACT_KEY) from BOSH.CONTRACT_ORDER_TBL ;
-- COUNT(*),COUNT(DISTINCTCONTRACT_KEY)
-- 146091,146091


		MERGE INTO CONTRACT_COVERAGE_XREF T1 USING
		(
			 Select Distinct CCX.CONTRACT_KEY,CCX.SI_KEY ,OIT.ORDER_KEY,OIT.ORDER_LINE_KEY,OIT.SERIALIZED_ITEM_KEY
    from BOSH.CONTRACT_COVERAGE_XREF CCX
         JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.CONTRACT_KEY = CCX.CONTRACT_KEY
         JOIN BOSH.ORDER_ITEM_TBL OIT on OIT.ORDER_KEY = COT.ORDER_KEY AND OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY
    where CCX.CONTRACT_KEY in (
    select  COTX.CONTRACT_KEY
           -- COUNT( distinct con.CONTRACT_KEY )
                        FROM bosh.CONTRACT_COMMON_LOAD_TBL_ARCH CCLT
                            JOIN BOSH.CONTRACT_OUTPUT_TBL_ARCH CCOT
                                ON(CCLT.UNIQUE_SEQ_NO=CCOT.UNIQUE_SEQ_NO)
                            LEFT JOIN P_ORDER_ITEM_TBL oit
                                ON(CCOT.ORDER_KEY=OIT.ORDER_KEY and CCLT.ORDER_LINE_ID=OIT.ORDER_LINE_KEY)
                            join BOSH.CONTRACT_DIM con on con.CONTRACT_KEY = CCOT.CONTRACT_KEY
                            join BOSH.SERIALIZED_ITEM_LKP SIL on SIL.SI_KEY = ccot.SI_KEY and SIL.SOURCE_SYSTEM_CD = 0
                            join BOSH.SERIALIZED_ITEM_LKP SIL2 on SIL2.SI_KEY = OIT.SERIALIZED_ITEM_KEY and SIL.SOURCE_SYSTEM_CD = 0
                            JOIN BOSH.CONTRACT_COVERAGE_XREF  COTX on COTX.CONTRACT_KEY = con.CONTRACT_KEY
                        Where ccot.SI_KEY <> OIT.SERIALIZED_ITEM_KEY and sil.SI_XID = SIL2.SI_XID
                            and con.retail_amt > 1
                            and con.contract_status_key NOT IN (2, 3,5)
                            and cotx.SI_KEY in (
    1260317,2109828,3177095,3187484,3280284,3294443,3369966,3418962,3481716,3504146,3538649,3556246,3556247,3556255,
    3584504,3597019,3660023,3660107,3679634,3703138,3728551,3732729,3740645,3821097,3821132,3823516,3824853,3867095,
    3885012,3919749,3924900,3940149,3940180,3940188,3977184,3996432,4047085,4096915,4106871,4121941,4165313,4165358,
    4174718,4220895,4296517,4308341))
		) T2
		ON(  T1.CONTRACT_KEY=T2.CONTRACT_KEY  )
		WHEN MATCHED THEN UPDATE
			SET T1.SI_KEY=T2.SERIALIZED_ITEM_KEY;


--Merge for correction CONTRACT_COVERAGE_XREF SI_KEYS
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'BOSH-1641', p_table_nm => 'CONTRACT_COVERAGE_XREF');

BEGIN

       MERGE INTO CONTRACT_COVERAGE_XREF T1 USING
		(
			 Select Distinct CCX.CONTRACT_KEY,CCX.SI_KEY ,OIT.ORDER_KEY,OIT.ORDER_LINE_KEY,OIT.SERIALIZED_ITEM_KEY
    from BOSH.CONTRACT_COVERAGE_XREF CCX
         JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.CONTRACT_KEY = CCX.CONTRACT_KEY
         JOIN BOSH.ORDER_ITEM_TBL OIT on OIT.ORDER_KEY = COT.ORDER_KEY AND OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY
    where CCX.CONTRACT_KEY in (
    select  COTX.CONTRACT_KEY
                        FROM bosh.CONTRACT_COMMON_LOAD_TBL_ARCH CCLT
                            JOIN BOSH.CONTRACT_OUTPUT_TBL_ARCH CCOT
                                ON(CCLT.UNIQUE_SEQ_NO=CCOT.UNIQUE_SEQ_NO)
                            LEFT JOIN P_ORDER_ITEM_TBL oit
                                ON(CCOT.ORDER_KEY=OIT.ORDER_KEY and CCLT.ORDER_LINE_ID=OIT.ORDER_LINE_KEY)
                            join BOSH.CONTRACT_DIM con on con.CONTRACT_KEY = CCOT.CONTRACT_KEY
                            join BOSH.SERIALIZED_ITEM_LKP SIL on SIL.SI_KEY = ccot.SI_KEY and SIL.SOURCE_SYSTEM_CD = 0
                            join BOSH.SERIALIZED_ITEM_LKP SIL2 on SIL2.SI_KEY = OIT.SERIALIZED_ITEM_KEY and SIL.SOURCE_SYSTEM_CD = 0
                            JOIN BOSH.CONTRACT_COVERAGE_XREF  COTX on COTX.CONTRACT_KEY = con.CONTRACT_KEY
                        Where ccot.SI_KEY <> OIT.SERIALIZED_ITEM_KEY  -- Here checked order SI_KEY is different that CONTRACT_OUTPUT_TBL picked SI_KEY
                            and sil.SI_XID = SIL2.SI_XID -- Here checked and taken cases where same SI_XID exist for two SI_KEY
                            and con.retail_amt > 1
                            and con.contract_status_key NOT IN (2, 3,5)
                            and cotx.SI_KEY in (
                            1260317,2109828,3177095,3187484,3280284,3294443,3369966,3418962,3481716,3504146,3538649,3556246,3556247,3556255,
                            3584504,3597019,3660023,3660107,3679634,3703138,3728551,3732729,3740645,3821097,3821132,3823516,3824853,3867095,
                            3885012,3919749,3924900,3940149,3940180,3940188,3977184,3996432,4047085,4096915,4106871,4121941,4165313,4165358,
                            4174718,4220895,4296517,4308341))
		) T2
		ON(  T1.CONTRACT_KEY=T2.CONTRACT_KEY  )
		WHEN MATCHED THEN UPDATE
			SET T1.SI_KEY=T2.SERIALIZED_ITEM_KEY,
                T1.UPDATE_AUDIT_KEY= v_audit_key,T1.SYNC_AUDIT_KEY =NULL
       where T1.SI_KEY <> T2.SERIALIZED_ITEM_KEY
       ;

        DBMS_OUTPUT.PUT_LINE(v_audit_key);
       COMMIT;

END;

select COUNT(*) from BOSH.CONTRACT_COVERAGE_XREF where UPDATE_AUDIT_KEY =949015;--104