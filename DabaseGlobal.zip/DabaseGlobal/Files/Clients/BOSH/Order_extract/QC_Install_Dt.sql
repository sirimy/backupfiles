--qc install date
select
        s.INSTALL_DT as new_INSTALL_DT
        ,t.INSTALL_DT as last_INSTALL_DT
        ,count(*)
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
       --on t.EXTERNAL_CUSTOMER_NO = s.EXTERNAL_CUSTOMER_NO
 where s.TRANSACTION_TYPE = 'U'
   and coalesce(s.INSTALL_DT, date '1999-01-01') <> coalesce(t.INSTALL_DT, date '1999-01-01')
 group by s.INSTALL_DT, t.INSTALL_DT;
/*+--------------+---------------+--------+
|NEW_INSTALL_DT|LAST_INSTALL_DT|COUNT(*)|
+--------------+---------------+--------+
|2023-06-01    |null           |5       |     --OK
|2023-05-01    |2023-05-01     |29      |     --No chage in install_dt. Delete these records if no other change
|2023-04-01    |2023-05-01     |6       |     --OK
|null          |null           |11360   |     --we will retain just 5 records from this set and that too if there are other changes else delete all
+--------------+---------------+--------+
 */
insert into ORDER_EXTRACT_TBL_UNIQUE_IDENTIFIER
select
    s.UNIQUE_IDENTIFIER, 'INSTALL_DT'
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
       --on t.EXTERNAL_CUSTOMER_NO = s.EXTERNAL_CUSTOMER_NO
 where s.TRANSACTION_TYPE = 'U'
   and coalesce(s.INSTALL_DT, date '1999-01-01') <> coalesce(t.INSTALL_DT, date '1999-01-01');
 ;
COMMIT;