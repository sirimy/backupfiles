--qc OWNERSHIP_INTENTION
--Firm_Nm should be populated where OWNERSHIP_INTENTION is PROPERTY_MANAGER
select
        s.FIRM_NM as new_FIRM_NM
        ,t.FIRM_NM as last_FIRM_NM
        ,s.OWNERSHIP_INTENTION as new_OWNERSHIP_INTENTION
        ,t.OWNERSHIP_INTENTION as last_OWNERSHIP_INTENTION
        ,count(*)
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
--    and coalesce(s.FIRM_NM, 'xyz') <> coalesce(t.FIRM_NM, 'xyz')  --no rows
   and coalesce(s.OWNERSHIP_INTENTION, 'xyz') <> coalesce(t.OWNERSHIP_INTENTION, 'xyz')  --no rows
 group by s.FIRM_NM, t.FIRM_NM
          ,s.OWNERSHIP_INTENTION, t.OWNERSHIP_INTENTION
 order by s.OWNERSHIP_INTENTION nulls first;
/*
+-----------+------------+-----------------------+------------------------+--------+
|NEW_FIRM_NM|LAST_FIRM_NM|NEW_OWNERSHIP_INTENTION|LAST_OWNERSHIP_INTENTION|COUNT(*)|
+-----------+------------+-----------------------+------------------------+--------+
|null       |null        |HOMEOWNER              |UNKNOWN                 |316     |
|null       |null        |PROPERTY_MANAGER       |HOMEOWNER               |1       |  --firm_nm should have been populated for this change
|null       |null        |PROPERTY_MANAGER       |UNKNOWN                 |1       |  --firm_nm should have been populated for this change
+-----------+------------+-----------------------+------------------------+--------+
*/
insert into ORDER_EXTRACT_TBL_UNIQUE_IDENTIFIER
select
       s.UNIQUE_IDENTIFIER, 'OWNERSHIP_INTENTION'

  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
--    and coalesce(s.FIRM_NM, 'xyz') <> coalesce(t.FIRM_NM, 'xyz')  --no rows
   and coalesce(s.OWNERSHIP_INTENTION, 'xyz') <> coalesce(t.OWNERSHIP_INTENTION, 'xyz')  --no rows
   and s.OWNERSHIP_INTENTION = 'PROPERTY_MANAGER';
--  group by s.FIRM_NM, t.FIRM_NM
--           ,s.OWNERSHIP_INTENTION, t.OWNERSHIP_INTENTION
--  order by s.OWNERSHIP_INTENTION nulls first
;
commit;