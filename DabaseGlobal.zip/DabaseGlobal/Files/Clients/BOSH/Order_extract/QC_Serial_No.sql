--qc SERIAL_NO
select
        s.SERIAL_NO as new_SERIAL_NO
        ,t.SERIAL_NO as last_SERIAL_NO
        ,count(*)
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
   and coalesce(s.SERIAL_NO, 'xyz') <> coalesce(t.SERIAL_NO, 'xyz')
 group by s.SERIAL_NO, t.SERIAL_NO
 order by s.SERIAL_NO nulls first;
/*
+-------------+--------------+--------+
|NEW_SERIAL_NO|LAST_SERIAL_NO|COUNT(*)|
+-------------+--------------+--------+
|null         |null          |11392   |
|S1 WAT28401UC|S1 WAT28401UC |1       |
|S123 PRG305WH|S123 PRG305WH |1       |
|S2 PRG305WH  |S2 PRG305WH   |1       |
|S2 WAT28401UC|S2 WAT28401UC |1       |
|S3 PRG305WH  |S3 PRG305WH   |1       |
|S3 WAT28401UC|S3 WAT28401UC |1       |
|S4 PRG305WH01|S4 PRG305WH   |1       |        --Only set with change in SERIAL_NO
|S4 WAT28401UC|S4 WAT28401UC |1       |
+-------------+--------------+--------+
 */

insert into ORDER_EXTRACT_TBL_UNIQUE_IDENTIFIER
select
       s.UNIQUE_IDENTIFIER, 'SERIAL_NO'

  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
   and coalesce(s.SERIAL_NO, 'xyz') <> coalesce(t.SERIAL_NO, 'xyz')
  ;
/*
 commit;
 */
 commit;