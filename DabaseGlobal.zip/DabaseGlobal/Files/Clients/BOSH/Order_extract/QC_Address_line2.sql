--qc SHIPPING_ADDRESS_LINE2_TX
select
        s.SHIPPING_ADDRESS_LINE2_TX as new_SHIPPING_ADDRESS_LINE2_TX
        ,t.SHIPPING_ADDRESS_LINE2_TX as last_SHIPPING_ADDRESS_LINE2_TX
        ,count(*)
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
   and coalesce(s.SHIPPING_ADDRESS_LINE2_TX, 'xyz') <> coalesce(t.SHIPPING_ADDRESS_LINE2_TX, 'xyz')
 group by s.SHIPPING_ADDRESS_LINE2_TX, t.SHIPPING_ADDRESS_LINE2_TX;
/*+-----------------------------+------------------------------+--------+
|NEW_SHIPPING_ADDRESS_LINE2_TX|LAST_SHIPPING_ADDRESS_LINE2_TX|COUNT(*)|
+-----------------------------+------------------------------+--------+
|10A                          |null                          |5       |
|10B                          |null                          |2       |
+-----------------------------+------------------------------+--------+
 */

insert into ORDER_EXTRACT_TBL_UNIQUE_IDENTIFIER
select
    s.UNIQUE_IDENTIFIER, 'SHIPPING_ADDRESS_LINE2_TX'
       -- ,count(*)
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
   and coalesce(s.SHIPPING_ADDRESS_LINE2_TX, 'xyz') <> coalesce(t.SHIPPING_ADDRESS_LINE2_TX, 'xyz');

commit;
select * from ORDER_EXTRACT_TBL_UNIQUE_IDENTIFIER;

select
    s.UNIQUE_IDENTIFIER,
        s.SHIPPING_ADDRESS_LINE2_TX as new_SHIPPING_ADDRESS_LINE2_TX
        ,t.SHIPPING_ADDRESS_LINE2_TX as last_SHIPPING_ADDRESS_LINE2_TX
       -- ,count(*)
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
   and coalesce(s.SHIPPING_ADDRESS_LINE2_TX, 'xyz') <> coalesce(t.SHIPPING_ADDRESS_LINE2_TX, 'xyz')
-- group by s.SHIPPING_ADDRESS_LINE2_TX, t.SHIPPING_ADDRESS_LINE2_TX
;


--Checking if BILLING_ADDRESS_LINE2_TX got populated by any chance
 select
        s.BILLING_ADDRESS_LINE2_TX as new_SHIPPING_ADDRESS_LINE2_TX
        ,t.BILLING_ADDRESS_LINE2_TX as last_SHIPPING_ADDRESS_LINE2_TX
        ,count(*)
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
   and coalesce(s.BILLING_ADDRESS_LINE2_TX, 'xyz') <> coalesce(t.BILLING_ADDRESS_LINE2_TX, 'xyz')
 group by s.BILLING_ADDRESS_LINE2_TX, t.BILLING_ADDRESS_LINE2_TX;
--No rows for BILLING_ADDRESS_LINE2_TX and this is expected
--Either no change or this column was/is null both last and this time...ideally this column should be null for these transactions