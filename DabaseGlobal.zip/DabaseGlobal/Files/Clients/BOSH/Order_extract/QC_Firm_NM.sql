--qc FIRM_NM
select
        s.FIRM_NM as new_SERIAL_NO
        ,t.FIRM_NM as last_SERIAL_NO
        ,s.OWNERSHIP_INTENTION as new_OWNERSHIP_INTENTION
        ,t.OWNERSHIP_INTENTION as last_OWNERSHIP_INTENTION
        ,count(*)
  from ORDER_EXTRACT_TBL s
       join bosh.ORDER_EXTRACT_TBL t on t.UNIQUE_IDENTIFIER = s.UNIQUE_IDENTIFIER
 where s.TRANSACTION_TYPE = 'U'
    and coalesce(s.FIRM_NM, 'xyz') <> coalesce(t.FIRM_NM, 'xyz')  --no rows
--   and coalesce(s.OWNERSHIP_INTENTION, 'xyz') <> coalesce(t.OWNERSHIP_INTENTION, 'xyz')  --no rows
 group by s.FIRM_NM, t.FIRM_NM
          ,s.OWNERSHIP_INTENTION, t.OWNERSHIP_INTENTION
 order by s.OWNERSHIP_INTENTION nulls first;
/*
+-------------+--------------+--------+
|NEW_SERIAL_NO|LAST_SERIAL_NO|COUNT(*)|
+-------------+--------------+--------+

+-------------+--------------+--------+
 */




 select c.order_id,ad1.address_id,ad2.address_id,
       ad2.firm_nm,ad1.firm_nm,
       ad2.first_nm,ad1.first_nm,
       ad2.last_nm,ad1.last_nm,
       ad2.middle_nm,ad1.middle_nm
from  order_tbl c
         join shipping_info_tbl sit on c.order_id   = sit.order_id
         join address_tbl ad2 on(sit.address_id=ad2.address_id)      --shipping info
         join billing_info_tbl bit on c.order_id   = bit.order_id
         join address_tbl ad1 on(bit.address_id=ad1.address_id)
        where
 c.order_id in (  351159,351157,351155,351179,351153);