
select COUNT(*) FROM BOSHSTG.bosh_rejected_cierra_nov06_2025 T1;--76


select  COUNT(OIT.ORDER_KEY),COUNT(CD.CONTRACT_KEY),COUNT(*) FROM BOSHSTG.bosh_rejected_cierra_nov06_2025 T1
                JOIN bosh.ORDER_ITEM_TBL OIT ON   ORDER_KEY  || '-' || ORDER_LINE_KEY = T1.UNIQUE_IDENTIFIER
                LEFT join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY
                LEFT JOIN BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = OIT.ORDER_KEY and COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY
                LEFT JOIN BOSH.CONTRACT_DIM CD on CD.CONTRACT_KEY = COT.CONTRACT_KEY;
-- +--------------------+----------------------+--------+
-- |COUNT(OIT.ORDER_KEY)|COUNT(CD.CONTRACT_KEY)|COUNT(*)|
-- +--------------------+----------------------+--------+
-- |76                  |0                     |76      |
-- +--------------------+----------------------+--------+

DECLARE

        v_audit_key INTEGER := get_audit_key (p_program_nm => 'Manual update', p_DESCRIPTIVE_TX => 'Manually populating data for contracts with date issue BOSH-1943', p_table_nm => 'RAW_CONTRACT_SALES_TBL', p_author_nm => 'iahmad' );
BEGIN

        Insert into bosh.RAW_CONTRACT_SALES_TBL
            (UNIQUE_IDENTIFIER, P2_CONTRACT_NO, STATUS_CD,
             CONTRACT_START_DATE, CONTRACT_END_DATE,
             ERROR_TXT, FILE_NM, BILLING_UNIQUE_SEQ_NO, SHIPPING_UNIQUE_SEQ_NO, INSERT_AUDIT_KEY)
         select  RCST.UNIQUE_IDENTIFIER, P2_CONTRACT_NO, STATUS_CD,
                 TO_CHAR(con, 'MM/DD/YYYY'), TO_CHAR(CORRECTED_CONTRACT_END_DATE, 'MM/DD/YYYY'),
                 ERROR_TXT, 'Bosch_REN_Contracts_V2_BOSH_1943', NULL, NULL, v_audit_key
        from bosh.RAW_CONTRACT_SALES_TBL RCST
          JOIN BOSHSTG.bosh_rejected_cierra_nov06_2025 T1 ON 'BSH' || '-' || RCST.UNIQUE_IDENTIFIER = T1.UNIQUE_IDENTIFIER;

       DBMS_OUTPUT.PUT_LINE(v_audit_key);
       DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );


       COMMIT;

END;