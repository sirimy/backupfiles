---> clean product price dim
        --===> Set active_ind = 'N' for suppress sql


--->

select COUNT(*),COUNT(distinct  BUNDLE_KEY ) from BASE_OFFER_ITEM_XREF;--433883
-- COUNT(*),COUNT(DISTINCTBUNDLE_KEY)
-- 433883,108701
;--

select COUNT(*),COUNT(distinct  BUNDLE_KEY ) from BASE_OFFER_ITEM_XREF;--433086
-- +--------+-------------------------+
-- |COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
-- +--------+-------------------------+
-- |433086  |108701                   |
-- +--------+-------------------------+

select * from BOSH.PRODUCT_PRICE_DIM PRD
JOIN BOSH.PRODUCT_DIM PD on PD.PRODUCT_KEY = PRD.PRODUCT_KEY
Where PD.MODEL_NO = 'HCB50651UC';

--create table BASE_OFFER_ITEM_XREF_JULY_2025_28 as select * from BASE_OFFER_ITEM_XREF;

select COUNT(*) from BASE_OFFER_ITEM_XREF_JULY_2025_28;--433883



 Select PRICING_SCHEME_KEY,POLICY_KEY, PRODUCT_KEY,TERM_KEY  from BASE_OFFER_ITEM_XREF ;
--> delete rows for which NVL(active_ind, 'Y') = 'N'


--Create Table soliciting_a_maximum_of_4_terms_2025_July_28 as
        SELECT *
                      FROM (
                            SELECT pricing_scheme_key, pricing_scheme_desc, product_key, age, term_months, policy_key
                                   ,row_number() OVER(PARTITION BY pricing_scheme_key, pricing_scheme_desc, product_key, age ORDER BY term_months DESC ) AS rno
                              FROM
                                   P_PRODUCT_PRICE_DIM ppd
                                   JOIN v_product pd USING (product_key)
                                   JOIN V_PRICING_SCHEME_DIM psd USING (pricing_scheme_key)
                                   --JOIN P_POLICY_TBL pol USING (policy_key)
                                    join
                                       (select policy_key,   age
                                        from policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                                        where pol.exp_dt > sysdate
                                        union
                                        select policy_key,   age
                                        from p_policy_tbl pol join p_term_dim tr on tr.term_key = pol.term_key
                                        where pol.exp_dt > sysdate
                                    ) pol USING (policy_key)
                             WHERE
                                   1=1
                               AND pricing_scheme_desc like 'RN%'
                               AND NVL(active_ind, 'Y') = 'Y'
                             AND psd.END_DT > sysdate
                               --AND NVL(pd.do_not_solicit_product_ind, 'N') <> 'Y'    --QC
                               --AND product_coverage_end_dt >= SYSDATE                --QC
                               --AND NVL( pd.price_amt, 0 ) <> 0                       --QC
                            )
                     WHERE    rno > 4
;
commit;

select pricing_scheme_desc, product_key, age, term_months, policy_key from soliciting_a_maximum_of_4_terms_2025_July_28
where pricing_scheme_desc not like '%RN%'
;--0

select count( distinct PRODUCT_KEY),COUNT(*)  from soliciting_a_maximum_of_4_terms_2025_July_28;--1826
-- +--------------------------+--------+
-- |COUNT(DISTINCTPRODUCT_KEY)|COUNT(*)|
-- +--------------------------+--------+
-- |479                       |1826    |
-- +--------------------------+--------+

select count(*)  from soliciting_a_maximum_of_4_terms_2025_July_28 where policy_key< 7000;--180
select count(*)  from soliciting_a_maximum_of_4_terms_2025_July_28 where policy_key > 7000;--1646

select distinct  age, term_months  from soliciting_a_maximum_of_4_terms_2025_July_28;
-- +---+-----------+
-- |AGE|TERM_MONTHS|
-- +---+-----------+
-- |3  |12         |
-- |2  |12         |
-- |4  |12         |
-- |5  |12         |
-- +---+-----------+

select * from BOSH.POLICY_EXT_TBL where POLICY_KEY in (733,1231,1246);
-- +----------+-----+---------------+----------------+
-- |POLICY_KEY|BRAND|CHANNELS       |PRODUCT_CAT_DESC|
-- +----------+-----+---------------+----------------+
-- |733       |BSUS |Renewal program|LAUNDRY-WASHER  |
-- |1231      |Bosch|RENEWAL PROGRAM|Laundry-Washer  |
-- |1246      |Bosch|RENEWAL PROGRAM|Laundry-Washer  |
-- +----------+-----+---------------+----------------+

select * from BOSH.POLICY_TBL where POLICY_KEY in (733,1231,1246);
-- +----------+-------------------------------------+--------------------------------------+------------------+------------+----------+-----------------+
-- |POLICY_KEY|NAME                                 |DESCRIPTION                           |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |MIN_PRODUCT_PRICE|
-- +----------+-------------------------------------+--------------------------------------+------------------+------------+----------+-----------------+
-- |733       |Bosch Appliance Service plan - 1 Year|1 yr Bosch Appliance Service plan (RN)|BSLWD12UR2        |2017-05-01  |2099-12-31|1000.00          |
-- |1231      |Bosch Appliance Service plan - 1 Year|1 yr Bosch Appliance Service plan (RN)|BSLWD12UR4        |2019-03-15  |2099-12-31|1000.00          |
-- |1246      |Bosch Appliance Service plan - 1 Year|1 yr Bosch Appliance Service plan (RN)|BSLWD12UR5        |2019-03-15  |2099-12-31|1000.00          |
-- +----------+-------------------------------------+--------------------------------------+------------------+------------+----------+-----------------+

select * from   soliciting_a_maximum_of_4_terms_2025_July_28 where POLICY_KEY = 733;


-- ON (src.pricing_scheme_key = tgt.pricing_scheme_key AND src.product_key = tgt.product_key AND src.policy_key = tgt.policy_key)
select max(policy_key),MIN(policy_key),max(pricing_scheme_key),min(pricing_scheme_key)  from soliciting_a_maximum_of_4_terms_2025_July_28;

select * from BOSH.PRICING_SCHEME_DIM where PRICING_SCHEME_KEY = 228;

select policy_key,count(*)
from soliciting_a_maximum_of_4_terms_2025_July_28
group by policy_key
order by policy_key
;


select count( distinct PRODUCT_KEY),COUNT(*) from bosh.PRODUCT_PRICE_DIM where  (pricing_scheme_key,product_key,product_key,policy_key) in (
            select pricing_scheme_key,product_key,product_key,policy_key from soliciting_a_maximum_of_4_terms_2025_July_28
            );
-- +--------------------------+--------+
-- |COUNT(DISTINCTPRODUCT_KEY)|COUNT(*)|
-- +--------------------------+--------+
-- |479                       |1826    |
-- +--------------------------+--------+


DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'BOSH-1867', p_table_nm => 'PRODUCT_PRICE_DIM');
BEGIN
        update  bosh.PRODUCT_PRICE_DIM
            SET  SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key
        where  (pricing_scheme_key,product_key,product_key,policy_key) in (
            select pricing_scheme_key,product_key,product_key,policy_key from soliciting_a_maximum_of_4_terms_2025_July_28
            )
        ;

       DBMS_OUTPUT.PUT_LINE(v_audit_key);
       DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );

       COMMIT;

END;


select  * from BOSHSTG.soliciting_a_maximum_of_4_terms_2025_July_28;

grant select on soliciting_a_maximum_of_4_terms_2025_July_28 to BOSH;


