select  policy_product_xid as SKU, min_product_price, max_product_price, vpr.model_no, vpr.price_amt as Model_MSRP,
       vpr.brand_nm, vpr.product_category_nm, age, ppd.term_months, ppd.base_price_amt,ppd.ACTIVE_IND, pricing_scheme_desc, ppd.PRICING_SCHEME_KEY,vpr.PRODUCT_KEY,pol.policy_key
  from
       (select policy_key, policy_product_xid, age, min_product_price, max_product_price, term_key from policy_tbl
         where exp_dt >= trunc(sysdate)
        union
       select policy_key, policy_product_xid, age, min_product_price, max_product_price, term_key from p_policy_tbl
        where exp_dt >= trunc(sysdate)
        ) pol
       left join
       (select * from V_POLICY_FEE_Stg fee
       union
       select * from bosh.V_POLICY_FEE fee
       ) fee on fee.policy_key = pol.policy_key
       join p_product_price_dim ppd
            on ppd.policy_key = pol.policy_key
       join bosh.v_product vpr
            on vpr.product_key = ppd.product_key
       join V_PRICING_SCHEME_DIM psd
            on psd.pricing_scheme_key = ppd.pricing_scheme_key
        join AUDIT_TBL AT on  ppd.INSERT_AUDIT_KEY = AT.AUDIT_KEY
  where psd.END_DT > sysdate
        and psd.PRICING_SCHEME_NAME <> 'BUILDER'
          and vpr.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
ORDER BY psd.PRICING_SCHEME_DESC,
         vpr.BRAND_NM,
         vpr.PRODUCT_CATEGORY_NM,
         pol.MIN_PRODUCT_PRICE,
         vpr.MODEL_NO,
         pol.age,
         ppd.term_months
;
-- PRICING SCHEME DESC
-- BRAND_NM
-- PRODUCT CATEGORY NM
-- MIN PRODUCT PRICE
-- MODEL_NO
-- AGE
-- TERM MONTHS
