select PRODUCT_KEY, MODEL_NO, PRODUCT_NM, PRICE_AMT as Model_MSRP, BRAND_NM, PRODUCT_CATEGORY_NM,
       MATERIAL_GROUP, MARKETING_PRODUCT_NM, DO_NOT_SOLICIT_PRODUCT_IND, to_char(PRODUCT_COVERAGE_END_DT, 'MM/DD/YYYY') as PRODUCT_COVERAGE_END_DT
  from bosh.v_product
 where 1=1
--    and do_not_solicit_product_ind = 'N'
--    and product_coverage_end_dt >= sysdate
   and nvl(price_amt, 0) <> 0
--AND BRAND_NM in ('Thermador','Gaggenau')
-- and PRODUCT_KEY in (select PRODUCT_KEY from BOSH.PRODUCT_PRICE_DIM where POLICY_KEY in (
-- select RAW_PRICING_TBL.POLICY_KEY from RAW_PRICING_TBL ))
;