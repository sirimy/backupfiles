
SELECT *
FROM ( SELECT DISTINCT
          ppt.POLICY_ID,
          pol.description,
--          pol.age,
--          pst.description, -- on un comment this line its increase lines as RO also exist with RN
--          psl.pricing_scheme_id,
          psl.DAYS_FROM_COVRG_LOW , psl.DAYS_FROM_COVRG_HIGH,
           (EXTRACT(epoch FROM (SELECT (date'2025-01-02 16:41:20.415131' - LATEST_COVERAGE_EXP_DT)))/86400) chk,si.SERIALIZED_ITEM_ID,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= date'2025-01-02 16:41:20.415131'
			          THEN
				       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'
				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= date'2025-01-02 16:41:20.415131'
			          THEN
				       date_trunc('day', date '2025-01-02 16:41:20.415131')
			          ELSE
				       date_trunc('day', date '2025-01-02 16:41:20.415131')+interval '1 days'
			     END AS coverage_start_dt,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > date'2025-01-02 16:41:20.415131'
			          THEN
			               date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= date'2025-01-02 16:41:20.415131'
			          THEN
				       date_trunc('day', date'2025-01-02 16:41:20.415131') + ppt.TERM_MONTHS * interval '1 month'
                      ELSE
				      date_trunc('day', date'2025-01-02 16:41:20.415131') + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
			     END AS coverage_end_dt,
			     ppt.BASE_PRICE_AMT,
			     ppt.TERM_MONTHS,
			     si.purchase_dt,
			     pol.age,
			     round(DATE_PART('day', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
			     pol.description as policy_description
			FROM
			(
			    SELECT * from serialized_item where serialized_item_id=16895452) si
			            JOIN pricing_scheme_lkp psl
                            ON (
                                si.latest_coverage_type_id=psl.latest_coverage_type_id and
                                (EXTRACT(epoch FROM (SELECT (date'2025-01-02 16:41:20.415131' - LATEST_COVERAGE_EXP_DT)))/86400)::int between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH
                                )
			JOIN product_price_tbl ppt
			            ON (
			                    si.product_id = ppt.product_id and
			                    psl.pricing_scheme_id = ppt.pricing_scheme_id and
			                    coalesce(ppt.active_ind, 'Y') = 'Y'
			                ) -- BOSH-361
			JOIN policy pol ON
			                (
			                    ppt.POLICY_ID=pol.POLICY_ID
			                 )
			JOIN product_ext PE ON
			                (
			                    PE.product_id = ppt.product_id
			                )
			join pricing_scheme_tbl pst on
			                pst.pricing_scheme_id = ppt.pricing_scheme_id
			WHERE
			        PE.PRODUCT_COVERAGE_END_DT  >=
                                            CASE
                                                WHEN si.LATEST_COVERAGE_EXP_DT > date'2025-01-02 16:41:20.415131'
                                                    THEN
                                                       date_trunc('day',LATEST_COVERAGE_EXP_DT)+interval '1 day'+ ppt.TERM_MONTHS * interval '1 month'
                                                WHEN si.LATEST_COVERAGE_EXP_DT + interval '1 days' >= date'2025-01-02 16:41:20.415131'
                                                    THEN
                                                        date_trunc('day', date'2025-01-02 16:41:20.415131') + ppt.TERM_MONTHS * interval '1 month'
                                                    ELSE
                                                        date_trunc('day', date'2025-01-02 16:41:20.415131') + interval '1 days' + ppt.TERM_MONTHS * interval '1 month'
                                            END
			        ---
			        and case
			            when substr(pst.description, 1, 2) = 'RN'
			                then
					        round(DATE_PART('day', si.latest_coverage_exp_dt - si.purchase_dt)/365)
				            else 0
				        end = coalesce (pol.age, 0)
			) t
where (coverage_end_dt - purchase_dt)  <= interval '3650 day'    --total coverage must be less than 10 years for all brands
ORDER BY TERM_MONTHS ASC;

select * from pricing_scheme_lkp where pricing_scheme_id in(161,176,177,178,179,180,181);