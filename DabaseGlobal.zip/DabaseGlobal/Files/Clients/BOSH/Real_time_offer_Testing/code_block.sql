
do $$
<<first_block>>
declare

/* Constants */
  c_delay_days     CONSTANT numeric := 1;
  c_offer_exp_dt   CONSTANT OFFER_TBL.OFFER_EXP_UTC_TS%TYPE := LOCALTIMESTAMP + INTERVAL '72' HOUR ; --ELUX-251
  c_offer_start_dt CONSTANT OFFER_TBL.OFFER_START_UTC_TS%TYPE := date_trunc('day', LOCALTIMESTAMP) - INTERVAL '1' DAY ; --FAP-1501
  c_offer_type_cd  CONSTANT VARCHAR(20):='PolicyOffer';
  --c_max_seq CONSTANT numeric := 999999999999999;
  --l_limit numeric := 1000;
  c_age_admissible_in_months CONSTANT numeric := 108;  --As per PK_Web.VIEW_AVAILABLE_PLANS




/* Variables */
   v_cnt                numeric;
   v_off_seq            numeric;
   v_in_serial          numeric;
   v_in_customer        numeric;
   --v_group_no           numeric;
   --v_seq_no             numeric;
   v_job_id             numeric;
   v_error_stack 	    text;
   i 			        numeric:=1;
  in_serialized_item_id text:='16895452';

/** Cursors **/
   --out_offer_id         REFCURSOR;
   v_off                text;
   r_rec_type           RECORD;
   sql_query TEXT := 'SELECT *
                        FROM ( SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT >= LOCALTIMESTAMP
			          THEN
				       date_trunc(''day'',LATEST_COVERAGE_EXP_DT)+interval ''1 day''
				  WHEN si.LATEST_COVERAGE_EXP_DT + interval '''|| c_delay_days ||' days'' >= LOCALTIMESTAMP
			          THEN
				       date_trunc(''day'', LOCALTIMESTAMP)
			          ELSE
				       date_trunc(''day'', LOCALTIMESTAMP)+interval '''|| c_delay_days ||' days''
			     END AS coverage_start_dt,
			     CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
			          THEN
			               date_trunc(''day'',LATEST_COVERAGE_EXP_DT)+interval ''1 day''+ ppt.TERM_MONTHS * interval ''1 month''
			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '''|| c_delay_days ||' days'' >= LOCALTIMESTAMP
			          THEN
				       date_trunc(''day'', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval ''1 month''
                                  ELSE
				      date_trunc(''day'', LOCALTIMESTAMP) + interval '''|| c_delay_days ||' days'' + ppt.TERM_MONTHS * interval ''1 month''
			     END AS coverage_end_dt,
			     ppt.BASE_PRICE_AMT,
			     ppt.TERM_MONTHS,
			     si.purchase_dt,
			     pol.age,
			     round(DATE_PART(''day'', latest_coverage_exp_dt - PURCHASE_DT)/365) as units_age,
			     pol.description as policy_description
			FROM
			(SELECT * from serialized_item where serialized_item_id='||in_serialized_item_id||') si
			JOIN pricing_scheme_lkp psl
			ON(si.latest_coverage_type_id=psl.latest_coverage_type_id and
			(EXTRACT(epoch FROM (SELECT (NOW() - LATEST_COVERAGE_EXP_DT)))/86400)::int
			between psl.DAYS_FROM_COVRG_LOW and psl.DAYS_FROM_COVRG_HIGH )
			JOIN product_price_tbl ppt ON
			(  si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id and coalesce(ppt.active_ind, ''Y'') = ''Y'') -- BOSH-361
			JOIN policy pol ON
			(ppt.POLICY_ID=pol.POLICY_ID
			)
			JOIN product_ext PE ON
			(PE.product_id = ppt.product_id)
			join pricing_scheme_tbl pst
	                on pst.pricing_scheme_id = ppt.pricing_scheme_id
			WHERE
			PE.PRODUCT_COVERAGE_END_DT  >= CASE WHEN si.LATEST_COVERAGE_EXP_DT > LOCALTIMESTAMP
			          THEN
			               date_trunc(''day'',LATEST_COVERAGE_EXP_DT)+interval ''1 day''+ ppt.TERM_MONTHS * interval ''1 month''
			          WHEN si.LATEST_COVERAGE_EXP_DT + interval '''|| c_delay_days ||' days'' >= LOCALTIMESTAMP
			          THEN
				       date_trunc(''day'', LOCALTIMESTAMP) + ppt.TERM_MONTHS * interval ''1 month''
                                  ELSE
				      date_trunc(''day'', LOCALTIMESTAMP) + interval '''|| c_delay_days ||' days'' + ppt.TERM_MONTHS * interval ''1 month''
			        END
			        ---
			    and case when substr(pst.description, 1, 2) = ''RN'' then
					  round(DATE_PART(''day'', si.latest_coverage_exp_dt - si.purchase_dt)/365)
				     else 0
				end = coalesce (pol.age, 0)
			) t
                        where (coverage_end_dt - purchase_dt)  <= interval ''3650 day''    --total coverage must be less than 10 years for all brands
                        ORDER BY TERM_MONTHS ASC';

begin
       -- get the number of films
        in_serialized_item_id := '16895452';

        raise notice '------>%',sql_query;

        FOR  r_rec_type in EXECUTE format(sql_query) USING in_serialized_item_id
        LOOP
            raise notice '------>%',sql_query;

            /**Based on Offer id and above policy_type_id find the seq no**/
			INSERT INTO offer_item_tbl_testing_iahmad (
			                OFFER_ID,
                                        OFFER_LINE_ID,
                                        OFFER_TYPE_CD,
                                        POLICY_ID,
                                        SERIALIZED_ITEM_ID,
                                        COVERAGE_START_DT,
                                        COVERAGE_EXP_DT,
                                        PRICE_AMT,
                                        DISCOUNT1_PCT,
                                        DISCOUNT2_AMT,
                                        DISCOUNT2_PCT,
                                        ACTIVE_IND,
                                        DISPLAY_SEQ_NUM,
                                        DISPLAY_GROUP_NUM,
                                        FLEXPAYABLE_IND,
                                        LAST_UPDATED_TS
                                        )
			VALUES (
			 0,
                         i,
                         c_offer_type_cd,
                         r_rec_type.POLICY_ID,
                         r_rec_type.SERIALIZED_ITEM_ID,
                         r_rec_type.coverage_start_dt,
                         r_rec_type.coverage_end_dt,
                         r_rec_type.BASE_PRICE_AMT,
                         1,
                         0,
                         0,
                         'Y',
                         i,
                         1,
                         'Y' --ELUX-299 06/08/2015
                         ,now()
                         );

                     -- COMMIT;
                      i := i + 1;

        end loop;


   -- display a message
   raise notice 'The number of rows is %', i;
end first_block $$;