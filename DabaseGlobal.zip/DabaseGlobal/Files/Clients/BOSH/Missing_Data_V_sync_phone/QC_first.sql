


CREATE TABLE boshstg_p_visitor_address_xref_bosh_1840
  AS (
     select distinct pvdx.VISITOR_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,pvdx.END_DT_KEY,pvdx.EFF_DT_KEY,pvdx.INSERT_AUDIT_KEY,ATT3.CREATION_DT,pvdx.UPDATE_AUDIT_KEY,pvdx.SYNC_AUDIT_KEY,SD.SERIAL_NO
     from BOSH.DS_ACE_OUTPUT_TBL_ARCH DSACE
                        join BOSH.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                        join BOSH.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                        join BOSH.ADDRESS_DIM AD on AD.ADDRESS_KEY = AOT.ADDRESS_KEY
                        join BOSH.CUSTOMER_DIM CD  on CD.PRIMARY_ADDRESS_KEY = AD.ADDRESS_KEY
                        join BOSH.VISITOR_DIM VD on VD.CUSTOMER_KEY = CD.CUSTOMER_KEY
                        --join BOSH.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                        join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VD.VISITOR_KEY
                        join BOSH.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY AND VOX.PRIMARY_IND = 'Y'
                        join BOSH.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                        join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                        join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
                        join AUDIT_TBL ATT3 on pvdx.INSERT_AUDIT_KEY = ATT3.AUDIT_KEY
                    where --DSACE.PROCESS_DT = '20250520' AND
                          DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
                          AND pvdx.PRIMARY_IND = 'Y'
                          AND AD.ADDRESS_LINE1_TX IS NULL
                          AND ATT.CREATION_DT >= date '2025-05-01'
                          AND ATT2.CREATION_DT >= date '2025-05-01'
     )
;--
