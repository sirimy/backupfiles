BOSH> DECLARE
             v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'SET PRIMARY_ADDRESS_KEY', p_table_nm => 'CUSTOMER_DIM');

      BEGIN


              MERGE INTO BOSH.VISITOR_ADDRESS_XREF tgt USING
                  (
                      Select * from (
                               select DISTINCT cd.CUSTOMER_KEY,
                                                                                          VX.VISITOR_KEY--,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
                                                                                          ,VAX.END_DT_KEY,VAX.EFF_DT_KEY,
                                                                                          VX.PRIMARY_IND,
                                                                                          ATT2.CREATION_DT,
                                                                                          AD2.ADDRESS_KEY,
                                                                                          AD2.ADDRESS_LINE1_TX,
                                                                                          VX.INSERT_AUDIT_KEY,
                                                                                          VX.SYNC_AUDIT_KEY,
                                                                                          VX.UPDATE_AUDIT_KEY,
                                                                                          ROW_NUMBER() OVER (PARTITION BY cd.CUSTOMER_KEY,VX.VISITOR_KEY ORDER BY ATT2.CREATION_DT desc) as rn
                                                                          from BOSH.VISITOR_ADDRESS_XREF VAX
                                                                                   join BOSH.ADDRESS_DIM AD1
                                                                                        on AD1.ADDRESS_KEY = VAX.ADDRESS_KEY AND VAX.PRIMARY_IND = 'X'
                                                                                   join BOSH.VISITOR_DIM vd
                                                                                        on vd.VISITOR_KEY = VAX.VISITOR_KEY AND VAX.PRIMARY_IND = 'X'
                                                                                   join BOSH.CUSTOMER_DIM cd
                                                                                        on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY AND VAX.PRIMARY_IND = 'X'
                                                                                   join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
                                                                                   join BOSHSTG.boshstg_p_visitor_address_xref_bosh_1840_30th_april T2
                                                                                        on T2.VISITOR_KEY = VAX.VISITOR_KEY
                                                                                   JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
                                                                                   join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
                                                                                   JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
                                                                          where AD1.ADDRESS_LINE1_TX IS NULL
                                                                            AND ATT.CREATION_DT > date'2025-04-30'
                                                                            and VAX.ADDRESS_KEY <> vx.ADDRESS_KEY
                                                                            and vx.PRIMARY_IND = 'N'
                                                                            AND AD2.ADDRESS_LINE1_TX is not null
                      )
                      Where rn = 1

                      )src
              ON (tgt.VISITOR_KEY = src.VISITOR_KEY AND tgt.ADDRESS_KEY = src.ADDRESS_KEY)
              WHEN MATCHED THEN
                  UPDATE SET tgt.ADDRESS_KEY_TEMP = src.ADDRESS_KEY,tgt.PRIMARY_IND = 'Y',tgt.END_DT_KEY = src.END_DT_KEY, SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key
              ;

               DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
                    DBMS_OUTPUT.PUT_LINE(v_audit_key);

             COMMIT;

      END;
[2025-06-04 14:46:15] completed in 750 ms
513
969450
