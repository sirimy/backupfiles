-- --+------------+-----------+
-- |CUSTOMER_KEY|VISITOR_KEY|
-- +------------+-----------+
-- |5609204     |3058141    |
-- +------------+-----------+

select vx.ADDRESS_KEY,ad1.ADDRESS_LINE1_TX,att.CREATION_DT from VISITOR_ADDRESS_XREF vx
         join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = vx.ADDRESS_KEY
     join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
         where VISITOR_KEY  =3058141;
-- +-----------+-----------------------+--------------------------+
-- |ADDRESS_KEY|ADDRESS_LINE1_TX       |CREATION_DT               |
-- +-----------+-----------------------+--------------------------+
-- |14094522   |10901 TORTUGA RACING LN|2025-06-04 04:39:17.000000|
-- |14514794   |NULL                   |2025-06-04 04:39:17.000000|
-- +-----------+-----------------------+--------------------------+

select * from VISITOR_ADDRESS_XREF vx  where VISITOR_KEY  =3058141;
select * from CUSTOMER_DIM CD  where CUSTOMER_KEY  =5609204;
-- +------------+-------------+-------------------+----------------------+-------------+----------------+-------------------+
-- |CUSTOMER_KEY|HOUSEHOLD_KEY|PRIMARY_VISITOR_KEY|DERIVED_SUPPRESSION_CD|DIM_STATUS_CD|PRIMARY_PURL_KEY|PRIMARY_ADDRESS_KEY|
-- +------------+-------------+-------------------+----------------------+-------------+----------------+-------------------+
-- |5609204     |2691170      |3058141            |N                     |N            |4293928         |14514794           |
-- +------------+-------------+-------------------+----------------------+-------------+----------------+-------------------+
COMMIT;
DECLARE
                   v_audit_key INTEGER := get_audit_key ( p_program_nm => 'PRIMARY_IND = Y To X', p_process_nm => 'GNRC_1786', p_table_nm => 'VISITOR_ADDRESS_XREF');

BEGIN
        update VISITOR_ADDRESS_XREF
            SET  SYNC_AUDIT_KEY = NULL, UPDATE_AUDIT_KEY = v_audit_key
        where VISITOR_KEY  =3058141 and PRIMARY_IND in ('Y','X');

        update CUSTOMER_DIM set SYNC_AUDIT_KEY = NULL, UPDATE_AUDIT_KEY = v_audit_key where CUSTOMER_KEY  =5609204;
        COMMIT;
end;

