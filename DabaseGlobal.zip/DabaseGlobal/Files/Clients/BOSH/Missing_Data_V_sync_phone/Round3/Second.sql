BOSH> DECLARE
             v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'SET PRIMARY_ADDRESS_KEY', p_table_nm => 'CUSTOMER_DIM');

      BEGIN


              MERGE INTO BOSH.CUSTOMER_DIM tgt USING
                  (
                      Select * from (
                               select DISTINCT cd.CUSTOMER_KEY,VX.VISITOR_KEY--,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
                                          ,VX.PRIMARY_IND,ATT2.CREATION_DT,AD2.ADDRESS_KEY,AD2.ADDRESS_LINE1_TX,VX.INSERT_AUDIT_KEY,VX.SYNC_AUDIT_KEY,VX.UPDATE_AUDIT_KEY,
                                          ROW_NUMBER() OVER(PARTITION BY cd.CUSTOMER_KEY,VX.VISITOR_KEY  ORDER BY ATT2.CREATION_DT desc) as rn
                                      from BOSH.CUSTOMER_DIM cd
                                           join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
                                           join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
                                           join BOSHSTG.boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = cd.PRIMARY_VISITOR_KEY
                                          JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
                                          join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
                                          JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
                                      where AD1.ADDRESS_LINE1_TX IS NULL AND ATT.CREATION_DT > date'2025-04-30'
                                          and cd.PRIMARY_ADDRESS_KEY <> vx.ADDRESS_KEY and vx.PRIMARY_IND = 'N'
                                          AND AD2.ADDRESS_LINE1_TX is not null
                      )
                      Where rn = 1

                      )src
              ON (tgt.CUSTOMER_KEY = src.CUSTOMER_KEY)
              WHEN MATCHED THEN
                  UPDATE SET tgt.PRIMARY_ADDRESS_KEY = ADDRESS_KEY , SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key
              ;

              DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
                    DBMS_OUTPUT.PUT_LINE(v_audit_key);

             COMMIT;

      END;
[2025-06-04 13:24:38] completed in 945 ms
515
969352
