BOSHSTG> DECLARE
                      v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'BOSH-1840', p_table_nm => 'CUSTOMER_DIM');

               BEGIN

                       merge into   BOSH.CUSTOMER_DIM tgt
                               using (

                                   select distinct CUSTOMER_KEY,ADDRESS_KEY from (
                                       select DISTINCT
                                               cd.CUSTOMER_KEY,
                                               T1.VISITOR_KEY,
                                               T1.ADDRESS_KEY,T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                                               --t1.PRIMARY_IND,t2.PRIMARY_IND,
                                               --t1.END_DT_KEY,t2.END_DT_KEY,
                                               T2.CREATION_DT,
                                               T2.INSERT_AUDIT_KEY,
                                               t1.SYNC_AUDIT_KEY,
                                               t1.UPDATE_AUDIT_KEY,
                                               t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY
                                               --,ATT.CREATION_DT
                                            from (
                                                        select * from BOSH.visitor_address_xref T0 where
                                                        VISITOR_KEY in
                                                        (
                                                            select vd2.VISITOR_KEY from BOSH.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                                select vd2.CUSTOMER_KEY
                                                                    --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                                   from BOSHSTG.boshstg_p_visitor_address_xref_bosh_1840_30th_april gvdx
                                                                         join BOSH.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                                   --       join BOSH.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                                         join BOSH.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                                         join BOSH.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                                   group by vd2.CUSTOMER_KEY
                                                                   --  having COUNT(cvdx.address_key) <= 2 --509
                                                                   having COUNT(cvdx.address_key) = 2 --57
                                                                   --order by DBMS_RANDOM.RANDOM()

               --
                                                        )
                                                       )
                                                ) T1
                                                join BOSHSTG.boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                                AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                                                join BOSH.CUSTOMER_DIM cd on cd.PRIMARY_ADDRESS_KEY = t2.ADDRESS_KEY and cd.PRIMARY_VISITOR_KEY = t2.VISITOR_KEY
                                                join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                            where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
               --                              AND CUSTOMER_KEY not in (1790432,
               --                                                         4269378,
               --                                                         2105602,
               --                                                         3067620,
               --                                                         2265018
               --                                                         )
                                            )

                           ) src  on  (tgt.CUSTOMER_KEY = src.CUSTOMER_KEY  )
                        WHEN MATCHED THEN
                               UPDATE SET
                                          tgt.PRIMARY_ADDRESS_KEY = src.ADDRESS_KEY,tgt.SYNC_AUDIT_KEY = NULL,tgt.UPDATE_AUDIT_KEY = v_audit_key
                       ;

                       DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
                       DBMS_OUTPUT.PUT_LINE(v_audit_key);

                      --COMMIT;

               END;
[2025-06-03 12:40:25] completed in 959 ms
121
969181
