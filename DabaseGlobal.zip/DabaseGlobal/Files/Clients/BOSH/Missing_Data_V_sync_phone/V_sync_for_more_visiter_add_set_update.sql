
select  COUNT(*) from boshstg_p_visitor_address_xref_bosh_1840_30th_april;--1646

select  COUNT(distinct VISITOR_KEY ) from boshstg_p_visitor_address_xref_bosh_1840_30th_april;--662

-- logic used for create temp table

CREATE TABLE boshstg_p_visitor_address_xref_bosh_1840_30th_april
  AS (
     select distinct pvdx.VISITOR_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,pvdx.END_DT_KEY,pvdx.EFF_DT_KEY,pvdx.INSERT_AUDIT_KEY,ATT3.CREATION_DT,pvdx.UPDATE_AUDIT_KEY,pvdx.SYNC_AUDIT_KEY
                   ,SD.SERIAL_NO
     from BOSH.DS_ACE_OUTPUT_TBL_ARCH DSACE
                        join BOSH.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                        join BOSH.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                        join BOSH.ADDRESS_DIM AD on AD.ADDRESS_KEY = AOT.ADDRESS_KEY
                        join BOSH.CUSTOMER_DIM CD  on CD.PRIMARY_ADDRESS_KEY = AD.ADDRESS_KEY
                        join BOSH.VISITOR_DIM VD on VD.CUSTOMER_KEY = CD.CUSTOMER_KEY
                        --join BOSH.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                        join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VD.VISITOR_KEY
                        join BOSH.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY AND VOX.PRIMARY_IND = 'Y'
                        join BOSH.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                        join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                        join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
                        join AUDIT_TBL ATT3 on pvdx.INSERT_AUDIT_KEY = ATT3.AUDIT_KEY
                    where --DSACE.PROCESS_DT = '20250520' AND
                          DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
                          AND pvdx.PRIMARY_IND = 'Y'
                          AND AD.ADDRESS_LINE1_TX IS NULL
                          AND ATT.CREATION_DT >= date '2025-04-30'
                          AND ATT2.CREATION_DT >= date '2025-04-30'
     )
;--

--*******************Here we already executed for exact 2 set values so 121 recrods cleared from this*************************--

-- Here set of 8 SQL which one by use for check data and also update records



-- sql 1 WHICH GET ALL DETAILS ALL VISITER AND ALL ADDRESS
select DISTINCT cd.CUSTOMER_KEY,VX.VISITOR_KEY,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
    ,VX.PRIMARY_IND,ATT2.CREATION_DT,AD2.ADDRESS_KEY,AD2.SOURCE_CD,AD2.ADDRESS_LINE1_TX,AD2.STATE_CD,AD2.CITY_NM,VX.INSERT_AUDIT_KEY,VX.SYNC_AUDIT_KEY,VX.UPDATE_AUDIT_KEY
from BOSH.CUSTOMER_DIM cd
     join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
     join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
     join boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = cd.PRIMARY_VISITOR_KEY
    JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
    join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
    JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
where AD1.ADDRESS_LINE1_TX IS NULL AND ATT.CREATION_DT > date'2025-04-30'
ORDER BY VX.VISITOR_KEY,ATT2.CREATION_DT
;--1478



-- sql 2 WHICH GET ALL   VISITER address and customer primary address key same and also primary ind = y
-- Here we mark Y to X
select DISTINCT cd.CUSTOMER_KEY,VX.VISITOR_KEY,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
    ,VX.PRIMARY_IND,ATT2.CREATION_DT,AD2.ADDRESS_KEY,AD2.ADDRESS_LINE1_TX,VX.INSERT_AUDIT_KEY,VX.SYNC_AUDIT_KEY,VX.UPDATE_AUDIT_KEY
from BOSH.CUSTOMER_DIM cd
     join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
     join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
     join boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = cd.PRIMARY_VISITOR_KEY
    JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
    join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
    JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
where AD1.ADDRESS_LINE1_TX IS NULL AND ATT.CREATION_DT > date'2025-04-30'
    and cd.PRIMARY_ADDRESS_KEY = vx.ADDRESS_KEY and vx.PRIMARY_IND = 'Y'
ORDER BY VX.VISITOR_KEY,ATT2.CREATION_DT
;--514

select * from BOSH.VISITOR_ADDRESS_XREF where (VISITOR_KEY,ADDRESS_KEY,PRIMARY_IND)
in ( select  VX.VISITOR_KEY,VX.ADDRESS_KEY,VX.PRIMARY_IND
from BOSH.CUSTOMER_DIM cd
     join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
     join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
     join BOSHSTG.boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = cd.PRIMARY_VISITOR_KEY
    JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
    join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
    JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
where AD1.ADDRESS_LINE1_TX IS NULL AND ATT.CREATION_DT > date'2025-04-30'
    and cd.PRIMARY_ADDRESS_KEY = vx.ADDRESS_KEY and vx.PRIMARY_IND = 'Y'
                                                      )

;





-- SQL 3 customer address is different that visiter primary address
        select DISTINCT cd.CUSTOMER_KEY,VX.VISITOR_KEY,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
            ,VX.PRIMARY_IND,ATT2.CREATION_DT,AD2.ADDRESS_KEY,AD2.ADDRESS_LINE1_TX,VX.INSERT_AUDIT_KEY,VX.SYNC_AUDIT_KEY,VX.UPDATE_AUDIT_KEY
        from BOSH.CUSTOMER_DIM cd
             join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
             join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
             join boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = cd.PRIMARY_VISITOR_KEY
            JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
            join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
            JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
        where AD1.ADDRESS_LINE1_TX IS NULL AND ATT.CREATION_DT > date'2025-04-30'
            and cd.PRIMARY_ADDRESS_KEY <> vx.ADDRESS_KEY and vx.PRIMARY_IND = 'Y'
        ORDER BY VX.VISITOR_KEY,ATT2.CREATION_DT
        ;--1
-- +------------+-----------+-------------------+--------------------------+----------------+-----------+--------------------------+-----------+----------------+----------------+--------------+----------------+
-- |CUSTOMER_KEY|VISITOR_KEY|PRIMARY_ADDRESS_KEY|CREATION_DT               |ADDRESS_LINE1_TX|PRIMARY_IND|CREATION_DT               |ADDRESS_KEY|ADDRESS_LINE1_TX|INSERT_AUDIT_KEY|SYNC_AUDIT_KEY|UPDATE_AUDIT_KEY|
-- +------------+-----------+-------------------+--------------------------+----------------+-----------+--------------------------+-----------+----------------+----------------+--------------+----------------+
-- |4505648     |2563226    |14514816           |2025-05-23 09:04:33.000000|NULL            |Y          |2025-05-15 02:32:14.000000|14516808   |1562 E 14TH ST  |959624          |959648        |NULL            |
-- +------------+-----------+-------------------+--------------------------+----------------+-----------+--------------------------+-----------+----------------+----------------+--------------+----------------+

--analytic_function([arguments]) OVER (PARTITION BY column_name ORDER BY column_name)


-- SQL 4 for get final visiter , customer and address key lastone with proper address line present
Select * from (
                 select DISTINCT cd.CUSTOMER_KEY,VX.VISITOR_KEY--,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
                            ,VX.PRIMARY_IND,ATT2.CREATION_DT,AD2.ADDRESS_KEY,AD2.ADDRESS_LINE1_TX,VX.INSERT_AUDIT_KEY,VX.SYNC_AUDIT_KEY,VX.UPDATE_AUDIT_KEY,
                            ROW_NUMBER() OVER(PARTITION BY cd.CUSTOMER_KEY,VX.VISITOR_KEY  ORDER BY ATT2.CREATION_DT desc) as rn
                        from BOSH.CUSTOMER_DIM cd
                             join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
                             join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
                             join boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = cd.PRIMARY_VISITOR_KEY
                            JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
                            join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
                            JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
                        where AD1.ADDRESS_LINE1_TX IS NULL AND ATT.CREATION_DT > date'2025-04-30'
                            and cd.PRIMARY_ADDRESS_KEY <> vx.ADDRESS_KEY and vx.PRIMARY_IND = 'N'
                            AND AD2.ADDRESS_LINE1_TX is not null
        )
        Where rn = 1
        ;--1

-- MERGE INTO target_table USING source_table
-- ON (condition)
-- WHEN MATCHED THEN
--     UPDATE SET column1 = value1, column2 = value2
-- WHEN NOT MATCHED THEN
--     INSERT (column1, column2) VALUES (value1, value2);


-- SQL 5 for update customer primary address key

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'SET PRIMARY_ADDRESS_KEY', p_table_nm => 'CUSTOMER_DIM');

BEGIN


        MERGE INTO BOSH.CUSTOMER_DIM tgt USING
            (
                Select * from (
                         select DISTINCT cd.CUSTOMER_KEY,VX.VISITOR_KEY--,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
                                    ,VX.PRIMARY_IND,ATT2.CREATION_DT,AD2.ADDRESS_KEY,AD2.ADDRESS_LINE1_TX,VX.INSERT_AUDIT_KEY,VX.SYNC_AUDIT_KEY,VX.UPDATE_AUDIT_KEY,
                                    ROW_NUMBER() OVER(PARTITION BY cd.CUSTOMER_KEY,VX.VISITOR_KEY  ORDER BY ATT2.CREATION_DT desc) as rn
                                from BOSH.CUSTOMER_DIM cd
                                     join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
                                     join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
                                     join boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = cd.PRIMARY_VISITOR_KEY
                                    JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
                                    join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
                                    JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
                                where AD1.ADDRESS_LINE1_TX IS NULL AND ATT.CREATION_DT > date'2025-04-30'
                                    and cd.PRIMARY_ADDRESS_KEY <> vx.ADDRESS_KEY and vx.PRIMARY_IND = 'N'
                                    AND AD2.ADDRESS_LINE1_TX is not null
                )
                Where rn = 1

                )src
        ON (tgt.CUSTOMER_KEY = src.CUSTOMER_KEY)
        WHEN MATCHED THEN
            UPDATE SET tgt.PRIMARY_ADDRESS_KEY = ADDRESS_KEY , SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key
        ;



       COMMIT;

END;


--SQL 6 check if inner sql is uniqe for CUSTOMER_KEY

select CUSTOMER_KEY,COUNT(*) from (
    Select * from (
                         select DISTINCT cd.CUSTOMER_KEY,VX.VISITOR_KEY--,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
                                    ,VX.PRIMARY_IND,ATT2.CREATION_DT,AD2.ADDRESS_KEY,AD2.ADDRESS_LINE1_TX,VX.INSERT_AUDIT_KEY,VX.SYNC_AUDIT_KEY,VX.UPDATE_AUDIT_KEY,
                                    ROW_NUMBER() OVER(PARTITION BY cd.CUSTOMER_KEY,VX.VISITOR_KEY  ORDER BY ATT2.CREATION_DT desc) as rn
                                from BOSH.CUSTOMER_DIM cd
                                     join BOSH.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
                                     join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
                                     join boshstg_p_visitor_address_xref_bosh_1840_30th_april T2 on T2.VISITOR_KEY = cd.PRIMARY_VISITOR_KEY
                                    JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
                                    join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
                                    JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
                                where AD1.ADDRESS_LINE1_TX IS NULL AND ATT.CREATION_DT > date'2025-04-30'
                                    and cd.PRIMARY_ADDRESS_KEY <> vx.ADDRESS_KEY and vx.PRIMARY_IND = 'N'
                                    AND AD2.ADDRESS_LINE1_TX is not null
                )
                Where rn = 1
              )t group by CUSTOMER_KEY
having COUNT(*) >1;--0




-- SQL 7 for update visiter address key

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'SET PRIMARY_ADDRESS_KEY', p_table_nm => 'CUSTOMER_DIM');

BEGIN


        MERGE INTO BOSH.VISITOR_ADDRESS_XREF tgt USING
            (
                Select * from (
                         select DISTINCT cd.CUSTOMER_KEY,
                                                                                    VX.VISITOR_KEY--,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
                                                                                    ,VAX.END_DT_KEY,VAX.EFF_DT_KEY,
                                                                                    VX.PRIMARY_IND,
                                                                                    ATT2.CREATION_DT,
                                                                                    AD2.ADDRESS_KEY,
                                                                                    AD2.ADDRESS_LINE1_TX,
                                                                                    VX.INSERT_AUDIT_KEY,
                                                                                    VX.SYNC_AUDIT_KEY,
                                                                                    VX.UPDATE_AUDIT_KEY,
                                                                                    ROW_NUMBER() OVER (PARTITION BY cd.CUSTOMER_KEY,VX.VISITOR_KEY ORDER BY ATT2.CREATION_DT desc) as rn
                                                                    from BOSH.VISITOR_ADDRESS_XREF VAX
                                                                             join BOSH.ADDRESS_DIM AD1
                                                                                  on AD1.ADDRESS_KEY = VAX.ADDRESS_KEY AND VAX.PRIMARY_IND = 'X'
                                                                             join BOSH.VISITOR_DIM vd
                                                                                  on vd.VISITOR_KEY = VAX.VISITOR_KEY AND VAX.PRIMARY_IND = 'X'
                                                                             join BOSH.CUSTOMER_DIM cd
                                                                                  on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY AND VAX.PRIMARY_IND = 'X'
                                                                             join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
                                                                             join BOSHSTG.boshstg_p_visitor_address_xref_bosh_1840_30th_april T2
                                                                                  on T2.VISITOR_KEY = VAX.VISITOR_KEY
                                                                             JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
                                                                             join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
                                                                             JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
                                                                    where AD1.ADDRESS_LINE1_TX IS NULL
                                                                      AND ATT.CREATION_DT > date'2025-04-30'
                                                                      and VAX.ADDRESS_KEY <> vx.ADDRESS_KEY
                                                                      and vx.PRIMARY_IND = 'N'
                                                                      AND AD2.ADDRESS_LINE1_TX is not null
                )
                Where rn = 1

                )src
        ON (tgt.VISITOR_KEY = src.VISITOR_KEY AND tgt.ADDRESS_KEY = src.ADDRESS_KEY)
        WHEN MATCHED THEN
            UPDATE SET tgt.ADDRESS_KEY_TEMP = src.ADDRESS_KEY,tgt.PRIMARY_IND = 'Y',tgt.END_DT_KEY = src.END_DT_KEY, SYNC_AUDIT_KEY =null,UPDATE_AUDIT_KEY = v_audit_key
        ;



       COMMIT;

END;


--SQL 8 check if inner sql is uniue for set VISITOR_KEY,ADDRESS_KEY

select VISITOR_KEY,ADDRESS_KEY,COUNT(*) from (
    Select * from (
                         select DISTINCT cd.CUSTOMER_KEY,
                                                                                    VX.VISITOR_KEY--,cd.PRIMARY_ADDRESS_KEY,att.CREATION_DT,ad1.ADDRESS_LINE1_TX
                                                                            ,
                                                                                    VX.PRIMARY_IND,
                                                                                    ATT2.CREATION_DT,
                                                                                    AD2.ADDRESS_KEY,
                                                                                    AD2.ADDRESS_LINE1_TX,
                                                                                    VX.INSERT_AUDIT_KEY,
                                                                                    VX.SYNC_AUDIT_KEY,
                                                                                    VX.UPDATE_AUDIT_KEY,
                                                                                    ROW_NUMBER() OVER (PARTITION BY cd.CUSTOMER_KEY,VX.VISITOR_KEY ORDER BY ATT2.CREATION_DT desc) as rn
                                                                    from BOSH.VISITOR_ADDRESS_XREF VAX
                                                                             join BOSH.ADDRESS_DIM AD1
                                                                                  on AD1.ADDRESS_KEY = VAX.ADDRESS_KEY AND VAX.PRIMARY_IND = 'X'
                                                                             join BOSH.VISITOR_DIM vd
                                                                                  on vd.VISITOR_KEY = VAX.VISITOR_KEY AND VAX.PRIMARY_IND = 'X'
                                                                             join BOSH.CUSTOMER_DIM cd
                                                                                  on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY AND VAX.PRIMARY_IND = 'X'
                                                                             join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
                                                                             join BOSHSTG.boshstg_p_visitor_address_xref_bosh_1840_30th_april T2
                                                                                  on T2.VISITOR_KEY = VAX.VISITOR_KEY
                                                                             JOIN bosh.VISITOR_ADDRESS_XREF vx ON VX.VISITOR_KEY = T2.VISITOR_KEY
                                                                             join AUDIT_TBL ATT2 on ATT2.AUDIT_KEY = vx.INSERT_AUDIT_KEY
                                                                             JOIN bosh.ADDRESS_DIM ad2 ON ad2.ADDRESS_KEY = VX.ADDRESS_KEY
                                                                    where AD1.ADDRESS_LINE1_TX IS NULL
                                                                      AND ATT.CREATION_DT > date'2025-04-30'
                                                                      and VAX.ADDRESS_KEY <> vx.ADDRESS_KEY
                                                                      and vx.PRIMARY_IND = 'N'
                                                                      AND AD2.ADDRESS_LINE1_TX is not null
                )
                Where rn = 1
              )t group by VISITOR_KEY,ADDRESS_KEY
having COUNT(*) >1;--0