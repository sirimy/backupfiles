 SELECT   T1.Contract_No,CANCEL_DT ,CANCEL_EFFECTIVE_DT,FULL_OR_PRO_RATED_REFUND,days_used
          FROM (
                select cc.CONTRACT_KEY,
                       clkp.Contract_XID AS Contract_No,
                       cc.CANCEL_BY,
                       cc.CANCEL_DT,
                       cc.CANCEL_EFFECTIVE_DT,
                       cc.CONTRACT_REFUND_AMT,
                       cc.TAX_REFUND_AMT,
                       si.SERIAL_NO, oit.PURCHASE_DT, oit.ORDER_KEY, trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) as days_used
                       ,ccci.FULL_OR_PRO_RATED_REFUND
                from gnrc.CONTRACT_CANCELLATION_DIM cc
                     join gnrc.CONTRACT_ORDER_TBL cot on cot.CONTRACT_KEY = cc.CONTRACT_KEY
                     LEFT JOIN
                          gnrc.contract_lkp clkp
                             ON (    clkp.contract_key = cot.contract_key
                                 AND clkp.source_system_cd = 0)
                     join gnrc.ORDER_ITEM_TBL oit on oit.ORDER_KEY = cot.ORDER_KEY and oit.ORDER_LINE_KEY = cot.ORDER_LINE_KEY
                     join gnrc.SERIALIZED_ITEM_DIM si on si.SI_KEY = oit.SERIALIZED_ITEM_KEY
                     left join gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ccci on ccci.CONTRACT_KEY = cc.CONTRACT_KEY
                where CANCEL_DT >= date '2024-05-01'   --cut off date
                  and CANCEL_DT <= last_day(current_date)   --up to the last day of the invoice month
                  --and extract(day from last_day(current_date)) - extract(day from current_date) <= 5 --check within the last 5 days of the month
                  and trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) > 30  --pro-rata cancellation rule will apply
                  --and ccci.CONTRACT_KEY is null

                order by CANCEL_DT, si.SERIAL_NO
              )T1 where t1.Contract_No in (
'41003070',
'41158164',
'40971184',
'40998968',
'40971351',
'40796240',
'40707969',
'40794117',
'40797832',
'41004863',
'41204759',
'40623523',
'41160601',
'41160495',
'40971554',
'41199250',
'41004932',
'40790098',
'41160620',
'41205328',
'41155656',
'41199462',
'40798341',
'41158429',
'41159791',
'41149968',
'41161350',
'41199682',
'41150459',
'40708133',
'40868644',
'41054471',
'41004332',
'41208360',
'41205458',
'41150526',
'41208255',
'41162734',
'41162135',
'41163182',
'41163178',
'41150086',
'40708434',
'41208665',
'41208525',
'41162537',
'41200180',
'41164213',
'41206383',
'41151741',
'41208799',
'41208999',
'41206556',
'41151689',
'40955316',
'41290298',
'41014667'
     );

select * from GNRC.V_TAX_REPORT where CONTRACT_NO in
                                      (
                                          SELECT   T1.Contract_No
          FROM (
                select cc.CONTRACT_KEY,
                       clkp.Contract_XID AS Contract_No,
                       cc.CANCEL_BY,
                       cc.CANCEL_DT,
                       cc.CANCEL_EFFECTIVE_DT,
                       cc.CONTRACT_REFUND_AMT,
                       cc.TAX_REFUND_AMT,
                       si.SERIAL_NO, oit.PURCHASE_DT, oit.ORDER_KEY, trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) as days_used
                       ,ccci.FULL_OR_PRO_RATED_REFUND
                from gnrc.CONTRACT_CANCELLATION_DIM cc
                     join gnrc.CONTRACT_ORDER_TBL cot on cot.CONTRACT_KEY = cc.CONTRACT_KEY
                     LEFT JOIN
                          gnrc.contract_lkp clkp
                             ON (    clkp.contract_key = cot.contract_key
                                 AND clkp.source_system_cd = 0)
                     join gnrc.ORDER_ITEM_TBL oit on oit.ORDER_KEY = cot.ORDER_KEY and oit.ORDER_LINE_KEY = cot.ORDER_LINE_KEY
                     join gnrc.SERIALIZED_ITEM_DIM si on si.SI_KEY = oit.SERIALIZED_ITEM_KEY
                     left join gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ccci on ccci.CONTRACT_KEY = cc.CONTRACT_KEY
                where CANCEL_DT >= date '2024-05-01'   --cut off date
                  and CANCEL_DT <= last_day(current_date)   --up to the last day of the invoice month
                  --and extract(day from last_day(current_date)) - extract(day from current_date) <= 5 --check within the last 5 days of the month
                  and trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) > 30  --pro-rata cancellation rule will apply
                   and ccci.CONTRACT_KEY is null
                order by CANCEL_DT, si.SERIAL_NO
              )T1
                                          );

select CONTRACT_STATUS,COUNT(*)
from GNRC.V_TAX_REPORT
Where CONTRACT_DATE > SYSDATE - 365
group by CONTRACT_STATUS;

 -- with no filter present
-- +---------------+--------+
-- |CONTRACT_STATUS|COUNT(*)|
-- +---------------+--------+
-- |Cancelled      |489     |
-- |Sold           |24483   |
-- +---------------+--------+
-- +---------------+--------+
-- |CONTRACT_STATUS|COUNT(*)|
-- +---------------+--------+
-- |Cancelled      |423     |
-- |Sold           |24483   |
-- +---------------+--------+

select *
from GNRC.V_TAX_REPORT
Where CONTRACT_DATE > SYSDATE - 365 and CONTRACT_STATUS = 'Cancelled'
and CONTRACT_NO not in (
41205805,
41152080,
40783451,
40799104,
41289493,
41151579,
41152653,
41207393,
41291140
    )
;
--


