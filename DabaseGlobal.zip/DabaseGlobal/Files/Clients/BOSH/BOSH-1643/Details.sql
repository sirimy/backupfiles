 select LCD.DESCRIPTION,LCD.COVERAGE_TYPE_KEY,COUNT(*)
        from (
              select distinct cc.contract_key, cc.contract_status_key, si.si_key, si.latest_coverage_type
                from p_contract_dim cc
                    join p_contract_coverage_xref ccx
                      ON (cc.contract_key = ccx.contract_key)
                    join p_serialized_item_dim si
                      ON (si.si_key = ccx.si_key)
               where
                     (cc.contract_status_key = 1 and si.latest_coverage_type not in (2, 9, 22))
             ) RS join BOSH.LATEST_COVERAGE_TYPE_DIM LCD on RS.LATEST_COVERAGE_TYPE = LCD.COVERAGE_TYPE_KEY
GROUP BY LCD.DESCRIPTION,LCD.COVERAGE_TYPE_KEY
;
-- +-------------------------------+-----------------+--------+
-- |DESCRIPTION                    |COVERAGE_TYPE_KEY|COUNT(*)|
-- +-------------------------------+-----------------+--------+
-- |Gaggenau Ambassador Suppression|21               |9       |
-- |Cancelled WARRANTY             |3                |1       |
-- +-------------------------------+-----------------+--------+

select * from BOSH.CONTRACT_DIM where CONTRACT_KEY in(180169,180410);
select * from BOSH.CONTRACT_ORDER_TBL where ORDER_KEY in(390825,390567);
-- +------------+---------+--------------+
-- |CONTRACT_KEY|ORDER_KEY|ORDER_LINE_KEY|
-- +------------+---------+--------------+
-- |180169      |390567   |1             |
-- |180410      |390825   |1             |
-- +------------+---------+--------------+
select * from RAW_CONTRACT_CANCELS_TBL where UNIQUE_IDENTIFIER in ('390567-1');
select ATT.CREATION_DT,OIT.* from BOSH.ORDER_ITEM_TBL OIT join AUDIT_TBL ATT on OIT.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
         where ORDER_KEY in(390825,390567);
-- +--------------------------+---------+--------------+-------------+--------------+-------------------+
-- |CREATION_DT               |ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY    |OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|
-- +--------------------------+---------+--------------+-------------+--------------+-------------------+
-- |2024-02-24 02:32:37.000000|390567   |1             |7634550072002|1             |2916236            |
-- |2024-02-27 02:32:26.000000|390825   |1             |43974        |1             |2916236            |
-- +--------------------------+---------+--------------+-------------+--------------+-------------------+
select * from BOSH.CONTRACT_CANCELLATION_DIM where CONTRACT_KEY in(180410,180169);
-- +------------+----------------------+--------------------------+--------------------------+
-- |CONTRACT_KEY|CANCEL_BY             |CANCEL_DT                 |CANCEL_EFFECTIVE_DT       |
-- +------------+----------------------+--------------------------+--------------------------+
-- |180169      |lmartinez@afterinc.com|2024-03-06 00:00:00.597000|2024-02-26 00:00:00.000000|
-- +------------+----------------------+--------------------------+--------------------------+
select * from RAW_CONTRACT_CANCELS_TBL where UNIQUE_IDENTIFIER in ('390567-1');
-- +-----------------------------------------------------------------------+-----------------+--------------+
-- |ERROR_MESSAGE                                                          |UNIQUE_IDENTIFIER|P2_CONTRACT_NO|
-- +-----------------------------------------------------------------------+-----------------+--------------+
-- |This contract is not in an Active status and hence cannot be cancelled.|390567-1         |BSH-390567-1  |
-- +-----------------------------------------------------------------------+-----------------+--------------+
select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY = 2916236;
-- +-------+-----------+--------------------+-----------+----------+
-- |SI_KEY |PRODUCT_KEY|LATEST_COVERAGE_TYPE|SERIAL_NO  |MODEL_NO  |
-- +-------+-----------+--------------------+-----------+----------+
-- |2916236|31568      |3                   |0107-004664|B36CL80ENS|
-- +-------+-----------+--------------------+-----------+----------+
select * from BOSH.LATEST_COVERAGE_TYPE_DIM where COVERAGE_TYPE_KEY = 3;
-- +-----------------+------------------+
-- |COVERAGE_TYPE_KEY|NAME              |
-- +-----------------+------------------+
-- |3                |Cancelled WARRANTY|
-- +-----------------+------------------+
select * from BOSH.CONTRACT_STATUS_DIM where CONTRACT_STATUS_KEY = 5;
-- +-------------------+----+-----------+
-- |CONTRACT_STATUS_KEY|NAME|DESCRIPTION|
-- +-------------------+----+-----------+
-- |5                  |EXP |Expired    |
-- +-------------------+----+-----------+
select * from BOSH.CONTRACT_DIM where CONTRACT_KEY in(180410,180169);
-- +------------+-------------------+----------------+
-- |CONTRACT_KEY|CONTRACT_STATUS_KEY|CONTRACT_SALE_DT|
-- +------------+-------------------+----------------+
-- |180169      |5                  |2024-02-10      |
-- |180410      |1                  |2024-02-26      |
-- +------------+-------------------+----------------+
select * from P_CONTRACT_COVERAGE_XREF where SI_KEY in (2916236);
-- +------------+-----------------+---------------------+-------+--------------------------+
-- |CONTRACT_KEY|COVERAGE_TYPE_KEY|COVERED_COMPONENT_KEY|SI_KEY |COVERAGE_START_DT         |
-- +------------+-----------------+---------------------+-------+--------------------------+
-- |180169      |2                |1                    |2916236|2024-02-10 00:00:00.000000|
-- |180169      |3                |1                    |2916236|2024-02-10 00:00:00.000000|
-- |180410      |2                |1                    |2916236|2023-05-04 00:00:00.000000|
-- |180410      |3                |1                    |2916236|2023-05-04 00:00:00.000000|
-- +------------+-----------------+---------------------+-------+--------------------------+

