    SELECT * FROM bosh.PRICING_SCHEME_DIM where INSERT_AUDIT_KEY = 584854;--Rows count 6
    SELECT COUNT(*) FROM bosh.policy_tbl where POLICY_KEY in ( select POLICY_KEY from BOSHSTG.RAW_PRICING_TBL);--Rows count 768
    SELECT COUNT(*)  FROM bosh.policy_lkp where POLICY_KEY in ( select POLICY_KEY from BOSHSTG.RAW_PRICING_TBL);--Rows count 1536
    SELECT COUNT(*)  FROM bosh.policy_ext_tbl where POLICY_KEY in ( select POLICY_KEY from BOSHSTG.RAW_PRICING_TBL) ;--Rows count 768
    SELECT COUNT(*) FROM bosh.policy_fee_xref PFX where POLICY_KEY in ( select POLICY_KEY from BOSHSTG.RAW_PRICING_TBL) order by POLICY_KEY,POLICY_FEE_VALUE ;--Rows count 1536
    SELECT COUNT(*) FROM bosh.policy_item_tbl where INSERT_AUDIT_KEY =583017   ;--Rows count 768
    SELECT COUNT(*) FROM bosh.POLICY_COVERAGE_TBL where POLICY_KEY in ( select POLICY_KEY from BOSHSTG.RAW_PRICING_TBL);--Rows count 1536
    SELECT COUNT(*) FROM bosh.t_and_c_contract_template_xref where POLICY_KEY in ( select POLICY_KEY from BOSHSTG.RAW_PRICING_TBL);--Rows count 39168
    SELECT COUNT(*) FROM bosh.product_price_dim where POLICY_KEY in ( select POLICY_KEY from BOSHSTG.RAW_PRICING_TBL);--Rows count 9544
    SELECT * FROM bosh.PRICING_SCHEME_DIM where INSERT_AUDIT_KEY = 584854 order by  PRICING_SCHEME_KEY desc ;--Rows count 768