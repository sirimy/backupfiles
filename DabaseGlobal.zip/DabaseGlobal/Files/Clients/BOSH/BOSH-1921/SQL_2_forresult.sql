 select sil.*, t1.*
        from (
              SELECT serialized_item_key, count(*), count(distinct oit.order_key)
                FROM p_order_tbl o
                     JOIN p_order_item_tbl oit on (oit.order_key = o.order_key)
                     left join p_contract_order_tbl co on (co.order_key = oit.order_key and co.order_line_key = oit.order_line_key)
                     left join p_contract_dim con on (con.contract_key = co.contract_key)
                     left join p_contract_status_dim cons on (cons.contract_status_key = con.contract_status_key)
                     left join p_policy_ext_tbl pex ON (pex.policy_key = oit.policy_key)
               WHERE oit.price_amt > 1
                AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                AND ( con.contract_status_key IS NULL OR con.contract_status_key NOT IN (2, 3, 4, 5) )
                AND exists (
                        select oit3.serialized_item_key
                        from   P_ORDER_ITEM_TBL oit3
                                join p_contract_order_tbl co3 on (co3.order_key = oit3.order_key and co3.order_line_key = oit3.order_line_key)
                                join p_contract_dim con3 on (con3.contract_key = co3.contract_key)
                                left join p_contract_status_dim cons3 on (cons3.contract_status_key = con3.contract_status_key)
                                join p_policy_ext_tbl pex3 ON (pex3.policy_key = oit3.policy_key)
                                join p_order_tbl o3 on oit3.ORDER_KEY = o3.ORDER_KEY
                        where 1 = 1
                        and oit3.serialized_item_key  = oit.serialized_item_key
                        and oit3.order_key <> oit.order_key
                        and con3.contract_key <> con.contract_key
                        and
                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                             or
                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                            )
                        and oit3.price_amt > 1
                        AND o3.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                        AND ( con3.contract_status_key IS NULL OR con3.contract_status_key NOT IN (2, 3, 4, 5) )  --canceled/fulfilled/expired
                        and pex3.channels = pex.channels
                        --and con3.contract_end_dt >= trunc(sysdate) - 60
                        and con3.contract_end_dt >= trunc(sysdate) - 30
                       )
               GROUP BY serialized_item_key
              HAVING COUNT(*) >= 2
             )t1 join bosh.SERIALIZED_ITEM_LKP sil on t1.SERIALIZED_ITEM_KEY = sil.SI_KEY and SOURCE_SYSTEM_CD =2 ;


 SELECT serialized_item_key,oit.order_key,co.CONTRACT_KEY,pex.CHANNELS,con.contract_status_key
                FROM p_order_tbl o
                     JOIN p_order_item_tbl oit on (oit.order_key = o.order_key)
                     left join p_contract_order_tbl co on (co.order_key = oit.order_key and co.order_line_key = oit.order_line_key)
                     left join p_contract_dim con on (con.contract_key = co.contract_key)
                     left join p_contract_status_dim cons on (cons.contract_status_key = con.contract_status_key)
                     left join p_policy_ext_tbl pex ON (pex.policy_key = oit.policy_key)
               WHERE oit.price_amt > 1
                AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                AND ( con.contract_status_key IS NULL OR con.contract_status_key NOT IN (2, 3, 4, 5) )
                AND oit.SERIALIZED_ITEM_KEY =1425172;
-- +-------------------+---------+------------+--------+-------------------+
-- |SERIALIZED_ITEM_KEY|ORDER_KEY|CONTRACT_KEY|CHANNELS|CONTRACT_STATUS_KEY|
-- +-------------------+---------+------------+--------+-------------------+
-- |1425172            |387991   |179061      |Renewal |1                  |
-- |1425172            |445395   |206102      |Renewal |1                  |
-- +-------------------+---------+------------+--------+-------------------+


--and oit.ORDER_KEY in(445395,387991);
;

-- +-------+---------+----------------+
-- |SI_KEY |SI_XID   |SOURCE_SYSTEM_CD|
-- +-------+---------+----------------+
-- |1205404|5635060  |2               |
-- |1425172|7724958  |2               |
-- |1452477|7919260  |2               |
-- |1458570|7974474  |2               |
-- |1541283|8605354  |2               |
-- |1860398|9822480  |2               |
-- |1467464|8047534  |2               |
-- |1482835|8145716  |2               |
-- |1483589|8157204  |2               |
-- |1485651|8199016  |2               |
-- |1495548|8270250  |2               |
-- |1505258|8402742  |2               |
-- |1564484|8732818  |2               |
-- |1571729|8843894  |2               |
-- |1588011|8933162  |2               |
-- |1589443|8932710  |2               |
-- |1603410|44889345 |2               |
-- |1603504|9024294  |2               |
-- |1860300|9827340  |2               |
-- |3126472|18419082 |2               |
-- |3652468|21548514 |2               |
-- |4345206|209369779|2               |
-- |4345208|209369791|2               |
-- |2211409|11640252 |2               |
-- |2110809|11121680 |2               |
-- |2165802|11452016 |2               |
-- |2165948|11447230 |2               |
-- |3669993|21708636 |2               |
-- |4462147|215897501|2               |
-- |2918692|16831650 |2               |
-- |2924845|16901438 |2               |
-- +-------+---------+----------------+
-- +-------------------+--------+----------------------------+
-- |SERIALIZED_ITEM_KEY|COUNT(*)|COUNT(DISTINCTOIT.ORDER_KEY)|
-- +-------------------+--------+----------------------------+
-- |1205404            |2       |2                           |
-- |1425172            |2       |2                           |
-- |1443778            |2       |2                           |
-- |1452477            |2       |2                           |
-- |1458570            |3       |3                           |
-- |1459199            |2       |2                           |
-- |1467464            |2       |2                           |
-- |1482835            |2       |2                           |
-- |1483589            |2       |2                           |
-- |1485651            |2       |2                           |
-- |1495548            |2       |2                           |
-- |1505258            |2       |2                           |
-- |1541283            |2       |2                           |
-- |1564484            |2       |2                           |
-- |1571729            |2       |2                           |
-- |1588011            |2       |2                           |
-- |1589443            |2       |2                           |
-- |1603410            |2       |2                           |
-- |1603504            |2       |2                           |
-- |1860300            |2       |2                           |
-- |1860398            |2       |2                           |
-- |2110809            |2       |2                           |
-- |2165802            |2       |2                           |
-- |2165948            |2       |2                           |
-- |2211409            |2       |2                           |
-- |2918692            |2       |2                           |
-- |2924845            |2       |2                           |
-- |3126472            |2       |2                           |
-- |3652468            |2       |2                           |
-- |3669993            |2       |2                           |
-- |4345206            |2       |2                           |
-- |4345208            |2       |2                           |
-- |4462147            |2       |2                           |
-- +-------------------+--------+----------------------------+

select lkp.SI_XID,lkp.SOURCE_SYSTEM_CD,T1.SERIALIZED_ITEM_KEY,T1.ORDER_KEY,ot.SALES_SOURCE_CD,T2.ORDER_KEY,ot1.SALES_SOURCE_CD,T1.CREATION_DT,T2.CREATION_DT
     ,t1.contract_end_dt,T2.contract_start_dt,cd.CONTRACT_STATUS_KEY,cd1.CONTRACT_STATUS_KEY
        ,T2.contract_start_dt-T1.contract_end_dt over_lap_diff,t1.DESCRIPTION,t2.DESCRIPTION
from si_key_appearing_against_multiple_active_contracts_bosh_1921 T1
    JOIN ( select * from si_key_appearing_against_multiple_active_contracts_bosh_1921 where row_no > 1 )T2
        ON T1.SERIALIZED_ITEM_KEY = T2.SERIALIZED_ITEM_KEY and T1.row_no = T2.row_no - 1
    join bosh.CONTRACT_DIM cd on cd.CONTRACT_KEY = t1.CONTRACT_KEY
    join bosh.CONTRACT_DIM cd1 on cd1.CONTRACT_KEY = t2.CONTRACT_KEY
    join bosh.ORDER_TBL ot on ot.ORDER_KEY = t1.ORDER_KEY
    join bosh.ORDER_TBL ot1 on ot1.ORDER_KEY = t2.ORDER_KEY
    join bosh.SERIALIZED_ITEM_LKP lkp on lkp.SI_KEY = T1.SERIALIZED_ITEM_KEY and SOURCE_SYSTEM_CD =2
where --t1.SERIALIZED_ITEM_KEY = 1483589
--T2.contract_start_dt-T1.contract_end_dt = -1-- 19 cases
--T2.contract_start_dt-T1.contract_end_dt = 1-- 35 cases
T2.contract_start_dt-T1.contract_end_dt not in (1,-1,0)--37
and T1.contract_end_dt > sysdate--35
  and t1.ORDER_KEY <> t2.ORDER_KEY
and cd.CONTRACT_STATUS_KEY = 1
and cd1.CONTRACT_STATUS_KEY = 1
and ot.SALES_SOURCE_CD not in ('OUTLET_SALES')
and ot1.SALES_SOURCE_CD not in ('OUTLET_SALES')
ORDER BY T2.CREATION_DT desc
;

select * from bosh.SERIALIZED_ITEM_LKP
-- +------------------+-----+-----+
-- |serialized_item_id|count|count|
-- +------------------+-----+-----+
-- |5635060           |2    |2    |
-- |9822480           |2    |2    |
-- |9827340           |2    |2    |
-- |18419082          |2    |2    |
-- |21548514          |2    |2    |
-- |21708636          |2    |2    |
-- |209369779         |2    |2    |
-- |209369791         |2    |2    |
-- |215897501         |2    |2    |
-- +------------------+-----+-----+
-- +---------+----------------+
-- |SI_XID   |SOURCE_SYSTEM_CD|
-- +---------+----------------+
-- |9822480  |2               |
-- |8605354  |2               |
-- |7974474  |2               |
-- |5635060  |2               |
-- |21548514 |2               |
-- |209369791|2               |
-- |209369779|2               |
-- |18419082 |2               |
-- +---------+----------------+