select *
  from (
	select oit.serialized_item_id, si.serial_num, si.purchase_dt::date as si_purchase_dt, pr.model_no, ot.created_by, ot.purchase_dt::date as order_purchase_dt,
	       contract_start_dt, contract_end_dt,
	       sales_source_cd, channels as Plan, oit.order_id, oit.order_line_id, pol.sku, tr.name as term, co.contract_id, cons.name as status
	       , oit.offer_id, oft.active_ind as Offer_active_ind, oit.price_amt, oit.tax_amt, flexpay_ind, tx.payment_type
	       , cust.first_nm, cust.last_nm, cust.firm_nm, address_line1_tx, locality_nm, s.code as State_code  --postal_code1_tx, postal_code2_tx,
	from order_tbl ot
		join ORDER_ITEM_TBL oit ON ( ot.order_id = oit.order_id )
		join serialized_item si on (si.serialized_item_id = oit.serialized_item_id)
		left join product pr on (pr.product_id = si.product_id)
		LEFT join customer_tbl cust using (customer_id) join address_tbl adr on (address_id = primary_address_id) join state s on (adr.state_id = s.state_id)
		left join (
			select *
			from (
			      select tx.order_id, tx.payment_type, row_number() over (partition by tx.order_id order by tx.created_ts) as rno
			       from payment_tx_tbl tx
			     ) tx
			where rno = 1
			) tx on tx.order_id  = ot.order_id
		left join offer_tbl oft on (oft.offer_id = oit.offer_id)
		left join contract_order co on (co.order_id = oit.order_id and co.order_line_id = oit.order_line_id)
		left join contract con on (con.contract_id = co.contract_id)
		left join contract_status cons on (cons.contract_status_id = con.contract_status_id)
		left join policy pol on pol.policy_id = oit.policy_id
		left join policy_ext pex ON (pex.policy_id = pol.policy_id)
		left join term tr on tr.term_id = pol.term_id
	where 1 = 1
	 and oit.price_amt > 1
         and ot.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
	 AND ( con.contract_status_id IS NULL OR con.contract_status_id NOT IN (2, 3, 4, 5) )  --cancelled/fulfilled/expired
	 AND exists (
		select oit3.serialized_item_id
		from    order_tbl ot3
                        join ORDER_ITEM_TBL oit3 ON ( ot3.order_id = oit3.order_id )
			left join contract_order co3 on (co3.order_id = oit3.order_id and co3.order_line_id = oit3.order_line_id)
			left join contract con3 on (con3.contract_id = co3.contract_id)
			left join contract_status cons3 on (cons3.contract_status_id = con3.contract_status_id)
			left join policy_ext pex3 ON (pex3.policy_id = oit3.policy_id)
		where 1 = 1
                and ot3.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
		and oit3.serialized_item_id  = oit.serialized_item_id
		and oit3.order_id <> oit.order_id
		and con3.contract_id <> con.contract_id
		and
                    (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
		     or
		     con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
		     or
		     con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
		     or
		     con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
		    )
		and oit3.price_amt > 1
		AND ( con3.contract_status_id IS NULL OR con3.contract_status_id NOT IN (2, 3, 4, 5) )  --cancelled/fulfilled/expired
		and pex3.channels = pex.channels
                and con3.contract_end_dt >= CURRENT_DATE - 30
	       )
	order by oit.purchase_dt desc ,  oit.order_id , oit.serialized_item_id
       ) O
;

-- +------------------+-----------+--------------+----------+--------------------------------------+-----------------+--------------------------+--------------------------+-------------------------+---------------+--------+-------------+-----------+-------+-----------+------+--------------+----------------+---------+-------+-----------+------------+--------+-------+-------+-----------------+-------------+----------+
-- |serialized_item_id|serial_num |si_purchase_dt|model_no  |created_by                            |order_purchase_dt|contract_start_dt         |contract_end_dt           |sales_source_cd          |plan           |order_id|order_line_id|sku        |term   |contract_id|status|offer_id      |offer_active_ind|price_amt|tax_amt|flexpay_ind|payment_type|first_nm|last_nm|firm_nm|address_line1_tx |locality_nm  |state_code|
-- +------------------+-----------+--------------+----------+--------------------------------------+-----------------+--------------------------+--------------------------+-------------------------+---------------+--------+-------------+-----------+-------+-----------+------+--------------+----------------+---------+-------+-----------+------------+--------+-------+-------+-----------------+-------------+----------+
-- |5635060           |NULL       |2018-10-05    |SHP865WF5N|jtassitano@afterinc.com               |2025-08-18       |2026-01-25 00:00:00.000000|2027-01-25 00:00:00.000000|MAIL_IN_CHECK_SALES      |Renewal program|476083  |1            |BSDHC12UR8 |1 Year |27645158   |ACTV  |11591063004926|N               |115.00   |0.00   |N          |CHECK_BYPASS|CANDACE |CANNATA|NULL   |199 HOME PLACE DR|BLAIRSVILLE  |GA        |
-- |5635060           |NULL       |2018-10-05    |SHP865WF5N|jahbisha.hixson@domesticandgeneral.com|2025-07-05       |2026-01-25 00:00:00.000000|2028-01-25 00:00:00.000000|MAIL_IN_CHECK_SALES      |Renewal program|469577  |1            |BSDHC24UR8 |2 Years|27142820   |ACTV  |11591063004870|N               |210.00   |0.00   |N          |CHECK_BYPASS|CANDACE |CANNATA|NULL   |199 HOME PLACE DR|BLAIRSVILLE  |GA        |
-- |9822480           |9907-000161|2019-10-01    |SHP865ZD5N|jtassitano@afterinc.com               |2025-08-19       |2026-01-19 00:00:00.000000|2027-01-19 00:00:00.000000|MAIL_IN_CHECK_SALES      |Renewal program|476049  |1            |BSDHD12UR7 |1 Year |27645364   |ACTV  |11534032004921|N               |150.00   |0.00   |N          |CHECK_BYPASS|SUSAN   |BEDELL |NULL   |2714 MADONNA DR  |FULLERTON    |CA        |
-- |9822480           |9907-000161|2019-10-01    |SHP865ZD5N|jahbisha.hixson@domesticandgeneral.com|2025-06-30       |2026-01-19 00:00:00.000000|2027-01-19 00:00:00.000000|MAIL_IN_CHECK_SALES      |Renewal program|468543  |1            |BSDHD12UR7 |1 Year |26957524   |ACTV  |11534032004875|N               |150.00   |0.00   |N          |CHECK_BYPASS|SUSAN   |BEDELL |NULL   |2714 MADONNA DR  |FULLERTON    |CA        |
-- |9827340           |9909-004383|2020-01-01    |SHXM4AY55N|bgeorge@afterinc.com                  |2025-09-16       |2026-01-03 00:00:00.000000|2027-01-03 00:00:00.000000|MAIL_IN_CHECK_SALES      |RENEWAL PROGRAM|479151  |1            |BSDHB12UR6 |1 Year |27815188   |ACTV  |11475489004976|N               |75.00    |2.25   |N          |CHECK_BYPASS|JOSE    |REXACH |NULL   |9 S LAKE CIR     |HAMPTON      |VA        |
-- |9827340           |9909-004383|2020-01-01    |SHXM4AY55N|godoi@afterinc.com                    |2024-06-25       |2025-01-02 00:00:00.000000|2027-01-02 00:00:00.000000|MAIL_IN_CHECK_SALES      |RENEWAL PROGRAM|409013  |1            |BSDHB24UR5 |2 Years|23280494   |ACTV  |9765378004873 |N               |137.00   |4.11   |N          |CHECK_BYPASS|JOSE    |REXACH |NULL   |9 S LAKE CIR     |HAMPTON      |VA        |
-- |18419082          |0208-000107|2022-11-23    |B36CL80ENS|jahbisha.hixson@domesticandgeneral.com|2025-07-23       |2025-11-24 00:00:00.000000|2026-11-24 00:00:00.000000|MAIL_IN_CHECK_SALES      |Renewal program|471533  |1            |BSFGJ12UR2 |1 Year |27349290   |ACTV  |11400523004920|N               |273.60   |22.91  |N          |CHECK_BYPASS|CHRIS   |ORABONA|NULL   |39 W LAKE BLVD   |MAHOPAC      |NY        |
-- |18419082          |0208-000107|2022-11-23    |B36CL80ENS|jahbisha.hixson@domesticandgeneral.com|2025-05-03       |2025-11-24 00:00:00.000000|2027-11-24 00:00:00.000000|MAIL_IN_CHECK_SALES      |Renewal program|459709  |1            |BSFGJ24UR2 |2 Years|26401978   |ACTV  |11400523004874|N               |495.20   |41.47  |Y          |CHECK_BYPASS|CHRIS   |ORABONA|NULL   |39 W LAKE BLVD   |MAHOPAC      |NY        |
-- |21548514          |0000-080920|2023-11-02    |SHP65CM5N |jahbisha.hixson@domesticandgeneral.com|2025-05-30       |2025-11-03 00:00:00.000000|2027-11-03 00:00:00.000000|MAIL_IN_CHECK_SALES      |Renewal program|464089  |1            |BSDHD24UR1 |2 Years|26684714   |ACTV  |11269237004925|N               |226.00   |0.00   |N          |CHECK_BYPASS|SUSAN   |BARRY  |NULL   |PO BOX 503       |YARMOUTH PORT|MA        |
-- |21548514          |0000-080920|2023-11-02    |SHP65CM5N |jahbisha.hixson@domesticandgeneral.com|2025-04-15       |2025-11-03 00:00:00.000000|2027-11-03 00:00:00.000000|MAIL_IN_CHECK_SALES      |Renewal program|458537  |1            |BSDHD24UR1 |2 Years|26384630   |ACTV  |11269237004879|N               |226.00   |0.00   |N          |CHECK_BYPASS|SUSAN   |BARRY  |NULL   |PO BOX 503       |YARMOUTH PORT|MA        |
-- |21708636          |0309-002983|2023-12-07    |SHE3AEM2N |lmartinez@afterinc.com                |2025-09-10       |2025-12-08 00:00:00.000000|2027-12-08 00:00:00.000000|MAIL_IN_CC_SALES         |Renewal program|479633  |1            |BSDHB24UR1 |2 Years|27817154   |ACTV  |11336945004913|N               |126.00   |8.82   |Y          |CREDIT_CARD |AMY     |BECK   |NULL   |1229 LOGAN RD    |BETHEL PARK  |PA        |
-- |21708636          |0309-002983|2023-12-07    |SHE3AEM2N |jahbisha.hixson@domesticandgeneral.com|2025-05-28       |2025-12-08 00:00:00.000000|2027-12-08 00:00:00.000000|MAIL_IN_CC_SALES         |Renewal program|463827  |1            |BSDHB24UR1 |2 Years|26684390   |ACTV  |11336945004867|N               |126.00   |8.82   |N          |CREDIT_CARD |AMY     |BECK   |NULL   |1229 LOGAN RD    |BETHEL PARK  |PA        |
-- |209369779         |NULL       |2023-05-26    |T36IB905SP|SYSTEM                                |2025-05-28       |2025-05-26 00:00:00.000000|2030-05-26 00:00:00.000000|WEB_SALES                |AM EB          |462483  |1            |THFGQ60U2  |5 Years|26622376   |ACTV  |58587         |N               |1104.25  |69.57  |Y          |CREDIT_CARD |DENISE  |FEENAN |NULL   |PO BOX 1227      |STUART       |FL        |
-- |209369779         |NULL       |2023-05-26    |T36IB905SP|SYSTEM                                |2025-05-25       |2025-05-26 00:00:00.000000|2030-05-26 00:00:00.000000|WEB_SALES                |AM EB          |461933  |4            |THFGQ60U2  |5 Years|26592938   |ACTV  |59228         |N               |1104.25  |69.57  |Y          |CREDIT_CARD |DENISE  |FEENAN |NULL   |PO BOX 1227      |STUART       |FL        |
-- |209369791         |NULL       |2023-05-26    |DWHD770WFP|SYSTEM                                |2025-05-28       |2025-05-26 00:00:00.000000|2030-05-26 00:00:00.000000|WEB_SALES                |AM EB          |462483  |2            |THDHF60U2  |5 Years|26622498   |ACTV  |58585         |N               |418.25   |26.35  |Y          |CREDIT_CARD |DENISE  |FEENAN |NULL   |PO BOX 1227      |STUART       |FL        |
-- |209369791         |NULL       |2023-05-26    |DWHD770WFP|SYSTEM                                |2025-05-25       |2025-05-26 00:00:00.000000|2030-05-26 00:00:00.000000|WEB_SALES                |AM EB          |461933  |3            |THDHF60U2  |5 Years|26592968   |ACTV  |59229         |N               |418.25   |26.34  |Y          |CREDIT_CARD |DENISE  |FEENAN |NULL   |PO BOX 1227      |STUART       |FL        |
-- |215897501         |NULL       |2024-08-27    |SHP65CM5N |lcasey@afterinc.com                   |2025-08-26       |2025-08-27 00:00:00.000000|2029-08-27 00:00:00.000000|CALL_CENTER_INBOUND_SALES|AM EB          |475803  |1            |BSDHD60U-25|4 Years|27815120   |ACTV  |62762         |N               |288.75   |20.93  |N          |CREDIT_CARD |FRANK   |PIERSON|NULL   |10402 PUMPKIN LN |RALEIGH      |NC        |
-- |215897501         |NULL       |2024-08-27    |SHP65CM5N |lcasey@afterinc.com                   |2025-08-26       |2025-08-27 00:00:00.000000|2029-08-27 00:00:00.000000|CALL_CENTER_INBOUND_SALES|AM EB          |475793  |1            |BSDHD60U-25|4 Years|27645146   |ACTV  |62762         |N               |288.75   |20.93  |N          |CREDIT_CARD |FRANK   |PIERSON|NULL   |10402 PUMPKIN LN |RALEIGH      |NC        |
-- +------------------+-----------+--------------+----------+--------------------------------------+-----------------+--------------------------+--------------------------+-------------------------+---------------+--------+-------------+-----------+-------+-----------+------+--------------+----------------+---------+-------+-----------+------------+--------+-------+-------+-----------------+-------------+----------+

-- +------------------+-----+-----+
-- |serialized_item_id|count|count|
-- +------------------+-----+-----+
-- |5635060           |2    |2    |
-- |9822480           |2    |2    |
-- |9827340           |2    |2    |
-- |18419082          |2    |2    |
-- |21548514          |2    |2    |
-- |21708636          |2    |2    |
-- |209369779         |2    |2    |
-- |209369791         |2    |2    |
-- |215897501         |2    |2    |
-- +------------------+-----+-----+
 select *
        from (
              SELECT serialized_item_id, count(*), count(distinct oit.order_id)
                FROM order_tbl o
                     JOIN order_item_tbl oit on (oit.order_id = o.order_id)
                     left join contract_order co on (co.order_id = oit.order_id and co.order_line_id = oit.order_line_id)
                     left join contract con on (con.contract_id = co.contract_id)
                     left join contract_status cons on (cons.contract_status_id = con.contract_status_id)
                     left join policy_ext pex ON (pex.policy_id = oit.policy_id)
               WHERE oit.price_amt > 1
                AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                AND ( con.contract_status_id IS NULL OR con.contract_status_id NOT IN (2, 3, 4, 5) )
                AND exists (
                        select oit3.serialized_item_id
                        from   order_item_tbl oit3
                                join order_tbl o3 on o3.order_id = oit3.order_id
                                join contract_order co3 on (co3.order_id = oit3.order_id and co3.order_line_id = oit3.order_line_id)
                                join contract con3 on (con3.contract_id = co3.contract_id)
                                left join contract_status cons3 on (cons3.contract_status_id = con3.contract_status_id)
                                join policy_ext pex3 ON (pex3.policy_id = oit3.policy_id)
                        where 1 = 1
                        and oit3.serialized_item_id  = oit.serialized_item_id
                        and oit3.order_id <> oit.order_id
                        and con3.contract_id <> con.contract_id
                        and
                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                             or
                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                            )
                        and oit3.price_amt > 1
                        AND o3.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                        AND ( con3.contract_status_id IS NULL OR con3.contract_status_id NOT IN (2, 3, 4, 5) )  --canceled/fulfilled/expired
                        and pex3.channels = pex.channels
                        --and con3.contract_end_dt >= trunc(sysdate) - 60
                        and con3.contract_end_dt >= CURRENT_DATE - 30
                       )
               GROUP BY serialized_item_id
              HAVING COUNT(*) >= 2
             )  t;