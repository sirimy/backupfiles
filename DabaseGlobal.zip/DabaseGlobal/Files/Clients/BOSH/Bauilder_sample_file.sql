--unit purchase dates will be current - 1 week
--Plan purchase dates will be current - 2 dyas
--external customer as new series

--Get Sales Extract for EB and AM type SKU and from latest set
insert into ORDER_EXTRACT_TBL_SAMPLE
select OET.*,'',0 from BOSH.ORDER_EXTRACT_TBL OET
                Where INSERT_AUDIT_KEY in  (
                                    select INSERT_AUDIT_KEY from BOSH.ORDER_EXTRACT_TBL order by INSERT_AUDIT_KEY desc FETCH FIRST 1 ROWS ONLY )
                and SKU_CD in (
                            select Distinct POLICY_PRODUCT_XID from BOSH.POLICY_TBL PT
                                where EXP_DT > systimestamp and
                                      PT.POLICY_KEY in (
                                        select distinct POLICY_KEY from BOSH.PRODUCT_PRICE_DIM PPD where  PPD.ACTIVE_IND= 'Y'
                                                and PPD.PRICING_SCHEME_KEY in (
                                                        select PRICING_SCHEME_KEY  from BOSH.PRICING_SCHEME_DIM where
                                                            (PRICING_SCHEME_DESC like '%AM%' or PRICING_SCHEME_DESC like '%EB%')  and END_DT > systimestamp ))
                            )
                FETCH FIRST 100 ROWS ONLY;



--update ORDER_EXTRACT_TBL_SAMPLE set BUILDER_SKU_CD = NULL,BUILDER_PRICE_AMNT=NULL;

    merge  into  ORDER_EXTRACT_TBL_SAMPLE tgt
    using (

            select OETS.UNIQUE_IDENTIFIER,OETS.SKU_CD,OETS.WARRANTY_PURCHASE_PRICE_AMT,OETS.TERM_KEY,OETS.MODEL_NO,NEWSET.POLICY_PRODUCT_XID,NEWSET.PRICE_BEFORE_DISCOUNT_AMT
                FROM
                (
                  select OET.UNIQUE_IDENTIFIER, OET.SKU_CD, OET.WARRANTY_PURCHASE_PRICE_AMT, PT.TERM_KEY,OET.MODEL_NO
                  from ORDER_EXTRACT_TBL_SAMPLE OET   inner join BOSH.POLICY_TBL PT on PT.POLICY_PRODUCT_XID = OET.SKU_CD where PT.EXP_DT > systimestamp
                  )  OETS
                Inner join
                (select *
                 from BOSH.POLICY_TBL PT
                          inner join BOSH.PRODUCT_PRICE_DIM PPD on PPD.POLICY_KEY = PT.POLICY_KEY
                          inner join BOSH.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = PPD.PRICING_SCHEME_KEY
                          inner join BOSH.PRODUCT_DIM PD on PD.PRODUCT_KEY = PPD.PRODUCT_KEY
                 where PSD.PRICING_SCHEME_NAME like '%BUILDER%'
                   and END_DT > systimestamp
                 ) NEWSET
                 on case when Instr(OETS.MODEL_NO, '/') > 0 THEN Substr(OETS.MODEL_NO, 1, Instr(OETS.MODEL_NO, '/') - 1) ELSE OETS.MODEL_NO END = NEWSET.MODEL_NO
                 where OETS.TERM_KEY = NEWSET.TERM_KEY order by UNIQUE_IDENTIFIER
        ) src
       on (src.UNIQUE_IDENTIFIER = tgt.UNIQUE_IDENTIFIER)
    when matched then
    update
    set
        tgt.BUILDER_SKU_CD   = src.POLICY_PRODUCT_XID,
        tgt.BUILDER_PRICE_AMNT      = src.PRICE_BEFORE_DISCOUNT_AMT;
