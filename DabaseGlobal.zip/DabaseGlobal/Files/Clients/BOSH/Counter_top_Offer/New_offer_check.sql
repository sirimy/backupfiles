
select * from bundle_offer_log_tbl order by log_date desc;


select * from offer_tbl where customer_id = 3685332 order by last_updated_ts desc;

select * from offer_tbl where new_offer_id = 'BPPTG3P';

select distinct ofit.serialized_item_id,p.model_no,p.description,oft.last_updated_ts,oft.offer_id
  from offer_tbl oft join  offer_item_tbl ofit on ofit.offer_id = oft.offer_id
       left join policy pol on pol.policy_id = ofit.policy_id
        left join serialized_item si on si.serialized_item_id = ofit.serialized_item_id
        left join product p on si.product_id = p.product_id
 where 1=1
--   and oft.active_ind = 'Y'
   and oft.offer_id < 500000   --real time offer
   and customer_id = 9346401
--    and serialized_item_id = <Enter serialized_item_id >   --enter required serialized_item_id if there are multiple units
   and offer_start_utc_ts > current_date - interval '45' day   --recent real time offers only
  --order by customer_id, serialized_item_id, offer_exp_dt, display_group_num, ofit.display_seq_num
limit 40;
-- +------------------+----------+-------------------+------------------------------------------+--------------------------+--------+
-- |serialized_item_id|model_no  |product_category_id|description                               |last_updated_ts           |offer_id|
-- +------------------+----------+-------------------+------------------------------------------+--------------------------+--------+
-- |184192297         |TQU60307  |23258930           |TQU60307, Fully Automatic Espresso Machine|2024-12-16 14:13:38.326786|53370   |
-- |184192331         |TIU20109  |23258930           |TIU20109, Fully Automatic Espresso Machine|2024-12-16 14:13:38.108636|53369   |
-- |184192337         |TIU20307  |23258930           |TIU20307, Fully Automatic Espresso Machine|2024-12-16 14:13:37.910920|53368   |
-- |184192343         |TIU20508  |23258930           |TIU20508, Fully Automatic Espresso Machine|2024-12-16 14:13:37.697842|53367   |
-- |184192349         |TPU60309  |23258930           |TPU60309, Fully Automatic Espresso Machine|2024-12-16 14:13:37.489505|53366   |
-- |184192355         |TPU60501  |23258930           |TPU60501, Fully Automatic Espresso Machine|2024-12-16 14:13:37.277413|53365   |
-- |184192363         |TQU60703  |23258930           |TQU60703, Fully Automatic Espresso Machine|2024-12-16 14:13:37.065538|53364   |
-- |187884793         |DWHD661EPR|2028332            |DWHD661EPR, Dishwasher                    |2024-12-16 14:13:36.542926|53363   |
-- |187884793         |DWHD661EPR|2028332            |DWHD661EPR, Dishwasher                    |2024-12-16 14:14:04.839880|53372   |
-- +------------------+----------+-------------------+------------------------------------------+--------------------------+--------+
select fn_real_time_offer_bundled('BOSCH','{184192297,184192331,184192337,184192343,184192349,184192355,184192363}'::text[],'3685332','iahmad');

select fn_real_time_offer_bundled('THERMADOR','{187884793}'::text[],'3685332','iahmad');
--B7UFJAA



-- delete from offer_item_tbl where offer_id = 53372;
-- delete from offer_tbl where offer_id = 53372;
-- commit;
--
-- BOSH: boshbaplweb, public> select fn_real_time_offer_bundled('BOSCH','{184192297,184192331,184192337,184192343,184192349,184192355,184192363,187884793}'::text[],'3685332','iahmad')
-- [2024-12-19 15:26:05] [P0001] ERROR: Unable to create offer: Serialized item "187884793" does not belong to Brand "BOSCH"
-- [2024-12-19 15:26:05] Where: PL/pgSQL function fn_real_time_offer_bundled(text,text[],text,text) line 142 at RAISE

commit;



select * from BUNDLE_OFFER_LOG_TBL where job_id >  112696 order by log_date desc;

select fn_real_time_offer_bundled('BOSCH','{184192297,184192331,184192337,184192343,184192349,184192355,184192363,82228357,82226869}'::text[],'3685332','iahmad');

-- delete from offer_item_tbl where offer_id = 53372;
-- delete from offer_tbl where offer_id = 53372;
-- commit;

--BY7NX7C

select distinct ofit.serialized_item_id,p.model_no,p.description,oft.last_updated_ts,oft.offer_id
  from offer_tbl oft join  offer_item_tbl ofit on ofit.offer_id = oft.offer_id
       left join policy pol on pol.policy_id = ofit.policy_id
        left join serialized_item si on si.serialized_item_id = ofit.serialized_item_id
        left join product p on si.product_id = p.product_id
 where 1=1
--   and oft.active_ind = 'Y'
   and oft.offer_id < 500000   --real time offer
   and customer_id = 3685332
--    and serialized_item_id = <Enter serialized_item_id >   --enter required serialized_item_id if there are multiple units
   and offer_start_utc_ts > current_date - interval '45' day   --recent real time offers only
  --order by customer_id, serialized_item_id, offer_exp_dt, display_group_num, ofit.display_seq_num
limit 40;


select distinct oft.offer_id
  from offer_tbl oft join  offer_item_tbl ofit on ofit.offer_id = oft.offer_id
       left join policy pol on pol.policy_id = ofit.policy_id
        left join serialized_item si on si.serialized_item_id = ofit.serialized_item_id
        left join product p on si.product_id = p.product_id
 where 1=1
--   and oft.active_ind = 'Y'
   and oft.offer_id < 500000   --real time offer
   and customer_id = 3685332
--    and serialized_item_id = <Enter serialized_item_id >   --enter required serialized_item_id if there are multiple units
   and offer_start_utc_ts > current_date - interval '45' day   --recent real time offers only
  --order by customer_id, serialized_item_id, offer_exp_dt, display_group_num, ofit.display_seq_num
limit 40;

delete from offer_item_tbl where offer_id = 51355;
delete from offer_tbl where offer_id = 51355;
commit;