

select * from email_tbl where
                            lower(EMAIL_ADDRESS_TX) like '%krause%' and
                                ( lower(EMAIL_ADDRESS_TX) like '%domesticandgeneral.com%'
                                    Or  lower(EMAIL_ADDRESS_TX) like '%afterinc.com%' );


--javascript: showOffer('3685332','184192297','','#viewCustomerProductStatus')
--javascript: showOffer('3685332','184192331','','#viewCustomerProductStatus')
--javascript: showOffer('3685332','184192337','','#viewCustomerProductStatus')
--javascript: showOffer('3685332','184192343','','#viewCustomerProductStatus')
--javascript: showOffer('3685332','184192349','','#viewCustomerProductStatus')
--javascript: showOffer('3685332','184192355','','#viewCustomerProductStatus')
--javascript: showOffer('3685332','184192363','','#viewCustomerProductStatus')

 SELECT UPPER(coalesce(vp.brand_nm,'XXX')),vp.product_category_nm
        FROM serialized_item si
        JOIN v_product vp  ON ( vp.product_id = si.product_id)
WHERE si.serialized_item_id in('184192297','184192331','184192337','184192343','184192349','184192355','184192363') ;
-- +-----+---------------------------+
-- |upper|product_category_nm        |
-- +-----+---------------------------+
-- |BOSCH|Countertop Espresso Machine|
-- |BOSCH|Countertop Espresso Machine|
-- |BOSCH|Countertop Espresso Machine|
-- |BOSCH|Countertop Espresso Machine|
-- |BOSCH|Countertop Espresso Machine|
-- |BOSCH|Countertop Espresso Machine|
-- |BOSCH|Countertop Espresso Machine|
-- +-----+---------------------------+

-- +-----+---------------------------+
-- |upper|product_category_nm        |
-- +-----+---------------------------+
-- |BOSCH|Countertop Espresso Machine|
-- +-----+---------------------------+

select oft.*, ofit.*, pol.description
  from offer_tbl oft join  offer_item_tbl ofit on ofit.offer_id = oft.offer_id
       left join policy pol on pol.policy_id = ofit.policy_id
 where 1=1
--   and oft.active_ind = 'Y'
   and oft.offer_id < 500000   --real time offer
   and customer_id = 3685332
--    and serialized_item_id = <Enter serialized_item_id >   --enter required serialized_item_id if there are multiple units
   and offer_start_utc_ts > current_date - interval '45' day   --recent real time offers only
  order by customer_id, serialized_item_id, offer_exp_dt, display_group_num, ofit.display_seq_num
limit 40;


select fn_real_time_offer_bundled('BOSCH','{184192297,184192331,184192337,184192343,184192349,184192355,184192363}'::text[],'3685332','iahmad');

-- delete from offer_item_tbl where offer_id = 51269;
-- delete from offer_tbl where offer_id = 51269;
-- commit;