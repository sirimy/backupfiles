
do $$
<<first_block>>
declare
    bundle_offer_count integer := 0;
    v_job_id integer := 0;
    v_offer                text:= '1';
    v_serialized_item_id                text:= '2';
    v_in_customer                text:= '3';
    v_existing_offer_id                text:= '4';
    in_created_by                text:= '5';
        v_off_seq                text:= '6';
        v_quickreg_code                text:= '7';
    v_final_error_desc                text:= '8';

    v_offer_final        text:= '8';

begin
   -- get the number of films
   select count(*)
   into bundle_offer_count
   from bundle_offer_log_tbl;

   -- display a message
   raise notice 'The number of films is %', bundle_offer_count;
--     PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,created_by)
--     VALUES (0,1,2,''E'',''Contract Already Exists'',''in_created_by'')') ;
   --values(v_job_id,v_in_serials[i],v_in_customer,'E','Contract Already Exists',in_created_by)
   --VALUES (''E'',''Invalid Customer:'||in_serialized_item_id||''''||','||''''||in_created_by||''')') ;
    --raise notice  '' || v_job_id::text ||','||v_serialized_item_id||','||v_in_customer||',''FO'',''Final offer returned(Existing offer): '||v_offer||''''||','''''||v_quickreg_code||''''','''''||created_by||''''')';

--     PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by) ' ||
--                           'VALUES ('||v_job_id::text||','||v_serialized_item_id||','||v_in_customer||',''FO'',''Final offer returned(Existing offer): '||v_offer||''''||','''||v_quickreg_code||''','''||created_by||''')') ;

    PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by) ' ||
                          'VALUES ('||v_job_id::text||','||v_serialized_item_id||','||v_in_customer||',''EO'',''Active offer exists for serialized_itm_id.'','''||v_existing_offer_id||''','''||in_created_by||''')') ;

  PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by)  VALUES (0,0,0,0,0,0,0)') ;


            PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by) ' ||
                          'VALUES ('||v_job_id::text||','||v_serialized_item_id||','||v_in_customer||',''FO'',''Final offer returned(Existing offer):: '||v_offer||''''||','''||v_existing_offer_id||''','''||in_created_by||''')') ;


--             insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by)
--             values(v_job_id, v_serialized_item_id::numeric,v_in_customer, 'O', 'Offer Items creating for serial item '|| v_serialized_item_id ||' and offer '||v_off_seq::text,v_quickreg_code, in_created_by);

           PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by) ' ||
                          'VALUES ('||v_job_id::text||','||v_serialized_item_id||','||v_in_customer||',''O'',''Offer Items creating for serial item '||v_serialized_item_id||' and offer '||v_off_seq::text||''','''||v_existing_offer_id||''','''||in_created_by||''')') ;


--     insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by)
--             values(v_job_id, v_serialized_item_id::numeric,v_in_customer, 'E', 'Unable to create offer: Product Not Eligible', v_quickreg_code, in_created_by);

    PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by) ' ||
                          'VALUES ('||v_job_id::text||','||v_serialized_item_id||','||v_in_customer||',''E'',''Unable to create offer: Product Not Eligible'','''||v_quickreg_code||''','''||in_created_by||''')') ;

--    insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by)
--             values(v_job_id, v_serialized_item_id::numeric,v_in_customer, 'FO', 'No offer got created. Error Raised: '|| v_final_error_desc, v_quickreg_code, in_created_by);
--

    PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by) ' ||
                          'VALUES ('||v_job_id::text||','||v_serialized_item_id||','||v_in_customer||',''FO'',''No offer got created. Error Raised: '||v_final_error_desc||''','''||v_quickreg_code||''','''||in_created_by||''')') ;

--
--       insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by)
--             values(v_job_id, v_serialized_item_id::numeric,v_in_customer, 'FO','Final new Offer returned to App :'||v_offer_final, v_quickreg_code, in_created_by);


    PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by) ' ||
                          'VALUES ('||v_job_id::text||','||v_serialized_item_id||','||v_in_customer||',''FO'',''Final new Offer returned to App : '||v_offer_final||''','''||v_quickreg_code||''','''||in_created_by||''')') ;



    insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,created_by)
            values(v_job_id, v_in_serials[i],v_in_customer, 'E', 'Contracts Not Available on appliances over 9 years old',in_created_by);

       PERFORM execute_query('insert into BUNDLE_OFFER_LOG_TBL(job_id,serialized_item_id,customer_id,offer_status,error_desc,offer_id,created_by) ' ||
                          'VALUES ('||v_job_id::text||','||v_in_serials[i]||','||v_in_customer||',''E'',''Contracts Not Available on appliances over 9 years old'','''','''||in_created_by||''')') ;


   select count(*)
   into bundle_offer_count
   from bundle_offer_log_tbl;

   -- display a message
   raise notice 'The number of films is %', bundle_offer_count;
end first_block $$;