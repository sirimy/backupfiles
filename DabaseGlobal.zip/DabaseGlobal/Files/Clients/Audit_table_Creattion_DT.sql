

select AT1.CREATION_DT,T1.* from BOSH.SERIALIZED_ITEM_DIM T1
         JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = T1.INSERT_AUDIT_KEY
         where T1.SI_KEY not in (
    select T2.SI_KEY from BOSH.SERIALIZED_ITEM_EXT_DIM T2
                  ) ;