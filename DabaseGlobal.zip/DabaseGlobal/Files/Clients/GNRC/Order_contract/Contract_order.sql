

select * from contract_order where contract_order.order_id in (778877,733489);


select * from order_item_tbl where order_item_tbl.order_id in (778877,733489);
+--------------------------+--------+-------------+-------------+-------------+------------------+---------+
|purchase_dt               |order_id|order_line_id|offer_id     |offer_line_id|serialized_item_id|policy_id|
+--------------------------+--------+-------------+-------------+-------------+------------------+---------+
|2023-08-18 16:07:34.915000|733489  |1            |8458748061240|2            |6267030           |141      |
|2023-11-27 15:14:17.348000|778877  |1            |8246907011096|1            |1665766           |132      |
+--------------------------+--------+-------------+-------------+-------------+------------------+---------+


select * from order_tbl where order_tbl.order_id in (778877,733489);
+--------------------------+--------+---------+------------------+--------------------+--------------------------+
|created_ts                |order_id|order_xid|billing_profile_id|created_by          |purchase_dt               |
+--------------------------+--------+---------+------------------+--------------------+--------------------------+
|2023-08-18 16:07:38.002000|733489  |2539963  |155429715         |sromero@afterinc.com|2023-08-18 16:07:34.915000|
|2023-11-27 15:14:20.545000|778877  |2562657  |160891977         |sromero@afterinc.com|2023-11-27 15:14:17.348000|
+--------------------------+--------+---------+------------------+--------------------+--------------------------+

select * from billing_info_tbl where order_id in (778877,733489);
+--------+----------+--------+--------+
|order_id|address_id|phone_id|email_id|
+--------+----------+--------+--------+
|733489  |4617108   |6263306 |6257064 |
|778877  |903598    |6316628 |203076  |
+--------+----------+--------+--------+


select * from address_tbl where address_id in (4617108,903598);
+----------+--------+---------+-----------+---------------------+----------------+-----------+--------+---------------+---------------+
|address_id|first_nm|middle_nm|last_nm    |address_line1_tx     |address_line2_tx|locality_nm|state_id|postal_code1_tx|postal_code2_tx|
+----------+--------+---------+-----------+---------------------+----------------+-----------+--------+---------------+---------------+
|903598    |RONALD  |NULL     |COPLEY     |2785 PONKAN SUMMIT DR|NULL            |APOPKA     |10      |32712          |6465           |
|4617108   |NINA    |NULL     |CREEL-MILLS|1824 BIG BRANCH RD   |NULL            |MIDDLEBURG |10      |32068          |3119           |
+----------+--------+---------+-----------+---------------------+----------------+-----------+--------+---------------+---------------+

select * from state where state_id =10;
+--------+-------+----+----------+-----------+--------------------------+---------------+
|state_id|name   |code|country_id|country_iso|last_updated_ts           |last_updated_by|
+--------+-------+----+----------+-----------+--------------------------+---------------+
|10      |Florida|FL  |1         |en_US      |2017-02-23 09:23:04.643194|NULL           |
+--------+-------+----+----------+-----------+--------------------------+---------------+



    SELECT DISTINCT T1.ORDER_ID
		FROM ORDER_TBL T1
		JOIN ORDER_ITEM_TBL OIT ON OIT.ORDER_ID = T1.ORDER_ID
		WHERE  oit.price_amt > 1    --skip test orders from bulk contract creation
		and   NOT EXISTS
			    (SELECT 1 FROM CONTRACT_ORDER T2
			     WHERE OIT.ORDER_ID = T2.ORDER_ID AND OIT.ORDER_LINE_ID=T2.ORDER_LINE_ID
			    ) ---THESE ARE THE NEW ORDERS
		 AND lower(OIT.LINE_ITEM_TYPE_CD) = 'policylineitem'
		 AND (OIT.POLICY_ID IS NOT NULL)  AND T1.ORDER_ID in (778877,733489);


select p_populate_contract(778877);
-- price_amt 595
-- CONTRACT_ID: 112490973
-- POPULATE THE CONTRACT TABLE FROM NEW ORDERS
-- new row for relation "contract" violates check constraint "chk_terms_id"
-- [2024-01-31 01:47:48] 1 row retrieved starting from 1 in 767 ms (execution: 271 ms, fetching: 496 ms)
select p_populate_contract(733489);
-- GNRC: gnrcexlwweb, public> select p_populate_contract(733489)
-- price_amt 1015
-- CONTRACT_ID: 112490975
-- POPULATE THE CONTRACT TABLE FROM NEW ORDERS
 new row for relation "contract" violates check constraint "chk_terms_id"
-- [2024-01-31 01:48:52] 1 row retrieved starting from 1 in 274 ms (execution: 222 ms, fetching: 52 ms)

 SELECT
				0,
				T7.ADDRESS_ID,
				null::text AS CLIENT_CONTRACT_NUM, -- T2.ORDER_ID::TEXT || LPAD(T2.ORDER_LINE_ID::TEXT, 2, '0')    AS CLIENT_CONTRACT_NUM,
				null::numeric AS CLIENT_CUSTOMER_NUM,
				T2.COVERAGE_EXP_DT AS CONTRACT_END_DT,
				T1.PURCHASE_DT AS CONTRACT_SALE_DT,
				T2.COVERAGE_START_DT AS CONTRACT_START_DT,
				(SELECT MIN(CONTRACT_STATUS_ID) FROM CONTRACT_STATUS
				 WHERE upper(NAME) = 'PNDG')  AS CONTRACT_STATUS_ID,
				COALESCE(T10.CURRENCY_CD, 'USD') CURRENCY_CD,
				T1.CUSTOMER_ID,
				T2.DISCOUNT1_AMT AS DISCOUNT_AMT,
				--T2.DML_FLAG,
				'CREATE' AS DML_FLAG,
				NULL::numeric as  NET_PREMIUM_AMT, -- T5.NET_PREMIUM_AMT AS NET_PREMIUM_AMT,
				T2.POLICY_ID,
				T7.ADDRESS_ID AS PURCHASE_ADDRESS_ID,
				T6.RESOLUTION_TYPE,
				T2.PRICE_AMT AS RETAIL_AMT,
				NULL::numeric AS  RISK_FREE_AMT,
				T2.TAX_AMT AS TAX,
				T12.TERMS_AND_CONDITIONS_ID,
				T11.STATE_ID,
				T12.STATE_ID,
				T2.POLICY_ID ,
				T12.POLICY_ID,
				T12.CHANNEL_PARTNER_ID,
				T1.PURCHASE_DT , T12.EFFECTIVE_DT , T12.END_DT,
				T12.CONTRACT_TEMPLATE_ID,
				T1.OUTLET_ID,
				'SYSTEM' as LAST_UPDATED_BY,
				CURRENT_TIMESTAMP AS LAST_UPDATED_TS
			FROM
			      ORDER_TBL T1
				JOIN ORDER_ITEM_TBL T2
				ON (T1.ORDER_ID = T2.ORDER_ID)
				LEFT JOIN BILLING_INFO_TBL T3
				ON (T1.ORDER_ID = T3.ORDER_ID)
				LEFT JOIN
				SERIALIZED_ITEM T4
				ON (T2.SERIALIZED_ITEM_ID =
				T4.SERIALIZED_ITEM_ID)
				LEFT JOIN POLICY T6
				ON (T2.POLICY_ID = T6.POLICY_ID)
				LEFT JOIN SHIPPING_INFO_TBL T7
				ON (T1.ORDER_ID = T7.ORDER_ID)
				JOIN
				(  SELECT ORDER_ID, MAX (CURRENCY_CD) CURRENCY_CD
					FROM PAYMENT_TX_TBL
					GROUP BY ORDER_ID) T10
				ON (T1.ORDER_ID = T10.ORDER_ID)
				LEFT JOIN ADDRESS_TBL T11
				ON (T7.ADDRESS_ID = T11.ADDRESS_ID)
				LEFT JOIN
				T_AND_C_CONTRACT_TEMPLATE_XREF T12
				ON (    T11.STATE_ID = T12.STATE_ID
				AND T2.POLICY_ID = T12.POLICY_ID
				AND COALESCE(T12.CHANNEL_PARTNER_ID::numeric, 0) = 0
				AND T1.PURCHASE_DT BETWEEN T12.EFFECTIVE_DT AND T12.END_DT --CHANGED BY  AS ON 02/26/2013
				)
			WHERE     T1.ORDER_ID = 778877 AND T2.ORDER_LINE_ID = 1
			AND lower(T2.LINE_ITEM_TYPE_CD) IN ('policylineitem')
			AND (T2.POLICY_ID IS NOT NULL
			) ;


--733489
ORDER_TBL.PURCHASE_DT = '2023-08-18 16:07:34.915000'
select * from T_AND_C_CONTRACT_TEMPLATE_XREF T12 where   T12.STATE_ID = 10
				AND T12.POLICY_ID = 141
				AND COALESCE(T12.CHANNEL_PARTNER_ID::numeric, 0) = 0;
				--AND T1.PURCHASE_DT BETWEEN T12.EFFECTIVE_DT AND T12.END_DT
+---------+--------+--------------------------+--------------------------+
|policy_id|state_id|effective_dt              |end_dt                    |
+---------+--------+--------------------------+--------------------------+
|141      |10      |2022-01-01 00:00:00.000000|2023-08-09 00:00:00.000000|
+---------+--------+--------------------------+--------------------------+


--778877
ORDER_TBL.PURCHASE_DT = '2023-11-27 15:14:17.348000'
select * from T_AND_C_CONTRACT_TEMPLATE_XREF T12 where   T12.STATE_ID = 10
				AND T12.POLICY_ID = 132
				AND COALESCE(T12.CHANNEL_PARTNER_ID::numeric, 0) = 0
				--AND T1.PURCHASE_DT BETWEEN T12.EFFECTIVE_DT AND T12.END_DT
+---------+--------+--------------------------+--------------------------+
|policy_id|state_id|effective_dt              |end_dt                    |
+---------+--------+--------------------------+--------------------------+
|132      |10      |2021-02-15 00:00:00.000000|2023-08-09 00:00:00.000000|
+---------+--------+--------------------------+--------------------------+
