

SELECT  *
		FROM (
			select cc.CONTRACT_KEY,
			cc.CANCEL_BY,
			cc.CANCEL_DT,
			cc.CANCEL_EFFECTIVE_DT,
			cc.CONTRACT_REFUND_AMT,
			cc.TAX_REFUND_AMT,
			si.SERIAL_NO, oit.PURCHASE_DT, oit.ORDER_KEY, trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) as days_used
			,ccci.FULL_OR_PRO_RATED_REFUND
			from gnrc.CONTRACT_CANCELLATION_DIM cc
			join gnrc.CONTRACT_ORDER_TBL cot on cot.CONTRACT_KEY = cc.CONTRACT_KEY
			join gnrc.ORDER_ITEM_TBL oit on oit.ORDER_KEY = cot.ORDER_KEY and oit.ORDER_LINE_KEY = cot.ORDER_LINE_KEY
			join gnrc.SERIALIZED_ITEM_DIM si on si.SI_KEY = oit.SERIALIZED_ITEM_KEY
			left join gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ccci on ccci.CONTRACT_KEY = cc.CONTRACT_KEY
			where CANCEL_DT >= date '2024-05-01'   --cut off date
			and CANCEL_DT <= last_day(current_date)   --up to the last day of the invoice month
			and extract(day from last_day(current_date)) - extract(day from current_date) <= 3 --check within the last 3 days of the month
			and trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) > 30  --pro-rata cancellation rule will apply
			and ccci.CONTRACT_KEY is null
			order by CANCEL_DT, si.SERIAL_NO
		)

		;