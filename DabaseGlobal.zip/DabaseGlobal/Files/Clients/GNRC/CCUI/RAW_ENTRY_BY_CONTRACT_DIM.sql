
insert into RAW_CONTRACT_CANCELLATION_CLIENT_INPUT
SELECT  CUSTOMER_NAME                ,
    SERIAL_NO AS SERIAL_NUMBER       ,
    STATE                            ,
    PURCHASE_DT AS PURCHASE_DATE     ,
    SYSDATE AS CANCEL_REQUEST_DATE              ,
    DESCRIPTION AS CANCEL_REASON                    ,
    PRODUCT_NM AS PRODUCT_NAME       ,
    TOTAL_AMT AS CONTRACT_AMOUNT                  ,
    TOTAL_AMT AS TOTAL_CUSTOMER_PAID_AMOUNT       ,
    TOTAL_AMT AS PAID_CONTRACT_AMOUNT             ,
    TAX_AMT AS PAID_TAX_AMOUNT_IF_APPLICABLE    ,
    'Pro rated' AS FULL_OR_PRO_RATED_REFUND         ,
     CONTRACT_REFUND_AMT AS CONTRACT_REFUND_AMOUNT           ,
    0 AS TAX_REFUND_AMOUNT_IF_APPLICABLE  ,
    CONTRACT_REFUND_AMT AS TOTAL_REFUND_AMOUNT              ,
    SYSDATE AS  APPROVED_DATE                    ,
    'Manual' AS NOTES_COMMENTS                   ,
    0 AS INSERT_AUDIT_KEY                 ,
    'contract_cancellation_client_input_01_Aug_2024.csv' AS FILE_NM                         ,
    ORDER_KEY
                FROM (
                        select cc.CONTRACT_KEY,
                        'GNRC-1566' AS CANCEL_BY,
                        date'2024-08-01' AS CANCEL_DT,
                        date'2024-08-01' AS CANCEL_EFFECTIVE_DT,
                        0 AS CONTRACT_REFUND_AMT,
                        0 AS TAX_REFUND_AMT,
                        si.SERIAL_NO, oit.PURCHASE_DT, oit.ORDER_KEY
                        ,ccci.FULL_OR_PRO_RATED_REFUND,
                         pd.PRODUCT_NM,'GNRC-1566 - remove per resolution case 8000023055' AS DESCRIPTION, AD.FIRST_NM || ' ' || AD.LAST_NM AS CUSTOMER_NAME
                        ,AD.STATE_CD AS STATE,OT.TOTAL_AMT,OT.TAX_AMT
                        from gnrc.CONTRACT_DIM cc
                        join gnrc.CONTRACT_LKP cl on cl.CONTRACT_KEY = cc.CONTRACT_KEY
                        join gnrc.CONTRACT_ORDER_TBL cot on cot.CONTRACT_KEY = cc.CONTRACT_KEY AND SOURCE_SYSTEM_CD = 0
                        join gnrc.ORDER_ITEM_TBL oit on oit.ORDER_KEY = cot.ORDER_KEY and oit.ORDER_LINE_KEY = cot.ORDER_LINE_KEY
                        join GNRC.ORDER_TBL OT on OT.ORDER_KEY = oit.ORDER_KEY
                        JOIN GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = OT.VISITOR_KEY
                        JOIN GNRC.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
                        JOIN GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
                        join gnrc.SERIALIZED_ITEM_DIM si on si.SI_KEY = oit.SERIALIZED_ITEM_KEY
                        join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = si.PRODUCT_KEY
                        left join gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ccci on ccci.CONTRACT_KEY = cc.CONTRACT_KEY
                        where  cl.CONTRACT_XID ='41001516'
                        and ccci.CONTRACT_KEY is null
                        order by CANCEL_DT, si.SERIAL_NO
                );