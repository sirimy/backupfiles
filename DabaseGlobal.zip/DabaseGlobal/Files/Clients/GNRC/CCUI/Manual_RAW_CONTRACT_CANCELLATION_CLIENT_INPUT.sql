insert into RAW_CONTRACT_CANCELLATION_CLIENT_INPUT
SELECT  CUSTOMER_NAME                ,
    SERIAL_NO AS SERIAL_NUMBER       ,
    STATE                            ,
    PURCHASE_DT AS PURCHASE_DATE     ,
    SYSDATE AS CANCEL_REQUEST_DATE              ,
    DESCRIPTION AS CANCEL_REASON                    ,
    PRODUCT_NM AS PRODUCT_NAME       ,
    TOTAL_AMT AS CONTRACT_AMOUNT                  ,
    CONTRACT_REFUND_AMT AS TOTAL_CUSTOMER_PAID_AMOUNT       ,
    CONTRACT_REFUND_AMT AS PAID_CONTRACT_AMOUNT             ,
    0 AS PAID_TAX_AMOUNT_IF_APPLICABLE    ,
    'Full' AS FULL_OR_PRO_RATED_REFUND         ,
     CONTRACT_REFUND_AMT AS CONTRACT_REFUND_AMOUNT           ,
    0 AS TAX_REFUND_AMOUNT_IF_APPLICABLE  ,
    CONTRACT_REFUND_AMT AS TOTAL_REFUND_AMOUNT              ,
    SYSDATE AS  APPROVED_DATE                    ,
    'Manual' AS NOTES_COMMENTS                   ,
    0 AS INSERT_AUDIT_KEY                 ,
    'contract_cancellation_client_input_28_august_manul_2026.csv' AS FILE_NM                         ,
    ORDER_KEY
                FROM (
                        select cc.CONTRACT_KEY,
                        cc.CANCEL_BY,
                        cc.CANCEL_DT,
                        cc.CANCEL_EFFECTIVE_DT,
                        cc.CONTRACT_REFUND_AMT,
                        cc.TAX_REFUND_AMT,
                        si.SERIAL_NO, oit.PURCHASE_DT, oit.ORDER_KEY, trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) as days_used
                        ,ccci.FULL_OR_PRO_RATED_REFUND,
                         pd.PRODUCT_NM,crt.DESCRIPTION, AD.FIRST_NM || ' ' || AD.LAST_NM AS CUSTOMER_NAME
                        ,AD.STATE_CD AS STATE,OT.TOTAL_AMT
                        from gnrc.CONTRACT_CANCELLATION_DIM cc
                        join gnrc.CANCELLATION_REASON_TBL crt on crt.CANCELLATION_REASON_KEY = cc.CANCELLATION_REASON_KEY
                        join gnrc.CONTRACT_ORDER_TBL cot on cot.CONTRACT_KEY = cc.CONTRACT_KEY
                        join gnrc.ORDER_ITEM_TBL oit on oit.ORDER_KEY = cot.ORDER_KEY and oit.ORDER_LINE_KEY = cot.ORDER_LINE_KEY
                        join GNRC.ORDER_TBL OT on OT.ORDER_KEY = oit.ORDER_KEY
                        JOIN GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = OT.VISITOR_KEY
                        JOIN GNRC.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
                        JOIN GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
                        join gnrc.SERIALIZED_ITEM_DIM si on si.SI_KEY = oit.SERIALIZED_ITEM_KEY
                        join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = si.PRODUCT_KEY
                        left join gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ccci on ccci.CONTRACT_KEY = cc.CONTRACT_KEY
                        where CANCEL_DT >= date '2024-05-01'   --cut off date
                        and CANCEL_DT <= last_day(current_date)   --up to the last day of the invoice month
                       -- and extract(day from last_day(current_date)) - extract(day from current_date) <= 5 --check within the last 5 days of the month
                        and trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) > 30  --pro-rata cancellation rule will apply
                        and ccci.CONTRACT_KEY is null
                        order by CANCEL_DT, si.SERIAL_NO
                );

COMMIT;