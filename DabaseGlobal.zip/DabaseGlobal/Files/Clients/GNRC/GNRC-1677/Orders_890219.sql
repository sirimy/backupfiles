select distinct  SID.SI_KEY,SID.SERIAL_NO ,OIT.ORDER_KEY
       -- ,VP.BRAND_NM,VP.PARENT_CATEGORY_NM,OT.SALES_SOURCE_CD,SP.MAIL_DROP_DATE,OT.PURCHASE_DT,ot.ORDER_CREATED_TS,OIT.OFFER_KEY
      -- ,RLT.OWNER_ADDRESS1 || ']-[' || SP.ADDRESS_LINE1_TX || ']-[' || AD.ADDRESS_LINE1_TX || ']-[' || AD1.ADDRESS_LINE1_TX || ']-[' ||  AD2.ADDRESS_LINE1_TX RAW_Add1_OFFER_Add1_CST_SHIP_BILL
       ,RLT.OWNER_ADDRESS1 RAW_Add1,RLT.OWNER_CITY RAW_CITY_NM ,RLT.OWNER_STATE RAW_STATE_CD,ST3.TAXABLE_STATUS RAW_TAXABLE_STATUS
     --  ,SP.ADDRESS_LINE1_TX OFFER_Add1,SP.CITY_NM OFFER_CITY_NM ,SP.STATE_CD OFFER_STATE_CD ,ST1.TAXABLE_STATUS OFFER_TAXABLE_STATUS
        ,AD.ADDRESS_LINE1_TX CST,AD.CITY_NM AD_CITY_NM  ,AD.STATE_CD AD_STATE_CD
        ,AD1.ADDRESS_LINE1_TX SHIP,AD1.CITY_NM SHIP_CITY_NM ,AD1.STATE_CD SHIP_STATE_CD ,ST2.TAXABLE_STATUS SHIP_TAXABLE_STATUS
        ,AD2.ADDRESS_LINE1_TX BILL,AD2.CITY_NM BILL_CITY_NM ,AD2.STATE_CD BILL_STATE_CD
        from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RLT
            JOIN GNRC.SERIALIZED_ITEM_DIM SID on SID.SERIAL_NO = LTRIM(TRIM(EQUIPMENT),'0')
            JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = SID.PRODUCT_KEY
            JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY
            JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            JOIN GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = OT.VISITOR_KEY
            JOIN GNRC.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            JOIN GNRC.SHIPPING_INFO_TBL SOT on SOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.BILLING_INFO_TBL BOT on BOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = SOT.ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD2 on AD2.ADDRESS_KEY = BOT.ADDRESS_KEY
--             LEFT JOIN date_dim dd on dd.DATE_KEY = SID.PURCHASE_DT_KEY
--             JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = OIT.INSERT_AUDIT_KEY
--            LEFT JOIN GNRC.CAMPAIGN_SPOOL_FILE_TBL SP ON SP.REFERENCE_ID = OIT.OFFER_KEY
--            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st1 ON ST1.STATE_CD = sP.STATE_CD
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st2 ON st2.STATE_CD = AD1.STATE_CD
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st3 ON st3.STATE_CD = RLT.OWNER_STATE
      where OT.ORDER_KEY = 890219;
-- +-------+----------+---------+------------------+-----------+------------+------------------+------------------+----------+-----------+--------------+------------+-------------+-------------------+--------------+------------+-------------+
-- |SI_KEY |SERIAL_NO |ORDER_KEY|RAW_ADD1          |RAW_CITY_NM|RAW_STATE_CD|RAW_TAXABLE_STATUS|CST               |AD_CITY_NM|AD_STATE_CD|SHIP          |SHIP_CITY_NM|SHIP_STATE_CD|SHIP_TAXABLE_STATUS|BILL          |BILL_CITY_NM|BILL_STATE_CD|
-- +-------+----------+---------+------------------+-----------+------------+------------------+------------------+----------+-----------+--------------+------------+-------------+-------------------+--------------+------------+-------------+
-- |1782389|3013500322|890219   |21371 Crestview Rd|Reno       |NV          |Non-Taxable       |21371 CRESTVIEW RD|RENO      |NV         |446 HEARTH WAY|PITTSBURG   |CA           |Non-Taxable        |446 HEARTH WAY|PITTSBURG   |CA           |
-- +-------+----------+---------+------------------+-----------+------------+------------------+------------------+----------+-----------+--------------+------------+-------------+-------------------+--------------+------------+-------------+

-- +-------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+----------------------------------------------------------------------------------------------+------------------+-----------+------------+------------------+------------------+-------------+--------------+--------------------+------------------+----------+-----------+--------------+------------+-------------+-------------------+--------------+------------+-------------+------+-------+
-- |SI_KEY |SERIAL_NO |ORDER_KEY|BRAND_NM|PARENT_CATEGORY_NM     |SALES_SOURCE_CD    |MAIL_DROP_DATE|PURCHASE_DT               |ORDER_CREATED_TS          |OFFER_KEY     |RAW_ADD1_OFFER_ADD1_CST_SHIP_BILL                                                             |RAW_ADD1          |RAW_CITY_NM|RAW_STATE_CD|RAW_TAXABLE_STATUS|OFFER_ADD1        |OFFER_CITY_NM|OFFER_STATE_CD|OFFER_TAXABLE_STATUS|CST               |AD_CITY_NM|AD_STATE_CD|SHIP          |SHIP_CITY_NM|SHIP_STATE_CD|SHIP_TAXABLE_STATUS|BILL          |BILL_CITY_NM|BILL_STATE_CD|STATUS|DETAILS|
-- +-------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+----------------------------------------------------------------------------------------------+------------------+-----------+------------+------------------+------------------+-------------+--------------+--------------------+------------------+----------+-----------+--------------+------------+-------------+-------------------+--------------+------------+-------------+------+-------+
-- |1782389|3013500322|890219   |GENERAC |RESIDENTIAL HKW A/C HSB|MAIL_IN_CHECK_SALES|2024-11-19    |2024-11-27 00:00:00.000000|2024-12-04 16:51:01.025231|11770632065089|21371 Crestview Rd]-[21371 CRESTVIEW RD]-[21371 CRESTVIEW RD]-[446 HEARTH WAY]-[446 HEARTH WAY|21371 Crestview Rd|Reno       |NV          |Non-Taxable       |21371 CRESTVIEW RD|RENO         |NV            |Non-Taxable         |21371 CRESTVIEW RD|RENO      |NV         |446 HEARTH WAY|PITTSBURG   |CA           |Non-Taxable        |446 HEARTH WAY|PITTSBURG   |CA           |NULL  |NULL   |
-- +-------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+----------------------------------------------------------------------------------------------+------------------+-----------+------------+------------------+------------------+-------------+--------------+--------------------+------------------+----------+-----------+--------------+------------+-------------+-------------------+--------------+------------+-------------+------+-------+

select AT1.CREATION_DT,T1.* from GNRC.ADDRESS_DIM T1
         JOIN AUDIT_TBL AT1 on T1.INSERT_AUDIT_KEY = AT1.AUDIT_KEY
         where ADDRESS_LINE1_TX in (upper('21371 Crestview Rd'),upper('446 HEARTH WAY'));
-- +--------------------------+-----------+---------+--------+--------+------------------+---------+--------+------------+------------+
-- |CREATION_DT               |ADDRESS_KEY|SOURCE_CD|FIRST_NM|LAST_NM |ADDRESS_LINE1_TX  |CITY_NM  |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
-- +--------------------------+-----------+---------+--------+--------+------------------+---------+--------+------------+------------+
-- |2023-10-30 12:00:07.000000|7586196    |NULL     |RICH    |STOCKAND|21371 CRESTVIEW RD|RENO     |NV      |89521       |6924        |
-- |2024-11-07 06:02:26.000000|8695468    |NCOA     |RICH    |STOCKAND|446 HEARTH WAY    |PITTSBURG|CA      |94565       |5583        |
-- +--------------------------+-----------+---------+--------+--------+------------------+---------+--------+------------+------------+



Select AT1.CREATION_DT,T1.* from GNRC.NCOA_UPDATED_ADDRESS_TBL T1
         JOIN AUDIT_TBL AT1 on T1.INSERT_AUDIT_KEY = AT1.AUDIT_KEY
         where ADDRESS_KEY in (7586196,8695468);
-- +--------------------+--------------------------+-----------+--------------+-------------+----------------------+-------------+--------------+--------------+
-- |NEW_ADDRESS_LINE1_TX|CREATION_DT               |ADDRESS_KEY|INPUT_FIRST_NM|INPUT_LAST_NM|INPUT_ADDRESS_LINE1_TX|INPUT_CITY_NM|INPUT_STATE_CD|INPUT_ZIP_CODE|
-- +--------------------+--------------------------+-----------+--------------+-------------+----------------------+-------------+--------------+--------------+
-- |NULL                |2024-07-03 20:18:33.000000|7586196    |RICH          |STOCKAND     |21371 CRESTVIEW RD    |RENO         |NV            |895216924     |
-- |NULL                |2024-09-06 06:47:21.000000|7586196    |RICH          |STOCKAND     |21371 CRESTVIEW RD    |RENO         |NV            |895216924     |
-- |NULL                |2024-10-09 04:46:48.000000|7586196    |Rich          |Stockand     |21371 Crestview Rd    |Reno         |NV            |89521-6924    |
-- |446 Hearth Way      |2024-11-07 06:21:13.000000|7586196    |Rich          |Stockand     |21371 Crestview Rd    |Reno         |NV            |89521-6924    |
-- +--------------------+--------------------------+-----------+--------------+-------------+----------------------+-------------+--------------+--------------+


Select AT1.CREATION_DT,"fileName" ,COUNT(*) from GNRC.RAW_MELISSA_DATA_TBL T1
         JOIN AUDIT_TBL AT1 on T1.INSERT_AUDIT_KEY = AT1.AUDIT_KEY
GROUP BY "fileName"  ,AT1.CREATION_DT;
+--------------------------+---------------------------------+--------+
|CREATION_DT               |fileName                         |COUNT(*)|
+--------------------------+---------------------------------+--------+
|2024-11-29 02:17:02.000000|AA_GNRC_20241007_144848_FINAL    |234650  |
|2024-11-25 05:34:21.000000|AA_gnrc_20241114_083212_final.txt|259433  |
|2024-12-10 10:49:59.000000|AA_gnrc_20241210_113029_final.txt|209253  |
+--------------------------+---------------------------------+--------+
---NCO_FACT audit key will use in RAW_MELISSA_DATA_TBL for Oct files
-- Same audit key use for RAW_MELISSA_DATA_TBL also

Select AT1.CREATION_DT,T1.* from GNRC.RAW_MELISSA_DATA_TBL T1
         JOIN AUDIT_TBL AT1 on T1.INSERT_AUDIT_KEY = AT1.AUDIT_KEY
         where "StagingID" in (7586196,8695468);
-- +--------------------------+---------+-------------+----------+------------------------------------------------------+-------------+------------------+
-- |CREATION_DT               |StagingID|FileTrackerID|LineItemID|MD_Results                                            |MD_NameFull  |MD_AddressLine1   |
-- +--------------------------+---------+-------------+----------+------------------------------------------------------+-------------+------------------+
-- |2024-11-25 05:34:21.000000|7586196  |20241106     |1         |AS01,AS12,CS02,ES01,GS05,NS01,NS05,VR01,VS12,VS40     |Rich Stockand|446 Hearth Way    |
-- |2024-11-25 05:34:21.000000|7586196  |20241106     |991       |AS01,GS05                                             |             |21371 Crestview Rd|
-- |2024-11-29 02:17:02.000000|7586196  |20241004     |1         |AS01,CS02,ES01,ES21,GS05,NS01,NS05,VR01,VS01,VS12,VS40|Rich Stockand|21371 Crestview Rd|
-- +--------------------------+---------+-------------+----------+------------------------------------------------------+-------------+------------------+


select AT1.CREATION_DT,T1.* from GNRC.CAMPAIGN_SPOOL_FILE_TBL T1
          JOIN AUDIT_TBL AT1 on T1.INSERT_AUDIT_KEY = AT1.AUDIT_KEY
         where  T1.REFERENCE_ID like '011770632065089';
-- +--------------------------+---------------+--------+--------+------------------+-------+--------+------------+------------+
-- |CREATION_DT               |REFERENCE_ID   |FIRST_NM|LAST_NM |ADDRESS_LINE1_TX  |CITY_NM|STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
-- +--------------------------+---------------+--------+--------+------------------+-------+--------+------------+------------+
-- |2024-10-16 12:34:06.000000|011770632065089|RICH    |STOCKAND|21371 CRESTVIEW RD|RENO   |NV      |89521       |6924        |
-- |2024-10-16 12:34:06.000000|011770632065089|RICH    |STOCKAND|21371 CRESTVIEW RD|RENO   |NV      |89521       |6924        |
-- +--------------------------+---------------+--------+--------+------------------+-------+--------+------------+------------+


Select AT1.CREATION_DT,T1.* from GNRC.RAW_LEADS_TBL T1
          JOIN AUDIT_TBL AT1 on T1.INSERT_AUDIT_KEY = AT1.AUDIT_KEY
          JOIN AUDIT_TBL AT1 on T1.INSERT_AUDIT_KEY = AT1.AUDIT_KEY
         where EQUIPMENT like '%3013500322%';
-- +--------------------------+-------------+------------------+----------+-----------+--------------+------------------+-------------------+------------------+---------------+---------+
-- |CREATION_DT               |OWNER_NAME   |OWNER_ADDRESS1    |OWNER_CITY|OWNER_STATE|OWNER_POSTCODE|OWNER_PHONE_NUMBER|OWNER_EMAIL        |EQUIPMENT         |VALID_FROM_DATE|MATERIAL |
-- +--------------------------+-------------+------------------+----------+-----------+--------------+------------------+-------------------+------------------+---------------+---------+
-- |2023-10-30 15:59:35.000000|Rich Stockand|21371 Crestview Rd|Reno      |NV         |89521-6924    |7755309599        |Rstockand@gmail.com|000000003013500322|2023-04-24     |G00722610|
-- +--------------------------+-------------+------------------+----------+-----------+--------------+------------------+-------------------+------------------+---------------+---------+



