--LISA BREMER
select * from
RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA_GNRC_1677
where ORDER_KEY =887163
Order by ORDER_CREATED_TS desc
;

select STATUS,DETAILS,COUNT(*) from
RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA_GNRC_1677
GROUP BY STATUS,DETAILS;
+---------+--------------------------------------------------------------------------+--------+
|STATUS   |DETAILS                                                                   |COUNT(*)|
+---------+--------------------------------------------------------------------------+--------+
|REPROCESS|RAW AND CUSTOMER DIFFERENT OTHER SAME TO RAW                              |14      |
|GOOD     |All Same                                                                  |7       |
|GOOD     |Offer NCOA later corrected Customer so order is good                      |1       |
|CHECK    |RAW,OFFER and Customer same but bill and ship is different                |1       |
|REPROCESS|RAW ,OFFER and SHIP SAME and CUSTOMER and BILL SAME                       |2       |
|CHECK    |BILL is to different than others , BILL to NCOA and others to RAW adddress|1       |
|REPROCESS|RAW DIFFERENT                                                             |25      |
|REPROCESS|RAW AND CUSTOMER DIFFERENT, RAW AND BILL SAME, CUSTOMER AND SHIP SAME     |1       |
|GOOD     |All Same Real Time Offer                                                  |5       |
+---------+--------------------------------------------------------------------------+--------+

select * from GNRC.ADDRESS_DIM where ADDRESS_LINE1_TX = upper('2523 S Fletcher Ave');
-- +-----------+--------+-------+-------------------+----------------+--------+------------+------------+
-- |ADDRESS_KEY|FIRST_NM|LAST_NM|ADDRESS_LINE1_TX   |CITY_NM         |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
-- +-----------+--------+-------+-------------------+----------------+--------+------------+------------+
-- |3057278    |LISA    |BREMER |2523 S FLETCHER AVE|FERNANDINA BEACH|FL      |32034       |2335        |
-- |8600346    |NULL    |NULL   |2523 S FLETCHER AVE|FERNANDINA BEACH|FL      |32034       |2335        |
-- +-----------+--------+-------+-------------------+----------------+--------+------------+------------+
select * from GNRC.NCOA_FCT where ADDRESS_KEY  =3057278 or NEW_ADDRESS_KEY =3057278;

select * from
RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA_GNRC_1677
where     STATUS ='REPROCESS'
Order by ORDER_CREATED_TS desc
;

COMMIT;

select * from
RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA_GNRC_1677
where SALES_SOURCE_CD in ('MAIL_IN_CHECK_SALES','MAIL_IN_CC_SALES','CALL_CENTER_INBOUND_SALES','CALL_CENTER_OUTBOUND_SALES')
--AND NVL(RAW_TAXABLE_STATUS,'XYZ') <> NVL(SHIP_TAXABLE_STATUS,'XYZ')--0
--AND NVL(OFFER_TAXABLE_STATUS,'XYZ') <> NVL(SHIP_TAXABLE_STATUS,'XYZ')--All offer blank--5
Order by ORDER_CREATED_TS desc
;

select * from
RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA_GNRC_1677
where
--AND NVL(RAW_TAXABLE_STATUS,'XYZ') <> NVL(SHIP_TAXABLE_STATUS,'XYZ')--0
NVL(OFFER_TAXABLE_STATUS,'XYZ') <>  'XYZ' AND  NVL(OFFER_TAXABLE_STATUS,'XYZ') <> NVL(SHIP_TAXABLE_STATUS,'XYZ')--All offer blank--5
Order by ORDER_CREATED_TS desc
;
+-------+----------+---------+--------+-----------------------+---------------+--------------+--------------------------+--------------------------+--------------+--------------------------------------------------------------------------------------------------------------+----------------------+-----------+------------+------------------+----------------------+-------------+--------------+--------------------+------------------+-----------+-----------+------------------+------------+-------------+-------------------+------------------+------------+-------------+
|SI_KEY |SERIAL_NO |ORDER_KEY|BRAND_NM|PARENT_CATEGORY_NM     |SALES_SOURCE_CD|MAIL_DROP_DATE|PURCHASE_DT               |ORDER_CREATED_TS          |OFFER_KEY     |RAW_ADD1_OFFER_ADD1_CST_SHIP_BILL                                                                             |RAW_ADD1              |RAW_CITY_NM|RAW_STATE_CD|RAW_TAXABLE_STATUS|OFFER_ADD1            |OFFER_CITY_NM|OFFER_STATE_CD|OFFER_TAXABLE_STATUS|CST               |AD_CITY_NM |AD_STATE_CD|SHIP              |SHIP_CITY_NM|SHIP_STATE_CD|SHIP_TAXABLE_STATUS|BILL              |BILL_CITY_NM|BILL_STATE_CD|
+-------+----------+---------+--------+-----------------------+---------------+--------------+--------------------------+--------------------------+--------------+--------------------------------------------------------------------------------------------------------------+----------------------+-----------+------------+------------------+----------------------+-------------+--------------+--------------------+------------------+-----------+-----------+------------------+------------+-------------+-------------------+------------------+------------+-------------+
|1797084|3011552741|889701   |GENERAC |RESIDENTIAL HKW A/C HSB|EMAIL_WEB_SALES|2024-10-29    |2024-12-04 01:39:27.280000|2024-12-03 20:39:31.616333|11840853065031|1515 MILLS B LANE BLVD]-[1515 MILLS B LANE BLVD]-[701 VALLEY GLEN DR]-[701 VALLEY GLEN DR]-[701 VALLEY GLEN DR|1515 MILLS B LANE BLVD|SAVANNAH   |GA          |Non-Taxable       |1515 MILLS B LANE BLVD|SAVANNAH     |GA            |Non-Taxable         |701 VALLEY GLEN DR|MORRISVILLE|NC         |701 VALLEY GLEN DR|MORRISVILLE |NC           |Taxable            |701 VALLEY GLEN DR|MORRISVILLE |NC           |
+-------+----------+---------+--------+-----------------------+---------------+--------------+--------------------------+--------------------------+--------------+--------------------------------------------------------------------------------------------------------------+----------------------+-----------+------------+------------------+----------------------+-------------+--------------+--------------------+------------------+-----------+-----------+------------------+------------+-------------+-------------------+------------------+------------+-------------+


-- select * from GNRC.SYNC_PROCESS_STATUS_TBL where PROCESS_START_TS > date'2024-12-06'
-- order by PROCESS_START_TS

--create table RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA_GNRC_1677 as (
select distinct  SID.SI_KEY,SID.SERIAL_NO ,OIT.ORDER_KEY
        ,VP.BRAND_NM,VP.PARENT_CATEGORY_NM,OT.SALES_SOURCE_CD,SP.MAIL_DROP_DATE,OT.PURCHASE_DT,ot.ORDER_CREATED_TS,OIT.OFFER_KEY
       ,RLT.OWNER_ADDRESS1 || ']-[' || SP.ADDRESS_LINE1_TX || ']-[' || AD.ADDRESS_LINE1_TX || ']-[' || AD1.ADDRESS_LINE1_TX || ']-[' ||  AD2.ADDRESS_LINE1_TX RAW_Add1_OFFER_Add1_CST_SHIP_BILL
       ,RLT.OWNER_ADDRESS1 RAW_Add1,RLT.OWNER_CITY RAW_CITY_NM ,RLT.OWNER_STATE RAW_STATE_CD,ST3.TAXABLE_STATUS RAW_TAXABLE_STATUS
       ,SP.ADDRESS_LINE1_TX OFFER_Add1,SP.CITY_NM OFFER_CITY_NM ,SP.STATE_CD OFFER_STATE_CD ,ST1.TAXABLE_STATUS OFFER_TAXABLE_STATUS
        ,AD.ADDRESS_LINE1_TX CST,AD.CITY_NM AD_CITY_NM  ,AD.STATE_CD AD_STATE_CD
        ,AD1.ADDRESS_LINE1_TX SHIP,AD1.CITY_NM SHIP_CITY_NM ,AD1.STATE_CD SHIP_STATE_CD ,ST2.TAXABLE_STATUS SHIP_TAXABLE_STATUS
        ,AD2.ADDRESS_LINE1_TX BILL,AD2.CITY_NM BILL_CITY_NM ,AD2.STATE_CD BILL_STATE_CD
        from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RLT
            JOIN GNRC.SERIALIZED_ITEM_DIM SID on SID.SERIAL_NO = LTRIM(TRIM(EQUIPMENT),'0')
            JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = SID.PRODUCT_KEY
            JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY
            JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            JOIN GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = OT.VISITOR_KEY
            JOIN GNRC.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            JOIN GNRC.SHIPPING_INFO_TBL SOT on SOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.BILLING_INFO_TBL BOT on BOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = SOT.ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD2 on AD2.ADDRESS_KEY = BOT.ADDRESS_KEY
--             LEFT JOIN date_dim dd on dd.DATE_KEY = SID.PURCHASE_DT_KEY
--             JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = OIT.INSERT_AUDIT_KEY
            LEFT JOIN GNRC.CAMPAIGN_SPOOL_FILE_TBL SP ON SP.REFERENCE_ID = OIT.OFFER_KEY
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st1 ON ST1.STATE_CD = sP.STATE_CD
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st2 ON st2.STATE_CD = AD1.STATE_CD
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st3 ON st3.STATE_CD = RLT.OWNER_STATE
      where OT.ORDER_CREATED_TS > date '2024-10-01'
  --)
;


select distinct  SID.SI_KEY,SID.SERIAL_NO ,OIT.ORDER_KEY
        ,VP.BRAND_NM,VP.PARENT_CATEGORY_NM,OT.SALES_SOURCE_CD,SP.MAIL_DROP_DATE,OT.PURCHASE_DT,ot.ORDER_CREATED_TS,OIT.OFFER_KEY
       ,RLT.OWNER_ADDRESS1 || ']-[' || SP.ADDRESS_LINE1_TX || ']-[' || AD.ADDRESS_LINE1_TX || ']-[' || AD1.ADDRESS_LINE1_TX || ']-[' ||  AD2.ADDRESS_LINE1_TX RAW_Add1_OFFER_Add1_CST_SHIP_BILL
       ,RLT.OWNER_ADDRESS1 RAW_Add1,RLT.OWNER_CITY RAW_CITY_NM ,RLT.OWNER_STATE RAW_STATE_CD,ST3.TAXABLE_STATUS RAW_TAXABLE_STATUS
       ,SP.ADDRESS_LINE1_TX OFFER_Add1,SP.CITY_NM OFFER_CITY_NM ,SP.STATE_CD OFFER_STATE_CD ,ST1.TAXABLE_STATUS OFFER_TAXABLE_STATUS
        ,AD.ADDRESS_LINE1_TX CST,AD.CITY_NM AD_CITY_NM  ,AD.STATE_CD AD_STATE_CD
        ,AD1.ADDRESS_LINE1_TX SHIP,AD1.CITY_NM SHIP_CITY_NM ,AD1.STATE_CD SHIP_STATE_CD ,ST2.TAXABLE_STATUS SHIP_TAXABLE_STATUS
        ,AD2.ADDRESS_LINE1_TX BILL,AD2.CITY_NM BILL_CITY_NM ,AD2.STATE_CD BILL_STATE_CD
        from GNRC.RAW_LEADS_TBL RLT
            JOIN GNRC.SERIALIZED_ITEM_DIM SID on SID.SERIAL_NO = LTRIM(TRIM(EQUIPMENT),'0')
            JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = SID.PRODUCT_KEY
            JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY
            JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            JOIN GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = OT.VISITOR_KEY
            JOIN GNRC.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            JOIN GNRC.SHIPPING_INFO_TBL SOT on SOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.BILLING_INFO_TBL BOT on BOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = SOT.ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD2 on AD2.ADDRESS_KEY = BOT.ADDRESS_KEY
--             LEFT JOIN date_dim dd on dd.DATE_KEY = SID.PURCHASE_DT_KEY
--             JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = OIT.INSERT_AUDIT_KEY
            LEFT JOIN GNRC.CAMPAIGN_SPOOL_FILE_TBL SP ON SP.REFERENCE_ID = OIT.OFFER_KEY
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st1 ON ST1.STATE_CD = sP.STATE_CD
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st2 ON st2.STATE_CD = AD1.STATE_CD
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st3 ON st3.STATE_CD = RLT.OWNER_STATE
      where OT.ORDER_KEY =887157;
-- +------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+-----------------------------------------------------------------------------------------------------------+----------------+------------+------------------+-------------------+----------------+--------------+--------------------+-------------------+-------------------+----------------+-----------+-------------------+----------------+-------------+-------------------+-------------------+----------------+-------------+
-- |SI_KEY|SERIAL_NO |ORDER_KEY|BRAND_NM|PARENT_CATEGORY_NM     |SALES_SOURCE_CD    |MAIL_DROP_DATE|PURCHASE_DT               |ORDER_CREATED_TS          |OFFER_KEY     |RAW_ADD1_OFFER_ADD1_CST_SHIP_BILL                                                                          |RAW_CITY_NM     |RAW_STATE_CD|RAW_TAXABLE_STATUS|OFFER_ADD1         |OFFER_CITY_NM   |OFFER_STATE_CD|OFFER_TAXABLE_STATUS|RAW_ADD1           |CST                |AD_CITY_NM      |AD_STATE_CD|SHIP               |SHIP_CITY_NM    |SHIP_STATE_CD|SHIP_TAXABLE_STATUS|BILL               |BILL_CITY_NM    |BILL_STATE_CD|
-- +------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+-----------------------------------------------------------------------------------------------------------+----------------+------------+------------------+-------------------+----------------+--------------+--------------------+-------------------+-------------------+----------------+-----------+-------------------+----------------+-------------+-------------------+-------------------+----------------+-------------+
-- |708845|3004568489|887163   |GENERAC |RESIDENTIAL HKW A/C HSB|MAIL_IN_CHECK_SALES|2024-07-16    |2024-11-21 00:00:00.000000|2024-11-21 15:03:36.408409|11187553098646|2523 S Fletcher Ave]-[2523 S FLETCHER AVE]-[2523 S FLETCHER AVE]-[2523 S FLETCHER AVE]-[2523 S FLETCHER AVE|Fernandina Beach|FL          |Taxable           |2523 S FLETCHER AVE|FERNANDINA BEACH|FL            |Taxable             |2523 S Fletcher Ave|2523 S FLETCHER AVE|FERNANDINA BEACH|FL         |2523 S FLETCHER AVE|FERNANDINA BEACH|FL           |Taxable            |2523 S FLETCHER AVE|FERNANDINA BEACH|FL           |
-- +------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+-----------------------------------------------------------------------------------------------------------+----------------+------------+------------------+-------------------+----------------+--------------+--------------------+-------------------+-------------------+----------------+-----------+-------------------+----------------+-------------+-------------------+-------------------+----------------+-------------+

-- +-------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+-----------------------------------------------------------------------------------------+-----------------+-----------+------------+------------------+---------------+-------------+--------------+--------------------+---------------+----------+-----------+---------------+------------+-------------+-------------------+---------------+------------+-------------+
-- |SI_KEY |SERIAL_NO |ORDER_KEY|BRAND_NM|PARENT_CATEGORY_NM     |SALES_SOURCE_CD    |MAIL_DROP_DATE|PURCHASE_DT               |ORDER_CREATED_TS          |OFFER_KEY     |RAW_ADD1_OFFER_ADD1_CST_SHIP_BILL                                                        |RAW_ADD1         |RAW_CITY_NM|RAW_STATE_CD|RAW_TAXABLE_STATUS|OFFER_ADD1     |OFFER_CITY_NM|OFFER_STATE_CD|OFFER_TAXABLE_STATUS|CST            |AD_CITY_NM|AD_STATE_CD|SHIP           |SHIP_CITY_NM|SHIP_STATE_CD|SHIP_TAXABLE_STATUS|BILL           |BILL_CITY_NM|BILL_STATE_CD|
-- +-------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+-----------------------------------------------------------------------------------------+-----------------+-----------+------------+------------------+---------------+-------------+--------------+--------------------+---------------+----------+-----------+---------------+------------+-------------+-------------------+---------------+------------+-------------+
-- |1779771|3013854484|887157   |GENERAC |RESIDENTIAL HKW A/C HSB|MAIL_IN_CHECK_SALES|2024-10-01    |2024-11-21 00:00:00.000000|2024-11-21 15:00:42.570573|11810611065034|210714 SANDY LANE]-[210714 SANDY LN]-[210714 SANDY LN]-[210714 SANDY LN]-[210714 SANDY LN|210714 SANDY LANE|MOSINEE    |WI          |Taxable           |210714 SANDY LN|MOSINEE      |WI            |Taxable             |210714 SANDY LN|MOSINEE   |WI         |210714 SANDY LN|MOSINEE     |WI           |Taxable            |210714 SANDY LN|MOSINEE     |WI           |
-- +-------+----------+---------+--------+-----------------------+-------------------+--------------+--------------------------+--------------------------+--------------+-----------------------------------------------------------------------------------------+-----------------+-----------+------------+------------------+---------------+-------------+--------------+--------------------+---------------+----------+-----------+---------------+------------+-------------+-------------------+---------------+------------+-------------+
