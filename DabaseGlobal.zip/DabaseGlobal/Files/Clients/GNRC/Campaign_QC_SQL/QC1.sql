select GST.EFFORT_NO as Effort, cm.CAMPAIGN_NM as Campaign, cr.WARRANTY_MONTHS as warr_mnth, psd.PRICING_SCHEME_KEY as PS_Key, psd.PRICING_SCHEME_NM, oix.PRICE_BEFORE_DISCOUNT_AMT
       ,COUNT(distinct oix.OFFER_KEY) as offers
        , listagg(distinct oix.POLICY_KEY, ', ') WITHIN GROUP (ORDER BY oix.POLICY_KEY) as POLICY_Keys
from  BUNDLE_DIM bd --  New leads in STG
    JOIN CAMPAIGN_PARTICIPATION_FCT cpf on cpf.BUNDLE_KEY = bd.BUNDLE_KEY
    join gnrc.CRITERIA_CELL_XREF ccx on ccx.CRITERIA_KEY = bd.CRITERIA_KEY and ccx.CELL_KEY = cpf.CELL_KEY
    join gnrc.CRITERIA_DIM cr on cr.CRITERIA_KEY = bd.CRITERIA_KEY
    join gnrc.PRICING_SCHEME_DIM psd on psd.PRICING_SCHEME_KEY = ccx.PRICING_SCHEME_KEY
    join gnrc.CELL_DIM cl on cl.CELL_KEY = cpf.CELL_KEY
    join gnrc.CELL_GROUP_DIM cg on cg.CELL_GROUP_KEY = cl.CELL_GROUP_KEY
    join gnrc.CAMPAIGN_DIM cm on cm.CAMPAIGN_KEY = cg.CAMPAIGN_KEY
    JOIN GNRC.STATE_TBL Gst on Gst.STATE_KEY = cpf.STATE_KEY -- EFFORT_NO
    join OFFER_ITEM_XREF oix on oix.OFFER_KEY = cpf.OFFER_KEY
    join gnrc.POLICY_TBL pol on pol.POLICY_KEY = oix.POLICY_KEY
 where 1=1
   and oix.POLICY_KEY = 143
--    and oix.POLICY_KEY in (167, 410,  143, 412)
--    and bd.DROP_DT < date '2025-08-01'
GROUP BY GST.EFFORT_NO, cm.CAMPAIGN_NM, cr.WARRANTY_MONTHS,  psd.PRICING_SCHEME_KEY, psd.PRICING_SCHEME_NM, oix.PRICE_BEFORE_DISCOUNT_AMT
order by GST.EFFORT_NO, cm.CAMPAIGN_NM, cr.WARRANTY_MONTHS;