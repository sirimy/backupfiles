SELECT COUNT(*) from gnrc.CASH_BATCH_DETAILS_TBL; --31-- batch details EMS [BatchDetails_Monthly_September2024.csv]
SELECT COUNT(*) from gnrc.CASH_EMERCHANT_TRANS_TBL; --4312-- order auth report Emerchant [OrderAuthCCReport.csv]
SELECT COUNT(*) from gnrc.CASH_EMS_TRANS_TBL; --4312-- transaction details EMS [Transaction Details_8.27.2024_9.30.2024.csv]
SELECT COUNT(*) from gnrc.CASH_EMS_DEPOSITS_TBL; --289-- deposit details EMS [DepositDetails_Monthly_September2024.csv]
SELECT COUNT(*) from gnrc.CASH_CHECK_VERIFY_TBL; --1125-- Checking Report from Teddy [Transaction_Results_10_08_2024_13_05_13.csv]


--CASH_BATCH_DETAILS_TBL ==> BatchDetails_Monthly_September2024.csv
--CASH_EMERCHANT_TRANS_TBL ==> OrderAuthCCReport.csv
--CASH_EMS_TRANS_TBL ==> Transaction Details_8.27.2024_9.30.2024.csv
--CASH_EMS_DEPOSITS_TBL ==> DepositDetails_Monthly_September2024.csv
--CASH_CHECK_VERIFY_TBL ==> Transaction_Results_10_08_2024_13_05_13.csv



SELECT COUNT(*) from CASH_BATCH_DETAILS_TBL; --31--
SELECT COUNT(*) from CASH_EMERCHANT_TRANS_TBL; --4312--
SELECT COUNT(*) from CASH_EMS_TRANS_TBL; --4312--
SELECT COUNT(*) from CASH_EMS_DEPOSITS_TBL; --289--
SELECT COUNT(*) from CASH_CHECK_VERIFY_TBL; --1125--



BEGIN
              gnrc.sp_core_merge_cash_working_tables();
end;


--Transaction_Results_11_13_2024_09_03_54.csv

select * from GNRC_CHECKS_DEPOSITED_IN_HUSQ_ACCOUNT;

select CHECK_NUMBER,DEPOSIT_DT,AMOUNT ,INSERT_AUDIT_KEY from CASH_CHECK_VERIFY_TBL;

insert into CASH_CHECK_VERIFY_TBL
(CHECK_NUMBER,DEPOSIT_DT,AMOUNT)
select CHECK_NUMBER  ,
    DEPOSIT_DT    ,
    AMOUNT  from GNRC_CHECKS_DEPOSITED_IN_HUSQ_ACCOUNT;





select CHECK_NUMBER,DEPOSIT_DT,AMOUNT ,INSERT_AUDIT_KEY from GNRC.CASH_CHECK_VERIFY_TBL;

select COUNT(*) from GNRC.CASH_CHECK_VERIFY_TBL;--1267
