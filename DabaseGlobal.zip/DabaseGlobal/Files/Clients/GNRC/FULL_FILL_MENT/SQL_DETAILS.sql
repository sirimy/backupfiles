
Select T2.*,T1.* from (
    select to_char(trunc(process_dt), 'YYYY-MM') MONTH_FL, count(*) CNT_FL, count(ERROR_DESC) CNT_ER_FL from gnrc.contract_fulfillment_tbl
    where trunc(process_dt) >= date '2025-01-01'
    group by to_char(trunc(process_dt), 'YYYY-MM') order by to_char(trunc(process_dt), 'YYYY-MM')
) T1
LEFT JOIN (
        select  to_char(trunc(process_dt), 'YYYY-MM') MONTH_SL, count(*) CNT_SL, count(ERROR_DESC) CNT_ER_SL  from gnrc.SALES_EXTRACT_FILE_TBL
        where trunc(process_dt) >= date '2025-01-01'
        group by to_char(trunc(process_dt), 'YYYY-MM') order by to_char(trunc(process_dt), 'YYYY-MM')
) T2 ON T1.MONTH_FL = T2.MONTH_SL
;
-- +--------+------+---------+--------+------+---------+
-- |MONTH_SL|CNT_SL|CNT_ER_SL|MONTH_FL|CNT_FL|CNT_ER_FL|
-- +--------+------+---------+--------+------+---------+
-- |2025-01 |3539  |0        |2025-01 |2900  |0        |
-- |2025-02 |3275  |0        |2025-02 |3332  |0        |
-- |2025-03 |3716  |0        |2025-03 |3348  |0        |
-- |2025-04 |2718  |0        |2025-04 |3612  |4        |
-- |2025-05 |3106  |0        |2025-05 |2346  |4        |
-- |2025-06 |3157  |0        |2025-06 |2849  |2        |
-- |2025-07 |3468  |0        |2025-07 |2208  |0        |
-- |2025-08 |2797  |0        |2025-08 |4383  |8        |
-- |2025-09 |3513  |0        |2025-09 |3284  |1        |
-- |2025-10 |3539  |0        |2025-10 |3905  |7        |
-- |2025-11 |2140  |0        |2025-11 |302   |0        |
-- +--------+------+---------+--------+------+---------+





select sl.PROCESS_DT ,r.R_CREATION_DT,r.FILE_NM, count(distinct sl.CONTRACT_NO) as sent_con, count(distinct r.SALES_DOCUMENT) as conf_con, count(distinct t1.CONTRACT_XID) as CONTRACT_XID
,t1.CONTRACT_STATUS_KEY AS STATUS_KEY,count(t1.CONTRACT_STATUS_KEY) CNT_STATUS,COUNT(CFT.CONTRACT_NO) FULL_NO
, count(distinct v.CONTRACT_NO) as CONTRACT_NO_UN_CONFIRMED
  from gnrc.SALES_EXTRACT_FILE_TBL sl
       left join (select * from (
                            select ATB.CREATION_DT R_CREATION_DT,r.*, row_number() over (partition by r.SALES_DOCUMENT order by r.INSERT_AUDIT_KEY) rno
                              from gnrc.RAW_CONTRACT_TBL r
                                    JOIN AUDIT_TBL ATB on ATB.AUDIT_KEY = r.INSERT_AUDIT_KEY
                             where r.ERROR_DESC is null and r.EQUIPMENT is not null and r.SALES_DOCUMENT is not null) r
                   where rno = 1
                ) r
            on sl.CONTRACT_NO = r.SALES_DOCUMENT
       left  join (
                Select LKP.*,CD.CONTRACT_STATUS_KEY from GNRC.CONTRACT_DIM CD
                        JOIN GNRC.CONTRACT_LKP LKP ON CD.CONTRACT_KEY = LKP.CONTRACT_KEY
            ) t1 on t1.CONTRACT_XID = r.SALES_DOCUMENT AND t1.SOURCE_SYSTEM_CD = 0
       left join gnrcStg.v_unconfirmed_sales v on v.CONTRACT_NO = r.SALES_DOCUMENT
       left join    GNRC.CONTRACT_FULFILLMENT_TBL  CFT on CFT.CONTRACT_NO = r.SALES_DOCUMENT
 where 1=1
   and sl.ERROR_DESC is null and sl.PROCESS_DT >= date '2025-10-17' and sl.PROCESS_DT < trunc(sysdate) - 5

 group by sl.PROCESS_DT, r.FILE_NM,t1.CONTRACT_STATUS_KEY ,r.R_CREATION_DT
 order by sl.PROCESS_DT ,r.R_CREATION_DT, r.FILE_NM;
-- +-------------------+--------------------------+-----------------------------------------------------+--------+--------+------------+----------+----------+-------+------------------------+
-- |PROCESS_DT         |R_CREATION_DT             |FILE_NM                                              |SENT_CON|CONF_CON|CONTRACT_XID|STATUS_KEY|CNT_STATUS|FULL_NO|CONTRACT_NO_UN_CONFIRMED|
-- +-------------------+--------------------------+-----------------------------------------------------+--------+--------+------------+----------+----------+-------+------------------------+
-- |2025-10-20 10:05:05|2025-10-24 01:01:38.000000|grnr_after_sales-entry-export_2025-10-23_07-00-00.txt|357     |357     |357         |1         |357       |357    |0                       |
-- |2025-10-20 10:05:05|2025-10-24 01:01:38.000000|grnr_after_sales-entry-export_2025-10-23_07-00-00.txt|5       |5       |5           |2         |5         |3      |0                       |
-- |2025-10-23 10:05:04|2025-10-28 01:01:32.000000|grnr_after_sales-entry-export_2025-10-27_07-00-00.txt|465     |465     |465         |1         |465       |465    |0                       |
-- |2025-10-23 10:05:04|2025-10-28 01:01:32.000000|grnr_after_sales-entry-export_2025-10-27_07-00-00.txt|3       |3       |3           |2         |3         |0      |0                       |
-- |2025-10-27 10:05:07|2025-11-04 02:01:33.000000|grnr_after_sales-entry-export_2025-11-03_07-00-00.txt|37      |37      |37          |1         |37        |37     |0                       |
-- |2025-10-27 10:05:07|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|314     |314     |314         |1         |314       |0      |0                       |
-- |2025-10-27 10:05:07|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|1       |1       |1           |2         |1         |0      |0                       |
-- |2025-10-30 10:05:05|2025-11-04 02:01:33.000000|grnr_after_sales-entry-export_2025-11-03_07-00-00.txt|55      |55      |55          |1         |55        |55     |0                       |
-- |2025-10-30 10:05:05|2025-11-04 02:01:33.000000|grnr_after_sales-entry-export_2025-11-03_07-00-00.txt|1       |1       |1           |2         |1         |1      |0                       |
-- |2025-10-30 10:05:05|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|425     |425     |425         |1         |425       |0      |0                       |
-- |2025-10-30 10:05:05|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|1       |1       |1           |2         |1         |0      |0                       |
-- |2025-11-03 11:05:06|2025-11-07 02:01:31.000000|grnr_after_sales-entry-export_2025-11-06_07-00-00.txt|37      |37      |37          |1         |37        |37     |0                       |
-- |2025-11-03 11:05:06|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|309     |309     |309         |1         |309       |0      |0                       |
-- |2025-11-06 11:05:05|2025-11-11 02:01:39.000000|grnr_after_sales-entry-export_2025-11-10_07-00-00.txt|62      |62      |62          |1         |62        |62     |0                       |
-- |2025-11-06 11:05:05|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|338     |338     |338         |1         |338       |0      |0                       |
-- |2025-11-06 11:05:05|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|3       |3       |3           |2         |3         |0      |0                       |
-- |2025-11-10 11:05:05|2025-11-14 02:01:38.000000|grnr_after_sales-entry-export_2025-11-13_07-00-00.txt|56      |56      |56          |1         |56        |56     |0                       |
-- |2025-11-10 11:05:05|2025-11-14 02:01:38.000000|grnr_after_sales-entry-export_2025-11-13_07-00-00.txt|1       |1       |1           |2         |1         |0      |0                       |
-- |2025-11-10 11:05:05|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|284     |284     |284         |1         |284       |0      |0                       |
-- |2025-11-13 11:05:04|2025-11-18 02:01:30.000000|grnr_after_sales-entry-export_2025-11-17_07-00-00.txt|54      |54      |54          |1         |54        |54     |0                       |
-- |2025-11-13 11:05:04|2025-11-21 02:01:30.000000|grnr_after_sales-entry-export_2025-11-20_07-00-00.txt|306     |306     |306         |1         |306       |0      |0                       |
-- +-------------------+--------------------------+-----------------------------------------------------+--------+--------+------------+----------+----------+-------+------------------------+

