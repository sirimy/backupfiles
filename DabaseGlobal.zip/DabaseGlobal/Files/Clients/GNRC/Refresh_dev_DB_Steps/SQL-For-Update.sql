--SQLs to use to update email tables in DEV Web:----

--Close all unnecessary editors in DataGrip to avoid any accidents or confusion.

select max(purchase_dt), max(created_ts), count(*) from order_tbl;
--  +--------------------------+--------------------------+------+
-- |max                       |max                       |count |
-- +--------------------------+--------------------------+------+
-- |2024-08-25 05:17:53.058000|2024-08-25 05:17:56.658000|192327|
-- +--------------------------+--------------------------+------+


---------------------------------------------------------------------------------------
--Email Clean-Up
---------------------------------------------------------------------------------------
--Have a look at email data in Web
---------------------------------------------------------------------------------------
select * from email_tbl order by random() limit 10;

select count(*) from  email_tbl;
--1402687

select * from email_tbl
 where
        (email_address_tx like '%AFTERINC.COM'
           or email_address_tx like '%FULCRM.COM'
           or email_address_tx like '%DOMESTICANDGENERAL.COM'
--            or email_address_tx like '%NOWHERE.COM'
        )
order by email_address_tx;
--26 rows

select distinct email_address_tx from email_tbl
 where
        (email_address_tx like '%AFTERINC.COM'
           or email_address_tx like '%FULCRM.COM'
           or email_address_tx like '%NOWHERE.COM'
          )
order by email_address_tx;
--22 rows
---------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------
--Update emails
---------------------------------------------------------------------------------------
--following update is meant to be run in Dev whenever it is refreshed using data from prod
update email_tbl
   set email_address_tx = email_id::text ||  '@NOWHERE.COM'
 where
       NOT (email_address_tx like '%AFTERINC.COM'
           or email_address_tx like '%FULCRM.COM'
           or email_address_tx like '%DOMESTICANDGENERAL.COM'
           or email_address_tx like '%NOWHERE.COM'
          )
   and email_address_tx is not null;
-- 1,357,969 rows affected in 2 m 57 s 473 ms

commit;

select  email_address_tx from email_tbl
 where
        not (email_address_tx like '%AFTERINC.COM'
           or email_address_tx like '%FULCRM.COM'
           or email_address_tx like '%NOWHERE.COM'
          )
order by random()
limit 100;


select * from email_tbl_audit where last_updated_ts >= current_date limit 10;
select count(*) from email_tbl_audit where last_updated_ts >= current_date and email_address_tx like '%NOWHERE.COM';
--1357969
delete from email_tbl_audit where last_updated_ts >= current_date and email_address_tx like '%NOWHERE.COM';
-- 1,357,969 rows affected in 12 s 653 ms
commit;
---------------------------------------------------------------------------------------

