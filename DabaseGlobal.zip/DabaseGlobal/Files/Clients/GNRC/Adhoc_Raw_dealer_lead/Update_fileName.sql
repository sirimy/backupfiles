

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'CCS-19657', p_table_nm => 'RAW_DEALER_LEADS_TBL');
BEGIN

        update  RAW_DEALER_LEADS_TBL
            SET  INSERT_AUDIT_KEY = v_audit_key,FILE_NM = 'Generac_After_Leads_ExtWarranty_adhoc_2025-10-13-00-00-00.txt'
        where 1 = 1;

       DBMS_OUTPUT.PUT_LINE(v_audit_key);
       DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );

       COMMIT;

END;
