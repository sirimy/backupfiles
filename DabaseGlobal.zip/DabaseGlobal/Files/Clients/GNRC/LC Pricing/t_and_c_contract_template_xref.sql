--               ------------------------------------------------------------------------------
--              Creating t_and_c_contract_template_xref data for commercial generator policies
--              ------------------------------------------------------------------------------
            insert
               into t_and_c_contract_template_xref (

                    CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY,
                    EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY, TC_CONT_TEMP_XREF_KEY,
                    COUNTRY_KEY, SEQ_NO
                    )
            select CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
                   , POSTAL_STATE_KEY,
                    EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY,
                    p_t_and_c_xref_seq.nextval as TC_CONT_TEMP_XREF_KEY,
                    COUNTRY_KEY, SEQ_NO
               from (
                     select
                        CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
                        , psd.POSTAL_STATE_KEY,
                        pol.EFFECTIVE_DT, tc.Exp_Dt AS END_DT, 'Y' AS ACTIVE_IND, NULL AS CHANNEL_PARTNER_KEY
                        , psd.COUNTRY_KEY
                        , ROW_NUMBER() OVER( PARTITION BY CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, pol.EFFECTIVE_DT
                              ORDER BY postal_state_key) as SEQ_NO
                    from gnrc.terms_and_conditions_dim tc
                          cross join gnrc.POSTAL_STATE_DIM psd
                           cross join gnrc.contract_template_tbl ctl   --this will be a placeholder only for Generac
                            cross join (
                                  select policy_key, pol.name, policy_group_key, pol.EFFECTIVE_DT
                                         ,(nvl(day, 0) + (nvl(month, 0) *30) + (nvl(year, 0) * 365))/365 AS Term_Year
                                         ,pex.PARENT_PRODUCT_CATEGORY, pex.description
                                    from policy_tbl pol
                                         join policy_ext_tbl pex using (policy_key)
                                         join gnrc.term_dim tr using (term_key)
                                   where pex.PARENT_PRODUCT_CATEGORY  = 'RESIDENTIAL GASEOUS L/C HSB 1'  and pex.COUNTRY = 'USA'
                                  ) pol
                              LEFT JOIN gnrc.COUNTRY_TBL ct ON (ct.country_3byte_cd = psd.country_iso)
                    where
                        exp_dt = date '2099-12-31'
                     and psd.country_iso = 'en_US'
                     and postal_state_cd NOT IN ('AE', 'AP', 'AA', 'NA', 'PR', 'VI')
                     and tc.NAME = 'Generac USA Terms & Conditions'
                     and pol.PARENT_PRODUCT_CATEGORY = 'RESIDENTIAL GASEOUS L/C HSB 1'
                     and (terms_and_conditions_key, policy_key, postal_state_key) NOT IN
                            (select tcx.terms_and_conditions_key, tcx.policy_key, tcx.postal_state_key
                               from gnrc.T_AND_C_CONTRACT_TEMPLATE_XREF tcx
                            )
                    order by TERMS_AND_CONDITIONS_KEY, POLICY_KEY
                    );
