

select COUNT(*) from product_price_dim_temp;--636

select  pex.COUNTRY, vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, min(to_number(vp.KW)), max(to_number(vp.KW)),
        tr.NAME, ppd.BASE_PRICE_AMT
        ,COUNT(*), count(distinct vp.MODEL_NO) MODELs
from   product_price_dim_temp ppd
       join gnrc.V_PRODUCT vp on vp.PRODUCT_KEY = ppd.PRODUCT_KEY
       join policy_tbl pol on (pol.policy_key = ppd.policy_key)
       join policy_ext_tbl pex on (pol.policy_key = pex.policy_key)
       join p_term_dim tr using (term_key)
group by pex.COUNTRY, vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, tr.NAME, ppd.BASE_PRICE_AMT
order by vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, ppd.BASE_PRICE_AMT
;
+-------+--------+-----------------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
|COUNTRY|BRAND_NM|PARENT_CATEGORY_NM           |MIN_KW|MAX_KW|MIN(TO_NUMBER(VP.KW))|MAX(TO_NUMBER(VP.KW))|NAME   |BASE_PRICE_AMT|COUNT(*)|MODELS|
+-------+--------+-----------------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|22    |60    |20                   |130                  |5 Year |750.0000      |162     |54    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|22    |60    |20                   |130                  |7 Year |1065.0000     |216     |54    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|22    |60    |20                   |130                  |10 Year|1485.0000     |270     |54    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|70    |150   |20                   |130                  |5 Year |1065.0000     |162     |54    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|70    |150   |20                   |130                  |7 Year |1485.0000     |216     |54    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|70    |150   |20                   |130                  |10 Year|2115.0000     |270     |54    |
+-------+--------+-----------------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+

+-------+--------+-----------------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
|COUNTRY|BRAND_NM|PARENT_CATEGORY_NM           |MIN_KW|MAX_KW|MIN(TO_NUMBER(VP.KW))|MAX(TO_NUMBER(VP.KW))|NAME   |BASE_PRICE_AMT|COUNT(*)|MODELS|
+-------+--------+-----------------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|22    |60    |22                   |60                   |5 Year |750.0000      |123     |41    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|22    |60    |22                   |60                   |7 Year |1065.0000     |164     |41    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|22    |60    |22                   |60                   |10 Year|1485.0000     |205     |41    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|70    |150   |70                   |130                  |5 Year |1065.0000     |36      |12    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|70    |150   |70                   |130                  |7 Year |1485.0000     |48      |12    |
|USA    |GENERAC |RESIDENTIAL GASEOUS L/C HSB 1|70    |150   |70                   |130                  |10 Year|2115.0000     |60      |12    |
+-------+--------+-----------------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+

select *  from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr where  pr.parent_category_nm IN ('RESIDENTIAL GASEOUS L/C HSB 1');