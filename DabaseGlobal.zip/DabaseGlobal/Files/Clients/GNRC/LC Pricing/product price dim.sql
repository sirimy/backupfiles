



    --AM and MPOS
             --Pricing data for HSBs
             INSERT
                INTO product_price_dim_temp (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,0 as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL GASEOUS L/C HSB 1')
                                join policy_tbl pol using (policy_key)
                                 JOIN gnrc.term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM gnrc.PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from gnrc.PRICING_SCHEME_DIM psd2  WHERE psd2.PRICING_SCHEME_nm LIKE 'AM')
                                       AND psd.PRICING_SCHEME_nm LIKE 'AM'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN gnrc.policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units in 1st or 2nd year of coverage'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          and pr.parent_category_nm IN ('RESIDENTIAL GASEOUS L/C HSB 1')
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );



          --AM for RE
             INSERT
                INTO product_price_dim_temp (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               , 0  as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL GASEOUS L/C HSB 1')
                                join policy_tbl pol using (policy_key)
                                 JOIN p_term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM P_PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from P_PRICING_SCHEME_DIM psd2 where UPPER(psd2.PRICING_SCHEME_nm) = 'AM FOR RE')
                                       AND PSD.END_DT >= current_date
                                       AND UPPER(psd.PRICING_SCHEME_nm) =  'AM FOR RE'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN p_policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units in 1st or 2nd year of coverage'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          and pr.parent_category_nm IN ('RESIDENTIAL GASEOUS L/C HSB 1')
                          and nvl(pr.do_not_solicit_product_ind, 'N') <> 'Y'
                          and nvl(pr.do_not_solicit_category_ind, 'N') <> 'Y'
                          and nvl(pr.do_not_solicit_brand_ind, 'N') <> 'Y'
                          and pol.EXP_DT >= trunc(sysdate)
                          and p_ext.country = 'USA'   --since there are similar policies for Canada also
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );




         --AM for RW
             INSERT
                INTO product_price_dim_temp (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               , 0  as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL GASEOUS L/C HSB 1')
                                join policy_tbl pol using (policy_key)
                                 JOIN p_term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM P_PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from P_PRICING_SCHEME_DIM psd2 where UPPER(psd2.PRICING_SCHEME_nm) = 'AM FOR RW')
                                       AND PSD.END_DT >= current_date
                                       AND UPPER(psd.PRICING_SCHEME_nm) =  'AM FOR RW'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN p_policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units in 1st or 2nd year of coverage'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          and pr.parent_category_nm IN ('RESIDENTIAL GASEOUS L/C HSB 1')
                          and nvl(pr.do_not_solicit_product_ind, 'N') <> 'Y'
                          and nvl(pr.do_not_solicit_category_ind, 'N') <> 'Y'
                          and nvl(pr.do_not_solicit_brand_ind, 'N') <> 'Y'
                          and pol.EXP_DT >= trunc(sysdate)
                          and p_ext.country = 'USA'   --since there are similar policies for Canada also
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );


    --AM and MPOS
             --Pricing data for AM and MPOS HSB - 7 & 10 Year Terms
             INSERT
                INTO product_price_dim_temp (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,0 as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL GASEOUS L/C HSB 1')
                                join policy_tbl pol using (policy_key)
                                 JOIN gnrc.term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM gnrc.PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from gnrc.PRICING_SCHEME_DIM psd2  WHERE psd2.PRICING_SCHEME_nm LIKE 'AM and MPOS HSB - 7 & 10 Year Terms')
                                       AND psd.PRICING_SCHEME_nm LIKE 'AM and MPOS HSB - 7 & 10 Year Terms'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN gnrc.policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units in 1st or 2nd year of coverage'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          and tr.DAY in (2555, 3650)   --7 and 10 year term only
                          and pr.parent_category_nm IN ('RESIDENTIAL GASEOUS L/C HSB 1')
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );

 --AM for RE
             --Pricing data for HSBs -- 10 year term only
             --This is used for: Recently Expired - Enhanced Warranty
             INSERT
                INTO product_price_dim_temp (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,0  as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL GASEOUS L/C HSB 1')
                                join policy_tbl pol using (policy_key)
                                 JOIN p_term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM P_PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from P_PRICING_SCHEME_DIM psd2 where psd2.PRICING_SCHEME_nm = 'RE HSB - 10 Year Term Only')
                                       AND PSD.END_DT >= current_date
                                       AND psd.PRICING_SCHEME_nm =  'RE HSB - 10 Year Term Only'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN p_policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units in 1st or 2nd year of coverage'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          and pr.parent_category_nm IN ('RESIDENTIAL GASEOUS L/C HSB 1')
                          and nvl(pr.do_not_solicit_product_ind, 'N') <> 'Y'
                          and nvl(pr.do_not_solicit_category_ind, 'N') <> 'Y'
                          and nvl(pr.do_not_solicit_brand_ind, 'N') <> 'Y'
                          and pol.EXP_DT >= trunc(sysdate)
                          and tr.DAY in (3650)   --10 year term only
                          and p_ext.country = 'USA'   --since there are similar policies for Canada also
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );