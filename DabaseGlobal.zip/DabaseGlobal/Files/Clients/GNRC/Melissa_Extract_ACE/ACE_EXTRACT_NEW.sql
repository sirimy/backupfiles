create view V_ACE_EXTRACT_NEW as
SELECT t."StagingID",
       to_char(CURRENT_TIMESTAMP, 'YYYYMMDD') AS "FileTrackerID",
       row_number() OVER (PARTITION BY t."StagingID" order by t."LastName") AS "LineItemID",
       t."ConsumerName",
       t."Salutation",
       t."FirstName",
       t."MiddleName",
       t."LastName",
       t."Suffix",
       t."BusinessName",
       t."DBAName",
       t."AddressLine1",
       t."AddressLine2",
       t."Locality",
       t."Region",
       t."PostalCode",
       t."Country",
       t."Phone",
       t."EmailAddress"
FROM (

            SELECT t1.unique_seq_no AS "StagingID",
                    ' '             AS "ConsumerName",
                    ' '             AS "Salutation",
			      CASE WHEN EXISTS
                                ( Select * from ACE_BUSINESS_KEYWORDS_TBL ab where ab.NAME_TYPE <> 'UNREAL'
			                                and INSTR(LOWER(((coalesce(t1.first_nm,'') || coalesce(t1.middle_nm,'')) || coalesce(t1.last_nm,'')) || coalesce(t1.firm_nm,'')), LOWER(ab.KEYWORD_NAME)) > 0
			                    )
			                THEN (((coalesce(t1.first_nm,'') || coalesce(t1.middle_nm,'')) || coalesce(t1.last_nm,'')) || coalesce(t1.firm_nm,''))
			                ELSE ''
			           END AS "BusinessName",
			      CASE WHEN EXISTS
                                ( Select * from ACE_BUSINESS_KEYWORDS_TBL ab where ab.NAME_TYPE <> 'UNREAL'
			                                and INSTR(LOWER(((coalesce(t1.first_nm,'') || coalesce(t1.middle_nm,'')) || coalesce(t1.last_nm,'')) || coalesce(t1.firm_nm,'')), LOWER(ab.KEYWORD_NAME)) > 0
			                    )
			                THEN ''
			                ELSE t1.FIRST_NM
			           END AS "FirstName",
			      CASE WHEN EXISTS
                                ( Select * from ACE_BUSINESS_KEYWORDS_TBL ab where ab.NAME_TYPE <> 'UNREAL'
			                                and INSTR(LOWER(((coalesce(t1.first_nm,'') || coalesce(t1.middle_nm,'')) || coalesce(t1.last_nm,'')) || coalesce(t1.firm_nm,'')), LOWER(ab.KEYWORD_NAME)) > 0
			                    )
			                THEN ''
			                ELSE t1.MIDDLE_NM
			           END          AS "MiddleName",
			      CASE WHEN EXISTS
                                ( Select * from ACE_BUSINESS_KEYWORDS_TBL ab where ab.NAME_TYPE <> 'UNREAL'
			                                and INSTR(LOWER(((coalesce(t1.first_nm,'') || coalesce(t1.middle_nm,'')) || coalesce(t1.last_nm,'')) || coalesce(t1.firm_nm,'')), LOWER(ab.KEYWORD_NAME)) > 0
			                    )
			                THEN ''
			                ELSE t1.LAST_NM
			           END            AS "LastName",
			      ' '               AS "Suffix",
			      ' '               AS "DBAName",
			      address_line1_tx  AS "AddressLine1",
			      address_line2_tx  AS "AddressLine2",
			      city_nm           AS "Locality",
			      state_cd          AS "Region",
			      zip_cd_tx         AS "PostalCode",
			      --null zip_code4_tx,
			      DECODE(upper(NVL(t1.primary_phone_ind,'Y')),'Y',t2.phone_no_cleaned)  AS "Phone",
			     -- DECODE(upper(NVL(t1.primary_phone_ind,'Y')),'N',t2.phone_no_cleaned) prior_phone_no,
			      email_address_tx  AS "EmailAddress",
			      country_cd AS "Country"
			FROM	common_load_tbl t1 join common_load_output_tbl t2 on t1.unique_seq_no=t2.unique_seq_no



    ) t
WHERE 1=1
/

