create function fn_real_time_offer(in_customer_id text DEFAULT NULL::text, in_serialized_item_id text DEFAULT NULL::text, in_created_by text DEFAULT 'SYSTEM'::text) returns text
	language plpgsql
as $$
DECLARE

/* Constants */
  c_delay_days     CONSTANT numeric := 1;
  c_offer_exp_dt   CONSTANT OFFER_TBL.OFFER_EXP_UTC_TS%TYPE := LOCALTIMESTAMP + INTERVAL '72' HOUR ; --ELUX-251
  c_offer_start_dt CONSTANT OFFER_TBL.OFFER_START_UTC_TS%TYPE := date_trunc('day', LOCALTIMESTAMP) - INTERVAL '1' DAY ; --FAP-1501
  c_offer_type_cd  CONSTANT VARCHAR(20):='PolicyOffer';

  c_age_admissible_in_months CONSTANT numeric := 120;
  c_max_allowed_term_in_years CONSTANT numeric := 10;


/* Variables */
   v_cnt                numeric;
   v_off_seq            numeric;
   v_in_serial          numeric;
   v_in_customer        numeric;
   v_job_id             numeric;
   v_error_stack 	    text;
   i 			        numeric:=1;

   v_off                text;
   r_rec_type           RECORD;

   sql_query_generac TEXT := 'SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
                             CASE
				WHEN CTS.OFFSET_PURCHASE_DT_IND = 1
				THEN
				   date_trunc(''day'',SI.PURCHASE_DT) + (CTS.DELAY_DAYS * interval ''1 day'')
				WHEN CTS.OFFSET_WARRANTY_EXP_DT_IND = 1
				THEN
				   date_trunc(''day'',SI.WARRANTY_EXPIRATION_DT) + (CTS.DELAY_DAYS * interval ''1 day''  )
			     END AS COVERAGE_START_DT,

			     CASE
				WHEN CTS.OFFSET_PURCHASE_DT_IND = 1
				THEN
				   date_trunc(''day'',SI.PURCHASE_DT) + (CTS.DELAY_DAYS * interval ''1 day'') + (ppt.TERM_MONTHS * interval ''1 month'') - interval  ''1 days''
				WHEN CTS.OFFSET_WARRANTY_EXP_DT_IND = 1
				THEN
				   date_trunc(''day'',SI.WARRANTY_EXPIRATION_DT) + (CTS.DELAY_DAYS * interval ''1 days''  ) + (ppt.TERM_MONTHS * interval ''1 month'') - interval  ''1 days''
			     END AS COVERAGE_END_DT,

			     ppt.BASE_PRICE_AMT,
			     ppt.TERM_MONTHS
			FROM
			(SELECT si.*, cn.country_3byte_cd, coalesce(six.enhanced_warranty_ind, ''N'') as enhanced_warranty_ind, vpr.parent_category_nm, vpr.brand_nm
			   from serialized_item si join ownership_xref ox on ox.serialized_item_id = si.serialized_item_id and ox.current_owner_ind = ''Y''
				join customer_tbl cust on cust.customer_id = ox.customer_id
				join address_tbl adr on adr.address_id = cust.primary_address_id
				join state st on st.state_id = adr.state_id
				join country cn on cn.country_id = st.country_id
			    left join serialized_item_ext six on six.serialized_item_id = si.serialized_item_id
                join v_product vpr on vpr.product_id = si.product_id
                where si.latest_coverage_type_id IN (1,3,6,17,20,2,5,10) and si.serialized_item_id=' || in_serialized_item_id || ') si -- Changed for ticket GNRC-306 ( Allow real time offer creation for generac suppressed serials)
			JOIN pricing_scheme_lkp psl
			   ON (case
                     when si.country_3byte_cd = ''USA'' and si.brand_nm = ''GENERAC'' and si.latest_coverage_type_id IN (1,3,6,17,20,10) and parent_category_nm IN (''RESIDENTIAL HKW A/C HSB'', ''RESIDENTIAL LKW A/C HSB'', ''PORTABLE GAS GENERATORS'', ''RESIDENTIAL GASEOUS L/C HSB 1'')
                     then
                         case
                              when round(extract(DAY from si.warranty_expiration_dt - si.purchase_dt)/30) = 24   --units with 2 year MFG warranty
                                   AND EXTRACT(DAY from (current_date - si.latest_coverage_exp_dt)) >= 827  --unit is at least 118 weeks away from LATEST_COVERAGE_EXP_DT
                                   AND (EXTRACT(DAYS from (current_date - si.purchase_dt))/365) <= 7  -- unit age is less then 7 yrears
                                   then 33   --6th Year
                              when date_part(''YEAR'', current_date) - date_part(''YEAR'', si.purchase_dt) <  5  AND si.latest_coverage_exp_dt >= current_date AND enhanced_warranty_ind = ''N'' then 31    --AI
                              when date_part(''YEAR'', current_date) - date_part(''YEAR'', si.purchase_dt) <  5  AND si.latest_coverage_exp_dt >= current_date AND enhanced_warranty_ind = ''Y'' then 34    --AI Enhanced Warranty
                              when date_part(''YEAR'', current_date) - date_part(''YEAR'', si.purchase_dt) <  4  AND si.latest_coverage_exp_dt <  current_date AND enhanced_warranty_ind = ''N'' then 34    --RE  --7 and 10 year term
                              when date_part(''YEAR'', current_date) - date_part(''YEAR'', si.purchase_dt) <  4  AND si.latest_coverage_exp_dt <  current_date AND enhanced_warranty_ind = ''Y'' then 35    --RE Enhanced Warranty --10 year term only
                              when date_part(''YEAR'', current_date) - date_part(''YEAR'', si.purchase_dt) in (4, 5)  AND si.latest_coverage_exp_dt <  current_date then 34    --RW   --7 and 10 year term
                         end
                     when si.country_3byte_cd = ''USA'' and si.brand_nm = ''GENERAC'' and si.latest_coverage_type_id IN (2,5) AND si.latest_coverage_exp_dt >= current_date - interval ''6 month'' and parent_category_nm IN (''RESIDENTIAL HKW A/C HSB'', ''RESIDENTIAL LKW A/C HSB'', ''PORTABLE GAS GENERATORS'', ''RESIDENTIAL GASEOUS L/C HSB 1'')
                     then
                         case
                              when round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5  then 37    --5 year upgrade
                              when round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7  then 36    --3 year upgrade
                         end
                     when si.country_3byte_cd = ''USA'' and si.brand_nm = ''HONEYWELL'' and si.latest_coverage_type_id IN (1,3,6,17,20,10) and parent_category_nm IN (''RESIDENTIAL HKW A/C HSB'', ''RESIDENTIAL LKW A/C HSB'', ''PORTABLE GAS GENERATORS'', ''RESIDENTIAL GASEOUS L/C HSB 1'')
                     then
                         case
                              when extract(day from current_date - si.purchase_dt) < 1600  AND si.latest_coverage_exp_dt >= current_date AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5 then 34    --offer 7 and 10 year terms --Units with 5 year warranty
                              when extract(day from current_date - si.purchase_dt) between 1601 and 1825 AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5 then 33                                    --Products registered approx from 4.4 up to 5 years ago     --AO 6th year pricing --Units with 5 year warranty
                              when extract(day from current_date - si.purchase_dt) < 2340  AND si.latest_coverage_exp_dt >= current_date AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7 then 35    --offer 10 year term only   --Units with 7 year warranty
                              when extract(day from current_date - si.purchase_dt) between 2341 and 2520 AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7 then 33                                    --Products registered approx from 6.4 up to 7 years ago     --AO 6th year pricing --Units with 7 year warranty
                         end
				     when si.country_3byte_cd = ''CAN'' and si.brand_nm = ''GENERAC'' and si.latest_coverage_type_id IN (1,3,6,17,20) and parent_category_nm IN (''RESIDENTIAL HKW A/C HSB'', ''RESIDENTIAL LKW A/C HSB'', ''PORTABLE GAS GENERATORS'')
                     then
                         case
                              when date_part(''YEAR'', current_date) - date_part(''YEAR'', si.purchase_dt) <  5  AND si.latest_coverage_exp_dt >= current_date then 40    --MPOS & AI
                         end
                     when si.country_3byte_cd = ''CAN'' and si.brand_nm = ''GENERAC'' and si.latest_coverage_type_id IN (2,5) AND si.latest_coverage_exp_dt >= current_date and parent_category_nm IN (''RESIDENTIAL HKW A/C HSB'', ''RESIDENTIAL LKW A/C HSB'', ''RESIDENTIAL GASEOUS L/C HSB 1'')
                     then
                         case
                              when round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5  then 44    --5 year upgrade
                              when round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7  then 43    --3 year upgrade
                         end
                     end = psl.pricing_scheme_id
			      )
			JOIN product_price_tbl ppt
			  ON ( si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id)
			JOIN policy pol
			  ON ( ppt.POLICY_ID = pol.POLICY_ID AND current_date between pol.effective_dt and pol.exp_dt)
			JOIN COVERAGE_TIMING_STRATEGY CTS
			  ON ( cts.coverage_timing_strategy_id = pol.coverage_timing_strategy_id)
		    JOIN product pr
			  ON pr.product_id = ppt.product_id
            JOIN brand br
              ON br.brand_id = pr.brand_id
	WHERE coalesce(pr.do_not_solicit_ind, ''N'') <> ''Y''
    AND   coalesce(br.do_not_solicit_ind, ''N'') <> ''Y''
   ORDER BY ppt.TERM_MONTHS ASC';


BEGIN

   /*******Check if input parameters are integers or not **********/
   BEGIN
        v_in_serial := in_serialized_item_id::numeric;
   EXCEPTION WHEN OTHERS THEN
	PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(STATUS_CD,STATUS_MSG,CREATED_BY)
	VALUES (''E'',''Invalid Serial:'||in_serialized_item_id||''''||','||''''||in_created_by||''')') ;

        RAISE EXCEPTION 'Invalid serial: "%"', in_serialized_item_id;
   END;

   BEGIN
        v_in_customer := in_customer_id::numeric;
   EXCEPTION WHEN OTHERS THEN
	PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(STATUS_CD,STATUS_MSG,CREATED_BY)
	VALUES (''E'',''Invalid Customer:'||in_serialized_item_id||''''||','||''''||in_created_by||''')') ;
        RAISE EXCEPTION 'Invalid customer: "%"', in_customer_id;
    END;



   /******Log  The transaction start  time ******/

   SELECT nextval('job_seq') INTO v_job_id ; --unique identifier to the instance of each job run

   PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
	VALUES ('||v_in_serial||','||v_in_customer||',''S'',''Job Started'','||v_job_id||','||''''||in_created_by||''')') ;



   /***Raise an application error if  input parameters are not passed***/

   IF (coalesce(v_in_serial::numeric, 0) = 0 OR coalesce(v_in_customer::numeric, 0) = 0)
   THEN
        PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
        VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Invalid Serial no or Customer no'','||v_job_id||','||''''||in_created_by||''')') ;
        RAISE EXCEPTION 'Unable to create offer:Invalid Serial or Customer Number'; --v_null_parameter;
   END IF;

   /***Raise an application error if  customer_id doesn't exist in customer tbl***/
   SELECT COUNT (*) INTO v_cnt
   FROM customer_tbl t1
   WHERE t1.customer_id = v_in_customer;

   IF v_cnt = 0
   THEN
        PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
        VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Invalid Customer no'','||v_job_id||','||''''||in_created_by||''')') ;
        RAISE EXCEPTION 'Unable to create offer:Invalid Customer no';  --v_invalid_customer;

   END IF;

   /***Raise an application error if  serial item doesn't exist in serial item tbl***/
   SELECT COUNT (*)
   INTO v_cnt
   FROM serialized_item t1
   WHERE serialized_item_id = v_in_serial;

   IF v_cnt = 0
   THEN

        PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
        VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Invalid Serial no'','||v_job_id||','||''''||in_created_by||''')') ;

        RAISE EXCEPTION 'Unable to create offer:Invalid Serial no'; --v_invalid_serial;
   END IF;


   /*** Raise an Application error if  sysdate-purchase date > c_age_admissible_in_months ***/
   SELECT COUNT (*)
   INTO v_cnt
   FROM serialized_item si
   WHERE     si.serialized_item_id = v_in_serial
   AND
       (SELECT extract( year FROM CURRENT_TIMESTAMP ) - extract( year FROM  purchase_dt )) > (c_age_admissible_in_months/12);

   IF v_cnt > 0
   THEN
        PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
        VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Contracts Not Available on appliances over ''' || c_age_admissible_in_months/12 || ''' years old'','||v_job_id||','||''''||in_created_by||''')') ;

        RAISE EXCEPTION 'Unable to create offer:Contracts not available on appliances over 10 years old'; --v_product_too_old;
   END IF;


   /*** Raise an Application error if  scrap date populated that is not 01/01/1900 ***/
   --Is it specific to elux?
   SELECT COUNT (*) INTO v_cnt
   FROM serialized_item si
   WHERE  si.serialized_item_id = v_in_serial AND coalesce(SCRAP_DT, to_date('1/01/1900', 'MM/DD/YYYY')) <> to_date('1/01/1900', 'MM/DD/YYYY')  ;

   IF v_cnt > 0
   THEN
        PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
        VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Appliance has been scrapped'','||v_job_id||','||''''||in_created_by||''')') ;

        RAISE EXCEPTION 'Unable to create offer:Appliance has been scrapped'; --v_scrapped_appl;
   END IF;


   /*** Raise an error if serial has c_max_allowed_term_in_years year long coverage already, which is the maximum allowed term  ***/
   SELECT COUNT (*)
   INTO   v_cnt
   FROM   serialized_item si
   WHERE  si.serialized_item_id = v_in_serial
   AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) >= c_max_allowed_term_in_years

   ;

   IF v_cnt > 0
   THEN
        PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
        VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Appliance has 10 year long coverage already'','||v_job_id||','||''''||in_created_by||''')') ;
        --VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Appliance has ''' || c_max_allowed_term_in_years || ''' year long coverage already'','||v_job_id||','||''''||in_created_by||''')') ;' ||

        RAISE EXCEPTION 'Unable to create offer:Appliances has 10 year long coverage already'; --v_product_too_old;
   END IF;


   /**Raise an error if a pending/open contract exists for requested serialized_item_id already **/
   --what if last contract has been cancelled?
   SELECT COUNT (*)
     INTO v_cnt
     FROM contract_coverage ccx JOIN contract using (contract_id) join contract_status cs using (contract_status_id)
    WHERE ccx.serialized_item_id = v_in_serial
     AND cs.name  = 'PNDG'   --IN ('ACTV', 'FULF', 'EXP', 'PNDG')
     AND contract_end_dt > current_date

   ;


   IF v_cnt > 0
   THEN
        PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
        VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Contract Already Exists'','||v_job_id||','||''''||in_created_by||''')') ;

        RAISE EXCEPTION 'Unable to create offer: Contract exists already';
   END IF;


   /**Raise an error if an open order exists for requested serialized_item_id already**/
   --We need this check so we don't create another order against a serial with some issues
   SELECT COUNT (*)
     INTO v_cnt
     FROM order_item_tbl oit
           left join contract_order co using (order_id)
           left join contract con using (contract_id)
    WHERE oit.serialized_item_id = v_in_serial
      AND con.client_contract_num is null ;


   IF v_cnt > 0
   THEN
        PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
        VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Order exists already'','||v_job_id||','||''''||in_created_by||''')') ;

        RAISE EXCEPTION 'Unable to create offer: Order exists already';
   END IF;


   /***Following sql checks if an active offer exists for given input else creates a new offer**/
   SELECT COUNT (ot.offer_id)
   INTO v_cnt
   FROM offer_tbl ot
         JOIN offer_item_tbl oit
            ON ot.offer_id = oit.offer_id
   WHERE ot.customer_id = v_in_customer
   AND oit.serialized_item_id = v_in_serial
   AND date_trunc('day', LOCALTIMESTAMP) BETWEEN date_trunc('day', OT.OFFER_START_UTC_TS) and  date_trunc('day', OT.OFFER_EXP_UTC_TS)
   AND UPPER (ot.active_ind) = 'Y'
   AND UPPER (oit.active_ind) = 'Y';

   IF v_cnt = 0
   THEN
    --RAISE NOTICE '%', 'sql_query_generac ' ||  sql_query_generac;
	/**Create a new offer for the passed input**/
	EXECUTE sql_query_generac INTO r_rec_type;
	GET DIAGNOSTICS v_cnt = ROW_COUNT;

	IF v_cnt = 0
	THEN
		/**Raise an application Error if product is not eligible for offer  **/
		PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
		VALUES ('||v_in_serial||','||v_in_customer||',''E'',''Product Not Eligible'','||v_job_id||','||''''||in_created_by||''')') ;

		RAISE EXCEPTION 'Unable to create offer: Product Not Eligible'; --v_inelg_exception;
	ELSE
		SELECT nextval('offer_seq') INTO v_off_seq ;

		INSERT INTO OFFER_TBL (
		       OFFER_ID, CUSTOMER_ID, ACTIVE_IND, DISPLAY_SEQ_NUM, BUNDLE_IND, OFFER_EXP_UTC_TS, OFFER_START_UTC_TS, OFFER_EXP_DT, LAST_UPDATED_TS)
        VALUES (v_off_seq, v_in_customer, 'Y', 1, 'N', c_offer_exp_dt, c_offer_start_dt, c_offer_exp_dt, now());

		/**Log the  offer**/
		INSERT INTO OFFER_LOG_TBL (OFFER_ID, SERIALIZED_ITEM_ID, CUSTOMER_ID, STATUS_CD, STATUS_MSG, JOB_ID, CREATED_BY)
		VALUES (v_off_seq, v_in_serial, v_in_customer, 'F', 'Offer Successfully Created', v_job_id, in_created_by);

		FOR  r_rec_type in EXECUTE format(sql_query_generac) USING in_serialized_item_id
		LOOP
			/**Based on Offer id and above policy_type_id find the seq no**/
			INSERT INTO OFFER_ITEM_TBl (
			                OFFER_ID,
                            OFFER_LINE_ID,
                            OFFER_TYPE_CD,
                            POLICY_ID,
                            SERIALIZED_ITEM_ID,
                            COVERAGE_START_DT,
                            COVERAGE_EXP_DT,
                            PRICE_AMT,
                            DISCOUNT1_PCT,
                            DISCOUNT2_AMT,
                            DISCOUNT2_PCT,
                            ACTIVE_IND,
                            DISPLAY_SEQ_NUM,
                            DISPLAY_GROUP_NUM,
                            FLEXPAYABLE_IND,
                            LAST_UPDATED_TS
                            )
			VALUES (
			            v_off_seq,
                         i,
                         c_offer_type_cd,
                         r_rec_type.POLICY_ID,
                         r_rec_type.SERIALIZED_ITEM_ID,
                         r_rec_type.coverage_start_dt,
                         r_rec_type.coverage_end_dt,
                         r_rec_type.BASE_PRICE_AMT,
                         1,
                         0,
                         0,
                         'Y',
                         i,
                         1,
                         'Y' --ELUX-299 06/08/2015
                         ,now()
                         );

                     -- COMMIT;
                      i := i + 1;

		END LOOP;
	END IF;
   ELSE

      /**Log the   offer**/
      INSERT INTO OFFER_LOG_TBL (SERIALIZED_ITEM_ID, CUSTOMER_ID, STATUS_CD, STATUS_MSG, JOB_ID,CREATED_BY)
      VALUES (v_in_serial,v_in_customer, 'F', 'Offer already exists', v_job_id, in_created_by);

   END IF;


   /**Below module gives the offer id **/

   SELECT DISTINCT string_agg(ot.offer_id::text, ',')
     FROM offer_tbl ot, offer_item_tbl oit
    WHERE ot.offer_id = oit.offer_id
     AND ot.customer_id = v_in_customer
     AND oit.serialized_item_id = v_in_serial
     AND date_trunc('day', LOCALTIMESTAMP) BETWEEN date_trunc('day', OT.OFFER_START_UTC_TS) AND  date_trunc('day', OT.OFFER_EXP_UTC_TS)
     AND UPPER (ot.active_ind) = 'Y'
     AND UPPER (oit.active_ind) = 'Y' INTO v_off;

   RETURN v_off;

   /**EXCEPTION HANDLING**/
   BEGIN
   EXCEPTION
   WHEN OTHERS
   THEN
	GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;

	PERFORM execute_query('INSERT INTO OFFER_LOG_TBL(SERIALIZED_ITEM_ID,CUSTOMER_ID,STATUS_CD,STATUS_MSG,JOB_ID,CREATED_BY)
	VALUES ('||v_in_serial||','||v_in_customer||',''E'','||SUBSTR(v_error_stack,1,3000)||','||v_job_id||','||''''||in_created_by||''')') ;

        RAISE EXCEPTION 'Unable to create offer:UNKNOWN APPLICATION ERROR';
   END;


END;
$$;

alter function fn_real_time_offer(text, text, text) owner to gnrcexlwweb;

