
select COUNT(* )from RAW_DEALER_LEADS_TBL;--1839

BEGIN PKG_RAW_DEALER_LEADS.prc_populate_common_load; END;

select COUNT(* )from COMMON_LOAD_HOLD_TBL;--1816

select COUNT(* )from COMMON_LOAD_TBL;--1816


select COUNT(* )from ADDRESS_OUTPUT_TBL;--0
select COUNT(* )from SI_OUTPUT_TBL;--0
select COUNT(* )from CUSTOMER_OUTPUT_TBL;--0
--
-- DECLARE
--        v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC-1699-PROD', p_table_nm => 'RAW_LEADS_TBL');
-- BEGIN
--     Insert into RAW_LEADS_TBL
--          select
--                RLT.owner_name, owner_address1, owner_city, owner_state, owner_postcode, owner_phone_number, owner_email, equipment,
--                valid_from_date, material, material_name, purchase_date, product_hier_level1, product_hier_level1_name, product_hier_level2,
--                product_hier_level2_name, master_warranty_number, master_warranty_desc, warranty_start_date, min_warranty_end_dt,
--                max_warranty_end_dt, notification_count,
--                'GNRC-1699-PROD', v_audit_key,
--                error_desc, product_hire_level3, product_hire_level_3_name, sales_office, NULL
--          from BAD_ADDRESS_REPROCESS_GNRC_1699_PROD AD1
--                  JOIN (select * from (
--                          select rlt.*, row_number() over (partition by LTRIM(TRIM(RLT.EQUIPMENT), '0') order by rlt.INSERT_AUDIT_KEY desc) rno
--                            from GNRC.RAW_LEADS_TBL RLT
--                         ) RLT
--                      where RLT.rno = 1
--                      ) RLT
--                     ON  (   AD1.SERIAL_NO = LTRIM(TRIM(RLT.EQUIPMENT),'0')
--                         )
--         Where AD1.SERIAL_NO in ( select LTRIM(TRIM(NVL(EQUIPMENT,'x')),'0') from GNRC.RAW_LEADS_TBL
--                                 where LTRIM(TRIM(NVL(EQUIPMENT,'x')),'0') not in (select LTRIM(TRIM(NVL(EQUIPMENT,'x')),'0') from GNRC.RAW_DEALER_LEADS_TBL)
--                            ) ;
--        COMMIT;
--
-- END;



select COUNT(*) CNT from DS_ACE_OUTPUT_TBL;--1816

select SUBSTR(ACE_ERROR_CD,1,1) CD,COUNT(*) CNT, ROUND((COUNT(*)/1816)*100,2) PERC from DS_ACE_OUTPUT_TBL
group by SUBSTR(ACE_ERROR_CD,1,1);
-- +--+----+-----+
-- |CD|CNT |PERC |
-- +--+----+-----+
-- |E |1680|92.51|
-- |S |136 |7.49 |
-- +--+----+-----+

select COUNT(*) from SERIALIZED_ITEM_DIM SI1;--26603

select
--     SI1.SI_KEY,SI1.SERIAL_NO
--      ,SI1.LATEST_COVERAGE_EXP_DT OLD, SI2.LATEST_COVERAGE_EXP_DT NEW
--      ,SI1.LATEST_COVERAGE_TYPE OLD, SI2.LATEST_COVERAGE_TYPE NEW
    SI1.LATEST_COVERAGE_TYPE old , SI2.LATEST_COVERAGE_TYPE new,COUNT(*)
from SERIALIZED_ITEM_DIM SI1
join GNRC.SERIALIZED_ITEM_DIM SI2 on SI1.SERIAL_NO = SI2.SERIAL_NO
Where
    SI1.PURCHASE_DT_KEY <> SI2.PURCHASE_DT_KEY--0
 OR SI1.REGISTRATION_DT <> SI2.REGISTRATION_DT--0
OR SI1.LATEST_COVERAGE_EXP_DT <> SI2.LATEST_COVERAGE_EXP_DT --0
--  OR SI1.WARRANTY_EXPIRATION_DT <> SI2.WARRANTY_EXPIRATION_DT--1
 OR SI1.LATEST_COVERAGE_EXP_DT <> SI2.LATEST_COVERAGE_EXP_DT--0
 OR SI1.LATEST_COVERAGE_TYPE <> SI2.LATEST_COVERAGE_TYPE --0
 GROUP BY SI1.LATEST_COVERAGE_TYPE , SI2.LATEST_COVERAGE_TYPE
;
--
-- +--------------------------+--------------------------+--------+
-- |OLD.c|NEW WARRANTY_EXPIRATION_DT|COUNT(*)|
-- +--------------------------+--------------------------+--------+
-- |2021-11-04 00:00:00.000000|2021-11-05 00:00:00.000000|1       |
-- +--------------------------+--------------------------+--------+

select distinct TEN_YEAR_COVERAGE_IND from SERIALIZED_ITEM_EXT_DIM;

select
    COUNT(*),SI1.PURCHASE_DT,SI2.PURCHASE_DT
from SERIALIZED_ITEM_EXT_DIM SI1
    join GNRC.SERIALIZED_ITEM_EXT_DIM SI2 on SI1.SI_KEY = SI2.SI_KEY
Where
    --SI1.VALID_FROM_DATE <> SI2.VALID_FROM_DATE--0
    --SI1.MASTER_WARRANTY_NUMBER <> SI2.MASTER_WARRANTY_NUMBER--0
    --SI1.WARRANTY_START_DATE <> SI2.WARRANTY_START_DATE--0
    --SI1.MAX_WARRANTY_END_DT <> SI2.MAX_WARRANTY_END_DT--7
    SI1.PURCHASE_DT <> SI2.PURCHASE_DT--0
 GROUP BY SI1.PURCHASE_DT , SI2.PURCHASE_DT;



select
    COUNT(*),SI1.TEN_YEAR_COVERAGE_IND,SI2.TEN_YEAR_COVERAGE_IND
from SERIALIZED_ITEM_EXT_DIM SI1
    join GNRC.SERIALIZED_ITEM_EXT_DIM SI2 on SI1.SI_KEY = SI2.SI_KEY
Where
    --SI1.SALES_OFFICE = SI2.SALES_OFFICE--0
    --SI1.ENHANCED_WARRANTY_IND = SI2.ENHANCED_WARRANTY_IND--0
    SI1.TEN_YEAR_COVERAGE_IND <> SI2.TEN_YEAR_COVERAGE_IND--All NULL
 GROUP BY SI1.TEN_YEAR_COVERAGE_IND , SI2.TEN_YEAR_COVERAGE_IND;



select LATEST_COVERAGE_TYPE,COUNT(*)
from SERIALIZED_ITEM_DIM
GROUP BY LATEST_COVERAGE_TYPE
;
-- +--------------------+--------+
-- |LATEST_COVERAGE_TYPE|COUNT(*)|
-- +--------------------+--------+
-- |1                   |26603   |
-- +--------------------+--------+

select  SI1.LATEST_COVERAGE_TYPE new,COUNT(*)
from SERIALIZED_ITEM_DIM SI1
join GNRC.SERIALIZED_ITEM_DIM SI2 on SI1.SERIAL_NO = SI2.SERIAL_NO
 GROUP BY   SI1.LATEST_COVERAGE_TYPE
;
+---+--------+
|NEW|COUNT(*)|
+---+--------+
|5  |1816    |
+---+--------+


--update serialized_item_dim to match with core (for existing records)
merge into serialized_item_dim tgt
using (
       select * from GNRC.serialized_item_dim src
      ) src
      on (src.si_key = tgt.si_key)
when matched then
update
set
    tgt.latest_coverage_type    = src.latest_coverage_type
where (  src.latest_coverage_type     <> tgt.latest_coverage_type     --
    );
--  rows
commit;
-- +--------------------+--------+
-- |LATEST_COVERAGE_TYPE|COUNT(*)|
-- +--------------------+--------+
-- |7                   |13      |
-- |1                   |25128   |
-- |18                  |1443    |
-- |3                   |4       |
-- |19                  |15      |
-- +--------------------+--------+

select COUNT(*) from   SERIALIZED_ITEM_DIM SI1
join GNRC.SERIALIZED_ITEM_DIM SI2 on SI1.SERIAL_NO = SI2.SERIAL_NO
Where
    SI1.PURCHASE_DT_KEY <> SI2.PURCHASE_DT_KEY--0
 OR SI1.REGISTRATION_DT <> SI2.REGISTRATION_DT--0
--OR SI1.LATEST_COVERAGE_EXP_DT <> SI2.LATEST_COVERAGE_EXP_DT --4
-- OR SI1.WARRANTY_EXPIRATION_DT <> SI2.WARRANTY_EXPIRATION_DT--2
--OR SI1.LATEST_COVERAGE_EXP_DT <> SI2.LATEST_COVERAGE_EXP_DT--4
 OR SI1.LATEST_COVERAGE_TYPE <> SI2.LATEST_COVERAGE_TYPE --1475
 --LATEST_COVERAGE_TYPE
-- +---+---+--------+
-- |OLD|NEW|COUNT(*)|
-- +---+---+--------+
-- |1  |7  |13      |
-- |1  |18 |1443    |
-- |1  |3  |4       |
-- |1  |19 |15      |
-- +---+---+--------+


select COUNT(*) from   CUSTOMER_DIM CS1
join GNRC.CUSTOMER_DIM CS2 on CS1.CUSTOMER_KEY = CS2.CUSTOMER_KEY
Where
 --   CS1.PRIMARY_ADDRESS_KEY <> CS2.PRIMARY_ADDRESS_KEY --3942
  --CS1.PRIMARY_EMAIL_KEY <> CS2.PRIMARY_EMAIL_KEY -- 5
  CS1.PRIMARY_PHONE_KEY <> CS2.PRIMARY_PHONE_KEY -- 10;

select
    --AD1.ACE_ERROR_CD ,AD2.ACE_ERROR_CD, AD1.FIRST_NM,AD1.LAST_NM ,AD1.ADDRESS_LINE1_TX, AD2.FIRST_NM,AD2.LAST_NM ,AD2.ADDRESS_LINE1_TX
*
from   CUSTOMER_DIM CS1 order by CUSTOMER_KEY desc;

select
    --AD1.ACE_ERROR_CD ,AD2.ACE_ERROR_CD, AD1.FIRST_NM,AD1.LAST_NM ,AD1.ADDRESS_LINE1_TX, AD2.FIRST_NM,AD2.LAST_NM ,AD2.ADDRESS_LINE1_TX
--COUNT(*)
from   CUSTOMER_DIM CS1
join GNRC.CUSTOMER_DIM CS2 on CS1.CUSTOMER_KEY = CS2.CUSTOMER_KEY
join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = CS1.PRIMARY_ADDRESS_KEY
join GNRC.ADDRESS_DIM AD2 on AD2.ADDRESS_KEY = CS2.PRIMARY_ADDRESS_KEY
Where
   CS1.PRIMARY_ADDRESS_KEY <> CS2.PRIMARY_ADDRESS_KEY
--AD1.ACE_ERROR_CD <> AD2.ACE_ERROR_CD
--AND NVL(AD1.ADDRESS_LINE1_TX,'X') <> NVL(AD2.ADDRESS_LINE1_TX,'x')
ORDER BY DBMS_RANDOM.RANDOM();
--3942

select * from ADDRESS_DIM where ADDRESS_KEY not in (select AD2.ADDRESS_KEY from GNRC.ADDRESS_DIM AD2  )
Order by DBMS_RANDOM.RANDOM();


 select count(*) from address_dim
 union all
 select count(*) from address_dim where ADDRESS_KEY in (select c.ADDRESS_KEY from GNRC.address_dim c)
 union all
 select count(*) from address_dim where ADDRESS_KEY not in (select c.ADDRESS_KEY from GNRC.address_dim c);
-- +--------+
-- |COUNT(*)|
-- +--------+
-- |1805    |
-- |1654    |
-- |151     |
-- +--------+

 select count(*) from customer_dim
 union all
 select count(*) from customer_dim where customer_key in (select c.customer_key from GNRC.customer_dim c)
 union all
 select count(*) from customer_dim where customer_key not in (select c.customer_key from GNRC.customer_dim c);
-- +--------+
-- |COUNT(*)|
-- +--------+
-- |1801    |
-- |1795    |
-- |6       |
-- +--------+


select count(*) from serialized_item_dim
union all
select count(*) from serialized_item_dim where si_key IN (select si.si_key from GNRC.serialized_item_dim si )
union all
select count(*) from serialized_item_dim where si_key NOT IN (select si.si_key from GNRC.serialized_item_dim si );
-- +--------+
-- |COUNT(*)|
-- +--------+
-- |1816    |
-- |1816    |
-- |0       |
-- +--------+

 select * from RAW_DEALER_LEADS_TBL;--1839

         select COUNT(*)
         from BAD_ADDRESS_REPROCESS_GNRC_1699_PROD AD1
                 JOIN (select * from (
                         select rlt.*, row_number() over (partition by LTRIM(TRIM(RLT.EQUIPMENT), '0') order by rlt.INSERT_AUDIT_KEY desc) rno
                           from GNRC.RAW_DEALER_LEADS_TBL RLT
                        ) RLT
                     where RLT.rno = 1
                     ) RLT
                    ON  (   AD1.SERIAL_NO = LTRIM(TRIM(RLT.EQUIPMENT),'0')
                        )
        Where AD1.SERIAL_NO in (select LTRIM(TRIM(NVL(EQUIPMENT,'x')),'0') from GNRC.RAW_DEALER_LEADS_TBL) ;--1839

