
select
      COUNT(distinct si.SI_KEY ) CNT --28681
    ,min( ddPURCHASE_DT.FULL_DT ) MINDATE
    --ddPURCHASE_DT.FULL_DT,SI.SI_KEY,(date '2025-01-31' - ddPURCHASE_DT.FULL_DT )/365
   from   gnrc.SERIALIZED_ITEM_DIM si
            left join gnrc.SERIALIZED_ITEM_LKP slkp on si.SI_KEY = slkp.SI_KEY and slkp.SOURCE_SYSTEM_CD = 0
            join gnrc.VISITOR_OWNERSHIP_XREF vox on vox.SI_KEY = si.SI_KEY and PRIMARY_IND = 'Y'
            join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM cs on cs.CUSTOMER_KEY = vd.CUSTOMER_KEY
            join gnrc.ADDRESS_DIM ad on ad.ADDRESS_KEY = cs.PRIMARY_ADDRESS_KEY
            JOIN GNRC.V_PRODUCT VP ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
            join fas.date_dim ddPURCHASE_DT on ddPURCHASE_DT.date_key = si.PURCHASE_DT_KEY
            left join gnrc.VISITOR_LKP VL on VL.VISITOR_KEY = cs.PRIMARY_VISITOR_KEY
            LEFT JOIN p_postal_state_dim psd ON UPPER(TRIM(psd.postal_state_cd)) = UPPER(TRIM(ad.STATE_CD))
            LEFT JOIN p_country_tbl ctry ON ctry.country_key = psd.country_key
   where 1=1
          AND vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'--
          AND ad.COUNTRY_CD = 'USA'--
          and ad.ACE_ERROR_CD like 'E%'--
          and ad.SOURCE_CD is NULL--
          --and (ADDRESS_LINE1_TX is null or not ( regexp_like(ADDRESS_LINE1_TX, '[[:digit:]]')  and   regexp_like(ADDRESS_LINE1_TX, '[[:alpha:]]'))) --
          and VP.DO_NOT_SOLICIT_PRODUCT_IND = 'N' -- Model is not DNS
          and (date '2025-01-31' - ddPURCHASE_DT.FULL_DT )/365 <= 6 -- Total Length from purchase date is less than 6 year by using Jan 31st is less than equal to purchase date + 6 years
          and si.LATEST_COVERAGE_TYPE not in (6,21)-- latest coverage type not in (6,21)
          -- Check how many coverage type 20
        order by ddPURCHASE_DT.FULL_DT asc;


select
      COUNT(distinct si.SI_KEY ) CNT --28681
    ,min( ddPURCHASE_DT.FULL_DT ) MINDATE
    --ddPURCHASE_DT.FULL_DT,SI.SI_KEY,(date '2025-01-31' - ddPURCHASE_DT.FULL_DT )/365
   from   gnrc.SERIALIZED_ITEM_DIM si
            left join gnrc.SERIALIZED_ITEM_LKP slkp on si.SI_KEY = slkp.SI_KEY and slkp.SOURCE_SYSTEM_CD = 0
            join gnrc.VISITOR_OWNERSHIP_XREF vox on vox.SI_KEY = si.SI_KEY and PRIMARY_IND = 'Y'
            join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM cs on cs.CUSTOMER_KEY = vd.CUSTOMER_KEY
            join gnrc.ADDRESS_DIM ad on ad.ADDRESS_KEY = cs.PRIMARY_ADDRESS_KEY
            JOIN GNRC.V_PRODUCT VP ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
            join fas.date_dim ddPURCHASE_DT on ddPURCHASE_DT.date_key = si.PURCHASE_DT_KEY
            left join gnrc.VISITOR_LKP VL on VL.VISITOR_KEY = cs.PRIMARY_VISITOR_KEY
            LEFT JOIN p_postal_state_dim psd ON UPPER(TRIM(psd.postal_state_cd)) = UPPER(TRIM(ad.STATE_CD))
            LEFT JOIN p_country_tbl ctry ON ctry.country_key = psd.country_key
   where 1=1
          AND vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'--
          AND ad.COUNTRY_CD = 'USA'--
          and ad.ACE_ERROR_CD like 'E%'--
          and ad.SOURCE_CD is NULL--
          and (ADDRESS_LINE1_TX is null or not ( regexp_like(ADDRESS_LINE1_TX, '[[:digit:]]')  and   regexp_like(ADDRESS_LINE1_TX, '[[:alpha:]]'))) --
          and VP.DO_NOT_SOLICIT_PRODUCT_IND = 'N' -- Model is not DNS
          and (date '2025-01-31' - ddPURCHASE_DT.FULL_DT )/365 <= 6 -- Total Length from purchase date is less than 6 year by using Jan 31st is less than equal to purchase date + 6 years
          and si.LATEST_COVERAGE_TYPE not in (6,21)-- latest coverage type not in (6,21)
          -- Check how many coverage type 20
        order by ddPURCHASE_DT.FULL_DT asc;