--leads where PURCHASE_DATE is missing
select * from RAW_DEALER_LEADS_MISSING_MODELS_TBL_20230810 where PURCHASE_DATE is null order by DBMS_RANDOM.RANDOM(); --11 rows

--leads with MIN_WARRANTY_END_DT in a leap year
select * from RAW_DEALER_LEADS_MISSING_MODELS_TBL_20230810 where extract(month from MIN_WARRANTY_END_DT) = 2 and extract(day from MIN_WARRANTY_END_DT) = 29; --none

--populating raw dealer leads into a temp table while converting dates to char
insert into RAW_DEALER_LEADS_MISSING_MODELS_TBL_22_20230810
select OWNER_NAME,
       OWNER_ADDRESS1,
       OWNER_CITY,
       OWNER_STATE,
       OWNER_POSTCODE,
       OWNER_PHONE_NUMBER,
       OWNER_EMAIL,
       EQUIPMENT,
       to_char(VALID_FROM_DATE, 'YYYY-MM-DD'),
       MATERIAL,
       MATERIAL_NAME,
       to_char(PURCHASE_DATE, 'YYYY-MM-DD'),
       PRODUCT_HIER_LEVEL1,
       PRODUCT_HIER_LEVEL1_NAME,
       PRODUCT_HIER_LEVEL2,
       PRODUCT_HIER_LEVEL2_NAME,
       MASTER_WARRANTY_NUMBER,
       MASTER_WARRANTY_DESC,
       to_char(WARRANTY_START_DATE, 'YYYY-MM-DD'),
       to_char(MIN_WARRANTY_END_DT, 'YYYY-MM-DD'),
       to_char(MAX_WARRANTY_END_DT, 'YYYY-MM-DD'),
       NOTIFICATION_COUNT,
       FILE_NM,
       INSERT_AUDIT_KEY,
       ERROR_DESC,
       PRODUCT_HIRE_LEVEL3,
       PRODUCT_HIRE_LEVEL_3_NAME,
       SALES_OFFICE,
       UNIQUE_SEQ_NO,
       to_char(EXTENDED_WARRANTY_END_DATE, 'YYYY-MM-DD')
from RAW_DEALER_LEADS_MISSING_MODELS_TBL_20230810;
--16305
commit;

select * from RAW_DEALER_LEADS_MISSING_MODELS_TBL_22_20230810 order by DBMS_RANDOM.RANDOM();
select * from RAW_DEALER_LEADS_MISSING_MODELS_TBL_22_20230810 where PURCHASE_DATE is null;  --11 rows

--Replacing first char/digit of year from 0 to 2 to fix the issue where leading digit of the year was 0
update RAW_DEALER_LEADS_MISSING_MODELS_TBL_22_20230810
   set VALID_FROM_DATE     = case when VALID_FROM_DATE is not null then '2' || substr(VALID_FROM_DATE, 2) end,
       PURCHASE_DATE       = case when PURCHASE_DATE is not null then '2' || substr(PURCHASE_DATE, 2) end,
       WARRANTY_START_DATE = case when WARRANTY_START_DATE is not null then '2' || substr(WARRANTY_START_DATE, 2)  end,
       MIN_WARRANTY_END_DT = case when MIN_WARRANTY_END_DT is not null then '2' || substr(MIN_WARRANTY_END_DT, 2)  end,
       MAX_WARRANTY_END_DT = case when MAX_WARRANTY_END_DT is not null then '2' || substr(MAX_WARRANTY_END_DT, 2)  end,
       EXTENDED_WARRANTY_END_DATE = case when EXTENDED_WARRANTY_END_DATE is not null then '2' || substr(EXTENDED_WARRANTY_END_DATE, 2)  end;
--16305
commit;

select * from RAW_DEALER_LEADS_MISSING_MODELS_TBL_22_20230810 order by DBMS_RANDOM.RANDOM();

--again populating raw dealer leads into another temp table while converting date columns from char to date
insert into RAW_DEALER_LEADS_MISSING_MODELS_TBL_33_20230810
select OWNER_NAME,
       OWNER_ADDRESS1,
       OWNER_CITY,
       OWNER_STATE,
       OWNER_POSTCODE,
       OWNER_PHONE_NUMBER,
       OWNER_EMAIL,
       EQUIPMENT,
        to_date(VALID_FROM_DATE, 'YYYY-MM-DD'),
       MATERIAL,
       MATERIAL_NAME,
       to_date(PURCHASE_DATE, 'YYYY-MM-DD'),
       PRODUCT_HIER_LEVEL1,
       PRODUCT_HIER_LEVEL1_NAME,
       PRODUCT_HIER_LEVEL2,
       PRODUCT_HIER_LEVEL2_NAME,
       MASTER_WARRANTY_NUMBER,
       MASTER_WARRANTY_DESC,
       to_date(WARRANTY_START_DATE, 'YYYY-MM-DD'),
       to_date(MIN_WARRANTY_END_DT, 'YYYY-MM-DD'),
       to_date(MAX_WARRANTY_END_DT, 'YYYY-MM-DD'),
       NOTIFICATION_COUNT,
       FILE_NM,
       INSERT_AUDIT_KEY,
       ERROR_DESC,
       PRODUCT_HIRE_LEVEL3,
       PRODUCT_HIRE_LEVEL_3_NAME,
       SALES_OFFICE,
       UNIQUE_SEQ_NO,
       to_date(EXTENDED_WARRANTY_END_DATE, 'YYYY-MM-DD')
from RAW_DEALER_LEADS_MISSING_MODELS_TBL_22_20230810;
--16305
COMMIT;

select * from RAW_DEALER_LEADS_MISSING_MODELS_TBL_22_20230810 where length(VALID_FROM_DATE) <> 10 or length(PURCHASE_DATE) <> 10
 or length(WARRANTY_START_DATE) <> 10 or length(MIN_WARRANTY_END_DT) <> 10 or length(MAX_WARRANTY_END_DT) <> 10;
--no rows

--Now dates look good
select * from RAW_DEALER_LEADS_MISSING_MODELS_TBL_33_20230810 order by DBMS_RANDOM.RANDOM();


--dealer leads by country/brand/warranty number/warranty dates
select Country_Cd, brand, MASTER_WARRANTY_NUMBER, MASTER_WARRANTY_DESC, warr_days, ext_warr_days, count(*) as equipments
from (
        select COUNTRY_3BYTE_CD as Country_Cd, case when MATERIAL_NAME like '%HNYWL%' or MATERIAL_NAME like '%HNYW%' then 'HONEYWELL' else 'GENERAC' end as brand,
                MASTER_WARRANTY_NUMBER, MASTER_WARRANTY_DESC,
                MIN_WARRANTY_END_DT - WARRANTY_START_DATE as warr_days,
                EXTENDED_WARRANTY_END_DATE - WARRANTY_START_DATE as ext_warr_days
        --        count(distinct Equipment) as Unique_Equipments
        from   RAW_DEALER_LEADS_MISSING_MODELS_TBL_33_20230810 r left join audit_tbl a on (audit_key = insert_audit_key)
               left join p_postal_state_dim psd on (psd.postal_state_cd = r.owner_state)
               left join P_COUNTRY_TBL cn on cn.COUNTRY_KEY = psd.COUNTRY_KEY
        where  1=1
        )
group by Country_Cd, brand, MASTER_WARRANTY_NUMBER, MASTER_WARRANTY_DESC, warr_days, ext_warr_days
order by Country_Cd, brand, MASTER_WARRANTY_NUMBER, MASTER_WARRANTY_DESC, warr_days, ext_warr_days;


--There is only 1 record with bad dates
select * from RAW_DEALER_LEADS_MISSING_MODELS_TBL_33_20230810 where MIN_WARRANTY_END_DT - WARRANTY_START_DATE < 1;