-- select * from RAW_LEADS_MISSING_MODELS_TBL where PURCHASE_DATE is null and OWNER_NAME is null and OWNER_ADDRESS1 is null and EQUIPMENT is null;
-- delete from RAW_LEADS_MISSING_MODELS_TBL where PURCHASE_DATE is null and OWNER_NAME is null and OWNER_ADDRESS1 is null and EQUIPMENT is null;
-- commit;

select * from RAW_LEADS_MISSING_MODELS_TBL_20230810 where PURCHASE_DATE is null order by DBMS_RANDOM.RANDOM(); --87 rows

select distinct extract(month from WARRANTY_START_DATE), extract(day from WARRANTY_START_DATE) from RAW_LEADS_MISSING_MODELS_TBL_20230810 order by 1, 2;
select distinct extract(month from MIN_WARRANTY_END_DT), extract(day from MIN_WARRANTY_END_DT) from RAW_LEADS_MISSING_MODELS_TBL_20230810 order by 1, 2;

select * from RAW_LEADS_MISSING_MODELS_TBL_20230810 where extract(month from MIN_WARRANTY_END_DT) = 2 and extract(day from MIN_WARRANTY_END_DT) = 29;  --may rows

--populating leads to a temp table while converting dates to char
insert into RAW_LEADS_MISSING_MODELS_TBL_22_20230810
select OWNER_NAME,
       OWNER_ADDRESS1,
       OWNER_CITY,
       OWNER_STATE,
       OWNER_POSTCODE,
       OWNER_PHONE_NUMBER,
       OWNER_EMAIL,
       EQUIPMENT,
       to_char(VALID_FROM_DATE, 'YYYY-MM-DD'),
       MATERIAL,
       MATERIAL_NAME,
       to_char(PURCHASE_DATE, 'YYYY-MM-DD'),
       PRODUCT_HIER_LEVEL1,
       PRODUCT_HIER_LEVEL1_NAME,
       PRODUCT_HIER_LEVEL2,
       PRODUCT_HIER_LEVEL2_NAME,
       MASTER_WARRANTY_NUMBER,
       MASTER_WARRANTY_DESC,
       to_char(WARRANTY_START_DATE, 'YYYY-MM-DD'),
       to_char(MIN_WARRANTY_END_DT, 'YYYY-MM-DD'),
       to_char(MAX_WARRANTY_END_DT, 'YYYY-MM-DD'),
       NOTIFICATION_COUNT,
       FILE_NM,
       INSERT_AUDIT_KEY,
       ERROR_DESC,
       PRODUCT_HIRE_LEVEL3,
       PRODUCT_HIRE_LEVEL_3_NAME,
       SALES_OFFICE,
       UNIQUE_SEQ_NO
from RAW_LEADS_MISSING_MODELS_TBL_20230810;
--219456
commit;

select * from RAW_LEADS_MISSING_MODELS_TBL_22_20230810;

--populating leads to a temp table while replacing first char/digit of the year of the date columns as leading digits of year were 0s
insert into RAW_LEADS_MISSING_MODELS_TBL_33_20230810
select OWNER_NAME,
       OWNER_ADDRESS1,
       OWNER_CITY,
       OWNER_STATE,
       OWNER_POSTCODE,
       OWNER_PHONE_NUMBER,
       OWNER_EMAIL,
       EQUIPMENT,
        '2' || substr(VALID_FROM_DATE, 2),
       MATERIAL,
       MATERIAL_NAME,
        '2' || substr(PURCHASE_DATE, 2),
       PRODUCT_HIER_LEVEL1,
       PRODUCT_HIER_LEVEL1_NAME,
       PRODUCT_HIER_LEVEL2,
       PRODUCT_HIER_LEVEL2_NAME,
       MASTER_WARRANTY_NUMBER,
       MASTER_WARRANTY_DESC,
        '2' || substr(WARRANTY_START_DATE, 2),
        '2' || substr(MIN_WARRANTY_END_DT, 2),
        '2' || substr(MAX_WARRANTY_END_DT, 2),
       NOTIFICATION_COUNT,
       FILE_NM,
       INSERT_AUDIT_KEY,
       ERROR_DESC,
       PRODUCT_HIRE_LEVEL3,
       PRODUCT_HIRE_LEVEL_3_NAME,
       SALES_OFFICE,
       UNIQUE_SEQ_NO
from RAW_LEADS_MISSING_MODELS_TBL_22_20230810
-- order by DBMS_RANDOM.RANDOM()
;
commit;

select * from RAW_LEADS_MISSING_MODELS_TBL_33_20230810 order by DBMS_RANDOM.RANDOM();

select * from RAW_LEADS_MISSING_MODELS_TBL_33_20230810 where length(VALID_FROM_DATE) <> 10 or length(PURCHASE_DATE) <> 10
 or length(WARRANTY_START_DATE) <> 10 or length(MIN_WARRANTY_END_DT) <> 10 or length(MAX_WARRANTY_END_DT) <> 10;

--there were records where PURCHASE_DATE was null
update RAW_LEADS_MISSING_MODELS_TBL_33_20230810 set PURCHASE_DATE = null where PURCHASE_DATE = '2';
--87 rows
commit;


--populating leads to a temp table while converting date columns from char to date
insert into RAW_LEADS_MISSING_MODELS_TBL_44_20230810
select OWNER_NAME,
       OWNER_ADDRESS1,
       OWNER_CITY,
       OWNER_STATE,
       OWNER_POSTCODE,
       OWNER_PHONE_NUMBER,
       OWNER_EMAIL,
       EQUIPMENT,
       to_date(VALID_FROM_DATE, 'YYYY-MM-DD'),
       MATERIAL,
       MATERIAL_NAME,
       to_date(PURCHASE_DATE, 'YYYY-MM-DD'),
       PRODUCT_HIER_LEVEL1,
       PRODUCT_HIER_LEVEL1_NAME,
       PRODUCT_HIER_LEVEL2,
       PRODUCT_HIER_LEVEL2_NAME,
       MASTER_WARRANTY_NUMBER,
       MASTER_WARRANTY_DESC,
       to_date(WARRANTY_START_DATE, 'YYYY-MM-DD'),
       to_date(MIN_WARRANTY_END_DT, 'YYYY-MM-DD'),
       to_date(MAX_WARRANTY_END_DT, 'YYYY-MM-DD'),
       NOTIFICATION_COUNT,
       FILE_NM,
       INSERT_AUDIT_KEY,
       ERROR_DESC,
       PRODUCT_HIRE_LEVEL3,
       PRODUCT_HIRE_LEVEL_3_NAME,
       SALES_OFFICE,
       UNIQUE_SEQ_NO
from RAW_LEADS_MISSING_MODELS_TBL_33_20230810;
--219456
commit;


--looks good now
select * from RAW_LEADS_MISSING_MODELS_TBL_44_20230810 order by DBMS_RANDOM.RANDOM();


--Counts by country/brand/warranty type/warranty days
select Country_Cd, brand, MASTER_WARRANTY_NUMBER, MASTER_WARRANTY_DESC, warr_days, count(*) as equipments
from (
        select COUNTRY_3BYTE_CD as Country_Cd, case when MATERIAL_NAME like '%HNYWL%' or MATERIAL_NAME like '%HNYW%' then 'HONEYWELL' else 'GENERAC' end as brand,
                MASTER_WARRANTY_NUMBER, MASTER_WARRANTY_DESC,
                MIN_WARRANTY_END_DT - WARRANTY_START_DATE as warr_days
        --        count(distinct Equipment) as Unique_Equipments
        from   RAW_LEADS_MISSING_MODELS_TBL_44_20230810 r left join audit_tbl a on (audit_key = insert_audit_key)
               left join p_postal_state_dim psd on (psd.postal_state_cd = r.owner_state)
               left join P_COUNTRY_TBL cn on cn.COUNTRY_KEY = psd.COUNTRY_KEY
        where  1=1
        )
group by Country_Cd, brand, MASTER_WARRANTY_NUMBER, MASTER_WARRANTY_DESC, warr_days
order by Country_Cd, brand, MASTER_WARRANTY_NUMBER, MASTER_WARRANTY_DESC, warr_days;