
select ccx.pricing_scheme_key
  from  gnrc.CRITERIA_CELL_XREF ccx
       join gnrc.criteria_dim cr using (criteria_key)
       left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
       join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
       join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
       join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
 where 1=1
   and active_ind = 'Y'
   and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
   and selection_tbl <> 'v_outbound_universe'
 GROUP BY ccx.pricing_scheme_key
 ;

-- THis SQL use for check pricing scheme used in campaign and in criteria
select
--     distinct CAMPAIGN_NM, cell_nm, ccx.pricing_scheme_key, pricing_scheme_nm,
--                 cell_group_nm, criteria_xid, WARRANTY_MONTHS, LATEST_COVERAGE_TYPE, POPULATION_PCT, CREATION_DT
  ccx.pricing_scheme_key,COUNT(*)
  from  gnrc.CRITERIA_CELL_XREF ccx
       join gnrc.criteria_dim cr using (criteria_key)
       left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
       join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
       join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
       join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
 where 1=1
   and active_ind = 'Y'
   and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
   and selection_tbl <> 'v_outbound_universe'
--    and criteria_xid like 'RE%'
--   and CRITERIA_XID like 'R%'
--   and criteria_xid NOT LIKE '%POR%'
--    and criteria_xid LIKE '%HSB%'
--    and ADDITIONAL_SQL_TXT LIKE '%GNH%'
--    and additional_sql_txt not LIKE '%HNH%'
--    and CELL_NM NOT LIKE '%NCOA%' and CELL_NM NOT LIKE '%GB 1000%'
--    and upper(CELL_NM) LIKE '%CAN%'
    --and ccx.pricing_scheme_key in (31,41,34,40,39)
--    and LATEST_COVERAGE_TYPE = 2
 GROUP BY ccx.pricing_scheme_key
order by --CAMPAIGN_NM, cell_nm,
         ccx.pricing_scheme_key;
-- +------------------+
-- |PRICING_SCHEME_KEY|
-- +------------------+
-- |31                |
-- |34                |
-- |40                |
-- +------------------+


-- THis SQL use for check pricing scheme used in campaign and in criteria
select
    distinct CAMPAIGN_NM, cell_nm, ccx.pricing_scheme_key, pricing_scheme_nm,
                cell_group_nm, criteria_xid, WARRANTY_MONTHS, LATEST_COVERAGE_TYPE, POPULATION_PCT, CREATION_DT

  from  gnrc.CRITERIA_CELL_XREF ccx
       join gnrc.criteria_dim cr using (criteria_key)
       left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
       join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
       join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
       join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
 where 1=1
   and active_ind = 'Y'
   and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
   and selection_tbl <> 'v_outbound_universe'
--    and criteria_xid like 'RE%'
--   and CRITERIA_XID like 'R%'
--   and criteria_xid NOT LIKE '%POR%'
--    and criteria_xid LIKE '%HSB%'
--    and ADDITIONAL_SQL_TXT LIKE '%GNH%'
--    and additional_sql_txt not LIKE '%HNH%'
--    and CELL_NM NOT LIKE '%NCOA%' and CELL_NM NOT LIKE '%GB 1000%'
--    and upper(CELL_NM) LIKE '%CAN%'
    and ccx.pricing_scheme_key in (31,41,34,40,39)
--    and LATEST_COVERAGE_TYPE = 2

order by CAMPAIGN_NM, cell_nm,ccx.pricing_scheme_key;

select PSD1.PRICING_SCHEME_KEY,PSD2.PRICING_SCHEME_KEY,PSD1.END_DT,PSD2.EFFECTIVE_DT,PSD2.END_DT
from GNRC.PRICING_SCHEME_DIM PSD1
         JOIN GNRC.PRICING_SCHEME_DIM PSD2 on PSD1.PRICING_SCHEME_NM = PSD2.PRICING_SCHEME_NM and PSD2.END_DT > sysdate
    where PSD1.PRICING_SCHEME_KEY in (31,34,40); --in (48,34,40);
-- +------------------+------------------+----------+------------+----------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_KEY|END_DT    |EFFECTIVE_DT|END_DT    |
-- +------------------+------------------+----------+------------+----------+
-- |31                |48                |2025-06-30|2025-07-01  |2099-12-31|
-- |34                |49                |2025-06-30|2025-07-01  |2099-12-31|
-- |40                |51                |2025-06-30|2025-07-01  |2099-12-31|
-- +------------------+------------------+----------+------------+----------+



-- THis SQL use for check pricing scheme used in campaign and in criteria
select
--     distinct CAMPAIGN_NM, cell_nm, ccx.pricing_scheme_key, pricing_scheme_nm,
--                 cell_group_nm, criteria_xid, WARRANTY_MONTHS, LATEST_COVERAGE_TYPE, POPULATION_PCT, CREATION_DT
 ccx.pricing_scheme_key,COUNT(*)
  from  gnrc.CRITERIA_CELL_XREF ccx
       join gnrc.criteria_dim cr using (criteria_key)
       left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
       join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
       join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
       join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
 where 1=1
   and active_ind = 'Y'
   and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
   and selection_tbl <> 'v_outbound_universe'
--    and criteria_xid like 'RE%'
--   and CRITERIA_XID like 'R%'
--   and criteria_xid NOT LIKE '%POR%'
--    and criteria_xid LIKE '%HSB%'
--    and ADDITIONAL_SQL_TXT LIKE '%GNH%'
--    and additional_sql_txt not LIKE '%HNH%'
--    and CELL_NM NOT LIKE '%NCOA%' and CELL_NM NOT LIKE '%GB 1000%'
--    and upper(CELL_NM) LIKE '%CAN%'
    and ccx.pricing_scheme_key in (33,42 )
--    and LATEST_COVERAGE_TYPE = 2
 group by ccx.pricing_scheme_key
order by --CAMPAIGN_NM, cell_nm,
         ccx.pricing_scheme_key;
-- +------------------+--------+
-- |PRICING_SCHEME_KEY|COUNT(*)|
-- +------------------+--------+
-- |33                |38      |
-- +------------------+--------+

select PSD1.PRICING_SCHEME_KEY,PSD2.PRICING_SCHEME_KEY,PSD1.END_DT,PSD2.END_DT
from GNRC.PRICING_SCHEME_DIM PSD1
         JOIN GNRC.PRICING_SCHEME_DIM PSD2 on PSD1.PRICING_SCHEME_NM = PSD2.PRICING_SCHEME_NM and PSD2.END_DT > sysdate
    where PSD1.PRICING_SCHEME_KEY in (33,42);
-- +------------------+------------------+----------+----------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_KEY|END_DT    |END_DT    |
-- +------------------+------------------+----------+----------+
-- |33                |46                |2025-06-30|2099-12-31|
-- |42                |47                |2025-06-30|2099-12-31|
-- +------------------+------------------+----------+----------+
create table  CRITERIA_CELL_XREF_PRICING_CHANGES_JULY_2025 as
(select * from  gnrc.CRITERIA_CELL_XREF where pricing_scheme_key in (33,42 ,31,34,40));
commit;


select  old.PRICING_SCHEME_KEY,ccx.PRICING_SCHEME_KEY,COUNT(*) from CRITERIA_CELL_XREF_PRICING_CHANGES_JULY_2025 OLD
    join gnrc.CRITERIA_CELL_XREF ccx on old.CRITERIA_KEY = ccx.CRITERIA_KEY and old.CELL_KEY = ccx.CELL_KEY
where old.PRICING_SCHEME_KEY in (33,42)
group by  old.PRICING_SCHEME_KEY,ccx.PRICING_SCHEME_KEY
;
-- +------------------+------------------+--------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_KEY|COUNT(*)|
-- +------------------+------------------+--------+
-- |33                |46                |38      |
-- |33                |33                |11      |
-- +------------------+------------------+--------+

select COUNT(*) from  gnrc.CRITERIA_CELL_XREF where pricing_scheme_key in (33,42 ,31,34,40);-- 169
select pricing_scheme_key,COUNT(*) from  gnrc.CRITERIA_CELL_XREF where pricing_scheme_key in (33,42 ,31,34,40)
group by pricing_scheme_key
;-- 169
-- +------------------+--------+
-- |PRICING_SCHEME_KEY|COUNT(*)|
-- +------------------+--------+
-- |31                |60      |
-- |40                |9       |
-- |34                |51      |
-- |33                |49      |
-- +------------------+--------+

update gnrc.CRITERIA_CELL_XREF SET pricing_scheme_key =  46 where PRICING_SCHEME_KEY = 33
and (CRITERIA_KEY,CELL_KEY) in (
    select CRITERIA_KEY,CELL_KEY
              from  gnrc.CRITERIA_CELL_XREF ccx
                   join gnrc.criteria_dim cr using (criteria_key)
                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                   join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                   join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                   join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
             where 1=1
               and active_ind = 'Y'
               and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
               and selection_tbl <> 'v_outbound_universe'
                and ccx.pricing_scheme_key in (33,42 )
        );
-- +------------------+------------------+----------+------------+----------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_KEY|END_DT    |EFFECTIVE_DT|END_DT    |
-- +------------------+------------------+----------+------------+----------+
-- |31                |48                |2025-06-30|2025-07-01  |2099-12-31|
-- |34                |49                |2025-06-30|2025-07-01  |2099-12-31|
-- |40                |51                |2025-06-30|2025-07-01  |2099-12-31|
-- +------------------+------------------+----------+------------+----------+

update gnrc.CRITERIA_CELL_XREF SET pricing_scheme_key =  48 where PRICING_SCHEME_KEY = 31
and (CRITERIA_KEY,CELL_KEY) in (
    select CRITERIA_KEY,CELL_KEY
              from  gnrc.CRITERIA_CELL_XREF ccx
                   join gnrc.criteria_dim cr using (criteria_key)
                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                   join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                   join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                   join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
             where 1=1
               and active_ind = 'Y'
               and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
               and selection_tbl <> 'v_outbound_universe'
                and ccx.pricing_scheme_key in (31,34, 40)
        );

update gnrc.CRITERIA_CELL_XREF SET pricing_scheme_key =  49 where PRICING_SCHEME_KEY = 34
and (CRITERIA_KEY,CELL_KEY) in (
    select CRITERIA_KEY,CELL_KEY
              from  gnrc.CRITERIA_CELL_XREF ccx
                   join gnrc.criteria_dim cr using (criteria_key)
                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                   join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                   join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                   join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
             where 1=1
               and active_ind = 'Y'
               and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
               and selection_tbl <> 'v_outbound_universe'
                and ccx.pricing_scheme_key in (31,34, 40)
        );

update gnrc.CRITERIA_CELL_XREF SET pricing_scheme_key =  51 where PRICING_SCHEME_KEY = 40
and (CRITERIA_KEY,CELL_KEY) in (
    select CRITERIA_KEY,CELL_KEY
              from  gnrc.CRITERIA_CELL_XREF ccx
                   join gnrc.criteria_dim cr using (criteria_key)
                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                   join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                   join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                   join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
             where 1=1
               and active_ind = 'Y'
               and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
               and selection_tbl <> 'v_outbound_universe'
                and ccx.pricing_scheme_key in (31,33,42,34, 40)

        );


-- scheme name, active indicator
select  old.PRICING_SCHEME_KEY,ccx.PRICING_SCHEME_KEY,COUNT(*),coalesce(ccx.POPULATION_PCT, 0)  from CRITERIA_CELL_XREF_PRICING_CHANGES_JULY_2025 OLD
    join gnrc.CRITERIA_CELL_XREF ccx on old.CRITERIA_KEY = ccx.CRITERIA_KEY and old.CELL_KEY = ccx.CELL_KEY
where old.PRICING_SCHEME_KEY in (31,34,40)
group by  old.PRICING_SCHEME_KEY,ccx.PRICING_SCHEME_KEY,coalesce(ccx.POPULATION_PCT, 0)
order by old.PRICING_SCHEME_KEY
;
-- +------------------+------------------+--------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_KEY|COUNT(*)|
-- +------------------+------------------+--------+
-- |31                |31                |30      |
-- |31                |48                |30      |
-- |34                |34                |13      |
-- |34                |49                |38      |
-- |40                |40                |2       |
-- |40                |51                |7       |
-- +------------------+------------------+--------+

select old.PRICING_SCHEME_KEY,psd2.PRICING_SCHEME_NM,ccx.PRICING_SCHEME_KEY,psd.PRICING_SCHEME_NM,coalesce(ccx.POPULATION_PCT, 0),active_ind,selection_tbl,COUNT(*)
              from CRITERIA_CELL_XREF_PRICING_CHANGES_JULY_2025 OLD
                   LEFT join gnrc.CRITERIA_CELL_XREF ccx on old.CRITERIA_KEY = ccx.CRITERIA_KEY and old.CELL_KEY = ccx.CELL_KEY
                   LEFT join gnrc.criteria_dim cr on ccx.CRITERIA_KEY = cr.CRITERIA_KEY  --using (criteria_key)
                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                   LEFT join gnrc.cell_dim cl on cl.CELL_KEY = ccx.CELL_KEY  --using (cell_key)
                   LEFT join gnrc.cell_group_dim cg using (cell_group_key)
                   LEFT join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                   LEFT join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
                   LEFT join gnrc.pricing_scheme_dim psd2 on psd2.pricing_scheme_key = OLD.pricing_scheme_key
             where 1=1
                --and old.PRICING_SCHEME_KEY = ccx.PRICING_SCHEME_KEY
                --and old.PRICING_SCHEME_KEY <> ccx.PRICING_SCHEME_KEY
group by  old.PRICING_SCHEME_KEY,psd2.PRICING_SCHEME_NM,ccx.PRICING_SCHEME_KEY,psd.PRICING_SCHEME_NM,coalesce(ccx.POPULATION_PCT, 0),active_ind,selection_tbl
order by old.PRICING_SCHEME_KEY
;