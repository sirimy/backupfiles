
select PSD.PRICING_SCHEME_NM,PEX.COUNTRY,COUNT(distinct VP.PRODUCT_KEY ) PRODUCT_KEY_CNT,COUNT(distinct PRD.POLICY_KEY ) POLICY_KEY_CNT
, listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
, listagg(distinct pex.WHEN_USED,', ') WITHIN GROUP (ORDER BY pl.POLICY_KEY) as POLICY_KEYs
from GNRC.PRODUCT_PRICE_DIM PRD
                JOIN V_PRODUCT VP on PRD.PRODUCT_KEY = VP.PRODUCT_KEY
                JOIN GNRC.PRICING_SCHEME_DIM PSD on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                JOIN GNRC.POLICY_TBL PL on PL.POLICY_KEY = PRD.POLICY_KEY
                JOIN GNRC.POLICY_EXT_TBL PEX on PEX.POLICY_KEY = PL.POLICY_KEY
Where PSD.END_DT > sysdate and PL.EXP_DT > sysdate
AND PRODUCT_CATEGORY_NM  like '%HSB%'
           AND DO_NOT_SOLICIT_BRAND_IND = 'N'
           AND DO_NOT_SOLICIT_CATEGORY_IND = 'N'
           AND DO_NOT_SOLICIT_PRODUCT_IND = 'N'
           AND PRD.PRICING_SCHEME_KEY in (
                                    select ccx.pricing_scheme_key
                                          from  gnrc.CRITERIA_CELL_XREF ccx
                                               join gnrc.criteria_dim cr using (criteria_key)
                                               left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                                               join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                                               join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                                               join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
                                         where 1=1
                                           and active_ind = 'Y'
                                           and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
                                           and selection_tbl <> 'v_outbound_universe'
                                         GROUP BY ccx.pricing_scheme_key
                            )


GROUP BY PSD.PRICING_SCHEME_NM,PEX.COUNTRY;