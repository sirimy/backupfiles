
select  PRICING_SCHEME_KEY, PRICING_SCHEME_NM, age, count(distinct TERM_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
from   P_product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
where
    psd.END_DT > sysdate
group by  PRICING_SCHEME_KEY, PRICING_SCHEME_NM, age
order by  PRICING_SCHEME_NM, PRICING_SCHEME_KEY, age;
-- +------------------+-----------------------------------------------+----+-----------------------+--------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_NM                              |AGE |COUNT(DISTINCTTERM_KEY)|TERMS   |
-- +------------------+-----------------------------------------------+----+-----------------------+--------+
-- |31                |AM                                             |NULL|3                      |5, 7, 10|
-- |41                |AM and MPOS HSB - 5, 7 & 10 Year Terms - CANADA|NULL|3                      |5, 7, 10|
-- |34                |AM and MPOS HSB - 7 & 10 Year Terms            |NULL|2                      |7, 10   |
-- |40                |AM and MPOS HSB - 7 & 10 Year Terms - CANADA   |NULL|2                      |7, 10   |
-- |32                |AM for RE                                      |NULL|3                      |5, 7, 10|
-- |39                |AM for RW                                      |NULL|3                      |5, 7, 10|
-- |0                 |DUMMY                                          |NULL|1                      |0       |
-- |42                |HSB - 6th Year - CANADA                        |NULL|1                      |10      |
-- |35                |RE HSB - 10 Year Term Only                     |NULL|1                      |10      |
-- |33                |SWEEP HSB - 6th Year                           |NULL|1                      |10      |
-- |36                |UP HSB USA - 3 Year Upgrade                    |7   |1                      |10      |
-- |37                |UP HSB USA - 5 Year Upgrade                    |5   |1                      |10      |
-- +------------------+-----------------------------------------------+----+-----------------------+--------+


select  PRICING_SCHEME_KEY, PRICING_SCHEME_NM,psd.EFFECTIVE_DT, age, count(distinct TERM_KEY),Count(distinct pol.POLICY_KEY)
       , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
    , listagg(distinct pol.POLICY_KEY, ', ') WITHIN GROUP (ORDER BY pol.POLICY_KEY) as POLICY_KEYs
from   product_price_dim ppd
       join P_pricing_scheme_dim psd using (pricing_scheme_key)
       join p_policy_tbl pol on (pol.policy_key = ppd.policy_key)
where
    psd.END_DT > sysdate
    --pol.POLICY_PRODUCT_XID = 'ZPD-EXWAR100002'
    --PRICING_SCHEME_NM = 'AM'
    and PRICING_SCHEME_KEY in (48,49,50,51,52)
    --and pol.POLICY_KEY in (143,170)
group by  PRICING_SCHEME_KEY, PRICING_SCHEME_NM, age,psd.EFFECTIVE_DT
order by  PRICING_SCHEME_NM, PRICING_SCHEME_KEY, age;