
Select * from (
    select
            RLT1.*
    from (select * from (
                 select rlt.*, row_number() over (partition by LTRIM(TRIM(RLT.EQUIPMENT), '0') order by rlt.INSERT_AUDIT_KEY desc) rno
                   from GNRC.RAW_LEADS_TBL RLT
                )RLT where  RLT.rno =2 and
                            RLT.ERROR_DESC is NULL
                            and RLT.FILE_NM not like '%adhoc%'
                            and RLT.FILE_NM not like '%GNRC-%'
                            and RLT.FILE_NM not like '%ncoa_customer_handling_%'
                            and RLT.FILE_NM not like '%histor%'
                            and RLT.FILE_NM not like '%with%'
                            and (RLT.FILE_NM like '%gnrc_after_leads_2%'    )
                  )
        RLT1
         JOIN (select * from (
                 select rlt.*, row_number() over (partition by LTRIM(TRIM(RLT.EQUIPMENT), '0') order by rlt.INSERT_AUDIT_KEY desc) rno
                   from GNRC.RAW_LEADS_TBL RLT
                ) RLT
             where RLT.rno = 1 and
                     RLT.ERROR_DESC is NULL
                    and RLT.FILE_NM not like '%adhoc%'
                    and RLT.FILE_NM not like '%GNRC-%'
                    and RLT.FILE_NM not like '%ncoa_customer_handling_%'
                    and RLT.FILE_NM not like '%histor%'
                    and RLT.FILE_NM not like '%with%'
                    and (RLT.FILE_NM like '%gnrc_after_leads_2%'    )
                    and LTRIM(TRIM(RLT.EQUIPMENT), '0') in (
                                                                select SERIAL_NO from (
                                                                select   LTRIM(TRIM(RLT10.EQUIPMENT), '0')  SERIAL_NO
                                                                    from GNRC.RAW_LEADS_TBL RLT10
                                                                    where
                                                                        RLT10.ERROR_DESC is NULL
                                                                        and RLT10.FILE_NM not like '%adhoc%'
                                                                        and RLT10.FILE_NM not like '%GNRC-%'
                                                                        and RLT10.FILE_NM not like '%ncoa_customer_handling_%'
                                                                        and RLT10.FILE_NM not like '%histor%'
                                                                        and RLT10.FILE_NM not like '%with%'
                                                                        and (RLT10.FILE_NM like '%gnrc_after_leads_2%'    )
                                                                    GROUP BY LTRIM(TRIM(RLT10.EQUIPMENT), '0')
                                                                    Having COUNT(*) > 1
                                                                )

                                                            )
             ) RLT
            ON  (   LTRIM(TRIM(RLT1.EQUIPMENT),'0') = LTRIM(TRIM(RLT.EQUIPMENT),'0')
                )
    where RLT1.FILE_NM <> RLT.FILE_NM
    UNION
    select
            RLT.*
    from (select * from (
                 select rlt.*, row_number() over (partition by LTRIM(TRIM(RLT.EQUIPMENT), '0') order by rlt.INSERT_AUDIT_KEY desc) rno
                   from GNRC.RAW_LEADS_TBL RLT
                )RLT where  RLT.rno =2 and
                            RLT.ERROR_DESC is NULL
                            and RLT.FILE_NM not like '%adhoc%'
                            and RLT.FILE_NM not like '%GNRC-%'
                            and RLT.FILE_NM not like '%ncoa_customer_handling_%'
                            and RLT.FILE_NM not like '%histor%'
                            and RLT.FILE_NM not like '%with%'
                            and (RLT.FILE_NM like '%gnrc_after_leads_2%'    )
                  )
        RLT1
         JOIN (select * from (
                 select rlt.*, row_number() over (partition by LTRIM(TRIM(RLT.EQUIPMENT), '0') order by rlt.INSERT_AUDIT_KEY desc) rno
                   from GNRC.RAW_LEADS_TBL RLT
                ) RLT
             where RLT.rno = 1 and
                     RLT.ERROR_DESC is NULL
                    and RLT.FILE_NM not like '%adhoc%'
                    and RLT.FILE_NM not like '%GNRC-%'
                    and RLT.FILE_NM not like '%ncoa_customer_handling_%'
                    and RLT.FILE_NM not like '%histor%'
                    and RLT.FILE_NM not like '%with%'
                    and (RLT.FILE_NM like '%gnrc_after_leads_2%'    )
                    and LTRIM(TRIM(RLT.EQUIPMENT), '0') in (
                                                                select SERIAL_NO from (
                                                                select   LTRIM(TRIM(RLT10.EQUIPMENT), '0')  SERIAL_NO
                                                                    from GNRC.RAW_LEADS_TBL RLT10
                                                                    where
                                                                        RLT10.ERROR_DESC is NULL
                                                                        and RLT10.FILE_NM not like '%adhoc%'
                                                                        and RLT10.FILE_NM not like '%GNRC-%'
                                                                        and RLT10.FILE_NM not like '%ncoa_customer_handling_%'
                                                                        and RLT10.FILE_NM not like '%histor%'
                                                                        and RLT10.FILE_NM not like '%with%'
                                                                        and (RLT10.FILE_NM like '%gnrc_after_leads_2%'    )
                                                                    GROUP BY LTRIM(TRIM(RLT10.EQUIPMENT), '0')
                                                                    Having COUNT(*) > 1
                                                                )

                                                            )
             ) RLT
            ON  (   LTRIM(TRIM(RLT1.EQUIPMENT),'0') = LTRIM(TRIM(RLT.EQUIPMENT),'0')
                )
    where RLT1.FILE_NM <> RLT.FILE_NM
)
ORDER BY EQUIPMENT
;--