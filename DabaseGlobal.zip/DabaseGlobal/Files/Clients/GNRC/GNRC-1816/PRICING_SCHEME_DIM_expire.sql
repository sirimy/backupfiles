
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC-1816', p_table_nm => 'PRICING_SCHEME_DIM');

BEGIN

         Update GNRC.PRICING_SCHEME_DIM
            SET END_DT = date'2025-06-30',
                UPDATE_AUDIT_KEY = v_audit_key
         where PRICING_SCHEME_NM in (
                select PRICING_SCHEME_NM from GNRCSTG.PRICING_SCHEME_DIM
            ) and END_DT > SYSDATE and PRICING_SCHEME_KEY in (
                31,34,39,40,41
             )
            ;

        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);

       COMMIT;

END;
