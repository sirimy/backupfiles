
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC-1816', p_table_nm => 'POLICY_TBL');

BEGIN

         Update GNRC.POLICY_TBL
            SET EXP_DT = date'2025-06-30' ,
                UPDATE_AUDIT_KEY = v_audit_key
          where POLICY_PRODUCT_XID = 'ZPD-EXWAR100002' and EXP_DT > sysdate and POLICY_KEY in (143,170)
            ;

        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);

       COMMIT;

END;



DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC-1816', p_table_nm => 'POLICY_TBL');

BEGIN

         Update GNRC.policy_fee_xref
            SET END_DT = date'2025-06-30' ,
                UPDATE_AUDIT_KEY = v_audit_key
          where   END_DT > sysdate and POLICY_KEY in (143,170)
            ;

        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);

       COMMIT;

END;