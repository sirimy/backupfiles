            --------1st sep-----------------------------------------------
            Update RAW_INDUSTRIAL_GENSETS_TBL
                    SET ERROR_DESC = 'KW Rating is missing'
            WHERE  LTRIM(TRIM(KW_RATING),'0') is null
                    and PRODUCT_HIER_LEVEL1 <> '20006'  ;
            --------1st sep-----------------------------------------------

             ---1st Sep---TRIM(CONCAT(MATERIAL,concat('-KW',regexp_substr(KW_RATING, '[0-9]*')) )) as  PRODUCT_UNIQUE_ID,
                         CASE
                            WHEN LTRIM(TRIM(KW_RATING),'0') is  null
                             THEN TRIM(MATERIAL)
                            ELSE TRIM(CONCAT(MATERIAL,concat('-KW',regexp_substr(KW_RATING, '[0-9]*')) ))
                            END   as PRODUCT_UNIQUE_ID,

               ---New dummy email suppress code added on 1st sep
        UPDATE COMMON_LOAD_HOLD_TBL
         SET EMAIL_ADDRESS_TX = NULL
        where EMAIL_ADDRESS_TX is not null
         and (TRIM(EMAIL_ADDRESS_TX)) IN ('NA@TOTALPOWER.CA','none@rockymountainpower.com','NONE','none','none@gmail.com'
        ,'na@na.com','na@totalpower.ca','NONE@GMAIL.COM','NA@NA.COM','NONE@ROCKYMOUNTAINPOWER.COM','none@aol.com',
        'None@gmail.com','none@generatorsystems.com','Anyone@anyone.com','unknown@email.com','UNKNOWN@UNKNOWN.COM'
        ,'unkown@unkown.com','NONE@HOTMAIL.COM','NA@KROGER.COM','N@A.COM','unknown@unknown.com','none@hotmail.com');
