
--QC Cases and SQL:

--All Address keys from RAW_MELISSA_DATA_TBL should be present in NCOA_UPDATED_ADDRESS_TBL. This is to ensure that latest changes are not eating up any input records
select * from RAW_MELISSA_DATA_TBL where "StagingID" in(
    Select "StagingID" from   RAW_MELISSA_DATA_TBL
        minus
    select TO_CHAR(ADDRESS_KEY) from NCOA_UPDATED_ADDRESS_TBL
                                )
    and "LineItemID" = 1
;

--For AS12 records, single row should exist in NCOA_UPDATED_ADDRESS_TBL and further it should be the original input address
 select ADDRESS_KEY,COUNT(*)
 from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY in (
 select "StagingID" from  RAW_MELISSA_DATA_TBL where "StagingID" in (
    select   "StagingID"  from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991')
    and "MD_Results"  like '%AS12%')
group by ADDRESS_KEY
Having COUNT(*) > 1
ORDER BY ADDRESS_KEY
;--0 rows


--For Non-AS12 mover records, double entry should be present in NCOA_UPDATED_ADDRESS_TBL. Count of distinct address keys should match with count of Non-AS12 movers
select COUNT(*) from (
     select ADDRESS_KEY,COUNT(*)
     from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY in (
     select "StagingID" from  RAW_MELISSA_DATA_TBL where "StagingID" in (
        select   "StagingID"  from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991')
        and "MD_Results" not like '%AS12%')
    group by ADDRESS_KEY
    Having COUNT(*) > 1)
;--1755

--Records loaded for AS12 in NCOA_UPDATED_ADDRESS_TBL should be the input address. Comparing street address between Raw_Melissa_* and NCOA_* table
select NUAT.ADDRESS_LINE1_TX , RML1."MD_AddressLine1" from NCOA_UPDATED_ADDRESS_TBL NUAT
         JOIN RAW_MELISSA_DATA_TBL RML1 on NUAT.ADDRESS_KEY = RML1."StagingID"
         where ADDRESS_KEY in (select RML."StagingID" from RAW_MELISSA_DATA_TBL RML  where RML."LineItemID" ='1' and RML."MD_Results" like '%AS12%')
            and "StagingID" in ( select RML."StagingID" from RAW_MELISSA_DATA_TBL RML  where RML."LineItemID" ='1' and RML."MD_Results" like '%AS12%')
            and RML1."LineItemID" = '991'
            and NUAT.ADDRESS_LINE1_TX <> RML1."MD_AddressLine1"
;--0 as expected all picked input address