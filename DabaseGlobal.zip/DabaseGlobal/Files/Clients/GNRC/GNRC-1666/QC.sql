select COUNT(*),COUNT(distinct ADDRESS_KEY ) from NCOA_UPDATED_ADDRESS_TBL where NEW_ADDRESS_LINE1_TX is not null  ;--6105
+--------+--------------------------+
|COUNT(*)|COUNT(DISTINCTADDRESS_KEY)|
+--------+--------------------------+
|1755    |1755                      |
+--------+--------------------------+

select 6105 - 4373 from DUAL;--1732

select * from RAW_MELISSA_DATA_TBL;

select "dateCreated",COUNT(*) from RAW_MELISSA_DATA_TBL
group by "dateCreated"
;

select COUNT(*),max("dateCreated"),min("dateCreated") from RAW_MELISSA_DATA_TBL;
-- +--------+-------------------+-------------------+
-- |COUNT(*)|MAX("DATECREATED") |MIN("DATECREATED") |
-- +--------+-------------------+-------------------+
-- |259433  |2024-11-28 07:46:56|2024-11-28 07:45:38|
-- +--------+-------------------+-------------------+



select "LineItemID",COUNT(*) from RAW_MELISSA_DATA_TBL
GROUP BY "LineItemID"
;
+----------+--------+
|LineItemID|COUNT(*)|
+----------+--------+
|991       |9631    |
|2         |10      |
|1         |249791  |
|3         |1       |
+----------+--------+

select COUNT(*) from RAW_MELISSA_DATA_TBL where "LineItemID"  = '991';--9631

select COUNT(*) from RAW_MELISSA_DATA_TBL where "LineItemID"  = '1' and "MD_Results" like '%AS12%';--7876

--where "LineItemID" = 1 and “MD_Results” not like ‘%AS12%’ and there is a corresponding raw record for same “StagingID“ with "LineItemID" = 991.


select COUNT(*) from RAW_MELISSA_DATA_TBL where "LineItemID"  = '1' and "MD_Results" not like '%AS12%'
        and "StagingID" in ( select "StagingID" from RAW_MELISSA_DATA_TBL where "LineItemID"  = '991' )
;--1755

select * from RAW_MELISSA_DATA_TBL where "LineItemID"  = '1' and "MD_Results" like '%AS12%';--7876

select * from RAW_MELISSA_DATA_TBL where "LineItemID"  = '991' and "MD_Results" like '%AS12%';--0

select COUNT(*) from NCOA_UPDATED_ADDRESS_TBL where NEW_ADDRESS_LINE1_TX is not null;--1755

select COUNT(*) from NCOA_UPDATED_ADDRESS_TBL
         where ADDRESS_KEY  in(
             select "StagingID" from RAW_MELISSA_DATA_TBL where "LineItemID"  = '1' and "MD_Results" like '%AS12%'
             )
         --and NEW_ADDRESS_LINE1_TX is not null
         --and ADDRESS_KEY =45510
ORDER BY ADDRESS_KEY
;

    select trunc("dateCreated"),"LineItemID", count(*),
           count(case when "MD_Results" like '%AS12%' then 1 end) as AS12
    from RAW_MELISSA_DATA_TBL
    group by trunc("dateCreated"),"LineItemID"
    ORDER BY trunc("dateCreated"),"LineItemID"
;

select * from RAW_MELISSA_DATA_TBL where "MD_Results" like '%AS12%' order by "StagingID";

select * from RAW_MELISSA_DATA_TBL where "StagingID" = '45510';
+---------+-------------+----------+-----------------------------------------------------------+-----------+--------------+---------------+
|StagingID|FileTrackerID|LineItemID|MD_Results                                                 |MD_NameFull|MD_CompanyName|MD_AddressLine1|
+---------+-------------+----------+-----------------------------------------------------------+-----------+--------------+---------------+
|45510    |20241106     |1         |AS01,AS12,CS02,ES01,GS05,NS01,NS05,NS06,PS01,PS07,VR01,VS40|Greg Eaton |              |14 Jean Dr     |
|45510    |20241106     |991       |AS01,GS05                                                  |           |              |5 Sea Barn Rd  |
+---------+-------------+----------+-----------------------------------------------------------+-----------+--------------+---------------+

select * from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY = 45510;
+-----------+-------------+---------------+--------------+---------------+-------------+---------------+----------------------+
|ADDRESS_KEY|INPUT_FIRM_NM|INPUT_PREFIX_NM|INPUT_FIRST_NM|INPUT_MIDDLE_NM|INPUT_LAST_NM|INPUT_SUFFIX_NM|INPUT_ADDRESS_LINE1_TX|
+-----------+-------------+---------------+--------------+---------------+-------------+---------------+----------------------+
|45510      |             |               |Greg          |NULL           |Eaton        |               |5 Sea Barn Rd         |
+-----------+-------------+---------------+--------------+---------------+-------------+---------------+----------------------+

-- NCOA process discarded AS12 records and retained input records in NCOA updated address table
-- check in bulk data
        select trunc("dateCreated"),"LineItemID", count(*),count(distinct "StagingID" ),
           count(case when "MD_Results" like '%AS12%' then 1 end) as AS12
    from RAW_MELISSA_DATA_TBL
    group by trunc("dateCreated"),"LineItemID"
    ORDER BY trunc("dateCreated"),"LineItemID"
;
+--------------------+----------+--------+--------------------------+----+
|TRUNC("DATECREATED")|LineItemID|COUNT(*)|COUNT(DISTINCT"STAGINGID")|AS12|
+--------------------+----------+--------+--------------------------+----+
|2024-11-28          |1         |249791  |249791                    |7876|
|2024-11-28          |2         |10      |10                        |0   |
|2024-11-28          |3         |1       |1                         |0   |
|2024-11-28          |991       |9631    |9631                      |0   |
+--------------------+----------+--------+--------------------------+----+

select COUNT(*) from   RAW_MELISSA_DATA_TBL where "LineItemID" = '1'
and "StagingID" in (select "StagingID" from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991');--9631

select COUNT(*) from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991'
and "StagingID" in (select "StagingID" from   RAW_MELISSA_DATA_TBL where "LineItemID" = '1');--9631


select COUNT(*) from   RAW_MELISSA_DATA_TBL where "LineItemID" = '1'
and "StagingID" in (select "StagingID" from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991')
and "MD_AddressLine1" in (select INPUT_ADDRESS_LINE1_TX from NCOA_UPDATED_ADDRESS_TBL )
;--756


select * from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991'
and "StagingID" in (select "StagingID" from   RAW_MELISSA_DATA_TBL where "LineItemID" = '1')
and "StagingID" not in (
        select "StagingID" from   RAW_MELISSA_DATA_TBL where "LineItemID" = '1'
        and "StagingID" in (select "StagingID" from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991')
        and "MD_AddressLine1" in (select INPUT_ADDRESS_LINE1_TX from NCOA_UPDATED_ADDRESS_TBL )
        )
;
+---------+-------------+----------+----------+-----------+--------------+--------------------+
|StagingID|FileTrackerID|LineItemID|MD_Results|MD_NameFull|MD_CompanyName|MD_AddressLine1     |
+---------+-------------+----------+----------+-----------+--------------+--------------------+
|45510    |20241106     |991       |AS01,GS05 |           |              |5 Sea Barn Rd       |
|5295342  |20241106     |991       |AS01,GS05 |           |              |105 Late Bloomer Dr |
|328726   |20241106     |991       |AS01,GS05 |           |              |6317 Weathers Rd    |
|258086   |20241106     |991       |AS01,GS05 |           |              |11629 Danville Dr   |
|2744656  |20241106     |991       |AS01,GS05 |           |              |255 SE Courances Dr |
|394206   |20241106     |991       |AS01,GS05 |           |              |429 Potomac Dr      |
|356976   |20241106     |991       |AS01,GS05 |           |              |837 E 8th Ave       |
|375094   |20241106     |991       |AS01,GS05 |           |              |3249 E Briarcliff Rd|
|488564   |20241106     |991       |AS01,GS05 |           |              |2800 N 5 Mile Rd    |
|434792   |20241106     |991       |AS01,GS05 |           |              |9435 N Romine Rd    |
+---------+-------------+----------+----------+-----------+--------------+--------------------+
select * from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY = 45510;

select COUNT(*) from   RAW_MELISSA_DATA_TBL ;
--259433

select COUNT(*),"LineItemID" from   RAW_MELISSA_DATA_TBL where "MD_AddressLine1" in (select INPUT_ADDRESS_LINE1_TX from NCOA_UPDATED_ADDRESS_TBL )
GROUP BY "LineItemID"
;
+--------+----------+
|COUNT(*)|LineItemID|
+--------+----------+
|231188  |1         |
|9       |2         |
|1       |3         |
|9467    |991       |
+--------+----------+
select COUNT(*),"LineItemID" from   RAW_MELISSA_DATA_TBL GROUP BY "LineItemID";
+--------+----------+
|COUNT(*)|LineItemID|
+--------+----------+
|249791  |1         |
|10      |2         |
|1       |3         |
|9631    |991       |
+--------+----------+

select T1.ADDRESS_KEY,T1.INPUT_ADDRESS_LINE1_TX,T2."StagingID",T2."MD_AddressLine1" from NCOA_UPDATED_ADDRESS_TBL     T1
   JOIN (select * from   RAW_MELISSA_DATA_TBL
        MINUS
    select * from   RAW_MELISSA_DATA_TBL where "MD_AddressLine1" in (select INPUT_ADDRESS_LINE1_TX from NCOA_UPDATED_ADDRESS_TBL )) T2
    ON T1.ADDRESS_KEY = T2."StagingID"
;
+-----------+-------------------------+---------+--------------------------+
|ADDRESS_KEY|INPUT_ADDRESS_LINE1_TX   |StagingID|MD_AddressLine1           |
+-----------+-------------------------+---------+--------------------------+
|1457646    |6945 Blair St            |1457646  |2162 S Slocum Rd          |
|1477846    |58935 390th St           |1477846  |189 Southland St          |
|1541636    |33975 Sunset Dr          |1541636  |420 Palm Lake Dr          |
|1596806    |4312 Tara Ct             |1596806  |5490 Timber Bend Dr       |
|1679474    |3720 Flagler Ave         |1679474  |507 SE 33rd Ter           |
|1687210    |1616 Atlantic Blvd Apt 11|1687210  |4802 Textile Rd           |
|1729830    |712 Madam Moores Ln      |1729830  |PO Box 3501               |
|1729830    |NULL                     |1729830  |PO Box 3501               |
|1899984    |40 Hill and Hollow Rd    |1899984  |1457 Salt Point Tpke Apt A|
|1903300    |54955 Moody Dr           |1903300  |12802 Crossing Creek Dr   |
+-----------+-------------------------+---------+--------------------------+
select * from   RAW_MELISSA_DATA_TBL where "StagingID" = '1457646';
+---------+-------------+----------+------------------------------------------------------+-----------+--------------+----------------+
|StagingID|FileTrackerID|LineItemID|MD_Results                                            |MD_NameFull|MD_CompanyName|MD_AddressLine1 |
+---------+-------------+----------+------------------------------------------------------+-----------+--------------+----------------+
|1457646  |20241106     |1         |AS01,AS12,CS02,ES01,GS05,NS01,NS05,NS06,PS01,PS07,VR01|Doug Ulberg|              |2162 S Slocum Rd|
|1457646  |20241106     |991       |AS01,GS05                                             |           |              |6945 Blair St   |
+---------+-------------+----------+------------------------------------------------------+-----------+--------------+----------------+
select * from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY = 1729830
UNION
select * from NCOA_UPDATED_ADDRESS_TBL
         where upper(INPUT_ADDRESS_LINE1_TX) = upper('PO Box 3501') or upper(ADDRESS_LINE1_TX) =  upper('PO Box 3501')
                or upper(NEW_ADDRESS_LINE1_TX ) = upper('PO Box 3501');


select COUNT(* ) from (
    select * from   RAW_MELISSA_DATA_TBL
        MINUS
    select * from   RAW_MELISSA_DATA_TBL where upper("MD_AddressLine1") in (select upper(INPUT_ADDRESS_LINE1_TX) from NCOA_UPDATED_ADDRESS_TBL  )
) T1 Where "MD_Results"  not like '%AS12%'
;
+---------+----------+--------------------------------------------------------------------------+----------------+--------------+---------------------------+
|StagingID|LineItemID|MD_Results                                                                |MD_NameFull     |MD_CompanyName|MD_AddressLine1            |
+---------+----------+--------------------------------------------------------------------------+----------------+--------------+---------------------------+
|1729830  |1         |AS01,AS20,CM01,CS01,CS10,ES01,GS05,NS01,NS05,NS06,PS01,PS08,PS10,VR01,VS01|Dustin Tyson    |              |PO Box 3501                |
|1947980  |1         |AS01,CM01,CS01,CS11,ES01,GS05,NS01,NS05,NS06,PS01,PS07,VR01,VS30,VS40     |Brian Crowley   |              |14974 Ashby Way E          |
|1959928  |1         |AS01,CM01,CS01,CS10,ES01,GS05,NS01,NS05,NS06,PS01,PS08,VR01,VS30,VS40     |Morton Roberts  |              |2348 Foxtree Rd            |
|1968538  |1         |AS01,CM01,CS01,CS10,ES01,GS05,NS01,NS05,NS06,PS01,PS07,VR01,VS30,VS40     |Caroline Amidon |              |786 Nantmeal Rd            |
|1969524  |1         |AS01,CM01,CS01,CS10,ES01,GS06,NS01,NS05,PS01,PS07,PS10,VR01,VS40          |David Borans    |              |1111 Avenel Blvd           |
|2011726  |1         |AS01,CM01,CS01,CS10,GS05,NS01,NS05,NS06,PS01,PS07,VR01,VS30               |Deborah Due     |              |312 E Chatham St           |
|2013058  |1         |AS01,CM01,CS01,CS10,GS05,NS01,NS05,NS06,PS01,PS09,VR01,VS01               |Steven Kiff     |              |3540 Rossmere Rd           |
|2027698  |1         |AS01,CM01,CS01,CS10,GS05,NS01,NS05,NS06,PS01,PS07,VR01                    |Jim Murray      |              |39 Pawnee Trl              |
|2351410  |1         |AS01,CM01,CS01,CS10,ES01,GS05,NS01,NS05,NS06,PS01,PS07,VR01,VR05          |Nancy Cedrone   |              |12430 Sunglow Blvd Unit 318|
|2364612  |1         |AS01,CM01,CS01,CS11,ES01,GS05,NS01,NS05,VR01,VS40                         |Harry Kipfmiller|              |725 W Middle St Apt 34     |
+---------+----------+--------------------------------------------------------------------------+----------------+--------------+---------------------------+

  select COUNT(* ) from (
    select * from   RAW_MELISSA_DATA_TBL
        MINUS
    select * from   RAW_MELISSA_DATA_TBL where "StagingID" in (select ADDRESS_KEY from NCOA_UPDATED_ADDRESS_TBL  )
) T1 Where "MD_Results"   like '%AS12%'
;


select * from RAW_MELISSA_DATA_TBL where "StagingID" in (
    select  "StagingID"
    from   RAW_MELISSA_DATA_TBL where "LineItemID" = '1'
    group by "StagingID"
    having COUNT(*)>1)
ORDER BY "StagingID"
;--

select count( distinct "StagingID"),max( "dateCreated"),min( "dateCreated"),count(*),count(*)- count( distinct "StagingID")
from   RAW_MELISSA_DATA_TBL where "LineItemID" = '1';
+--------------------------+-------------------+-------------------+--------+-----------------------------------+
|COUNT(DISTINCT"STAGINGID")|MAX("DATECREATED") |MIN("DATECREATED") |COUNT(*)|COUNT(*)-COUNT(DISTINCT"STAGINGID")|
+--------------------------+-------------------+-------------------+--------+-----------------------------------+
|249791                    |2024-11-28 16:44:15|2024-11-28 16:42:55|249791  |0                                  |
+--------------------------+-------------------+-------------------+--------+-----------------------------------+

 select count( distinct ADDRESS_KEY),COUNT(*),COUNT(*)-count( distinct ADDRESS_KEY)
 from NCOA_UPDATED_ADDRESS_TBL;
+--------------------------+--------+-----------------------------------+
|COUNT(DISTINCTADDRESS_KEY)|COUNT(*)|COUNT(*)-COUNT(DISTINCTADDRESS_KEY)|
+--------------------------+--------+-----------------------------------+
|249791                    |259422  |9631                               |
+--------------------------+--------+-----------------------------------+
---+

select   249791 -   239802 from DUAL;--9989

select * from RAW_MELISSA_DATA_TBL where "StagingID" in(
    Select "StagingID"  from   RAW_MELISSA_DATA_TBL
        minus
    select TO_CHAR(ADDRESS_KEY) from  NCOA_UPDATED_ADDRESS_TBL
                                )
    and "LineItemID" = 1
;

select * from RAW_MELISSA_DATA_TBL where "StagingID" in
(    Select "StagingID"  from   RAW_MELISSA_DATA_TBL
      minus
   select TO_CHAR(ADDRESS_KEY) from  NCOA_UPDATED_ADDRESS_TBL
 )
 and "LineItemID" = 1;

select * from RAW_MELISSA_DATA_TBL where "StagingID" in(
    Select "StagingID"  from   RAW_MELISSA_DATA_TBL
        minus
    select TO_CHAR(ADDRESS_KEY) from  NCOA_UPDATED_ADDRESS_TBL
                                )
        --and "MD_Results" like '%AS12%'
        and "MD_Results" NOT like '%AS12%' and "LineItemID" = 1
;
-- +---------+-------------+----------+----------------------------------------------------------------+--------------+----------------------+--------------+
-- |StagingID|FileTrackerID|LineItemID|MD_Results                                                      |MD_NameFull   |MD_AddressLine1       |MD_CompanyName|
-- +---------+-------------+----------+----------------------------------------------------------------+--------------+----------------------+--------------+
-- |6236150  |20241106     |1         |AS01,AS12,CS02,ES01,GS05,NS01,NS05,VR01,VS12,VS40               |Phil Aidikoff |2040 N Stateline Rd   |              |
-- |6236150  |20241106     |991       |AS01,GS05                                                       |              |400 Martin Ln         |              |
-- |6236600  |20241106     |1         |AS01,AS12,AS17,AS20,CS02,ES01,GS05,NS01,NS05,NS06,VR01,VS12,VS40|John Humphries|PO Box 2022           |              |
-- |6236600  |20241106     |991       |AS01,AS17,GS05                                                  |              |1331 Shiloh Unity Rd  |              |
-- |6241172  |20241106     |1         |AS01,AS12,CS02,ES01,GS05,NS01,NS05,NS06,VR01,VS40               |Larry Zent    |30314 S State Route Dd|              |
-- |6241172  |20241106     |991       |AS01,GS05                                                       |              |502 Smith Dr          |              |
-- |6243932  |20241106     |1         |AS01,AS12,CS02,ES01,GS05,NS01,NS05,NS06,VR01,VS12,VS40          |Ed Green      |1288 W 1500 N         |              |
-- |6243932  |20241106     |991       |AS01,GS05                                                       |              |460 E 300 S           |              |
-- |6245004  |20241106     |1         |AS01,AS12,CS02,ES01,GS06,NS01,NS05,NS06,VR01,VS40               |Ray Williams  |7976 Kirkridge St     |              |
-- |6245004  |20241106     |991       |AS01,GS05                                                       |              |973 Tranquil Point Rd |              |
-- |6245010  |20241106     |1         |AS01,AS12,CS02,ES01,GS05,NS01,NS05,VR01,VS01,VS13,VS40          |Rob Mikitarian|830 E Orange Grove Ave|              |
-- +---------+-------------+----------+----------------------------------------------------------------+--------------+----------------------+--------------+
-- +---------+-------------+----------+-----------------------------------------------------------+---------------+------------------------------+
-- |StagingID|FileTrackerID|LineItemID|MD_Results                                                 |MD_NameFull    |MD_AddressLine1               |
-- +---------+-------------+----------+-----------------------------------------------------------+---------------+------------------------------+
-- |8458106  |20241106     |1         |AS01,CS02,ES01,GS06,NS01,NS05,NS06,VR01,VS12,VS40          |Matt Huffman   |3359 Southern Oaks Dr         |
-- |8458110  |20241106     |1         |AS01,CS02,ES01,GS05,NS01,NS05,NS06,VR01,VR05               |Ann Crisp      |18981 62nd Pl                 |
-- |8458112  |20241106     |1         |AS01,CS02,ES01,GS06,VS40                                   |               |4032 County Road 795          |
-- |8458122  |20241106     |1         |AS01,CS02,ES01,GS05,NS01,NS05,NS06,VR01,VS40               |Tyler Dykes    |2116 NE County Road 410       |
-- |8458124  |20241106     |1         |AS01,CS02,ES01,GS01,NS01,NS05,NS06,VR01,VS40               |Curtis Kay     |1533 Sharon Ln                |
-- |8458126  |20241106     |1         |AS01,CS02,ES01,GS05,NS01,NS05,NS06,VR01,VS40               |Jeff Riebe     |3454 Steelgate Ct             |
-- |8458128  |20241106     |1         |AS01,CS02,ES01,GS01,NS01,NS05,VR01,VS13,VS40               |Matthew Sheaver|734 Palm Crest Dr             |
-- |8458132  |20241106     |1         |AS01,AS17,AS24,CS02,ES01,GS05,NS01,NS05,VR01,VS01,VS12,VS40|David Hrobon   |225 Cannon Ct E               |
-- |8458140  |20241106     |1         |AE10,ES01,GS01,NS01,NS05,NS06                              |Dave Mancini   |24133 National Forest Road 209|
-- |8458142  |20241106     |1         |AS01,AS17,CS02,ES01,GS05,NS01,NS05,NS06,VR01,VR05          |Kevin Connelly |8650 County Road 13 N         |
-- +---------+-------------+----------+-----------------------------------------------------------+---------------+------------------------------+

select * from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY = 6241172;--0
select * from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY = 8458142;--0



 select count( distinct ADDRESS_KEY),COUNT(*)
 from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY in (
 select "StagingID" from  RAW_MELISSA_DATA_TBL where "StagingID" in (
    select   "StagingID"  from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991')
    and "MD_Results"  like '%AS12%')
;--0


 select count( distinct "StagingID") from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991' ;--9631

select COUNT(* ) from  RAW_MELISSA_DATA_TBL where "StagingID" in (
    select   "StagingID"  from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991')
    and "MD_Results"  like '%AS12%'
;--7876

 select ADDRESS_KEY,COUNT(*)
 from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY in (
 select "StagingID" from  RAW_MELISSA_DATA_TBL where "StagingID" in (
    select   "StagingID"  from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991')
    and "MD_Results"  like '%AS12%')
group by ADDRESS_KEY
Having COUNT(*) > 1
ORDER BY ADDRESS_KEY
;--0 rows


select  "MD_AddressLine1" from RAW_MELISSA_DATA_TBL
         where --"StagingID" = '45510' AND
               "LineItemID" = '991'
           and "StagingID" in ( select RML."StagingID" from RAW_MELISSA_DATA_TBL RML  where RML."LineItemID" ='1' and RML."MD_Results" like '%AS12%');


select NUAT.ADDRESS_LINE1_TX , RML1."MD_AddressLine1" from NCOA_UPDATED_ADDRESS_TBL NUAT
         JOIN RAW_MELISSA_DATA_TBL RML1 on NUAT.ADDRESS_KEY = RML1."StagingID"
         where ADDRESS_KEY in (select RML."StagingID" from RAW_MELISSA_DATA_TBL RML  where RML."LineItemID" ='1' and RML."MD_Results" like '%AS12%')
            and "StagingID" in ( select RML."StagingID" from RAW_MELISSA_DATA_TBL RML  where RML."LineItemID" ='1' and RML."MD_Results" like '%AS12%')
            and RML1."LineItemID" = '991'
            and NUAT.ADDRESS_LINE1_TX <> RML1."MD_AddressLine1"
;--0 as expected all picked input address


select COUNT(*) from (
     select ADDRESS_KEY,COUNT(*)
     from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY in (
     select "StagingID" from  RAW_MELISSA_DATA_TBL where "StagingID" in (
        select   "StagingID"  from   RAW_MELISSA_DATA_TBL where "LineItemID" = '991')
        and "MD_Results" not like '%AS12%')
    group by ADDRESS_KEY
    Having COUNT(*) > 1)
;--1755

select count( distinct ADDRESS_KEY)  from NCOA_UPDATED_ADDRESS_TBL where NEW_ADDRESS_LINE1_TX is not null;--1755
--239802


select COUNT(*),COUNT(case when  NEW_ADDRESS_LINE1_TX is not null then 1 end ) from NCOA_UPDATED_ADDRESS_TBL  ;--1755
+--------+----------------------------------------------------+
|COUNT(*)|COUNT(CASEWHENNEW_ADDRESS_LINE1_TXISNOTNULLTHEN1END)|
+--------+----------------------------------------------------+
|241546  |1755                                                |
+--------+----------------------------------------------------+


select COUNT(*) from NCOA_UPDATED_ADDRESS_TBL ;

select 9631 - 7876 from DUAL;--1755

select COUNT(*),COUNT(distinct ADDRESS_KEY ) from NCOA_UPDATED_ADDRESS_TBL where NEW_ADDRESS_LINE1_TX is not null  ;--

+--------+--------------------------+
|COUNT(*)|COUNT(DISTINCTADDRESS_KEY)|
+--------+--------------------------+
|1755    |1755                      |
+--------+--------------------------+
select COUNT(*) from RAW_MELISSA_DATA_TBL where "LineItemID"  = '991';--9631

select COUNT(*) from NCOA_UPDATED_ADDRESS_TBL where NEW_ADDRESS_LINE1_TX is not null  ;--1755

select * from NCOA_UPDATED_ADDRESS_TBL where ADDRESS_KEY = 3839354;
+-----------+-------------+---------------+--------------+---------------+-------------+---------------+----------------------+----------------------+----------------+--------------+--------------+----------------------+----------------+----------------+--------+------------+------------+---------------------+------------+----------------+--------------+--------------+--------+--------------+-------------+--------------+----------------+----------+--------------------+--------------------+-------------+------------+----------------+----------------+-------------------------+----------------+--------------------+------------------+-----------------+-----------------+--------------------+------------------+---------------------------+------------+-----------------+--------------+-------------+-----------+---------------+---------------+---------+-------------+-------------------+----------------+--------------+
|ADDRESS_KEY|INPUT_FIRM_NM|INPUT_PREFIX_NM|INPUT_FIRST_NM|INPUT_MIDDLE_NM|INPUT_LAST_NM|INPUT_SUFFIX_NM|INPUT_ADDRESS_LINE1_TX|INPUT_ADDRESS_LINE2_TX|INPUT_CITY_NM   |INPUT_STATE_CD|INPUT_ZIP_CODE|ADDRESS_LINE1_TX      |ADDRESS_LINE2_TX|CITY_NM         |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|RECORD_TYPE_CD|LACS_IND|LACS_RETURN_CD|DPV_STATUS_CD|DPV_NO_STAT_CD|CASS_REC_TYPE_CD|ACE_ERR_CD|NEW_ADDRESS_LINE1_TX|NEW_ADDRESS_LINE2_TX|NEW_CITY_NM  |NEW_STATE_CD|NEW_ZIP_CODE5_TX|NEW_ZIP_CODE4_TX|NEW_DELIVERY_POINT_BAR_CD|NEW_CHK_DIGIT_CD|NEW_CARRIER_ROUTE_NO|NEW_LINE_OF_TRAVEL|NEW_DPV_STATUS_CD|NEW_DPV_NOSTAT_CD|NEW_CASS_REC_TYPE_CD|NEW_RECORD_TYPE_CD|PUERTO_RICO_URBANIZATION_NM|MOVE_TYPE_CD|MOVE_EFFECTIVE_DT|NCOA_RETURN_CD|ANK_RETURN_CD|VISITOR_KEY|NEW_ADDRESS_KEY|NEW_ADDRESS_IND|LOT_ORDER|NEW_LOT_ORDER|MOVER_DELIVERY_TYPE|INSERT_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+-------------+---------------+--------------+---------------+-------------+---------------+----------------------+----------------------+----------------+--------------+--------------+----------------------+----------------+----------------+--------+------------+------------+---------------------+------------+----------------+--------------+--------------+--------+--------------+-------------+--------------+----------------+----------+--------------------+--------------------+-------------+------------+----------------+----------------+-------------------------+----------------+--------------------+------------------+-----------------+-----------------+--------------------+------------------+---------------------------+------------+-----------------+--------------+-------------+-----------+---------------+---------------+---------+-------------+-------------------+----------------+--------------+
|3839354    |             |               |Marlene       |NULL           |Massa        |               |354 NW Springview Loop|                      |Port Saint Lucie|FL            |34986-2665    |354 NW Springview Loop|                |Port Saint Lucie|FL      |34986       |2665        |54                   |2           |C007            |NULL          |NULL          |NULL    |NULL          |NULL         |NULL          |NULL            |NULL      |NULL                |NULL                |NULL         |NULL        |NULL            |NULL            |NULL                     |NULL            |NULL                |NULL              |NULL             |NULL             |NULL                |NULL              |                           |NULL        |NULL             |NULL          |NULL         |NULL       |NULL           |NULL           |NULL     |NULL         |NULL               |NULL            |NULL          |
|3839354    |NULL         |NULL           |Marlene       |NULL           |Massa        |NULL           |NULL                  |NULL                  |NULL            |NULL          |NULL          |NULL                  |NULL            |NULL            |NULL    |NULL        |NULL        |NULL                 |NULL        |NULL            |NULL          |NULL          |NULL    |NULL          |NULL         |NULL          |NULL            |NULL      |304 Por La Mar Cir  |                    |Santa Barbara|CA          |93103           |3788            |04                       |4               |C022                |NULL              |NULL             |NULL             |NULL                |NULL              |                           |NULL        |2024-07-01       |NULL          |NULL         |NULL       |NULL           |NULL           |NULL     |NULL         |NULL               |NULL            |NULL          |
+-----------+-------------+---------------+--------------+---------------+-------------+---------------+----------------------+----------------------+----------------+--------------+--------------+----------------------+----------------+----------------+--------+------------+------------+---------------------+------------+----------------+--------------+--------------+--------+--------------+-------------+--------------+----------------+----------+--------------------+--------------------+-------------+------------+----------------+----------------+-------------------------+----------------+--------------------+------------------+-----------------+-----------------+--------------------+------------------+---------------------------+------------+-----------------+--------------+-------------+-----------+---------------+---------------+---------+-------------+-------------------+----------------+--------------+


    select trunc("dateCreated") DT, count(*) COUNT,
           count(case when "MD_Results" like '%AS12%' then 1 end) as AS12,
           count(case when "LineItemID" = '991' then 1 end) as T991,9631-7876 AS NONAS12_MOVERS
    from RAW_MELISSA_DATA_TBL
    group by trunc("dateCreated");