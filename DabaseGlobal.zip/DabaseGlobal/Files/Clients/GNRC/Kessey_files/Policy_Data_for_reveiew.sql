select vpr.PRODUCT_KEY,pol.policy_key, policy_product_xid as SKU, MIN_KW, MAX_KW, vpr.model_no, vpr.price_amt as Model_MSRP,
       vpr.brand_nm, vpr.product_category_nm,vpr.KW, age, ppd.term_months, ppd.base_price_amt, PRICING_SCHEME_NM, ppd.PRICING_SCHEME_KEY
  from
       (select policy_key, policy_product_xid, age, min_product_price, max_product_price, term_key from policy_tbl ) pol
        join
        (select policy_key, MIN_KW, MAX_KW  from POLICY_EXT_TBL r  ) pex
       on pex.policy_key = pol.policy_key
       --join p_term_dim tr on tr.term_key = pol.term_key
       left join
       (select * from V_POLICY_FEE_Stg fee ) fee on fee.policy_key = pol.policy_key
       join PRODUCT_PRICE_DIM_TEMP ppd
       on ppd.policy_key = pol.policy_key
       join gnrc.v_product vpr
       on vpr.product_key = ppd.product_key
       left join gnrc.PRICING_SCHEME_DIM psd
       on psd.pricing_scheme_key = ppd.pricing_scheme_key
 where ppd.POLICY_KEY in (
select RAW_PRICING_TBL.POLICY_KEY from RAW_PRICING_TBL )
order by pol.policy_key, psd.PRICING_SCHEME_KEY
;

/*
select * from p_term_dim tr ;
select * from v_policy_fee;
select * from V_POLICY_FEE_Stg where retail_amt is null;
select * from product_price_dim ppd
 where ppd.base_price_amt is null
--   and rownum <= 10 ;
 */