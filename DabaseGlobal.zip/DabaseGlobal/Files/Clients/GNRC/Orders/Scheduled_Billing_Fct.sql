SELECT sum(payment_due_amt) over() as total, a.creation_dt, u.creation_dt as updated_td, sales_source_cd, sbf.*
  FROM p_scheduled_billing_fct sbf
       JOIN gnrc.order_tbl ot on (ot.order_key = sbf.order_key)
       LEFT JOIN audit_tbl a on (a.audit_key = sbf.insert_audit_key)    
       LEFT JOIN audit_tbl u on (u.audit_key = sbf.update_audit_key)
  WHERE sbf.order_key in(
--       :order_key
815253
,0
      )
--   AND trunc(sbf.payment_due_dt) < TRUNC(ot.purchase_dt)
-- where PAYMENT_STATUS_CD = 'HOLD'
--  where trim(PAYMENT_STATUS_CD) not in ( 'PAID', 'CANCEL', 'FLEXPAY_TERMINATED')
 ORDER BY sbf.order_key, sbf.seq_no
 ;
 
select * from p_scheduled_billing_fct sbf
 where 1=1 --and PAYMENT_TX_ID like 'FP%'
  and ORDER_KEY = :order_key
--   and trunc(sbf.payment_due_dt) = date '2017-11-15'
--    and trunc(sbf.payment_due_dt) = date '2020-06-03'
--    and sbf.payment_collected_dt is null
 order by dbms_random.random; 

select payment_status_cd, count(*) from p_scheduled_billing_fct sbf group by payment_status_cd order by payment_status_cd;

select count(distinct order_key), MIN(purchase_dt), max(purchase_dt)
  from order_tbl
 where order_key > 158675
   and order_key < 159076 ;
 
select * from gnrc.order_item_tbl where order_key = 154451;
   
select * from gnrc.tax_detail_tbl where tax_detail_key = 8297247;
    
select * from gnrc.payment_tx_tbl where order_key = 154451;
    
select * from user_tables where table_name like '%SCHED%';
 
select * from gnrc.scheduled_billing_fct 
 where 1=1
--   and payment_due_dt < trunc(sysdate-1) + 3
--   and TRIM(payment_status_cd) <> 'PAID'
--   and seq_no <> 1
   and order_key = 185231
 order by order_key, seq_no;

select * from gnrc.SURCHARGE_ASSESSMENT_TBL where order_key = 154451;
 

select * from user_tab_columns
 where column_name like '%TAX%'
  and table_name NOT IN ('TAX_REPORT_DETAILS_TBL', 'TAX_OUTPUT_TBL', 'TAX_DETAIL_TBL', 'TAX_DETAIL_AUDIT', 'COMMON_ORDER_ERROR_TBL', 'COMMON_ORDER_HOLD_TBL', 'COMMON_ORDER_TBL')
  and table_name NOT LIKE 'CAMPAIGN_SPOOL%'
;

select * from gnrc.policy_tbl;  

select * from gnrc.V_SURCHARGE_ASSESSMENT_TBL sat;

select * from gnrc.scheduled_billing_fct
 where PAYMENT_STATUS_CD = 'CANCEL'
   and PAYMENT_DUE_DT >= date '2019-07-01'
   and order_key in (
           select cot.order_key  
             from gnrc.contract_order_tbl cot                          
                   left join gnrc.contract_lkp clkp on clkp.contract_key = cot.contract_key and clkp.source_system_cd = 0
                   left join gnrc.contract_dim con on  clkp.contract_key = con.contract_key
            where contract_status_key <> 2
           )         
 order by 1, 2;
 
select * 
  from P_payment_tx_tbl px 
       join P_scheduled_billing_fct sbf
       on sbf.order_key = px.order_key 
       --and sbf.seq_no = px.seq_no
 where 1=1
--   and upper(sbf.payment_tx_id) like 'FP%' 
--   and upper(px.payment_tx_key) not like 'FP%'
   and replace(UPPER(sbf.payment_tx_id), 'FP') = replace(UPPER(px.payment_tx_key), 'FP')  
   and UPPER(sbf.payment_tx_id) <> UPPER(px.payment_tx_key)
 order by deposit_dt, sbf.order_key; 
 
select PAYMENT_STATUS_CD, count(distinct order_key), count(*), max(payment_due_dt) 
from   p_scheduled_billing_fct sbf LEFT JOIN audit_tbl u on (u.audit_key = sbf.update_audit_key)
--where  PAYMENT_STATUS_CD = 'FLEXPAY_TERMINATED'
group by PAYMENT_STATUS_CD
order by 1;


select u.creation_dt as updated_td, sbf.* from gnrc.scheduled_billing_fct sbf LEFT JOIN audit_tbl u on (u.audit_key = sbf.update_audit_key)
where  PAYMENT_STATUS_CD = 'FLEXPAY_TERMINATED'
order by 1, 2, 3;


select u.creation_dt, sbf.* from gnrc.scheduled_billing_fct sbf LEFT JOIN audit_tbl u on (u.audit_key = sbf.update_audit_key)
where  1=1
-- and    u.creation_dt >= date '2020-06-17'
--  and     coalesce(payment_status_cd, 'X') not in ('PAID', 'PAID                ')
--and    payment_status_cd in ('CANCEL', 'CANCEL              ')
and sbf.order_key in (
        341087,
        341877,
        341877
       )
order by 2, 3, 1;


select u.creation_dt, sbf.* from gnrc.scheduled_billing_fct sbf LEFT JOIN audit_tbl u on (u.audit_key = sbf.update_audit_key)
where  1=1
--and    payment_collected_dt <= date '2020-06-01'
and    payment_collected_dt >= date '2020-06-01'
and    trim(payment_status_cd) is null
and    nvl(payment_collected_amt, 0) <> 0
order by 2, 3, 1;



--QA: --Order/Contract is cancelled but FP is still active
select *
from P_SCHEDULED_BILLING_FCT T1
WHERE EXISTS
  (SELECT 1
   from (select order_key
         from P_CONTRACT_ORDER_TBL cot
         where exists(select 1 from p_contract_cancellation_dim cc where cot.contract_key = cc.contract_key)
        ) T2
   where t1.order_key = t2.order_key)
  AND PAYMENT_TX_ID IS NULL
  AND NVL(upper(trim(PAYMENT_STATUS_CD)), 'ACTIVE') NOT IN ('CANCEL', 'FLEXPAY_TERMINATED');


