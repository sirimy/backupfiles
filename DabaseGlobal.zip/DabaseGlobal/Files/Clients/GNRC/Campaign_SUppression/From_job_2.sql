 -- solicitation/client_specific/post_spool_suppression_esa

----------------------------------------------------------------
--############################################################--
----------------------------------------------------------------
               --Suppress sales where latest_coverage_type = '2' except for Upgrade campaigns
               --Leads used in MU campaign had no prior sale in our systems but I still added MU here
               --INSERT INTO suppression_tbl
               SELECT DISTINCT spl.bundle_key,
                      'S',
                      sysdate,
                      'Sale',
                      ''
               FROM  offer_item_xref oix
                     join campaign_spool_file_Tbl spl on spl.reference_id = oix.offer_key
                     join CAMPAIGN_PARTICIPATION_FCT fct on fct.BUNDLE_KEY = spl.BUNDLE_KEY
                     JOIN gnrc.cell_dim cell   on fct.cell_key = cell.cell_key
               WHERE upper(CELL_DSC) not like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 2) not in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU')
               AND   si_key IN
                       ( SELECT si_key FROM P_serialized_item_dim WHERE latest_coverage_type = '2'
                       ) ;

----------------------------------------------------------------
--same exist in page this suppression
----------------------------------------------------------------
                 --Suppress sales based upon order in p_order_tbl except for Upgrade campaigns
                 --Leads used in MU campaign had no prior sale in our systems but I still added MU here
                 --INSERT INTO suppression_tbl
                 SELECT DISTINCT spl.bundle_key,
                        'S',
                        sysdate,
                        'Sale',
                        ''
                 FROM  campaign_spool_file_tbl spl
                      join CAMPAIGN_PARTICIPATION_FCT fct on fct.BUNDLE_KEY = spl.BUNDLE_KEY
                     JOIN gnrc.cell_dim cell   on fct.cell_key = cell.cell_key
                 WHERE upper(CELL_DSC) not like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 2) not in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU')
                 AND   p1_serial_no IN (
                          SELECT
                                 si.serial_no
                          FROM
                                 p_order_tbl o
                                 JOIN p_order_item_tbl oi ON (O.order_key = OI.ORDER_KEY)
                                 JOIN P_serialized_item_dim si ON (si.si_key = oi.serialized_item_key)
                               )
                  and spl.bundle_key NOT IN
                           (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
                           );
----------------------------------------------------------------
--###############################Also exist in page#############################--
----------------------------------------------------------------

                --if it is Upgrade lead and total length of warranty is >= 10 years then suppress
                --Subtracting 5 days from (365*10) to take care of boundary cases for whatever reasons
               --INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
               SELECT DISTINCT spl.bundle_key, 'S', sysdate, 'Sale'
               FROM   campaign_spool_file_tbl spl
                      join CAMPAIGN_PARTICIPATION_FCT fct on fct.BUNDLE_KEY = spl.BUNDLE_KEY
                     JOIN gnrc.cell_dim cell   on fct.cell_key = cell.cell_key

               WHERE  upper(CELL_DSC) like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 2) in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU')
               AND    p1_serial_no IN (
                          SELECT serial_no FROM p_serialized_item_dim si
                                           ---> with serial table we also join in order table to see if at least 1 order exist for this serial
                                           WHERE latest_coverage_type <> 1
                             AND  si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT >= (365*10) - 5
                             --AND recent sale OT last 60 days orders
                          )
               AND spl.bundle_key NOT IN
                         (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
                         );

---> with serial table we also join in order table to see if at least 1 order exist for this serial

-->
--===> new sql to add in job
--Lead has 10 years coverage: Upgrades
   SELECT DISTINCT spl.BUNDLE_KEY, 'M', sysdate, 'Lead Has 10 Years Coverage'
   FROM   gnrc.cell_dim cell
           JOIN CAMPAIGN_PARTICIPATION_FCT fct
              on fct.cell_key = cell.cell_key
           join campaign_spool_file_tbl spl on spl.BUNDLE_KEY = fct.BUNDLE_KEY
            --campaign_spool_file_tbl spl
--            JOIN V_BUNDLE_DIM bd on bd.BUNDLE_KEY = spl.BUNDLE_KEY --using (bundle_key)
--           JOIN v_bundle_item_xref vx on vx.BUNDLE_KEY = bd.BUNDLE_KEY--USING (bundle_key)
--           JOIN p_criteria_dim cd USING (criteria_key)
--          JOIN p_serialized_item_dim si USING (si_key)
   WHERE  1=1
   AND     upper(CELL_DSC) like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) = 'U'
   --AND    si.LATEST_COVERAGE_TYPE not in (2, 5)
   AND    p1_serial_no IN (
                          SELECT serial_no FROM p_serialized_item_dim si WHERE si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT >= (365*10) - 5
                          )
   AND    spl.BUNDLE_KEY NOT IN
            (SELECT sup.bundle_key FROM v_suppression_tbl sup WHERE sup.bundle_key IS NOT NULL
            );




---- Later addded

---post_spool_suppression_esa.job
--[1]
--Suppress sales where latest_coverage_type = '2' except for Upgrade campaigns
--Leads used in MU campaign had no prior sale in our systems but I still added MU here
--INSERT INTO suppression_tbl
SELECT DISTINCT spl.bundle_key,
      'S',
      sysdate,
      'Sale',
      'v_audit_key'
FROM  offer_item_xref oix
     join campaign_spool_file_Tbl spl on spl.reference_id = oix.offer_key
     JOIN CAMPAIGN_PARTICIPATION_FCT fct on spl.BUNDLE_KEY = fct.BUNDLE_KEY
     JOIN gnrc.cell_dim cell on fct.cell_key = cell.cell_key
WHERE upper(CELL_DSC) not like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 2) not in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU', 'CU')
AND   si_key IN
       ( SELECT si_key FROM P_serialized_item_dim WHERE latest_coverage_type = '2'
       ) ;
--------------------------------------------

--------------------------------------------
--[2]
 --Suppress sales based upon order in p_order_tbl except for Upgrade campaigns
                 --Leads used in MU campaign had no prior sale in our systems but I still added MU here
                 --INSERT INTO suppression_tbl
                 SELECT DISTINCT spl.bundle_key,
                        'S',
                        sysdate,
                        'Sale',
                        'v_audit_key'
                 FROM  campaign_spool_file_tbl spl
                       JOIN CAMPAIGN_PARTICIPATION_FCT fct on spl.BUNDLE_KEY = fct.BUNDLE_KEY
                       JOIN gnrc.cell_dim cell on fct.cell_key = cell.cell_key
                 WHERE upper(CELL_DSC) not like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 2) not in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU', 'CU')
                 AND   p1_serial_no IN (
                          SELECT
                                 si.serial_no
                          FROM
                                 p_order_tbl o
                                 JOIN p_order_item_tbl oi ON (O.order_key = OI.ORDER_KEY)
                                 JOIN P_serialized_item_dim si ON (si.si_key = oi.serialized_item_key)
                               )
                  and spl.bundle_key NOT IN
                           (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
                           );
--[3]
 --if it is Upgrade lead and total length of warranty is >= 10 years then suppress
                --Subtracting 5 days from (365*10) to take care of boundary cases for whatever reasons
              -- INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
               SELECT DISTINCT spl.bundle_key, 'S', sysdate, 'Sale'
               FROM   campaign_spool_file_tbl spl
                       JOIN CAMPAIGN_PARTICIPATION_FCT fct on spl.BUNDLE_KEY = fct.BUNDLE_KEY
                       JOIN gnrc.cell_dim cell on fct.cell_key = cell.cell_key
               WHERE upper(CELL_DSC) like  '%UPGRADE%'  --substr(GUARANTEE_ID, 10, 2) in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU', 'CU')
               AND    p1_serial_no IN (
                          SELECT serial_no FROM p_serialized_item_dim si WHERE latest_coverage_type <> 1
                             AND  si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT >= (365*10) - 5
                          )
               AND spl.bundle_key NOT IN
                         (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
                         );


