--[1] --Sale suppression based upon SN --applicable to non-upgrade campaigns only---> if oder exsit then supress
--[2] --if it is Upgrade lead and total length of warranty is >= 10 years then suppress
      --Subtracting 5 days from (365*10) to take care of boundary cases for whatever reasons --> complete 10 years
--[4] --Change of Coverage Type: All campaigns except upgrades
--[5] --Change of Coverage Type: Upgrades

--==> in ticket we will take back old sql
-->and new sql as it s in txt file format
--==> also add date time in sql files


--Sale suppression based upon SN --applicable to non-upgrade campaigns only
 --   INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
    SELECT distinct fct.BUNDLE_KEY,substr(GUARANTEE_ID, 10, 1),GUARANTEE_ID,cell.*
    FROM  gnrc.cell_dim cell
			   JOIN CAMPAIGN_PARTICIPATION_FCT fct
				  on fct.cell_key = cell.cell_key
			   join campaign_spool_file_tbl cp on cp.BUNDLE_KEY = fct.BUNDLE_KEY
    WHERE upper(CELL_DSC) not like  '%UPGRADE%'
        AND p1_serial_no IN (
           SELECT
                  si.serial_no
             FROM
                  p_order_tbl o
                  JOIN p_order_item_tbl oi ON (O.order_key = OI.ORDER_KEY)
                  JOIN P_serialized_item_dim si ON (si.si_key = oi.serialized_item_key)
                  )
     and cp.bundle_key NOT IN
              (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
              );

---#####***********Exit in job **************###----
 --if it is Upgrade lead and total length of warranty is >= 10 years then suppress
 --Subtracting 5 days from (365*10) to take care of boundary cases for whatever reasons
 --Here we covering our sales

--    INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
   SELECT DISTINCT cp.BUNDLE_KEY, 'S', sysdate, 'Sale'
   FROM   gnrc.cell_dim cell
			   JOIN CAMPAIGN_PARTICIPATION_FCT fct
				  on fct.cell_key = cell.cell_key
			   join campaign_spool_file_tbl cp on cp.BUNDLE_KEY = fct.BUNDLE_KEY
   WHERE  upper(CELL_DSC) like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) = 'U'
   AND    p1_serial_no IN (
              SELECT serial_no FROM p_serialized_item_dim si
                               JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = si.SI_KEY
                               JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
                    ---> with serial table we also join in order table to see if at least 1 order exist for this serial
                               WHERE latest_coverage_type <> 1
                 AND  si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT >= (365*10) - 5
                 AND OT.ORDER_CREATED_TS > (sysdate - 60)
            --AND recent sale OT last 60 days orders
              )
   AND cp.BUNDLE_KEY NOT IN
             (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
             );

--    commit;

---#####***********New sql**************###----
 --if it is Upgrade lead and total length of warranty is >= 10 years then suppress
 --Subtracting 5 days from (365*10) to take care of boundary cases for whatever reasons
 --Its catch all SQL to cover what ever will be left after upgrade sale sql above

--    INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
   SELECT DISTINCT cp.BUNDLE_KEY, 'M', sysdate, 'Lead Has 10 Years Coverage'
   FROM   gnrc.cell_dim cell
			   JOIN CAMPAIGN_PARTICIPATION_FCT fct
				  on fct.cell_key = cell.cell_key
			   join campaign_spool_file_tbl cp on cp.BUNDLE_KEY = fct.BUNDLE_KEY
   WHERE  upper(CELL_DSC) like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) = 'U'
   AND    p1_serial_no IN (
              SELECT serial_no FROM p_serialized_item_dim si
                               WHERE  si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT >= (365*10) - 5
              )
   AND cp.BUNDLE_KEY NOT IN
             (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
             );




--Change of Coverage Type: All campaigns except upgrades
--    INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
   SELECT DISTINCT spl.BUNDLE_KEY, 'M', sysdate, 'Change of Coverage Type'
   FROM    gnrc.cell_dim cell
			   JOIN CAMPAIGN_PARTICIPATION_FCT fct
				  on fct.cell_key = cell.cell_key
			   join campaign_spool_file_tbl spl on spl.BUNDLE_KEY = fct.BUNDLE_KEY
            --campaign_spool_file_tbl spl
          JOIN V_BUNDLE_DIM bd on bd.BUNDLE_KEY = spl.BUNDLE_KEY --using (bundle_key)
          JOIN v_bundle_item_xref vx on vx.BUNDLE_KEY = bd.BUNDLE_KEY--USING (bundle_key)
          JOIN p_criteria_dim cd USING (criteria_key)
          JOIN p_serialized_item_dim si USING (si_key)
   WHERE  1=1
   AND   upper(CELL_DSC) not like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) <> 'U'
   AND    NVL(cd.latest_coverage_type, si.latest_coverage_type) <> si.LATEST_COVERAGE_TYPE
   AND    spl.BUNDLE_KEY NOT IN
             (SELECT sup.bundle_key FROM v_suppression_tbl sup WHERE sup.bundle_key IS NOT NULL
             );

--Change of Coverage Type: Upgrades
   SELECT DISTINCT spl.BUNDLE_KEY, 'M', sysdate, 'Change of Coverage Type'
   FROM   gnrc.cell_dim cell
           JOIN CAMPAIGN_PARTICIPATION_FCT fct
              on fct.cell_key = cell.cell_key
           join campaign_spool_file_tbl spl on spl.BUNDLE_KEY = fct.BUNDLE_KEY
            --campaign_spool_file_tbl spl
           JOIN V_BUNDLE_DIM bd on bd.BUNDLE_KEY = spl.BUNDLE_KEY --using (bundle_key)
          JOIN v_bundle_item_xref vx on vx.BUNDLE_KEY = bd.BUNDLE_KEY--USING (bundle_key)
          JOIN p_criteria_dim cd USING (criteria_key)
          JOIN p_serialized_item_dim si USING (si_key)
   WHERE  1=1
   AND     upper(CELL_DSC) like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) = 'U'
   AND    si.LATEST_COVERAGE_TYPE not in (2, 5)
   AND    spl.BUNDLE_KEY NOT IN
            (SELECT sup.bundle_key FROM v_suppression_tbl sup WHERE sup.bundle_key IS NOT NULL
            );
