--Sale suppression based upon bundle
    insert into suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
    select distinct t1.bundle_key, 'S',  sysdate,  'Sale'
    from
           campaign_spool_file_Tbl t1
           join (select spl.bundle_key
                 from   p_order_item_tbl oit
                        join p_campaign_spool_file_tbl spl on spl.reference_id = oit.OFFER_KEY
                 ) t2
              on (t1.bundle_key = t2.bundle_key);


--  --Sale suppression based upon SN --applicable to non-upgrade campaigns only
--     INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
--     SELECT DISTINCT bundle_key, 'S', sysdate, 'Sale'
--     FROM   campaign_spool_file_tbl
--     WHERE  substr(GUARANTEE_ID, 10, 1) <> 'U'
--     AND    p1_serial_no IN (
--            SELECT
--                   si.serial_no
--              FROM
--                   p_order_tbl o
--                   JOIN p_order_item_tbl oi ON (O.order_key = OI.ORDER_KEY)
--                   JOIN P_serialized_item_dim si ON (si.si_key = oi.serialized_item_key)
--                   )
--      and bundle_key NOT IN
--               (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
--               );

--[1] ----Sale suppression based upon SN --applicable to non-upgrade campaigns only
 --   INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
    SELECT DISTINCT cp.bundle_key, 'S', sysdate, 'Sale'
    FROM  gnrc.cell_dim cell
			   JOIN CAMPAIGN_PARTICIPATION_FCT fct
				  on fct.cell_key = cell.cell_key
			   join campaign_spool_file_tbl cp on cp.BUNDLE_KEY = fct.BUNDLE_KEY
    WHERE upper(CELL_DSC) not like  '%UPGRADE%'
        AND p1_serial_no IN (
           SELECT
                  si.serial_no
             FROM
                  p_order_tbl o
                  JOIN p_order_item_tbl oi ON (O.order_key = OI.ORDER_KEY)
                  JOIN P_serialized_item_dim si ON (si.si_key = oi.serialized_item_key)
                  )
     and cp.bundle_key NOT IN
              (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
              );




 --if it is Upgrade lead and total length of warranty is >= 10 years then suppress
 --Subtracting 5 days from (365*10) to take care of boundary cases for whatever reasons
   INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
   SELECT DISTINCT bundle_key, 'S', sysdate, 'Sale'
   FROM   campaign_spool_file_tbl
   WHERE  substr(GUARANTEE_ID, 10, 1) = 'U'
   AND    p1_serial_no IN (
              SELECT serial_no FROM p_serialized_item_dim si WHERE latest_coverage_type <> 1
                 AND  si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT >= (365*10) - 5
              )
   AND bundle_key NOT IN
             (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
             );

--[2]----if it is Upgrade lead and total length of warranty is >= 10 years then suppress
 --Subtracting 5 days from (365*10) to take care of boundary cases for whatever reasons
 --Here we covering our sales
   INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
   SELECT DISTINCT cp.BUNDLE_KEY, 'S', sysdate, 'Sale'
   FROM   gnrc.cell_dim cell
			   JOIN CAMPAIGN_PARTICIPATION_FCT fct
				  on fct.cell_key = cell.cell_key
			   join campaign_spool_file_tbl cp on cp.BUNDLE_KEY = fct.BUNDLE_KEY
   WHERE  upper(CELL_DSC) like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) = 'U'
   AND    p1_serial_no IN (
              SELECT serial_no FROM p_serialized_item_dim si
                               JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = si.SI_KEY
                               JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
                    ---> with serial table we also join in order table to see if at least 1 order exist for this serial
                               WHERE latest_coverage_type <> 1
                 AND  si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT >= (365*10) - 5
                 AND OT.ORDER_CREATED_TS > (sysdate - 60)
            --AND recent sale OT last 60 days orders
              )
   AND cp.BUNDLE_KEY NOT IN
             (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
             );


    commit;

-- [3] --#####***********New sql**************###----
 --if it is Upgrade lead and total length of warranty is >= 10 years then suppress
 --Subtracting 5 days from (365*10) to take care of boundary cases for whatever reasons
 --Its catch all SQL to cover what ever will be left after upgrade sale sql above

--    INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
   SELECT DISTINCT cp.BUNDLE_KEY, 'M', sysdate, 'Lead Has 10 Years Coverage'
   FROM   gnrc.cell_dim cell
			   JOIN CAMPAIGN_PARTICIPATION_FCT fct
				  on fct.cell_key = cell.cell_key
			   join campaign_spool_file_tbl cp on cp.BUNDLE_KEY = fct.BUNDLE_KEY
   WHERE  upper(CELL_DSC) like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) = 'U'
   AND    p1_serial_no IN (
              SELECT serial_no FROM p_serialized_item_dim si
                               WHERE  si.LATEST_COVERAGE_EXP_DT - si.REGISTRATION_DT >= (365*10) - 5
              )
   AND cp.BUNDLE_KEY NOT IN
             (SELECT bundle_key FROM v_suppression_tbl WHERE bundle_key IS NOT NULL
             );
commit;



-- --Change of Coverage Type: All campaigns except upgrades
--    INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
--    SELECT DISTINCT bundle_key, 'M', sysdate, 'Change of Coverage Type'
--    FROM   campaign_spool_file_tbl spl
--           JOIN V_BUNDLE_DIM bd using (bundle_key)
--           JOIN v_bundle_item_xref USING (bundle_key)
--           JOIN p_criteria_dim cd USING (criteria_key)
--           JOIN p_serialized_item_dim si USING (si_key)
--    WHERE  1=1
--    AND    substr(GUARANTEE_ID, 10, 1) <> 'U'
--    AND    NVL(cd.latest_coverage_type, si.latest_coverage_type) <> si.LATEST_COVERAGE_TYPE
--    AND    bundle_key NOT IN
--              (SELECT sup.bundle_key FROM v_suppression_tbl sup WHERE sup.bundle_key IS NOT NULL
--              );

--[4] ----Change of Coverage Type: All campaigns except upgrades
   INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
   SELECT DISTINCT spl.BUNDLE_KEY, 'M', sysdate, 'Change of Coverage Type'
   FROM    gnrc.cell_dim cell
			   JOIN CAMPAIGN_PARTICIPATION_FCT fct
				  on fct.cell_key = cell.cell_key
			   join campaign_spool_file_tbl spl on spl.BUNDLE_KEY = fct.BUNDLE_KEY
            --campaign_spool_file_tbl spl
          JOIN V_BUNDLE_DIM bd on bd.BUNDLE_KEY = spl.BUNDLE_KEY --using (bundle_key)
          JOIN v_bundle_item_xref vx on vx.BUNDLE_KEY = bd.BUNDLE_KEY--USING (bundle_key)
          JOIN p_criteria_dim cd USING (criteria_key)
          JOIN p_serialized_item_dim si USING (si_key)
   WHERE  1=1
   AND   upper(CELL_DSC) not like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) <> 'U'
   AND    NVL(cd.latest_coverage_type, si.latest_coverage_type) <> si.LATEST_COVERAGE_TYPE
   AND    spl.BUNDLE_KEY NOT IN
             (SELECT sup.bundle_key FROM v_suppression_tbl sup WHERE sup.bundle_key IS NOT NULL
             );



--Change of Coverage Type: Upgrades
--    SELECT DISTINCT bundle_key, 'M', sysdate, 'Change of Coverage Type'
--    FROM   campaign_spool_file_tbl spl
--           JOIN V_BUNDLE_DIM bd using (bundle_key)
--           JOIN v_bundle_item_xref USING (bundle_key)
--           JOIN p_criteria_dim cd USING (criteria_key)
--           JOIN p_serialized_item_dim si USING (si_key)
--    WHERE  1=1
--    AND    substr(GUARANTEE_ID, 10, 1) = 'U'
--    AND    si.LATEST_COVERAGE_TYPE not in (2, 5)
--    AND    bundle_key NOT IN
--             (SELECT sup.bundle_key FROM v_suppression_tbl sup WHERE sup.bundle_key IS NOT NULL
--             );

--[5] ----Change of Coverage Type: Upgrades
   INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
   SELECT DISTINCT spl.BUNDLE_KEY, 'M', sysdate, 'Change of Coverage Type'
   FROM   gnrc.cell_dim cell
           JOIN CAMPAIGN_PARTICIPATION_FCT fct
              on fct.cell_key = cell.cell_key
           join campaign_spool_file_tbl spl on spl.BUNDLE_KEY = fct.BUNDLE_KEY
            --campaign_spool_file_tbl spl
           JOIN V_BUNDLE_DIM bd on bd.BUNDLE_KEY = spl.BUNDLE_KEY --using (bundle_key)
          JOIN v_bundle_item_xref vx on vx.BUNDLE_KEY = bd.BUNDLE_KEY--USING (bundle_key)
          JOIN p_criteria_dim cd USING (criteria_key)
          JOIN p_serialized_item_dim si USING (si_key)
   WHERE  1=1
   AND     upper(CELL_DSC) like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 1) = 'U'
   AND    si.LATEST_COVERAGE_TYPE not in (2, 5)
   AND    spl.BUNDLE_KEY NOT IN
            (SELECT sup.bundle_key FROM v_suppression_tbl sup WHERE sup.bundle_key IS NOT NULL
            );




 --Suppress Customer DNS
    INSERT INTO suppression_tbl (BUNDLE_KEY, SUPPRESSION_CD, INSERTED_DT, SUPPRESSION_REASON)
    SELECT DISTINCT spl.bundle_key,
              'M',
              sysdate,
              'Customer DNS'
    FROM  campaign_spool_file_tbl spl
    WHERE customer_key IN
          (  select customer_key
              from p_customer_dim cust
             where 1=2
                or ( nvl(derived_suppression_cd, 'N') <> 'N'
                     or nvl(ADDRESS_SUPPRESSION_CD, 'N') = 'Y' )
          )
    --AND channel_nm = 'MAIL'
    AND  spl.bundle_key NOT IN
           (SELECT sup.bundle_key FROM V_SUPPRESSION_TBL sup
            where sup.bundle_key is not null
           ) ;


SELECT SUPPRESSION_REASON, count(*), count(distinct BUNDLE_KEY)
  FROM campaign_spool_file_tbl spl join suppression_tbl sup using (bundle_key)
 GROUP BY SUPPRESSION_REASON;


    DELETE FROM campaign_spool_file_tbl
    WHERE BUNDLE_KEY IN (
              SELECT BUNDLE_KEY FROM suppression_tbl);

    COMMIT;