--solicitation/client_specific/post_spool_suppression_common

----------------------------------------------------------------
--############################################################--
----------------------------------------------------------------
                --dealer sold warranty suppression. Applies to all except Upgrade campaigns
                -- INSERT INTO suppression_tbl
                SELECT DISTINCT spl.bundle_key,
                  'D',
                  sysdate,
                  'Warranty sold outside After systems'
                  ,'v_audit_key'
                FROM offer_item_xref oix
                     join campaign_spool_file_Tbl spl on spl.reference_id = oix.OFFER_KEY
                 --New
                    JOIN CAMPAIGN_PARTICIPATION_FCT fct on spl.BUNDLE_KEY = fct.BUNDLE_KEY
                    JOIN gnrc.cell_dim cell   on fct.cell_key = cell.cell_key
                WHERE upper(CELL_DSC) not like  '%UPGRADE%' --substr(GUARANTEE_ID, 10, 2) not in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU')
                AND si_key IN
                  ( SELECT si_key FROM P_serialized_item_dim WHERE latest_coverage_type IN ('5', '18', '11')
                  )
                AND spl.bundle_key NOT IN
                     (SELECT bundle_key FROM suppression_tbl
                      );
----------------------------------------------------------------
--############################################################--
----------------------------------------------------------------
--


-- later added

-- post_spool_suppression_common.job
--[1]
 --dealer sold warranty suppression. Applies to all except Upgrade campaigns
               -- INSERT INTO suppression_tbl
                SELECT DISTINCT spl.bundle_key,
                  'D',
                  sysdate,
                  'Warranty sold outside After systems'
                  ,'v_audit_key'
                FROM offer_item_xref oix
                     join campaign_spool_file_Tbl spl on spl.reference_id = oix.OFFER_KEY
                    JOIN CAMPAIGN_PARTICIPATION_FCT fct on spl.BUNDLE_KEY = fct.BUNDLE_KEY
                    JOIN gnrc.cell_dim cell on fct.cell_key = cell.cell_key
                WHERE upper(CELL_DSC) not like  '%UPGRADE%'  --substr(GUARANTEE_ID, 10, 2) not in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU', 'CU')
                AND si_key IN
                  ( SELECT si_key FROM P_serialized_item_dim WHERE latest_coverage_type IN ('5', '18', '11')
                  )
                AND spl.bundle_key NOT IN
                     (SELECT bundle_key FROM suppression_tbl
                      );

--[2]
--dealer sold warranty suppression. Applies to all except Upgrade campaign
               -- INSERT INTO suppression_tbl
                SELECT DISTINCT spl.bundle_key,
                  'D',
                  sysdate,
                  'Warranty sold outside After systems',
                  'v_audit_key'
                FROM offer_item_xref oix
                     join campaign_spool_file_Tbl spl on spl.reference_id = oix.OFFER_KEY
                    JOIN CAMPAIGN_PARTICIPATION_FCT fct on spl.BUNDLE_KEY = fct.BUNDLE_KEY
                    JOIN gnrc.cell_dim cell on fct.cell_key = cell.cell_key
                WHERE upper(CELL_DSC) not like  '%UPGRADE%'  --substr(GUARANTEE_ID, 10, 2) not in ('UP', 'US', 'UE', 'UM', 'UA', 'UN', 'MU', 'CU')
                AND si_key IN
                  ( SELECT si.si_key FROM P_serialized_item_dim si join gnrc.raw_dealer_sold_warranties r ON (ltrim(r.equipment, '0') = si.serial_no)
                  )
                AND spl.bundle_key NOT IN
                     (SELECT bundle_key FROM suppression_tbl
                      );

--[3]


