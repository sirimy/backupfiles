--  delete from RAW_LEADS_TBL_AS12_OCT_NOV_2024;

select AT1.CREATION_DT,AT1.AUDIT_KEY,COUNT(*) FROM RAW_LEADS_TBL_AS12_OCT_NOV_2024 onc
         JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = onc.INSERT_AUDIT_KEY
 group by AT1.CREATION_DT,AT1.AUDIT_KEY
Order by AT1.CREATION_DT desc
;
-- +--------------------------+---------+--------+
-- |CREATION_DT               |AUDIT_KEY|COUNT(*)|
-- +--------------------------+---------+--------+
-- |2024-11-07 06:02:26.000000|1012287  |7657    |
-- |2024-10-09 04:17:23.000000|1003916  |5348    |
-- +--------------------------+---------+--------+




select * from RAW_LEADS_TBL_AS12_OCT_NOV_2024;

Insert into RAW_LEADS_TBL_AS12_OCT_NOV_2024(  OWNER_NAME    ,
                            OWNER_ADDRESS1    ,
                            OWNER_CITY    ,
                            OWNER_STATE    ,
                            OWNER_POSTCODE    ,
                            OWNER_PHONE_NUMBER    ,
                            OWNER_EMAIL    ,
                            EQUIPMENT    ,
                            VALID_FROM_DATE    ,
                            MATERIAL    ,
                            MATERIAL_NAME    ,
                            PURCHASE_DATE    ,
                            PRODUCT_HIER_LEVEL1    ,
                            PRODUCT_HIER_LEVEL1_NAME    ,
                            PRODUCT_HIER_LEVEL2    ,
                            PRODUCT_HIER_LEVEL2_NAME    ,
                            MASTER_WARRANTY_NUMBER    ,
                            MASTER_WARRANTY_DESC    ,
                            WARRANTY_START_DATE    ,
                            MIN_WARRANTY_END_DT    ,
                            MAX_WARRANTY_END_DT    ,
                            NOTIFICATION_COUNT    ,
                            FILE_NM    ,
                            INSERT_AUDIT_KEY    ,
                            ERROR_DESC    ,
                            PRODUCT_HIRE_LEVEL3    ,
                            PRODUCT_HIRE_LEVEL_3_NAME    ,
                            SALES_OFFICE
                            )
select  OWNER_NAME    ,
        OWNER_ADDRESS1    ,
        OWNER_CITY    ,
        OWNER_STATE    ,
        OWNER_POSTCODE    ,
        OWNER_PHONE_NUMBER    ,
        OWNER_EMAIL    ,
        EQUIPMENT    ,
        VALID_FROM_DATE    ,
        MATERIAL    ,
        MATERIAL_NAME    ,
        PURCHASE_DATE    ,
        PRODUCT_HIER_LEVEL1    ,
        PRODUCT_HIER_LEVEL1_NAME    ,
        PRODUCT_HIER_LEVEL2    ,
        PRODUCT_HIER_LEVEL2_NAME    ,
        MASTER_WARRANTY_NUMBER    ,
        MASTER_WARRANTY_DESC    ,
        WARRANTY_START_DATE    ,
        MIN_WARRANTY_END_DT    ,
        MAX_WARRANTY_END_DT    ,
        NOTIFICATION_COUNT    ,
        'AS12_customer_handling_'||to_char(sysdate,'MMDDYYYY')||'.txt' as FILE_NM    ,
        TC_INSERT_AUDIT_KEY   ,
        NULL as ERROR_DESC    ,
        PRODUCT_HIRE_LEVEL3    ,
        PRODUCT_HIRE_LEVEL_3_NAME    ,
        SALES_OFFICE
          from  (
            select RL.*,TC.INSERT_AUDIT_KEY TC_INSERT_AUDIT_KEY,
                   ROW_NUMBER()  OVER (PARTITION BY TC.CUSTOMER_KEY,TC.SERIAL_NO ORDER BY RL.INSERT_AUDIT_KEY DESC) AS rn
             from TMP_CUSTOMERS_NCOA_OCT_NOV_2024 TC
             join GNRC.CUSTOMER_DIM  CD
             ON ( TC.CUSTOMER_KEY = CD.CUSTOMER_KEY)
             join GNRC.VISITOR_OWNERSHIP_XREF  VOX
             ON ( VOX.VISITOR_KEY = CD.PRIMARY_VISITOR_KEY --AND VOX.PRIMARY_IND = 'Y'
                 )
             join GNRC.SERIALIZED_ITEM_DIM SI
             ON  (SI.SI_KEY = VOX.SI_KEY  AND SI.SERIAL_NO = TC.SERIAL_NO )
             join GNRC.RAW_LEADS_TBL RL
             ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)

             )
        where rn = 1;