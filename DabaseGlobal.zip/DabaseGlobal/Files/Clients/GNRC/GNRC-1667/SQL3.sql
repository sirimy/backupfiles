select COUNT(*)
        from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RLT
            JOIN GNRC.SERIALIZED_ITEM_DIM SID on SID.SERIAL_NO = LTRIM(TRIM(EQUIPMENT),'0')
            JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = SID.PRODUCT_KEY
            JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY
            JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            LEFT JOIN date_dim dd on dd.DATE_KEY = SID.PURCHASE_DT_KEY
            JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = OIT.INSERT_AUDIT_KEY
where AT1.CREATION_DT > date '2024-10-01';--38

  select SID.SI_KEY ,OIT.ORDER_KEY,AT1.CREATION_DT ORDER_CREATED
        ,VP.BRAND_NM,VP.PARENT_CATEGORY_NM,OT.SALES_SOURCE_CD,DD.FULL_DT AS PURCHASE_DT,ot.ORDER_CREATED_TS
        from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RLT
            JOIN GNRC.SERIALIZED_ITEM_DIM SID on SID.SERIAL_NO = LTRIM(TRIM(EQUIPMENT),'0')
            JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = SID.PRODUCT_KEY
            JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY
            JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            LEFT JOIN date_dim dd on dd.DATE_KEY = SID.PURCHASE_DT_KEY
            JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = OIT.INSERT_AUDIT_KEY
        where AT1.CREATION_DT > date '2024-10-01'
            order by CREATION_DT desc
;


create table RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA as (
  select distinct  SID.SI_KEY,SID.SERIAL_NO,RLT.EQUIPMENT ,OIT.ORDER_KEY
        ,VP.BRAND_NM,VP.PARENT_CATEGORY_NM,OT.SALES_SOURCE_CD,SP.MAIL_DROP_DATE,OT.PURCHASE_DT,ot.ORDER_CREATED_TS
       ,SP.ADDRESS_LINE1_TX OFFER,SP.CITY_NM OFFER_CITY_NM ,SP.STATE_CD OFFER_STATE_CD ,ST1.TAXABLE_STATUS OFFER_TAXABLE_STATUS
        ,AD.ADDRESS_LINE1_TX CST,AD.CITY_NM AD_CITY_NM  ,AD.STATE_CD AD_STATE_CD
        ,AD1.ADDRESS_LINE1_TX SHIP,AD1.CITY_NM SHIP_CITY_NM ,AD1.STATE_CD SHIP_STATE_CD ,ST2.TAXABLE_STATUS SHIP_TAXABLE_STATUS
        ,AD2.ADDRESS_LINE1_TX BILL,AD2.CITY_NM BILL_CITY_NM ,AD2.STATE_CD BILL_STATE_CD
        from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RLT
            JOIN GNRC.SERIALIZED_ITEM_DIM SID on SID.SERIAL_NO = LTRIM(TRIM(EQUIPMENT),'0')
            JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = SID.PRODUCT_KEY
            JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY
            JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            JOIN GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = OT.VISITOR_KEY
            JOIN GNRC.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            JOIN GNRC.SHIPPING_INFO_TBL SOT on SOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.BILLING_INFO_TBL BOT on BOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = SOT.ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD2 on AD2.ADDRESS_KEY = BOT.ADDRESS_KEY
--             LEFT JOIN date_dim dd on dd.DATE_KEY = SID.PURCHASE_DT_KEY
--             JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = OIT.INSERT_AUDIT_KEY
            LEFT JOIN GNRC.CAMPAIGN_SPOOL_FILE_TBL SP ON SP.REFERENCE_ID = OIT.OFFER_KEY
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st1 ON ST1.STATE_CD = sP.STATE_CD
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st2 ON st2.STATE_CD = AD1.STATE_CD

      where OT.ORDER_CREATED_TS > date '2024-10-01'
            )
;

select * from RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA;


select distinct  SID.SI_KEY,SID.SERIAL_NO,RLT.EQUIPMENT ,OIT.ORDER_KEY
        ,VP.BRAND_NM,VP.PARENT_CATEGORY_NM,OT.SALES_SOURCE_CD,SP.MAIL_DROP_DATE,OT.PURCHASE_DT,ot.ORDER_CREATED_TS
       ,SP.ADDRESS_LINE1_TX OFFER,SP.CITY_NM OFFER_CITY_NM ,SP.STATE_CD OFFER_STATE_CD ,ST1.TAXABLE_STATUS OFFER_TAXABLE_STATUS
        ,AD.ADDRESS_LINE1_TX CST,AD.CITY_NM AD_CITY_NM  ,AD.STATE_CD AD_STATE_CD
        ,AD1.ADDRESS_LINE1_TX SHIP,AD1.CITY_NM SHIP_CITY_NM ,AD1.STATE_CD SHIP_STATE_CD ,ST2.TAXABLE_STATUS SHIP_TAXABLE_STATUS
        ,AD2.ADDRESS_LINE1_TX BILL,AD2.CITY_NM BILL_CITY_NM ,AD2.STATE_CD BILL_STATE_CD
        from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RLT
            JOIN GNRC.SERIALIZED_ITEM_DIM SID on SID.SERIAL_NO = LTRIM(TRIM(EQUIPMENT),'0')
            JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = SID.PRODUCT_KEY
            JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY
            JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
            JOIN GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = OT.VISITOR_KEY
            JOIN GNRC.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            JOIN GNRC.SHIPPING_INFO_TBL SOT on SOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.BILLING_INFO_TBL BOT on BOT.ORDER_KEY = OT.ORDER_KEY
            JOIN GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = SOT.ADDRESS_KEY
            JOIN GNRC.ADDRESS_DIM AD2 on AD2.ADDRESS_KEY = BOT.ADDRESS_KEY
--             LEFT JOIN date_dim dd on dd.DATE_KEY = SID.PURCHASE_DT_KEY
--             JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = OIT.INSERT_AUDIT_KEY
            LEFT JOIN GNRC.CAMPAIGN_SPOOL_FILE_TBL SP ON SP.REFERENCE_ID = OIT.OFFER_KEY
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st1 ON ST1.STATE_CD = sP.STATE_CD
            LEFT JOIN GNRC.STATE_TAX_STATUS_DIM st2 ON st2.STATE_CD = AD1.STATE_CD

      where OT.ORDER_CREATED_TS > date '2024-10-01';

Select * from GNRC.ORDER_TBL where ORDER_KEY = 891645;
+---------+---------+-------------------+----------+--------------------------+
|ORDER_KEY|ORDER_XID|BILLING_PROFILE_KEY|CREATED_BY|PURCHASE_DT               |
+---------+---------+-------------------+----------+--------------------------+
|891645   |2619041  |178323943          |SYSTEM    |2024-12-10 18:00:00.486000|
+---------+---------+-------------------+----------+--------------------------+

Select * from GNRC.ORDER_ITEM_TBL where ORDER_KEY = 891645;
+---------+--------------+--------------+--------------+-------------------+
|ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY     |OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|
+---------+--------------+--------------+--------------+-------------------+
|891645   |1             |11844425005984|1             |1859035            |
+---------+--------------+--------------+--------------+-------------------+
select * from GNRC.CAMPAIGN_SPOOL_FILE_TBL SP where  SP.P1_SERIAL_NO ='3014036565' ORDER BY MAIL_DROP_DATE desc;



select * from GNRC.CAMPAIGN_SPOOL_FILE_TBL SP where  SP.REFERENCE_ID like '011844425005984';

+---------------+--------+-------+-------------------+-----------+--------+------------+------------+-----------------+--------------------+--------------+-------------------+-------------+--------------+----+---------------+
|REFERENCE_ID   |FIRST_NM|LAST_NM|ADDRESS_LINE1_TX   |CITY_NM    |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|EMAIL_ADDRESS    |GUARANTEE_ID        |MAIL_DROP_DATE|EST_MAIL_IN_HOME_DT|OBTM_START_DT|EMAIL_START_DT|WAVE|OFFER_EXPIRE_DT|
+---------------+--------+-------+-------------------+-----------+--------+------------+------------+-----------------+--------------------+--------------+-------------------+-------------+--------------+----+---------------+
|011844425005984|LEIGH   |MARTS  |11261 RIVERCREST DR|LITTLE ROCK|AR      |72212       |1417        |LTMARTS@GMAIL.COM|202436GNPAI04017B301|2024-12-03    |2024-12-10         |NULL         |2024-12-11    |NULL|2025-01-08     |
|011844425005984|LEIGH   |MARTS  |11261 RIVERCREST DR|LITTLE ROCK|AR      |72212       |1417        |LTMARTS@GMAIL.COM|202436GNPAI04017B301|2024-12-03    |2024-12-10         |NULL         |2024-12-11    |NULL|2025-01-08     |
+---------------+--------+-------+-------------------+-----------+--------+------------+------------+-----------------+--------------------+--------------+-------------------+-------------+--------------+----+---------------+


Select * from GNRC.SERIALIZED_ITEM_DIM where SI_KEY = 1859035;
+-------+-----------+----------+--------+---------------+---------------+--------------------------+
|SI_KEY |PRODUCT_KEY|SERIAL_NO |MODEL_NO|REGISTRATION_DT|PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |
+-------+-----------+----------+--------+---------------+---------------+--------------------------+
|1859035|60808      |3014036565|G0089170|2024-01-09     |12427          |2025-01-08 00:00:00.000000|
+-------+-----------+----------+--------+---------------+---------------+--------------------------+
Select * from GNRC.RAW_LEADS_TBL where EQUIPMENT like '%3014036565%';
+---------------------------------------------------+-----------+----------------+----------+-----------+--------------+------------------+
|FILE_NM                                            |OWNER_NAME |OWNER_ADDRESS1  |OWNER_CITY|OWNER_STATE|OWNER_POSTCODE|EQUIPMENT         |
+---------------------------------------------------+-----------+----------------+----------+-----------+--------------+------------------+
|gnrc_after_leads_2024-03-13-14-56-32.txt           |Leigh Marts|891 Fred Koch Rd|Lonoke    |AR         |72086-9235    |000000003014036565|
|AS12_nov_customer_handling_2024-12-06-gnrc-1668.txt|Leigh Marts|891 Fred Koch Rd|Lonoke    |AR         |72086-9235    |000000003014036565|
+---------------------------------------------------+-----------+----------------+----------+-----------+--------------+------------------+
select * from GNRC.ADDRESS_DIM where ADDRESS_LINE1_TX in ('11261 RIVERCREST DR','891 FRED KOCH RD');
+-----------+---------+--------+-------+-------------------+-----------+--------+------------+------------+
|ADDRESS_KEY|SOURCE_CD|FIRST_NM|LAST_NM|ADDRESS_LINE1_TX   |CITY_NM    |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
+-----------+---------+--------+-------+-------------------+-----------+--------+------------+------------+
|7958228    |NULL     |LEIGH   |MARTS  |891 FRED KOCH RD   |LONOKE     |AR      |72086       |9235        |--CST -- BILL -SHIP
|8691566    |NCOA     |LEIGH   |MARTS  |11261 RIVERCREST DR|LITTLE ROCK|AR      |72212       |1417        |--OFFER adddress used
+-----------+---------+--------+-------+-------------------+-----------+--------+------------+------------+

    +-----------+---------+--------+-------+-------------------+-----------+--------+------------+------------+
    +-----------+---------+--------+-------+-------------------+-----------+--------+------------+------------+
    +-----------+---------+--------+-------+-------------------+-----------+--------+------------+------------+


Select * from GNRC.ORDER_TBL where ORDER_KEY = 891379;
+---------+---------+--------------------+--------------------------+
|ORDER_KEY|ORDER_XID|CREATED_BY          |PURCHASE_DT               |
+---------+---------+--------------------+--------------------------+
|891379   |2618908  |bgeorge@afterinc.com|2024-12-02 00:00:00.000000|
+---------+---------+--------------------+--------------------------+
Select * from GNRC.ORDER_ITEM_TBL where ORDER_KEY = 891379;
+---------+--------------+--------------+--------------+-------------------+
|ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY     |OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|
+---------+--------------+--------------+--------------+-------------------+
|891379   |1             |11912768065038|1             |1804021            |
+---------+--------------+--------------+--------------+-------------------+

select * from GNRC.CAMPAIGN_SPOOL_FILE_TBL SP where  SP.REFERENCE_ID like '011844425005984';
+---------------+--------+-------+----------------+-----------------+--------+------------+------------+------------+--------------------------+--------------------+--------------+-------------------+--------------+---------------+---------------+
|REFERENCE_ID   |FIRST_NM|LAST_NM|ADDRESS_LINE1_TX|CITY_NM          |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|PHONE_NUMBER|EMAIL_ADDRESS             |GUARANTEE_ID        |MAIL_DROP_DATE|EST_MAIL_IN_HOME_DT|EMAIL_START_DT|OFFER_EXPIRE_DT|CONTRACT_EXP_DT|
+---------------+--------+-------+----------------+-----------------+--------+------------+------------+------------+--------------------------+--------------------+--------------+-------------------+--------------+---------------+---------------+
|011912768065038|CLAIR   |MYERS  |307 SAN JUAN DR |PONTE VEDRA BEACH|FL      |32082       |1819        |NULL        |JEFFERSONMYERS07@GMAIL.COM|202440GNHM500205B220|2024-11-19    |2024-11-26         |2024-11-27    |2024-12-30     |2025-10-04     |
|011912768065038|CLAIR   |MYERS  |307 SAN JUAN DR |PONTE VEDRA BEACH|FL      |32082       |1819        |NULL        |JEFFERSONMYERS07@GMAIL.COM|202440GNHM500205B220|2024-11-19    |2024-11-26         |2024-11-27    |2024-12-30     |2025-10-04     |
+---------------+--------+-------+----------------+-----------------+--------+------------+------------+------------+--------------------------+--------------------+--------------+-------------------+--------------+---------------+---------------+


select AT1.CREATION_DT,T1.* from GNRC.CAMPAIGN_SPOOL_FILE_TBL T1
          JOIN AUDIT_TBL AT1 on T1.INSERT_AUDIT_KEY = AT1.AUDIT_KEY
         where  T1.REFERENCE_ID like '011844425005984';

Select * from GNRC.SERIALIZED_ITEM_DIM where SI_KEY = 1804021;
+-------+-----------+----------+--------+---------------+--------------------------+
|SI_KEY |PRODUCT_KEY|SERIAL_NO |MODEL_NO|PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |
+-------+-----------+----------+--------+---------------+--------------------------+
|1804021|52202      |3013158839|G0072090|12331          |2025-10-04 00:00:00.000000|
+-------+-----------+----------+--------+---------------+--------------------------+

Select * from GNRC.RAW_LEADS_TBL where EQUIPMENT like '%3013158839%';
+---------------------------------------------------+-----------+---------------+-----------------+-----------+--------------+------------------+------------------+
|FILE_NM                                            |OWNER_NAME |OWNER_ADDRESS1 |OWNER_CITY       |OWNER_STATE|OWNER_POSTCODE|OWNER_PHONE_NUMBER|EQUIPMENT         |
+---------------------------------------------------+-----------+---------------+-----------------+-----------+--------------+------------------+------------------+
|gnrc_after_leads_2023-12-06-14-56-53.txt           |Clair Myers|307 San Juan Dr|Ponte Vedra Beach|FL         |32082-1819    |2032472251        |000000003013158839|
|AS12_nov_customer_handling_2024-12-06-gnrc-1668.txt|Clair Myers|307 San Juan Dr|Ponte Vedra Beach|FL         |32082-1819    |2032472251        |000000003013158839|
+---------------------------------------------------+-----------+---------------+-----------------+-----------+--------------+------------------+------------------+

select * from GNRC.ADDRESS_DIM where ADDRESS_LINE1_TX in ('307 SAN JUAN DR');
+-----------+--------+-------+----------------+-----------------+--------+------------+------------+
|ADDRESS_KEY|FIRST_NM|LAST_NM|ADDRESS_LINE1_TX|CITY_NM          |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
+-----------+--------+-------+----------------+-----------------+--------+------------+------------+
|7683200    |CLAIR   |MYERS  |307 SAN JUAN DR |PONTE VEDRA BEACH|FL      |32082       |1819        |--OFFER--CST--BILL--SHIP
+-----------+--------+-------+----------------+-----------------+--------+------------+------------+

    Select * from GNRC.RAW_LEADS_TBL where EQUIPMENT like '%3014036565%';


select * from GNRC.LATEST_COVERAGE_TYPE_DIM order by COVERAGE_TYPE_KEY;
-- +-----------------+---------------------------------------+---------------------------------------+
-- |COVERAGE_TYPE_KEY|NAME                                   |DESCRIPTION                            |
-- +-----------------+---------------------------------------+---------------------------------------+
-- |1                |MNF WARRANTY                           |MNF WARRANTY                           |
-- |2                |Extended WARRANTY                      |Extended WARRANTY                      |
-- |3                |Cancelled WARRANTY                     |Cancelled WARRANTY                     |
-- |5                |Dealer Sale                            |Dealer Sale                            |
-- |6                |Generac Suppressed                     |Generac Suppressed                     |
-- |7                |Change in ownership                    |Change in ownership                    |
-- |10               |Missing Model Leads                    |Missing Model Leads                    |
-- |11               |Missing Model Upgrade Leads            |Missing Model Upgrade Leads            |
-- |17               |Serial Suppressed                      |Serial Suppressed                      |
-- |18               |Warranty Sold Outside After Inc Systems|Warranty Sold Outside After Inc Systems|
-- |19               |Error                                  |Serial is in Error                     |
-- |20               |Permanent Dealer suppression           |Permanent Dealer suppression           |
-- |21               |Dealer Sale with 10 Year Coverage      |Dealer Sale with 10 Year Coverage      |
-- +-----------------+---------------------------------------+---------------------------------------+
select LATEST_COVERAGE_TYPE,COUNT(*) from GNRC.SERIALIZED_ITEM_DIM group by  LATEST_COVERAGE_TYPE;

Select * from GNRC.CRITERIA_DIM where ACTIVE_IND = 'N' AND CRITERIA_CD like '%MU%' order by  CRITERIA_XID;

SELECT SUPPRESSION_REASON, count(*), count(distinct BUNDLE_KEY)
  FROM campaign_spool_file_tbl spl join suppression_tbl sup using (bundle_key)
 GROUP BY SUPPRESSION_REASON;
-- +-----------------------+--------+-------------------------+
-- |SUPPRESSION_REASON     |COUNT(*)|COUNT(DISTINCTBUNDLE_KEY)|
-- +-----------------------+--------+-------------------------+
-- |Sale                   |94      |51                       |
-- |Change of Coverage Type|8       |4                        |
-- |Bad DM/Email Addresses |6       |3                        |
-- +-----------------------+--------+-------------------------+

--0

select SUPPRESSION_REASON,COUNT(*) from suppression_tbl group by SUPPRESSION_REASON order by SUPPRESSION_REASON;
-- +----------------------------------------------+--------+
-- |SUPPRESSION_REASON                            |COUNT(*)|
-- +----------------------------------------------+--------+
-- |10 year dealer sold warranty                  |17      |
-- |Ace error stat                                |6715    |
-- |Bad DM Addresses                              |4       |
-- |Bad DM/Email Addresses                        |114     |
-- |Change of Coverage Type                       |368     |
-- |Change of Ownership                           |427     |
-- |Customer DNS                                  |88      |
-- |DPBC IS NULL                                  |1       |
-- |Ext Warranty Canceled                         |1       |
-- |Has 10 Years Coverage                         |25      |
-- |MPOS or AI lead with 5 year (or more) warranty|855     |
-- |NCOA-HSB - USA                                |2773    |
-- |Past max product purchase date                |1       |
-- |Sale                                          |2445    |
-- |State Suppression - USA                       |87      |
-- |Tax error                                     |1       |
-- |Tax exceptions - USA                          |23      |
-- |Warranty sold outside After systems           |1       |
-- +----------------------------------------------+--------+

-- +----------------------------------------------+--------+
-- |SUPPRESSION_REASON                            |COUNT(*)|
-- +----------------------------------------------+--------+
-- |10 year dealer sold warranty                  |17      |
-- |Ace error stat                                |6715    |
-- |Bad DM Addresses                              |4       |
-- |Bad DM/Email Addresses                        |114     |
-- |Change of Coverage Type                       |368     |
-- |Change of Ownership                           |427     |
-- |Customer DNS                                  |88      |
-- |DPBC IS NULL                                  |1       |
-- |Ext Warranty Canceled                         |1       |
-- |Has 10 Years Coverage                         |25      |
-- |MPOS or AI lead with 5 year (or more) warranty|855     |
-- |NCOA-HSB - USA                                |2773    |
-- |Past max product purchase date                |1       |
-- |Sale                                          |2445    |
-- |State Suppression - USA                       |87      |
-- |Tax error                                     |1       |
-- |Tax exceptions - USA                          |23      |
-- |Warranty sold outside After systems           |1       |
-- +----------------------------------------------+--------+

--+----------------------------------------------+--------+
|SUPPRESSION_REASON                            |COUNT(*)|
+----------------------------------------------+--------+
|10 year dealer sold warranty                  |17      |
|Ace error stat                                |6715    |
|Bad DM Addresses                              |4       |
|Bad DM/Email Addresses                        |114     |
|Change of Coverage Type                       |368     |
|Change of Ownership                           |427     |
|Customer DNS                                  |88      |
|DPBC IS NULL                                  |1       |
|Ext Warranty Canceled                         |1       |
|Has 10 Years Coverage                         |25      |
|MPOS or AI lead with 5 year (or more) warranty|855     |
|NCOA-HSB - USA                                |2773    |
|Past max product purchase date                |1       |
|Sale                                          |2462    |
|State Suppression - USA                       |87      |
|Tax error                                     |1       |
|Tax exceptions - USA                          |23      |
|Warranty sold outside After systems           |1       |
+----------------------------------------------+--------+
