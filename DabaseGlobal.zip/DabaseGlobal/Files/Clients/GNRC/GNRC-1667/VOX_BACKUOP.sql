
select * from GNRC.VISITOR_OWNERSHIP_XREF;

select COUNT(*) from GNRC.VISITOR_OWNERSHIP_XREF;--2032954

-- create table VISITOR_OWNERSHIP_XREF_20241205 AS
-- select * from GNRC.VISITOR_OWNERSHIP_XREF;
-- Add comment Ticket number


select COUNT(*) AS CORE from GNRC.VISITOR_OWNERSHIP_XREF
UNION ALL
select COUNT(*) AS BKP from VISITOR_OWNERSHIP_XREF_20241205;
-- +-------+
-- |CORE   |
-- +-------+
-- |2032954|
-- |2032954|
-- +-------+
-- create table visitor_history_tbl_20241205 AS
-- select * from GNRC.visitor_history_tbl;
-- Add comment Ticket number
--[2024-12-05 13:04:56] 2,277,860 rows affected in 3 s 877 ms
-- create table visitor_address_xref_20241205 AS
-- select * from GNRC.visitor_address_xref;
--[2024-12-05 13:05:36] 2,134,407 rows affected in 5 s 146 ms
-- create table VISITOR_EMAIL_XREF_20241205 AS
-- select * from GNRC.VISITOR_EMAIL_XREF;
--[2024-12-05 13:10:16] 1,471,683 rows affected in 4 s 233 ms
-- create table VISITOR_PHONE_XREF_20241205 AS
-- select * from GNRC.VISITOR_PHONE_XREF;
--[2024-12-05 13:11:03] 2,303,850 rows affected in 5 s 186 ms
-- create table visitor_purl_xref_20241205 AS
--  select * from GNRC.visitor_purl_xref;
--[2024-12-05 13:13:49] 2,179,033 rows affected in 4 s 191 ms

 select COUNT(*) from GNRC.visitor_history_tbl;--2277860
select COUNT(*) from GNRC.visitor_address_xref;--2134407
select COUNT(*) from GNRC.VISITOR_EMAIL_XREF;--1471683
select COUNT(*) from GNRC.VISITOR_PHONE_XREF;--2303850
select COUNT(*) from GNRC.visitor_purl_xref;--2179033

select COUNT(*) from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205;--4870




select COUNT(*) from GNRC.visitor_history_tbl where VISITOR_KEY in (
    select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
    );--4877
--


select COUNT(*) from GNRC.visitor_address_xref where VISITOR_KEY in (
    select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
    );--4875



    select COUNT(*) from GNRC.VISITOR_EMAIL_XREF where VISITOR_KEY in (
    select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
    );--9
--

  select COUNT(*) from GNRC.VISITOR_PHONE_XREF where VISITOR_KEY in (
    select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
    );--9



--[2024-12-05 13:22:06] 4,880 rows affected in 793 ms
 select COUNT(*) from GNRC.visitor_purl_xref where VISITOR_KEY in (
    select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
    );--4880



--
-- create table VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 AS
--     select * from GNRC.VISITOR_OWNERSHIP_XREF VOX
--     where (VOX.SI_KEY, VOX.VISITOR_KEY) in (
--             select  VOXAS12.SI_KEY, VOXAS12.VISITOR_KEY
--             from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 VOXAS12
--             where INSERT_AUDIT_KEY <> 1016865
-- );

select COUNT(*) from GNRC.VISITOR_OWNERSHIP_XREF VOX
    where (VOX.SI_KEY, VOX.VISITOR_KEY) in (
            select  VOXAS12.SI_KEY, VOXAS12.VISITOR_KEY
            from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 VOXAS12
            where INSERT_AUDIT_KEY <> 1016865
);--4870

COMMIT;

select COUNT(*) from GNRC.VISITOR_OWNERSHIP_XREF VOX
   where (VOX.SI_KEY, VOX.VISITOR_KEY) in ( select  VOXAS12.SI_KEY, VOXAS12.VISITOR_KEY
                                            from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 VOXAS12
                                            where INSERT_AUDIT_KEY <> 1016865)
    and (VOX.SI_KEY, VOX.VISITOR_KEY) in (
                                            select SI.SI_KEY,VOX.VISITOR_KEY
                                            from
                                                     RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
                                                     join GNRC.SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
                                                      LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
                                                      LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
                                                      LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
                                                      LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
                                            where ERROR_DESC IS NULL
                                            AND RL.INSERT_AUDIT_KEY = 1003916 -- oct
                                    );--4870






--
-- create table VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024_2nd as
--     select * from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024;

select primary_ind,COUNT(*) from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 group by  primary_ind;
-- +-----------+--------+
-- |PRIMARY_IND|COUNT(*)|
-- +-----------+--------+
-- |Y          |5333    |
-- +-----------+--------+

 MERGE INTO VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 vox
                 USING
                 (
		SELECT VISITOR_KEY,SI_KEY,PURCHASE_DT_KEY,EFF_DT_KEY,END_DT_KEY,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY,PRIMARY_IND
                   	FROM p_visitor_ownership_xref core
                   	where primary_ind='Y' and exists(
                                                select 1 from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 stg where stg.si_key=core.si_key
                                                    )
                 )vrx
                 ON(vox.VISITOR_KEY=vrx.VISITOR_KEY and vox.SI_KEY=vrx.SI_KEY)
                 WHEN MATCHED THEN UPDATE
                 set
                 vox.PURCHASE_DT_KEY=GREATEST(vrx.PURCHASE_DT_KEY,vox.PURCHASE_DT_KEY),
                 vox.EFF_DT_KEY=GREATEST(vrx.EFF_DT_KEY,vox.EFF_DT_KEY)
                WHEN NOT MATCHED THEN
                INSERT(VISITOR_KEY,SI_KEY,PURCHASE_DT_KEY,EFF_DT_KEY,END_DT_KEY,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY,PRIMARY_IND)
                VALUES(vrx.VISITOR_KEY,vrx.SI_KEY,vrx.PURCHASE_DT_KEY,vrx.EFF_DT_KEY,vrx.END_DT_KEY,vrx.INSERT_AUDIT_KEY,vrx.UPDATE_AUDIT_KEY,vrx.PRIMARY_IND);

select primary_ind,COUNT(*) from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 group by  primary_ind;
-- +-----------+--------+
-- |PRIMARY_IND|COUNT(*)|
-- +-----------+--------+
-- |Y          |10203   |
-- +-----------+--------+
select primary_ind,COUNT(*) from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 where INSERT_AUDIT_KEY <> 1016865 group by  primary_ind;
-- +-----------+--------+
-- |PRIMARY_IND|COUNT(*)|
-- +-----------+--------+
-- |Y          |4870    |
-- +-----------+--------+
select primary_ind,COUNT(*) from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 where INSERT_AUDIT_KEY = 1016865 group by  primary_ind;
-- +-----------+--------+
-- |PRIMARY_IND|COUNT(*)|
-- +-----------+--------+
-- |Y          |5333    |
-- +-----------+--------+

Select * from (
select '1' A1,FDM.full_dt EFF_DT,FDM2.full_dt end_dt,FDM1.full_dt purchase_dt, VOXA12ON2024.* from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 VOXA12ON2024
         JOIN fas.date_dim FDM on FDM.date_key = VOXA12ON2024.EFF_DT_KEY
         JOIN fas.date_dim FDM1 on FDM1.date_key = VOXA12ON2024.purchase_dt_key
         JOIN fas.date_dim FDM2 on FDM2.date_key = VOXA12ON2024.END_DT_KEY
         where VOXA12ON2024.INSERT_AUDIT_KEY = 1016865
UNION
select '2' A1,FDM.full_dt EFF_DT,FDM2.full_dt end_dt,FDM1.full_dt purchase_dt, VOXA12ON2024.* from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 VOXA12ON2024
         JOIN fas.date_dim FDM on FDM.date_key = VOXA12ON2024.EFF_DT_KEY
         JOIN fas.date_dim FDM1 on FDM1.date_key = VOXA12ON2024.purchase_dt_key
         JOIN fas.date_dim FDM2 on FDM2.date_key = VOXA12ON2024.END_DT_KEY
         where VOXA12ON2024.INSERT_AUDIT_KEY <> 1016865
)T1
ORDER BY T1.SI_KEY desc,A1 ;

MERGE INTO VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 vox
		 USING(SELECT visitor_key,si_key,
			CASE WHEN rank=1 THEN '99999' ELSE ( select TO_CHAR(MAX(date_key)) from fas.date_dim where full_dt=trunc(sysdate))END AS end_dt_key,
			CASE WHEN rank=1 THEN 'Y' ELSE 'N' END AS primary_ind FROM(
			SELECT visitor_key,si_key,
			DENSE_RANK() OVER (PARTITION BY si_key ORDER BY purchase_dt_key desc,eff_dt_key desc,visitor_key desc) as rank
			FROM VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024)
		      )vrx
		 ON(vox.visitor_key=vrx.visitor_key and vox.si_key=vrx.si_key)
		WHEN MATCHED THEN UPDATE SET
		vox.primary_ind=vrx.primary_ind,
		vox.end_dt_key=vrx.end_dt_key;

select * from GNRC.VISITOR_OWNERSHIP_XREF where SI_KEY = 1984133 order by EFF_DT_KEY,END_DT_KEY;

select AT1.CREATION_DT,AT1.AUDIT_KEY,COUNT(*)
from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 VOXA
        --JOIN GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = VOXA.VISITOR_KEY
        JOIN AUDIT_TBL AT1 on At1.AUDIT_KEY = VOXA.INSERT_AUDIT_KEY
GROUP BY AT1.CREATION_DT,AT1.AUDIT_KEY
ORDER BY AT1.CREATION_DT DESC

;

select primary_ind,COUNT(*) from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 where INSERT_AUDIT_KEY <> 1016865 group by  primary_ind;
-- +-----------+--------+
-- |PRIMARY_IND|COUNT(*)|
-- +-----------+--------+
-- |Y          |4870    |
-- +-----------+--------+
select primary_ind,COUNT(*) from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 where INSERT_AUDIT_KEY = 1016865 group by  primary_ind;
-- +-----------+--------+
-- |PRIMARY_IND|COUNT(*)|
-- +-----------+--------+
-- |N          |4870    |
-- |Y          |463     |
-- +-----------+--------+
COMMIT;
select * from GNRC.VISITOR_OWNERSHIP_XREF where SI_KEY = 1719426;
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|VISITOR_KEY|SI_KEY |PURCHASE_DT_KEY|EFF_DT_KEY|END_DT_KEY|OWNERSHIP_CD_PCT|PRIMARY_IND|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|1618527    |1719426|12041          |12041     |12757     |NULL            |N          |876278          |1016874         |1016874       |
|2051448    |1719426|12041          |12041     |99999     |NULL            |Y          |1005937         |1016874         |1016874       |
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
select * from VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024 where SI_KEY = 1719426;
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|VISITOR_KEY|SI_KEY |PURCHASE_DT_KEY|EFF_DT_KEY|END_DT_KEY|OWNERSHIP_CD_PCT|PRIMARY_IND|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|1618527    |1719426|12041          |12041     |12757     |NULL            |N          |1016865         |NULL            |NULL          |
|2051448    |1719426|12041          |12041     |99999     |NULL            |Y          |1005937         |1016874         |NULL          |
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+

select COUNT(*) from COMMON_LOAD_HOLD_TBL;--217
select COUNT(*) from COMMON_LOAD_TBL;--217
select COUNT(*) from ADDRESS_OUTPUT_TBL;--5332
select COUNT(*) from SI_OUTPUT_TBL;--5332
select COUNT(*) from CUSTOMER_OUTPUT_TBL;--5333