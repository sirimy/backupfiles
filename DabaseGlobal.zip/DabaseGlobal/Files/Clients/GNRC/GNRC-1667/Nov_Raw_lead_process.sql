

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual Load for AS12 NCOA', p_process_nm => 'GNRC-1668', p_table_nm => 'RAW_LEADS_TBL');

BEGIN
        insert into RAW_LEADS_TBL
        select OWNER_NAME                ,
                OWNER_ADDRESS1           ,
                OWNER_CITY                 ,
                OWNER_STATE                ,
                OWNER_POSTCODE            ,
                OWNER_PHONE_NUMBER        ,
                OWNER_EMAIL                ,
                EQUIPMENT                  ,
                VALID_FROM_DATE            ,
                MATERIAL                   ,
                MATERIAL_NAME             ,
                PURCHASE_DATE              ,
                PRODUCT_HIER_LEVEL1        ,
                PRODUCT_HIER_LEVEL1_NAME   ,
                PRODUCT_HIER_LEVEL2        ,
                PRODUCT_HIER_LEVEL2_NAME   ,
                MASTER_WARRANTY_NUMBER     ,
                MASTER_WARRANTY_DESC       ,
                WARRANTY_START_DATE       ,
                MIN_WARRANTY_END_DT       ,
                MAX_WARRANTY_END_DT        ,
                NOTIFICATION_COUNT         ,
                'AS12_nov_customer_handling_2024-12-06-gnrc-1668.txt'                    ,
                v_audit_key           ,
                ERROR_DESC                ,
                PRODUCT_HIRE_LEVEL3        ,
                PRODUCT_HIRE_LEVEL_3_NAME  ,
                SALES_OFFICE             ,
                UNIQUE_SEQ_NO from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
                            where ERROR_DESC IS NULL
                            AND RL.INSERT_AUDIT_KEY = 1012287;

       COMMIT;

END;

select INSERT_AUDIT_KEY,COUNT(*) from RAW_LEADS_TBL_AS12_OCT_NOV_2024 group by INSERT_AUDIT_KEY;

--
-- UPDATE RAW_LEADS_TBL_AS12_OCT_NOV_2024
-- set ERROR_DESC = 'Sales'
--     where LTRIM(TRIM(EQUIPMENT),'0') in ( select LTRIM(TRIM(SERIAL_NO))  from  RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA);



COMMIT;
select * from RAW_LEADS_TBL where ERROR_DESC is not null ;--0
select FILE_NM,COUNT(*) from RAW_LEADS_TBL group by FILE_NM;--7627


select * from COMMON_LOAD_HOLD_TBL;
select COUNT(*) from COMMON_LOAD_HOLD_TBL;--7626
select COUNT(*) from COMMON_LOAD_TBL;--7626

 commit;


select COUNT(*) from ADDRESS_OUTPUT_TBL;--7626
select COUNT(*) from SI_OUTPUT_TBL;--7626
select COUNT(*) from CUSTOMER_OUTPUT_TBL;--7626

select COUNT(*) from VISITOR_OWNERSHIP_XREF  ;--0

select INSERT_AUDIT_KEY,PRIMARY_IND,COUNT(*) from VISITOR_OWNERSHIP_XREF  group by INSERT_AUDIT_KEY,PRIMARY_IND
order by INSERT_AUDIT_KEY desc
;--0
+----------------+-----------+--------+
|INSERT_AUDIT_KEY|PRIMARY_IND|COUNT(*)|
+----------------+-----------+--------+
|1020182         |Y          |7546    |
+----------------+-----------+--------+
select * from AUDIT_TBL where AUDIT_KEY = 1020182;

insert into VISITOR_OWNERSHIP_XREF_AS12_OCT_NOV_2024
select * from VISITOR_OWNERSHIP_XREF  where INSERT_AUDIT_KEY = 1020182;--7626


select COUNT(*) from VISITOR_DIM;--7693
select COUNT(*) from VISITOR_LKP;--0
select COUNT(*) from ADDRESS_DIM;--7622
select COUNT(*) from CUSTOMER_DIM;--7528
select COUNT(*) from CUSTOMER_LKP;--39
select COUNT(*) from ADDRESS_DIM;--7622
select COUNT(*) from ADDRESS_LKP;--148

select COUNT(*) from CUSTOMER_DIM where CUSTOMER_KEY in (select CUSTOMER_KEY from GNRC.CUSTOMER_EXT_DIM);--49


select * from ADDRESS_DIM order by DBMS_RANDOM.RANDOM();--5327
select COUNT(*) from CUSTOMER_DIM where PRIMARY_ADDRESS_KEY in (select ADDRESS_KEY from ADDRESS_DIM);--632
select COUNT(*) from VISITOR_OWNERSHIP_XREF  where PRIMARY_IND ='Y' AND SI_KEY in (select SI_KEY from SERIALIZED_ITEM_DIM);--7626

select COUNT(*) from SERIALIZED_ITEM_DIM;--7626
select COUNT(*) from SERIALIZED_ITEM_LKP;--0
select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--7626

select * from ADDRESS_EXT_DIM;


select
       RL.EQUIPMENT,SI.SERIAL_NO,SI.SI_KEY,
       RL.OWNER_NAME,
       RL.OWNER_ADDRESS1,RL.OWNER_CITY
       ,VD.VISITOR_KEY,VD.CUSTOMER_KEY,AD.FIRST_NM,AD.LAST_NM,
       AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY,CEX.NCOA_FLAG,AD1.SOURCE_CD,AD1.ADDRESS_LINE1_TX
   -- COUNT(*)
from
         RAW_LEADS_TBL RL
          LEFT join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT  join VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y')
          LEFT join VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          LEFT join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
 where ERROR_DESC IS NULL
  AND UPPER(OWNER_ADDRESS1) = AD.ADDRESS_LINE1_TX
ORDER BY DBMS_RANDOM.RANDOM()
;--6799





select
--        RL.EQUIPMENT,SI.SERIAL_NO,SI.SI_KEY,
--        RL.OWNER_NAME,
--        RL.OWNER_ADDRESS1,RL.OWNER_CITY
--        ,VD.VISITOR_KEY,VD.CUSTOMER_KEY,AD.FIRST_NM,AD.LAST_NM,
--        AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY,CEX.NCOA_FLAG
    COUNT(*)
from
         RAW_LEADS_TBL RL
          LEFT join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT  join VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y')
          LEFT join VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join PHONE_DIM AD on AD.PHONE_KEY = CD.PRIMARY_PHONE_KEY
          JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
 where ERROR_DESC IS NULL
  AND translate (TRIM(RL.OWNER_PHONE_NUMBER),'0'||translate (TRIM(RL.OWNER_PHONE_NUMBER),'x0123456789','x'),'0') = PHONE_NO
ORDER BY DBMS_RANDOM.RANDOM()
;--7375




select
--        RL.EQUIPMENT,SI.SERIAL_NO,SI.SI_KEY,
--        RL.OWNER_NAME,
--        RL.OWNER_ADDRESS1,RL.OWNER_CITY
--        ,VD.VISITOR_KEY,VD.CUSTOMER_KEY,AD.FIRST_NM,AD.LAST_NM,
--        AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY,CEX.NCOA_FLAG
    COUNT(*)
from
         RAW_LEADS_TBL RL
          LEFT join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT  join VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y')
          LEFT join VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join EMAIL_DIM AD on AD.EMAIL_KEY = CD.PRIMARY_EMAIL_KEY
          JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
 where ERROR_DESC IS NULL
  AND UPPER(TRIM(RL.OWNER_EMAIL)) = EMAIL_ADDRESS_TX
ORDER BY DBMS_RANDOM.RANDOM()
;--6048



select COUNT(*) from SERIALIZED_ITEM_DIM where SI_KEY in (select VISITOR_OWNERSHIP_XREF.SI_KEY from VISITOR_OWNERSHIP_XREF);--7626
select COUNT(*) from VISITOR_OWNERSHIP_XREF where VISITOR_KEY in (select VISITOR_DIM.VISITOR_KEY from VISITOR_DIM);--7726
select COUNT(*) from VISITOR_OWNERSHIP_XREF where VISITOR_KEY in (select VISITOR_DIM.VISITOR_KEY from VISITOR_DIM) and PRIMARY_IND = 'Y';--7584
select COUNT(*) from CUSTOMER_DIM where CUSTOMER_KEY in (select VISITOR_DIM.CUSTOMER_KEY from VISITOR_DIM);--7528
select COUNT(*) from ADDRESS_DIM  ;--7622
select COUNT(*) from CUSTOMER_DIM  ;--7528
select COUNT(*) from CUSTOMER_DIM where PRIMARY_ADDRESS_KEY in (select ADDRESS_KEY from ADDRESS_DIM);--7456

select * from visitor_purl_xref;--65

select COUNT(*) from GNRC.visitor_history_tbl;--2277860
select COUNT(*) from GNRC.visitor_address_xref;--2134407
select COUNT(*) from GNRC.VISITOR_EMAIL_XREF;--1471683
select COUNT(*) from GNRC.VISITOR_PHONE_XREF;--2303850
select COUNT(*) from GNRC.visitor_purl_xref;--2179033

-- delete from GNRC.visitor_history_tbl where VISITOR_KEY in (
--     select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
--     );--4877
--[2024-12-05 13:18:40] 4,877 rows affected in 414 ms


-- delete from GNRC.visitor_address_xref where VISITOR_KEY in (
--     select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
--     );--4875
--[2024-12-05 13:19:27] 4,875 rows affected in 915 ms


-- delete from GNRC.VISITOR_EMAIL_XREF where VISITOR_KEY in (
--     select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
--     );--9
--[2024-12-05 13:20:46] 9 rows affected in 511 ms


-- delete  from GNRC.VISITOR_PHONE_XREF where VISITOR_KEY in (
--     select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
--     );--9

---visitor_history_tbl
--V_VISITOR_EMAIL
