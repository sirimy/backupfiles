select VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE,COUNT(*)
        ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX THEN 1 END) SAME
        ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) <> ADDRESS_LINE1_TX THEN 1 END) DIFF
        ,COUNT(CEX.CUSTOMER_KEY)
from
         RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
         join GNRC.SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          LEFT JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
where ERROR_DESC IS NULL
AND RL.INSERT_AUDIT_KEY = 1003916 -- oct =4482 <>849
GROUP BY VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE
;
-- +----------------------------+--------------------+--------+----+----+-----------------------+
-- |PARENT_MARKETING_CATEGORY_NM|LATEST_COVERAGE_TYPE|COUNT(*)|SAME|DIFF|COUNT(CEX.CUSTOMER_KEY)|
-- +----------------------------+--------------------+--------+----+----+-----------------------+
-- |PRESSURE WASHER             |1                   |1       |0   |1   |1                      |
-- |PORTABLE GAS GENERATOR      |1                   |60      |3   |57  |2                      |
-- |HOME STANDBY GENERATOR      |1                   |4971    |4447|522 |11                     |
-- |HOME STANDBY GENERATOR      |5                   |111     |5   |106 |0                      |
-- |HOME STANDBY GENERATOR      |18                  |22      |8   |14  |1                      |
-- |HOME STANDBY GENERATOR      |2                   |161     |15  |146 |1                      |
-- |HOME STANDBY GENERATOR      |7                   |2       |1   |1   |0                      |
-- |HOME STANDBY GENERATOR      |6                   |1       |0   |1   |0                      |
-- |HOME STANDBY GENERATOR      |21                  |4       |3   |1   |1                      |
-- +----------------------------+--------------------+--------+----+----+-----------------------+


select COUNT(*) from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
                where ERROR_DESC IS not NULL
                AND RL.INSERT_AUDIT_KEY = 1003916;--15

select COUNT(*) from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
                where ERROR_DESC IS NULL
                AND RL.INSERT_AUDIT_KEY = 1003916;--5333

select * from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
                where ERROR_DESC IS NULL
                AND RL.INSERT_AUDIT_KEY = 1003916;

select * from RAW_LEADS_TBL
UNION
select OWNER_NAME                ,
    OWNER_ADDRESS1           ,
    OWNER_CITY                 ,
    OWNER_STATE                ,
    OWNER_POSTCODE            ,
    OWNER_PHONE_NUMBER        ,
    OWNER_EMAIL                ,
    EQUIPMENT                  ,
    VALID_FROM_DATE            ,
    MATERIAL                   ,
    MATERIAL_NAME             ,
    PURCHASE_DATE              ,
    PRODUCT_HIER_LEVEL1        ,
    PRODUCT_HIER_LEVEL1_NAME   ,
    PRODUCT_HIER_LEVEL2        ,
    PRODUCT_HIER_LEVEL2_NAME   ,
    MASTER_WARRANTY_NUMBER     ,
    MASTER_WARRANTY_DESC       ,
    WARRANTY_START_DATE       ,
    MIN_WARRANTY_END_DT       ,
    MAX_WARRANTY_END_DT        ,
    NOTIFICATION_COUNT         ,
    FILE_NM                    ,
    INSERT_AUDIT_KEY           ,
    ERROR_DESC                ,
    PRODUCT_HIRE_LEVEL3        ,
    PRODUCT_HIRE_LEVEL_3_NAME  ,
    SALES_OFFICE             ,
    UNIQUE_SEQ_NO from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
                where ERROR_DESC IS NULL
                AND RL.INSERT_AUDIT_KEY = 1003916;

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual Load for AS12 NCOA', p_process_nm => 'GNRC-1668', p_table_nm => 'RAW_LEADS_TBL');

BEGIN
        insert into RAW_LEADS_TBL
        select OWNER_NAME                ,
                OWNER_ADDRESS1           ,
                OWNER_CITY                 ,
                OWNER_STATE                ,
                OWNER_POSTCODE            ,
                OWNER_PHONE_NUMBER        ,
                OWNER_EMAIL                ,
                EQUIPMENT                  ,
                VALID_FROM_DATE            ,
                MATERIAL                   ,
                MATERIAL_NAME             ,
                PURCHASE_DATE              ,
                PRODUCT_HIER_LEVEL1        ,
                PRODUCT_HIER_LEVEL1_NAME   ,
                PRODUCT_HIER_LEVEL2        ,
                PRODUCT_HIER_LEVEL2_NAME   ,
                MASTER_WARRANTY_NUMBER     ,
                MASTER_WARRANTY_DESC       ,
                WARRANTY_START_DATE       ,
                MIN_WARRANTY_END_DT       ,
                MAX_WARRANTY_END_DT        ,
                NOTIFICATION_COUNT         ,
                'AS12_customer_handling_gnrc-1668.txt'                    ,
                v_audit_key           ,
                ERROR_DESC                ,
                PRODUCT_HIRE_LEVEL3        ,
                PRODUCT_HIRE_LEVEL_3_NAME  ,
                SALES_OFFICE             ,
                UNIQUE_SEQ_NO from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
                            where ERROR_DESC IS NULL
                            AND RL.INSERT_AUDIT_KEY = 1003916;

       COMMIT;

END;


UPDATE RAW_LEADS_TBL_AS12_OCT_NOV_2024
set ERROR_DESC = 'Sales'
    where LTRIM(TRIM(EQUIPMENT),'0') in ( select LTRIM(TRIM(SERIAL_NO))  from  RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA);

select COUNT(*) from RAW_LEADS_TBL;--5331
COMMIT;
select * from RAW_LEADS_TBL where ERROR_DESC is not null ;--0

select * from COMMON_LOAD_HOLD_TBL;
select COUNT(*) from COMMON_LOAD_HOLD_TBL;--5331
select COUNT(*) from COMMON_LOAD_TBL;--5331

select FILE_NM,COUNT(*) from COMMON_LOAD_HOLD_TBL group by FILE_NM;--5331
-- +----------------------------------------+--------+
-- |FILE_NM                                 |COUNT(*)|
-- +----------------------------------------+--------+
-- |gnrc_after_leads_2024-12-04-14-56-03.txt|6546    |
-- |AS12_customer_handling_gnrc-1668.txt    |10662   |
-- +----------------------------------------+--------+
select FILE_NM,COUNT(*) from COMMON_LOAD_TBL group by FILE_NM;--5331
-- +----------------------------------------+--------+
-- |FILE_NM                                 |COUNT(*)|
-- +----------------------------------------+--------+
-- |gnrc_after_leads_2024-12-04-14-56-03.txt|6546    |
-- |AS12_customer_handling_gnrc-1668.txt    |10662   |
-- +----------------------------------------+--------+


select COUNT(*) from ADDRESS_OUTPUT_TBL;--5331
select COUNT(*) from SI_OUTPUT_TBL;--5331
select COUNT(*) from CUSTOMER_OUTPUT_TBL;--5331

select COUNT(*) from VISITOR_OWNERSHIP_XREF  ;--5409

select INSERT_AUDIT_KEY,PRIMARY_IND,COUNT(*) from VISITOR_OWNERSHIP_XREF  group by INSERT_AUDIT_KEY,PRIMARY_IND;--0
+----------------+-----------+--------+
|INSERT_AUDIT_KEY|PRIMARY_IND|COUNT(*)|
+----------------+-----------+--------+
|1020105         |Y          |5286    |
+----------------+-----------+--------+



select COUNT(*),COUNT(distinct VISITOR_KEY),COUNT(distinct SI_KEY) from VISITOR_OWNERSHIP_XREF;--10308
+--------+--------------------------+---------------------+
|COUNT(*)|COUNT(DISTINCTVISITOR_KEY)|COUNT(DISTINCTSI_KEY)|
+--------+--------------------------+---------------------+
|5409    |5361                      |5331                 |
+--------+--------------------------+---------------------+


select COUNT(*) from VISITOR_DIM;--5284
select COUNT(*) from VISITOR_LKP;--0select COUNT(*) from ADDRESS_DIM;--5327
select COUNT(*) from CUSTOMER_DIM;--5259
select COUNT(*) from CUSTOMER_LKP;--67
select COUNT(*) from ADDRESS_DIM;--5327
select COUNT(*) from ADDRESS_LKP;--0

select COUNT(*) from CUSTOMER_DIM where CUSTOMER_KEY in (select CUSTOMER_KEY from GNRC.CUSTOMER_EXT_DIM);--4855


select * from ADDRESS_DIM order by DBMS_RANDOM.RANDOM();--5327
select COUNT(*) from CUSTOMER_DIM where PRIMARY_ADDRESS_KEY in (select ADDRESS_KEY from ADDRESS_DIM);--5197
select COUNT(*) from VISITOR_OWNERSHIP_XREF  where PRIMARY_IND ='Y' AND SI_KEY in (select SI_KEY from SERIALIZED_ITEM_DIM);--5331

select COUNT(*) from SERIALIZED_ITEM_DIM;--5331
select COUNT(*) from SERIALIZED_ITEM_LKP;--0
select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--5331

select * from ADDRESS_EXT_DIM;


select
--        RL.EQUIPMENT,SI.SERIAL_NO,SI.SI_KEY,
--        RL.OWNER_NAME,
--        RL.OWNER_ADDRESS1,RL.OWNER_CITY
--        ,VD.VISITOR_KEY,VD.CUSTOMER_KEY,AD.FIRST_NM,AD.LAST_NM,
--        AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY,CEX.NCOA_FLAG
    COUNT(*)
from
         RAW_LEADS_TBL RL
          LEFT join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT  join VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y')
          LEFT join VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
 where ERROR_DESC IS NULL
  AND UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX
ORDER BY DBMS_RANDOM.RANDOM()
;--4671



select
--        RL.EQUIPMENT,SI.SERIAL_NO,SI.SI_KEY,
--        RL.OWNER_NAME,
--        RL.OWNER_ADDRESS1,RL.OWNER_CITY
--        ,VD.VISITOR_KEY,VD.CUSTOMER_KEY,AD.FIRST_NM,AD.LAST_NM,
--        AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY,CEX.NCOA_FLAG
    COUNT(*)
from
         RAW_LEADS_TBL RL
          LEFT join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT  join VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y')
          LEFT join VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join PHONE_DIM AD on AD.PHONE_KEY = CD.PRIMARY_PHONE_KEY
          JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
 where ERROR_DESC IS NULL
  AND translate (TRIM(RL.OWNER_PHONE_NUMBER),'0'||translate (TRIM(RL.OWNER_PHONE_NUMBER),'x0123456789','x'),'0') = PHONE_NO
ORDER BY DBMS_RANDOM.RANDOM()
;--5077




select
--        RL.EQUIPMENT,SI.SERIAL_NO,SI.SI_KEY,
--        RL.OWNER_NAME,
--        RL.OWNER_ADDRESS1,RL.OWNER_CITY
--        ,VD.VISITOR_KEY,VD.CUSTOMER_KEY,AD.FIRST_NM,AD.LAST_NM,
--        AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY,CEX.NCOA_FLAG
    COUNT(*)
from
         RAW_LEADS_TBL RL
          LEFT join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT  join VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y')
          LEFT join VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join EMAIL_DIM AD on AD.EMAIL_KEY = CD.PRIMARY_EMAIL_KEY
          JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
 where ERROR_DESC IS NULL
  AND UPPER(TRIM(RL.OWNER_EMAIL)) = EMAIL_ADDRESS_TX
ORDER BY DBMS_RANDOM.RANDOM()
;--4259

+----------+----------+-------+----------------+------------------------+-------------+-----------+------------+--------+--------+------------------------+-------------+----------------+---------+
|EQUIPMENT |SERIAL_NO |SI_KEY |OWNER_NAME      |OWNER_ADDRESS1          |OWNER_CITY   |VISITOR_KEY|CUSTOMER_KEY|FIRST_NM|LAST_NM |ADDRESS_LINE1_TX        |CITY_NM      |INSERT_AUDIT_KEY|NCOA_FLAG|
+----------+----------+-------+----------------+------------------------+-------------+-----------+------------+--------+--------+------------------------+-------------+----------------+---------+
|3012968958|3012968958|1508710|RICHARD THOMPSON|11400 S PENNSYLVANIA AVE|OKLAHOMA CITY|1560852    |3060196     |RICHARD |THOMPSON|11400 S PENNSYLVANIA AVE|OKLAHOMA CITY|1017053         |Y        |
+----------+----------+-------+----------------+------------------------+-------------+-----------+------------+--------+--------+------------------------+-------------+----------------+---------+


--case check for different addrress
select * from GNRC.VISITOR_OWNERSHIP_XREF where SI_KEY = 1462894;
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|VISITOR_KEY|SI_KEY |PURCHASE_DT_KEY|EFF_DT_KEY|END_DT_KEY|OWNERSHIP_CD_PCT|PRIMARY_IND|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|1516442    |1462894|12141          |12141     |12757     |NULL            |N          |850435          |1016874         |1016874       |
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
select * from VISITOR_OWNERSHIP_XREF where SI_KEY = 1462894;
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|VISITOR_KEY|SI_KEY |PURCHASE_DT_KEY|EFF_DT_KEY|END_DT_KEY|OWNERSHIP_CD_PCT|PRIMARY_IND|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|1516442    |1462894|12141          |12141     |99999     |NULL            |Y          |1017054         |NULL            |NULL          |
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
+------------------+----------+-------+---------------+------------------+----------+-----------+------------+--------+----------+-------------------+-------+----------------+---------+
|EQUIPMENT         |SERIAL_NO |SI_KEY |OWNER_NAME     |OWNER_ADDRESS1    |OWNER_CITY|VISITOR_KEY|CUSTOMER_KEY|FIRST_NM|LAST_NM   |ADDRESS_LINE1_TX   |CITY_NM|INSERT_AUDIT_KEY|NCOA_FLAG|
+------------------+----------+-------+---------------+------------------+----------+-----------+------------+--------+----------+-------------------+-------+----------------+---------+
|000000003009170085|3009170085|1462894|Jack Wilkenfeld|1457 River Club Dr|Vero Beach|1516442    |2974946     |JACK    |WILKENFELD|10004 FOX SPRING CT|OAKTON |1017053         |Y        |
+------------------+----------+-------+---------------+------------------+----------+-----------+------------+--------+----------+-------------------+-------+----------------+---------+
select * from GNRC.VISITOR_DIM where VISITOR_KEY = 1516442;
+-----------+------------+-------------+---------------+-------------+----------------+----------------+--------------+
|VISITOR_KEY|CUSTOMER_KEY|HOUSEHOLD_KEY|VISITOR_TYPE_CD|DIM_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+------------+-------------+---------------+-------------+----------------+----------------+--------------+
|1516442    |2974946     |1469870      |NULL           |N            |850435          |1016870         |1016870       |
+-----------+------------+-------------+---------------+-------------+----------------+----------------+--------------+
select * from GNRC.CUSTOMER_DIM where CUSTOMER_KEY = 2974946;
select * from GNRC.ADDRESS_DIM where ADDRESS_KEY = 8519406;
select * from VISITOR_OWNERSHIP_XREF_20241205 where SI_KEY = 1462894;
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|VISITOR_KEY|SI_KEY |PURCHASE_DT_KEY|EFF_DT_KEY|END_DT_KEY|OWNERSHIP_CD_PCT|PRIMARY_IND|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|1516442    |1462894|12141          |12141     |12757     |NULL            |N          |850435          |1016874         |1016874       |
|2054707    |1462894|12141          |12141     |99999     |NULL            |Y          |1005937         |1016874         |1016874       |
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
select * from GNRC.VISITOR_DIM where VISITOR_KEY = 2054707;
+-----------+------------+-------------+---------------+-------------+----------------+----------------+--------------+
|VISITOR_KEY|CUSTOMER_KEY|HOUSEHOLD_KEY|VISITOR_TYPE_CD|DIM_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+------------+-------------+---------------+-------------+----------------+----------------+--------------+
|1516442    |2974946     |1469870      |NULL           |N            |850435          |1016870         |1016870       |
+-----------+------------+-------------+---------------+-------------+----------------+----------------+--------------+
select * from GNRC.CUSTOMER_DIM where CUSTOMER_KEY = 4053698;
select * from GNRC.ADDRESS_DIM where ADDRESS_KEY = 8601866;
+-----------+-------+---------+--------+---------+-------+------------------+----------------+----------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX  |ADDRESS_LINE2_TX|CITY_NM   |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
+-----------+-------+---------+--------+---------+-------+------------------+----------------+----------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
|8601866    |NULL   |NULL     |NULL    |NULL     |NULL   |1457 RIVER CLUB DR|NULL            |VERO BEACH|FL      |32963       |3914        |N             |S00000      |NULL    |A            |NULL                 |NULL       |12141     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |RIVER CLUB       |1457             |NULL   |NULL     |NULL       |NULL     |Y            |1005937         |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |1005940       |
+-----------+-------+---------+--------+---------+-------+------------------+----------------+----------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
select * from GNRC.ADDRESS_DIM where ADDRESS_LINE1_TX = '1457 RIVER CLUB DR';
+-----------+-------+---------+--------+---------+----------+------------------+----------------+----------+--------+------------+------------+
|ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM   |ADDRESS_LINE1_TX  |ADDRESS_LINE2_TX|CITY_NM   |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
+-----------+-------+---------+--------+---------+----------+------------------+----------------+----------+--------+------------+------------+
|6302524    |NULL   |NULL     |JACK    |NULL     |WILKENFELD|1457 RIVER CLUB DR|NULL            |VERO BEACH|FL      |32963       |3914        |
|8601866    |NULL   |NULL     |NULL    |NULL     |NULL      |1457 RIVER CLUB DR|NULL            |VERO BEACH|FL      |32963       |3914        |
+-----------+-------+---------+--------+---------+----------+------------------+----------------+----------+--------+------------+------------+
select * from GNRC.CUSTOMER_DIM where PRIMARY_ADDRESS_KEY = 6302524;
select * from ADDRESS_DIM where ADDRESS_LINE1_TX = '1457 RIVER CLUB DR';
+-----------+-------+---------+--------+---------+----------+------------------+----------------+----------+--------+------------+------------+
|ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM   |ADDRESS_LINE1_TX  |ADDRESS_LINE2_TX|CITY_NM   |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
+-----------+-------+---------+--------+---------+----------+------------------+----------------+----------+--------+------------+------------+
|6302524    |NULL   |NULL     |JACK    |NULL     |WILKENFELD|1457 RIVER CLUB DR|NULL            |VERO BEACH|FL      |32963       |3914        |
+-----------+-------+---------+--------+---------+----------+------------------+----------------+----------+--------+------------+------------+
select * from CUSTOMER_DIM where PRIMARY_ADDRESS_KEY = 6302524;
select * from CUSTOMER_DIM where PRIMARY_ADDRESS_KEY = 8601866;
select * from ADDRESS_DIM where ADDRESS_LINE1_TX = '10004 FOX SPRING CT';




select COUNT(*) from SERIALIZED_ITEM_DIM where SI_KEY in (select VISITOR_OWNERSHIP_XREF.SI_KEY from VISITOR_OWNERSHIP_XREF);--5331
select COUNT(*) from VISITOR_OWNERSHIP_XREF where VISITOR_KEY in (select VISITOR_DIM.VISITOR_KEY from VISITOR_DIM);--5332
select COUNT(*) from VISITOR_OWNERSHIP_XREF where VISITOR_KEY in (select VISITOR_DIM.VISITOR_KEY from VISITOR_DIM) and PRIMARY_IND = 'Y';--5287
select COUNT(*) from CUSTOMER_DIM where CUSTOMER_KEY in (select VISITOR_DIM.CUSTOMER_KEY from VISITOR_DIM);--5239
select COUNT(*) from ADDRESS_DIM  ;--5327
select COUNT(*) from CUSTOMER_DIM  ;--5259
select COUNT(*) from CUSTOMER_DIM where PRIMARY_ADDRESS_KEY in (select ADDRESS_KEY from ADDRESS_DIM);--5197


select COUNT(*) from GNRC.visitor_history_tbl;--2277860
select COUNT(*) from GNRC.visitor_address_xref;--2134407
select COUNT(*) from GNRC.VISITOR_EMAIL_XREF;--1471683
select COUNT(*) from GNRC.VISITOR_PHONE_XREF;--2303850
select COUNT(*) from GNRC.visitor_purl_xref;--2179033

-- delete from GNRC.visitor_history_tbl where VISITOR_KEY in (
--     select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
--     );--4877
--[2024-12-05 13:18:40] 4,877 rows affected in 414 ms


-- delete from GNRC.visitor_address_xref where VISITOR_KEY in (
--     select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
--     );--4875
--[2024-12-05 13:19:27] 4,875 rows affected in 915 ms


-- delete from GNRC.VISITOR_EMAIL_XREF where VISITOR_KEY in (
--     select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
--     );--9
--[2024-12-05 13:20:46] 9 rows affected in 511 ms


-- delete  from GNRC.VISITOR_PHONE_XREF where VISITOR_KEY in (
--     select VOX.VISITOR_KEY from VISITOR_OWNERSHIP_XREF_AS12_DELETED_20241205 VOX
--     );--9

---visitor_history_tbl
--V_VISITOR_EMAIL


select COUNT(*),COUNT( PRIMARY_PHONE_KEY),COUNT(PRIMARY_EMAIL_KEY) from CUSTOMER_DIM  ;--5239

select COUNT(*) from ADDRESS_DIM where ADDRESS_KEY in (select CUSTOMER_DIM.PRIMARY_ADDRESS_KEY from CUSTOMER_DIM);--158

select AD.* from ADDRESS_DIM  AD
                    JOIN CUSTOMER_DIM CD ON CD.PRIMARY_ADDRESS_KEY = AD.ADDRESS_KEY order by DBMS_RANDOM.RANDOM();

select AD.* from GNRC.ADDRESS_DIM  AD
                    JOIN CUSTOMER_DIM CD ON CD.PRIMARY_ADDRESS_KEY = AD.ADDRESS_KEY
            order by DBMS_RANDOM.RANDOM();


select RL.EQUIPMENT,
       RL.OWNER_NAME,
       RL.OWNER_ADDRESS1,RL.OWNER_CITY
       ,AD.FIRST_NM,AD.LAST_NM,
       AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY
from
         RAW_LEADS_TBL RL
         join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT join VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          LEFT JOIN V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
where ERROR_DESC IS NULL
AND UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX
ORDER BY DBMS_RANDOM.RANDOM()--146
;

select
--     RL.EQUIPMENT,
--        RL.OWNER_NAME,
--        RL.OWNER_ADDRESS1,RL.OWNER_CITY
--        ,AD.FIRST_NM,AD.LAST_NM,
--        AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY
    COUNT(*)

from
         RAW_LEADS_TBL RL
         join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          LEFT JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
where ERROR_DESC IS NULL
--AND RL.INSERT_AUDIT_KEY = 1003916 -- oct =4482 <>849
AND UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX
ORDER BY DBMS_RANDOM.RANDOM()
;

select * from GNRC.VISITOR_OWNERSHIP_XREF where SI_KEY = 1719426;
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|VISITOR_KEY|SI_KEY |PURCHASE_DT_KEY|EFF_DT_KEY|END_DT_KEY|OWNERSHIP_CD_PCT|PRIMARY_IND|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
|1618527    |1719426|12041          |12041     |12757     |NULL            |N          |876278          |1016874         |1016874       |
|2051448    |1719426|12041          |12041     |99999     |NULL            |Y          |1005937         |1016874         |1016874       |
+-----------+-------+---------------+----------+----------+----------------+-----------+----------------+----------------+--------------+
select * from AUDIT_TBL where AUDIT_KEY in (1005937,876278,1016874) order by CREATION_DT;

select * from GNRC.SERIALIZED_ITEM_DIM SI
          LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
where si.SI_KEY = 1719426;

select RL.EQUIPMENT,
       RL.OWNER_NAME,
       RL.OWNER_ADDRESS1,RL.OWNER_CITY,SI.SI_KEY
       ,AD.FIRST_NM,AD.LAST_NM,
       AD.ADDRESS_LINE1_TX,AD.CITY_NM,CD.PRIMARY_ADDRESS_KEY,AT1.CREATION_DT,cd.UPDATE_AUDIT_KEY,AT2.CREATION_DT
--     VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE,COUNT(*)
--         ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX THEN 1 END) SAME
--         ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) <> ADDRESS_LINE1_TX THEN 1 END) DIFF
--         ,COUNT(CEX.CUSTOMER_KEY)
from
         RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
         join GNRC.SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          LEFT JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
          JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = AD.INSERT_AUDIT_KEY
          JOIN AUDIT_TBL at2 on at2.AUDIT_KEY = cd.INSERT_AUDIT_KEY
where ERROR_DESC IS NULL
AND RL.INSERT_AUDIT_KEY = 1003916 -- oct =4482 <>849
--AND RL.INSERT_AUDIT_KEY = 1012287 -- Nov =204 <>7073
AND UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX
--GROUP BY VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE
ORDER BY DBMS_RANDOM.RANDOM()
;