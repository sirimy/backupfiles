select AT1.CREATION_DT,AT1.AUDIT_KEY,COUNT(*) FROM gnrc.NCOA_FCT onc
         JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = onc.INSERT_AUDIT_KEY
group by AT1.CREATION_DT,AT1.AUDIT_KEY
Order by AT1.CREATION_DT desc
;
+--------------------------+---------+--------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|
+--------------------------+---------+--------+
|2024-11-07 06:02:26.000000|1012287  |9631    |
|2024-10-09 04:17:23.000000|1003916  |7411    |
|2024-09-11 10:27:47.000000|996362   |38      |
|2024-09-06 06:47:04.000000|995705   |1356    |
|2024-08-06 16:57:23.000000|986569   |1071    |
|2024-07-03 20:18:22.000000|978189   |833     |
|2024-06-04 20:23:29.000000|970324   |949     |
+--------------------------+---------+--------+
select AT1.CREATION_DT,AT1.AUDIT_KEY,COUNT(*) FROM gnrc.NCOA_FCT onc
         JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = onc.INSERT_AUDIT_KEY
         where onc.INSERT_AUDIT_KEY in (1012287,1003916)
         and onc.ADDRESS_KEY in (select "StagingID"   from gnrc.RAW_MELISSA_DATA_TBL where "MD_Results" like '%AS12%')
group by AT1.CREATION_DT,AT1.AUDIT_KEY
Order by AT1.CREATION_DT desc
;
+--------------------------+---------+--------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|
+--------------------------+---------+--------+
|2024-11-07 06:02:26.000000|1012287  |7876    |
|2024-10-09 04:17:23.000000|1003916  |5477    |
+--------------------------+---------+--------+

select AT1.CREATION_DT,AT1.AUDIT_KEY,COUNT(*) FROM gnrc.NCOA_FCT onc
         JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = onc.INSERT_AUDIT_KEY
         where onc.INSERT_AUDIT_KEY in (1012287,1003916)
         and onc.ADDRESS_KEY in (select "StagingID"   from gnrc.RAW_MELISSA_DATA_TBL where "MD_Results" like '%AS12%')

group by AT1.CREATION_DT,AT1.AUDIT_KEY
Order by AT1.CREATION_DT desc
;
SELECT COUNT(ced.CUSTOMER_KEY) FROM GNRC.CUSTOMER_EXT_DIM ced
    where ced.CUSTOMER_KEY in (select customer_key from gnrcstg.TMP_CUSTOMERS_NCOA_OCT_NOV_2024);
--5037

+--------------------------+---------+--------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|
+--------------------------+---------+--------+
|2024-11-07 06:02:26.000000|1012287  |1755    |
|2024-10-09 04:17:23.000000|1003916  |1934    |
+--------------------------+---------+--------+

select COUNT(*) from TMP_CUSTOMERS_NCOA;--1353

select * from gnrc.raw_leads_tbl order by INSERT_AUDIT_KEY desc;--1305

select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from gnrc.raw_leads_tbl group by FILE_NM,INSERT_AUDIT_KEY order by INSERT_AUDIT_KEY desc;--
+---------------------------------------------------+----------------+--------+
|FILE_NM                                            |INSERT_AUDIT_KEY|COUNT(*)|
+---------------------------------------------------+----------------+--------+
|ncoa_customer_handling_12062024.txt                |1020336         |1305    |
|AS12_nov_customer_handling_2024-12-06-gnrc-1668.txt|1020181         |7627    |
|AS12_customer_handling_2024-12-06-gnrc-1668.txt    |1020137         |5331    |
+---------------------------------------------------+----------------+--------+

select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from gnrc.raw_leads_tbl
    where FILE_NM in ('ncoa_customer_handling_12062024.txt','AS12_nov_customer_handling_2024-12-06-gnrc-1668.txt','AS12_customer_handling_2024-12-06-gnrc-1668.txt')
group by FILE_NM,INSERT_AUDIT_KEY order by INSERT_AUDIT_KEY desc;--


select * from raw_leads_tbl;--1305

select COUNT(*) from CUSTOMER_EXT_DIM;--1353



select * from COMMON_LOAD_HOLD_TBL;
select COUNT(*) from COMMON_LOAD_HOLD_TBL;--1305
select COUNT(*) from COMMON_LOAD_TBL;--1305

select FILE_NM,COUNT(*) from COMMON_LOAD_HOLD_TBL group by FILE_NM;--5331
+-----------------------------------+--------+
|FILE_NM                            |COUNT(*)|
+-----------------------------------+--------+
|ncoa_customer_handling_12062024.txt|1305    |
+-----------------------------------+--------+


select FILE_NM,COUNT(*) from COMMON_LOAD_TBL group by FILE_NM;--5331
+-----------------------------------+--------+
|FILE_NM                            |COUNT(*)|
+-----------------------------------+--------+
|ncoa_customer_handling_12062024.txt|1305    |
+-----------------------------------+--------+


select COUNT(*) from ADDRESS_OUTPUT_TBL;--1305
select COUNT(*) from SI_OUTPUT_TBL;--1305
select COUNT(*) from CUSTOMER_OUTPUT_TBL;--0

select COUNT(*) from VISITOR_OWNERSHIP_XREF  ;--0

select INSERT_AUDIT_KEY,PRIMARY_IND,COUNT(*) from VISITOR_OWNERSHIP_XREF  group by INSERT_AUDIT_KEY,PRIMARY_IND;--0
+----------------+-----------+--------+
|INSERT_AUDIT_KEY|PRIMARY_IND|COUNT(*)|
+----------------+-----------+--------+
|1020105         |Y          |5286    |
+----------------+-----------+--------+


select COUNT(*) from VISITOR_DIM;--1304
select COUNT(*) from VISITOR_LKP;--0
select COUNT(*) from ADDRESS_DIM;--1304
select COUNT(*) from CUSTOMER_DIM;--1304
select COUNT(*) from CUSTOMER_LKP;--1301
select COUNT(*) from ADDRESS_DIM;--1304
select COUNT(*) from ADDRESS_LKP;--2596

select * from ADDRESS_LKP order by ADDRESS_KEY;--2596

select COUNT(*) from CUSTOMER_DIM where CUSTOMER_KEY in (select CUSTOMER_KEY from CUSTOMER_EXT_DIM);--0

select COUNT(*) from CUSTOMER_EXT_DIM;

select * from ADDRESS_DIM order by DBMS_RANDOM.RANDOM();--0

select COUNT(*) from CUSTOMER_DIM where PRIMARY_ADDRESS_KEY in (select ADDRESS_KEY from ADDRESS_DIM);--0
select COUNT(*) from VISITOR_OWNERSHIP_XREF  where PRIMARY_IND ='Y' AND SI_KEY in (select SI_KEY from SERIALIZED_ITEM_DIM);--0

select COUNT(*) from SERIALIZED_ITEM_DIM;--1305
select COUNT(*) from SERIALIZED_ITEM_LKP;--0
select COUNT(*) from SERIALIZED_ITEM_EXT_DIM;--0

select * from ADDRESS_EXT_DIM;



select
       RL.EQUIPMENT,SI.SERIAL_NO,SI.SI_KEY,
       RL.OWNER_NAME,
       RL.OWNER_ADDRESS1,RL.OWNER_CITY
       ,VD.VISITOR_KEY,VD.CUSTOMER_KEY,AD.FIRST_NM,AD.LAST_NM,
       AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY,CEX.NCOA_FLAG
    --COUNT(*)
from
         GNRC.RAW_LEADS_TBL RL
          LEFT join GNRC.SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT  join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y')
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
 where ERROR_DESC IS NULL AND FILE_NM = 'ncoa_customer_handling_12062024.txt'
  AND UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX
ORDER BY DBMS_RANDOM.RANDOM()
;--1305 total
--46
--1170


select
--        RL.EQUIPMENT,SI.SERIAL_NO,SI.SI_KEY,
--        RL.OWNER_NAME,
--        RL.OWNER_ADDRESS1,RL.OWNER_CITY
--        ,VD.VISITOR_KEY,VD.CUSTOMER_KEY,AD.FIRST_NM,AD.LAST_NM,
--        AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY,CEX.NCOA_FLAG
    COUNT(*)
from
         RAW_LEADS_TBL RL
          LEFT join SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT  join VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y')
          LEFT join VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
 where ERROR_DESC IS NULL
  AND UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX
ORDER BY DBMS_RANDOM.RANDOM()
;--1305 total
--46

select COUNT(*) from customer_ext_dim;--1305
