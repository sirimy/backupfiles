+--------------------------+---------+--------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|
+--------------------------+---------+--------+
|2024-11-07 06:02:26.000000|1012287  |9631    |
|2024-10-09 04:17:23.000000|1003916  |7411    |
+--------------------------+---------+--------+


select AT1.CREATION_DT,AT1.AUDIT_KEY,COUNT(*) FROM gnrc.NCOA_FCT onc
         JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = onc.INSERT_AUDIT_KEY
        where onc.INSERT_AUDIT_KEY in (1012287,1003916)
        and onc.ADDRESS_KEY in (select "StagingID"   from gnrc.RAW_MELISSA_DATA_TBL where "MD_Results" like '%AS12%')
group by AT1.CREATION_DT,AT1.AUDIT_KEY
Order by AT1.CREATION_DT desc
;
+--------------------------+---------+--------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|
+--------------------------+---------+--------+
|2024-11-07 06:02:26.000000|1012287  |7876    |
|2024-10-09 04:17:23.000000|1003916  |5477    |
+--------------------------+---------+--------+

COMMIT;
select * from TMP_CUSTOMERS_NCOA_OCT_NOV_2024;

INSERT INTO gnrcstg.TMP_CUSTOMERS_NCOA_OCT_NOV_2024 (customer_key,
                                           current_address_key,
                                           orig_address_key,
                                           serial_no,
                                           Insert_audit_key)
    SELECT T.CUSTOMER_KEY,
           T.PRIMARY_ADDRESS_KEY,
           NULL as orig_address_key, -- This will be populated after ACE
           T.serial_no,
           INSERT_AUDIT_KEY
        FROM (SELECT CD.CUSTOMER_KEY,
                     CD.PRIMARY_ADDRESS_KEY,
                     si.serial_no,NF.INSERT_AUDIT_KEY,
                     ROW_NUMBER ()
                     OVER (PARTITION BY CD.CUSTOMER_KEY ORDER BY VOX.EFF_DT_KEY DESC)
                        AS rno
                FROM GNRC.customer_dim cd
                     JOIN
                     (
                        SELECT DISTINCT
                                  onc.address_key, onc.new_address_key,onc.INSERT_AUDIT_KEY,
                                  FIRST_VALUE (onc.new_address_key)
                                    OVER (PARTITION BY (CONNECT_BY_ROOT onc.address_key)
                                            ORDER BY LEVEL DESC)
                                     AS new_key
                                  ,CONNECT_BY_ISCYCLE  as loop_ind
                             FROM gnrc.NCOA_FCT  onc
                        CONNECT BY NOCYCLE
                           PRIOR onc.new_address_key = onc.address_key
                        ) NF
                        ON (NF.NEW_ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY)
                     JOIN
                           GNRC.VISITOR_DIM vd
                        ON (VD.CUSTOMER_KEY = CD.CUSTOMER_KEY)
                     JOIN
                           GNRC.VISITOR_OWNERSHIP_XREF vox
                        ON (    VOX.VISITOR_KEY = VD.VISITOR_KEY
                           -- AND VOX.PRIMARY_IND = 'Y'
                            )
                     JOIN GNRC.SERIALIZED_ITEM_DIM SI
                        ON (SI.SI_KEY = VOX.SI_KEY)
                     JOIN GNRC.V_PRODUCT VP
                        ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
                  where NF.INSERT_AUDIT_KEY in (1012287, 1003916)
                        and NF.ADDRESS_KEY in ( select "StagingID"   from gnrc.RAW_MELISSA_DATA_TBL
                                                 where "MD_Results" like '%AS12%'
                                                   AND "StagingID" in (select "StagingID"   from gnrc.RAW_MELISSA_DATA_TBL where "LineItemID" = '991' )
                                         )
--                WHERE     vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'
--                      AND SI.LATEST_COVERAGE_TYPE = 1


                    ) T
       WHERE     1=1
         AND T.rno = 1
--          AND T.CUSTOMER_KEY NOT IN
--                     (SELECT ced.CUSTOMER_KEY FROM GNRC.CUSTOMER_EXT_DIM ced )
;


select AT1.CREATION_DT,AT1.AUDIT_KEY,COUNT(*),count(distinct SERIAL_NO),count(distinct CUSTOMER_KEY),count(distinct current_address_key) FROM TMP_CUSTOMERS_NCOA_OCT_NOV_2024 onc
         JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = onc.INSERT_AUDIT_KEY
 group by AT1.CREATION_DT,AT1.AUDIT_KEY
Order by AT1.CREATION_DT desc
;
+--------------------------+---------+--------+------------------------+---------------------------+----------------------------------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|COUNT(DISTINCTSERIAL_NO)|COUNT(DISTINCTCUSTOMER_KEY)|COUNT(DISTINCTCURRENT_ADDRESS_KEY)|
+--------------------------+---------+--------+------------------------+---------------------------+----------------------------------+
|2024-11-07 06:02:26.000000|1012287  |8085    |8084                    |8085                       |7845                              |
|2024-10-09 04:17:23.000000|1003916  |5611    |5611                    |5611                       |5420                              |
+--------------------------+---------+--------+------------------------+---------------------------+----------------------------------+

+--------------------------+---------+--------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|
+--------------------------+---------+--------+
|2024-11-07 06:02:26.000000|1012287  |7876    |
|2024-10-09 04:17:23.000000|1003916  |5477    |
+--------------------------+---------+--------+

select COUNT(*) from (
    select CURRENT_ADDRESS_KEY,Count(*)
    FROM TMP_CUSTOMERS_NCOA_OCT_NOV_2024
    group by CURRENT_ADDRESS_KEY
    having Count(*) > 1
)--422
;

select CURRENT_ADDRESS_KEY,Count(*)
    FROM TMP_CUSTOMERS_NCOA_OCT_NOV_2024
    group by CURRENT_ADDRESS_KEY
    having Count(*) > 2;
-- +-------------------+--------+
-- |CURRENT_ADDRESS_KEY|COUNT(*)|
-- +-------------------+--------+
-- |8695508            |2       |
-- |667266             |2       |
-- |1956232            |2       |
-- |1549822            |3       |
-- |3880628            |2       |
-- |4056784            |2       |
-- |4719346            |2       |
-- |4723886            |2       |
-- |7600670            |2       |
-- |8291820            |2       |
-- +-------------------+--------+
-- +-------------------+--------+
-- |CURRENT_ADDRESS_KEY|COUNT(*)|
-- +-------------------+--------+
-- |1549822            |3       |
-- |2481718            |3       |
-- |6374484            |3       |
-- |5718066            |3       |
-- |6653842            |3       |
-- |6932884            |3       |
-- |8517074            |3       |
-- |8523364            |3       |
-- |6241350            |3       |
-- +-------------------+--------+

select * from TMP_CUSTOMERS_NCOA_OCT_NOV_2024 where CURRENT_ADDRESS_KEY = 1549822;
-- +------------+-------------------+----------------+----------------+----------+
-- |CUSTOMER_KEY|CURRENT_ADDRESS_KEY|ORIG_ADDRESS_KEY|INSERT_AUDIT_KEY|SERIAL_NO |
-- +------------+-------------------+----------------+----------------+----------+
-- |1760062     |8695508            |NULL            |1012287         |3005939011|
-- |1668658     |8695508            |NULL            |1012287         |3005275104|
-- +------------+-------------------+----------------+----------------+----------+
-- +------------+-------------------+----------------+----------------+----------+
-- |CUSTOMER_KEY|CURRENT_ADDRESS_KEY|ORIG_ADDRESS_KEY|INSERT_AUDIT_KEY|SERIAL_NO |
-- +------------+-------------------+----------------+----------------+----------+
-- |1820856     |1549822            |NULL            |1012287         |3005194932|
-- |1820860     |1549822            |NULL            |1012287         |3005194962|
-- |752546      |1549822            |NULL            |1012287         |3000717436|
-- +------------+-------------------+----------------+----------------+----------+

select * from GNRC.NCOA_FCT where NEW_ADDRESS_KEY =1549822;
-- +-------------+-----------+---------------+
-- |NCOA_DATE_KEY|ADDRESS_KEY|NEW_ADDRESS_KEY|
-- +-------------+-----------+---------------+
-- |12730        |3836698    |1549822        |
-- |12730        |3844994    |1549822        |
-- +-------------+-----------+---------------+

select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in (3836698,3844994,1549822);
+-----------+---------+--------+-------+----------------+----------+--------+------------+------------+
|ADDRESS_KEY|SOURCE_CD|FIRST_NM|LAST_NM|ADDRESS_LINE1_TX|CITY_NM   |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|
+-----------+---------+--------+-------+----------------+----------+--------+------------+------------+
|1549822    |NCOA     |SCOTT   |HOFFMAN|216 BIRCHWOOD PL|NORTHVILLE|NY      |12134       |3734        |
|3836698    |NULL     |SCOTT   |HOFFMAN|220 BIRCHWOOD PL|NORTHVILLE|NY      |12134       |3734        |
|3844994    |NULL     |SCOTT   |HOFFMAN|224 BIRCHWOOD PL|NORTHVILLE|NY      |12134       |3734        |
+-----------+---------+--------+-------+----------------+----------+--------+------------+------------+
select * from RAW_LEADS_TBL_AS12_OCT_NOV_2024 where EQUIPMENT like '%3000717436%';
-- +-------------+----------------+----------+-----------+--------------+------------------+-----------------+------------------+-------------+---------------+--------+
-- |OWNER_NAME   |OWNER_ADDRESS1  |OWNER_CITY|OWNER_STATE|OWNER_POSTCODE|OWNER_PHONE_NUMBER|OWNER_EMAIL      |EQUIPMENT         |PURCHASE_DATE|VALID_FROM_DATE|MATERIAL|
-- +-------------+----------------+----------+-----------+--------------+------------------+-----------------+------------------+-------------+---------------+--------+
-- |Scott Hoffman|216 Birchwood Pl|Northville|NY         |12134-3734    |5188636239        |scott_5@yahoo.com|000000003000717436|2017-04-25   |2016-07-15     |G0069220|
-- +-------------+----------------+----------+-----------+--------------+------------------+-----------------+------------------+-------------+---------------+--------+

select COUNT(*) from RAW_LEADS_TBL_AS12_OCT_NOV_2024;

select AT1.CREATION_DT,AT1.AUDIT_KEY,COUNT(*) FROM RAW_LEADS_TBL_AS12_OCT_NOV_2024 onc
         JOIN AUDIT_TBL AT1 on AT1.AUDIT_KEY = onc.INSERT_AUDIT_KEY
 group by AT1.CREATION_DT,AT1.AUDIT_KEY
Order by AT1.CREATION_DT desc
;
+--------------------------+---------+--------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|
+--------------------------+---------+--------+
|2024-11-07 06:02:26.000000|1012287  |7657    |
|2024-10-09 04:17:23.000000|1003916  |5348    |
+--------------------------+---------+--------+
--Below is NCOFACT AS12 counts


select COUNT(*) from RAW_LEADS_TBL_AS12_OCT_NOV_2024
    where LTRIM(TRIM(EQUIPMENT),'0') in ( select LTRIM(TRIM(SERIAL_NO))  from  RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA);

select *  from  RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA;


select *  from  RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA;


UPDATE RAW_LEADS_TBL_AS12_OCT_NOV_2024
set ERROR_DESC = 'Sales'
    where LTRIM(TRIM(EQUIPMENT),'0') in ( select LTRIM(TRIM(SERIAL_NO))  from  RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA);

select * from RAW_LEADS_TBL_AS12_OCT_NOV_2024 where ERROR_DESC = 'Sales';


-- update RAW_LEADS_TBL_AS12_OCT_NOV_2024
-- SET ORDER_KEY = (select RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA.ORDER_KEY  from  RAW_LEADS_TBL_AS12_OCT_NOV_2024_ORDERS_DATA where LTRIM(TRIM(SERIAL_NO)) =  LTRIM(TRIM(EQUIPMENT),'0'))
-- where ERROR_DESC = 'Sales'
-- ;

select count(distinct OT.ORDER_KEY ),max(OT.ORDER_CREATED_TS),min(OT.ORDER_CREATED_TS)
  from RAW_LEADS_TBL_AS12_OCT_NOV_2024 RLT
            JOIN GNRC.SERIALIZED_ITEM_DIM SID on SID.SERIAL_NO = LTRIM(TRIM(EQUIPMENT),'0')
            JOIN GNRC.ORDER_ITEM_TBL OIT on OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY
            JOIN GNRC.ORDER_TBL OT on OT.ORDER_KEY = OIT.ORDER_KEY
where OT.ORDER_CREATED_TS > date '2024-10-01'
;
-- +---------------------------+--------------------------+--------------------------+
-- |COUNT(DISTINCTOT.ORDER_KEY)|MAX(OT.ORDER_CREATED_TS)  |MIN(OT.ORDER_CREATED_TS)  |
-- +---------------------------+--------------------------+--------------------------+
-- |41                         |2024-12-02 15:59:07.173923|2024-10-02 09:25:02.260731|
-- +---------------------------+--------------------------+--------------------------+

COMMIT;



select RL.EQUIPMENT,
       RL.OWNER_NAME,
       RL.OWNER_ADDRESS1,RL.OWNER_CITY
       ,AD.FIRST_NM,AD.LAST_NM,
       AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY
from
         RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
         join GNRC.SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
where ERROR_DESC IS NULL
AND RL.INSERT_AUDIT_KEY = 1003916 -- oct
--AND RL.INSERT_AUDIT_KEY = 1012287 -- Nov
AND UPPER(OWNER_ADDRESS1) <> ADDRESS_LINE1_TX
ORDER BY DBMS_RANDOM.RANDOM()
;
+--------------------------+---------+--------+
|CREATION_DT               |AUDIT_KEY|COUNT(*)|
+--------------------------+---------+--------+
|2024-11-07 06:02:26.000000|1012287  |7876    |
|2024-10-09 04:17:23.000000|1003916  |5477    |
+--------------------------+---------+--------+

select VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE,COUNT(*)
        ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX THEN 1 END) SAME
        ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) <> ADDRESS_LINE1_TX THEN 1 END) DIFF
        ,COUNT(CEX.CUSTOMER_KEY)
from
         RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
         join GNRC.SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          LEFT JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
where ERROR_DESC IS NULL
--AND RL.INSERT_AUDIT_KEY = 1003916 -- oct =4482 <>849
AND RL.INSERT_AUDIT_KEY = 1012287 -- Nov =204 <>7073
--AND UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX
GROUP BY VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE
;
-- +----------------------------+--------------------+--------+----+----+-----------------------+
-- |PARENT_MARKETING_CATEGORY_NM|LATEST_COVERAGE_TYPE|COUNT(*)|SAME|DIFF|COUNT(CEX.CUSTOMER_KEY)|
-- +----------------------------+--------------------+--------+----+----+-----------------------+
-- |PRESSURE WASHER             |1                   |1       |0   |1   |1                      |
-- |PORTABLE GAS GENERATOR      |1                   |60      |3   |57  |2                      |
-- |HOME STANDBY GENERATOR      |1                   |4971    |4447|522 |11                     |
-- |HOME STANDBY GENERATOR      |5                   |111     |5   |106 |0                      |
-- |HOME STANDBY GENERATOR      |18                  |22      |8   |14  |1                      |
-- |HOME STANDBY GENERATOR      |2                   |161     |15  |146 |1                      |
-- |HOME STANDBY GENERATOR      |7                   |2       |1   |1   |0                      |
-- |HOME STANDBY GENERATOR      |6                   |1       |0   |1   |0                      |
-- |HOME STANDBY GENERATOR      |21                  |4       |3   |1   |1                      |
-- +----------------------------+--------------------+--------+----+----+-----------------------+


select VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE,COUNT(*)
        ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX THEN 1 END) SAME
        ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) <> ADDRESS_LINE1_TX THEN 1 END) DIFF
        ,COUNT(CEX.CUSTOMER_KEY)
from
         RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
         join GNRC.SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          LEFT JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
where ERROR_DESC IS NULL
AND RL.INSERT_AUDIT_KEY = 1003916 -- oct =4482 <>849
--AND RL.INSERT_AUDIT_KEY = 1012287 -- Nov =204 <>7073
AND UPPER(OWNER_ADDRESS1) <> ADDRESS_LINE1_TX
AND LATEST_COVERAGE_TYPE = '1'
AND VP.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'
GROUP BY VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE
;


select RL.EQUIPMENT,
       RL.OWNER_NAME,
       RL.OWNER_ADDRESS1,RL.OWNER_CITY
       ,AD.FIRST_NM,AD.LAST_NM,
       AD.ADDRESS_LINE1_TX,AD.CITY_NM,RL.INSERT_AUDIT_KEY
--     VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE,COUNT(*)
--         ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) = ADDRESS_LINE1_TX THEN 1 END) SAME
--         ,COUNT(CASE WHEN UPPER(OWNER_ADDRESS1) <> ADDRESS_LINE1_TX THEN 1 END) DIFF
--         ,COUNT(CEX.CUSTOMER_KEY)
from
         RAW_LEADS_TBL_AS12_OCT_NOV_2024 RL
         join GNRC.SERIALIZED_ITEM_DIM SI ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
          LEFT join GNRC.VISITOR_OWNERSHIP_XREF  VOX ON  ( VOX.SI_KEY   = SI.SI_KEY AND VOX.PRIMARY_IND = 'Y'   )
          LEFT join GNRC.VISITOR_DIM  VD ON ( VOX.VISITOR_KEY = VD.VISITOR_KEY )
          LEFT join GNRC.CUSTOMER_DIM  CD ON ( VD.CUSTOMER_KEY = CD.CUSTOMER_KEY )
          LEFT join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
          LEFT JOIN GNRC.V_PRODUCT VP on VP.PRODUCT_KEY = Si.PRODUCT_KEY
          LEFT JOIN GNRC.CUSTOMER_EXT_DIM CEX ON CEX.CUSTOMER_KEY = CD.CUSTOMER_KEY
where ERROR_DESC IS NULL
--AND RL.INSERT_AUDIT_KEY = 1003916 -- oct =4482 <>849
AND RL.INSERT_AUDIT_KEY = 1012287 -- Nov =204 <>7073
AND UPPER(OWNER_ADDRESS1) <> ADDRESS_LINE1_TX
AND LATEST_COVERAGE_TYPE = '1'
AND VP.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'
--GROUP BY VP.PARENT_MARKETING_CATEGORY_NM,SI.LATEST_COVERAGE_TYPE
ORDER BY DBMS_RANDOM.RANDOM()
;