
===>SERIAL to SI_KEY use to Bundle_Item_XRF to check campaign details its picked


bundle_dim bd
	join BUNDLE_ITEM_XREF bix using (bundle_key)
	join P_CRITERIA_DIM  using (CRITERIA_KEY)
	join P_CRITERIA_CELL_XREF ccx using (CRITERIA_KEY)
	join P_SERIALIZED_ITEM_DIM si using (si_key);




select CRITERIA_CD, DROP_DT, count(*)  from bundle_dim bd
		join BUNDLE_ITEM_XREF bix using (bundle_key)
		join P_CRITERIA_DIM using (CRITERIA_KEY)
		join P_CRITERIA_CELL_XREF ccx using (CRITERIA_KEY)
		join P_SERIALIZED_ITEM_DIM si using (si_key)
group by CRITERIA_CD, DROP_DTorder by CRITERIA_CD, DROP_DT;





--This logic based upon STREAM_LENGTH_DAYS is much better than the one based upon state_machine_key
update camp_available_universe_tbl cmp
set wf_suppression_cd = 'Mid Stream'
where wf_suppression_cd is null
and SI_KEY IN
  (select SI_KEY from
          (SELECT t0.SI_KEY, t0.drop_dt, t2.drop_dt + coalesce(t3.STREAM_LENGTH_DAYS, 0) as stream_end_dt, t3.STREAM_LENGTH_DAYS,
                  t0.CRITERIA_KEY, t3.CRITERIA_XID,
                  row_number() over (partition by t0.SI_KEY order by t2.drop_dt + coalesce(t3.STREAM_LENGTH_DAYS, 0) desc) as rno
          FROM  camp_available_universe_tbl t0
                join gnrc.bundle_item_xref  t1 on t0.SI_KEY       = t1.SI_KEY
                join gnrc.bundle_dim        t2 on t1.bundle_key   = t2.bundle_key
                join gnrc.criteria_dim      t3 on t2.criteria_key = t3.criteria_key
          WHERE 1=1
          AND t0.wf_suppression_cd is null
          AND t2.suppression_cd IS NULL
          AND coalesce(t3.selection_tbl, 'xyz') <> 'v_outbound_universe'   --exclude OB bundles
          AND t2.BUNDLE_KEY  in (--to be called mid-stream, lets check that bundle is either active in SM or appears in CPF and has not been suppressed
                  (select bst2.BUNDLE_KEY from gnrc.BUNDLE_STATE_TBL bst2 join gnrc.STATE_TBL s2 using (state_key) WHERE s2.state_type_cd = 'A'
                  union all
                  select cp.bundle_key from gnrc.campaign_participation_fct cp
                  )
                   minus
                   select sup.bundle_key from gnrc.SUPPRESSION_TBL sup where sup.bundle_key is not null
                  )
          )
   where rno = 1
      AND drop_dt         < stream_end_dt
  );




SELECT camp.campaign_xid, CRITERIA_CD, PARENT_CATEGORY_NM, DROP_DT
  FROM gnrc.cell_dim cell
			   JOIN gnrc.cell_group_dim cgd
				  ON (cgd.cell_group_key = cell.cell_group_key)
			   JOIN gnrc.campaign_dim camp
				  ON (CAMP.CAMPAIGN_KEY = cgd.campaign_key)
			   JOIN gnrc.cell_selection_fct cs
				  on cs.cell_key = cell.cell_key
			   join gnrc.bundle_item_xref bix
				  on bix.bundle_key = cs.bundle_key
			   join gnrc.bundle_dim bd
				  on bd.bundle_key = bix.bundle_key
			   join gnrc.criteria_dim cri
				  on cri.criteria_key = bd.criteria_key
			   join gnrc.serialized_item_dim si
				  on si.si_key = bix.si_key
			   join gnrc.v_product vpr
				  on vpr.product_key = si.product_key
		--        left join gnrc.serialized_item_ext_dim six
		--           on six.si_key = si.si_key
		--        left join gnrc.suppression_tbl sup
		--          on sup.bundle_key = bd.bundle_key
		--        join gnrc.customer_dim cust on cust.customer_key = bd.customer_key
		  WHERE 1=1
		   AND bix.si_key in (...)
		group by camp.campaign_xid, CRITERIA_CD, PARENT_CATEGORY_NM, DROP_DT
		order by camp.campaign_xid, CRITERIA_CD, PARENT_CATEGORY_NM, DROP_DT

