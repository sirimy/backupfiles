
select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from GNRC.RAW_LEADS_TBL group by FILE_NM,INSERT_AUDIT_KEY order by INSERT_AUDIT_KEY desc;
-- +----------------------------------------+----------------+--------+
-- |FILE_NM                                 |INSERT_AUDIT_KEY|COUNT(*)|
-- +----------------------------------------+----------------+--------+
-- |gnrc_after_leads_2025-04-30-14-56-12.txt|1069624         |2987    |
-- +----------------------------------------+----------------+--------+

Select COUNT(*) from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt';--2987


    select COUNT(*) from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
    );--2987

select COUNT(*) from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
    );--3046


Select * from GNRC.SERIALIZED_ITEM_DIM where SI_KEY in (
    select POSTED_SERIAL_ITEM_KEY from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
    ));--2987

Select COUNT(*) from GNRC.SERIALIZED_ITEM_DIM where SI_KEY in (
    select POSTED_SERIAL_ITEM_KEY from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
    ));--2987


Select COUNT(*) from GNRC.VISITOR_OWNERSHIP_XREF where SI_KEY in (
    select POSTED_SERIAL_ITEM_KEY from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
    ));--2987


Select * from GNRC.SERIALIZED_ITEM_EXT_DIM where SI_KEY in (
    select POSTED_SERIAL_ITEM_KEY from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
    ));--2987

 Select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in (
    select ADDRESS_KEY from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
            Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
        ))
and FIRM_NM IS NOT NULL
;--50 firm name its treated


Select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in (
    select ADDRESS_KEY from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
            Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
        ))
and ZIP_CODE5_TX is null
;--0 ZIP_CODE5_TX is null

Select COUNT(*) from GNRC.CUSTOMER_DIM where PRIMARY_ADDRESS_KEY in (
    select ADDRESS_KEY from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
            Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
        ))
;--3019


Select COUNT(*),max(INSERT_AUDIT_KEY),min(INSERT_AUDIT_KEY) from GNRC.CUSTOMER_DIM CD JOIN AUDIT_TBL ATB on CD.INSERT_AUDIT_KEY =ATB.AUDIT_KEY
where PRIMARY_ADDRESS_KEY in (
    select ADDRESS_KEY from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
            Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'gnrc_after_leads_2025-04-30-14-56-12.txt'
        ))
AND CREATION_DT > sysdate - 1
;--2859
-- +--------+---------------------+---------------------+
-- |COUNT(*)|MAX(INSERT_AUDIT_KEY)|MIN(INSERT_AUDIT_KEY)|
-- +--------+---------------------+---------------------+
-- |2859    |1069642              |1069642              |
-- +--------+---------------------+---------------------+