
select FILE_NM,INSERT_AUDIT_KEY,COUNT(*) from GNRC.RAW_DEALER_LEADS_TBL group by FILE_NM,INSERT_AUDIT_KEY order by INSERT_AUDIT_KEY desc;
-- +-------------------------------------------------------+----------------+--------+
-- |FILE_NM                                                |INSERT_AUDIT_KEY|COUNT(*)|
-- +-------------------------------------------------------+----------------+--------+
-- |Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt|1069799         |625     |
-- +-------------------------------------------------------+----------------+--------+

Select COUNT(*) from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt';--614


    select COUNT(*) from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
    );--614

select COUNT(*) from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
    );--614


Select COUNT(*) from GNRC.SERIALIZED_ITEM_DIM where SI_KEY in (
    select POSTED_SERIAL_ITEM_KEY from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
    ));--614

Select COUNT(*) from GNRC.SERIALIZED_ITEM_DIM where SI_KEY in (
    select POSTED_SERIAL_ITEM_KEY from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
    ));--614


Select COUNT(*) from GNRC.VISITOR_OWNERSHIP_XREF where SI_KEY in (
    select POSTED_SERIAL_ITEM_KEY from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
    ));--623


Select * from GNRC.SERIALIZED_ITEM_EXT_DIM where SI_KEY in (
    select POSTED_SERIAL_ITEM_KEY from GNRC.SI_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
        Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
    ));--623

 Select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in (
    select ADDRESS_KEY from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
            Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
        ))
and FIRM_NM IS NOT NULL
;--3 firm name its treated


Select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in (
    select ADDRESS_KEY from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
            Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
        ))
and ZIP_CODE5_TX is null
;--0 ZIP_CODE5_TX is null

Select COUNT(*) from GNRC.CUSTOMER_DIM where PRIMARY_ADDRESS_KEY in (
    select ADDRESS_KEY from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
            Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
        ))
;--609


Select COUNT(*),max(INSERT_AUDIT_KEY),min(INSERT_AUDIT_KEY) from GNRC.CUSTOMER_DIM CD JOIN AUDIT_TBL ATB on CD.INSERT_AUDIT_KEY =ATB.AUDIT_KEY
where PRIMARY_ADDRESS_KEY in (
    select ADDRESS_KEY from GNRC.ADDRESS_OUTPUT_TBL_ARCH where UNIQUE_SEQ_NO in (
            Select UNIQUE_SEQ_NO from GNRC.COMMON_LOAD_TBL_ARCH where FILE_NM = 'Generac_After_Leads_ExtWarranty_2025-04-30-07-02-41.txt'
        ))
AND CREATION_DT > sysdate - 1
;--
-- +--------+---------------------+---------------------+
-- |COUNT(*)|MAX(INSERT_AUDIT_KEY)|MIN(INSERT_AUDIT_KEY)|
-- +--------+---------------------+---------------------+
-- |497     |1069800              |1069800              |
-- +--------+---------------------+---------------------+