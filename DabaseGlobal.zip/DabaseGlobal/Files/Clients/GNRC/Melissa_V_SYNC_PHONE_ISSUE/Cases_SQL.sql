-- CREATE TABLE GNRC_DS_ACE_OUTPUT_TBL_ARCH_GNRC_1786
--   AS (SELECT * FROM GNRC.DS_ACE_OUTPUT_TBL_ARCH  where PROCESS_DT = '20250520');

CREATE TABLE GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786
  AS (SELECT * FROM GNRC.COMMON_LOAD_TBL_ARCH  where PROCESS_DT = '20250520');



select * from GNRC_ADDRESS_OUTPUT_TBL_ARCH_GNRC_1786;
select * from GNRC_DS_ACE_OUTPUT_TBL_ARCH_GNRC_1786;
select * from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786;



select T2.PHONE_NO,T1.CITY_NM,T2.CITY_NM,T1.STATE_CD,T2.STATE_CD from GNRC_DS_ACE_OUTPUT_TBL_ARCH_GNRC_1786 T1
        JOIN GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 ON T1.UNIQUE_SEQ_NO = T2.UNIQUE_SEQ_NO
where T2.FILE_NM = 'v_sync_phone'
  AND ( T1.CITY_NM IS not NULL  OR T1.STATE_CD IS NOT NULL)
;




MERGE INTO GNRC_DS_ACE_OUTPUT_TBL_ARCH_GNRC_1786 tgt
    USING (SELECT * FROM GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 WHERE FILE_NM = 'v_sync_phone') src
    ON (tgt.UNIQUE_SEQ_NO = src.UNIQUE_SEQ_NO)
  WHEN MATCHED THEN
    UPDATE SET tgt.CITY_NM = src.CITY_NM,
               tgt.STATE_CD = src.STATE_CD
  WHERE tgt.CITY_NM IS not NULL  OR tgt.STATE_CD IS NOT NULL;





select COUNT(*) from GNRC.DS_ACE_OUTPUT_TBL_ARCH  where PROCESS_DT = '20250520';--228
select COUNT(*) from GNRC.COMMON_LOAD_TBL_ARCH  where PROCESS_DT = '20250520';--228
select COUNT(*) from GNRC.ADDRESS_OUTPUT_TBL_ARCH  where PROCESS_DT = '20250520';--228
select COUNT(*) from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM = 'v_sync_phone';--114
select distinct CITY_NM,STATE_CD from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM = 'v_sync_phone';--114

select ADDRESS_KEY,COUNT(*) from GNRC_ADDRESS_OUTPUT_TBL_ARCH_GNRC_1786 T1
        JOIN GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 ON T1.UNIQUE_SEQ_NO = T2.UNIQUE_SEQ_NO
where T2.FILE_NM = 'v_sync_phone'
group by ADDRESS_KEY;


select distinct SOURCE_TABLE_NAME from GNRC.SYNC_PROCESS_MAPPING_TBL where TARGET_SYSTEM_NAME = 'GNRCSTG' and TARGET_TABLE_NAME
in ('COMMON_LOAD_ADDRESS_TBL','COMMON_LOAD_EMAIL_TBL','COMMON_LOAD_PHONE_TBL');
-- +-----------------+
-- |SOURCE_TABLE_NAME|
-- +-----------------+
-- |V_SYNC_ADDRESS   |
-- |V_SYNC_EMAIL     |
-- |V_SYNC_PHONE     |
-- +-----------------+

-- v_sync_phone(phone_xid, visitor_xid, primary_phone_ind, phone_no, phone_ext, file_nm, phone_role_type, last_updated_by, last_updated_ts, phone_pref_ind) as
-- 	SELECT phone_xid,
--     visitor_xid,
--     primary_phone_ind,
--     phone_no,
--     phone_ext,
--     file_nm,
--     phone_role_type,
--     last_updated_by,
--     last_updated_ts,
--     phone_pref_ind
--    FROM ( SELECT cpxa.last_updated_ts,
--             pd.phone_id AS phone_xid,
--             pd.phone_no,
--             pd.phone_ext,
--             cpxa.customer_id AS visitor_xid,
--                 CASE
--                     WHEN cust.primary_phone_id IS NULL THEN 'N'::text
--                     ELSE 'Y'::text
--                 END AS primary_phone_ind,
--             cpxa.phone_role_cd AS phone_role_type,
--             'v_sync_phone'::text AS file_nm,
--             upper(cpxa.last_updated_by) AS last_updated_by,
--                 CASE
--                     WHEN COALESCE(cust.do_not_phone::text, 'Y'::text) = 'Y'::text THEN 'N'::text
--                     ELSE 'Y'::text
--                 END AS phone_pref_ind,
--             row_number() OVER (PARTITION BY cpxa.customer_id, cpxa.phone_id ORDER BY cpxa.last_updated_ts DESC) AS rno
--            FROM ( SELECT customer_phone_xref_audit.cust_phone_audit_id,
--                     customer_phone_xref_audit.last_updated_ts,
--                     COALESCE(upper(customer_phone_xref_audit.last_updated_by::text), 'SYSTEM'::character varying::text) AS last_updated_by,
--                     customer_phone_xref_audit.phone_id,
--                     customer_phone_xref_audit.customer_id,
--                     customer_phone_xref_audit.phone_role_cd,
--                     customer_phone_xref_audit.dml_flag
--                    FROM customer_phone_xref_audit
--                   WHERE COALESCE(upper(customer_phone_xref_audit.last_updated_by::text), 'SYSTEM'::character varying::text) <> 'GNRC'::text AND customer_phone_xref_audit.dml_flag::text <> 'DELETE'::text) cpxa
--              LEFT JOIN phone_tbl pd ON cpxa.phone_id = pd.phone_id
--              LEFT JOIN customer_tbl cust ON cpxa.customer_id = cust.customer_id AND cpxa.phone_id = cust.primary_phone_id) t1
--   WHERE rno = 1;



-------------------------------------------------
-- v_sync_email(email_xid, visitor_xid, primary_email_ind, email_address_tx, file_nm, email_role_type, last_updated_by, last_updated_ts, email_pref_ind) as
-- 	SELECT email_xid,
--     visitor_xid,
--     primary_email_ind,
--     email_address_tx,
--     file_nm,
--     email_role_type,
--     last_updated_by,
--     last_updated_ts,
--     email_pref_ind
--    FROM ( SELECT cexa.last_updated_ts,
--             ed.email_id AS email_xid,
--             ed.email_address_tx,
--             cexa.customer_id AS visitor_xid,
--                 CASE
--                     WHEN cust.primary_email_id IS NULL THEN 'N'::text
--                     ELSE 'Y'::text
--                 END AS primary_email_ind,
--             cexa.email_role_cd AS email_role_type,
--             'v_sync_email'::text AS file_nm,
--             COALESCE(upper(cexa.last_updated_by::text), 'SYSTEM'::character varying::text) AS last_updated_by,
--                 CASE
--                     WHEN COALESCE(cust.do_not_email::text, 'Y'::text) = 'Y'::text THEN 'N'::text
--                     ELSE 'Y'::text
--                 END AS email_pref_ind,
--             row_number() OVER (PARTITION BY cexa.customer_id, cexa.email_id ORDER BY cexa.last_updated_ts DESC) AS rno
--            FROM ( SELECT customer_email_xref_audit.cust_email_audit_id,
--                     customer_email_xref_audit.last_updated_ts,
--                     customer_email_xref_audit.last_updated_by,
--                     customer_email_xref_audit.email_id,
--                     customer_email_xref_audit.customer_id,
--                     customer_email_xref_audit.email_role_cd,
--                     customer_email_xref_audit.dml_flag
--                    FROM customer_email_xref_audit
--                   WHERE COALESCE(upper(customer_email_xref_audit.last_updated_by::text), 'SYSTEM'::character varying::text) <> 'GNRC'::text AND customer_email_xref_audit.dml_flag::text <> 'DELETE'::text) cexa
--              LEFT JOIN email_tbl ed ON cexa.email_id = ed.email_id
--              LEFT JOIN customer_tbl cust ON cexa.customer_id = cust.customer_id AND cexa.email_id = cust.primary_email_id) t1
--   WHERE rno = 1;

---------------------------------------------------------
--
-- v_sync_address(address_xid, visitor_xid, primary_address_ind, first_nm, middle_nm, last_nm, firm_nm, address_line1_tx, address_line2_tx, address_line3_tx, city_nm, city_nm2, state_cd, zip_cd_tx, country_cd, address_role_type, last_updated_ts, file_nm, last_updated_by, mail_pref_ind) as
-- 	SELECT address_xid,
--     visitor_xid,
--     primary_address_ind,
--     first_nm,
--     middle_nm,
--     last_nm,
--     firm_nm,
--     address_line1_tx,
--     address_line2_tx,
--     address_line3_tx,
--     city_nm,
--     city_nm2,
--     state_cd,
--     zip_cd_tx,
--     country_cd,
--     address_role_type,
--     last_updated_ts,
--     file_nm,
--     last_updated_by,
--     mail_pref_ind
--    FROM ( SELECT caxa.last_updated_ts,
--             ad.address_id AS address_xid,
--             caxa.customer_id AS visitor_xid,
--                 CASE
--                     WHEN cust.primary_address_id IS NULL THEN 'N'::text
--                     ELSE 'Y'::text
--                 END AS primary_address_ind,
--             "substring"(btrim(ad.first_nm::text), 1, 60) AS first_nm,
--             "substring"(btrim(ad.middle_nm::text), 1, 60) AS middle_nm,
--             "substring"(btrim(ad.last_nm::text), 1, 60) AS last_nm,
--             "substring"(btrim(ad.firm_nm::text), 1, 60) AS firm_nm,
--             "substring"(btrim(ad.address_line1_tx::text), 1, 60) AS address_line1_tx,
--             "substring"(btrim(ad.address_line2_tx::text), 1, 60) AS address_line2_tx,
--             "substring"(btrim(ad.address_line3_tx::text), 1, 60) AS address_line3_tx,
--             "substring"(btrim(ad.locality_nm::text), 1, 60) AS city_nm,
--             "substring"(btrim(ad.locality2_nm::text), 1, 60) AS city_nm2,
--             st.code AS state_cd,
--             ad.postal_code1_tx::text || ad.postal_code2_tx::text AS zip_cd_tx,
--             ad.postal_code2_tx,
--             co.country_3byte_cd AS country_cd,
--             caxa.address_role_cd AS address_role_type,
--             'v_sync_address'::text AS file_nm,
--             COALESCE(upper(caxa.last_updated_by::text), 'SYSTEM'::character varying::text) AS last_updated_by,
--                 CASE
--                     WHEN COALESCE(cust.do_not_mail::text, 'Y'::text) = 'Y'::text THEN 'N'::text
--                     ELSE 'Y'::text
--                 END AS mail_pref_ind,
--             row_number() OVER (PARTITION BY caxa.customer_id, caxa.address_id ORDER BY caxa.last_updated_ts DESC) AS rno
--            FROM ( SELECT customer_address_xref_audit.cust_addr_audit_id,
--                     customer_address_xref_audit.last_updated_ts,
--                     customer_address_xref_audit.last_updated_by,
--                     customer_address_xref_audit.customer_id,
--                     customer_address_xref_audit.address_id,
--                     customer_address_xref_audit.address_role_cd,
--                     customer_address_xref_audit.dml_flag
--                    FROM customer_address_xref_audit
--                   WHERE customer_address_xref_audit.dml_flag::text <> 'DELETE'::text AND COALESCE(upper(customer_address_xref_audit.last_updated_by::text), 'SYSTEM'::character varying::text) <> 'GNRC'::text) caxa
--              LEFT JOIN address_tbl ad ON caxa.address_id = ad.address_id
--              LEFT JOIN state st ON ad.state_id = st.state_id
--              LEFT JOIN country co ON st.country_id = co.country_id
--              LEFT JOIN customer_tbl cust ON caxa.customer_id = cust.customer_id AND caxa.address_id = cust.primary_address_id) t1
--   WHERE rno = 1;

--
select * from GNRC.VISITOR_LKP where VISITOR_XID = '1724218';
-- +-----------+-----------+----------------+
-- |VISITOR_KEY|VISITOR_XID|SOURCE_SYSTEM_CD|
-- +-----------+-----------+----------------+
-- |899744     |1724218    |2               |
-- +-----------+-----------+----------------+

select * from v_visitor_address where VISITOR_KEY = 899744;
-- +-----------+-----------+
-- |VISITOR_KEY|ADDRESS_KEY|
-- +-----------+-----------+
-- |899744     |9450708    |
-- +-----------+-----------+

select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in(9450708,3633948);

select * from (
SELECT *
     FROM visitor_address_xref
    WHERE primary_ind = 'Y'
   UNION ALL
   SELECT *
     FROM p_visitor_address_xref t1
) where VISITOR_KEY = 899744;
-- +-----------+-----------+
-- |VISITOR_KEY|ADDRESS_KEY|
-- +-----------+-----------+
-- |899744     |3633948    |
-- |899744     |9450708    |
-- +-----------+-----------+
--     WHERE     primary_ind = 'Y'
--           AND NOT EXISTS
--                  (SELECT 1
--                     FROM visitor_address_xref t2
--                    WHERE t1.visitor_key = t2.visitor_key);

-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX|ADDRESS_LINE2_TX|CITY_NM|STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |3633948    |NULL   |NULL     |JAMES   |NULL     |TIMLER |201293 DUBAY DR |NULL            |MOSINEE|WI      |54455       |7507        |N             |S08000      |NULL    |A            |NULL                 |NULL       |11106     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |DUBAY            |201293           |NULL   |NULL     |NULL       |NULL     |Y            |545937          |1053832         |NULL |NULL    |NULL    |93                   |6           |R010            |0281A         |USA       |NULL     |NULL               |NULL           |NULL                   |1053832       |
-- |9450708    |NULL   |NULL     |NULL    |NULL     |NULL   |NULL            |NULL            |WAUSAU |WI      |NULL        |NULL        |N             |NULL        |NULL    |A            |NULL                 |NULL       |12923     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |NULL             |NULL             |NULL   |NULL     |NULL       |NULL     |NULL         |1078305         |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |1078322       |
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+

-- 2 main SQL

--[1] Counts from  MD data table
select COUNT( distinct AD.ADDRESS_KEY ) from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                    join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                    join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VL.VISITOR_KEY
                    join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = pvdx.ADDRESS_KEY
                    join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY
                    join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                    join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                    join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                where --DSACE.PROCESS_DT = '20250520' AND
                      DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
                      AND pvdx.PRIMARY_IND = 'Y'  AND AD.ADDRESS_LINE1_TX IS NULL
                      AND ATT.CREATION_DT >= date '2025-05-01'
                      AND ATT2.CREATION_DT >= date '2025-05-01'
;--394

-- [2] Counts from direct check address and customer from blank records

select  COUNT(distinct AD.ADDRESS_KEY )
from GNRC.VISITOR_OWNERSHIP_XREF VOX
            join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join gnrc.VISITOR_DIM VD on VD.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
where VOX.PRIMARY_IND = 'Y' AND AD.ADDRESS_LINE1_TX IS NULL
      AND ATT.CREATION_DT >= date '2025-05-01'
ORDER BY DBMS_RANDOM.RANDOM()
;--403











select COUNT(distinct VISITOR_KEY) from (
    select DISTINCT cvdx.VISITOR_KEY,gvdx.ADDRESS_KEY, cvdx.ADDRESS_KEY
           ,ATT.CREATION_DT,AD.FIRST_NM,AD.LAST_NM,AD.ADDRESS_LINE1_TX
           ,ATT2.CREATION_DT,AD1.FIRST_NM,AD1.LAST_NM,AD1.ADDRESS_LINE1_TX
        from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
            join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = gvdx.ADDRESS_KEY
            join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cvdx.ADDRESS_KEY
            join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = gvdx.VISITOR_KEY
            join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
            join AUDIT_TBL ATT2 on AD1.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
        where cvdx.ADDRESS_KEY <> gvdx.ADDRESS_KEY
              and cvdx.VISITOR_KEY in (
                select cvdx.VISITOR_KEY
                 from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                    join  gnrc.CUSTOMER_DIM cd on cd.PRIMARY_VISITOR_KEY = cvdx.VISITOR_KEY
                 group by cvdx.VISITOR_KEY,cd.CUSTOMER_KEY
                 having COUNT(*)=2
                )
            and AD.ADDRESS_LINE1_TX IS NULL
            and AD1.ADDRESS_LINE1_TX IS NOT NULL
    order by cvdx.VISITOR_KEY,ATT.CREATION_DT
)t
;--509

Select COUNT(distinct T2_ADDRESS_KEY) from (

    Select T1.ADDRESS_KEY,T2.ADDRESS_KEY AS T2_ADDRESS_KEY,t1.PRIMARY_IND,t2.PRIMARY_IND,t1.END_DT_KEY,t2.END_DT_KEY,T2.CREATION_DT,T2.INSERT_AUDIT_KEY,t1.SYNC_AUDIT_KEY,t1.UPDATE_AUDIT_KEY,t2.SYNC_AUDIT_KEY,ATT.CREATION_DT from (

        select * from p_visitor_address_xref where
        VISITOR_KEY in
        (
        select cvdx.VISITOR_KEY
                         from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                            join  gnrc.CUSTOMER_DIM cd on cd.PRIMARY_VISITOR_KEY = cvdx.VISITOR_KEY
                         group by cvdx.VISITOR_KEY,cd.CUSTOMER_KEY
                         having COUNT(*)=2
            )
     ) T1
    join gnrstg_p_visitor_address_xref_gnc_1786 T2 on T2.VISITOR_KEY =  t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                                        AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
    join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
    where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
    order by T2.CREATION_DT
        ) T1
;

Select COUNT(*) from (
    select cvdx.VISITOR_KEY
                 from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                 group by cvdx.VISITOR_KEY
                 having COUNT(*)=2
    );--359

Select COUNT(*) from (
    select cd.CUSTOMER_KEY
         from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
            join  gnrc.CUSTOMER_DIM cd on cd.PRIMARY_VISITOR_KEY = cvdx.VISITOR_KEY
    group by  cd.CUSTOMER_KEY
    having COUNT(*)=2);

;




--  select cvdx.VISITOR_KEY
--                  from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
--                     join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
--                  group by cvdx.VISITOR_KEY
--                  having COUNT(*)=2;


select COUNT(distinct VISITOR_KEY) from (
    select DISTINCT cvdx.VISITOR_KEY,gvdx.ADDRESS_KEY, cvdx.ADDRESS_KEY
           ,ATT.CREATION_DT,AD.FIRST_NM,AD.LAST_NM,AD.ADDRESS_LINE1_TX
           ,ATT2.CREATION_DT,AD1.FIRST_NM,AD1.LAST_NM,AD1.ADDRESS_LINE1_TX
        from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
            join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = gvdx.ADDRESS_KEY
            join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cvdx.ADDRESS_KEY
            join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = gvdx.VISITOR_KEY
            join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
            join AUDIT_TBL ATT2 on AD1.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
        where cvdx.ADDRESS_KEY <> gvdx.ADDRESS_KEY
              and cvdx.VISITOR_KEY in (
                select cvdx.VISITOR_KEY
                 from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                 group by cvdx.VISITOR_KEY
                 having COUNT(*) > 2
                )
            and AD.ADDRESS_LINE1_TX IS NULL
            and AD1.ADDRESS_LINE1_TX IS NOT NULL
    order by cvdx.VISITOR_KEY,ATT.CREATION_DT
)t
;--48

    Select T.VISITOR_KEY,T.ADDRESS_KEY_1, T.ADDRESS_KEY_2
                   ,T.CREATION_DT_1,T.FIRST_NM_1,T.LAST_NM_1,T.ADDRESS_LINE1_TX_1
                   ,T.CREATION_DT_2
                    , ROW_NUMBER() OVER( PARTITION BY T.VISITOR_KEY ORDER BY T.CREATION_DT_2 DESC) as SEQ_NO
                    ,T.FIRST_NM_2,T.LAST_NM_2,T.ADDRESS_LINE1_TX_2--,T.SERIAL_NO
    from (
        select DISTINCT cvdx.VISITOR_KEY,gvdx.ADDRESS_KEY AS ADDRESS_KEY_1, cvdx.ADDRESS_KEY AS ADDRESS_KEY_2
                   ,ATT.CREATION_DT AS CREATION_DT_1,AD.FIRST_NM AS FIRST_NM_1,AD.LAST_NM AS LAST_NM_1,AD.ADDRESS_LINE1_TX AS ADDRESS_LINE1_TX_1
                   ,ATT2.CREATION_DT AS CREATION_DT_2,AD1.FIRST_NM AS FIRST_NM_2,AD1.LAST_NM AS LAST_NM_2,AD1.ADDRESS_LINE1_TX AS ADDRESS_LINE1_TX_2--,SD.SERIAL_NO
                from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                    join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = gvdx.ADDRESS_KEY
                    join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cvdx.ADDRESS_KEY
                    join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = gvdx.VISITOR_KEY and VOX.PRIMARY_IND = 'Y'
                    --join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                    join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                    join AUDIT_TBL ATT2 on AD1.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
                where 1=1 AND cvdx.ADDRESS_KEY <> gvdx.ADDRESS_KEY
                      and cvdx.VISITOR_KEY in (
                        select cvdx.VISITOR_KEY
                         from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                         group by cvdx.VISITOR_KEY
                         having COUNT(*) > 2
                        )
                    and AD.ADDRESS_LINE1_TX IS NULL
                    and AD1.ADDRESS_LINE1_TX IS NOT NULL
                    and ATT2.CREATION_DT < date '2025-05-01'
           ) T
        order by T.VISITOR_KEY,T.CREATION_DT_2
;

--New Final SQL


Select T1.VISITOR_KEY,T1.ADDRESS_KEY,T2.ADDRESS_KEY AS T2_ADDRESS_KEY,t1.PRIMARY_IND,t2.PRIMARY_IND,t1.END_DT_KEY,t2.END_DT_KEY,T2.CREATION_DT,T2.INSERT_AUDIT_KEY,t1.SYNC_AUDIT_KEY,t1.UPDATE_AUDIT_KEY,t2.SYNC_AUDIT_KEY,ATT.CREATION_DT
from (
        select * from p_visitor_address_xref T0 where
        VISITOR_KEY in
        (
        select cvdx.VISITOR_KEY
                         from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                            join  gnrc.CUSTOMER_DIM cd on cd.PRIMARY_VISITOR_KEY = cvdx.VISITOR_KEY
                         group by cvdx.VISITOR_KEY,cd.CUSTOMER_KEY
                         having COUNT(*) > 2
            )
     ) T1
    join gnrstg_p_visitor_address_xref_gnc_1786 T2 on T2.VISITOR_KEY =  t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                                        AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
    join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
    where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
    order by T2.CREATION_DT
;



CREATE TABLE GNRC_VISITOR_ADDRESS_XREF_GNRC_1786_BACKUP
  AS (
      select * from GNRC.VISITOR_ADDRESS_XREF VAX where VAX.VISITOR_KEY in (
    select T2.VISITOR_KEY from gnrstg_p_visitor_address_xref_gnc_1786 T2
    )
);



CREATE TABLE GNRC_VISITOR_ADDRESS_XREF_GNRC_1786
  AS (
      select * from GNRC.VISITOR_ADDRESS_XREF VAX where VAX.VISITOR_KEY in (
    select T2.VISITOR_KEY from gnrstg_p_visitor_address_xref_gnc_1786 T2
    )
);


select * from gnrstg_p_visitor_address_xref_gnc_1786;

select * from GNRC.CUSTOMER_DIM CD where CD.CUSTOMER_KEY in (
        select CDD.CUSTOMER_KEY from gnrstg_p_visitor_address_xref_gnc_1786 T2
                              JOIN gnrc.ADDRESS_DIM ad ON AD.ADDRESS_KEY = T2.ADDRESS_KEY
                              join GNRC.CUSTOMER_DIM  CDD on CDD.PRIMARY_ADDRESS_KEY = Ad.ADDRESS_KEY AND CDD.PRIMARY_VISITOR_KEY = T2.VISITOR_KEY

        where AD.ADDRESS_LINE1_TX is null
    );

--  temp table copy data
CREATE TABLE GNRC_CUSTOMER_DIM_GNRC_1786_BACKUP
  AS (
     select * from GNRC.CUSTOMER_DIM CD where CD.CUSTOMER_KEY in (
        select CDD.CUSTOMER_KEY from gnrstg_p_visitor_address_xref_gnc_1786 T2
                              JOIN gnrc.ADDRESS_DIM ad ON AD.ADDRESS_KEY = T2.ADDRESS_KEY
                              join GNRC.CUSTOMER_DIM  CDD on CDD.PRIMARY_ADDRESS_KEY = Ad.ADDRESS_KEY AND CDD.PRIMARY_VISITOR_KEY = T2.VISITOR_KEY

        where AD.ADDRESS_LINE1_TX is null
    )
);--561 rows affected in 367 ms


select COUNT(*) from GNRC_CUSTOMER_DIM_GNRC_1786;--561
select COUNT(*) from GNRC_CUSTOMER_DIM_GNRC_1786_BACKUP;--560


select * from GNRC.CUSTOMER_DIM CD where CD.CUSTOMER_KEY in
                                         (select CDD.CUSTOMER_KEY
                                                             from gnrstg_p_visitor_address_xref_gnc_1786 T2
                                                                      JOIN gnrc.ADDRESS_DIM ad ON AD.ADDRESS_KEY = T2.ADDRESS_KEY
                                                                      join GNRC.CUSTOMER_DIM CDD
                                                                           on CDD.PRIMARY_ADDRESS_KEY =
                                                                              Ad.ADDRESS_KEY AND
                                                                              CDD.PRIMARY_VISITOR_KEY = T2.VISITOR_KEY

                                                             where AD.ADDRESS_LINE1_TX is null);

--
-- MERGE INTO GNRC_DS_ACE_OUTPUT_TBL_ARCH_GNRC_1786 tgt
--     USING (SELECT * FROM GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 WHERE FILE_NM = 'v_sync_phone') src
--     ON (tgt.UNIQUE_SEQ_NO = src.UNIQUE_SEQ_NO)
--   WHEN MATCHED THEN
--     UPDATE SET tgt.CITY_NM = src.CITY_NM,
--                tgt.STATE_CD = src.STATE_CD
--   WHERE tgt.CITY_NM IS not NULL  OR tgt.STATE_CD IS NOT NULL;


select
        cd.CUSTOMER_KEY,
        T1.VISITOR_KEY,
        T1.ADDRESS_KEY,T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
        t1.PRIMARY_IND,t2.PRIMARY_IND,
        t1.END_DT_KEY,t2.END_DT_KEY,
        T2.CREATION_DT,T2.INSERT_AUDIT_KEY,
        t1.SYNC_AUDIT_KEY,t1.UPDATE_AUDIT_KEY,
        t2.SYNC_AUDIT_KEY,ATT.CREATION_DT
     from (
                 select * from p_visitor_address_xref T0 where
                 VISITOR_KEY in
                 (
                         select cvdx.VISITOR_KEY
                         from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                         join p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                         join gnrc.CUSTOMER_DIM cd on cd.PRIMARY_VISITOR_KEY = cvdx.VISITOR_KEY
                         group by cvdx.VISITOR_KEY, cd.CUSTOMER_KEY
                         having COUNT(*) > 2
                 )
         ) T1
         join gnrstg_p_visitor_address_xref_gnc_1786 T2
         join gnrc.CUSTOMER_DIM cd on cd.PRIMARY_ADDRESS_KEY = t2.ADDRESS_KEY and cd.PRIMARY_VISITOR_KEY = t2.VISITOR_KEY

     on T2.VISITOR_KEY = t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
         AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
         join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
     where t1.ADDRESS_KEY <> t2.ADDRESS_KEY


;




select CUSTOMER_KEY,COUNT(*) from GNRC_CUSTOMER_DIM_GNRC_1786
GROUP BY  CUSTOMER_KEY
Having COUNT(*) > 1
;

-- Here customer PRIMARY_ADDRESS_KEY update for wrong accounts
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC_1786', p_table_nm => 'GNRC_CUSTOMER_DIM_GNRC_1786');

BEGIN

        merge into   GNRC_CUSTOMER_DIM_GNRC_1786 tgt
                using (

                    select distinct CUSTOMER_KEY,ADDRESS_KEY from (
                        select DISTINCT
                                cd.CUSTOMER_KEY,
                                T1.VISITOR_KEY,
                                T1.ADDRESS_KEY,T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                                --t1.PRIMARY_IND,t2.PRIMARY_IND,
                                --t1.END_DT_KEY,t2.END_DT_KEY,
                                T2.CREATION_DT,
                                T2.INSERT_AUDIT_KEY,
                                t1.SYNC_AUDIT_KEY,
                                t1.UPDATE_AUDIT_KEY,
                                t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY
                                --,ATT.CREATION_DT
                             from (
                                         select * from p_visitor_address_xref T0 where
                                         VISITOR_KEY in
                                         (
                                             select vd2.VISITOR_KEY from gnrc.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                 select vd2.CUSTOMER_KEY
                                                     --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                    from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                                                          join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                    --       join gnrc.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                    group by vd2.CUSTOMER_KEY
                                                    --  having COUNT(cvdx.address_key) <= 2 --509
                                                    having COUNT(cvdx.address_key) = 2 --57
                                                    --order by DBMS_RANDOM.RANDOM()

--
                                         )
                                        )
                                 ) T1
                                 join gnrstg_p_visitor_address_xref_gnc_1786 T2 on T2.VISITOR_KEY = t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                 AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                                 join gnrc.CUSTOMER_DIM cd on cd.PRIMARY_ADDRESS_KEY = t2.ADDRESS_KEY and cd.PRIMARY_VISITOR_KEY = t2.VISITOR_KEY
                                 join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
                             where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
                             AND CUSTOMER_KEY not in (1790432,
                                                        4269378,
                                                        2105602,
                                                        3067620,
                                                        2265018
                                                        ))

            ) src  on  (tgt.CUSTOMER_KEY = src.CUSTOMER_KEY  )
         WHEN MATCHED THEN
                UPDATE SET
                           tgt.PRIMARY_ADDRESS_KEY = src.ADDRESS_KEY,tgt.SYNC_AUDIT_KEY = NULL,tgt.UPDATE_AUDIT_KEY = v_audit_key
        ;


       COMMIT;

END;



select COUNT(distinct CUSTOMER_KEY) from (
     select distinct CUSTOMER_KEY,ADDRESS_KEY from (
                        select DISTINCT
                                cd.CUSTOMER_KEY,
                                T1.VISITOR_KEY,
                                T1.ADDRESS_KEY,T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                                --t1.PRIMARY_IND,t2.PRIMARY_IND,
                                --t1.END_DT_KEY,t2.END_DT_KEY,
                                T2.CREATION_DT,
                                T2.INSERT_AUDIT_KEY,
                                t1.SYNC_AUDIT_KEY,
                                t1.UPDATE_AUDIT_KEY,
                                t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY
                                --,ATT.CREATION_DT
                             from (
                                         select * from p_visitor_address_xref T0 where
                                         VISITOR_KEY in
                                         (
                                             select vd2.VISITOR_KEY from gnrc.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                 select vd2.CUSTOMER_KEY
                                                     --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                    from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                                                          join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                    --       join gnrc.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                    group by vd2.CUSTOMER_KEY
                                                    --  having COUNT(cvdx.address_key) <= 2 --509
                                                    having COUNT(cvdx.address_key) = 2 --57
                                                    --order by DBMS_RANDOM.RANDOM()

--
                                         )
                                        )
                                 ) T1
                                 join gnrstg_p_visitor_address_xref_gnc_1786 T2 on T2.VISITOR_KEY = t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                 AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                                 join gnrc.CUSTOMER_DIM cd on cd.PRIMARY_ADDRESS_KEY = t2.ADDRESS_KEY and cd.PRIMARY_VISITOR_KEY = t2.VISITOR_KEY
                                 join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
                             where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
                             AND CUSTOMER_KEY not in (1790432,
                                                        4269378,
                                                        2105602,
                                                        3067620,
                                                        2265018
                                                        ))
              ) T
Where T.CUSTOMER_KEY   in (
    select cd.CUSTOMER_KEY from GNRC_CUSTOMER_DIM_GNRC_1786_BACKUP cd
    )
;--508

select VISITOR_KEY,ADDRESS_KEY,COUNT(*) from GNRC_VISITOR_ADDRESS_XREF_GNRC_1786_BACKUP
group by VISITOR_KEY,ADDRESS_KEY
having COUNT(*) > 1
;--578

select COUNT(*) from (
    select cvdx.VISITOR_KEY
     from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
     join p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
     join gnrc.CUSTOMER_DIM cd on cd.PRIMARY_VISITOR_KEY = cvdx.VISITOR_KEY
     group by cvdx.VISITOR_KEY, cd.CUSTOMER_KEY
     having COUNT(*) = 2
) T--510
;

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'PRIMARY_IND = N', p_process_nm => 'GNRC_1786', p_table_nm => 'GNRC_VISITOR_ADDRESS_XREF_GNRC_1786');

BEGIN


        merge into   GNRC_VISITOR_ADDRESS_XREF_GNRC_1786 tgt
                using (
                        Select distinct T1.VISITOR_KEY,
                               T1.ADDRESS_KEY,
                               T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                               --t1.PRIMARY_IND,
                               --t2.PRIMARY_IND,
                               t1.EFF_DT_KEY AS t1_EFF_DT_KEY,
                               t1.END_DT_KEY AS T1_END_DT_KEY,
                               t2.EFF_DT_KEY,
                               t2.END_DT_KEY,
                               --T2.CREATION_DT,
                               --T2.INSERT_AUDIT_KEY,
                               t1.SYNC_AUDIT_KEY,
                               t1.UPDATE_AUDIT_KEY,
                               t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY,
                               ATT.CREATION_DT
                    from (
                            select * from p_visitor_address_xref T0 where
                            VISITOR_KEY in
                            (
                             select vd2.VISITOR_KEY from gnrc.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                 select vd2.CUSTOMER_KEY
                                                     --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                    from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                                                          join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                    --       join gnrc.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                    group by vd2.CUSTOMER_KEY
                                                    --  having COUNT(cvdx.address_key) <= 2 --509
                                                    having COUNT(cvdx.address_key) = 2 --57
                                                    --order by DBMS_RANDOM.RANDOM()

--
                                         )
                                )
                         ) T1
                        join gnrstg_p_visitor_address_xref_gnc_1786 T2 on T2.VISITOR_KEY =  t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                                                            AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                        join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
                        where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
            ) src  on  (tgt.VISITOR_KEY = src.VISITOR_KEY and tgt.ADDRESS_KEY = src.T2_ADDRESS_KEY)
         WHEN MATCHED THEN
                UPDATE SET
                           tgt.PRIMARY_IND = 'X',tgt.END_DT_KEY = src.T1_END_DT_KEY,tgt.SYNC_AUDIT_KEY = NULL,tgt.UPDATE_AUDIT_KEY = v_audit_key
        WHERE tgt.PRIMARY_IND = 'Y';


       COMMIT;

END;



select count(distinct   VISITOR_KEY ||  T2_ADDRESS_KEY ) from (
Select distinct T1.VISITOR_KEY,
                               T1.ADDRESS_KEY,
                               T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                               --t1.PRIMARY_IND,
                               --t2.PRIMARY_IND,
                               t1.EFF_DT_KEY AS t1_EFF_DT_KEY,
                               t1.END_DT_KEY AS T1_END_DT_KEY,
                               t2.EFF_DT_KEY,
                               t2.END_DT_KEY,
                               --T2.CREATION_DT,
                               --T2.INSERT_AUDIT_KEY,
                               t1.SYNC_AUDIT_KEY,
                               t1.UPDATE_AUDIT_KEY,
                               t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY,
                               ATT.CREATION_DT
                    from (
                            select * from GNRC.visitor_address_xref T0 where
                            VISITOR_KEY in
                            (
                             select vd2.VISITOR_KEY from gnrc.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                 select vd2.CUSTOMER_KEY
                                                     --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                    from GNRCSTG.gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                                                          join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                    --       join gnrc.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                    group by vd2.CUSTOMER_KEY
                                                    --  having COUNT(cvdx.address_key) <= 2 --509
                                                    having COUNT(cvdx.address_key) = 2 --57
                                                    --order by DBMS_RANDOM.RANDOM()

--
                                         )
                                )
                         ) T1
                        join GNRCSTG.gnrstg_p_visitor_address_xref_gnc_1786 T2 on T2.VISITOR_KEY =  t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                                                            AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                        join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
                        where t1.ADDRESS_KEY <> t2.ADDRESS_KEY) T
Where VISITOR_KEY || ADDRESS_KEY  in (
    select TIN.VISITOR_KEY || TIN.ADDRESS_KEY from GNRC_VISITOR_ADDRESS_XREF_GNRC_1786 TIN
    )
;--508





DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'PRIMARY_IND = Y', p_process_nm => 'GNRC_1786', p_table_nm => 'GNRC_VISITOR_ADDRESS_XREF_GNRC_1786');

BEGIN


        merge into   GNRC_VISITOR_ADDRESS_XREF_GNRC_1786 tgt
                using (
                           Select distinct T1.VISITOR_KEY,
                               T1.ADDRESS_KEY,
                               T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                               --t1.PRIMARY_IND,
                               --t2.PRIMARY_IND,
                               t1.EFF_DT_KEY AS t1_EFF_DT_KEY,
                               t1.END_DT_KEY AS T1_END_DT_KEY,
                               t2.EFF_DT_KEY,
                               t2.END_DT_KEY,
                               --T2.CREATION_DT,
                               --T2.INSERT_AUDIT_KEY,
                               t1.SYNC_AUDIT_KEY,
                               t1.UPDATE_AUDIT_KEY,
                               t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY,
                               ATT.CREATION_DT
                    from (
                            select * from p_visitor_address_xref T0 where
                            VISITOR_KEY in
                            (
                             select vd2.VISITOR_KEY from gnrc.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                 select vd2.CUSTOMER_KEY
                                                     --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                    from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                                                          join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                    --       join gnrc.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                          join gnrc.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                    group by vd2.CUSTOMER_KEY
                                                    --  having COUNT(cvdx.address_key) <= 2 --509
                                                    having COUNT(cvdx.address_key) = 2 --57
                                                    --order by DBMS_RANDOM.RANDOM()

--
                                         )
                                )
                         ) T1
                        join gnrstg_p_visitor_address_xref_gnc_1786 T2 on T2.VISITOR_KEY =  t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                                                            AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                        join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
                        where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
            ) src  on  (tgt.VISITOR_KEY = src.VISITOR_KEY and tgt.ADDRESS_KEY = src.ADDRESS_KEY)
         WHEN MATCHED THEN
                UPDATE SET
                           tgt.PRIMARY_IND = 'Y',tgt.END_DT_KEY = src.END_DT_KEY,tgt.SYNC_AUDIT_KEY = NULL,tgt.UPDATE_AUDIT_KEY = v_audit_key
        WHERE tgt.PRIMARY_IND = 'N';


       COMMIT;

END;

    grant select on gnrstg_p_visitor_address_xref_gnc_1786 to gnrc;


select VAX.VISITOR_KEY,VAX.ADDRESS_KEY,VAX.PRIMARY_IND,cd.CUSTOMER_KEY,cd.PRIMARY_ADDRESS_KEY,AD.ADDRESS_KEY,ad.FIRST_NM,ad.ADDRESS_LINE1_TX
,ad1.FIRST_NM,ad1.ADDRESS_LINE1_TX  from GNRC.VISITOR_ADDRESS_XREF VAX
        join GNRC.CUSTOMER_DIM CD on CD.PRIMARY_VISITOR_KEY = VAX.VISITOR_KEY AND VAX.PRIMARY_IND = 'Y'
        join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = vax.ADDRESS_KEY and vax.PRIMARY_IND = 'Y'
        join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
where vax.VISITOR_KEY in (
    select T2.VISITOR_KEY from gnrstg_p_visitor_address_xref_gnc_1786 T2
    )
and AD.ADDRESS_LINE1_TX IS NULL;--52


select VAX.VISITOR_KEY,VAX.ADDRESS_KEY,VAX.PRIMARY_IND,cd.CUSTOMER_KEY,cd.PRIMARY_ADDRESS_KEY,AD.ADDRESS_KEY,ad.FIRST_NM,ad.ADDRESS_LINE1_TX
,ad1.FIRST_NM,ad1.ADDRESS_LINE1_TX  from GNRC_VISITOR_ADDRESS_XREF_GNRC_1786 VAX
        join GNRC_CUSTOMER_DIM_GNRC_1786 CD on CD.PRIMARY_VISITOR_KEY = VAX.VISITOR_KEY AND VAX.PRIMARY_IND = 'Y'
        join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = vax.ADDRESS_KEY and vax.PRIMARY_IND = 'Y'
        join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cd.PRIMARY_ADDRESS_KEY
where vax.VISITOR_KEY in (
    select T2.VISITOR_KEY from gnrstg_p_visitor_address_xref_gnc_1786 T2
    )
--and cd.PRIMARY_ADDRESS_KEY = AD.ADDRESS_KEY --
--and cd.PRIMARY_ADDRESS_KEY <> AD.ADDRESS_KEY --1
;
-- +------------+-------------------+-----------+--------+----------------+
-- |CUSTOMER_KEY|PRIMARY_ADDRESS_KEY|ADDRESS_KEY|FIRST_NM|ADDRESS_LINE1_TX|
-- +------------+-------------------+-----------+--------+----------------+
-- |1735368     |3659116            |9410618    |NULL    |NULL            |
-- +------------+-------------------+-----------+--------+----------------+



select T1.*,T2.PROCESS_NM,T2.PROGRAM_NM
from GNRC_VISITOR_ADDRESS_XREF_GNRC_1786 T1 join AUDIT_TBL T2
on T1.UPDATE_AUDIT_KEY = T2.AUDIT_KEY
where T1.PRIMARY_IND = 'Y';



select T1.PRIMARY_IND,T1.UPDATE_AUDIT_KEY,COUNT(*)
from GNRC_VISITOR_ADDRESS_XREF_GNRC_1786 T1
GROUP BY T1.PRIMARY_IND,T1.UPDATE_AUDIT_KEY;