DECLARE
             v_audit_key INTEGER := get_audit_key ( p_program_nm => 'PRIMARY_IND = N To Y', p_process_nm => 'GNRC_1786', p_table_nm => 'VISITOR_ADDRESS_XREF');

      BEGIN


              merge into   GNRC.VISITOR_ADDRESS_XREF tgt
                      using (
                              Select distinct T1.VISITOR_KEY,
                                     T1.ADDRESS_KEY,
                                     T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                                     --t1.PRIMARY_IND,
                                     --t2.PRIMARY_IND,
                                     t1.EFF_DT_KEY AS t1_EFF_DT_KEY,
                                     t1.END_DT_KEY AS T1_END_DT_KEY,
                                     t2.EFF_DT_KEY,
                                     t2.END_DT_KEY,
                                     --T2.CREATION_DT,
                                     --T2.INSERT_AUDIT_KEY,
                                     t1.SYNC_AUDIT_KEY,
                                     t1.UPDATE_AUDIT_KEY,
                                     t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY,
                                     ATT.CREATION_DT
                          from (
                                  select * from GNRC.visitor_address_xref T0 where
                                  VISITOR_KEY in
                                  (
                                   select vd2.VISITOR_KEY from gnrc.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                       select vd2.CUSTOMER_KEY
                                                           --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                          from GNRCSTG.gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                                                                join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                          --       join gnrc.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                                join gnrc.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                                join gnrc.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                          group by vd2.CUSTOMER_KEY
                                                          having COUNT(cvdx.address_key) > 2 --57

      --
                                               )
                                      )
                               ) T1
                              join GNRCSTG.gnrstg_p_visitor_address_xref_gnc_1786 T2 on T2.VISITOR_KEY =  t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                                                                  AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                              join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
                              where t1.ADDRESS_KEY <> t2.ADDRESS_KEY and t2.ADDRESS_KEY not in (9434684,9418320,9450712,9410662,9451118)
                  ) src  on  (tgt.VISITOR_KEY = src.VISITOR_KEY and tgt.ADDRESS_KEY = src.ADDRESS_KEY)
               WHEN MATCHED THEN
                      UPDATE SET
                                 tgt.PRIMARY_IND = 'Y',tgt.END_DT_KEY = src.END_DT_KEY,tgt.SYNC_AUDIT_KEY = NULL,tgt.UPDATE_AUDIT_KEY = v_audit_key
              WHERE tgt.PRIMARY_IND = 'N';


              DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT);
              DBMS_OUTPUT.PUT_LINE(v_audit_key);

            --

      END;
-- [2025-05-27 17:46:18] completed in 740 ms
-- 508
-- 1079407
COMMIT;