
select * from VISITOR_ADDRESS_XREF where (VISITOR_KEY,ADDRESS_KEY) in
(
select VISITOR_KEY ,T2_ADDRESS_KEY  from (
    Select distinct T1.VISITOR_KEY,
                                           T1.ADDRESS_KEY,
                                           T2.ADDRESS_KEY AS T2_ADDRESS_KEY,
                                           --t1.PRIMARY_IND,
                                           --t2.PRIMARY_IND,
                                           t1.EFF_DT_KEY AS t1_EFF_DT_KEY,
                                           t1.END_DT_KEY AS T1_END_DT_KEY,
                                           t2.EFF_DT_KEY,
                                           t2.END_DT_KEY,
                                           --T2.CREATION_DT,
                                           --T2.INSERT_AUDIT_KEY,
                                           t1.SYNC_AUDIT_KEY,
                                           t1.UPDATE_AUDIT_KEY,
                                           t2.SYNC_AUDIT_KEY AS t2_SYNC_AUDIT_KEY,
                                           ATT.CREATION_DT
                                from (
                                        select * from GNRC.visitor_address_xref T0 where
                                        VISITOR_KEY in
                                        (
                                         select vd2.VISITOR_KEY from gnrc.VISITOR_DIM vd2 where vd2.CUSTOMER_KEY in (
                                                             select vd2.CUSTOMER_KEY
                                                                 --vd2.CUSTOMER_KEY, count(cvdx.address_key), count(distinct cvdx.VISITOR_KEY)
                                                                from GNRCSTG.gnrstg_p_visitor_address_xref_gnc_1786_from30th_april gvdx
                                                                      join gnrc.VISITOR_DIM vd on vd.VISITOR_KEY = gvdx.visitor_key
                                                                --       join gnrc.CUSTOMER_DIM cd on cd.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                                      join gnrc.VISITOR_DIM vd2 on vd2.CUSTOMER_KEY = vd.CUSTOMER_KEY
                                                                      join gnrc.visitor_address_xref cvdx on cvdx.VISITOR_KEY = vd2.VISITOR_KEY
                                                                group by vd2.CUSTOMER_KEY
                                                               -- having COUNT(cvdx.address_key) > 2 --57

            --
                                                     )
                                            )
                                     ) T1
                                    join GNRCSTG.gnrstg_p_visitor_address_xref_gnc_1786_from30th_april T2 on T2.VISITOR_KEY =  t1.VISITOR_KEY AND T2.SYNC_AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                                                                        AND t1.UPDATE_AUDIT_KEY = t2.SYNC_AUDIT_KEY
                                    join AUDIT_TBL ATT on Att.AUDIT_KEY = T1.SYNC_AUDIT_KEY
                                    where t1.ADDRESS_KEY <> t2.ADDRESS_KEY
              )T group by VISITOR_KEY ,T2_ADDRESS_KEY
having COUNT(*) >1

    )           ;
-- VISITOR_KEY,ADDRESS_KEY,ROLE_KEY,EFF_DT_KEY,END_DT_KEY,PRIMARY_IND,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY,SYNC_AUDIT_KEY
-- 931225,9450712,3,12923,99999,Y,1078305,,1078323
-- 1031040,9410662,3,12916,99999,Y,1077222,,1077241
-- 1172090,9434684,3,12917,99999,Y,1077356,,1077372
-- 2168738,9451118,3,12925,99999,Y,1078557,,1078576
-- 1556173,9418320,3,12917,99999,Y,1077356,,1077372

select vx.ADDRESS_KEY,ad1.ADDRESS_LINE1_TX,att.CREATION_DT from VISITOR_ADDRESS_XREF vx
         join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = vx.ADDRESS_KEY
     join AUDIT_TBL ATT on Att.AUDIT_KEY = AD1.SYNC_AUDIT_KEY
         where VISITOR_KEY  =1556173;
-- ADDRESS_KEY,ADDRESS_LINE1_TX,CREATION_DT
-- 6463280,1065 PONTI RD,2025-05-14 03:52:36.000000
-- 7756776,1065 PONTI RD,2025-05-14 03:52:36.000000
-- 8676258,3200 DANVILLE BLVD,2025-05-14 03:52:36.000000
-- 9418320,,2025-05-14 03:52:36.000000
select * from VISITOR_ADDRESS_XREF vx  where VISITOR_KEY  =1556173;

DECLARE
                   v_audit_key INTEGER := get_audit_key ( p_program_nm => 'PRIMARY_IND = Y To X', p_process_nm => 'GNRC_1786', p_table_nm => 'VISITOR_ADDRESS_XREF');

BEGIN
        update VISITOR_ADDRESS_XREF
            SET  SYNC_AUDIT_KEY = NULL, UPDATE_AUDIT_KEY = v_audit_key
        where VISITOR_KEY  =1556173 and PRIMARY_IND in ('Y','X');
        COMMIT;
end;