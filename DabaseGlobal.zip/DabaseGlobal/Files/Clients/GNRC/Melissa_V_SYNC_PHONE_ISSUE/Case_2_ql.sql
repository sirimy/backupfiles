
-- CREATE TABLE GNRC_ADDRESS_OUTPUT_TBL_ARCH_GNRC_1786
--   AS (SELECT * FROM GNRC.ADDRESS_OUTPUT_TBL_ARCH  where PROCESS_DT = '20250520');


select * from GNRC_ADDRESS_OUTPUT_TBL_ARCH_GNRC_1786;
select * from GNRC_DS_ACE_OUTPUT_TBL_ARCH_GNRC_1786;
select * from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786;

select T2.PHONE_NO,T1.CITY_NM,T2.CITY_NM,T1.STATE_CD,T2.STATE_CD from GNRC_DS_ACE_OUTPUT_TBL_ARCH_GNRC_1786 T1
        JOIN GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 ON T1.UNIQUE_SEQ_NO = T2.UNIQUE_SEQ_NO
where T2.FILE_NM = 'v_sync_phone'
  --AND ( T1.CITY_NM IS not NULL  OR T1.STATE_CD IS NOT NULL)
;


MERGE INTO GNRC_DS_ACE_OUTPUT_TBL_ARCH_GNRC_1786 tgt
    USING (SELECT * FROM GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 WHERE FILE_NM = 'v_sync_phone') src
    ON (tgt.UNIQUE_SEQ_NO = src.UNIQUE_SEQ_NO)
  WHEN MATCHED THEN
    UPDATE SET tgt.CITY_NM = src.CITY_NM,
               tgt.STATE_CD = src.STATE_CD
  WHERE tgt.CITY_NM IS not NULL  OR tgt.STATE_CD IS NOT NULL;


select COUNT(*) from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM = 'v_sync_phone';--114
select distinct CITY_NM,STATE_CD from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM = 'v_sync_phone';--114

select ADDRESS_KEY,COUNT(*) from GNRC_ADDRESS_OUTPUT_TBL_ARCH_GNRC_1786 T1
        JOIN GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 ON T1.UNIQUE_SEQ_NO = T2.UNIQUE_SEQ_NO
where T2.FILE_NM = 'v_sync_phone'
group by ADDRESS_KEY;



select COUNT(*) from GNRC.DS_ACE_OUTPUT_TBL_ARCH  where PROCESS_DT = '20250520';--228
select COUNT(*) from GNRC.COMMON_LOAD_TBL_ARCH  where PROCESS_DT = '20250520';--228
select COUNT(*) from GNRC.ADDRESS_OUTPUT_TBL_ARCH  where PROCESS_DT = '20250520';--228

select COUNT(*),COUNT(distinct PHONE_NO ) from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM = 'v_sync_phone';--114
-- +--------+-----------------------+
-- |COUNT(*)|COUNT(DISTINCTPHONE_NO)|
-- +--------+-----------------------+
-- |114     |112                    |
-- +--------+-----------------------+

select T2.FILE_NM,COUNT(*),COUNT(distinct PHONE_NO ),COUNT(distinct ADDRESS_LINE1_TX ),COUNT(distinct EMAIL_ADDRESS_TX ) from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 group by T2.FILE_NM  ;
-- +--------------+--------+-----------------------+-------------------------------+-------------------------------+
-- |FILE_NM       |COUNT(*)|COUNT(DISTINCTPHONE_NO)|COUNT(DISTINCTADDRESS_LINE1_TX)|COUNT(DISTINCTEMAIL_ADDRESS_TX)|
-- +--------------+--------+-----------------------+-------------------------------+-------------------------------+
-- |v_sync_address|50      |0                      |32                             |0                              |
-- |v_sync_email  |64      |0                      |0                              |56                             |
-- |v_sync_phone  |114     |112                    |0                              |0                              |
-- +--------------+--------+-----------------------+-------------------------------+-------------------------------+




select distinct FILE_NM from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM <> 'v_sync_phone' and VISITOR_XID in (
    select VISITOR_XID from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM = 'v_sync_phone');--114


select * from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM = 'v_sync_phone' and VISITOR_XID not in (
    select VISITOR_XID from GNRC_COMMON_LOAD_TBL_ARCH_GNRC_1786 T2 where T2.FILE_NM <> 'v_sync_phone');--114

select COUNT(*) from GNRC.COMMON_LOAD_TBL_ARCH CL where PROCESS_DT = '20250523' and FILE_NM = 'v_sync_phone';--161

select ADDRESS_KEY,COUNT(*),Cl.FILE_NM,CL.CITY_NM,CL.STATE_CD,CL.ADDRESS_LINE1_TX,DSACE.CITY_NM,DSACE.STATE_CD
     ,AOT.FIRST_NM,AOT.LAST_NM,AOT.CITY_NM,AOT.STATE_CD from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                where DSACE.PROCESS_DT = '20250523' AND DSACE.ADDRESS_LINE1_TX IS NULL
GROUP BY ADDRESS_KEY,AOT.FIRST_NM,AOT.LAST_NM,Cl.FILE_NM,CL.CITY_NM,CL.STATE_CD,CL.ADDRESS_LINE1_TX,DSACE.CITY_NM,DSACE.STATE_CD,AOT.CITY_NM,AOT.STATE_CD
;--
-- +-----------+------------+-------+--------+----------------+-------+--------+---------+--------+--------+
-- |ADDRESS_KEY|FILE_NM     |CITY_NM|STATE_CD|ADDRESS_LINE1_TX|CITY_NM|STATE_CD|CITY_NM  |STATE_CD|COUNT(*)|
-- +-----------+------------+-------+--------+----------------+-------+--------+---------+--------+--------+
-- |1455202    |v_sync_phone|NULL   |NULL    |NULL            |NULL   |NULL    |NULL     |NULL    |161     |-- All v_sync_phone records got same ADDRESS_KEY

-- |4946278    |v_sync_phone|NULL   |NULL    |NULL            |NULL   |NULL    |LEXINGTON|TN      |1       |
-- |6241104    |v_sync_phone|NULL   |NULL    |NULL            |NULL   |NULL    |ELLSWORTH|ME      |1       |
-- |8092572    |v_sync_phone|NULL   |NULL    |NULL            |NULL   |NULL    |KATY     |TX      |1       |
-- +-----------+------------+-------+--------+----------------+-------+--------+---------+--------+--------+



select distinct SOURCE_TABLE_NAME from GNRC.SYNC_PROCESS_MAPPING_TBL where TARGET_SYSTEM_NAME = 'GNRCSTG' and TARGET_TABLE_NAME
in ('COMMON_LOAD_ADDRESS_TBL','COMMON_LOAD_EMAIL_TBL','COMMON_LOAD_PHONE_TBL');
-- +-----------------+
-- |SOURCE_TABLE_NAME|
-- +-----------------+
-- |V_SYNC_ADDRESS   |
-- |V_SYNC_EMAIL     |
-- |V_SYNC_PHONE     |
-- +-----------------+

select * from GNRC.VISITOR_LKP where VISITOR_XID = '1724218';
-- +-----------+-----------+----------------+
-- |VISITOR_KEY|VISITOR_XID|SOURCE_SYSTEM_CD|
-- +-----------+-----------+----------------+
-- |899744     |1724218    |2               |
-- +-----------+-----------+----------------+

select * from v_visitor_address where VISITOR_KEY = 899744;
-- +-----------+-----------+
-- |VISITOR_KEY|ADDRESS_KEY|
-- +-----------+-----------+
-- |899744     |9450708    |
-- +-----------+-----------+

select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in(9450708,3633948);

select * from (
SELECT visitor_key, address_key
     FROM visitor_address_xref
    WHERE primary_ind = 'Y'
   UNION ALL
   SELECT visitor_key, address_key
     FROM p_visitor_address_xref t1
) where VISITOR_KEY = 899744;
-- +-----------+-----------+
-- |VISITOR_KEY|ADDRESS_KEY|
-- +-----------+-----------+
-- |899744     |3633948    |
-- |899744     |9450708    |
-- +-----------+-----------+
--     WHERE     primary_ind = 'Y'
--           AND NOT EXISTS
--                  (SELECT 1
--                     FROM visitor_address_xref t2
--                    WHERE t1.visitor_key = t2.visitor_key);

-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX|ADDRESS_LINE2_TX|CITY_NM|STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |3633948    |NULL   |NULL     |JAMES   |NULL     |TIMLER |201293 DUBAY DR |NULL            |MOSINEE|WI      |54455       |7507        |N             |S08000      |NULL    |A            |NULL                 |NULL       |11106     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |DUBAY            |201293           |NULL   |NULL     |NULL       |NULL     |Y            |545937          |1053832         |NULL |NULL    |NULL    |93                   |6           |R010            |0281A         |USA       |NULL     |NULL               |NULL           |NULL                   |1053832       |
-- |9450708    |NULL   |NULL     |NULL    |NULL     |NULL   |NULL            |NULL            |WAUSAU |WI      |NULL        |NULL        |N             |NULL        |NULL    |A            |NULL                 |NULL       |12923     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |NULL             |NULL             |NULL   |NULL     |NULL       |NULL     |NULL         |1078305         |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |1078322       |
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+-------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+


select ADDRESS_KEY,Cl.FILE_NM,CL.CITY_NM,CL.STATE_CD,CL.ADDRESS_LINE1_TX,DSACE.CITY_NM,DSACE.STATE_CD
     ,AOT.CITY_NM,AOT.STATE_CD,COUNT(*) from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                where DSACE.PROCESS_DT = '20250520' AND DSACE.ADDRESS_LINE1_TX IS NULL
GROUP BY ADDRESS_KEY,Cl.FILE_NM,CL.CITY_NM,CL.STATE_CD,CL.ADDRESS_LINE1_TX,DSACE.CITY_NM,DSACE.STATE_CD,AOT.CITY_NM,AOT.STATE_CD
;--

select distinct cl.VISITOR_XID,AOT.ADDRESS_KEY,VL.VISITOR_XID,VL.VISITOR_KEY,sd.SERIAL_NO,pvdx.VISITOR_KEY,pvdx.END_DT_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,AD.FIRST_NM,AD.LAST_NM,AD.ADDRESS_LINE1_TX
from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                    join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                    join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VL.VISITOR_KEY
                    join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = pvdx.ADDRESS_KEY
                    join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY
                    join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                    join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                where DSACE.PROCESS_DT = '20250520' AND DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NULL AND DSACE.CITY_NM IS NULL
                AND pvdx.PRIMARY_IND = 'Y' AND AD.FIRST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
                AND ATT.CREATION_DT >= date '2025-05-01'
ORDER BY pvdx.VISITOR_KEY
--GROUP BY ADDRESS_KEY,Cl.FILE_NM,CL.CITY_NM,CL.STATE_CD,CL.ADDRESS_LINE1_TX,DSACE.CITY_NM,DSACE.STATE_CD,AOT.CITY_NM,AOT.STATE_CD
;--


select COUNT( distinct AD.ADDRESS_KEY ) from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                    join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                    join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VL.VISITOR_KEY
                    join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = pvdx.ADDRESS_KEY
                    join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY
                    join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                    join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                    join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                where --DSACE.PROCESS_DT = '20250520' AND
                      DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
                      AND pvdx.PRIMARY_IND = 'Y' AND AD.FIRST_NM IS NULL AND AD.LAST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
                      AND ATT.CREATION_DT >= date '2025-05-01'
                      AND ATT2.CREATION_DT >= date '2025-05-01'
;--395


select  COUNT(distinct AD.ADDRESS_KEY )
from GNRC.VISITOR_OWNERSHIP_XREF VOX
            join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join gnrc.VISITOR_DIM VD on VD.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
where VOX.PRIMARY_IND = 'Y' AND AD.FIRST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
      AND ATT.CREATION_DT >= date '2025-05-01'
ORDER BY DBMS_RANDOM.RANDOM()
;--405




select  distinct VOX.VISITOR_KEY
from GNRC.VISITOR_OWNERSHIP_XREF VOX
            join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join gnrc.VISITOR_DIM VD on VD.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
where VOX.PRIMARY_IND = 'Y' AND AD.FIRST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
      AND ATT.CREATION_DT >= date '2025-05-01'

;--405



select pvdx.VISITOR_KEY,COUNT(*) from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                    join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                    join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VL.VISITOR_KEY
                where DSACE.PROCESS_DT = '20250520' AND DSACE.ADDRESS_LINE1_TX IS NULL
GROUP BY pvdx.VISITOR_KEY
HAVING COUNT(*) >2
ORDER BY pvdx.VISITOR_KEY
;--

select  distinct VOX.VISITOR_KEY
from GNRC.VISITOR_OWNERSHIP_XREF VOX
            join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join gnrc.VISITOR_DIM VD on VD.VISITOR_KEY = vox.VISITOR_KEY
            join gnrc.CUSTOMER_DIM CD on CD.CUSTOMER_KEY = VD.CUSTOMER_KEY
            join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
where VOX.PRIMARY_IND = 'Y' AND AD.FIRST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
      AND ATT.CREATION_DT >= date '2025-05-01'
      AND VOX.VISITOR_KEY not in (
        select pvdx.VISITOR_KEY from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                    join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                    join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VL.VISITOR_KEY
                    join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = pvdx.ADDRESS_KEY
                    join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY
                    join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                    join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                    join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                where --DSACE.PROCESS_DT = '20250520' AND
                      DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
                      AND pvdx.PRIMARY_IND = 'Y' AND AD.FIRST_NM IS NULL AND AD.LAST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
                      AND ATT.CREATION_DT >= date '2025-05-01'
                      AND ATT2.CREATION_DT >= date '2025-05-01'
                        );


select * from (
SELECT *
     FROM visitor_address_xref
    --WHERE primary_ind = 'Y'
   UNION ALL
   SELECT *
     FROM p_visitor_address_xref t1
) where VISITOR_KEY = 1946059;
-- +-----------+-----------+--------+----------+----------+-----------+----------------+----------------+--------------+
-- |VISITOR_KEY|ADDRESS_KEY|ROLE_KEY|EFF_DT_KEY|END_DT_KEY|PRIMARY_IND|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +-----------+-----------+--------+----------+----------+-----------+----------------+----------------+--------------+
-- |1946059    |8099758    |3       |12484     |12906     |N          |959450          |1069715         |1069715       |
-- |1946059    |9410654    |3       |12905     |99999     |Y          |1069696         |NULL            |1069715       |
-- +-----------+-----------+--------+----------+----------+-----------+----------------+----------------+--------------+

select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in(8099758,9410654);

select vox.VISITOR_KEY,sd.SERIAL_NO from GNRC.VISITOR_OWNERSHIP_XREF VOX
            JOIN GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
where VOX.VISITOR_KEY = 1946059;
-- +-----------+----------+
-- |VISITOR_KEY|SERIAL_NO |
-- +-----------+----------+
-- |1946059    |3013584489|
-- +-----------+----------+

select distinct cl.VISITOR_XID,AOT.ADDRESS_KEY,VL.VISITOR_XID,VL.VISITOR_KEY,sd.SERIAL_NO,
                DSACE.STATE_CD,DSACE.CITY_NM,CL.STATE_CD,CL.CITY_NM,
                pvdx.VISITOR_KEY,pvdx.END_DT_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,AD.FIRST_NM,AD.LAST_NM,AD.ADDRESS_LINE1_TX
    from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                            join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                            join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                            join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                            join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VL.VISITOR_KEY
                            join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = pvdx.ADDRESS_KEY
                            join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY
                            join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                            join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                        where 1=1  --DSACE.PROCESS_DT = '20250520' AND
                              --DSACE.ADDRESS_LINE1_TX IS NULL
                              -- AND DSACE.STATE_CD IS NULL
                              -- AND DSACE.CITY_NM IS NULL
                               AND AD.FIRST_NM IS NULL
                               AND AD.ADDRESS_LINE1_TX IS NULL
                              --AND pvdx.PRIMARY_IND = 'Y'
                              --AND ATT.CREATION_DT >= date '2025-05-01'
                              --AND ATT2.CREATION_DT >= date '2025-05-01'
                              AND VL.VISITOR_KEY = 1946059;


--
-- CREATE TABLE gnrstg_p_visitor_address_xref_gnc_1786
--   AS (
--     select distinct pvdx.VISITOR_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,pvdx.END_DT_KEY,pvdx.EFF_DT_KEY,pvdx.INSERT_AUDIT_KEY,ATT3.CREATION_DT,SD.SERIAL_NO from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
--                         join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
--                         join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
--                         join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
--                         join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VL.VISITOR_KEY
--                         join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = pvdx.ADDRESS_KEY
--                         join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY
--                         join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
--                         join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
--                         join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
--                         join AUDIT_TBL ATT3 on pvdx.INSERT_AUDIT_KEY = ATT3.AUDIT_KEY
--                     where --DSACE.PROCESS_DT = '20250520' AND
--                           DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
--                           AND pvdx.PRIMARY_IND = 'Y' AND AD.FIRST_NM IS NULL AND AD.LAST_NM IS NULL AND AD.ADDRESS_LINE1_TX IS NULL
--                           AND ATT.CREATION_DT >= date '2025-05-01'
--                           AND ATT2.CREATION_DT >= date '2025-05-01'
--      )
-- ;--395



CREATE TABLE gnrstg_p_visitor_address_xref_gnc_1786
  AS (
     select distinct pvdx.VISITOR_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,pvdx.END_DT_KEY,pvdx.EFF_DT_KEY,pvdx.INSERT_AUDIT_KEY,ATT3.CREATION_DT,pvdx.UPDATE_AUDIT_KEY,pvdx.SYNC_AUDIT_KEY,SD.SERIAL_NO
     from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                        join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                        join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                        join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = AOT.ADDRESS_KEY
                        join GNRC.CUSTOMER_DIM CD  on CD.PRIMARY_ADDRESS_KEY = AD.ADDRESS_KEY
                        join GNRC.VISITOR_DIM VD on VD.CUSTOMER_KEY = CD.CUSTOMER_KEY
                        --join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                        join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VD.VISITOR_KEY
                        join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY AND VOX.PRIMARY_IND = 'Y'
                        join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                        join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                        join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
                        join AUDIT_TBL ATT3 on pvdx.INSERT_AUDIT_KEY = ATT3.AUDIT_KEY
                    where --DSACE.PROCESS_DT = '20250520' AND
                          DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
                          AND pvdx.PRIMARY_IND = 'Y'
                          AND AD.ADDRESS_LINE1_TX IS NULL
                          AND ATT.CREATION_DT >= date '2025-05-01'
                          AND ATT2.CREATION_DT >= date '2025-05-01'
     )
;--z

COMMIT;

select COUNT(*) from gnrstg_p_visitor_address_xref_gnc_1786;--578

select COUNT(distinct ADDRESS_KEY) from gnrstg_p_visitor_address_xref_gnc_1786;--406

select
    INSERT_AUDIT_KEY,t1.CREATION_DT,t1.UPDATE_AUDIT_KEY,t2.CREATION_DT,t1.SYNC_AUDIT_KEY,t3.CREATION_DT,COUNT(*)
from gnrstg_p_visitor_address_xref_gnc_1786 t1
    LEFT join AUDIT_TBL t2 on NVL(t1.UPDATE_AUDIT_KEY,0) = t2.AUDIT_KEY
    LEFT join AUDIT_TBL t3 on NVL(t1.SYNC_AUDIT_KEY,0) = t3.AUDIT_KEY
group by INSERT_AUDIT_KEY,t1.CREATION_DT,t1.UPDATE_AUDIT_KEY,t1.SYNC_AUDIT_KEY,t2.CREATION_DT,t3.CREATION_DT
order by t1.CREATION_DT
;--406

select COUNT(distinct ADDRESS_KEY ) from (
select distinct pvdx.VISITOR_KEY,pvdx.ADDRESS_KEY,pvdx.PRIMARY_IND,pvdx.END_DT_KEY,pvdx.EFF_DT_KEY,pvdx.INSERT_AUDIT_KEY,ATT3.CREATION_DT,SD.SERIAL_NO from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                        join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                        join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                        join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = AOT.ADDRESS_KEY
                        join GNRC.CUSTOMER_DIM CD  on CD.PRIMARY_ADDRESS_KEY = AD.ADDRESS_KEY
                        join GNRC.VISITOR_DIM VD on VD.CUSTOMER_KEY = CD.CUSTOMER_KEY
                        --join GNRC.VISITOR_LKP VL ON VL.VISITOR_XID = CL.VISITOR_XID
                        join p_visitor_address_xref pvdx ON pvdx.VISITOR_KEY = VD.VISITOR_KEY
                        join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = pvdx.VISITOR_KEY AND VOX.PRIMARY_IND = 'Y'
                        join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
                        join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
                        join AUDIT_TBL ATT2 on CL.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
                        join AUDIT_TBL ATT3 on pvdx.INSERT_AUDIT_KEY = ATT3.AUDIT_KEY
                    where --DSACE.PROCESS_DT = '20250520' AND
                          DSACE.ADDRESS_LINE1_TX IS NULL AND DSACE.STATE_CD IS NOT NULL AND DSACE.CITY_NM IS NOT NULL
                          AND pvdx.PRIMARY_IND = 'Y'
                          AND AD.ADDRESS_LINE1_TX IS NULL
                          AND ATT.CREATION_DT >= date '2025-05-01'
                          AND ATT2.CREATION_DT >= date '2025-05-01') T

;


select COUNT(distinct VISITOR_KEY) from (
    select DISTINCT cvdx.VISITOR_KEY,gvdx.ADDRESS_KEY, cvdx.ADDRESS_KEY
           ,ATT.CREATION_DT,AD.FIRST_NM,AD.LAST_NM,AD.ADDRESS_LINE1_TX
           ,ATT2.CREATION_DT,AD1.FIRST_NM,AD1.LAST_NM,AD1.ADDRESS_LINE1_TX
        from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
            join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
            join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = gvdx.ADDRESS_KEY
            join GNRC.ADDRESS_DIM AD1 on AD1.ADDRESS_KEY = cvdx.ADDRESS_KEY
            join GNRC.VISITOR_OWNERSHIP_XREF VOX on VOX.VISITOR_KEY = gvdx.VISITOR_KEY
            join GNRC.SERIALIZED_ITEM_DIM SD on SD.SI_KEY = VOX.SI_KEY
            join AUDIT_TBL ATT on AD.INSERT_AUDIT_KEY = ATT.AUDIT_KEY
            join AUDIT_TBL ATT2 on AD1.INSERT_AUDIT_KEY = ATT2.AUDIT_KEY
        where cvdx.PRIMARY_IND = 'N'
            and cvdx.VISITOR_KEY in (
                select cvdx.VISITOR_KEY
                 from gnrstg_p_visitor_address_xref_gnc_1786 gvdx
                    join  p_visitor_address_xref cvdx on cvdx.VISITOR_KEY = gvdx.VISITOR_KEY
                 group by cvdx.VISITOR_KEY
                 having COUNT(*)=2
                )
            and AD.ADDRESS_LINE1_TX IS NULL
            and AD1.ADDRESS_LINE1_TX IS NOT NULL
    order by cvdx.VISITOR_KEY,ATT.CREATION_DT
)t
;--359


select CREATION_DT,COUNT(*),max(END_DT_KEY),min(END_DT_KEY) from gnrstg_p_visitor_address_xref_gnc_1786
group by CREATION_DT;
-- +--------------------------+--------+---------------+---------------+
-- |CREATION_DT               |COUNT(*)|MAX(END_DT_KEY)|MIN(END_DT_KEY)|
-- +--------------------------+--------+---------------+---------------+
-- |2025-05-09 02:18:21.000000|19      |99999          |99999          |
-- |2025-05-21 02:17:29.000000|29      |99999          |99999          |
-- |2025-05-06 02:18:19.000000|36      |99999          |99999          |
-- |2025-05-05 02:17:22.000000|7       |99999          |99999          |
-- |2025-05-10 02:17:25.000000|29      |99999          |99999          |
-- |2025-05-20 02:18:12.000000|22      |99999          |99999          |
-- |2025-05-04 02:18:06.000000|6       |99999          |99999          |
-- |2025-05-15 02:17:17.000000|19      |99999          |99999          |
-- |2025-05-19 02:17:07.000000|1       |99999          |99999          |
-- |2025-05-07 02:17:26.000000|28      |99999          |99999          |
-- |2025-05-11 02:17:37.000000|4       |99999          |99999          |
-- |2025-05-17 02:18:16.000000|18      |99999          |99999          |
-- |2025-05-16 02:18:14.000000|27      |99999          |99999          |
-- |2025-05-13 02:18:17.000000|23      |99999          |99999          |
-- |2025-05-12 02:17:07.000000|1       |99999          |99999          |
-- |2025-05-03 02:18:14.000000|32      |99999          |99999          |
-- |2025-05-02 03:37:50.000000|47      |99999          |99999          |
-- |2025-05-08 02:18:21.000000|25      |99999          |99999          |
-- |2025-05-22 02:18:21.000000|26      |99999          |99999          |
-- |2025-05-18 02:17:59.000000|2       |99999          |99999          |
-- |2025-05-14 02:17:29.000000|14      |99999          |99999          |
-- +--------------------------+--------+---------------+---------------+

select * from (
SELECT *
     FROM visitor_address_xref
    --WHERE primary_ind = 'Y'
   UNION ALL
   SELECT *
     FROM p_visitor_address_xref t1
) where VISITOR_KEY = 434381;

select * from GNRC.ADDRESS_DIM where ADDRESS_KEY in(1616464,9413418,9413488);
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |ADDRESS_KEY|FIRM_NM|SOURCE_CD|FIRST_NM|MIDDLE_NM|LAST_NM|ADDRESS_LINE1_TX|ADDRESS_LINE2_TX|CITY_NM  |STATE_CD|ZIP_CODE5_TX|ZIP_CODE4_TX|SUPPRESSION_CD|ACE_ERROR_CD|NIXIE_CD|DIM_STATUS_CD|CASS_CERTIFICATION_CD|LOAD_DT_KEY|EFF_DT_KEY|END_DT_KEY|COMMERCIAL_IND|DELIVERY_POINT_CD|DELIVERY_POINT_CORRECTION_CD|CARRIER_ROUTE_CD|LOT_CD|DEALER_IND|PRIMARY_STREET_NM|PRIMARY_STREET_NO|UNIT_NO|RR_BOX_NO|RR_ROUTE_NO|PO_BOX_NO|DPV_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|TITLE|MAT_POST|PRE_NAME|DELIVERY_POINT_BAR_CD|CHK_DIGIT_CD|CARRIER_ROUTE_NO|LINE_OF_TRAVEL|COUNTRY_CD|STATUS_CD|FOREIGN_ADDRESS_IND|ASSIGNMENT_TYPE|ACTUAL_ASSIGNMENT_LEVEL|SYNC_AUDIT_KEY|
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+
-- |1616464    |NULL   |NULL     |WILLIAM |NULL     |ROBERT |709 SANDPIPER LN|NULL            |OPELOUSAS|LA      |70570       |8690        |Y             |S80000      |NULL    |A            |NULL                 |NULL       |12909     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |SANDPIPER        |709              |NULL   |NULL     |NULL       |NULL     |Y            |44278           |1073272         |NULL |NULL    |NULL    |09                   |9           |C012            |0105A         |USA       |NULL     |NULL               |NULL           |NULL                   |1073272       |
-- |9413418    |NULL   |NULL     |JAMES   |NULL     |EAGLIN |709 SANDPIPER LN|NULL            |OPELOUSAS|LA      |70570       |8690        |N             |S80000      |NULL    |A            |NULL                 |NULL       |12909     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |SANDPIPER        |709              |NULL   |NULL     |NULL       |NULL     |Y            |1073254         |NULL            |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |1073272       |
-- |9413488    |NULL   |NULL     |NULL    |NULL     |NULL   |NULL            |NULL            |ROCKVILLE|MD      |NULL        |NULL        |N             |NULL        |NULL    |A            |NULL                 |NULL       |12921     |NULL      |N             |NULL             |NULL                        |NULL            |NULL  |NULL      |NULL             |NULL             |NULL   |NULL     |NULL       |NULL     |NULL         |1073255         |1078043         |NULL |NULL    |NULL    |NULL                 |NULL        |NULL            |NULL          |USA       |NULL     |NULL               |NULL           |NULL                   |1078043       |
-- +-----------+-------+---------+--------+---------+-------+----------------+----------------+---------+--------+------------+------------+--------------+------------+--------+-------------+---------------------+-----------+----------+----------+--------------+-----------------+----------------------------+----------------+------+----------+-----------------+-----------------+-------+---------+-----------+---------+-------------+----------------+----------------+-----+--------+--------+---------------------+------------+----------------+--------------+----------+---------+-------------------+---------------+-----------------------+--------------+

select * from GNRC.VISITOR_OWNERSHIP_XREF where VISITOR_KEY = 434381;
-- +-----------+-------+---------------+----------+----------+
-- |VISITOR_KEY|SI_KEY |PURCHASE_DT_KEY|EFF_DT_KEY|END_DT_KEY|
-- +-----------+-------+---------------+----------+----------+
-- |434381     |395260 |10028          |10028     |99999     |
-- |434381     |1519750|12212          |12212     |99999     |
-- +-----------+-------+---------------+----------+----------+

select * from GNRC.SERIALIZED_ITEM_DIM where SI_KEY in (395260,1519750);
-- +-------+-----------+----------+--------+---------------+--------------------------+
-- |SI_KEY |PRODUCT_KEY|SERIAL_NO |MODEL_NO|PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |
-- +-------+-----------+----------+--------+---------------+--------------------------+
-- |395260 |12804      |3001748340|G0070431|10028          |2019-06-15 00:00:00.000000|
-- |1519750|46402      |3012961004|G0072101|12212          |2025-06-07 00:00:00.000000|
-- +-------+-----------+----------+--------+---------------+--------------------------+
select * from GNRC.RAW_LEADS_TBL where EQUIPMENT like '%3001748340%' OR EQUIPMENT like '%3012961004%';
-- +--------------+------------------+----------+-----------+--------------+------------------+-------------------+------------------+---------------+--------+
-- |OWNER_NAME    |OWNER_ADDRESS1    |OWNER_CITY|OWNER_STATE|OWNER_POSTCODE|OWNER_PHONE_NUMBER|OWNER_EMAIL        |EQUIPMENT         |VALID_FROM_DATE|MATERIAL|
-- +--------------+------------------+----------+-----------+--------------+------------------+-------------------+------------------+---------------+--------+
-- |William Robert|709 sandpaper lane|Opelousas |LA         |70570         |3379427610        |Boss8309@gmail.com |000000003001748340|2017-05-15     |G0070431|
-- |WILLIAM ROBERT|709 Sandpiper Ln  |Opelousas |LA         |70570-8690    |3379427610        |NOEMAIL@generac.com|000000003012961004|2022-12-12     |G0072101|
-- |WILLIAM ROBERT|709 Sandpiper Ln  |Opelousas |LA         |70570-8690    |3379427610        |NOEMAIL@generac.com|3012961004        |2022-12-12     |G0072101|
-- +--------------+------------------+----------+-----------+--------------+------------------+-------------------+------------------+---------------+--------+

select * from gnrc.CUSTOMER_DIM where PRIMARY_VISITOR_KEY = 434381;
-- +------------+-------------+-------------------+----------------------+-------------+----------------+-------------------+----------------------+-----------------+--------------------+-----------------+--------------------+----------------+----------------+--------------+
-- |CUSTOMER_KEY|HOUSEHOLD_KEY|PRIMARY_VISITOR_KEY|DERIVED_SUPPRESSION_CD|DIM_STATUS_CD|PRIMARY_PURL_KEY|PRIMARY_ADDRESS_KEY|ADDRESS_SUPPRESSION_CD|PRIMARY_PHONE_KEY|PHONE_SUPPRESSION_CD|PRIMARY_EMAIL_KEY|EMAIL_SUPPRESSION_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +------------+-------------+-------------------+----------------------+-------------+----------------+-------------------+----------------------+-----------------+--------------------+-----------------+--------------------+----------------+----------------+--------------+
-- |782940      |389980       |434381             |N                     |N            |405537          |9413488            |N                     |2713088          |N                   |1761665          |Y                   |44278           |1073285         |1073285       |
-- +------------+-------------+-------------------+----------------------+-------------+----------------+-------------------+----------------------+-----------------+--------------------+-----------------+--------------------+----------------+----------------+--------------+

select * from GNRC.VISITOR_DIM where CUSTOMER_KEY = 782940;
-- +-----------+------------+-------------+
-- |VISITOR_KEY|CUSTOMER_KEY|HOUSEHOLD_KEY|
-- +-----------+------------+-------------+
-- |434381     |782940      |389980       |
-- +-----------+------------+-------------+


select AD.ADDRESS_KEY,AD.ADDRESS_LINE1_TX,AD.FIRST_NM,AOT.ADDRESS_KEY,CL.UNIQUE_SEQ_NO--,COUNT(*)
     ,Cl.FILE_NM,CL.CITY_NM,CL.STATE_CD,CL.ADDRESS_LINE1_TX,DSACE.CITY_NM,DSACE.STATE_CD
     ,AOT.FIRST_NM,AOT.LAST_NM,AOT.CITY_NM,AOT.STATE_CD from GNRC.DS_ACE_OUTPUT_TBL_ARCH DSACE
                    join GNRC.COMMON_LOAD_TBL_ARCH CL ON CL.UNIQUE_SEQ_NO = DSACE.UNIQUE_SEQ_NO and FILE_NM = 'v_sync_phone'
                    join GNRC.ADDRESS_OUTPUT_TBL_ARCH AOT on AOT.UNIQUE_SEQ_NO = CL.UNIQUE_SEQ_NO
                    join GNRC.VISITOR_LKP VL on VL.VISITOR_XID = CL.VISITOR_XID
                    join GNRC.VISITOR_ADDRESS_XREF VAX on VAX.VISITOR_KEY = VL.VISITOR_KEY
                    join GNRC.VISITOR_DIM VD on VD.VISITOR_KEY = VAX.VISITOR_KEY

                             join GNRC.ADDRESS_DIM AD on AD.ADDRESS_KEY = VAX.ADDRESS_KEY and VAX.PRIMARY_IND = 'Y'
                where DSACE.PROCESS_DT = '20250524' AND DSACE.ADDRESS_LINE1_TX IS NULL;