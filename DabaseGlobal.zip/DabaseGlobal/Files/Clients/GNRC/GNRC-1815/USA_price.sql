 DECLARE
              --4/14/2016 AJ
              v_audit_key NUMBER;
          BEGIN
              v_audit_key := gnrc.get_audit_key (p_program_nm => 'POLICY', p_author_nm  => 'ajain', p_process_nm => 'POLICY Data Creation', p_descriptive_tx => 'Product price data creation', p_table_nm => 'PRODUCT_PRICE_DIM');

             DELETE FROM product_price_dim where PRODUCT_KEY not  in (
                Select pr.PRODUCT_KEY from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr where pr.parent_category_nm IN ('RESIDENTIAL GASEOUS L/C HSB 1')
                );

             COMMIT;


             --AM Sweep
             --Pricing data for historical leads/sweep
             --HSBs
             INSERT
                INTO product_price_dim (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,v_audit_key as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL HKW A/C HSB and RESIDENTIAL LKW A/C HSB')
                                join policy_tbl pol using (policy_key)
                                 JOIN gnrc.term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from PRICING_SCHEME_DIM psd2 where   psd2.PRICING_SCHEME_nm LIKE '%%SWEEP%%')
                                       AND psd.PRICING_SCHEME_nm LIKE '%%SWEEP%%'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN gnrc.policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units in 6th year of coverage'
                                and p_ext.COUNTRY = 'USA'
                                and pr.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          and pr.parent_category_nm IN ('RESIDENTIAL LKW A/C HSB', 'RESIDENTIAL HKW A/C HSB')
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );


             --AM and MPOS
             --Pricing data for HSBs
             INSERT
                INTO product_price_dim (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,v_audit_key as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL HKW A/C HSB and RESIDENTIAL LKW A/C HSB')
                                join policy_tbl pol using (policy_key)
                                 JOIN gnrc.term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM gnrc.PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from gnrc.PRICING_SCHEME_DIM psd2 )
                                       AND psd.PRICING_SCHEME_nm LIKE 'AM'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN gnrc.policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units in 1st or 2nd year of coverage'
                        and p_ext.COUNTRY = 'USA'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          and pr.parent_category_nm IN ('RESIDENTIAL LKW A/C HSB', 'RESIDENTIAL HKW A/C HSB')
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );

             --select * from product_price_dim;
             --AM and MPOS
             --Pricing data for Portable Generators
             INSERT
                INTO product_price_dim (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,v_audit_key as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( UPPER(pr.parent_category_nm) = 'PORTABLE GAS GENERATORS'
                                          AND UPPER(p_ext.parent_product_category) = 'PORTABLE GENERATOR'
                                          AND pr.KW BETWEEN MIN_KW AND MAX_KW
                                          )
                                join policy_tbl pol using (policy_key)
                                 JOIN gnrc.term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM gnrc.PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from gnrc.PRICING_SCHEME_DIM psd2 )
                                       AND psd.PRICING_SCHEME_nm LIKE 'AM'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN gnrc.policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on Portables units in 1st or 2nd year of coverage'
                        and p_ext.COUNTRY = 'USA'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          --and pr.parent_category_nm IN ('PORTABLE GENERATOR')
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );


             --AM and MPOS
             --Pricing data for Pressure Washers
             INSERT
                INTO product_price_dim (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,v_audit_key as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on (UPPER(pr.parent_category_nm) = 'PRESSURE WASHERS'
                                       AND UPPER(p_ext.parent_product_category) = 'POWER WASHER'
                                       )
                                join policy_tbl pol using (policy_key)
                                 JOIN gnrc.term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM gnrc.PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from gnrc.PRICING_SCHEME_DIM psd2 )
                                       AND psd.PRICING_SCHEME_nm LIKE 'AM'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN gnrc.policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on Pressure Washers units in 1st or 2nd year of coverage'
                        and p_ext.COUNTRY = 'USA'
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );

              -------------------------------------------------
            --Pricing data for TRANSFER SWITCHES (In testing we will upgrade with AMP comes for models)
            -------------------------------------------------
             INSERT
                INTO product_price_dim (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                     INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS,
                      INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,v_audit_key as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from gnrc.V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN policy_ext_tbl p_ext on ( UPPER(pr.parent_category_nm) = 'TRANSFER SWITCHES'
                                          AND UPPER(p_ext.parent_product_category) = 'TRANSFER SWITCHES'
                                          AND pr.KW BETWEEN MIN_AMP AND MAX_AMP
                                          )
                                join policy_tbl pol using (policy_key)
                                 JOIN gnrc.term_dim tr using (term_key)
                                  cross join (
                                    SELECT PRICING_SCHEME_Key
                                      FROM gnrc.PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from gnrc.PRICING_SCHEME_DIM psd2 )
                                       AND psd.PRICING_SCHEME_nm LIKE 'AM'
                                    ) psd
                                    JOIN Policy_Fee_xref pfx USING (policy_key)
                                     JOIN gnrc.policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used IN ('CTS','GTS','PSTS')
                          --and pc.do_not_solicit_category_ind = 'N'
                          and pft.name = 'MSRP'
                          --and pr.parent_category_nm IN ('PORTABLE GENERATOR')
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM gnrc.product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );



             COMMIT;

          END;