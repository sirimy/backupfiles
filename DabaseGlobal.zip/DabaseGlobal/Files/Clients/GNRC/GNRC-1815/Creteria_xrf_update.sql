


DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Pricing Change', p_process_nm => 'GNRC-1817', p_table_nm => 'CRITERIA_CELL_XREF');

BEGIN


        update gnrc.CRITERIA_CELL_XREF SET pricing_scheme_key =  46,UPDATE_AUDIT_KEY = v_audit_key where PRICING_SCHEME_KEY = 33
        and (CRITERIA_KEY,CELL_KEY) in (
            select CRITERIA_KEY,CELL_KEY
                      from  gnrc.CRITERIA_CELL_XREF ccx
                           join gnrc.criteria_dim cr using (criteria_key)
                           left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                           join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                           join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                           join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
                     where 1=1
                       and active_ind = 'Y'
                       and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
                       and selection_tbl <> 'v_outbound_universe'
                        and ccx.pricing_scheme_key in (33,42 )
                );


        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);



END;

  COMMIT;
