  DECLARE
              --4/14/2016 AJ
              v_audit_key NUMBER;
          BEGIN
              v_audit_key := gnrc.get_audit_key (p_program_nm => 'POLICY', p_author_nm  => 'ajain', p_process_nm => 'POLICY Data Creation', p_descriptive_tx => 'POLICY T and C xref data Creation', p_table_nm => 'T_AND_C_CONTRACT_TEMPLATE_XREF');

             delete from T_AND_C_CONTRACT_TEMPLATE_XREF;
             commit;


             --------------------------------------------------------------------------------
             --Creating t_and_c_contract_template_xref data for single term and condition for all
             --------------------------------------------------------------------------------
            insert
               into t_and_c_contract_template_xref (

                    CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY,
                    EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY, TC_CONT_TEMP_XREF_KEY,
                    COUNTRY_KEY, SEQ_NO
                    )
            select CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
                   , POSTAL_STATE_KEY,
                    EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY,
                    p_t_and_c_xref_seq.nextval as TC_CONT_TEMP_XREF_KEY,
                    COUNTRY_KEY, SEQ_NO
            from (
                     select
                            CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
                            , psd.POSTAL_STATE_KEY,
                            pol.EFFECTIVE_DT, tc.Exp_Dt AS END_DT, 'Y' AS ACTIVE_IND, NULL AS CHANNEL_PARTNER_KEY
                            , psd.COUNTRY_KEY
                            , ROW_NUMBER() OVER( PARTITION BY CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, pol.EFFECTIVE_DT
                                  ORDER BY postal_state_key) as SEQ_NO
                       from gnrc.terms_and_conditions_dim tc
                              cross join gnrc.POSTAL_STATE_DIM psd
                               cross join gnrc.contract_template_tbl ctl   --this will be a placeholder only for Generac
                                cross join (
                                      select policy_key, pol.name, policy_group_key, pol.EFFECTIVE_DT
                                             ,(nvl(day, 0) + (nvl(month, 0) *30) + (nvl(year, 0) * 365))/365 AS Term_Year
                                             ,pex.PARENT_PRODUCT_CATEGORY, pex.description, pol.age
                                        from policy_tbl pol
                                             join policy_ext_tbl pex using (policy_key)
                                             join gnrc.term_dim tr using (term_key)
                                      where pex.PARENT_PRODUCT_CATEGORY   LIKE '%%HSB%%'
                                         and pex.when_used IN ('To be used on AC Residential units in 6th year of coverage')
                                         and pol.EXP_DT> sysdate
                                        and pex.COUNTRY = 'USA'
                                      ) pol
                                  LEFT JOIN gnrc.COUNTRY_TBL ct ON (ct.country_3byte_cd = psd.country_iso)
                      where
                            exp_dt = date '2099-12-31'
                        and psd.country_iso = 'en_US'
                        and postal_state_cd NOT IN ('AE', 'AP', 'AA', 'NA', 'PR', 'VI')
                        and upper(tc.name) Not LIKE  '%%CANADA%%'
                        and (terms_and_conditions_key, policy_key, postal_state_key) NOT IN
                                (select tcx.terms_and_conditions_key, tcx.policy_key, tcx.postal_state_key
                                   from gnrc.T_AND_C_CONTRACT_TEMPLATE_XREF tcx
                                )

                    );




                --------------------------------------------------------------------------------
             --Creating t_and_c_contract_template_xref data for HSB policies for canada
             --------------------------------------------------------------------------------
             insert
               into t_and_c_contract_template_xref (

                    CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY,
                    EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY, TC_CONT_TEMP_XREF_KEY,
                    COUNTRY_KEY, SEQ_NO
                    )


             select CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY,
                    EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY,
                    p_t_and_c_xref_seq.nextval as TC_CONT_TEMP_XREF_KEY,
                    COUNTRY_KEY, SEQ_NO
               from (
                       select
                            CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
                            , psd.POSTAL_STATE_KEY,
                            pol.EFFECTIVE_DT, tc.Exp_Dt AS END_DT, 'Y' AS ACTIVE_IND, NULL AS CHANNEL_PARTNER_KEY
                            , psd.COUNTRY_KEY
                            , ROW_NUMBER() OVER( PARTITION BY CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, pol.EFFECTIVE_DT
                                  ORDER BY postal_state_key) as SEQ_NO
                       from gnrc.terms_and_conditions_dim tc
                              cross join gnrc.POSTAL_STATE_DIM psd
                               cross join gnrc.contract_template_tbl ctl   --this will be a placeholder only for Generac
                                cross join (
                                      select policy_key, pol.name, policy_group_key, pol.EFFECTIVE_DT
                                             ,(nvl(day, 0) + (nvl(month, 0) *30) + (nvl(year, 0) * 365))/365 AS Term_Year
                                             ,pex.PARENT_PRODUCT_CATEGORY, pol.description
                                        from policy_tbl pol
                                             join policy_ext_tbl pex using (policy_key)
                                             join gnrc.term_dim tr using (term_key)
                                       where pex.PARENT_PRODUCT_CATEGORY   LIKE '%%HSB%%'
                                         and pex.when_used IN ('To be used on AC Residential units in 6th year of coverage')
                                         and pex.COUNTRY = 'CANADA'
                                      ) pol
                                  LEFT JOIN gnrc.COUNTRY_TBL ct ON (ct.country_3byte_cd = psd.country_iso)
                      where
                            exp_dt = date '2099-12-31'
                        and psd.country_iso = 'en_CA'
                        and UPPER(tc.name) like '%%CANADA%%'
                        and psd.postal_state_cd IN ('NB', 'NL', 'NS', 'ON', 'PE')
                        and (
                             (tc.name like '%%10%%' and pol.Term_Year = 10)
                            )
                       --AND pol.PARENT_PRODUCT_CATEGORY  LIKE '%%HSB%%'
                        and (terms_and_conditions_key, policy_key, postal_state_key) NOT IN
                                (select tcx.terms_and_conditions_key, tcx.policy_key, tcx.postal_state_key
                                   from gnrc.T_AND_C_CONTRACT_TEMPLATE_XREF tcx
                                )
                      order by TERMS_AND_CONDITIONS_KEY, POLICY_KEY
                    );


             commit;


               --------------------------------------------------------------------------------
             --Creating t_and_c_contract_template_xref data for commercial generator policies
             --------------------------------------------------------------------------------
--             insert
--                into t_and_c_contract_template_xref (
--
--                     CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY,
--                     EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY, TC_CONT_TEMP_XREF_KEY,
--                     COUNTRY_KEY, SEQ_NO
--                     )
--             select CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
--                    , POSTAL_STATE_KEY,
--                     EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY,
--                     p_t_and_c_xref_seq.nextval as TC_CONT_TEMP_XREF_KEY,
--                     COUNTRY_KEY, SEQ_NO
--                from (
--                      select
--                         CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
--                         , psd.POSTAL_STATE_KEY,
--                         pol.EFFECTIVE_DT, tc.Exp_Dt AS END_DT, 'Y' AS ACTIVE_IND, NULL AS CHANNEL_PARTNER_KEY
--                         , psd.COUNTRY_KEY
--                         , ROW_NUMBER() OVER( PARTITION BY CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, pol.EFFECTIVE_DT
--                               ORDER BY postal_state_key) as SEQ_NO
--                     from gnrc.terms_and_conditions_dim tc
--                           cross join gnrc.POSTAL_STATE_DIM psd
--                            cross join gnrc.contract_template_tbl ctl   --this will be a placeholder only for Generac
--                             cross join (
--                                   select policy_key, pol.name, policy_group_key, pol.EFFECTIVE_DT
--                                          ,(nvl(day, 0) + (nvl(month, 0) *30) + (nvl(year, 0) * 365))/365 AS Term_Year
--                                          ,pex.PARENT_PRODUCT_CATEGORY, pex.description
--                                     from policy_tbl pol
--                                          join policy_ext_tbl pex using (policy_key)
--                                          join gnrc.term_dim tr using (term_key)
--                                    where pex.DESCRIPTION  = 'Commercial Generators'
--                                   ) pol
--                               LEFT JOIN gnrc.COUNTRY_TBL ct ON (ct.country_3byte_cd = psd.country_iso)
--                     where
--                         exp_dt = date '2099-12-31'
--                      and psd.country_iso = 'en_US'
--                      and postal_state_cd NOT IN ('AE', 'AP', 'AA', 'NA', 'PR', 'VI')
--                      and CASE
--                              WHEN tc.name LIKE '%%5 Year%%Commercial Generators%%' AND pol.Term_Year = 5
--                              AND pol.PARENT_PRODUCT_CATEGORY  in ('DIESEL GENERATOR', 'GAS GENERATOR', 'GEMINI GENERATOR')  then 1
--                              WHEN tc.name LIKE '%%7 Year%%Commercial Generators%%' AND pol.Term_Year = 7
--                              AND pol.PARENT_PRODUCT_CATEGORY  in ('DIESEL GENERATOR', 'GAS GENERATOR', 'GEMINI GENERATOR')  then 1
--                              WHEN tc.name LIKE '%%10 Year%%Commercial Generators%%' AND pol.Term_Year = 10
--                              AND pol.PARENT_PRODUCT_CATEGORY  in ('DIESEL GENERATOR', 'GAS GENERATOR', 'GEMINI GENERATOR')  then 1
--                          END = 1
--                      and (terms_and_conditions_key, policy_key, postal_state_key) NOT IN
--                             (select tcx.terms_and_conditions_key, tcx.policy_key, tcx.postal_state_key
--                                from gnrc.T_AND_C_CONTRACT_TEMPLATE_XREF tcx
--                             )
--                     order by TERMS_AND_CONDITIONS_KEY, POLICY_KEY
--                     );
                --663
              ------------------------------------------------------------------------
             --Creating t_and_c_contract_template_xref data for TRANSFER SWITCHES policies
             --------------------------------------------------------------------------------
            --  insert
--                into t_and_c_contract_template_xref (
--
--                     CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, POSTAL_STATE_KEY,
--                     EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY, TC_CONT_TEMP_XREF_KEY,
--                     COUNTRY_KEY, SEQ_NO
--                     )
--             select CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
--                    , POSTAL_STATE_KEY,
--                     EFFECTIVE_DT, END_DT, ACTIVE_IND, CHANNEL_PARTNER_KEY,
--                     p_t_and_c_xref_seq.nextval as TC_CONT_TEMP_XREF_KEY,
--                     COUNTRY_KEY, SEQ_NO
--                from (
--                      select
--                         CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY
--                         , psd.POSTAL_STATE_KEY,
--                         pol.EFFECTIVE_DT, tc.Exp_Dt AS END_DT, 'Y' AS ACTIVE_IND, NULL AS CHANNEL_PARTNER_KEY
--                         , psd.COUNTRY_KEY
--                         , ROW_NUMBER() OVER( PARTITION BY CONTRACT_TEMPLATE_KEY, TERMS_AND_CONDITIONS_KEY, POLICY_KEY, pol.EFFECTIVE_DT
--                               ORDER BY postal_state_key) as SEQ_NO,tc.description,pol.PARENT_PRODUCT_CATEGORY
--                     from gnrc.terms_and_conditions_dim tc
--                           cross join gnrc.POSTAL_STATE_DIM psd
--                            cross join gnrc.contract_template_tbl ctl   --this will be a placeholder only for Generac
--                             cross join (
--                                   select policy_key, pol.name, policy_group_key, pol.EFFECTIVE_DT
--                                          ,(nvl(day, 0) + (nvl(month, 0) *30) + (nvl(year, 0) * 365))/365 AS Term_Year
--                                          ,pex.PARENT_PRODUCT_CATEGORY, pex.description
--                                     from policy_tbl pol
--                                          join policy_ext_tbl pex using (policy_key)
--                                          join gnrc.term_dim tr using (term_key)
--                                    where pex.DESCRIPTION  = 'TRANSFER SWITCHES'
--                                   ) pol
--                               LEFT JOIN gnrc.COUNTRY_TBL ct ON (ct.country_3byte_cd = psd.country_iso)
--                     where
--                         exp_dt = date '2099-12-31'
--                      and psd.country_iso = 'en_US'
--                      and postal_state_cd NOT IN ('AE', 'AP', 'AA', 'NA', 'PR', 'VI')
--                      and CASE
--                              WHEN tc.name LIKE '%%5 Year%%TRANSFER SWITCHES%%' AND pol.Term_Year = 5
--                              AND pol.PARENT_PRODUCT_CATEGORY  in ('TRANSFER SWITCHES')  then 1
--                              WHEN tc.name LIKE '%%7 Year%%TRANSFER SWITCHES%%' AND pol.Term_Year = 7
--                              AND pol.PARENT_PRODUCT_CATEGORY  in ('TRANSFER SWITCHES')  then 1
--                              WHEN tc.name LIKE '%%10 Year%%TRANSFER SWITCHES%%' AND pol.Term_Year = 10
--                              AND pol.PARENT_PRODUCT_CATEGORY  in ('TRANSFER SWITCHES')  then 1
--                          END = 1
--                      and (terms_and_conditions_key, policy_key, postal_state_key) NOT IN
--                             (select tcx.terms_and_conditions_key, tcx.policy_key, tcx.postal_state_key
--                                from gnrc.T_AND_C_CONTRACT_TEMPLATE_XREF tcx
--                             )
--                     order by TERMS_AND_CONDITIONS_KEY, POLICY_KEY
--                     );

             commit;

          END;