
DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC-1815', p_table_nm => 'POLICY_TBL');

BEGIN

         Update GNRC.POLICY_TBL
            SET EXP_DT = date'2025-07-03' ,
                UPDATE_AUDIT_KEY = v_audit_key
         where POLICY_KEY in ( 167,173) and EXP_DT = date'2099-12-31'
            ;
        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);

          Update GNRC.policy_fee_xref
            SET END_DT = date'2025-07-03' ,
                UPDATE_AUDIT_KEY = v_audit_key
         where POLICY_KEY in ( 167,173) and END_DT = date'2099-12-31'
            ;

        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);



END;

COMMIT;



DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC-1815', p_table_nm => 'PRICING_SCHEME_DIM');

BEGIN

         Update GNRC.PRICING_SCHEME_DIM
            SET END_DT = date'2025-07-03',
                UPDATE_AUDIT_KEY = v_audit_key
         where PRICING_SCHEME_NM in (
                select PRICING_SCHEME_NM from GNRCSTG.PRICING_SCHEME_DIM
            ) and END_DT > SYSDATE
            ;


        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);



END;

  COMMIT;