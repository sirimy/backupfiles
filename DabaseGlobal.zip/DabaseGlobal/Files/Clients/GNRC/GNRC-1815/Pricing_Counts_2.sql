
select * from GNRC.POLICY_TBL PL where PL.POLICY_KEY in (
    Select ppd.POLICY_KEY from GNRC.PRODUCT_PRICE_DIM ppd where ppd.PRICING_SCHEME_KEY in (
        SELECT psd.PRICING_SCHEME_KEY FROM gnrc.PRICING_SCHEME_DIM psd WHERE PRICING_SCHEME_NM IN (
            select PRICING_SCHEME_NM from PRICING_SCHEME_DIM
        ) AND END_DT > SYSDATE)
) and PL.EXP_DT > SYSDATE
;
-- +----------+---------------------------+---------------------------+------------------+------------+----------+
-- |POLICY_KEY|NAME                       |DESCRIPTION                |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |
-- +----------+---------------------------+---------------------------+------------------+------------+----------+
-- |167       |Warranty Extension: 10 Year|Warranty Extension: 10 Year|ZPD-EXWAR100005   |2022-06-01  |2099-12-31|
-- |173       |Warranty Extension         |Warranty Extension: 10 Year|ZPD-EXWAR100005   |2023-08-01  |2099-12-31|
-- +----------+---------------------------+---------------------------+------------------+------------+----------+

SELECT * FROM gnrc.PRICING_SCHEME_DIM WHERE PRICING_SCHEME_NM IN (
    select PRICING_SCHEME_NM from PRICING_SCHEME_DIM
) AND END_DT > SYSDATE
;
-- +------------------+-----------------------+------------+----------+----------------+----------------+--------------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_NM      |EFFECTIVE_DT|END_DT    |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +------------------+-----------------------+------------+----------+----------------+----------------+--------------+
-- |33                |SWEEP HSB - 6th Year   |2022-06-01  |2099-12-31|755059          |NULL            |NULL          |
-- |42                |HSB - 6th Year - CANADA|2023-08-01  |2099-12-31|873546          |874210          |NULL          |
-- +------------------+-----------------------+------------+----------+----------------+----------------+--------------+


-- STG
select * from PRICING_SCHEME_DIM;
-- +------------------+-----------------------+------------+----------+----------------+----------------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_NM      |EFFECTIVE_DT|END_DT    |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
-- +------------------+-----------------------+------------+----------+----------------+----------------+
-- |46                |SWEEP HSB - 6th Year   |2025-06-26  |2099-12-31|1086017         |NULL            |
-- |47                |HSB - 6th Year - CANADA|2025-06-26  |2099-12-31|1086017         |NULL            |
-- +------------------+-----------------------+------------+----------+----------------+----------------+

SELECT  count(*) ,count(DISTINCT ppd.PRODUCT_KEY )  from   PRODUCT_PRICE_DIM ppd
        join gnrc.V_PRODUCT vp on vp.PRODUCT_KEY = ppd.PRODUCT_KEY
;
-- +--------+------------------------------+
-- |COUNT(*)|COUNT(DISTINCTPPD.PRODUCT_KEY)|
-- +--------+------------------------------+
-- |802     |401                           |
-- +--------+------------------------------+

SELECT  count(*) ,ppd.PRICING_SCHEME_KEY,ppd.POLICY_KEY,count(DISTINCT ppd.PRODUCT_KEY )  from   PRODUCT_PRICE_DIM ppd
        join gnrc.V_PRODUCT vp on vp.PRODUCT_KEY = ppd.PRODUCT_KEY
    WHERE vp.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
GROUP BY ppd.PRICING_SCHEME_KEY,ppd.POLICY_KEY;
-- +--------+------------------------------+
-- |COUNT(*)|COUNT(DISTINCTPPD.PRODUCT_KEY)|
-- +--------+------------------------------+
-- |602     |301                           |
-- +--------+------------------------------+


select  pex.COUNTRY,psd.PRICING_SCHEME_NM, vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, min(to_number(vp.KW)), max(to_number(vp.KW)),
        tr.NAME, ppd.BASE_PRICE_AMT
        ,COUNT(*), count(distinct vp.MODEL_NO) MODELs
from   PRODUCT_PRICE_DIM ppd
        join PRICING_SCHEME_DIM psd using(PRICING_SCHEME_KEY)
       join gnrc.V_PRODUCT vp on vp.PRODUCT_KEY = ppd.PRODUCT_KEY
       join policy_tbl pol on (pol.policy_key = ppd.policy_key)
       join policy_ext_tbl pex on (pol.policy_key = pex.policy_key)
       join p_term_dim tr using (term_key)
where POLICY_PRODUCT_XID = 'ZPD-EXWAR100005' and vp.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
group by pex.COUNTRY,psd.PRICING_SCHEME_NM, vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, tr.NAME, ppd.BASE_PRICE_AMT
order by vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, ppd.BASE_PRICE_AMT
;
-- +-------+-----------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
-- |COUNTRY|PRICING_SCHEME_NM      |BRAND_NM |PARENT_CATEGORY_NM     |MIN_KW|MAX_KW|MIN(TO_NUMBER(VP.KW))|MAX(TO_NUMBER(VP.KW))|NAME   |BASE_PRICE_AMT|COUNT(*)|MODELS|
-- +-------+-----------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
-- |CANADA |HSB - 6th Year - CANADA|GENERAC  |RESIDENTIAL HKW A/C HSB|NULL  |NULL  |12                   |26                   |10 Year|635.0000      |162     |162   |
-- |USA    |SWEEP HSB - 6th Year   |GENERAC  |RESIDENTIAL HKW A/C HSB|NULL  |NULL  |12                   |26                   |10 Year|635.0000      |162     |162   |
-- |CANADA |HSB - 6th Year - CANADA|GENERAC  |RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |14                   |10 Year|635.0000      |76      |76    |
-- |USA    |SWEEP HSB - 6th Year   |GENERAC  |RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |14                   |10 Year|635.0000      |76      |76    |
-- |CANADA |HSB - 6th Year - CANADA|HONEYWELL|RESIDENTIAL HKW A/C HSB|NULL  |NULL  |12                   |26                   |10 Year|635.0000      |51      |51    |
-- |USA    |SWEEP HSB - 6th Year   |HONEYWELL|RESIDENTIAL HKW A/C HSB|NULL  |NULL  |12                   |26                   |10 Year|635.0000      |51      |51    |
-- |CANADA |HSB - 6th Year - CANADA|HONEYWELL|RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |13                   |10 Year|635.0000      |12      |12    |
-- |USA    |SWEEP HSB - 6th Year   |HONEYWELL|RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |13                   |10 Year|635.0000      |12      |12    |
-- +-------+-----------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+


select  pex.COUNTRY,PRICING_SCHEME_KEY,MAX(pex.POLICY_KEY),MIN(pex.POLICY_KEY),psd.PRICING_SCHEME_NM, vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, min(to_number(vp.KW)), max(to_number(vp.KW)),
        tr.NAME, ppd.BASE_PRICE_AMT
        ,COUNT(*), count(distinct vp.MODEL_NO) MODELs
from   GNRC.PRODUCT_PRICE_DIM ppd
        join GNRC.PRICING_SCHEME_DIM psd using(PRICING_SCHEME_KEY)
       join gnrc.V_PRODUCT vp on vp.PRODUCT_KEY = ppd.PRODUCT_KEY
       join GNRC.policy_tbl pol on (pol.policy_key = ppd.policy_key)
       join GNRC.policy_ext_tbl pex on (pol.policy_key = pex.policy_key)
       join p_term_dim tr using (term_key)
where POLICY_PRODUCT_XID = 'ZPD-EXWAR100005' and pol.EXP_DT > sysdate and vp.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
group by pex.COUNTRY,PRICING_SCHEME_KEY,psd.PRICING_SCHEME_NM, vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, tr.NAME, ppd.BASE_PRICE_AMT
order by vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, ppd.BASE_PRICE_AMT
;
-- +-------+-----------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
-- |COUNTRY|PRICING_SCHEME_NM      |BRAND_NM |PARENT_CATEGORY_NM     |MIN_KW|MAX_KW|MIN(TO_NUMBER(VP.KW))|MAX(TO_NUMBER(VP.KW))|NAME   |BASE_PRICE_AMT|COUNT(*)|MODELS|
-- +-------+-----------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
-- |CANADA |HSB - 6th Year - CANADA|GENERAC  |RESIDENTIAL HKW A/C HSB|NULL  |NULL  |12                   |26                   |10 Year|535.0000      |152     |152   |
-- |USA    |SWEEP HSB - 6th Year   |GENERAC  |RESIDENTIAL HKW A/C HSB|NULL  |NULL  |12                   |26                   |10 Year|535.0000      |162     |162   |
-- |CANADA |HSB - 6th Year - CANADA|GENERAC  |RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |11                   |10 Year|535.0000      |72      |72    |
-- |USA    |SWEEP HSB - 6th Year   |GENERAC  |RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |14                   |10 Year|535.0000      |76      |76    |
-- |CANADA |HSB - 6th Year - CANADA|HONEYWELL|RESIDENTIAL HKW A/C HSB|NULL  |NULL  |12                   |26                   |10 Year|535.0000      |46      |46    |
-- |USA    |SWEEP HSB - 6th Year   |HONEYWELL|RESIDENTIAL HKW A/C HSB|NULL  |NULL  |12                   |26                   |10 Year|535.0000      |51      |51    |
-- |CANADA |HSB - 6th Year - CANADA|HONEYWELL|RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |11                   |10 Year|535.0000      |11      |11    |
-- |USA    |SWEEP HSB - 6th Year   |HONEYWELL|RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |13                   |10 Year|535.0000      |12      |12    |
-- +-------+-----------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+



