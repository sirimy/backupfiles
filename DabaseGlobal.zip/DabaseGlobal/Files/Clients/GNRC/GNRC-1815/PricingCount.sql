select PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_NM,PSD.END_DT,PSD.EFFECTIVE_DT,COUNT(*) from GNRC.POLICY_TBL PL
            JOIN GNRC.PRODUCT_PRICE_DIM PPD on PL.POLICY_KEY = PPD.POLICY_KEY
            JOIN GNRC.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = PPD.PRICING_SCHEME_KEY
            JOIN GNRC.PRODUCT_DIM PD on PD.PRODUCT_KEY = PPD.PRODUCT_KEY
         where POLICY_PRODUCT_XID = 'ZPD-EXWAR100005' and EXP_DT > sysdate AND PD.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
Group By PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_NM,PSD.END_DT,PSD.EFFECTIVE_DT
;
-- +------------------+-----------------------+----------+------------+--------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_NM      |END_DT    |EFFECTIVE_DT|COUNT(*)|
-- +------------------+-----------------------+----------+------------+--------+
-- |33                |SWEEP HSB - 6th Year   |2099-12-31|2022-06-01  |301     |
-- |42                |HSB - 6th Year - CANADA|2099-12-31|2023-08-01  |281     |
-- +------------------+-----------------------+----------+------------+--------+

select max(POLICY_KEY) from GNRC.POLICY_TBL;--406

select * from RAW_PRICING_TBL ;
-- +---------------+----------------------------------+----------------------------------------------------------+-----------------------------------+---------------------+---------------------------------------------------+------+------+----------+------------+----------+--------------+------------------------------------------+----------------+--------------+-----------+-------+-------+-------+
-- |MATERIAL_NUMBER|MATERIAL_DESCRIPTION              |WHEN_USED                                                 |TERM                               |CONTRACT_RETAIL_PRICE|PARENT_PRODUCT_CATEGORY                            |MIN_KW|MAX_KW|POLICY_KEY|EFFECTIVE_DT|EXP_DT    |UNDERWRITER_NM|FILE_NM                                   |INSERT_AUDIT_KEY|NEW_POLICY_KEY|DESCRIPTION|COUNTRY|MIN_AMP|MAX_AMP|
-- +---------------+----------------------------------+----------------------------------------------------------+-----------------------------------+---------------------+---------------------------------------------------+------+------+----------+------------+----------+--------------+------------------------------------------+----------------+--------------+-----------+-------+-------+-------+
-- |ZPD-EXWAR100005|AC RES YR 6 - 10 EXTED 10 YR P/L/T|To be used on AC Residential units in 6th year of coverage|10yr Warranty from Date of Purchase|635                  |RESIDENTIAL HKW A/C HSB and RESIDENTIAL LKW A/C HSB|NULL  |NULL  |410       |2026-06-26  |2099-12-31|Generac       |generac_pricing_change_GNRC-1815_June_2025|1085998         |NULL          |NULL       |NULL   |NULL   |NULL   |
-- |ZPD-EXWAR100005|AC RES YR 6 - 10 EXTED 10 YR P/L/T|To be used on AC Residential units in 6th year of coverage|10yr Warranty from Date of Purchase|635                  |RESIDENTIAL HKW A/C HSB and RESIDENTIAL LKW A/C HSB|NULL  |NULL  |411       |2026-06-26  |2099-12-31|Generac       |generac_pricing_change_GNRC-1815_June_2025|1085998         |NULL          |NULL       |CANADA |NULL   |NULL   |
-- +---------------+----------------------------------+----------------------------------------------------------+-----------------------------------+---------------------+---------------------------------------------------+------+------+----------+------------+----------+--------------+------------------------------------------+----------------+--------------+-----------+-------+-------+-------+


select * FROM policy_lkp;
-- +-------------------+----------------+--------------+----------+----------------+----------------+--------------+
-- |POLICY_XID         |SOURCE_SYSTEM_CD|EXT_ID_TYPE_CD|POLICY_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +-------------------+----------------+--------------+----------+----------------+----------------+--------------+
-- |ZPD-EXWAR100005-410|0               |2             |410       |1086011         |NULL            |NULL          |
-- |ZPD-EXWAR100005-411|0               |2             |411       |1086011         |NULL            |NULL          |
-- |411                |2               |1             |411       |1086012         |NULL            |NULL          |
-- |410                |2               |1             |410       |1086012         |NULL            |NULL          |
-- +-------------------+----------------+--------------+----------+----------------+----------------+--------------+


select * FROM policy_tbl;
-- +----------+---------------------------+---------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+----+--------------+----------------+----------------+----------+--------------+---------------+------------+
-- |POLICY_KEY|NAME                       |DESCRIPTION                |POLICY_PRODUCT_XID|EFFECTIVE_DT|EXP_DT    |MIN_PRODUCT_PRICE|MAX_PRODUCT_PRICE|CURRENCY_CD|POLICY_TYPE_KEY|TERM_KEY|CONTRACT_SALES_CHANNEL_KEY|COVERAGE_TIMING_STRATEGY_KEY|RESOLUTION_TYPE|IMAGE_LINK|THUMBNAIL_IMAGE_LINK|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|AGE |SYNC_AUDIT_KEY|SUBSCRIBABLE_IND|POLICY_GROUP_KEY|DEDUCTIBLE|DEDUCTIBLE_MAX|UNDERWRITER_KEY|NEW_USED_IND|
-- +----------+---------------------------+---------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+----+--------------+----------------+----------------+----------+--------------+---------------+------------+
-- |410       |Warranty Extension: 10 Year|Warranty Extension: 10 Year|ZPD-EXWAR100005   |2026-06-26  |2099-12-31|NULL             |NULL             |USD        |1              |10      |3                         |1                           |NULL           |NULL      |NULL                |1086011         |NULL            |NULL|NULL          |NULL            |1               |NULL      |NULL          |1              |N           |
-- |411       |Warranty Extension: 10 Year|Warranty Extension: 10 Year|ZPD-EXWAR100005   |2026-06-26  |2099-12-31|NULL             |NULL             |USD        |1              |10      |3                         |1                           |NULL           |NULL      |NULL                |1086011         |NULL            |NULL|NULL          |NULL            |1               |NULL      |NULL          |1              |N           |
-- +----------+---------------------------+---------------------------+------------------+------------+----------+-----------------+-----------------+-----------+---------------+--------+--------------------------+----------------------------+---------------+----------+--------------------+----------------+----------------+----+--------------+----------------+----------------+----------+--------------+---------------+------------+


select * FROM policy_ext_tbl;
-- +----------+----------------------------------------------------------+-----------+---------------------------------------------------+------+------+----------------+----------------+--------------+-------+-------+-------+
-- |POLICY_KEY|WHEN_USED                                                 |DESCRIPTION|PARENT_PRODUCT_CATEGORY                            |MIN_KW|MAX_KW|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|COUNTRY|MIN_AMP|MAX_AMP|
-- +----------+----------------------------------------------------------+-----------+---------------------------------------------------+------+------+----------------+----------------+--------------+-------+-------+-------+
-- |410       |To be used on AC Residential units in 6th year of coverage|NULL       |RESIDENTIAL HKW A/C HSB and RESIDENTIAL LKW A/C HSB|NULL  |NULL  |NULL            |NULL            |NULL          |USA    |NULL   |NULL   |
-- |411       |To be used on AC Residential units in 6th year of coverage|NULL       |RESIDENTIAL HKW A/C HSB and RESIDENTIAL LKW A/C HSB|NULL  |NULL  |NULL            |NULL            |NULL          |CANADA |NULL   |NULL   |
-- +----------+----------------------------------------------------------+-----------+---------------------------------------------------+------+------+----------------+----------------+--------------+-------+-------+-------+

select * FROM policy_fee_xref;
-- +----------+-------------------+----------------+--------------------------+--------------------------+----------------+----------------+--------------+
-- |POLICY_KEY|POLICY_FEE_TYPE_KEY|POLICY_FEE_VALUE|EFFECTIVE_DT              |END_DT                    |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +----------+-------------------+----------------+--------------------------+--------------------------+----------------+----------------+--------------+
-- |410       |5111               |635.00          |2026-06-26 00:00:00.000000|2099-12-31 00:00:00.000000|NULL            |NULL            |NULL          |
-- |411       |5111               |635.00          |2026-06-26 00:00:00.000000|2099-12-31 00:00:00.000000|NULL            |NULL            |NULL          |
-- |410       |5114               |190.50          |2026-06-26 00:00:00.000000|2099-12-31 00:00:00.000000|NULL            |NULL            |NULL          |
-- |411       |5114               |190.50          |2026-06-26 00:00:00.000000|2099-12-31 00:00:00.000000|NULL            |NULL            |NULL          |
-- +----------+-------------------+----------------+--------------------------+--------------------------+----------------+----------------+--------------+

select * from policy_item_tbl;
-- +---------------+----+----------------+----------------+--------------+
-- |POLICY_ITEM_KEY|NAME|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +---------------+----+----------------+----------------+--------------+
-- |1350           |410 |1086013         |NULL            |NULL          |
-- |1351           |411 |1086013         |NULL            |NULL          |
-- +---------------+----+----------------+----------------+--------------+

select * from POLICY_COVERAGE_TBL;
-- +----------+-----------------+---------------------+--------+----------------------------+----------------+----------------+--------------+---------------+
-- |POLICY_KEY|COVERAGE_TYPE_KEY|COVERED_COMPONENT_KEY|TERM_KEY|COVERAGE_TIMING_STRATEGY_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|POLICY_ITEM_KEY|
-- +----------+-----------------+---------------------+--------+----------------------------+----------------+----------------+--------------+---------------+
-- |410       |2                |1                    |10      |1                           |1086014         |NULL            |NULL          |1350           |
-- |410       |3                |1                    |10      |1                           |1086014         |NULL            |NULL          |1350           |
-- |411       |2                |1                    |10      |1                           |1086014         |NULL            |NULL          |1351           |
-- |411       |3                |1                    |10      |1                           |1086014         |NULL            |NULL          |1351           |
-- +----------+-----------------+---------------------+--------+----------------------------+----------------+----------------+--------------+---------------+



select POLICY_KEY,T_C_X.TERMS_AND_CONDITIONS_KEY,TC.NAME,COUNT(*)
from T_AND_C_CONTRACT_TEMPLATE_XREF T_C_X join gnrc.TERMS_AND_CONDITIONS_DIM TC
        on TC.TERMS_AND_CONDITIONS_KEY = T_C_X.TERMS_AND_CONDITIONS_KEY
group by POLICY_KEY,T_C_X.TERMS_AND_CONDITIONS_KEY,TC.NAME;
-- +----------+------------------------+---------------------------------------------------------------------------+--------+
-- |POLICY_KEY|TERMS_AND_CONDITIONS_KEY|NAME                                                                       |COUNT(*)|
-- +----------+------------------------+---------------------------------------------------------------------------+--------+
-- |410       |15                      |Generac USA Terms & Conditions                                             |51      |
-- |411       |7                       |10 Year Power Plan - CANADA - Residential and Commercial Standby Generators|5       |
-- +----------+------------------------+---------------------------------------------------------------------------+--------+

