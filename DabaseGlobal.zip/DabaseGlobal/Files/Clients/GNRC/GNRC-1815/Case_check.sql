select PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_NM,PSD.END_DT,PSD.EFFECTIVE_DT,COUNT(*)
from GNRC.POLICY_TBL PL
            JOIN GNRC.PRODUCT_PRICE_DIM PPD on PL.POLICY_KEY = PPD.POLICY_KEY
            JOIN GNRC.PRICING_SCHEME_DIM PSD on PSD.PRICING_SCHEME_KEY = PPD.PRICING_SCHEME_KEY
            JOIN GNRC.PRODUCT_DIM PD on PD.PRODUCT_KEY = PPD.PRODUCT_KEY
         where POLICY_PRODUCT_XID = 'ZPD-EXWAR100005'
           --and EXP_DT > sysdate
           AND PD.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
Group By PSD.PRICING_SCHEME_KEY,PSD.PRICING_SCHEME_NM,PSD.END_DT,PSD.EFFECTIVE_DT
ORDER BY PSD.PRICING_SCHEME_KEY
;

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual update', p_process_nm => 'GNRC-1815', p_table_nm => 'PRICING_SCHEME_DIM');

BEGIN

         Update GNRC.PRICING_SCHEME_DIM
            SET END_DT = date'2025-06-25',
                UPDATE_AUDIT_KEY = v_audit_key
         where PRICING_SCHEME_NM in (
                select PRICING_SCHEME_NM from GNRCSTG.PRICING_SCHEME_DIM
            ) and END_DT > SYSDATE
            ;


        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);

       COMMIT;

END;
-- +------------------+-----------------------+----------+------------+--------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_NM      |END_DT    |EFFECTIVE_DT|COUNT(*)|
-- +------------------+-----------------------+----------+------------+--------+
-- |5                 |SWEEP HSB - 6th Year   |2021-12-31|2018-10-01  |254     |
-- |23                |SWEEP HSB - 6th Year   |2022-05-31|2022-01-01  |256     |
-- |33                |SWEEP HSB - 6th Year   |2025-06-25|2022-06-01  |301     |
-- |42                |HSB - 6th Year - CANADA|2025-06-25|2023-08-01  |281     |
-- |46                |SWEEP HSB - 6th Year   |2099-12-31|2025-06-26  |301     |
-- |47                |HSB - 6th Year - CANADA|2099-12-31|2025-06-26  |301     |
-- +------------------+-----------------------+----------+------------+--------+


select  pex.COUNTRY,PRICING_SCHEME_KEY,MAX(pex.POLICY_KEY),MIN(pex.POLICY_KEY),psd.PRICING_SCHEME_NM, vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, min(to_number(vp.KW)), max(to_number(vp.KW)),
        tr.NAME, ppd.BASE_PRICE_AMT
        ,COUNT(*), count(distinct vp.MODEL_NO) MODELs
from   GNRC.PRODUCT_PRICE_DIM ppd
        join GNRC.PRICING_SCHEME_DIM psd using(PRICING_SCHEME_KEY)
       join gnrc.V_PRODUCT vp on vp.PRODUCT_KEY = ppd.PRODUCT_KEY
       join GNRC.policy_tbl pol on (pol.policy_key = ppd.policy_key)
       join GNRC.policy_ext_tbl pex on (pol.policy_key = pex.policy_key)
       join p_term_dim tr using (term_key)
where POLICY_PRODUCT_XID = 'ZPD-EXWAR100005'
  and pol.EXP_DT > sysdate
  and vp.DO_NOT_SOLICIT_PRODUCT_IND = 'Y'-- check it
group by pex.COUNTRY,PRICING_SCHEME_KEY,psd.PRICING_SCHEME_NM, vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, tr.NAME, ppd.BASE_PRICE_AMT
order by vp.BRAND_NM, vp.Parent_CATEGORY_NM, pex.MIN_KW,pex.MAX_KW, ppd.BASE_PRICE_AMT
;
-- +-------+------------------+-------------------+-------------------+--------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
-- |COUNTRY|PRICING_SCHEME_KEY|MAX(PEX.POLICY_KEY)|MIN(PEX.POLICY_KEY)|PRICING_SCHEME_NM   |BRAND_NM |PARENT_CATEGORY_NM     |MIN_KW|MAX_KW|MIN(TO_NUMBER(VP.KW))|MAX(TO_NUMBER(VP.KW))|NAME   |BASE_PRICE_AMT|COUNT(*)|MODELS|
-- +-------+------------------+-------------------+-------------------+--------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+
-- |USA    |46                |410                |410                |SWEEP HSB - 6th Year|GENERAC  |RESIDENTIAL HKW A/C HSB|NULL  |NULL  |13                   |26                   |10 Year|635.0000      |74      |74    |
-- |USA    |46                |410                |410                |SWEEP HSB - 6th Year|GENERAC  |RESIDENTIAL LKW A/C HSB|NULL  |NULL  |8                    |11                   |10 Year|635.0000      |13      |13    |
-- |USA    |46                |410                |410                |SWEEP HSB - 6th Year|HONEYWELL|RESIDENTIAL HKW A/C HSB|NULL  |NULL  |18                   |24                   |10 Year|635.0000      |12      |12    |
-- |USA    |46                |410                |410                |SWEEP HSB - 6th Year|HONEYWELL|RESIDENTIAL LKW A/C HSB|NULL  |NULL  |10                   |10                   |10 Year|635.0000      |1       |1     |
-- +-------+------------------+-------------------+-------------------+--------------------+---------+-----------------------+------+------+---------------------+---------------------+-------+--------------+--------+------+

