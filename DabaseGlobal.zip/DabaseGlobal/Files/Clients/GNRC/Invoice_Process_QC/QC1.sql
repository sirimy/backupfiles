
select SUM(ITEM_PRICE_AMT),SUM(PREMIUM_AMT) from EXTRACT_CANCELS_ADJUSTMENT_INV_05_2024;--64
+-------------------+----------------+
|SUM(ITEM_PRICE_AMT)|SUM(PREMIUM_AMT)|
+-------------------+----------------+
|-3832.4            |-1341.35        |
+-------------------+----------------+




select IREF.NAME,COUNT(*),SUM(INVOICE_KEY_VALUE) from INVOICE_FCT_TBL IFT
                JOIN GNRC.INVOICE_REF IREF on IFT.INVOICE_KEY = IREF.INVOICE_KEY
                join gnrc.PARTIAL_CANCELLATIONS_GNRC1528 PCG on PCG.AFTER_ORDER_ID = ORDER_KEY AND PCG.AFTER_ORDER_LINE_ID = ORDER_LINE_KEY
                join gnrc.PARTIAL_CANCELLATIONS_GNRC1533 PCG1 on PCG1.ORDER_NO = ORDER_KEY AND PCG1.ORDER_LINE_NO = ORDER_LINE_KEY
                where (ORDER_KEY,ORDER_LINE_KEY) in
                        ( select ORDER_NO,ORDER_LINE_NO from EXTRACT_CANCELS_ADJUSTMENT_INV_05_2024)
                and (ift.INVOICE_KEY_VALUE = TO_CHAR(-1*PCG.TOTAL_GROSS_SALES) OR ift.INVOICE_KEY_VALUE = TO_CHAR(PCG1.PREMIUM_AMT))
GROUP BY IREF.NAME
;
+--------------+--------+----------------------+
|NAME          |COUNT(*)|SUM(INVOICE_KEY_VALUE)|
+--------------+--------+----------------------+
|REFUND REVENUE|64      |-3832.4               |
|REFUND PREMIUM|64      |-1341.35              |
+--------------+--------+----------------------+

select SUM(ITEM_PRICE_AMT),SUM(PREMIUM_AMT),COUNT(*)
from   EXTRACT_CANCELS_DETAILS_INV_05_2024;

select SUM(ITEM_PRICE_AMT),SUM(PREMIUM_AMT),COUNT(*)
from   EXTRACT_CANCELS_DETAILS_INV_05_2024
WHERE  1 = 1
AND (order_no, order_line_no) IN (
        Select ci.ORDER_KEY,ci.ORDER_LINE_KEY
        FROM gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ci
               join gnrc.CONTRACT_CANCELLATION_DIM cc on cc.CONTRACT_KEY = ci.CONTRACT_KEY
               join gnrc.CONTRACT_LKP clkp on clkp.CONTRACT_KEY = cc.CONTRACT_KEY and clkp.SOURCE_SYSTEM_CD = 0
         where 1=1
           and FULL_OR_PRO_RATED_REFUND <> 'Full'
           and cc.CANCEL_DT >= date '2024-05-01'
    );
+-------------------+----------------+--------+
|SUM(ITEM_PRICE_AMT)|SUM(PREMIUM_AMT)|COUNT(*)|
+-------------------+----------------+--------+
|16054.14           |5618.94         |26      |
+-------------------+----------------+--------+



select IREF.NAME,COUNT(*),SUM(IFT.INVOICE_KEY_VALUE) from INVOICE_FCT_TBL IFT
                JOIN GNRC.INVOICE_REF IREF on IFT.INVOICE_KEY = IREF.INVOICE_KEY
                where (ORDER_KEY,ORDER_LINE_KEY)
                                   IN (
                    Select ci.ORDER_KEY,ci.ORDER_LINE_KEY
                    FROM gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ci
                           join gnrc.CONTRACT_CANCELLATION_DIM cc on cc.CONTRACT_KEY = ci.CONTRACT_KEY
                           join gnrc.CONTRACT_LKP clkp on clkp.CONTRACT_KEY = cc.CONTRACT_KEY and clkp.SOURCE_SYSTEM_CD = 0
                     where 1=1
                       and FULL_OR_PRO_RATED_REFUND <> 'Full'
                       and cc.CANCEL_DT >= date '2024-05-01'
                )
        and IREF.NAME in ('REFUND REVENUE','REFUND PREMIUM')
GROUP BY IREF.NAME
;
+--------------+--------+--------------------------+
|NAME          |COUNT(*)|SUM(IFT.INVOICE_KEY_VALUE)|
+--------------+--------+--------------------------+
|REFUND REVENUE|26      |16054.14                  |
|REFUND PREMIUM|26      |5618.94                   |
+--------------+--------+--------------------------+


select CONTRACT_STATUS,SUM(TOTAL_GROSS_SALES),SUM(TAX_COLLECTED),COUNT(*)
from   GNRC.V_TAX_REPORT
WHERE  1 = 1
AND (AFTER_ORDER_ID, AFTER_ORDER_LINE_ID) IN (
        Select ci.ORDER_KEY,ci.ORDER_LINE_KEY
        FROM gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ci
               join gnrc.CONTRACT_CANCELLATION_DIM cc on cc.CONTRACT_KEY = ci.CONTRACT_KEY
               join gnrc.CONTRACT_LKP clkp on clkp.CONTRACT_KEY = cc.CONTRACT_KEY and clkp.SOURCE_SYSTEM_CD = 0
         where 1=1
           and FULL_OR_PRO_RATED_REFUND <> 'Full'
           and cc.CANCEL_DT >= date '2024-05-01'
    )
GROUP BY CONTRACT_STATUS
;
+---------------+----------------------+------------------+--------+
|CONTRACT_STATUS|SUM(TOTAL_GROSS_SALES)|SUM(TAX_COLLECTED)|COUNT(*)|
+---------------+----------------------+------------------+--------+
|Sold           |17534                 |965.27            |26      |
|Prorata Cancel |-16054.14             |-891.96           |26      |
+---------------+----------------------+------------------+--------+

select SUM(oit.PRICE_AMT * ci.REFUND_PERCENTAGE),SUM(oit.TAX_AMT * ci.REFUND_PERCENTAGE), COUNT(*)
from   GNRC.ORDER_ITEM_TBL oit
       join gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ci
            on ci.ORDER_KEY = oit.ORDER_KEY and ci.ORDER_LINE_KEY = oit.ORDER_LINE_KEY
       join gnrc.CONTRACT_CANCELLATION_DIM cc on cc.CONTRACT_KEY = ci.CONTRACT_KEY
       join gnrc.CONTRACT_LKP clkp on clkp.CONTRACT_KEY = cc.CONTRACT_KEY and clkp.SOURCE_SYSTEM_CD = 0
 where 1=1
   and FULL_OR_PRO_RATED_REFUND <> 'Full'
   and cc.CANCEL_DT >= date '2024-05-01';
+---------------------------------------+-------------------------------------+--------+
|SUM(OIT.PRICE_AMT*CI.REFUND_PERCENTAGE)|SUM(OIT.TAX_AMT*CI.REFUND_PERCENTAGE)|COUNT(*)|
+---------------------------------------+-------------------------------------+--------+
|16054.14155                            |891.9565954                          |26      |
+---------------------------------------+-------------------------------------+--------+


    select * from RAW_CONTRACT_TBL;

select * from CONTRACT_COMMON_LOAD_TBL;



select SUM(ITEM_PRICE_AMT),SUM(PREMIUM_AMT) from EXTRACT_SALES_ADJUSTMENT_INV_05_2024;--32
+-------------------+----------------+
|SUM(ITEM_PRICE_AMT)|SUM(PREMIUM_AMT)|
+-------------------+----------------+
|6400               |2204.8          |
+-------------------+----------------+





select IREF.NAME,COUNT(*),SUM(INVOICE_KEY_VALUE) from INVOICE_FCT_TBL IFT
                JOIN GNRC.INVOICE_REF IREF on IFT.INVOICE_KEY = IREF.INVOICE_KEY
                where (ORDER_KEY,ORDER_LINE_KEY) in
                        ( select ORDER_NO,ORDER_LINE_NO from EXTRACT_SALES_ADJUSTMENT_INV_05_2024)
GROUP BY IREF.NAME
;
+-------+--------+----------------------+
|NAME   |COUNT(*)|SUM(INVOICE_KEY_VALUE)|
+-------+--------+----------------------+
|PREMIUM|32      |-2204.8               |
|REVENUE|32      |-6400                 |
+-------+--------+----------------------+

select IREF.NAME,COUNT(*),SUM(INVOICE_KEY_VALUE) from INVOICE_FCT_TBL IFT
                JOIN GNRC.INVOICE_REF IREF on IFT.INVOICE_KEY = IREF.INVOICE_KEY
                where IFT.INVOICE_KEY in (8,9)
GROUP BY IREF.NAME
;

select IREF.NAME,COUNT(*),SUM(INVOICE_KEY_VALUE) from INVOICE_FCT_TBL IFT
                JOIN GNRC.INVOICE_REF IREF on IFT.INVOICE_KEY = IREF.INVOICE_KEY
                where IFT.INVOICE_KEY_VALUE = '200' and IFT.INVOICE_KEY = 8
GROUP BY IREF.NAME
;
+----------+--------+----------------------+
|NAME      |COUNT(*)|SUM(INVOICE_KEY_VALUE)|
+----------+--------+----------------------+
|ADJUSTMENT|32      |6400                  |
+----------+--------+----------------------+



select IREF.NAME,COUNT(*),SUM(INVOICE_KEY_VALUE) from INVOICE_FCT_TBL IFT
                JOIN GNRC.INVOICE_REF IREF on IFT.INVOICE_KEY = IREF.INVOICE_KEY
                where IFT.INVOICE_KEY_VALUE <> '200' and IFT.INVOICE_KEY = 8
GROUP BY IREF.NAME
;
+----------+--------+----------------------+
|NAME      |COUNT(*)|SUM(INVOICE_KEY_VALUE)|
+----------+--------+----------------------+
|ADJUSTMENT|64      |-3832.4               |
+----------+--------+----------------------+


select IREF.NAME,COUNT(*),SUM(INVOICE_KEY_VALUE) from INVOICE_FCT_TBL IFT
                JOIN GNRC.INVOICE_REF IREF on IFT.INVOICE_KEY = IREF.INVOICE_KEY
                where IFT.INVOICE_KEY_VALUE = '68.9' and
                      IFT.INVOICE_KEY = 9
GROUP BY IREF.NAME
;
+------------------+--------+----------------------+
|NAME              |COUNT(*)|SUM(INVOICE_KEY_VALUE)|
+------------------+--------+----------------------+
|ADJUSTMENT PREMIUM|32      |2204.8                |
+------------------+--------+----------------------+


select IREF.NAME,COUNT(*),SUM(INVOICE_KEY_VALUE) from INVOICE_FCT_TBL IFT
                JOIN GNRC.INVOICE_REF IREF on IFT.INVOICE_KEY = IREF.INVOICE_KEY
                where IFT.INVOICE_KEY_VALUE <> '68.9' and IFT.INVOICE_KEY = 9
GROUP BY IREF.NAME
;
+------------------+--------+----------------------+
|NAME              |COUNT(*)|SUM(INVOICE_KEY_VALUE)|
+------------------+--------+----------------------+
|ADJUSTMENT PREMIUM|64      |-1341.35              |
+------------------+--------+----------------------+


select UPDATE_AUDIT_KEY,PROGRAM_NM,CREATION_DT,COUNT(*)
from GNRC.CONTRACT_DIM CD join AUDIT_TBL AT1 on CD.UPDATE_AUDIT_KEY = AT1.AUDIT_KEY
where AT1.CREATION_DT > SYSDATE -1
GROUP BY UPDATE_AUDIT_KEY,PROGRAM_NM,CREATION_DT
;
+----------------+---------------+--------------------------+--------+
|UPDATE_AUDIT_KEY|PROGRAM_NM     |CREATION_DT               |COUNT(*)|
+----------------+---------------+--------------------------+--------+
|979954          |CONTRACT MODULE|2024-07-16 02:43:59.000000|59      |
|979994          |RAW_CONTRACT   |2024-07-16 07:08:16.000000|547     |
+----------------+---------------+--------------------------+--------+


