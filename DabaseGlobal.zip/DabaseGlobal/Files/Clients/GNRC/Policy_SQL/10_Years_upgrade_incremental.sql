
           --Pricing data for HSBs --3 year upgrade
             INSERT
                INTO product_price_dim (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS
                     ,INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS
                      ,INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,v_audit_key as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from p_V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN p_policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL HKW A/C HSB and RESIDENTIAL LKW A/C HSB')
                                JOIN p_policy_tbl pol using (policy_key)
                                 JOIN p_term_dim tr using (term_key)
                                  CROSS JOIN (
                                    SELECT PRICING_SCHEME_Key
                                      FROM P_PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from P_PRICING_SCHEME_DIM psd2 where upper(psd2.PRICING_SCHEME_NM) = 'UP HSB CAN - 3 YEAR UPGRADE')
                                       AND PSD.END_DT >= current_date
                                       AND upper(psd.PRICING_SCHEME_NM) = 'UP HSB CAN - 3 YEAR UPGRADE'
                                     ) psd
                                     JOIN P_Policy_Fee_xref pfx USING (policy_key)
                                      JOIN p_policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units having 7 years of extended coverage'
                          and  pr.do_not_solicit_product_ind = 'N'
                          and  pr.do_not_solicit_category_ind = 'N'
                          and  nvl(pr.do_not_solicit_brand_ind, 'N') <> 'Y'
                          and  pol.EXP_DT >= trunc(sysdate)
                          and  pft.name = 'MSRP'
                          and  pr.parent_category_nm IN ('RESIDENTIAL LKW A/C HSB', 'RESIDENTIAL HKW A/C HSB')
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM p_product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );
--259



        --Pricing data for HSB -- 5 year upgrade
        INSERT
                INTO product_price_dim (
                     PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                     BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                     DEALER_COST, DEALER_RETAIL_PRICE, PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, GREATEST_SAVINGS_AMT,
                     YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS
                     ,INSERT_AUDIT_KEY
                     )
             SELECT
                      PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY,
                      policy_fee_value as BASE_PRICE_AMT, AGE_MONTHS, TERM_MONTHS,
                      DEALER_COST, DEALER_RETAIL_PRICE, policy_fee_value AS PRICE_BEFORE_DISCOUNT_AMT, TERM_DISCOUNT_AMT, policy_fee_value as GREATEST_SAVINGS_AMT,
                      YEARS_OUT_OF_WARRANTY, PREMIUM_AMT, STATUS
                      ,INSERT_AUDIT_KEY
                       --,PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, min_kw, max_kw, name --debug columns

                 FROM (
                       select  psd.PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY, pfx.policy_fee_value, NULL AS AGE_MONTHS,
                               term_value * 12 AS TERM_MONTHS,
                               null as DEALER_COST, null as DEALER_RETAIL_PRICE, NULL AS TERM_DISCOUNT_AMT,
                               NULL AS YEARS_OUT_OF_WARRANTY, NULL AS PREMIUM_AMT, 'A' as STATUS
                               ,v_audit_key as INSERT_AUDIT_KEY
                               --,psd.PRICING_SCHEME_NM, parent_category_nm, p_ext.when_used, p_ext.min_kw, p_ext.max_kw, name --debug columns
                         from p_V_PRODUCT_ATTRIBUTE_XREF pr
                               JOIN p_policy_ext_tbl p_ext on ( p_ext.parent_product_category = 'RESIDENTIAL HKW A/C HSB and RESIDENTIAL LKW A/C HSB')
                                JOIN p_policy_tbl pol using (policy_key)
                                 JOIN p_term_dim tr using (term_key)
                                  CROSS JOIN (
                                    SELECT PRICING_SCHEME_Key
                                      FROM P_PRICING_SCHEME_DIM psd
                                     WHERE psd.effective_dt = ( select max(psd2.effective_dt) from P_PRICING_SCHEME_DIM psd2 where upper(psd2.PRICING_SCHEME_NM) = 'UP HSB CAN - 5 YEAR UPGRADE')
                                       AND PSD.END_DT >= current_date
                                       AND upper(psd.PRICING_SCHEME_NM) = 'UP HSB CAN - 5 YEAR UPGRADE'
                                     ) psd
                                     JOIN P_Policy_Fee_xref pfx USING (policy_key)
                                      JOIN p_policy_fee_type pft using (policy_fee_type_key)
                        WHERE  p_ext.when_used = 'To be used on AC Residential units having 5 years of extended coverage'
                          and  pr.do_not_solicit_product_ind = 'N'
                          and  pr.do_not_solicit_category_ind = 'N'
                          and nvl(pr.do_not_solicit_brand_ind, 'N') <> 'Y'
                          and pol.EXP_DT >= trunc(sysdate)
                          and pft.name = 'MSRP'
                          and pr.parent_category_nm IN ('RESIDENTIAL LKW A/C HSB', 'RESIDENTIAL HKW A/C HSB')
                      )
               WHERE (PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY) NOT IN
                        (SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM p_product_price_dim
                         UNION ALL
                        SELECT PRICING_SCHEME_KEY, PRODUCT_KEY, POLICY_KEY
                           FROM product_price_dim
                        );