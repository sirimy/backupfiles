select PO.policy_id,PO.sku,PO.name,PO.description,POT.description from policy PO inner join policy_ext POT on PO.policy_id = POT.policy_id
Where POT.product_cat_desc like 'RESIDENTIAL%'
Order by PO.policy_id;

SELECT oit.serialized_item_id,
             si.serial_num,
             ot.created_by,
             ot.purchase_dt,
             ot.sales_source_cd,
             oit.order_id,
             oit.order_line_id,
            oit.offer_id,
             oit.price_amt,
             oit.tax_amt,
             oit.flexpay_ind,
             cust.first_nm,
             cust.last_nm,
             cust.firm_nm,
             adr.address_line1_tx,
             adr.locality_nm,
             s.code    AS state_code,
             p.name    AS policy_name,
             oit.coverage_exp_dt
      FROM order_tbl ot
               JOIN order_item_tbl oit ON ot.order_id = oit.order_id
               JOIN policy p USING (policy_id)
               JOIN serialized_item si ON si.serialized_item_id = oit.serialized_item_id
               LEFT JOIN customer_tbl cust USING (customer_id)
               JOIN address_tbl adr ON adr.address_id = cust.primary_address_id
               JOIN state s ON adr.state_id = s.state_id
where p.policy_id in ( 168,169);


select * from OFFER_tbl ot join  OFFER_item_tbl oit using (offer_id)
       left join policy pol using (policy_id) left join policy_ext pex using (policy_id)
 where 1=1
--   and ot.active_ind = 'Y'
--   and offer_start_utc_ts <= current_date
-- and offer_exp_dt >= current_date
--   and offer_exp_dt >= date '2021-12-01'
  and current_date between offer_start_utc_ts and offer_exp_dt
  order by offer_exp_dt, offer_id, price_amt
--   order by random()
limit 30;



select PO.policy_id,PO.sku,PO.name,PO.description,POT.description,POT.product_cat_desc from policy PO inner join policy_ext POT on PO.policy_id = POT.policy_id
Where POT.product_cat_desc not like 'RESIDENTIAL%'
Order by PO.policy_id, PO.sku;


select * from policy;-- where policy_id in ( 117,118,142,168,169);
Select * from policy_ext order by policy_id;


select * from OFFER_tbl ot join  OFFER_item_tbl oit using (offer_id)
       left join policy pol using (policy_id) left join policy_ext pex using (policy_id)
 where 1=1
--   and ot.active_ind = 'Y'
--   and offer_start_utc_ts <= current_date
-- and offer_exp_dt >= current_date
--   and offer_exp_dt >= date '2021-12-01'
  and current_date between offer_start_utc_ts and offer_exp_dt
  order by offer_exp_dt, offer_id, price_amt
--   order by random()
limit 30;


select * from offer_item_tbl join offer_tbl using (offer_id)
         where policy_id = 116 and offer_exp_dt >= date '2022-01-01'
limit 10;
--Policy sql from web:
select *
  from policy_ext pex
       join policy pol using (policy_id)
       join v_policy_fee_xref fee using (policy_id)
 where 1=1
--    and exp_dt > current_date
-- where policy_id IN (150)
-- where  sku IN ('ZPD-EXWAR100003', 'ZPD-EXWAR100001')
  and pex.product_cat_desc like 'RESIDENTIAL%'
--  and pex.product_cat_desc not in ('DIESEL GENERATOR', 'GAS GENERATOR', 'GEMINI GENERATOR' )
--  and term_id = 10
 order by policy_id;
