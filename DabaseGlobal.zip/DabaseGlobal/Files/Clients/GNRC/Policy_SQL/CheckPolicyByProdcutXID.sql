select * from p_policy_tbl ppt inner join gnrc.policy_ext_tbl pet on ppt.POLICY_KEY = pet.POLICY_KEY
         inner join gnrc.V_POLICY_FEE vpf on vpf.POLICY_KEY = pet.POLICY_KEY
         where   ppt.POLICY_PRODUCT_XID in ('ZPD-EXWAR100003','ZPD-EXWAR100002')
         and pet.PARENT_PRODUCT_CATEGORY not in ('PORTABLE GENERATOR','PORTABLE GENERATOR','POWER WASHER')
         --AND COUNTRY = 'CANADA'
         order by ppt.POLICY_PRODUCT_XID,pet.POLICY_KEY;