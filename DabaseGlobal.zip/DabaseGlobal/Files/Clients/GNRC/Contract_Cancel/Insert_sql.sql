CREATE TABLE contract_cancellation_client_input AS (
select

           TYPE,
           CUSTOMER_NAME       ,
            SERIAL_NUMBER       ,
            STATE                ,
            PURCHASE_DATE         ,
            CANCEL_REQUEST_DATE    ,
            CANCEL_REASON           ,
            PRODUCT_NAME             ,
            CONTRACT_AMOUNT               ,
            TOTAL_CUSTOMER_PAID_AMOUNT        ,
            TAX_AMOUNT_IF_APPLICABLE       ,
            PAID_CONTRACT_AMOUNT       ,
            PAID_TAX_AMOUNT_IF_APPLICABLE ,
            FULL_OR_PRO_RATED_REFUND       ,
            CONTRACT_REFUND_AMOUNT          ,
            TAX_REFUND_AMOUNT_IF_APPLICABLE  ,
            TOTAL_REFUND_AMOUNT             ,
            REFUND_PERCENTAGE  ,
            APPROVED_DATE ,
            NOTES_COMMENTS,
            CD.CONTRACT_KEY,
            OI.FLEXPAY_IND,
            CD.CONTRACT_STATUS_KEY,
            CSD.DESCRIPTION,
            trunc(oi.PURCHASE_DT) as ORDER_PURCHASE_DT,
            oi.ORDER_KEY,
            oi.ORDER_LINE_KEY,
            oi.PRICE_AMT,
            oi.TAX_AMT,
            oi.PRICE_AMT + oi.TAX_AMT as total_amt

from (
     select
        'COMPLETED_3RD'  AS TYPE,
        CUSTOMER_NAME    ,
        SERIAL_NUMBER    ,
        STATE             ,
        PURCHASE_DATE      ,
        CANCEL_REQUEST_DATE    ,
        CANCEL_REASON         ,
        PRODUCT_NAME         ,
        CONTRACT_AMOUNT                  ,
        TOTAL_CUSTOMER_PAID_AMOUNT         ,
        0.01 AS TAX_AMOUNT_IF_APPLICABLE      ,
        PAID_CONTRACT_AMOUNT               ,
        PAID_TAX_AMOUNT_IF_APPLICABLE       ,
        FULL_OR_PRO_RATED_REFUND            ,
        CONTRACT_REFUND_AMOUNT              ,
        TAX_REFUND_AMOUNT_IF_APPLICABLE     ,
        TOTAL_REFUND_AMOUNT                 ,
        round(TOTAL_REFUND_AMOUNT/TOTAL_CUSTOMER_PAID_AMOUNT ,4)  as REFUND_PERCENTAGE                  ,
        APPROVED_DATE                    ,
        NOTES_COMMENTS
        from COMPLETED_3RD_GENERAC_CANCELS_CLIENT_APPROVAL_MAY03_2024_FORMATED

        UNION
        select
            'COMPLETED_2ND'  AS TYPE,
            CUSTOMER_NAME    ,
            SERIAL_NUMBER     ,
            STATE           ,
            PURCHASE_DATE     ,
            CANCEL_REQUEST_DATE      ,
            CANCEL_REASON        ,
            PRODUCT_NAME        ,
            CONTRACT_AMOUNT              ,
            0.01 AS TOTAL_CUSTOMER_PAID_AMOUNT   ,
            TAX_AMOUNT_IF_APPLICABLE     ,
            CUSTOMER_PAID_AMOUNT AS PAID_CONTRACT_AMOUNT      ,
            0.01 AS PAID_TAX_AMOUNT_IF_APPLICABLE     ,
            FULL_OR_PRO_RATED_REFUND           ,
            CONTRACT_REFUND_AMOUNT           ,
            TAX_REFUND_AMOUNT_IF_APPLICABLE    ,
            TOTAL_REFUND_AMOUNT                ,
            round(CONTRACT_REFUND_AMOUNT /CONTRACT_AMOUNT ,4)       as REFUND_PERCENTAGE                  ,
            APPROVED_DATE_GNC                  ,
            NOTES_COMMENTS

        from COMPLETED_2ND_GENERAC_CANCELS_CLIENT_APPROVAL_MAY03_2024_FORMATED
        UNION
       select
                'COMPLETED'  AS TYPE,
                CUSTOMER_NAME ,
                TO_NUMBER(SERIAL_NUMBER) AS SERIAL_NUMBER ,
                STATE           ,
                PURCHASE_DATE     ,
                CANCEL_REQUEST_DATE ,
                CANCEL_REASON         ,
                EXTENDED_WARRANTY_TYPE AS PRODUCT_NAME      ,
                0.01 AS CONTRACT_AMOUNT        ,
                0.01 AS TOTAL_CUSTOMER_PAID_AMOUNT ,
                0.01 AS TAX_AMOUNT_IF_APPLICABLE     ,
                CUSTOMER_PAID_AMOUNT    AS PAID_CONTRACT_AMOUNT           ,
                0.01 AS PAID_TAX_AMOUNT_IF_APPLICABLE ,
                FULL_OR_PRO_RATED_REFUND   ,
                0.01 CONTRACT_REFUND_AMOUNT     ,
                0.01 AS TAX_REFUND_AMOUNT_IF_APPLICABLE ,
                REFUND_AMOUNT    AS TOTAL_REFUND_AMOUNT          ,
                round(REFUND_AMOUNT/CUSTOMER_PAID_AMOUNT,4)   as REFUND_PERCENTAGE                  ,
                APPROVED_DATE_GNC          ,
                NOTES_COMMENTS
    from COMPLETED_GENERAC_CANCELS_CLIENT_APPROVAL_MAY03_2024_FORMATED
        UNION
        Select
            'NEW_GENERAC'  AS TYPE,
            CUSTOMER_NAME ,
            SERIAL_NUMBER  ,
            STATE           ,
            PURCHASE_DATE    ,
            CANCEL_REQUEST_DATE ,
            CANCEL_REASON        ,
            PRODUCT_NAME          ,
            CONTRACT_AMOUNT               ,
            TOTAL_CUSTOMER_PAID_AMOUNT     ,
            0.01 AS TAX_AMOUNT_IF_APPLICABLE   ,
            PAID_CONTRACT_AMOUNT            ,
            PAID_TAX_AMOUNT_IF_APPLICABLE    ,
            FULL_OR_PRO_RATED_REFUND         ,
            CONTRACT_REFUND_AMOUNT           ,
            TAX_REFUND_AMOUNT_IF_APPLICABLE  ,
            TOTAL_REFUND_AMOUNT              ,
            round(TOTAL_REFUND_AMOUNT/TOTAL_CUSTOMER_PAID_AMOUNT,4)        as REFUND_PERCENTAGE                  ,
            APPROVED_DATE                   ,
            NOTES_COMMENTS
        from NEW_GENERAC_CANCELS_CLIENT_APPROVAL_MAY03_2024_FORMATED
        UNION
        Select
          'NONPAY_GENERAC'  AS TYPE,
           CUSTOMER_NAME       ,
            SERIAL_NUMBER       ,
            STATE                ,
            PURCHASE_DATE         ,
            CANCEL_REQUEST_DATE    ,
            CANCEL_REASON           ,
            PRODUCT_NAME             ,
            CONTRACT_AMOUNT               ,
            0.01 AS TOTAL_CUSTOMER_PAID_AMOUNT        ,
            TAX_AMOUNT_IF_APPLICABLE       ,
            CUSTOMER_PAID_AMOUNT  AS PAID_CONTRACT_AMOUNT       ,
            0.01 AS PAID_TAX_AMOUNT_IF_APPLICABLE ,
            FULL_OR_PRO_RATED_REFUND       ,
            CONTRACT_REFUND_AMOUNT          ,
            TAX_REFUND_AMOUNT_IF_APPLICABLE  ,
            TOTAL_REFUND_AMOUNT             ,
            round(TOTAL_REFUND_AMOUNT/CUSTOMER_PAID_AMOUNT,4)  as REFUND_PERCENTAGE                  ,
            APPROVED_DATE_GNC ,
            NOTES_COMMENTS
        from NONPAY_GENERAC_CANCELS_CLIENT_APPROVAL_MAY03_2024_FORMATED
              ) t
join gnrc.SERIALIZED_ITEM_DIM si on si.SERIAL_NO = to_char(t.SERIAL_NUMBER)
       join gnrc.ORDER_ITEM_TBL oi on oi.SERIALIZED_ITEM_KEY = si.SI_KEY
        LEFT JOIN GNRC.CONTRACT_ORDER_TBL COTT ON COTT.ORDER_KEY = oi.ORDER_KEY
        LEFT JOIN GNRC.CONTRACT_DIM  CD ON CD.CONTRACT_KEY = COTT.CONTRACT_KEY
        LEFT JOIN GNRC.CONTRACT_STATUS_DIM CSD ON CSD.CONTRACT_STATUS_KEY = CD.CONTRACT_STATUS_KEY
 where 1=1
  and (trunc(oi.PURCHASE_DT) = t.PURCHASE_DATE or  t.SERIAL_NUMBER in ('3003842646','3008505371','3008525125')
     )
)
;

commit;



Update contract_cancellation_client_input
    SET REFUND_PERCENTAGE =  round(TOTAL_REFUND_AMOUNT/TOTAL_CUSTOMER_PAID_AMOUNT ,5)
where  TYPE = 'COMPLETED_3RD';

Update contract_cancellation_client_input
SET REFUND_PERCENTAGE = round(CONTRACT_REFUND_AMOUNT /CONTRACT_AMOUNT ,5)
where  TYPE = 'COMPLETED_2ND';

Update contract_cancellation_client_input
SET REFUND_PERCENTAGE = round(TOTAL_REFUND_AMOUNT/PAID_CONTRACT_AMOUNT,5)
where  TYPE = 'COMPLETED';

Update contract_cancellation_client_input
SET REFUND_PERCENTAGE =  round(TOTAL_REFUND_AMOUNT/TOTAL_CUSTOMER_PAID_AMOUNT,5)
where  TYPE = 'NEW_GENERAC';

Update contract_cancellation_client_input
SET REFUND_PERCENTAGE = round(TOTAL_REFUND_AMOUNT/PAID_CONTRACT_AMOUNT,5)
where  TYPE = 'NONPAY_GENERAC';