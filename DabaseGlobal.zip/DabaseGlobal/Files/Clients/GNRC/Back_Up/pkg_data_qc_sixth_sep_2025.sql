create PACKAGE BODY         pkg_data_qc
AS
   /***************************************************************************/
   C_CRLF                 CONSTANT VARCHAR2(4)       := CHR(13) || CHR(10);


   PROCEDURE proc_data_qc
   IS
      l_count                       NUMBER;
      l_qc_text                     VARCHAR2(10000):= NULL;
      l_temp_text                   VARCHAR2(10000):= NULL;
      l_count2                      NUMBER;

   BEGIN


      l_count := 0;
      SELECT COUNT(*) INTO l_count
        FROM (
              select contract_key from p_contract_dim
              minus
              select contract_key from p_contract_lkp
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' contracts in contract_dim, which dont exist in contract_lkp.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      --------------

      l_count := 0;
      SELECT COUNT(*) INTO l_count
        FROM (
             select contract_key from p_contract_lkp
             minus
             select contract_key from p_contract_dim
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' contracts in contract_lkp, which dont exist in contract_dim.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      --------------


      l_count := 0;
      SELECT COUNT(*) INTO l_count
        FROM (
             select contract_xid, source_system_cd, count(* ) from p_contract_lkp
             group by contract_xid, source_system_cd
             having count(*) >= 2
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' contracts having dupes in contract_lkp on contract_xid and source_system_cd';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      --------------


      l_count := 0;
      SELECT COUNT(*) INTO l_count
        FROM (
             select contract_key, source_system_cd, count(* ) from p_contract_lkp
             group by contract_key, source_system_cd
             having count(*) >= 2
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' contracts having dupes in contract_lkp on contract_key and source_system_cd';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_LKP', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      --------------


      SELECT COUNT(DISTINCT contract_key) INTO l_count
        FROM (
              SELECT
                     contract_key,
                     si_key,
                     COUNT (*)
                     ,MAX (contract_sale_dt)
                FROM p_contract_dim
                      JOIN p_contract_coverage_xref ccx USING (contract_key)
                       JOIN p_serialized_item_dim si USING (si_key)
                        --JOIN V_PRODUCT USING (product_key)
               WHERE coverage_type_key = 2
               GROUP BY contract_key, si_key
              HAVING COUNT (*) >= 2
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' contracts with duplicate records in contract_coverage_xref.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_COVERAGE_XREF', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;




      l_count := 0;
      select count(*) into l_count
        from (
              --if there are 2 or more active "non upgrade" contracts
              select si_key, count(distinct contract_key)
                from p_serialized_item_dim
                     join p_contract_coverage_xref using (si_key)
                     join p_contract_lkp clkp using (contract_key)
                     join p_contract_dim con using (contract_key)
                     join p_policy_tbl pol using (policy_key)
               where coverage_type_key = 2
                 and con.contract_status_key NOT IN (2, 3, 5)
                 and lower(pol.name) not like '%upgrade%'
               group by si_key
              having count(distinct contract_key) >= 2
             union all
              --if there are 2 or more active "upgrade" contracts
              select si_key, count(distinct contract_key)
                from p_serialized_item_dim
                     join p_contract_coverage_xref using (si_key)
                     join p_contract_lkp clkp using (contract_key)
                     join p_contract_dim con using (contract_key)
                     join p_policy_tbl pol using (policy_key)
               where coverage_type_key = 2
                 and con.contract_status_key NOT IN (2, 3, 5)
                 and lower(pol.name) like '%upgrade%'
               group by si_key
              having count(distinct contract_key) >= 2
            );


      --Creating QC record to warn only if there are more than 1 serials with this issue
      --This will help to avoid repeated daily QC alert emails
      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' si_key(s), which are appearing against multiple active contracts.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;



      l_count := 0;
      select count(*) into l_count
        from (
              --2 or more active "non-upgrade" orders
              SELECT serialized_item_key, count(*), count(distinct oit.order_key)
                FROM p_order_tbl o
                     JOIN p_order_item_tbl oit on (oit.order_key = o.order_key)
                     join p_policy_tbl pol using (policy_key)
                     left join p_contract_order_tbl co on (co.order_key = oit.order_key and co.order_line_key = oit.order_line_key)
                     left join p_contract_dim con on (con.contract_key = co.contract_key)
                     left join p_contract_status_dim cons on (cons.contract_status_key = con.contract_status_key)
               WHERE oit.price_amt > 1
                AND ( con.contract_status_key IS NULL OR con.contract_status_key NOT IN (2, 3, 5) )
                AND lower(pol.name) not like '%upgrade%'
               GROUP BY serialized_item_key
              HAVING COUNT(distinct oit.order_key) >= 2

            union all
           --2 or more active "upgrade" orders
           SELECT serialized_item_key, count(*), count(distinct oit.order_key)
                FROM p_order_tbl o
                     JOIN p_order_item_tbl oit on (oit.order_key = o.order_key)
                     join p_policy_tbl pol using (policy_key)
                     left join p_contract_order_tbl co on (co.order_key = oit.order_key and co.order_line_key = oit.order_line_key)
                     left join p_contract_dim con on (con.contract_key = co.contract_key)
                     left join p_contract_status_dim cons on (cons.contract_status_key = con.contract_status_key)
               WHERE oit.price_amt > 1
                AND ( con.contract_status_key IS NULL OR con.contract_status_key NOT IN (2, 3, 5) )
                AND lower(pol.name) like '%upgrade%'
               GROUP BY serialized_item_key
              HAVING COUNT(distinct oit.order_key) >= 2
             );


       IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' si_key(s), which are appearing against multiple orders.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'ORDER_ITEM_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;


      l_count := 0;
      select count(*) into l_count
        from (
              select cot2.order_key, cot2.order_line_key
                from p_contract_order_tbl cot2
               group by cot2.order_key, cot2.order_line_key
               having count(*) >= 2
            );


       IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' duplicate order_key and order_line_key combinations in contract_order_tbl.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;



      l_count := 0;
      select count(*) into l_count
        from (
              select contract_key
                from p_contract_order_tbl cot2
               group by contract_key
               having count(*) >= 2
            );


       IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' contracts having duplicate entries in contract_order_tbl.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_ORDER_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;



      --Serial belongs to one or more orders  and if contract is active then  latest_coverage_type should be 2. If not 2 then problem.
      l_count := 0;
      select count(*) into l_count
        from (
              select distinct cc.contract_key, cc.contract_status_key, si.si_key, si.latest_coverage_type
                from p_contract_dim cc
                    join p_contract_coverage_xref ccx
                      ON (cc.contract_key = ccx.contract_key)
                    join p_serialized_item_dim si
                      ON (si.si_key = ccx.si_key)
               where
                     (cc.contract_status_key = 1 and si.latest_coverage_type <> 2)
                 and coalesce(si.SERIAL_NO, 'XYZ123') not in ('3011659383')   --Exception...CCS-17420
             );

       IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' Active contracts/serials with a latest_coverage_type other then 2.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;


      --serials with single order and contract is cancelled then latest_coverage_type should be one of:
      -- 3 which represents cancels
      -- 5 which is for dealer sale
      -- 18, 20, 21 where serial has been suppressed permanently
      l_count := 0;
      select count(*) into l_count
        from (
              select distinct cc.contract_key, cc.contract_status_key, si.si_key, si.latest_coverage_type
              from p_contract_dim cc
                    join p_contract_coverage_xref ccx
                    ON (cc.contract_key = ccx.contract_key)
                    join p_serialized_item_dim si
                    ON (si.si_key = ccx.si_key)
             where
                     (cc.contract_status_key = 2 and si.latest_coverage_type NOT IN (3, 5, 18, 20, 21))

                     and si.si_key NOT IN (--initially we were checking DISTINCT order_key only, which was working fine
                                    --however, order 434551 from Feb 2021 had same serial in 2 line items of same order
                                    -- and so changed it to DISTINCT order_key || ORDER_LINE_KEY   --AJ on 3/19/2021
                            SELECT oit.serialized_item_key
                              FROM p_order_item_tbl oit
                          GROUP BY serialized_item_key
                            HAVING COUNT (DISTINCT order_key || order_line_key) > 1
                          )
             );

       IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' cancelled contracts/serials with single order but latest_coverage_type is not 3.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;


     --serials where there exists multiple order and contract is cancelled and there exists no  another contract as active then latest_coverage_type should be 3

      l_count := 0;
      select count(*) into l_count
        from (
              select distinct cc.contract_key, cc.contract_status_key, si.si_key, si.latest_coverage_type
              from p_contract_dim cc
                    join p_contract_coverage_xref ccx
                    ON (cc.contract_key = ccx.contract_key)
                    join p_serialized_item_dim si
                    ON (si.si_key = ccx.si_key)
             where
                     (cc.contract_status_key = 2 and si.latest_coverage_type <> 3)
                     and si.si_key  IN (
                            SELECT oit.serialized_item_key
                              FROM p_order_item_tbl oit
                          GROUP BY serialized_item_key
                            HAVING COUNT (DISTINCT order_key) > 1
                          )

                      and not  exists  ( select CD1.CONTRACT_KEY
                                              from GNRC.CONTRACT_DIM CD1
                                              join GNRC.CONTRACT_COVERAGE_XREF ccx1
                                                ON ( CCX1.CONTRACT_KEY = CD1.CONTRACT_KEY)
                                              join GNRC.SERIALIZED_ITEM_DIM si1
                                                ON ( SI1.SI_KEY = CCX1.SI_KEY)
                                             where CD1.CONTRACT_STATUS_KEY IN (1, 8, 5)
                                               and ccx1.COVERAGE_TYPE_KEY = 2
                                               and CCX1.SI_KEY IN      -- Serial have multiple orders
                                                  ( select  oit.serialized_item_key
                                                      from gnrc.order_item_tbl oit
                                                      group by oit.serialized_item_key
                                                     having count(distinct oit.order_key) > 1
                                                   )
                                               and  CD1.CONTRACT_KEY <> cc.CONTRACT_KEY -- contract is not the one we are processing
                                               and  CCX1.SI_KEY = SI.SI_KEY  -- serial is same as in the contract under process
                                            )
             );



       IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' cancelled contracts/serials with multiple orders and no contract is active and latest_coverage_type is not 3.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;



      l_count := 0;
      select count(*) into l_count
        from (
            select si_key, serial_no, latest_coverage_type
              from p_serialized_item_dim
             where latest_coverage_type = 1
               and si_key IN (
                      SELECT serialized_item_key
                        FROM p_order_tbl o
                             JOIN p_order_item_tbl oi on (oi.order_key = o.order_key)
                        where o.ORDER_KEY <> 743655 --GNRC-1380
                      )
            );


       IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' serials with orders but latest_coverage_type is 1.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SERIALIZED_ITEM_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;



      --GNRC-284
      l_count := 0;
      select count(*)
        into l_count
        from p_order_tbl ot join p_order_item_tbl oit on oit.order_key = ot.order_key
       where not exists (
               select P.order_key
                 from p_PAYMENT_TX_TBL P join gnrc.audit_tbl a on (audit_key = insert_audit_key)
                where P.order_key = ot.order_key
                  and P.payment_type = 'CHECK_BYPASS' and lower(payment_tx_key) like 'fp%'
               )
         and ot.order_key IN (
               select P.order_key
                 from p_PAYMENT_TX_TBL P join gnrc.audit_tbl a on (audit_key = insert_audit_key)
                where P.payment_type = 'CHECK_BYPASS'
             )
      --and SALES_SOURCE_CD <> 'MAIL_IN_CHECK_SALES'
         and flexpay_ind = 'Y'
         and ot.purchase_dt >= trunc(sysdate) - 60;


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' CHECK_BYPASS orders but payment_tx_key is not prefixed with fp';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'PAYMENT_TX_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;



      --This is a client specific check and may not be applicable to every client so review and keep/comment out accordingly
      l_count := 0;
      select count(*)
        into l_count
        from p_serialized_item_dim si
       where latest_coverage_type NOT IN (19, 20)
        and si.si_key not in (
               select six.si_key
                 from p_serialized_item_ext_dim six
               )
       ;


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' si_keys, which do not exist in p_serialized_item_ext_dim';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SERIALIZED_ITEM_EXT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;



      l_count := 0;
      --Checking status of unpaid CC ordres
      select count(*) into l_count
       from (
              select trunc(sbf.payment_due_dt), count(distinct sbf.order_key) as payments_due, count(sbf.payment_collected_dt) as payments_collected
               from p_scheduled_billing_fct sbf
                    join gnrc.order_tbl ot on (ot.order_key = sbf.order_key)
              where trunc(sbf.payment_due_dt) between trunc(sysdate) - 30 and trunc(sysdate) - 2
                and NVL(PAYMENT_STATUS_CD, 'XYZ') NOT IN ('CANCEL')  --, 'PAID'
                and SALES_SOURCE_CD <> 'MAIL_IN_CHECK_SALES'
              group by trunc(sbf.payment_due_dt)
              --Filtering out dates with only a handful of orders to avoid false alarm
              having count(distinct sbf.order_key) >= 5 and count(sbf.payment_collected_dt) = 0
              --order by trunc(sbf.payment_due_dt)
               );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' due dates with more than 5 orders but none got charged.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SCHEDULED_BILLING_FCT', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;


      --NCOAed customers should not have primary_email_key set in Customer_Dim
      --Though ignore customers with orders as they may have updated their details while placing order
      /* Now we are not NULLifying primary_email_key of NCOAed customers anymore as now
        we are creating new customer record for new owner of the address and the previous/moved
        customer can retian his/her email record
      select count(cust.primary_email_key)
             --, a.creation_dt as updated_dt, em.email_address_tx, ced.ncoa_flag
        into l_count
        from gnrc.customer_dim cust  --left join audit_tbl a on (a.audit_key = cust.update_audit_key)
             left join gnrc.email_dim em
                on (em.email_key = cust.primary_email_key)
             join gnrc.customer_ext_dim ced
               on ced.customer_key = cust.customer_key
       where cust.primary_email_key is not null
         and cust.customer_key NOT IN
                ( select vd.customer_key
                    from gnrc.order_tbl ot
                         join gnrc.visitor_dim vd
                            on vd.visitor_key = ot.visitor_key
                )
      ;

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' NCOAed customers with email_key in Customer_Dim.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;
      END IF;
      */
      --------------


      --This is a client specific check and may not be applicable to every client so review and keep/comment out accordingly
      --This QC check was copied from PROCEDURE GNRCSTG.sp_sales_extract_file_data
      --1/17/2022: Now sales extract has been turned into a bi-weekly process and hence the daily QA check won't work so
      --we are modifying it to look at sales, which were created in DW at least 4 days ago
      l_count := 0;
      select count(*) into l_count
        from (
             select to_char(oit.order_key), oit.ORDER_LINE_Key
               from gnrc.order_item_tbl oit join AUDIT_TBL ai on ai.AUDIT_KEY = oit.INSERT_AUDIT_KEY
                    join gnrc.SERIALIZED_ITEM_DIM sid on oit.SERIALIZED_ITEM_KEY = sid.SI_KEY
                    join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = sid.PRODUCT_KEY
                    join gnrc.PRODUCT_CATEGORY_DIM pcd on pcd.PRODUCT_CATEGORY_KEY = pd.PRODUCT_CATEGORY_KEY
              where ai.CREATION_DT < trunc(sysdate) - 4
              and pcd.MARKETING_PRODUCT_CATEGORY_NM not in ('GAS GENERATOR', 'GEMINI GENERATOR', 'DIESEL GENERATOR')
             minus
             (select seft2.ORDER_NO, seft2.ORDER_LINE_NO from SALES_EXTRACT_FILE_TBL seft2
              union all
              select seft2.ORDER_NO, seft2.ORDER_LINE_NO from GNRC.SALES_EXTRACT_FILE_TBL seft2
             ));


      IF NVL(l_count, 0) <> 0 THEN

         l_temp_text := ' There are ' || l_count || ' sales, which have not been assigned a contract.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SALES_EXTRACT_FILE_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;



      --This is a client specific check and will not be applicable to other clients so review and comment out accordingly
      --SKUs/Contracts, which need to be ordered soon/immediately
      l_count := 0;
      SELECT COUNT(*) INTO l_count
        FROM (
            SELECT policy_sku, pex_description, Contracts_received, Contracts_Assigned, Contracts_Available
                   ,ROUND((Contracts_Available/Contracts_received)*100) as "%Avail"
                   ,Unassigned_Sales
              FROM (
                    SELECT act.policy_sku, pex_description,
                           count(*) as Contracts_received,
                           sum(case when seft.contract_no is not null then 1 else 0 end) as Contracts_Assigned,
                           sum(case when seft.contract_no is not null then 0 else 1 end) as Contracts_Available
                           ,max(Unassigned_Sales) as Unassigned_Sales
                      FROM GNRC.AVAILABLE_CONTRACT_TBL act
                           LEFT JOIN GNRC.SALES_EXTRACT_FILE_TBL seft on (act.contract_no = seft.contract_no)
                           --JOIN gnrc.policy_tbl pol on pol.Policy_Product_Xid = act.Policy_SKU Join gnrc.policy_ext_tbl pex on (pex.policy_key = pol.policy_key)
                          --we can have multiple policy_keys for a given Policy_Product_Xid
                          JOIN (select POLICY_PRODUCT_XID, pex_description
                                   from (select pol.POLICY_PRODUCT_XID, pex.DESCRIPTION as pex_DESCRIPTION, row_number() over (partition by pol.POLICY_PRODUCT_XID order by pol.INSERT_AUDIT_KEY) as rn
                                           from gnrc.policy_tbl pol Join gnrc.policy_ext_tbl pex on (pex.policy_key = pol.policy_key)
                                ) pol
                                where rn = 1) pol
                              ON pol.Policy_Product_Xid = act.Policy_SKU
                           LEFT JOIN (
                               SELECT pol.Policy_Product_Xid, count(oit.order_key) as Unassigned_Sales
                                 FROM gnrc.order_item_tbl oit
                                      JOIN gnrc.policy_tbl pol on pol.policy_key = oit.policy_key
                                      JOIN gnrc.policy_ext_tbl pex on (pex.policy_key = pol.policy_key)
                                      LEFT JOIN GNRC.SALES_EXTRACT_FILE_TBL seft2 on (seft2.ORDER_NO = oit.ORDER_Key and seft2.ORDER_LINE_NO = oit.ORDER_LINE_Key)
                                WHERE seft2.order_no is null
                                GROUP BY pol.Policy_Product_Xid
                                    ) oit
                                ON oit.Policy_Product_Xid = act.Policy_SKU
                      GROUP BY act.policy_sku, pex_description
                     )
             --ORDER BY policy_sku
             )
       WHERE "%Avail" <= 5;



      IF NVL(l_count, 0) <> 0 THEN

         l_temp_text := ' There are ' || l_count || ' SKUS, which need to be ordered immediately';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'AVAILABLE_CONTRACT_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');

      END IF;



      --Data integrity issues with p_surcharge_assessment_tbl
      l_count := 0;
      select count(*)
        into l_count
        from p_surcharge_assessment_tbl where nvl(tax_amt, 0) > nvl(surcharge_amt, 0);


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' records in p_surcharge_assessment_tbl where tax_amt > surcharge_amt';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SURCHARGE_ASSESSMENT_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;



      --Data integrity issues with p_surcharge_assessment_tbl
      l_count := 0;
      select count(*)
        into l_count
        from p_surcharge_assessment_tbl join p_order_tbl using (order_key)
       where tax_detail_key is null;


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' records in p_surcharge_assessment_tbl where tax_detail_key is null';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SURCHARGE_ASSESSMENT_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;


      --GNRC-602: tax_detail_keys used with multiple orders
      l_count := 0;
      select count(*)
      into   l_count
      from   (
              select tax_detail_key, count(distinct order_key), min(sales_source_cd), max(sales_source_cd)
              from   p_surcharge_assessment_tbl sat join p_order_tbl ot using (order_key)
              where  ot.purchase_dt >= date '2019-09-24'  --date when changes were applied
              group by tax_detail_key having count(distinct order_key) >= 2
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' tax_detail_keys in p_surcharge_assessment_tbl, which are used with multiple orders';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SURCHARGE_ASSESSMENT_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;




      --GNRC-611: tax_amt is 0 in p_surcharge_assessment_tbl (mismatch with p_tax_detail_tbl)
      l_count := 0;
      select count(*)
      into   l_count
      from   (
              select * from p_surcharge_assessment_tbl sat join p_tax_detail_tbl tdt using (tax_detail_key)
              where  tdt.tax_amt > sat.tax_amt
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' records in surcharge_assessment_tbl where tax_amt does not match with that in tax_detail_tbl';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SURCHARGE_ASSESSMENT_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      ----



     --same tax_detail_key is shared between order tax and surcharge tax
      l_count := 0;
      select count(distinct order_key)
      into   l_count
      from   (
              select ot.order_key, oit.order_line_key, ot.purchase_dt, tx.tax_detail_key, stx.tax_detail_key
              from   gnrc.ORDER_TBL ot
                      JOIN gnrc.ORDER_ITEM_TBL oit
                         ON (oit.order_key = ot.order_key)
                      JOIN gnrc.tax_detail_tbl tx
                         ON (tx.tax_detail_key = oit.tax_detail_key)
                      LEFT JOIN GNRC.SURCHARGE_ASSESSMENT_TBL sat
                         ON (sat.order_key = oit.order_key) --this join works in both DW and Web and hence safer to use
                      LEFT JOIN GNRC.TAX_DETAIL_TBL stx
                         ON (stx.tax_detail_key = sat.tax_detail_key)
              where
                       ot.purchase_dt >= date '2019-09-24'  --date when changes were applied
              AND    tx.tax_detail_key = stx.tax_detail_key
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' orders where tax_detail_key is shared between order tax and surcharge tax ';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'TAX_DETAIL_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;


      COMMIT;


      --Order/Contract is cancelled but FP is still active
      l_count := 0;
      select count(distinct order_key)
      into   l_count
      from   (
              select *
                from P_SCHEDULED_BILLING_FCT T1
                where EXISTS
                  (select 1
                   from (select order_key
                         from P_CONTRACT_ORDER_TBL cot
                         where exists(select 1 from p_contract_cancellation_dim cc where cot.contract_key = cc.contract_key)
                        ) T2
                   where t1.order_key = t2.order_key)
                  and PAYMENT_TX_ID IS NULL
                  and NVL(upper(trim(PAYMENT_STATUS_CD)), 'ACTIVE') NOT IN ('CANCEL', 'FLEXPAY_TERMINATED')
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' cancelled orders with an active flexpay ';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SCHEDULED_BILLING_FCT', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;


      --Payment_Status_cd of seq 1 is null
      l_count := 0;
      select count(distinct order_key)
      into   l_count
      from   (
              select * from p_SCHEDULED_BILLING_FCT
                WHERE trim(payment_status_cd) IS NULL
                AND SEQ_NO = 1
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' orders where Payment_Status_cd of seq 1 is null ';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SCHEDULED_BILLING_FCT', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;


      --Payment_collected_amt is non zero but Payment_Status_cd is null
      l_count := 0;
      select count(distinct order_key)
      into   l_count
      from   (
              select u.creation_dt, sbf.* from gnrc.scheduled_billing_fct sbf LEFT JOIN audit_tbl u on (u.audit_key = sbf.update_audit_key)
                where  1=1
                and    payment_collected_dt >= date '2020-06-01'  --to exclude a historical record in error
                and    trim(payment_status_cd) is null
                and    nvl(payment_collected_amt, 0) <> 0
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' orders where Payment_collected_amt is non zero but Payment_Status_cd is null ';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SCHEDULED_BILLING_FCT', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;



       --Dealer Leads
      l_count := 0;
      select count(distinct serial_no)
      into   l_count
      from   (
              select LATEST_COVERAGE_TYPE, serial_no
              from   gnrc.RAW_DEALER_LEADS_TBL rl
                     join gnrc.SERIALIZED_ITEM_DIM si on serial_no = trim(ltrim(rl.equipment, '0'))
                     --left join GNRC.RAW_RESI_DEALER_SUPPRESS_TBL rr on LTRIM(TRIM(rr.EQUIPMENT), '0') = LTRIM(TRIM(rl.EQUIPMENT), '0')
              where  1=1
              and    ERROR_DESC is null and si.LATEST_COVERAGE_TYPE not in (2, 3, 5, 17, 20, 21, 11, 7)
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' valid dealer leads where LATEST_COVERAGE_TYPE not in (2, 3, 5, 17, 20, 21, 11, 7) ';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SERIALIZED_ITEM_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;



       --Checking if there are dupes in sales views/campaign responses
      --Root cause: This happens when we use diff campaign name for outbound campaign
      --Solution: use exactly same campaign_nm for DM/EM/OB for a given campaign in campaign_dim
      l_count := 0;
      select *
      into   l_count
      from   (
              select count(*) - count(distinct ORDER_Key || ORDER_Line_Key) as diff
                from   gnrc.v_contract_sales_detail
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' dupes in gnrc.v_contract_sales_detail';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'V_CONTRACT_SALES_DETAIL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;


      l_count := 0;
      SELECT COUNT(*) INTO l_count
        FROM (
              (select MATERIAL from gnrc.RAW_DEALER_LEADS_TBL where MATERIAL is not null and ERROR_DESC is null
              union
              select MATERIAL from gnrc.RAW_LEADS_TBL where MATERIAL is not null and ERROR_DESC is null
              )
              minus
              select MODEL_NO from gnrc.PRODUCT_DIM
             );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' models in RAW_LEADS_TBL/RAW_DEALER_LEADS_TBL, which do not exist in PRODUCT_DIM.';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      COMMIT;


      l_count := 0;
      SELECT COUNT(*) INTO l_count
        FROM gnrc.SERIALIZED_ITEM_DIM where PRODUCT_KEY is null;

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' leads in SERIALIZED_ITEM_DIM where PRODUCT_KEY is NULL';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      COMMIT;



      l_count := 0;
      --findings pricing data where old policies got assigned to new pricing schemes or vice-versa
      --or Canadian policies got assigned to USA pricing schemes
      --6/1/2022: Policy_Key 143 is an exception as we retained this policy_key (pricing) as there was no change in this pricing (7 year term)
      --However, mapped it to new pricing schemes in combination of other newer policies
      select count(*) into l_count
        from gnrc.PRODUCT_PRICE_DIM ppd join gnrc.PRICING_SCHEME_DIM psd using (pricing_scheme_key)
             join gnrc.POLICY_TBL pol using (policy_key)
             join gnrc.POLICY_EXT_TBL pex using (policy_key)
        where 1=1
          and ((psd.end_dt >= trunc(sysdate) and pol.EXP_DT < trunc(sysdate))
              --or(psd.end_dt < trunc(sysdate) and pol.EXP_DT >= trunc(sysdate) and POLICY_KEY <> 143)--GNRC-1816
              or
              (upper(coalesce(pex.COUNTRY, 'USA')) = 'CANADA' and upper(psd.PRICING_SCHEME_NM) not like '%CANADA%' and psd.end_dt >= trunc(sysdate))
              or --Following/Reverse will not work as we use USA policies for Canadian pricing schemes also
              (upper(coalesce(pex.COUNTRY, 'USA')) = 'USA' and upper(psd.PRICING_SCHEME_NM) like '%CANADA%' and psd.end_dt >= trunc(sysdate))
              );


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' mismatched pricing records in product_price_dim. Check immediately!';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'PRODUCT_PRICE_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      COMMIT;


      l_count := 0;
      --GNRC-1822
       select COUNT(T2.MODEL_CNT - T1.MODEL_CNT) into l_count from (
                    select 'GNRC' AS C1,PSD.PRICING_SCHEME_NM,PEX.COUNTRY,COUNT(distinct VP.PRODUCT_KEY ) MODEL_CNT,COUNT(distinct PRD.POLICY_KEY ) POLICY_KEY_CNT
                    , listagg(distinct TERM_KEY, ', ') WITHIN GROUP (ORDER BY TERM_KEY) as Terms
                    , listagg(distinct pex.WHEN_USED,', ') WITHIN GROUP (ORDER BY pl.POLICY_KEY) as POLICY_KEYs
                    from GNRC.PRODUCT_PRICE_DIM PRD
                                    JOIN V_PRODUCT VP on PRD.PRODUCT_KEY = VP.PRODUCT_KEY
                                    JOIN GNRC.PRICING_SCHEME_DIM PSD on PRD.PRICING_SCHEME_KEY = PSD.PRICING_SCHEME_KEY
                                    JOIN GNRC.POLICY_TBL PL on PL.POLICY_KEY = PRD.POLICY_KEY
                                    JOIN GNRC.POLICY_EXT_TBL PEX on PEX.POLICY_KEY = PL.POLICY_KEY
                    Where PSD.END_DT > sysdate and PL.EXP_DT > sysdate
                    AND PRODUCT_CATEGORY_NM  like '%HSB%'
                               AND DO_NOT_SOLICIT_BRAND_IND = 'N'
                               AND DO_NOT_SOLICIT_CATEGORY_IND = 'N'
                               AND DO_NOT_SOLICIT_PRODUCT_IND = 'N'
                               AND PRD.PRICING_SCHEME_KEY in (
                                                        select ccx.pricing_scheme_key
                                                              from  gnrc.CRITERIA_CELL_XREF ccx
                                                                   join gnrc.criteria_dim cr using (criteria_key)
                                                                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                                                             where 1=1
                                                               and active_ind = 'Y'
                                                               and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
                                                               and selection_tbl <> 'v_outbound_universe'
                                                             GROUP BY ccx.pricing_scheme_key
                                                )

                    GROUP BY PSD.PRICING_SCHEME_NM,PEX.COUNTRY) T1
                        JOIN (  select 'GNRC' AS C1,COUNT(vp.PRODUCT_KEY)  MODEL_CNT from V_PRODUCT VP
                                                                    JOIN GNRC.PRODUCT_DIM PD on PD.PRODUCT_KEY = VP.PRODUCT_KEY
                                                                    JOIn AUDIT_TBL ATT on ATT.AUDIT_KEY = PD.INSERT_AUDIT_KEY
                                                             where PRODUCT_CATEGORY_NM  like '%HSB%'
                                                               AND DO_NOT_SOLICIT_BRAND_IND = 'N'
                                                               AND DO_NOT_SOLICIT_CATEGORY_IND = 'N'
                                                               AND VP.DO_NOT_SOLICIT_PRODUCT_IND = 'N'
                                                               AND ATT.CREATION_DT < sysdate - 14) T2
                    ON  T1.C1 = T2.C1
                Where T2.MODEL_CNT - T1.MODEL_CNT > 0;


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' eligible models pricing records ar missing in product_price_dim . Check immediately!';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'PRODUCT_PRICE_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'IAHMAD', 'WARNING');
      END IF;
      COMMIT;


      --checking if there are dupes in MV_CAMPAIGN_RESPONSE
      l_count := 0;
      select count(*)
      into   l_count
      from   (
              select count(*) - count(distinct order_key || order_line_key) from gnrc.MV_CAMPAIGN_RESPONSE
             );


      IF l_count > 1
      THEN
         l_temp_text := 'There are ' || l_count || ' dupes in MV_CAMPAIGN_RESPONSE';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'MV_CAMPAIGN_RESPONSE', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;



       --checking if MV_CAMPAIGN_RESPONSE is getting refreshed
      l_count := 0;
      select count(*)
      into   l_count
      from   (
              select count(*) from gnrc.MV_CAMPAIGN_RESPONSE where PURCHASE_DT >= trunc(sysdate) - 3
             );


      IF l_count = 0
      THEN
         l_temp_text := 'MV_CAMPAIGN_RESPONSE is not getting refreshed';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'MV_CAMPAIGN_RESPONSE', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;



      l_count := 0;
      --finding if policy records are missing from T_AND_C_CONTRACT_TEMPLATE_XREF
      select count(*) into l_count
        from (select policy_key from P_POLICY_TBL where POLICY_KEY <> 0
              minus
              select policy_key from P_T_AND_C_XREF
             );


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' policies, which are missing T_AND_C_CONTRACT_TEMPLATE_XREF data. Check immediately!';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'PRODUCT_PRICE_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      COMMIT;


      l_count := 0;
      --Checking if Canadian addresses are going into error
      --GNRC-776 Canadian ACE Issue: Check is generic irrespective of the country but it was mainly added because of Canada
      select count(*), sum(cnts)
      into  l_count, l_count2
      from (
              select substr(cl.PROCESS_DT, 1, 6), count(distinct cl.SERIAL_NO) as cnts
                from  gnrc.common_load_tbl_arch cl join gnrc.address_output_tbl_arch ar on ar.UNIQUE_SEQ_NO = cl.UNIQUE_SEQ_NO
               where  cl.ADDRESS_LINE1_TX is not null and ar.ADDRESS_LINE1_TX is null
                 and  cl.PROCESS_DT = ar.PROCESS_DT
                 --and  to_date(cl.PROCESS_DT, 'YYYYMMDD') >= trunc(TRUNC(SYSDATE, 'MM')-1, 'MM')  --check from the last month onward
                 and  to_date(cl.PROCESS_DT, 'YYYYMMDD') >= trunc(SYSDATE) - 7 -- new check for check for 7 days only
              group by substr(cl.PROCESS_DT, 1, 6)
              having count(distinct cl.SERIAL_NO) > 50
              --order by substr(cl.PROCESS_DT, 1, 6)
           );


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' process months with a total of '  || l_count2 || ' Canadian leads where ADDRESS_LINE1_TX got wiped out!';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'ADDRESS_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      COMMIT;


      l_count := 0;
      --CAMPAIGN_EXT_DIM must have a record for every campaign in CAMPAIGN_DIM
      select count(*)
      into  l_count
      from (
              select CAMPAIGN_KEY
                from  gnrc.CAMPAIGN_DIM
               minus
              select CAMPAIGN_KEY
                from  gnrc.CAMPAIGN_EXT_DIM
           );


      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' campaign record(s), which are missing from CAMPAIGN_EXT_DIM';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CAMPAIGN_EXT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;



      l_count := 0;
      --STATE_MACHINE_EXT_TBL should have a record for every SM in STATE_MACHINE_TBL
      select count(*)
      into  l_count
      from (
              select STATE_MACHINE_KEY
                from  gnrc.STATE_MACHINE_TBL
               minus
              select STATE_MACHINE_KEY
                from  gnrc.STATE_MACHINE_EXT_TBL
           );

      IF l_count <> 0
      THEN
         l_temp_text := 'There are ' || l_count || ' SM record(s), which are missing from STATE_MACHINE_EXT_TBL';
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'STATE_MACHINE_EXT_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'WARNING');
      END IF;
      COMMIT;



    l_count := 0;
      --If there is a spike in unconfirmed sales
     select count(*)
     into  l_count
      from gnrcStg.v_unconfirmed_sales v
     where 1 = 1
        and order_created_dt > date '2022-01-14'      --cut off date when we started sending sales extract to Generac
        and order_created_dt < trunc(sysdate) - 30    --ignoring recent sales to avoid false alerts
           ;


      IF l_count > 30   --we will ignore if number is small...because if there is some real/major issue then this number will become big very quickly
      THEN
         l_temp_text := 'There are a large number of unconfirmed sales: ' || to_char(l_count);
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'V_UNCONFIRMED_SALES', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;


      l_count := 0;
      --If there is a spike WARRANTY_EXPIRATION_DT null values
     select count(*)
     into  l_count
      from GNRC.SERIALIZED_ITEM_DIM SI where SI.WARRANTY_EXPIRATION_DT is null;


      IF l_count > 11500   --we are start from this number as normal old vlaues already of 10K
      THEN
         l_temp_text := 'There are a large number of WARRANTY_EXPIRATION_DT null values : ' || to_char(l_count);
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SERIALIZED_ITEM_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;

      l_count := 0;

      --warn if new HSB models have been received but pricing didn’t get created
     select COUNT( distinct pr.MODEL_NO)  into  l_count
          from gnrc.product_dim pr left join AUDIT_TBL ai on ai.AUDIT_KEY = pr.INSERT_AUDIT_KEY
                join gnrc.product_category_dim pc on pc.product_category_key = pr.product_category_key
                left join gnrc.product_category_dim ppc
                 on (ppc.product_category_key = pc.parent_category_key )
                join gnrc.brand_dim br on br.brand_key = pr.brand_key
                left join gnrc.SERIALIZED_ITEM_DIM si on si.PRODUCT_KEY = pr.PRODUCT_KEY
          where
          1=1
         and pr.model_no not like '%SD'
         and pc.MARKETING_PRODUCT_CATEGORY_NM = 'HOME STANDBY GENERATOR'
         and DO_NOT_SOLICIT_PRODUCT_IND = 'N'
             and pr.PRODUCT_KEY not in (
               select ppd.product_key from gnrc.PRODUCT_PRICE_DIM ppd join gnrc.PRICING_SCHEME_DIM psd using (pricing_scheme_key)
                where psd.end_dt > trunc(sysdate)
             )
         and pr.MODEL_NO not in ('G0053244','G0053243','G0054800')  --this is an LC model with 20KW, which is outside of KW pricing range received
--                 group by pr.MODEL_NO, PRODUCT_NM, pc.PRODUCT_CATEGORY_NM, ppc.PRODUCT_CATEGORY_NM, pc.MARKETING_PRODUCT_CATEGORY_NM, BRAND_NM,
--                        DO_NOT_SOLICIT_PRODUCT_IND, pc.DO_NOT_SOLICIT_CATEGORY_IND, DO_NOT_SOLICIT_BRAND_IND, CREATION_DT
      ;



      IF l_count > 0
      THEN
         l_temp_text := 'There are new HSB models for which pricing did not get created: ' || to_char(l_count);
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'PRODUCT_PRICE_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;


      l_count := 0;
      --warn if there are SD models, which have not been suppressed

        select  COUNT( distinct pr.MODEL_NO)   into  l_count
          from gnrc.product_dim pr left join AUDIT_TBL ai on ai.AUDIT_KEY = pr.INSERT_AUDIT_KEY
                join gnrc.product_category_dim pc on pc.product_category_key = pr.product_category_key
                left join gnrc.product_category_dim ppc
                 on (ppc.product_category_key = pc.parent_category_key )
                join gnrc.brand_dim br on br.brand_key = pr.brand_key
                left join gnrc.SERIALIZED_ITEM_DIM si on si.PRODUCT_KEY = pr.PRODUCT_KEY
          where
          1=1
         and pr.model_no like '%SD'
        -- and pc.MARKETING_PRODUCT_CATEGORY_NM = 'HOME STANDBY GENERATOR'
         and DO_NOT_SOLICIT_PRODUCT_IND = 'N'
    --             group by pr.MODEL_NO, PRODUCT_NM, pc.PRODUCT_CATEGORY_NM, ppc.PRODUCT_CATEGORY_NM, pc.MARKETING_PRODUCT_CATEGORY_NM, BRAND_NM,
    --                    DO_NOT_SOLICIT_PRODUCT_IND, pc.DO_NOT_SOLICIT_CATEGORY_IND, DO_NOT_SOLICIT_BRAND_IND, CREATION_DT
    --             order by CREATION_DT, pr.MODEL_NO
        ;


      IF l_count > 0
      THEN
         l_temp_text := 'There are SD models, which have not been suppressed: ' || to_char(l_count);
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'PRODUCT_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;
      COMMIT;



    l_count := 0;
      --If there is a spike in PURCHASE_DT_KEY negative values
     select count(*)
     into  l_count
      from GNRC.SERIALIZED_ITEM_DIM where NVL(PURCHASE_DT_KEY,0) < 0;


      IF l_count > 100   --we will ignore if number is small...because if there is some real/major issue then this number will become big very quickly
      THEN
         l_temp_text := 'There are a large number of leads with negative PURCHASE_DT_KEY in SI_DIM : ' || to_char(l_count);
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

          insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
          values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SERIALIZED_ITEM_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      ELSE
           l_count := 0;
          select COUNT(*) into  l_count from GNRC.SERIALIZED_ITEM_DIM SI
          LEFT join GNRCSTG.DATE_DIM DM on DM.DATE_KEY = NVL(SI.PURCHASE_DT_KEY,0)
          where  DM.FULL_DT < date '2000-01-01';--0
           IF l_count > 100   --we will ignore if number is small...because if there is some real/major issue then this number will become big very quickly
           THEN
              l_temp_text := 'There are a large number of leads with PURCHASE_DT less than 2000-01-01 : ' || to_char(l_count);
              dbms_output.put_line (l_temp_text);
              l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

              insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
              values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SERIALIZED_ITEM_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
           ELSE
               l_count := 0;
                select COUNT(*) into  l_count from GNRC.SERIALIZED_ITEM_DIM SI
                 where  NVL(SI.WARRANTY_EXPIRATION_DT,date '2000-01-01') < date '2000-01-01' OR
                        NVL(SI.REGISTRATION_DT,date '2000-01-01') < date '2000-01-01' OR
                        NVL(SI.LATEST_COVERAGE_EXP_DT,date '2000-01-01') < date '2000-01-01';
               IF l_count > 200
               Then
                   l_temp_text := 'There are a large number of leads with WARRANTY_EXPIRATION_DT/REGISTRATION_DT/LATEST_COVERAGE_EXP_DT less than 2000-01-01 : ' || to_char(l_count);
                   dbms_output.put_line (l_temp_text);
                   l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

                  insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
                  values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'SERIALIZED_ITEM_DIM', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
               end if;
            END IF;
      END IF ;

      COMMIT;



      l_count := 0;
      --Warn if there are pro-rated contract cancellation records missing from gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT
      Select COUNT(*)   into  l_count from (
            select cc.CONTRACT_KEY,
                   cc.CANCEL_BY,
                   cc.CANCEL_DT,
                   cc.CANCEL_EFFECTIVE_DT,
                   cc.CONTRACT_REFUND_AMT,
                   cc.TAX_REFUND_AMT,
                   si.SERIAL_NO, oit.PURCHASE_DT, oit.ORDER_KEY, trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) as days_used
                   ,ccci.FULL_OR_PRO_RATED_REFUND
            from gnrc.CONTRACT_CANCELLATION_DIM cc
                 join gnrc.CONTRACT_ORDER_TBL cot on cot.CONTRACT_KEY = cc.CONTRACT_KEY
                 join gnrc.ORDER_ITEM_TBL oit on oit.ORDER_KEY = cot.ORDER_KEY and oit.ORDER_LINE_KEY = cot.ORDER_LINE_KEY
                 join gnrc.SERIALIZED_ITEM_DIM si on si.SI_KEY = oit.SERIALIZED_ITEM_KEY
                 left join gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT ccci on ccci.CONTRACT_KEY = cc.CONTRACT_KEY
            where CANCEL_DT >= date '2024-05-01'
              and trunc(sysdate) - trunc(CANCEL_DT) > 4  --if contract was cancelled more than 4 day ago...assuming we would have loaded client input file
              and trunc(sysdate) - trunc(CANCEL_DT) <= 45  --We will skip old records as there will be exceptions
              and trunc(cc.CANCEL_EFFECTIVE_DT) - trunc(oit.PURCHASE_DT) > 30  --pro-rata cancellation rule will apply
              and ccci.CONTRACT_KEY is null
              and sysdate > last_day(TRUNC(sysdate)) -7
            order by CANCEL_DT, si.SERIAL_NO)
        ;


      IF l_count > 0
      THEN
         l_temp_text := 'There are pro-rated contract cancellation record(s) missing from gnrc.CONTRACT_CANCELLATION_CLIENT_INPUT: ' || to_char(l_count);
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'CONTRACT_CANCELLATION_CLIENT_INPUT', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');
      END IF;

      COMMIT;


      l_count := 0;
      --Warn if there are sales with mismatch between shipping country and plan country


      select  COUNT(*)  into  l_count from (
      select si.serial_no, ot.order_key as order_no, OIT.ORDER_LINE_KEY, trunc(ot.purchase_dt) as  order_purchase_dt,
           con.contract_key, contract_xid, con.contract_status_key, ct.COUNTRY_3BYTE_CD as ship_country,
              pex.COUNTRY as pex_country, order_created_ts
      from
           gnrc.order_item_tbl oit
           join gnrc.order_tbl ot
           ON ( ot.ORDER_KEY = oit.ORDER_KEY )
           join gnrc.serialized_item_dim si ON (si.si_key = oit.serialized_item_key)
           LEFT JOIN gnrc.order_item_disc_info_lkp disc
                    ON (    disc.order_key = oit.order_key
                        AND disc.order_line_key = oit.order_line_key)
           LEFT join gnrc.SHIPPING_INFO_TBL sif
           ON ( SIF.order_key = oit.order_key)
           LEFT join gnrc.ADDRESS_DIM  ADDR
           ON ( ADDR.ADDRESS_KEY = SIF.ADDRESS_KEY)
           left join gnrc.POSTAL_STATE_DIM psd on psd.POSTAL_STATE_CD = ADDR.STATE_CD
           left join gnrc.COUNTRY_TBL ct on ct.COUNTRY_KEY = psd.COUNTRY_KEY
           JOIN gnrc.v_policy_fee fee
           ON fee.policy_key = oit.policy_key
           LEFT JOIN gnrc.order_confirmation_tbl  oct
           ON (    oct.order_key = oit.order_key
                        AND oct.order_line_key = oit.order_line_key)
           left join gnrc.contract_order_tbl cot
           ON ( OIT.ORDER_KEY = COT.ORDER_KEY
                AND OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY)
           left join gnrc.contract_lkp clkp on clkp.contract_key = cot.contract_key and clkp.source_system_cd = 0
           left join gnrc.contract_dim con
           ON ( con.contract_key = clkp.contract_key)
           left join gnrc.contract_cancellation_dim can
           ON ( can.contract_key = con.contract_key)
           left join gnrc.policy_tbl pol on pol.policy_key = oit.policy_key
           left join gnrc.POLICY_EXT_TBL pex on pex.policy_key = pol.policy_key
      where 1=1

      ) t
      where 1=1
      and trunc(ORDER_CREATED_TS) > date '2024-08-01'
      and case when ship_country = 'CAN' then 'CANADA' else ship_country end <> pex_country;


      IF l_count > 0
      THEN
         l_temp_text := 'There are sales with mismatch between shipping country and plan country : ' || to_char(l_count);
         dbms_output.put_line (l_temp_text);
         l_qc_text :=   l_qc_text || l_temp_text || C_CRLF;

         insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
         values ('PKG_DATA_QC.PROC_DATA_QC', 'Daily data QA', l_temp_text, l_count, SYSTIMESTAMP, 'ORDER_ITEM_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'IAHMAD', 'ERROR');
      END IF;

      COMMIT;

   END PROC_DATA_QC;



   PROCEDURE proc_sync_qc
   IS
      --l_count                       NUMBER;
      l_temp_text                   VARCHAR2(1096):= NULL;

   BEGIN

       l_temp_text := NULL;
       select LISTAGG(trunc(process_start_ts)||':'|| run_id||':'||table_name||':'||SOURCE_SCHEMA||':'||TARGET_SCHEMA||'::'||status||'::'||substr(MESSAGE,0,100)||chr(10),'')
                WITHIN GROUP (ORDER BY run_id desc ,table_name) AS txt
         into l_temp_text
         from GNRC.SYNC_PROCESS_STATUS_TBL
        where status NOT IN ( 'IMPORTED','EXPORT_SKIPPED','EXPORTED','IMPORT_SKIPPED')
          and process_start_ts BETWEEN  TRUNC(CURRENT_DATE) - 1   AND TRUNC(CURRENT_DATE) + 1
         ;

      --------------


      IF l_temp_text IS NOT NULL
      THEN

        insert into PROCESS_QA_LOG (PROGRAM_NM, PROCESS_NM, DESCRIPTIVE_TX, Record_Count, CREATION_DT, TABLE_NM, USER_NM, AUTHOR_NM, LOG_TYPE)
        values ('PKG_DATA_QC.PROC_SYNC_QC', 'Daily Web Sync QA', l_temp_text, NULL, SYSTIMESTAMP, 'SYNC_PROCESS_STATUS_TBL', SYS_CONTEXT ('USERENV', 'SESSION_USER'), 'AJAIN', 'ERROR');

        commit;

      END IF;



   END PROC_SYNC_QC;

END pkg_data_qc;
/

