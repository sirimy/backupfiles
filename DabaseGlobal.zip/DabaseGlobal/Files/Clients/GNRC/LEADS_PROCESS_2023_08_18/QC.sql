
Select distinct RLT.OWNER_NAME, RLT.OWNER_ADDRESS1, RLT.OWNER_CITY, RLT.OWNER_STATE, RLT.OWNER_POSTCODE, RLT.OWNER_PHONE_NUMBER, RLT.OWNER_EMAIL, RLT.EQUIPMENT, RLT.VALID_FROM_DATE, RLT.MATERIAL, RLT.MATERIAL_NAME, RLT.PURCHASE_DATE, RLT.PRODUCT_HIER_LEVEL1, RLT.PRODUCT_HIER_LEVEL1_NAME, RLT.PRODUCT_HIER_LEVEL2, RLT.PRODUCT_HIER_LEVEL2_NAME, RLT.MASTER_WARRANTY_NUMBER, RLT.MASTER_WARRANTY_DESC, RLT.WARRANTY_START_DATE, RLT.MIN_WARRANTY_END_DT, RLT.MAX_WARRANTY_END_DT, RLT.NOTIFICATION_COUNT, RLT.PRODUCT_HIRE_LEVEL3, RLT.PRODUCT_HIRE_LEVEL_3_NAME, RLT.SALES_OFFICE,RLT.FILE_NM
,RLT.INSERT_AUDIT_KEY
--     SIOUT.POSTED_SERIAL_ITEM_KEY,SIOUT.PROCESS_DT,ATT.CREATION_DT
--      ,RLT.FILE_NM,CLA.FILE_NM, RLT.WARRANTY_START_DATE,RLT.PURCHASE_DATE,RLT.MIN_WARRANTY_END_DT,RLT.MAX_WARRANTY_END_DT
--                 ,CLA.PURCHASE_DT,CLA.LATEST_COVERAGE_EXP_DT,CLA.WARRANTY_EXPIRATION_DT
    from GNRC.SI_OUTPUT_TBL_ARCH SIOUT
            JOIN GNRC.RAW_LEADS_TBL RLT ON SIOUT.UNIQUE_SEQ_NO = RLT.UNIQUE_SEQ_NO
            JOIN AUDIT_TBL ATT on ATT.AUDIT_KEY = RLT.INSERT_AUDIT_KEY
            JOIN GNRC.COMMON_LOAD_TBL_ARCH CLA ON CLA.UNIQUE_SEQ_NO = SIOUT.UNIQUE_SEQ_NO
        where SIOUT.POSTED_SERIAL_ITEM_KEY in (
                select  sid2.SI_KEY
                    from GNRC.SERIALIZED_ITEM_DIM  SID2
                         left join date_dim dd on dd.DATE_KEY = sid2.PURCHASE_DT_KEY where SERIAL_NO in( '3012673810'
                          ,'3013136268','3013557274','3011054102','3010235586','3012467306','3011492657'
                         ,'3012097648','3012317282','3012000464','3012822855','3012317621','3013461126','3013235819','3012279796',
                         '3012802444','3013255951','3013292015','3012077577','3013135420','3011200288','3012621254','3012078125','3011851833',
                         '3011230741','3013497944','3009748216','3012941484','3011639989','3011985089','3012045289','3013441078','3011640408','3012855680',
                         '3012097818','3013344136','3012802293','3013528296','3012317270','3011599271','3013256070','3012105340','3013389684','3012045437',
                         '3012368602','3011819084','3013255265','3011760237', '3012622919'
                        )
                )
      and RLT.FILE_NM <> 'AS12_nov_customer_handling_2024-12-06-gnrc-1668.txt'
      --and CLA.FILE_NM like '%gnrc_after_leads%'
ORDER BY LTRIM(RLT.EQUIPMENT,0),RLT.INSERT_AUDIT_KEY
;
-- +----------------------+----------+--------------------------+----------------------------------------+----------------------------------------+-------------------+-------------+-------------------+-------------------+--------------------------+----------------------+--------------------------+
-- |POSTED_SERIAL_ITEM_KEY|PROCESS_DT|CREATION_DT               |FILE_NM                                 |FILE_NM                                 |WARRANTY_START_DATE|PURCHASE_DATE|MIN_WARRANTY_END_DT|MAX_WARRANTY_END_DT|PURCHASE_DT               |LATEST_COVERAGE_EXP_DT|WARRANTY_EXPIRATION_DT    |
-- +----------------------+----------+--------------------------+----------------------------------------+----------------------------------------+-------------------+-------------+-------------------+-------------------+--------------------------+----------------------+--------------------------+
-- |1524814               |20230824  |2023-08-24 23:15:04.000000|gnrc_after_leads_2023-08-23-14-56-12.txt|gnrc_after_leads_2023-08-23-14-56-12.txt|2023-06-21         |2023-06-21   |2028-06-20         |2028-06-20         |2023-06-21 00:00:00.000000|NULL                  |2028-06-20 00:00:00.000000|
-- |1524814               |20230829  |2023-08-20 22:23:50.000000|gnrc_after_leads_2023-08-18-00-00-00.txt|gnrc_after_leads_2023-08-18-00-00-00.txt|2023-06-21         |2023-06-21   |2025-06-20         |2028-06-19         |2023-06-21 00:00:00.000000|NULL                  |2025-06-20 00:00:00.000000|
-- +----------------------+----------+--------------------------+----------------------------------------+----------------------------------------+-------------------+-------------+-------------------+-------------------+--------------------------+----------------------+--------------------------+

select COUNT(distinct SERIAL_NO ) from GNRC.COMMON_LOAD_TBL_ARCH CLA where CLA.FILE_NM ='gnrc_after_leads_2023-08-18-00-00-00.txt' and CLA.PROCESS_DT = '20230829';--219276

select COUNT(*) from GNRC.COMMON_LOAD_TBL_ARCH CLA where CLA.FILE_NM ='gnrc_after_leads_2023-08-18-00-00-00.txt'
                                                     and CLA.PROCESS_DT = '20230829'
                                                     and WARRANTY_EXPIRATION_DT < date '2026-01-01'
                                                     and   SERIAL_NO in( '3012673810'
                          ,'3013136268','3013557274','3011054102','3010235586','3012467306','3011492657'
                         ,'3012097648','3012317282','3012000464','3012822855','3012317621','3013461126','3013235819','3012279796',
                         '3012802444','3013255951','3013292015','3012077577','3013135420','3011200288','3012621254','3012078125','3011851833',
                         '3011230741','3013497944','3009748216','3012941484','3011639989','3011985089','3012045289','3013441078','3011640408','3012855680',
                         '3012097818','3013344136','3012802293','3013528296','3012317270','3011599271','3013256070','3012105340','3013389684','3012045437',
                         '3012368602','3011819084','3013255265','3011760237', '3012622919'
                        )
;--219276

select COuNT(*),MAX(RLT.MIN_WARRANTY_END_DT),MIN(RLT.MAX_WARRANTY_END_DT) from GNRC.COMMON_LOAD_TBL_ARCH CLA
                       JOIN GNRC.RAW_LEADS_TBL RLT ON CLA.UNIQUE_SEQ_NO = RLT.UNIQUE_SEQ_NO
                where CLA.FILE_NM ='gnrc_after_leads_2023-08-18-00-00-00.txt' and CLA.PROCESS_DT = '20230829'
and RLT.MIN_WARRANTY_END_DT<> RLT.MAX_WARRANTY_END_DT
;--187896

select RLT.EQUIPMENT,CLA.SERIAL_NO,RLT.MIN_WARRANTY_END_DT,RLT.MAX_WARRANTY_END_DT from GNRC.COMMON_LOAD_TBL_ARCH CLA
                       JOIN GNRC.RAW_LEADS_TBL RLT ON CLA.UNIQUE_SEQ_NO = RLT.UNIQUE_SEQ_NO
                where CLA.FILE_NM ='gnrc_after_leads_2023-08-18-00-00-00.txt' and CLA.PROCESS_DT = '20230829'
and RLT.MIN_WARRANTY_END_DT<> RLT.MAX_WARRANTY_END_DT
;--

select * from GNRC.SERIALIZED_ITEM_DIM
where LATEST_COVERAGE_TYPE = 1   and WARRANTY_EXPIRATION_DT <> LATEST_COVERAGE_EXP_DT
--AND SERIAL_NO = '3012673810'
and   SERIAL_NO in( select CLA.SERIAL_NO  from GNRC.COMMON_LOAD_TBL_ARCH CLA
                       JOIN GNRC.RAW_LEADS_TBL RLT ON CLA.UNIQUE_SEQ_NO = RLT.UNIQUE_SEQ_NO
                where CLA.FILE_NM ='gnrc_after_leads_2023-08-18-00-00-00.txt' and CLA.PROCESS_DT = '20230829'
                        )
;

select COuNT(*),MAX(WARRANTY_EXPIRATION_DT),MIN(LATEST_COVERAGE_EXP_DT)  from GNRC.SERIALIZED_ITEM_DIM
where LATEST_COVERAGE_TYPE = 1   and WARRANTY_EXPIRATION_DT <> LATEST_COVERAGE_EXP_DT
--AND SERIAL_NO = '3012673810'
and   SERIAL_NO in( select CLA.SERIAL_NO  from GNRC.COMMON_LOAD_TBL_ARCH CLA
                       JOIN GNRC.RAW_LEADS_TBL RLT ON CLA.UNIQUE_SEQ_NO = RLT.UNIQUE_SEQ_NO
                where CLA.FILE_NM ='gnrc_after_leads_2023-08-18-00-00-00.txt' and CLA.PROCESS_DT = '20230829'
                        )
;
-- +--------+---------------------------+---------------------------+
-- |COUNT(*)|MAX(WARRANTY_EXPIRATION_DT)|MIN(LATEST_COVERAGE_EXP_DT)|
-- +--------+---------------------------+---------------------------+
-- |51      |2028-06-07 00:00:00.000000 |2024-04-08                 |
-- +--------+---------------------------+---------------------------+
