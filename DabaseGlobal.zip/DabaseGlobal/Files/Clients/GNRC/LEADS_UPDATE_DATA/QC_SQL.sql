
select
  RLT1.FILE_NM,RLT1.*,
  RLT.FILE_NM,RLT.*
from GNRC.RAW_DEALER_LEADS_TBL RLT1
     JOIN (select * from (
             select rlt.*, row_number() over (partition by LTRIM(TRIM(RLT.EQUIPMENT), '0') order by rlt.INSERT_AUDIT_KEY desc) rno
               from GNRC.RAW_DEALER_LEADS_TBL RLT
            ) RLT
         where RLT.rno = 1
         ) RLT
        ON  (   LTRIM(TRIM(RLT1.EQUIPMENT),'0') = LTRIM(TRIM(RLT.EQUIPMENT),'0')
            )
where
    RLT1.ERROR_DESC is NULL and RLT.ERROR_DESC IS NULL
    and RLT1.FILE_NM not like '%Adhoc%' and RLT.FILE_NM not like '%Adhoc%'
    and RLT1.FILE_NM not like '%GNRC-%' and RLT.FILE_NM not like '%GNRC-%'
    and RLT1.FILE_NM not like '%UPDATE%' and RLT.FILE_NM not like '%UPDATE%'
    and (RLT1.FILE_NM like '%Generac_After_Leads_ExtWarranty_%'   and RLT.FILE_NM like '%Generac_After_Leads_ExtWarranty_%')
    and RLT1.FILE_NM <>  RLT.FILE_NM
order by rlt.INSERT_AUDIT_KEY desc
;
