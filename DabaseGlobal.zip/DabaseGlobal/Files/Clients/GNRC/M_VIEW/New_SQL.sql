insert into MV_CAMPAIGN_RESPONSE_temp
WITH CAMPAIGN_PARTICIPATION_FCT_MV (BUNDLE_KEY, offer_key, message_key,TIMING_KEY,CUSTOMER_KEY,DROP_DT)
      AS
      (
            Select cpf.BUNDLE_KEY, cpf.offer_key, cpf.message_key,cpf.TIMING_KEY,cpf.CUSTOMER_KEY,td.DROP_DT
                    from CAMPAIGN_PARTICIPATION_FCT CPF
                      JOIN TIMING_DIM TD ON (TD.TIMING_KEY = CPF.TIMING_KEY )

      )
SELECT SOLICITED_OFFER_KEY,
       PURCHASED_OFFER_KEY,
       VISITOR_KEY,
       CUSTOMER_KEY,
       SI_KEY,
       PRODUCT_KEY,
       ORDER_KEY,
       ORDER_LINE_KEY,
       PURCHASE_DT,
       CANCEL_EFFECTIVE_DT,
       CHANNEL,
       NAME,
       CONTRACT_SALE_PRICE,
       POLICY_PREMIUM_AMT,
       POLICY_KEY,
       SALE_TYPE,
       ATTRIBUTION_TYPE_TX,
       FLEXPAY_IND
  FROM (SELECT SOLICITED_OFFER_KEY,
               PURCHASED_OFFER_KEY,
               VISITOR_KEY,
               CUSTOMER_KEY,
               SI_KEY,
               PRODUCT_KEY,
               ORDER_KEY,
               ORDER_LINE_KEY,
               PURCHASE_DT,
               CANCEL_EFFECTIVE_DT,
               CHANNEL,
               NAME,
               CONTRACT_SALE_PRICE,
               POLICY_PREMIUM_AMT,
               POLICY_KEY,
               SALE_TYPE,
               CASE
                  WHEN SOLICITED_OFFER_KEY IS NOT NULL THEN 'Serialized Item'
               END
                  AS Attribution_Type_Tx,
               CASE WHEN FLEXPAY_IND = 'Y' THEN 1 ELSE 0 END AS FLEXPAY_IND
          FROM (SELECT TO_NUMBER (CP.OFFER_KEY) AS SOLICITED_OFFER_KEY,
                       OIT.OFFER_KEY AS PURCHASED_OFFER_KEY,
                       OT.VISITOR_KEY,
                       VD.CUSTOMER_KEY,
                       OIT.SERIALIZED_ITEM_KEY AS SI_KEY,
                       SID.PRODUCT_KEY,
                       OIT.ORDER_KEY,
                       OIT.ORDER_LINE_KEY,
                       TRUNC (OIT.PURCHASE_DT) AS PURCHASE_DT,
                       CCD.CANCEL_EFFECTIVE_DT,
                       OT.SALES_SOURCE_CD AS CHANNEL,
                       TERM.NAME,
                       OIT.PRICE_AMT - NVL (DISC.TOTAL_LINE_DISCOUNT_AMT, 0)
                          CONTRACT_SALE_PRICE,
                       PFR.POLICY_FEE_VALUE AS POLICY_PREMIUM_AMT,
                       OIT.POLICY_KEY,
                       'Direct' AS SALE_TYPE,
                       ROW_NUMBER ()
                       OVER (PARTITION BY OIT.ORDER_KEY, OIT.ORDER_LINE_KEY
                             ORDER BY CP.drop_Dt DESC)
                          cp_Rn,
                       CP.drop_dt,
                       oit.flexpay_ind
                  FROM ORDER_ITEM_TBL OIT
                       JOIN ORDER_TBL OT
                          ON (    OT.ORDER_KEY = OIT.ORDER_KEY
                              AND OT.SUB_TOTAL_AMT > 1)
                       LEFT JOIN
                       (  SELECT ORDER_KEY,
                                 ORDER_LINE_KEY,
                                 SUM (DISCOUNT_AMT) TOTAL_LINE_DISCOUNT_AMT
                            FROM ORDER_ITEM_DISC_INFO_LKP
                        GROUP BY ORDER_KEY, ORDER_LINE_KEY) DISC
                          ON (    DISC.ORDER_KEY = OIT.ORDER_KEY
                              AND DISC.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY)
                       JOIN VISITOR_DIM VD
                          ON (VD.VISITOR_KEY = OT.VISITOR_KEY)
                       JOIN SERIALIZED_ITEM_DIM SID
                          ON (OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY)
                       JOIN PRODUCT_DIM PD
                          ON (SID.PRODUCT_KEY = PD.PRODUCT_KEY)
                       LEFT JOIN CONTRACT_ORDER_TBL COT
                          ON (    COT.ORDER_KEY = OIT.ORDER_KEY
                              AND COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY) -- contract pending confirmation
                       LEFT JOIN CONTRACT_CANCELLATION_DIM CCD
                          ON (CCD.CONTRACT_KEY = COT.CONTRACT_KEY)
                       JOIN BRAND_DIM BD ON (BD.BRAND_KEY = PD.BRAND_KEY)
                       JOIN POLICY_TBL PT ON (PT.POLICY_KEY = OIT.POLICY_KEY)
                       JOIN
                       (SELECT PFR.POLICY_KEY, PFR.POLICY_FEE_VALUE
                          FROM POLICY_FEE_XREF PFR
                               JOIN POLICY_FEE_TYPE PFT
                                  ON (    PFT.POLICY_FEE_TYPE_KEY =
                                             PFR.POLICY_FEE_TYPE_KEY
                                      AND UPPER (PFT.NAME) = 'PREMIUM_AMT'))
                       PFR
                          ON (PFR.POLICY_KEY = PT.POLICY_KEY)
                       JOIN TERM_DIM TERM ON (PT.TERM_KEY = TERM.TERM_KEY)
                       JOIN BUNDLE_ITEM_XREF bix ON (BIX.SI_KEY = SID.SI_KEY)
                       JOIN CAMPAIGN_PARTICIPATION_FCT_MV CP
                          ON CP.BUNDLE_KEY = BIX.BUNDLE_KEY
--                        JOIN TIMING_DIM T ON     T.TIMING_KEY = CP.TIMING_KEY
                             AND TRUNC (OIT.PURCHASE_DT) >= CP.DROP_DT
                       JOIN MESSAGE_DIM M ON (M.MESSAGE_KEY = CP.MESSAGE_KEY) -- AND M.CHANNEL_KEY = 1)
                 WHERE oit.offer_key IN (SELECT OIX.OFFER_KEY
                                           FROM OFFER_ITEM_XREF OIX))
         WHERE cp_rn = 1
        UNION ALL
        (SELECT COALESCE (SOLICITED_SI_OFFER_KEY,
                          SOLICITED_CUST_OFFER_KEY,
                          SOLICITED_HH_OFFER_KEY)
                   AS SOLICITED_OFFER_KEY,
                PURCHASED_OFFER_KEY,
                VISITOR_KEY,
                CUSTOMER_KEY,
                SI_KEY,
                PRODUCT_KEY,
                ORDER_KEY,
                ORDER_LINE_KEY,
                PURCHASE_DT,
                CANCEL_EFFECTIVE_DT,
                CHANNEL,
                TERM,
                CONTRACT_SALE_PRICE,
                POLICY_PREMIUM_AMT,
                POLICY_KEY,
                'Add on' AS SALE_TYPE,
                CASE
                   WHEN SOLICITED_SI_OFFER_KEY IS NOT NULL
                   THEN
                      'Serialized Item'
                   WHEN     SOLICITED_SI_OFFER_KEY IS NULL
                        AND SOLICITED_CUST_OFFER_KEY IS NOT NULL
                   THEN
                      'Customer'
                   WHEN     SOLICITED_SI_OFFER_KEY IS NULL
                        AND SOLICITED_CUST_OFFER_KEY IS NULL
                        AND SOLICITED_HH_OFFER_KEY IS NOT NULL
                   THEN
                      'Household'
                   ELSE
                      'Unattributed'
                END
                   AS ATTRIBUTION_TYPE_TX,
                CASE WHEN FLEXPAY_IND = 'Y' THEN 1 ELSE 0 END AS FLEXPAY_IND
           FROM (

                    SELECT TO_NUMBER (CPF.OFFER_KEY) AS SOLICITED_SI_OFFER_KEY,
                        TO_NUMBER (CPF2.OFFER_KEY) AS SOLICITED_CUST_OFFER_KEY,
                        TO_NUMBER (CPF3.OFFER_KEY) AS SOLICITED_HH_OFFER_KEY,
                        0 AS SOLICITED_HH_OFFER_KEY,
                        OIT.OFFER_KEY AS PURCHASED_OFFER_KEY,
                        OT.VISITOR_KEY,
                        VD.CUSTOMER_KEY,
                        OIT.SERIALIZED_ITEM_KEY AS SI_KEY,
                        SID.PRODUCT_KEY,
                        OIT.ORDER_KEY,
                        OIT.ORDER_LINE_KEY,
                        TRUNC (OIT.PURCHASE_DT) AS PURCHASE_DT,
                        CCD.CANCEL_EFFECTIVE_DT,
                        OT.SALES_SOURCE_CD AS CHANNEL,
                        TERM.NAME AS TERM,
                        OIT.PRICE_AMT - NVL (DISC.TOTAL_LINE_DISCOUNT_AMT, 0)
                           CONTRACT_SALE_PRICE,
                        PFR.POLICY_FEE_VALUE AS POLICY_PREMIUM_AMT,
                        OIT.POLICY_KEY,
                        ROW_NUMBER ()
                        OVER (
                           PARTITION BY OIT.ORDER_KEY,
                                        OIT.ORDER_LINE_KEY,
                                        OIT.OFFER_KEY
                           ORDER BY cpf.drop_dt desc nulls last, cpf2.DROP_DT DESC nulls last--, cpf3.DROP_DT desc nulls last
                            )
                           AS RN,
                        OIT.FLEXPAY_IND
                   FROM ORDER_TBL OT
                        JOIN ORDER_ITEM_TBL OIT
                           ON (OIT.ORDER_KEY = OT.ORDER_KEY)
                        LEFT JOIN
                        (  SELECT ORDER_KEY,
                                  ORDER_LINE_KEY,
                                  SUM (DISCOUNT_AMT) TOTAL_LINE_DISCOUNT_AMT
                             FROM ORDER_ITEM_DISC_INFO_LKP
                         GROUP BY ORDER_KEY, ORDER_LINE_KEY) DISC
                           ON (    DISC.ORDER_KEY = OIT.ORDER_KEY
                               AND DISC.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY)
                        LEFT JOIN CAMPAIGN_PARTICIPATION_FCT_MV CPFO
                           ON (CPFO.OFFER_KEY = OIT.OFFER_KEY)
                        JOIN SERIALIZED_ITEM_DIM SID
                           ON (OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY)
                        LEFT JOIN BUNDLE_ITEM_XREF BIX
                           ON (BIX.SI_KEY = SID.SI_KEY)
                        LEFT JOIN
--                            (
--                                Select cpf.BUNDLE_KEY, cpf.offer_key, cpf.message_key, td.DROP_DT from CAMPAIGN_PARTICIPATION_FCT_MV CPF
--                                         JOIN TIMING_DIM TD
--                                    ON (TD.TIMING_KEY = CPF.TIMING_KEY )
--
--                            )
                           CAMPAIGN_PARTICIPATION_FCT_MV    CPF ON (CPF.BUNDLE_KEY = BIX.BUNDLE_KEY AND ot.PURCHASE_DT >= CPF.DROP_DT )
                        LEFT JOIN MESSAGE_DIM M
                           ON (M.MESSAGE_KEY = CPF.MESSAGE_KEY) -- AND M.CHANNEL_KEY = 1)
                        LEFT JOIN VISITOR_DIM VD
                           ON (VD.VISITOR_KEY = OT.VISITOR_KEY)
                        LEFT JOIN
--                             (
--
--                                 select cpf2.CUSTOMER_KEY, cpf2.offer_key, cpf2.message_key, td2.DROP_DT from CAMPAIGN_PARTICIPATION_FCT_MV CPF2
--                                     JOIN TIMING_DIM TD2
--                                 ON (TD2.TIMING_KEY = CPF2.TIMING_KEY )
--
--                             )
                            CAMPAIGN_PARTICIPATION_FCT_MV cpf2  ON (CPF2.CUSTOMER_KEY = VD.CUSTOMER_KEY AND ot.PURCHASE_DT >= cpf2.DROP_DT )
                        LEFT JOIN MESSAGE_DIM M2
                           ON (M2.MESSAGE_KEY = CPF2.MESSAGE_KEY) --AND M2.CHANNEL_KEY = 1)
                        LEFT JOIN CUSTOMER_DIM CUST
                           ON CUST.household_key = VD.household_key
--                         LEFT JOIN
-- --                                 (
-- --
-- --                                 select cpf3.CUSTOMER_KEY, cpf3.offer_key, cpf3.message_key, td3.DROP_DT from CAMPAIGN_PARTICIPATION_FCT_MV CPF3
-- --                                     JOIN TIMING_DIM TD3
-- --                                 ON (TD3.TIMING_KEY = CPF3.TIMING_KEY )
-- --
-- --                                 )
--                             CAMPAIGN_PARTICIPATION_FCT_MV cpf3 ON (CPF3.CUSTOMER_KEY = CUST.CUSTOMER_KEY AND ot.PURCHASE_DT >= cpf3.DROP_DT )
                        LEFT JOIN PRODUCT_DIM PD
                           ON (SID.PRODUCT_KEY = PD.PRODUCT_KEY)
                        LEFT JOIN CONTRACT_ORDER_TBL COT
                           ON (    COT.ORDER_KEY = OIT.ORDER_KEY
                               AND COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY) -- contract pending confirmation
                        LEFT JOIN CONTRACT_CANCELLATION_DIM CCD
                           ON (CCD.CONTRACT_KEY = COT.CONTRACT_KEY)
                        JOIN BRAND_DIM BD ON (BD.BRAND_KEY = PD.BRAND_KEY)
                        JOIN POLICY_TBL PT
                           ON (PT.POLICY_KEY = OIT.POLICY_KEY)
                        JOIN
                        (SELECT PFR.POLICY_KEY, PFR.POLICY_FEE_VALUE
                           FROM POLICY_FEE_XREF PFR
                                JOIN POLICY_FEE_TYPE PFT
                                   ON (    PFT.POLICY_FEE_TYPE_KEY =
                                              PFR.POLICY_FEE_TYPE_KEY
                                       AND UPPER (PFT.NAME) = 'PREMIUM_AMT'))
                        PFR
                           ON (PFR.POLICY_KEY = PT.POLICY_KEY)
                        JOIN TERM_DIM TERM ON (PT.TERM_KEY = TERM.TERM_KEY)
                  WHERE CPFO.OFFER_KEY IS NULL --Exclude sales against solicited/regular offers
                )
          WHERE RN = 1)
        ORDER BY 1, 2)--[2025-07-09 04:03:05] 224,373 rows affected in 1 m 46 s 247 ms