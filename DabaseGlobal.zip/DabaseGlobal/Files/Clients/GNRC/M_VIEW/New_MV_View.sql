create materialized view MV_CAMPAIGN_RESPONSE_
	refresh complete on demand
as
SELECT SOLICITED_OFFER_KEY,
       PURCHASED_OFFER_KEY,
       VISITOR_KEY,
       CUSTOMER_KEY,
       SI_KEY,
       PRODUCT_KEY,
       ORDER_KEY,
       ORDER_LINE_KEY,
       PURCHASE_DT,
       CANCEL_EFFECTIVE_DT,
       CHANNEL,
       NAME,
       CONTRACT_SALE_PRICE,
       POLICY_PREMIUM_AMT,
       POLICY_KEY,
       SALE_TYPE,
       ATTRIBUTION_TYPE_TX,
       FLEXPAY_IND
  FROM (SELECT SOLICITED_OFFER_KEY,
               PURCHASED_OFFER_KEY,
               VISITOR_KEY,
               CUSTOMER_KEY,
               SI_KEY,
               PRODUCT_KEY,
               ORDER_KEY,
               ORDER_LINE_KEY,
               PURCHASE_DT,
               CANCEL_EFFECTIVE_DT,
               CHANNEL,
               NAME,
               CONTRACT_SALE_PRICE,
               POLICY_PREMIUM_AMT,
               POLICY_KEY,
               SALE_TYPE,
               CASE
                  WHEN SOLICITED_OFFER_KEY IS NOT NULL THEN 'Serialized Item'
               END
                  AS Attribution_Type_Tx,
               CASE WHEN FLEXPAY_IND = 'Y' THEN 1 ELSE 0 END AS FLEXPAY_IND
          FROM (SELECT TO_NUMBER (CP.OFFER_KEY) AS SOLICITED_OFFER_KEY,
                       OIT.OFFER_KEY AS PURCHASED_OFFER_KEY,
                       OT.VISITOR_KEY,
                       VD.CUSTOMER_KEY,
                       OIT.SERIALIZED_ITEM_KEY AS SI_KEY,
                       SID.PRODUCT_KEY,
                       OIT.ORDER_KEY,
                       OIT.ORDER_LINE_KEY,
                       TRUNC (OIT.PURCHASE_DT) AS PURCHASE_DT,
                       CCD.CANCEL_EFFECTIVE_DT,
                       OT.SALES_SOURCE_CD AS CHANNEL,
                       TERM.NAME,
                       OIT.PRICE_AMT - NVL (DISC.TOTAL_LINE_DISCOUNT_AMT, 0)
                          CONTRACT_SALE_PRICE,
                       PFR.POLICY_FEE_VALUE AS POLICY_PREMIUM_AMT,
                       OIT.POLICY_KEY,
                       'Direct' AS SALE_TYPE,
                       ROW_NUMBER ()
                       OVER (PARTITION BY OIT.ORDER_KEY, OIT.ORDER_LINE_KEY
                             ORDER BY T.drop_Dt DESC)
                          cp_Rn,
                       T.drop_dt,
                       oit.flexpay_ind
                  FROM ORDER_ITEM_TBL OIT
                       JOIN ORDER_TBL OT
                          ON (    OT.ORDER_KEY = OIT.ORDER_KEY
                              AND OT.SUB_TOTAL_AMT > 1)
                       LEFT JOIN
                       (  SELECT ORDER_KEY,
                                 ORDER_LINE_KEY,
                                 SUM (DISCOUNT_AMT) TOTAL_LINE_DISCOUNT_AMT
                            FROM ORDER_ITEM_DISC_INFO_LKP
                        GROUP BY ORDER_KEY, ORDER_LINE_KEY) DISC
                          ON (    DISC.ORDER_KEY = OIT.ORDER_KEY
                              AND DISC.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY)
                       JOIN VISITOR_DIM VD
                          ON (VD.VISITOR_KEY = OT.VISITOR_KEY)
                       JOIN SERIALIZED_ITEM_DIM SID
                          ON (OIT.SERIALIZED_ITEM_KEY = SID.SI_KEY)
                       JOIN PRODUCT_DIM PD
                          ON (SID.PRODUCT_KEY = PD.PRODUCT_KEY)
                       LEFT JOIN CONTRACT_ORDER_TBL COT
                          ON (    COT.ORDER_KEY = OIT.ORDER_KEY
                              AND COT.ORDER_LINE_KEY = OIT.ORDER_LINE_KEY) -- contract pending confirmation
                       LEFT JOIN CONTRACT_CANCELLATION_DIM CCD
                          ON (CCD.CONTRACT_KEY = COT.CONTRACT_KEY)
                       JOIN BRAND_DIM BD ON (BD.BRAND_KEY = PD.BRAND_KEY)
                       JOIN POLICY_TBL PT ON (PT.POLICY_KEY = OIT.POLICY_KEY)
                       JOIN
                       (SELECT PFR.POLICY_KEY, PFR.POLICY_FEE_VALUE
                          FROM POLICY_FEE_XREF PFR
                               JOIN POLICY_FEE_TYPE PFT
                                  ON (    PFT.POLICY_FEE_TYPE_KEY =
                                             PFR.POLICY_FEE_TYPE_KEY
                                      AND UPPER (PFT.NAME) = 'PREMIUM_AMT'))
                       PFR
                          ON (PFR.POLICY_KEY = PT.POLICY_KEY)
                       JOIN TERM_DIM TERM ON (PT.TERM_KEY = TERM.TERM_KEY)
                       JOIN BUNDLE_ITEM_XREF bix ON (BIX.SI_KEY = SID.SI_KEY)
                       JOIN CAMPAIGN_PARTICIPATION_FCT CP
                          ON CP.BUNDLE_KEY = BIX.BUNDLE_KEY
                       JOIN TIMING_DIM T
                          ON     T.TIMING_KEY = CP.TIMING_KEY
                             AND TRUNC (OIT.PURCHASE_DT) >= T.DROP_DT
                       JOIN MESSAGE_DIM M ON (M.MESSAGE_KEY = CP.MESSAGE_KEY) -- AND M.CHANNEL_KEY = 1)
                 WHERE oit.offer_key IN (SELECT OIX.OFFER_KEY
                                           FROM OFFER_ITEM_XREF OIX))
         WHERE cp_rn = 1
        UNION ALL
        (SELECT COALESCE (SOLICITED_SI_OFFER_KEY,
                          SOLICITED_CUST_OFFER_KEY,
                          SOLICITED_HH_OFFER_KEY)
                   AS SOLICITED_OFFER_KEY,
                PURCHASED_OFFER_KEY,
                VISITOR_KEY,
                CUSTOMER_KEY,
                SI_KEY,
                PRODUCT_KEY,
                ORDER_KEY,
                ORDER_LINE_KEY,
                PURCHASE_DT,
                CANCEL_EFFECTIVE_DT,
                CHANNEL,
                TERM,
                CONTRACT_SALE_PRICE,
                POLICY_PREMIUM_AMT,
                POLICY_KEY,
                'Add on' AS SALE_TYPE,
                CASE
                   WHEN SOLICITED_SI_OFFER_KEY IS NOT NULL
                   THEN
                      'Serialized Item'
                   WHEN     SOLICITED_SI_OFFER_KEY IS NULL
                        AND SOLICITED_CUST_OFFER_KEY IS NOT NULL
                   THEN
                      'Customer'
                   WHEN     SOLICITED_SI_OFFER_KEY IS NULL
                        AND SOLICITED_CUST_OFFER_KEY IS NULL
                        AND SOLICITED_HH_OFFER_KEY IS NOT NULL
                   THEN
                      'Household'
                   ELSE
                      'Unattributed'
                END
                   AS ATTRIBUTION_TYPE_TX,
                CASE WHEN FLEXPAY_IND = 'Y' THEN 1 ELSE 0 END AS FLEXPAY_IND
           FROM (SELECT SOLICITED_SI_OFFER_KEY,
                            SOLICITED_CUST_OFFER_KEY,
                            SOLICITED_HH_OFFER_KEY,
                            PURCHASED_OFFER_KEY,
                             VISITOR_KEY,
                             CUSTOMER_KEY,
                             SI_KEY,
                             PRODUCT_KEY,
                             ORDER_KEY,
                             ORDER_LINE_KEY,
                             PURCHASE_DT,
                             CANCEL_EFFECTIVE_DT,
                             CHANNEL,
                             TERM,
                             CONTRACT_SALE_PRICE,
                             POLICY_PREMIUM_AMT,
                             POLICY_KEY,
                             ROW_NUMBER ()
                              OVER ( PARTITION BY  ORDER_KEY, ORDER_LINE_KEY, OIT_OFFER_KEY  ORDER BY cpf_drop_dt desc nulls last, cpf2_DROP_DT DESC nulls last, cpf3_DROP_DT desc nulls last) AS RN,
                              FLEXPAY_IND
                   FROM CAMPAIGN_RESPONSE_ADD_ON
                ) WHERE RN = 1
          )
        ORDER BY 1, 2)
/

