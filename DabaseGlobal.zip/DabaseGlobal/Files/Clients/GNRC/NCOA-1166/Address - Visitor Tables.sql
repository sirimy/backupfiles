--Check all leads records based upon a serial or phone or email etc
select si.serial_no as EQUIPMENT, serial_no,  vpr.model_no, vpr.PARENT_MARKETING_CATEGORY_NM, AD.STATE_CD, AD.ZIP_CODE5_TX, ace_error_cd, ad.address_key,
       ad.first_nm, ad.last_nm, firm_nm, cd.customer_key, cd.household_key, vd.visitor_key, vox.primary_ind,  
       cd.customer_key, si.latest_coverage_type, ad.address_line1_tx, ad.CITY_NM, ad.source_cd, address_suppression_cd, phone_suppression_cd,
       primary_email_key, email_suppression_cd, primary_email_key, vox.si_key, pu.purl_txt, ph.PHONE_NO, em.EMAIL_ADDRESS_TX, a2.CREATION_DT
from 
     gnrc.visitor_dim vd 
    join gnrc.customer_dim cd on (cd.customer_key = vd.customer_key)
    join gnrc.address_dim ad on (ad.address_key = CD.PRIMARY_ADDRESS_KEY)
    join GNRC.VISITOR_OWNERSHIP_XREF vox on (VOX.visitor_key = vd.visitor_key)
    join GNRC.SERIALIZED_ITEM_DIM si on si.si_key = vox.si_key
    left join gnrc.purl_dim pu on pu.purl_key = primary_purl_key
    left join gnrc.EMAIL_DIM em on em.EMAIL_KEY = cd.PRIMARY_EMAIL_KEY
    left join gnrc.PHONE_DIM ph on ph.PHONE_KEY = cd.PRIMARY_PHONE_KEY
    left join gnrc.audit_tbl a2 on (a2.audit_key = cd.UPDATE_AUDIT_KEY)
    left join v_product vpr on vpr.PRODUCT_KEY = si.PRODUCT_KEY
where 1=1
--  and vox.primary_ind = 'Y'
--  and ( cd.customer_key in ( 2451152))
--   and vd.visitor_key = 567133
--    and vox.si_key =  1320587
--  and serial_no = :PID
--   and serial_no in ('3001507091', '9153154')
--   and si.si_key IN (312159 )
--  and cd.primary_email_key = 699736
   and em.EMAIL_ADDRESS_TX IN (
'DAYNA.SALTER@YMAIL.COM'
)
--    and PRIMARY_PHONE_KEY = 1298519
--    and PHONE_NO = '2812291365'
--  and ad.address_key IN (1410924, 1298 )
--  and ad.country_cd = 'CAN' and primary_email_key is not null
--   and FIRST_NM like 'PSEG%'
 --order by serial_no, ad.first_nm
  ;
