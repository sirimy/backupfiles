--raw leads data inserted by/for ncoa process
select r.*, a.CREATION_DT from gnrc.raw_leads_tbl r left join audit_tbl a on (audit_key = insert_audit_key)
 where file_nm like 'ncoa_customer_handling%'
 order by a.CREATION_DT desc;

select r.file_nm, a.CREATION_DT, count(*) as total_counts,
       count(OWNER_PHONE_NUMBER) as unique_phones, count(OWNER_EMAIL) as unique_emails
  from gnrc.raw_leads_tbl r left join audit_tbl a on (audit_key = insert_audit_key)
 where file_nm like 'ncoa_customer_handling%'
 group by file_nm, a.CREATION_DT
 order by a.CREATION_DT desc;


select r.file_nm,   count(*) as total_counts,INSERT_AUDIT_KEY
  from gnrc.raw_leads_tbl r left join audit_tbl a on (audit_key = insert_audit_key)
 where file_nm not like 'ncoa_customer_handling%' and a.CREATION_DT   >= to_date('01-01-2023','DD-MM-YYYY')
 group by file_nm,INSERT_AUDIT_KEY
Order by INSERT_AUDIT_KEY
;
+----------------------------------------+------------+----------------+
|FILE_NM                                 |TOTAL_COUNTS|INSERT_AUDIT_KEY|
+----------------------------------------+------------+----------------+
|gnrc_after_leads_2023-01-04-14-56-41.txt|2396        |811141          |
|gnrc_after_leads_2023-01-11-14-57-39.txt|2703        |814086          |
|gnrc_after_leads_2023-01-18-14-56-25.txt|2249        |815088          |
|gnrc_after_leads_2023-01-25-14-56-12.txt|1892        |815832          |
|gnrc_after_leads_adhoc_2023-01-30.txt   |1           |816824          |
|gnrc_after_leads_2023-02-01-14-56-17.txt|2376        |817097          |
|gnrc_after_leads_adhoc_2023-02-01.txt   |2           |820234          |
|gnrc_after_leads_2023-02-08-14-56-56.txt|2224        |820551          |
|gnrc_after_leads_2023-02-15-14-56-00.txt|2286        |821605          |
|gnrc_after_leads_2023-02-22-14-57-00.txt|3317        |822586          |
|gnrc_after_leads_2023-03-01-14-56-57.txt|1474        |823886          |
|gnrc_after_leads_2023-03-08-14-56-17.txt|1635        |826976          |
|gnrc_after_leads_2023-03-15-14-56-21.txt|1986        |827999          |
|gnrc_after_leads_2023-03-22-14-56-15.txt|1724        |829418          |
|gnrc_after_leads_adhoc_2023-03-27.txt   |2           |830015          |
|gnrc_after_leads_2023-03-29-14-56-40.txt|1776        |830577          |
+----------------------------------------+------------+----------------+






--shows that single phone and email is used against all the ncoa raw records
select r.file_nm, a.CREATION_DT, count(*) as total_counts,
       count(distinct OWNER_PHONE_NUMBER) as unique_phones, count(distinct OWNER_EMAIL) as unique_emails
  from gnrc.raw_leads_tbl r left join audit_tbl a on (audit_key = insert_audit_key)
 where file_nm like 'ncoa_customer_handling%'
 group by file_nm, a.CREATION_DT
 order by a.CREATION_DT desc;
/*
+-----------------------------------+--------------------------+------------+-------------+-------------+
|FILE_NM                            |CREATION_DT               |TOTAL_COUNTS|UNIQUE_PHONES|UNIQUE_EMAILS|
+-----------------------------------+--------------------------+------------+-------------+-------------+
|ncoa_customer_handling_03202023.txt|2023-03-20 10:24:53.000000|411         |1            |1            |
|ncoa_customer_handling_02282023.txt|2023-02-28 12:25:06.000000|3769        |1            |1            |
|ncoa_customer_handling_01302023.txt|2023-01-30 11:32:12.000000|317         |1            |1            |
|ncoa_customer_handling_12272022.txt|2022-12-27 14:11:28.000000|385         |1            |1            |
|ncoa_customer_handling_11142022.txt|2022-11-14 15:58:43.000000|457         |1            |1            |
|ncoa_customer_handling_10182022.txt|2022-10-18 11:49:03.000000|565         |1            |1            |
|ncoa_customer_handling_09162022.txt|2022-09-16 12:45:31.000000|419         |1            |1            |
|ncoa_customer_handling_09012022.txt|2022-09-01 10:03:52.000000|490         |1            |1            |
|ncoa_customer_handling_07222022.txt|2022-07-22 10:39:10.000000|669         |1            |1            |
|ncoa_customer_handling_06152022.txt|2022-06-15 15:01:13.000000|571         |1            |1            |
|ncoa_customer_handling_05312022.txt|2022-05-31 08:01:48.000000|315         |1            |1            |
|ncoa_customer_handling_04212022.txt|2022-04-21 09:37:05.000000|611         |1            |1            |
|ncoa_customer_handling_03182022.txt|2022-03-18 10:44:34.000000|478         |1            |1            |
|ncoa_customer_handling_03022022.txt|2022-03-02 10:35:57.000000|4135        |1            |1            |
|ncoa_customer_handling_01182022.txt|2022-01-18 11:14:44.000000|862         |1            |1            |
|ncoa_customer_handling_11192021.txt|2021-11-19 05:33:26.000000|1021        |1            |1            |
|ncoa_customer_handling_09302021.txt|2021-09-30 11:00:47.000000|463         |1            |1            |
|ncoa_customer_handling_09012021.txt|2021-09-01 04:44:10.000000|29          |1            |1            |
|ncoa_customer_handling_08232021.txt|2021-08-23 17:15:02.000000|524         |1            |1            |
|ncoa_customer_handling_07162021.txt|2021-07-16 09:22:18.000000|676         |1            |1            |
|ncoa_customer_handling_06162021.txt|2021-06-16 10:45:01.000000|658         |1            |1            |
|ncoa_customer_handling_05172021.txt|2021-05-17 11:17:05.000000|379         |1            |1            |
|ncoa_customer_handling_09172020.txt|2021-04-29 10:49:13.000000|27          |1            |1            |
|ncoa_customer_handling_04152021.txt|2021-04-15 12:13:44.000000|550         |1            |1            |
|ncoa_customer_handling_03162021.txt|2021-03-16 14:21:12.000000|433         |1            |1            |
|ncoa_customer_handling_02262021.txt|2021-02-26 10:49:00.000000|2933        |1            |1            |
|ncoa_customer_handling_01192021.txt|2021-01-19 11:26:47.000000|358         |1            |1            |
|ncoa_customer_handling_12142020.txt|2020-12-14 08:09:40.000000|313         |1            |1            |
|ncoa_customer_handling_11132020.txt|2020-11-13 07:06:38.000000|457         |1            |1            |
|ncoa_customer_handling_10222020.txt|2020-10-22 10:16:18.000000|694         |1            |1            |
|ncoa_customer_handling_09172020.txt|2020-09-17 10:33:52.000000|255         |1            |1            |
|ncoa_customer_handling_08172020.txt|2020-08-17 11:09:24.000000|586         |1            |1            |
|ncoa_customer_handling_07152020.txt|2020-07-15 15:26:56.000000|1320        |1            |1            |
|ncoa_customer_handling_06162020.txt|2020-06-16 14:23:09.000000|414         |1            |1            |
|ncoa_customer_handling_05202020.txt|2020-05-20 14:09:58.000000|285         |1            |1            |
|ncoa_customer_handling_04212020.txt|2020-04-21 09:43:36.000000|334         |1            |1            |
|ncoa_customer_handling_03232020.txt|2020-03-23 10:17:31.000000|1750        |1            |1            |
|ncoa_customer_handling_01162020.txt|2020-01-16 10:58:31.000000|607         |1            |1            |
|ncoa_customer_handling_12132019.txt|2019-12-13 15:42:19.000000|394         |1            |1            |
|ncoa_customer_handling_11132019.txt|2019-11-13 13:29:44.000000|672         |1            |1            |
|ncoa_customer_handling_10242019.txt|2019-10-24 13:58:56.000000|596         |1            |1            |
|ncoa_customer_handling_09132019.txt|2019-09-13 12:01:46.000000|1106        |1            |1            |
|ncoa_customer_handling_08162019.txt|2019-08-16 12:50:45.000000|681         |1            |1            |
|ncoa_customer_handling_07192019.txt|2019-07-19 11:19:12.000000|629         |1            |1            |
|ncoa_customer_handling_06132019.txt|2019-06-13 12:19:37.000000|838         |1            |1            |
|ncoa_customer_handling_05162019.txt|2019-05-16 10:15:40.000000|457         |1            |1            |
|ncoa_customer_handling_04172019.txt|2019-04-17 13:13:39.000000|2211        |1            |1            |
|ncoa_customer_handling_12192018.txt|2018-12-19 13:00:53.000000|656         |1            |1            |
|ncoa_customer_handling_11302018.txt|2018-11-30 09:47:55.000000|891         |1            |1            |
|ncoa_customer_handling_10252018.txt|2018-10-25 15:12:08.000000|676         |1            |1            |
|ncoa_customer_handling_09262018.txt|2018-09-26 15:03:15.000000|1349        |1            |1            |
|ncoa_customer_handling_08222018.txt|2018-08-22 09:03:22.000000|669         |1            |1            |
|ncoa_customer_handling_07182018.txt|2018-07-18 23:53:22.000000|545         |1            |1            |
|ncoa_customer_handling_07062018.txt|2018-07-06 07:12:56.000000|674         |1            |1            |
+-----------------------------------+--------------------------+------------+-------------+-------------+
 */


select count(distinct r.file_nm), count(distinct a.CREATION_DT), count(*) as total_counts, count(distinct trim(ltrim(equipment, '0'))) unique_leads,
       count(distinct OWNER_PHONE_NUMBER) as unique_phones, count(distinct OWNER_EMAIL) as unique_emails
  from gnrc.raw_leads_tbl r left join audit_tbl a on (audit_key = insert_audit_key)
 where file_nm like 'ncoa_customer_handling%';
/*
+------------------------+----------------------------+------------+------------+-------------+-------------+
|COUNT(DISTINCTR.FILE_NM)|COUNT(DISTINCTA.CREATION_DT)|TOTAL_COUNTS|UNIQUE_LEADS|UNIQUE_PHONES|UNIQUE_EMAILS|
+------------------------+----------------------------+------------+------------+-------------+-------------+
|53                      |54                          |42564       |41522       |1            |1            |
+------------------------+----------------------------+------------+------------+-------------+-------------+
 */



--Serials with multiple NCOA lead records
select --count(distinct r.file_nm), count(distinct a.CREATION_DT), count(*), count(distinct trim(ltrim(equipment, '0'))),
       --count(distinct OWNER_PHONE_NUMBER), count(distinct OWNER_EMAIL)
       a.CREATION_DT, r.*
  from gnrc.raw_leads_tbl r left join audit_tbl a on (audit_key = insert_audit_key)
 where file_nm like 'ncoa_customer_handling%'
   and trim(ltrim(equipment, '0')) in (
            select trim(ltrim(equipment, '0'))
              from gnrc.raw_leads_tbl r left join audit_tbl a on (audit_key = insert_audit_key)
             where file_nm like 'ncoa_customer_handling%'
            group by trim(ltrim(equipment, '0'))
            having count(*) >= 2
            )
order by trim(ltrim(equipment, '0')), a.CREATION_DT;


SELECT COUNT(ced.CUSTOMER_KEY) FROM GNRC.CUSTOMER_EXT_DIM ced order by CUSTOMER_KEY desc;