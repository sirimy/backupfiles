--this code is used by ~/jobs/solicitation/client_specific/ncoa_customer_handling/

--
-- DECLARE
--    v_audit_key   NUMBER;
--    v_count       INTEGER := 0;
--    v_count2       INTEGER := 0;
-- BEGIN
--   -- insert the original raw leads record for NCOA'ed customers from core into staging.
--   -- there we will set the NAME as 'GENERAC CUSTOMER' and ELAIL AND PHONE as NULL.
--   -- Processing this data using common load will create a new customer with the ownership of the serial.
--
--    v_audit_key :=
--       gnrc.get_audit_key (
--          p_program_nm       => 'GNRC-336',
--          p_author_nm        => 'drautela',
--          p_process_nm       => 'populate raw_leads_tbl in staging',
--          p_descriptive_tx   => 'GNRC-336-Update address record of NCOAed customers',
--          p_table_nm         => 'raw_leads_tbl');

  
-- Insert into raw_leads_tbl(  OWNER_NAME    ,
--                             OWNER_ADDRESS1    ,
--                             OWNER_CITY    ,
--                             OWNER_STATE    ,
--                             OWNER_POSTCODE    ,
--                             OWNER_PHONE_NUMBER    ,
--                             OWNER_EMAIL    ,
--                             EQUIPMENT    ,
--                             VALID_FROM_DATE    ,
--                             MATERIAL    ,
--                             MATERIAL_NAME    ,
--                             PURCHASE_DATE    ,
--                             PRODUCT_HIER_LEVEL1    ,
--                             PRODUCT_HIER_LEVEL1_NAME    ,
--                             PRODUCT_HIER_LEVEL2    ,
--                             PRODUCT_HIER_LEVEL2_NAME    ,
--                             MASTER_WARRANTY_NUMBER    ,
--                             MASTER_WARRANTY_DESC    ,
--                             WARRANTY_START_DATE    ,
--                             MIN_WARRANTY_END_DT    ,
--                             MAX_WARRANTY_END_DT    ,
--                             NOTIFICATION_COUNT    ,
--                             FILE_NM    ,
--                             INSERT_AUDIT_KEY    ,
--                             ERROR_DESC    ,
--                             PRODUCT_HIRE_LEVEL3    ,
--                             PRODUCT_HIRE_LEVEL_3_NAME    ,
--                             SALES_OFFICE
--                             )
select  'GENERAC OWNER' as OWNER_NAME    ,
        OWNER_ADDRESS1    ,
        OWNER_CITY    ,
        OWNER_STATE    ,
        OWNER_POSTCODE    ,
        NULL as OWNER_PHONE_NUMBER    ,
        NULL as OWNER_EMAIL    ,
        EQUIPMENT    ,
        VALID_FROM_DATE    ,
        MATERIAL    ,
        MATERIAL_NAME    ,
        PURCHASE_DATE    ,
        PRODUCT_HIER_LEVEL1    ,
        PRODUCT_HIER_LEVEL1_NAME    ,
        PRODUCT_HIER_LEVEL2    ,
        PRODUCT_HIER_LEVEL2_NAME    ,
        MASTER_WARRANTY_NUMBER    ,
        MASTER_WARRANTY_DESC    ,
        WARRANTY_START_DATE    ,
        MIN_WARRANTY_END_DT    ,
        MAX_WARRANTY_END_DT    ,
        NOTIFICATION_COUNT    ,
        'ncoa_customer_handling_'||to_char(sysdate,'MMDDYYYY')||'.txt' as FILE_NM    ,
        null as  INSERT_AUDIT_KEY    ,
        NULL as ERROR_DESC    ,
        PRODUCT_HIRE_LEVEL3    ,
        PRODUCT_HIRE_LEVEL_3_NAME    ,
        SALES_OFFICE    
          from  (  
            select RL.*, 
                   ROW_NUMBER()  OVER (PARTITION BY TC.CUSTOMER_KEY ORDER BY RL.INSERT_AUDIT_KEY DESC) AS rn
             from TMP_CUSTOMERS_NCOA TC
             join GNRC.CUSTOMER_DIM  CD
             ON ( TC.CUSTOMER_KEY = CD.CUSTOMER_KEY)
             join GNRC.VISITOR_OWNERSHIP_XREF  VOX
             ON ( VOX.VISITOR_KEY = CD.PRIMARY_VISITOR_KEY AND VOX.PRIMARY_IND = 'Y')
             join GNRC.SERIALIZED_ITEM_DIM SI
             ON  (SI.SI_KEY = VOX.SI_KEY)
             join GNRC.RAW_LEADS_TBL RL
             ON (  LTRIM(TRIM(RL.EQUIPMENT),'0') = SI.SERIAL_NO)
            where si.latest_coverage_type = 1  --(2, 5)
             ) 
        where rn = 1;


--    COMMIT;
-- END;
