
DECLARE
   v_audit_key   NUMBER;
   v_count       INTEGER := 0;
   v_count2       INTEGER := 0;
BEGIN
   -- temp table tmp_customers_to_manage will store the candidate customers where address is changed.
   -- Clean tmp_customers_to_manage
   DELETE FROM TMP_CUSTOMERS_NCOA;

   COMMIT;

   -- Process safety check -- if tables in staging have already data -- raise error

   SELECT SUM (ct)
     INTO v_count
     FROM (SELECT COUNT (*) ct FROM address_dim
           UNION ALL
           SELECT COUNT (*) ct FROM customer_dim
           UNION ALL
           SELECT COUNT (*) ct FROM visitor_address_xref
           UNION ALL
           SELECT COUNT (*) cd FROM customer_ext_dim);

   IF NVL (v_count, 0) <> 0
   THEN
      raise_application_error (
         -20001,
         'Some of the tables have data in staging. Please check and clean tables in staging before attempting for handling NCOA customer');
   END IF;


   v_audit_key :=
      gnrc.get_audit_key (
         p_program_nm       => 'GNRC-336',
         p_author_nm        => 'drautela',
         p_process_nm       => 'Update address record of NCOAed customers',
         p_descriptive_tx   => 'GNRC-336-Update address record of NCOAed customers',
         p_table_nm         => 'TMP_CUSTOMERS_NCOA');

   INSERT INTO gnrcstg.TMP_CUSTOMERS_NCOA (customer_key,
                                           current_address_key,
                                           orig_address_key,
                                           serial_no,
                                           Insert_audit_key)
    SELECT T.CUSTOMER_KEY,
           T.PRIMARY_ADDRESS_KEY,
           NULL as orig_address_key, -- This will be populated after ACE
           T.serial_no,
           V_AUDIT_KEY
        FROM (SELECT CD.CUSTOMER_KEY,
                     CD.PRIMARY_ADDRESS_KEY,
                     si.serial_no,
                     ROW_NUMBER ()
                     OVER (PARTITION BY CD.CUSTOMER_KEY ORDER BY VOX.EFF_DT_KEY DESC)
                        AS rno
                FROM GNRC.customer_dim cd
                     JOIN
                     (
                        SELECT DISTINCT
                                  onc.address_key, onc.new_address_key,
                                  FIRST_VALUE (onc.new_address_key)
                                    OVER (PARTITION BY (CONNECT_BY_ROOT onc.address_key)
                                            ORDER BY LEVEL DESC)
                                     AS new_key
                                  ,CONNECT_BY_ISCYCLE  as loop_ind
                             FROM gnrc.NCOA_FCT onc
                        CONNECT BY NOCYCLE
                           PRIOR onc.new_address_key = onc.address_key
                        ) NF
                        ON (NF.NEW_ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY)
                     JOIN
                           GNRC.VISITOR_DIM vd
                        ON (VD.CUSTOMER_KEY = CD.CUSTOMER_KEY)
                     JOIN
                           GNRC.VISITOR_OWNERSHIP_XREF vox
                        ON (    VOX.VISITOR_KEY = VD.VISITOR_KEY
                            AND VOX.PRIMARY_IND = 'Y'
                            )
                     JOIN GNRC.SERIALIZED_ITEM_DIM SI
                        ON (SI.SI_KEY = VOX.SI_KEY)
                     JOIN GNRC.V_PRODUCT VP
                        ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
                     LEFT JOIN (
                                select SERIALIZED_ITEM_KEY,MAX(PURCHASE_DT) AS ORDER_PURCHASE_DT from GNRC.ORDER_ITEM_TBL GROUP BY  SERIALIZED_ITEM_KEY
                            )  OIT on OIT.SERIALIZED_ITEM_KEY = SI.SI_KEY
                   WHERE
                     vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'
                     AND SI.LATEST_COVERAGE_TYPE in (1,2,5)
                     AND  coalesce(ORDER_PURCHASE_DT,trunc(SYSDATE) - 50) < trunc(SYSDATE) - 45
                     AND  FLOOR( (SI.LATEST_COVERAGE_EXP_DT - SI.REGISTRATION_DT)/365) <= 7

                    ) T
       WHERE     1=1
         AND T.rno = 1
         AND T.CUSTOMER_KEY NOT IN
                    (SELECT ced.CUSTOMER_KEY FROM GNRC.CUSTOMER_EXT_DIM ced );

   COMMIT;
   -- we let the table populated and qc that if there is any customers where primary_address of custmomer does not exists in the NCOA table
   -- changed address_id

   SELECT count(distinct  CD.CUSTOMER_KEY)
     INTO v_count
     FROM GNRC.customer_dim cd
    JOIN
     (
        SELECT DISTINCT
                  onc.address_key, onc.new_address_key,
                  FIRST_VALUE (onc.new_address_key)
                    OVER (PARTITION BY (CONNECT_BY_ROOT onc.address_key)
                            ORDER BY LEVEL DESC)
                     AS new_key
                  ,CONNECT_BY_ISCYCLE  as loop_ind
             FROM gnrc.NCOA_FCT onc
        CONNECT BY NOCYCLE
           PRIOR onc.new_address_key = onc.address_key
        ) NF
        ON (NF.NEW_ADDRESS_KEY = CD.PRIMARY_ADDRESS_KEY)
     JOIN
     GNRC.VISITOR_DIM vd
     ON (VD.CUSTOMER_KEY = CD.CUSTOMER_KEY)
     JOIN
     GNRC.VISITOR_OWNERSHIP_XREF vox
      ON (    VOX.VISITOR_KEY = VD.VISITOR_KEY
              AND VOX.PRIMARY_IND = 'Y'
           )
     JOIN GNRC.SERIALIZED_ITEM_DIM SI
      ON (SI.SI_KEY = VOX.SI_KEY)
     JOIN GNRC.V_PRODUCT VP
      ON (SI.PRODUCT_KEY = VP.PRODUCT_KEY)
       LEFT JOIN (
                                select SERIALIZED_ITEM_KEY,MAX(PURCHASE_DT) AS ORDER_PURCHASE_DT from GNRC.ORDER_ITEM_TBL GROUP BY  SERIALIZED_ITEM_KEY
                            )  OIT on OIT.SERIALIZED_ITEM_KEY = SI.SI_KEY
    WHERE
          vp.PARENT_MARKETING_CATEGORY_NM = 'HOME STANDBY GENERATOR'
     AND SI.LATEST_COVERAGE_TYPE in (1,2,5)
     AND  coalesce(ORDER_PURCHASE_DT,trunc(SYSDATE) - 50) < trunc(SYSDATE) - 45
     AND  FLOOR( (SI.LATEST_COVERAGE_EXP_DT - SI.REGISTRATION_DT)/365) <= 7
     AND CD.PRIMARY_ADDRESS_KEY  IN ( --simple check that, if customer's PRIMARY_ADDRESS_KEY is a new/NCOAed addrss_key

                                      select new_address_key

                                        from gnrc.NCOA_FCT onc

                                     )

     AND cd.customer_key NOT IN

                    (SELECT ced.CUSTOMER_KEY FROM GNRC.CUSTOMER_EXT_DIM ced )
                    ;


    select count(distinct customer_key)
      into v_count2
      from TMP_CUSTOMERS_NCOA;

   IF NVL (v_count, 0) <>  NVL (v_count2, 0)
   THEN
      raise_application_error (
         -20001,
         'Some of the customers primary address does not match with the changed address key in ncao_fct table');
   END IF;

END;