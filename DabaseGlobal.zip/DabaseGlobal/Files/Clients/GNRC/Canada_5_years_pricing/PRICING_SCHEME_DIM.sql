
select * from PRICING_SCHEME_DIM;


select * from GNRC.PRICING_SCHEME_DIM where PRICING_SCHEME_KEY = 40;
+------------------+--------------------------------------------+------------+----------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NM                           |EFFECTIVE_DT|END_DT    |
+------------------+--------------------------------------------+------------+----------+
|40                |AM and MPOS HSB - 7 & 10 Year Terms - CANADA|2022-08-17  |2099-12-31|
+------------------+--------------------------------------------+------------+----------+

'AM and MPOS HSB - 5 Year Terms - CANADA' ,

select * from GNRC.PRODUCT_PRICE_DIM where PRICING_SCHEME_KEY =40 order by PRODUCT_KEY,POLICY_KEY;
+------------------+-----------+----------+--------------+----+----------+-----------+
|PRICING_SCHEME_KEY|PRODUCT_KEY|POLICY_KEY|BASE_PRICE_AMT|SKU |AGE_MONTHS|TERM_MONTHS|
+------------------+-----------+----------+--------------+----+----------+-----------+
|41                |10402      |170       |825.0000      |NULL|NULL      |84         |
|40                |10402      |170       |825.0000      |NULL|NULL      |84         |
|40                |10402      |171       |1035.0000     |NULL|NULL      |120        |
+------------------+-----------+----------+--------------+----+----------+-----------+


DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual Add', p_process_nm => 'New Value for Canada PRICING_SCHEME_DIM', p_table_nm => 'PRICING_SCHEME_DIM');

BEGIN
       INSERT INTO PRICING_SCHEME_DIM
       (
            PRICING_SCHEME_KEY ,
            PRICING_SCHEME_NM ,
            EFFECTIVE_DT    ,
            END_DT,
            INSERT_AUDIT_KEY
       )
        select
            (select MAX(PRICING_SCHEME_KEY) + 1 from GNRC.PRICING_SCHEME_DIM ) ,
            'AM and MPOS HSB - 5,7 & 10 Year Terms - CANADA' ,
            TO_DATE('2023-08-11 00:00:00','YYYY-MM-DD HH24:MI:SS'),
            END_DT,
            v_audit_key
        FROM  GNRC.PRICING_SCHEME_DIM  WHERE PRICING_SCHEME_KEY = 40;


       COMMIT;

END;



DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual Add', p_process_nm => 'New Value for Canada PRICING_SCHEME_DIM', p_table_nm => 'PRICING_SCHEME_DIM');

BEGIN
       INSERT INTO PRICING_SCHEME_DIM
       (
            PRICING_SCHEME_KEY ,
            PRICING_SCHEME_NM ,
            EFFECTIVE_DT    ,
            END_DT,
            INSERT_AUDIT_KEY
       )
        select
            (select MAX(PRICING_SCHEME_KEY) + 2 from GNRC.PRICING_SCHEME_DIM ) ,
            'HSB - 6th Year - CANADA' ,
            TO_DATE('2023-08-11 00:00:00','YYYY-MM-DD HH24:MI:SS'),
            date '2099-12-31',
            v_audit_key
        FROM  GNRC.PRICING_SCHEME_DIM  WHERE PRICING_SCHEME_KEY = 23;


       COMMIT;

END;

select * from PRICING_SCHEME_DIM;
+------------------+----------------------------------------------+------------+----------+----------------+----------------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NM                             |EFFECTIVE_DT|END_DT    |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
+------------------+----------------------------------------------+------------+----------+----------------+----------------+
|42                |HSB - 6th Year - CANADA                       |2023-08-11  |2022-05-31|810998          |NULL            |
|41                |AM and MPOS HSB - 5,7 & 10 Year Terms - CANADA|2023-08-11  |2099-12-31|810984          |NULL            |
+------------------+----------------------------------------------+------------+----------+----------------+----------------+
