INSERT INTO GNRC.TERMS_AND_CONDITIONS_DIM
    (TERMS_AND_CONDITIONS_KEY, name, description, LINK_TXT, effective_dt, exp_dt, superseded_by_key, html_link_txt)
VALUES
    (16, '5 Year Power Plan - CANADA - Residential and Commercial Standby Generators', '05.2, Residential & Commercial, CAN', 'To be added',
     date '2023-08-11',date '2099-12-31', null, 'To be added');