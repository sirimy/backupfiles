-- insert into RAW_PRICING_TBL
-- select * from GNRC.RAW_PRICING_TBL where RAW_PRICING_TBL.MATERIAL_NUMBER = 'ZPD-EXWAR100001'
-- and POLICY_KEY = 162;
-- COMMIT;

-- take from last gap 170 group

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual Add', p_process_nm => 'New Value for Canada RAW_PRICING_TBL', p_table_nm => 'RAW_PRICING_TBL');

BEGIN
        update RAW_PRICING_TBL
            SET INSERT_AUDIT_KEY = v_audit_key
                ,POLICY_KEY=172
                ,FILE_NM='generac_pricing_change_GNRC-1274_Aug2023'
                ,COUNTRY = 'CANADA'
                ,EFFECTIVE_DT = date '2023-08-11';

       COMMIT;

END;

insert into RAW_PRICING_TBL
select * from GNRC.RAW_PRICING_TBL where RAW_PRICING_TBL.MATERIAL_NUMBER = 'ZPD-EXWAR100005'
and POLICY_KEY = 167;
COMMIT;


DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Manual Add', p_process_nm => 'New Value for Canada RAW_PRICING_TBL', p_table_nm => 'RAW_PRICING_TBL');

BEGIN
        update RAW_PRICING_TBL
            SET INSERT_AUDIT_KEY = v_audit_key
                ,POLICY_KEY=173
                ,FILE_NM='generac_pricing_change_GNRC-1276_Aug2023'
                ,COUNTRY = 'CANADA'
                ,EFFECTIVE_DT = date '2023-08-11'
            where RAW_PRICING_TBL.MATERIAL_NUMBER = 'ZPD-EXWAR100005';

       COMMIT;

END;