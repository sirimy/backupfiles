

  SELECT pricing_scheme_key, PRICING_SCHEME_NM, count(cr.CRITERIA_KEY)
    FROM P_CRITERIA_DIM cr
         join P_CRITERIA_CELL_XREF ccx on (ccx.criteria_key = cr.CRITERIA_KEY and ccx.POPULATION_PCT > 0)
         join P_PRICING_SCHEME_DIM psd using (PRICING_SCHEME_KEY)
   WHERE active_ind = 'Y'
    and SELECTION_TBL = 'v_outbound_universe'
    and psd.END_DT < trunc(sysdate)
  group by pricing_scheme_key, PRICING_SCHEME_NM
  order by pricing_scheme_key, PRICING_SCHEME_NM;
-- +------------------+-----------------------------------+----------------------+
-- |PRICING_SCHEME_KEY|PRICING_SCHEME_NM                  |COUNT(CR.CRITERIA_KEY)|
-- +------------------+-----------------------------------+----------------------+
-- |31                |AM                                 |10                    |
-- |33                |SWEEP HSB - 6th Year               |1                     |
-- |34                |AM and MPOS HSB - 7 & 10 Year Terms|1                     |
-- +------------------+-----------------------------------+----------------------+

 select ccx.PRICING_SCHEME_KEY,COUNT(*),COUNT( distinct CRITERIA_KEY),COUNT( distinct  CELL_KEY)
                              from  gnrc.CRITERIA_CELL_XREF ccx
                                   join gnrc.criteria_dim cr using (criteria_key)
                                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                                   join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                                   join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                                   join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
                             where 1=1
                               and active_ind = 'Y'
                               and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
                               and SELECTION_TBL = 'v_outbound_universe'
                                and ccx.pricing_scheme_key in (31,33,34)
group by ccx.PRICING_SCHEME_KEY
;
-- +------------------+--------+---------------------------+-----------------------+
-- |PRICING_SCHEME_KEY|COUNT(*)|COUNT(DISTINCTCRITERIA_KEY)|COUNT(DISTINCTCELL_KEY)|
-- +------------------+--------+---------------------------+-----------------------+
-- |31                |10      |10                         |10                     |
-- |33                |1       |1                          |1                      |
-- |34                |1       |1                          |1                      |
-- +------------------+--------+---------------------------+-----------------------+

DECLARE
       v_audit_key INTEGER := get_audit_key ( p_program_nm => 'Pricing Change', p_process_nm => 'GNRC-1838', p_table_nm => 'CRITERIA_CELL_XREF');

BEGIN


                update gnrc.CRITERIA_CELL_XREF SET pricing_scheme_key =  48,UPDATE_AUDIT_KEY = v_audit_key where PRICING_SCHEME_KEY = 31
                and (CRITERIA_KEY,CELL_KEY) in (
                    select CRITERIA_KEY,CELL_KEY
                              from  gnrc.CRITERIA_CELL_XREF ccx
                                   join gnrc.criteria_dim cr using (criteria_key)
                                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                                   join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                                   join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                                   join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
                             where 1=1
                               and active_ind = 'Y'
                               and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
                               and SELECTION_TBL = 'v_outbound_universe'
                                and ccx.pricing_scheme_key in (31)
                        );

                update gnrc.CRITERIA_CELL_XREF SET pricing_scheme_key =  49,UPDATE_AUDIT_KEY = v_audit_key where PRICING_SCHEME_KEY = 34
                and (CRITERIA_KEY,CELL_KEY) in (
                    select CRITERIA_KEY,CELL_KEY
                              from  gnrc.CRITERIA_CELL_XREF ccx
                                   join gnrc.criteria_dim cr using (criteria_key)
                                   left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                                   join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                                   join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                                   join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
                             where 1=1
                               and active_ind = 'Y'
                               and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
                               and SELECTION_TBL = 'v_outbound_universe'
                                and ccx.pricing_scheme_key in (34)
                        );



        update gnrc.CRITERIA_CELL_XREF SET pricing_scheme_key =  46,UPDATE_AUDIT_KEY = v_audit_key where PRICING_SCHEME_KEY = 33
        and (CRITERIA_KEY,CELL_KEY) in (
            select CRITERIA_KEY,CELL_KEY
                      from  gnrc.CRITERIA_CELL_XREF ccx
                           join gnrc.criteria_dim cr using (criteria_key)
                           left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
                           join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
                           join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
                           join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
                     where 1=1
                       and active_ind = 'Y'
                       and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
                       and SELECTION_TBL = 'v_outbound_universe'
                        and ccx.pricing_scheme_key in (33)
                );



        DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT );
        DBMS_OUTPUT.PUT_LINE(v_audit_key);



END;

  COMMIT;