select * from GNRC.ORDER_ITEM_TBL where SERIALIZED_ITEM_KEY in (810298,818425);
+--------------------------+---------+--------------+--------------+--------------+-------------------+----------+
|PURCHASE_DT               |ORDER_KEY|ORDER_LINE_KEY|OFFER_KEY     |OFFER_LINE_KEY|SERIALIZED_ITEM_KEY|POLICY_KEY|
+--------------------------+---------+--------------+--------------+--------------+-------------------+----------+
|2023-09-19 19:17:49.899000|743655   |1             |10253071089629|2             |810298             |171       |
|2024-04-02 21:31:24.782000|821901   |1             |9224279059929 |2             |818425             |141       |
+--------------------------+---------+--------------+--------------+--------------+-------------------+----------+

SELECT * FROM order_tbl WHERE order_id IN (743655,821901);
+--------+---------+--------------------+--------------------------+-------------+
|order_id|order_xid|created_by          |purchase_dt               |sub_total_amt|
+--------+---------+--------------------+--------------------------+-------------+
|743655  |2545046  |lcasey@afterinc.com |2023-09-19 19:17:49.899000|1035.00      |
|821901  |2584169  |smurray@afterinc.com|2024-04-02 21:31:24.782000|1015.00      |
+--------+---------+--------------------+--------------------------+-------------+

SELECT * FROM contract_order WHERE order_id IN (743655,821901);


SELECT p_populate_contract(821901);
-- price_amt 1015
-- CONTRACT_ID: 117073653
-- POPULATE THE CONTRACT TABLE FROM NEW ORDERS
-- new row for relation "contract" violates check constraint "chk_terms_id"
SELECT p_populate_contract(743655);
-- price_amt 1035
-- CONTRACT_ID: 117073655
-- POPULATE THE CONTRACT TABLE FROM NEW ORDERS
-- new row for relation "contract" violates check constraint "chk_terms_id"

SELECT
				--V_CONTRACT_ID::integer as CONTRACT_ID,
                t1.order_id,
				T7.ADDRESS_ID,
				T1.PURCHASE_DT AS CONTRACT_SALE_DT,
				T1.CUSTOMER_ID,
				T2.POLICY_ID,
				T12.TERMS_AND_CONDITIONS_ID,
				T11.STATE_ID , T12.STATE_ID
				, T2.POLICY_ID , T12.POLICY_ID
				, COALESCE(T12.CHANNEL_PARTNER_ID::numeric, 0)
				, T1.PURCHASE_DT , T12.EFFECTIVE_DT , T12.END_DT

			FROM
			      ORDER_TBL T1
				JOIN ORDER_ITEM_TBL T2
				ON (T1.ORDER_ID = T2.ORDER_ID)
				LEFT JOIN BILLING_INFO_TBL T3
				ON (T1.ORDER_ID = T3.ORDER_ID)
				LEFT JOIN
				SERIALIZED_ITEM T4
				ON (T2.SERIALIZED_ITEM_ID =
				T4.SERIALIZED_ITEM_ID)
				LEFT JOIN POLICY T6
				ON (T2.POLICY_ID = T6.POLICY_ID)
				LEFT JOIN SHIPPING_INFO_TBL T7
				ON (T1.ORDER_ID = T7.ORDER_ID)
				JOIN
				(  SELECT ORDER_ID, MAX (CURRENCY_CD) CURRENCY_CD
					FROM PAYMENT_TX_TBL
					GROUP BY ORDER_ID) T10
				ON (T1.ORDER_ID = T10.ORDER_ID)
				LEFT JOIN ADDRESS_TBL T11
				ON (T7.ADDRESS_ID = T11.ADDRESS_ID)
				LEFT JOIN
				T_AND_C_CONTRACT_TEMPLATE_XREF T12
				ON (    T11.STATE_ID = T12.STATE_ID
				AND T2.POLICY_ID = T12.POLICY_ID
				AND COALESCE(T12.CHANNEL_PARTNER_ID::numeric, 0) = 0
				AND T1.PURCHASE_DT BETWEEN T12.EFFECTIVE_DT AND T12.END_DT --CHANGED BY  AS ON 02/26/2013
				)
			WHERE     T1.ORDER_ID IN (743655,821901) AND T2.ORDER_LINE_ID = 1
			AND lower(T2.LINE_ITEM_TYPE_CD) IN ('policylineitem')
			AND (T2.POLICY_ID IS NOT NULL );

+--------+----------+--------------------------+-----------+---------+-----------------------+--------+--------+---------+---------+--------+--------------------------+------------+------+
|order_id|address_id|contract_sale_dt          |customer_id|policy_id|terms_and_conditions_id|state_id|state_id|policy_id|policy_id|coalesce|purchase_dt               |effective_dt|end_dt|
+--------+----------+--------------------------+-----------+---------+-----------------------+--------+--------+---------+---------+--------+--------------------------+------------+------+
|743655  |6292793   |2023-09-19 19:17:49.899000|1662866    |171      |NULL                   |10      |NULL    |171      |NULL     |0       |2023-09-19 19:17:49.899000|NULL        |NULL  |
|821901  |3539356   |2024-04-02 21:31:24.782000|1679322    |141      |NULL                   |38      |NULL    |141      |NULL     |0       |2024-04-02 21:31:24.782000|NULL        |NULL  |
+--------+----------+--------------------------+-----------+---------+-----------------------+--------+--------+---------+---------+--------+--------------------------+------------+------+

SELECT * FROM t_and_c_contract_template_xref WHERE state_id = 10 AND policy_id = 171;-- OLD CASE NO ROW EXIST

SELECT * FROM t_and_c_contract_template_xref WHERE state_id = 38 AND policy_id = 141;
+-----------------------+--------------------+---------+--------+--------------------------+--------------------------+----------+
|terms_and_conditions_id|contract_template_id|policy_id|state_id|effective_dt              |end_dt                    |active_ind|
+-----------------------+--------------------+---------+--------+--------------------------+--------------------------+----------+
|3                      |1                   |141      |38      |2022-01-01 00:00:00.000000|2023-08-09 00:00:00.000000|Y         |
+-----------------------+--------------------+---------+--------+--------------------------+--------------------------+----------+

SELECT * FROM terms_and_conditions WHERE terms_and_conditions_id = 3;
+-----------------------+-----------------------------------+--------------------------+--------------------------+
|terms_and_conditions_id|description                        |effective_dt              |exp_dt                    |
+-----------------------+-----------------------------------+--------------------------+--------------------------+
|3                      |10.1, Residential & Commercial, USA|2017-02-01 00:00:00.000000|2023-08-09 00:00:00.000000|
+-----------------------+-----------------------------------+--------------------------+--------------------------+
