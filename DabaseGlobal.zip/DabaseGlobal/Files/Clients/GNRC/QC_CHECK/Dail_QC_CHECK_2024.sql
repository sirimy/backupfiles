

 select COUNT( distinct SERIAL_NO),min(PROCESS_DT),max(PROCESS_DT) from GNRC.SALES_EXTRACT_FILE_TBL seft2
where PROCESS_DT > date'2024-01-18' AND SERIAL_NO in (select SERIAL_NO from missing_model_upgrade_sales);
+------------------------+-------------------+-------------------+
|COUNT(DISTINCTSERIAL_NO)|MIN(PROCESS_DT)    |MAX(PROCESS_DT)    |
+------------------------+-------------------+-------------------+
|105                     |2024-01-18 11:05:05|2024-01-18 11:05:05|
+------------------------+-------------------+-------------------+
+------------------------+-------------------+-------------------+
|COUNT(DISTINCTSERIAL_NO)|MIN(PROCESS_DT)    |MAX(PROCESS_DT)    |
+------------------------+-------------------+-------------------+
|143                     |2024-01-18 11:05:05|2024-02-01 11:05:04|
+------------------------+-------------------+-------------------+


--l_temp_text := ' There are ' || l_count || ' sales, which have not been assigned a contract.';


-- There are 61 sales, which have not been assigned a contract.

select * from GNRC.SERIALIZED_ITEM_DIM where SI_KEY in (
    select SERIALIZED_ITEM_KEY from GNRC.ORDER_ITEM_TBL where ORDER_KEY in (
        select ORDER_NO
            from (
                     select to_char(oit.order_key) as ORDER_NO, oit.ORDER_LINE_Key
                       from gnrc.order_item_tbl oit join AUDIT_TBL ai on ai.AUDIT_KEY = oit.INSERT_AUDIT_KEY
                            join gnrc.SERIALIZED_ITEM_DIM sid on oit.SERIALIZED_ITEM_KEY = sid.SI_KEY
                            join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = sid.PRODUCT_KEY
                            join gnrc.PRODUCT_CATEGORY_DIM pcd on pcd.PRODUCT_CATEGORY_KEY = pd.PRODUCT_CATEGORY_KEY
                      where ai.CREATION_DT < trunc(sysdate)  - 4
                      and pcd.MARKETING_PRODUCT_CATEGORY_NM not in ('GAS GENERATOR', 'GEMINI GENERATOR', 'DIESEL GENERATOR')
                     minus
                     (select seft2.ORDER_NO, seft2.ORDER_LINE_NO from SALES_EXTRACT_FILE_TBL seft2 where PROCESS_DT < date'2023-12-21'
                      union all
                      select seft2.ORDER_NO, seft2.ORDER_LINE_NO from GNRC.SALES_EXTRACT_FILE_TBL seft2 where PROCESS_DT < date'2023-12-21'
                     )
                 )
    ))
and  SERIAL_NO  in (
                '3006377878','3006378355','3006378441','3006394305','3006573741','3006678721','3006716324','3006954110',
                '3006954184','3006954185','3006955666','3006955987','3006990607','3006991488','3006991628','3006991769',
                '3006997719','3006998716','3006998938','3006999002','3007021023','3007021999','3007022041','3007024145',
                '3007024207','3007024323','3007024504','3007077481','3007077748','3007077832','3007088267','3007088329',
                '3007088371','3007088501','3007093129','3007093136','3007131088','3007197203','3007197215','3007206554',
                '3007206844','3007207163','3007207206','3007260995','3007261020','3007261190','3007261466','3007261660',
                '3007261860','3007302941','3007303540','3007303912','3007303928','3007309032','3007411750','3007541157',
                '3007585800','3007586216','3007587480','3007587487','3007587488','3007618425','3007618515','3007693990',
                '3007694549','3007695799','3007696516','3007696944','3007697211','3007697240','3007697278','3007700348',
                '3007700485','3007700578','3007740514','3007740733','3007741051','3007859766','3007860055','3007860829',
                '3007885052','3007885334','3007885453','3007885710','3008097465','3008098137','3008162152','3008217620',
                '3008302626','3008308564','3008308593','3008308680','3008308911','3008408953','3008409005','3008409199',
                '3008409253','3008425863','3008445187','3008445658','3008454139','3008489272','3008489300','3008493442',
                '3008493818','3008493925','3008505399','3008524733','3008524990','3008525012','3008525095','3008525353',
                '3008587292','3008587374','3008701681','3008702091','3008702651','3008702706','3008702786','3008702801',
                '3008703300','3008703372','3008704256','3008715375','3008715906','3008716029','3008716033','3008716074',
                '3008716328','3008716409','3008716700','3008717349','3008722747','3008722874','3008797687','3008798865',
                '3008798936','3008803345','3008804038','3008874720','3008944154','3008944174','3008944221','3008944336',
                '3008944368','3008944598','3008968185','3008968336','3008968534','3008968664','3008969461','3008969762',
                '3009059783','3009059802','3009060196','3009064939','3009065117','3009066018','3009066078','3009071107',
                '3009092084','3009092432','3009092636','3009098839','3009099057','3009131618','3009160394','3009161449',
                '3009161501','3009162282','3009162401','3009163152','3009181249','3009185255','3009185261','3009193211',
                '3009193917','3009194211','3009194595','3009194845','3009194854','3009206243','3009238973','3009239389',
                '3009275238','3009290228','3009298598','3009298604','3009305490','3009312791','3009532460','3009550048',
                '3009550062','3009681233','3009686851','3009701296','3009704722','3009707137','3009709324','3009709342',
                '3009709623','3009710499','3009721797','3009736776','3009748236','3009748784','3009750851','3009752748',
                '3009767360','3009802299','3009811319','3009811419','3009842263','3009843331','3009843461','3009854847',
                '3009854871','3009854894','3009866614','3009880777','3009880805','3009880965','3009881208','3009899611',
                '3009905544','3010218507','3010218611','3010219002','3010219223','3010219234','3010219497','3010219511',
                '3010220510','3010220555','3010231524','3010235177','3010248571','3010258753','3010258843','3010266700'
                    )

;



--Check dates for orders created

    select min(OT.PURCHASE_DT),max(OT.PURCHASE_DT),min(OT.ORDER_CREATED_TS),max(OT.ORDER_CREATED_TS),COUNT(*)
    ,COUNT(Distinct OIT.POLICY_KEY ),MAX(POLICY_KEY)
    from GNRC.ORDER_TBL OT join GNRC.ORDER_ITEM_TBL OIT on OT.ORDER_KEY = OIT.ORDER_KEY

    where OT.ORDER_KEY in (
        select ORDER_NO
            from (
                     select to_char(oit.order_key) as ORDER_NO, oit.ORDER_LINE_Key
                       from gnrc.order_item_tbl oit join AUDIT_TBL ai on ai.AUDIT_KEY = oit.INSERT_AUDIT_KEY
                            join gnrc.SERIALIZED_ITEM_DIM sid on oit.SERIALIZED_ITEM_KEY = sid.SI_KEY
                            join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = sid.PRODUCT_KEY
                            join gnrc.PRODUCT_CATEGORY_DIM pcd on pcd.PRODUCT_CATEGORY_KEY = pd.PRODUCT_CATEGORY_KEY
                      where ai.CREATION_DT < trunc(sysdate) -4
                      and pcd.MARKETING_PRODUCT_CATEGORY_NM not in ('GAS GENERATOR', 'GEMINI GENERATOR', 'DIESEL GENERATOR')
                     minus
                     (select seft2.ORDER_NO, seft2.ORDER_LINE_NO from SALES_EXTRACT_FILE_TBL seft2 where PROCESS_DT < date'2023-12-21'
                      union all
                      select seft2.ORDER_NO, seft2.ORDER_LINE_NO from GNRC.SALES_EXTRACT_FILE_TBL seft2 where PROCESS_DT < date'2023-12-21'
                     )
                 )
    )

;

+--------------------------+--------------------------+--------------------------+--------------------------+--------+-----------------------------+---------------+
|MIN(OT.PURCHASE_DT)       |MAX(OT.PURCHASE_DT)       |MIN(OT.ORDER_CREATED_TS)  |MAX(OT.ORDER_CREATED_TS)  |COUNT(*)|COUNT(DISTINCTOIT.POLICY_KEY)|MAX(POLICY_KEY)|
+--------------------------+--------------------------+--------------------------+--------------------------+--------+-----------------------------+---------------+
|2023-12-21 20:31:57.233000|2023-12-29 21:13:53.065000|2023-12-21 15:32:00.109526|2023-12-29 16:13:56.910055|69      |1                            |168            |
+--------------------------+--------------------------+--------------------------+--------------------------+--------+-----------------------------+---------------+


select distinct COT.ORDER_KEY,CSD.DESCRIPTION,CT.CONTRACT_KEY,CX.SI_KEY from GNRC.CONTRACT_ORDER_TBL COT
             JOIN GNRC.CONTRACT_DIM CT on CT.CONTRACT_KEY = COT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_COVERAGE_XREF CX on CX.CONTRACT_KEY = CT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_STATUS_DIM CSD on CT.CONTRACT_STATUS_KEY =   CSD.CONTRACT_STATUS_KEY
    where ORDER_KEY in (select distinct OIT2.ORDER_KEY
                        from GNRC.SERIALIZED_ITEM_DIM SID
                                 JOIN GNRC.ORDER_ITEM_TBL OIT2
                                      on OIT2.SERIALIZED_ITEM_KEY = SID.SI_KEY
                        where SI_KEY in (select SERIALIZED_ITEM_KEY
                                         from GNRC.ORDER_ITEM_TBL
                                         where ORDER_KEY in (select ORDER_NO
                                                             from (select to_char(oit.order_key) as ORDER_NO, oit.ORDER_LINE_Key
                                                                   from gnrc.order_item_tbl oit
                                                                            join AUDIT_TBL ai on ai.AUDIT_KEY = oit.INSERT_AUDIT_KEY
                                                                            join gnrc.SERIALIZED_ITEM_DIM sid on oit.SERIALIZED_ITEM_KEY = sid.SI_KEY
                                                                            join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = sid.PRODUCT_KEY
                                                                            join gnrc.PRODUCT_CATEGORY_DIM pcd
                                                                                 on pcd.PRODUCT_CATEGORY_KEY = pd.PRODUCT_CATEGORY_KEY
                                                                   where ai.CREATION_DT < trunc(sysdate) --- 4
                                                                     and pcd.MARKETING_PRODUCT_CATEGORY_NM not in
                                                                         ('GAS GENERATOR', 'GEMINI GENERATOR',
                                                                          'DIESEL GENERATOR')
                                                                   minus
                                                                   (select seft2.ORDER_NO, seft2.ORDER_LINE_NO
                                                                    from SALES_EXTRACT_FILE_TBL seft2
                                                                    union all
                                                                    select seft2.ORDER_NO, seft2.ORDER_LINE_NO
                                                                    from GNRC.SALES_EXTRACT_FILE_TBL seft2))))
                          and SERIAL_NO in (
                                            '3006377878', '3006378355', '3006378441', '3006394305', '3006573741',
                                            '3006678721', '3006716324', '3006954110',
                                            '3006954184', '3006954185', '3006955666', '3006955987', '3006990607',
                                            '3006991488', '3006991628', '3006991769',
                                            '3006997719', '3006998716', '3006998938', '3006999002', '3007021023',
                                            '3007021999', '3007022041', '3007024145',
                                            '3007024207', '3007024323', '3007024504', '3007077481', '3007077748',
                                            '3007077832', '3007088267', '3007088329',
                                            '3007088371', '3007088501', '3007093129', '3007093136', '3007131088',
                                            '3007197203', '3007197215', '3007206554',
                                            '3007206844', '3007207163', '3007207206', '3007260995', '3007261020',
                                            '3007261190', '3007261466', '3007261660',
                                            '3007261860', '3007302941', '3007303540', '3007303912', '3007303928',
                                            '3007309032', '3007411750', '3007541157',
                                            '3007585800', '3007586216', '3007587480', '3007587487', '3007587488',
                                            '3007618425', '3007618515', '3007693990',
                                            '3007694549', '3007695799', '3007696516', '3007696944', '3007697211',
                                            '3007697240', '3007697278', '3007700348',
                                            '3007700485', '3007700578', '3007740514', '3007740733', '3007741051',
                                            '3007859766', '3007860055', '3007860829',
                                            '3007885052', '3007885334', '3007885453', '3007885710', '3008097465',
                                            '3008098137', '3008162152', '3008217620',
                                            '3008302626', '3008308564', '3008308593', '3008308680', '3008308911',
                                            '3008408953', '3008409005', '3008409199',
                                            '3008409253', '3008425863', '3008445187', '3008445658', '3008454139',
                                            '3008489272', '3008489300', '3008493442',
                                            '3008493818', '3008493925', '3008505399', '3008524733', '3008524990',
                                            '3008525012', '3008525095', '3008525353',
                                            '3008587292', '3008587374', '3008701681', '3008702091', '3008702651',
                                            '3008702706', '3008702786', '3008702801',
                                            '3008703300', '3008703372', '3008704256', '3008715375', '3008715906',
                                            '3008716029', '3008716033', '3008716074',
                                            '3008716328', '3008716409', '3008716700', '3008717349', '3008722747',
                                            '3008722874', '3008797687', '3008798865',
                                            '3008798936', '3008803345', '3008804038', '3008874720', '3008944154',
                                            '3008944174', '3008944221', '3008944336',
                                            '3008944368', '3008944598', '3008968185', '3008968336', '3008968534',
                                            '3008968664', '3008969461', '3008969762',
                                            '3009059783', '3009059802', '3009060196', '3009064939', '3009065117',
                                            '3009066018', '3009066078', '3009071107',
                                            '3009092084', '3009092432', '3009092636', '3009098839', '3009099057',
                                            '3009131618', '3009160394', '3009161449',
                                            '3009161501', '3009162282', '3009162401', '3009163152', '3009181249',
                                            '3009185255', '3009185261', '3009193211',
                                            '3009193917', '3009194211', '3009194595', '3009194845', '3009194854',
                                            '3009206243', '3009238973', '3009239389',
                                            '3009275238', '3009290228', '3009298598', '3009298604', '3009305490',
                                            '3009312791', '3009532460', '3009550048',
                                            '3009550062', '3009681233', '3009686851', '3009701296', '3009704722',
                                            '3009707137', '3009709324', '3009709342',
                                            '3009709623', '3009710499', '3009721797', '3009736776', '3009748236',
                                            '3009748784', '3009750851', '3009752748',
                                            '3009767360', '3009802299', '3009811319', '3009811419', '3009842263',
                                            '3009843331', '3009843461', '3009854847',
                                            '3009854871', '3009854894', '3009866614', '3009880777', '3009880805',
                                            '3009880965', '3009881208', '3009899611',
                                            '3009905544', '3010218507', '3010218611', '3010219002', '3010219223',
                                            '3010219234', '3010219497', '3010219511',
                                            '3010220510', '3010220555', '3010231524', '3010235177', '3010248571',
                                            '3010258753', '3010258843', '3010266700'
                            ))
Order by SI_KEY,CONTRACT_KEY;





select * from GNRC.SERIALIZED_ITEM_DIM where SI_KEY in (
    select SERIALIZED_ITEM_KEY from GNRC.ORDER_ITEM_TBL where ORDER_KEY in (
        select ORDER_NO
            from (
                     select to_char(oit.order_key) as ORDER_NO, oit.ORDER_LINE_Key
                       from gnrc.order_item_tbl oit join AUDIT_TBL ai on ai.AUDIT_KEY = oit.INSERT_AUDIT_KEY
                            join gnrc.SERIALIZED_ITEM_DIM sid on oit.SERIALIZED_ITEM_KEY = sid.SI_KEY
                            join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = sid.PRODUCT_KEY
                            join gnrc.PRODUCT_CATEGORY_DIM pcd on pcd.PRODUCT_CATEGORY_KEY = pd.PRODUCT_CATEGORY_KEY
                      where ai.CREATION_DT < trunc(sysdate)  - 4
                      and pcd.MARKETING_PRODUCT_CATEGORY_NM not in ('GAS GENERATOR', 'GEMINI GENERATOR', 'DIESEL GENERATOR')
                     minus
                     (select seft2.ORDER_NO, seft2.ORDER_LINE_NO from SALES_EXTRACT_FILE_TBL seft2 where PROCESS_DT < date'2023-12-21'
                      union all
                      select seft2.ORDER_NO, seft2.ORDER_LINE_NO from GNRC.SALES_EXTRACT_FILE_TBL seft2 where PROCESS_DT < date'2023-12-21'
                     )
                 )
    ))
and  SERIAL_NO  in (
               '3006991769','3010219497','3009239389','3010219223','3007696944','3008308680',
'3008445658','3009161501','3009181249','3010248571','3008489300','3009854894',
'3009842263','3007207163','3006394305','3008715375','3006999002','3009843331',
'3009748236','3009881208','3008722874','3007860829','3009752748','3009704722',
'3007741051','3008717349','3009312791','3008703372','3009767360','3008445187',
'3009880777','3008968664','3009811319','3009866614','3006377878','3009298598',
'3009305490','3009160394','3009194211','3008803345','3009802299','3007694549',
'3010235177','3007021023','3008716074','3010218507','3008493925','3007303912',
'3008493818','3009750851','3008162152','3009092636','3009162401','3009194854',
'3008798865','3008308593','3008704256','3009059783','3009709623','3007696516',
'3007697278','3008944154','3009550062','3007093136','3007260995','3008409199',
'3006716324','3008944598','3007088501','3007695799','3006997719','3008302626',
'3009905544','3008217620','3007131088','3009736776','3008587292','3009701296',
'3008524990','3009854871','3010219511','3007303540','3008703300','3007261860',
'3008454139','3007024145','3008968336','3009811419','3007587480','3009880805',
'3007207206','3008505399','3008797687','3009185255','3009298604','3009059802',
'3009899611','3010266700','3008944221','3007077481','3008944368','3007740514',
'3009060196','3009854847','3007693990','3007697240','3008409253','3008722747',
'3006998938','3007261466','3008969762','3009193917','3007697211','3008587374',
'3007303928','3007618425','3009092084','3007885334','3007885453','3007088371',
'3006991488','3007541157','3009161449','3007859766','3009066078','3009686851',
'3007077748','3009550048','3008715906','3010220510','3007586216','3008944336',
'3008308911','3009193211','3007302941'
                    )

;

select '''' || SERIAL_NO || ''',' from missing_model_upgrade_sales  where SERIAL_NO not in(
select SERIAL_NO from GNRC.SERIALIZED_ITEM_DIM where SI_KEY in (
    ( select mim.SI_KEY from missing_model_upgrade_sales_cancelled_jan_2024 mim)
))
;--102

COMMIT;


select COUNT(*) from MISSING_MODEL_UPGRADE_SALES_CANCELLED_JAN_2024;--105
select COUNT(*) from MISSING_MODEL_UPGRADE_SALES_CANCELLED_JAN_2024;--143

COMMIT;
------------------------------------
-- insert into MISSING_MODEL_UPGRADE_SALES_CANCELLED_JAN_2024
-- (
--     ORDER_KEY ,
--     DESCRIPTION,
--     CONTRACT_KEY,
--     SI_KEY       ,
--     SOURCE_SYSTEM_CD,
--     RAW_DESCRIPTION ,
--     CONTRACT_XID
-- )
Select
       TB1.ORDER_KEY AS TB1_ORDER_KEY,
       TB1.DESCRIPTION AS TB1_DESCRIPTION,
       TB1.CONTRACT_KEY AS TB1_CONTRACT_KEY,
       TB1.SI_KEY AS TB1_SI_KEY ,
       TB1.SOURCE_SYSTEM_CD AS TB1_SOURCE_SYSTEM_CD,
       TB1.RAW_DESCRIPTION AS TB1_RAW_DESCRIPTION,
       TB1.CONTRACT_XID AS TB1_CONTRACT_XID
from (
select distinct rct.SALES_DOCUMENT,COT.ORDER_KEY,CSD.DESCRIPTION,CT.CONTRACT_KEY,CX.SI_KEY ,clkp.SOURCE_SYSTEM_CD,rct.DESCRIPTION AS RAW_DESCRIPTION,clkp.CONTRACT_XID from GNRC.CONTRACT_ORDER_TBL COT
             JOIN GNRC.CONTRACT_DIM CT on CT.CONTRACT_KEY = COT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_COVERAGE_XREF CX on CX.CONTRACT_KEY = CT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_STATUS_DIM CSD on CT.CONTRACT_STATUS_KEY =   CSD.CONTRACT_STATUS_KEY
             left join gnrc.CONTRACT_LKP clkp on clkp.CONTRACT_KEY = CT.CONTRACT_KEY and clkp.SOURCE_SYSTEM_CD = 0
             left join gnrc.RAW_CONTRACT_TBL rct on rct.SALES_DOCUMENT = clkp.CONTRACT_XID --and rct.DESCRIPTION is not null
    where ORDER_KEY in (select distinct OIT2.ORDER_KEY
                        from GNRC.SERIALIZED_ITEM_DIM SID
                                 JOIN GNRC.ORDER_ITEM_TBL OIT2
                                      on OIT2.SERIALIZED_ITEM_KEY = SID.SI_KEY
                        where SI_KEY in (select SERIALIZED_ITEM_KEY
                                         from GNRC.ORDER_ITEM_TBL
                                         where ORDER_KEY in (select ORDER_NO
                                                             from (select to_char(oit.order_key) as ORDER_NO, oit.ORDER_LINE_Key
                                                                   from gnrc.order_item_tbl oit
                                                                            join AUDIT_TBL ai on ai.AUDIT_KEY = oit.INSERT_AUDIT_KEY
                                                                            join gnrc.SERIALIZED_ITEM_DIM sid on oit.SERIALIZED_ITEM_KEY = sid.SI_KEY
                                                                            join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = sid.PRODUCT_KEY
                                                                            join gnrc.PRODUCT_CATEGORY_DIM pcd
                                                                                 on pcd.PRODUCT_CATEGORY_KEY = pd.PRODUCT_CATEGORY_KEY
                                                                   where ai.CREATION_DT < trunc(sysdate)
                                                                     and pcd.MARKETING_PRODUCT_CATEGORY_NM not in
                                                                         ('GAS GENERATOR', 'GEMINI GENERATOR',
                                                                          'DIESEL GENERATOR')
                                                                   minus
                                                                   (select seft2.ORDER_NO, seft2.ORDER_LINE_NO
                                                                    from SALES_EXTRACT_FILE_TBL seft2
                                                                    union all
                                                                    select seft2.ORDER_NO, seft2.ORDER_LINE_NO
                                                                    from GNRC.SALES_EXTRACT_FILE_TBL seft2))))
                          and SERIAL_NO in  ( select SERIAL_NO from missing_model_upgrade_sales))

)   TB1 join
 (
select distinct rct.SALES_DOCUMENT,COT.ORDER_KEY,CSD.DESCRIPTION,CT.CONTRACT_KEY,CX.SI_KEY ,clkp.SOURCE_SYSTEM_CD,rct.DESCRIPTION AS RAW_DESCRIPTION,clkp.CONTRACT_XID from GNRC.CONTRACT_ORDER_TBL COT
             JOIN GNRC.CONTRACT_DIM CT on CT.CONTRACT_KEY = COT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_COVERAGE_XREF CX on CX.CONTRACT_KEY = CT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_STATUS_DIM CSD on CT.CONTRACT_STATUS_KEY =   CSD.CONTRACT_STATUS_KEY
             left join gnrc.CONTRACT_LKP clkp on clkp.CONTRACT_KEY = CT.CONTRACT_KEY and clkp.SOURCE_SYSTEM_CD = 2
             left join gnrc.RAW_CONTRACT_TBL rct on rct.SALES_DOCUMENT = clkp.CONTRACT_XID --and rct.DESCRIPTION is not null
    where ORDER_KEY in (select distinct OIT2.ORDER_KEY
                        from GNRC.SERIALIZED_ITEM_DIM SID
                                 JOIN GNRC.ORDER_ITEM_TBL OIT2
                                      on OIT2.SERIALIZED_ITEM_KEY = SID.SI_KEY
                        where SI_KEY in (select SERIALIZED_ITEM_KEY
                                         from GNRC.ORDER_ITEM_TBL
                                         where ORDER_KEY in (select ORDER_NO
                                                             from (select to_char(oit.order_key) as ORDER_NO, oit.ORDER_LINE_Key
                                                                   from gnrc.order_item_tbl oit
                                                                            join AUDIT_TBL ai on ai.AUDIT_KEY = oit.INSERT_AUDIT_KEY
                                                                            join gnrc.SERIALIZED_ITEM_DIM sid on oit.SERIALIZED_ITEM_KEY = sid.SI_KEY
                                                                            join gnrc.PRODUCT_DIM pd on pd.PRODUCT_KEY = sid.PRODUCT_KEY
                                                                            join gnrc.PRODUCT_CATEGORY_DIM pcd
                                                                                 on pcd.PRODUCT_CATEGORY_KEY = pd.PRODUCT_CATEGORY_KEY
                                                                   where ai.CREATION_DT < trunc(sysdate)
                                                                     and pcd.MARKETING_PRODUCT_CATEGORY_NM not in
                                                                         ('GAS GENERATOR', 'GEMINI GENERATOR',
                                                                          'DIESEL GENERATOR')
                                                                   minus
                                                                   (select seft2.ORDER_NO, seft2.ORDER_LINE_NO
                                                                    from SALES_EXTRACT_FILE_TBL seft2
                                                                    union all
                                                                    select seft2.ORDER_NO, seft2.ORDER_LINE_NO
                                                                    from GNRC.SALES_EXTRACT_FILE_TBL seft2))))
                          and SERIAL_NO in  ( select SERIAL_NO from missing_model_upgrade_sales))
)   TB2      on TB1.SI_KEY =TB2.SI_KEY AND TB1.ORDER_KEY < 790000 AND tb1.DESCRIPTION <> tb2.DESCRIPTION
where TB1.RAW_DESCRIPTION is not null
and (TB1.ORDER_KEY,TB1.CONTRACT_KEY,TB1.SI_KEY) not in (select ORDER_KEY,CONTRACT_KEY,SI_KEY from MISSING_MODEL_UPGRADE_SALES_CANCELLED_JAN_2024)
Order by tb1.DESCRIPTION;

-------------------------------------






Select
       TB1.SALES_DOCUMENT,
       TB1.ORDER_KEY AS TB1_ORDER_KEY,
       TB1.DESCRIPTION AS TB1_DESCRIPTION,
       TB1.CONTRACT_KEY AS TB1_CONTRACT_KEY,
       TB1.SI_KEY AS TB1_SI_KEY ,
       TB1.SOURCE_SYSTEM_CD AS TB1_SOURCE_SYSTEM_CD,
       TB1.RAW_DESCRIPTION AS TB1_RAW_DESCRIPTION,
       TB1.CONTRACT_XID AS TB1_CONTRACT_XID
       ,TB2.ORDER_KEY AS TB2_ORDER_KEY,
        TB2.DESCRIPTION AS TB2_DESCRIPTION,
        TB2.CONTRACT_KEY AS TB2_CONTRACT_KEY,
        TB2.SI_KEY AS TB2_SI_KEY ,
        TB2.SOURCE_SYSTEM_CD AS TB2_SOURCE_SYSTEM_CD,
        TB2.RAW_DESCRIPTION AS TB2_RAW_DESCRIPTION,
        TB2.CONTRACT_XID AS TB2_CONTRACT_XID

from (
select distinct rct.SALES_DOCUMENT,COT.ORDER_KEY,CSD.DESCRIPTION,CT.CONTRACT_KEY,CX.SI_KEY ,clkp.SOURCE_SYSTEM_CD,rct.DESCRIPTION AS RAW_DESCRIPTION,clkp.CONTRACT_XID from GNRC.CONTRACT_ORDER_TBL COT
             JOIN GNRC.CONTRACT_DIM CT on CT.CONTRACT_KEY = COT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_COVERAGE_XREF CX on CX.CONTRACT_KEY = CT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_STATUS_DIM CSD on CT.CONTRACT_STATUS_KEY =   CSD.CONTRACT_STATUS_KEY
             left join gnrc.CONTRACT_LKP clkp on clkp.CONTRACT_KEY = CT.CONTRACT_KEY and clkp.SOURCE_SYSTEM_CD = 0
             left join gnrc.RAW_CONTRACT_TBL rct on rct.SALES_DOCUMENT = clkp.CONTRACT_XID --and rct.DESCRIPTION is not null
    where ORDER_KEY in (select distinct OIT2.ORDER_KEY
                        from GNRC.SERIALIZED_ITEM_DIM SID
                                 JOIN GNRC.ORDER_ITEM_TBL OIT2
                                      on OIT2.SERIALIZED_ITEM_KEY = SID.SI_KEY
                        where  SERIAL_NO in  ( select SERIAL_NO from missing_model_upgrade_sales))

)   TB1 join
 (
select distinct rct.SALES_DOCUMENT,COT.ORDER_KEY,CSD.DESCRIPTION,CT.CONTRACT_KEY,CX.SI_KEY ,clkp.SOURCE_SYSTEM_CD,rct.DESCRIPTION AS RAW_DESCRIPTION,clkp.CONTRACT_XID
            from GNRC.CONTRACT_ORDER_TBL COT
             JOIN GNRC.CONTRACT_DIM CT on CT.CONTRACT_KEY = COT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_COVERAGE_XREF CX on CX.CONTRACT_KEY = CT.CONTRACT_KEY
             JOIN GNRC.CONTRACT_STATUS_DIM CSD on CT.CONTRACT_STATUS_KEY =   CSD.CONTRACT_STATUS_KEY
             left join gnrc.CONTRACT_LKP clkp on clkp.CONTRACT_KEY = CT.CONTRACT_KEY and clkp.SOURCE_SYSTEM_CD = 2
             left join gnrc.RAW_CONTRACT_TBL rct on rct.SALES_DOCUMENT = clkp.CONTRACT_XID --and rct.DESCRIPTION is not null
    where ORDER_KEY in (select distinct OIT2.ORDER_KEY
                        from GNRC.SERIALIZED_ITEM_DIM SID
                                 JOIN GNRC.ORDER_ITEM_TBL OIT2
                                      on OIT2.SERIALIZED_ITEM_KEY = SID.SI_KEY
                        where   SERIAL_NO in  ( select SERIAL_NO from missing_model_upgrade_sales))
)   TB2      on TB1.SI_KEY =TB2.SI_KEY AND TB1.ORDER_KEY < 790000 AND tb1.DESCRIPTION <> tb2.DESCRIPTION
where TB1.RAW_DESCRIPTION is not null
Order by tb1.DESCRIPTION;