

select * from OFFER_LOG_TBL where serialized_item_id = 8482738 order by log_date desc;
-- +------------------+-----------+
-- |serialized_item_id|customer_id|
-- +------------------+-----------+
-- |8482738           |3002802    |
-- +------------------+-----------+

SELECT DISTINCT si.SERIALIZED_ITEM_ID,ppt.POLICY_ID,
                             CASE
				WHEN CTS.OFFSET_PURCHASE_DT_IND = 1
				THEN
				   date_trunc('day',SI.PURCHASE_DT) + (CTS.DELAY_DAYS * interval '1 day')
				WHEN CTS.OFFSET_WARRANTY_EXP_DT_IND = 1
				THEN
				   date_trunc('day',SI.WARRANTY_EXPIRATION_DT) + (CTS.DELAY_DAYS * interval '1 day'  )
			     END AS COVERAGE_START_DT,

			     CASE
				WHEN CTS.OFFSET_PURCHASE_DT_IND = 1
				THEN
				   date_trunc('day',SI.PURCHASE_DT) + (CTS.DELAY_DAYS * interval '1 day') + (ppt.TERM_MONTHS * interval '1 month') - interval  '1 days'
				WHEN CTS.OFFSET_WARRANTY_EXP_DT_IND = 1
				THEN
				   date_trunc('day',SI.WARRANTY_EXPIRATION_DT) + (CTS.DELAY_DAYS * interval '1 days'  ) + (ppt.TERM_MONTHS * interval '1 month') - interval  '1 days'
			     END AS COVERAGE_END_DT,

			     ppt.BASE_PRICE_AMT,
			     ppt.TERM_MONTHS
			FROM
			(SELECT si.*, cn.country_3byte_cd, coalesce(six.enhanced_warranty_ind, 'N') as enhanced_warranty_ind, vpr.parent_category_nm, vpr.brand_nm
			   from serialized_item si join ownership_xref ox on ox.serialized_item_id = si.serialized_item_id and ox.current_owner_ind = 'Y'
				join customer_tbl cust on cust.customer_id = ox.customer_id
				join address_tbl adr on adr.address_id = cust.primary_address_id
				join state st on st.state_id = adr.state_id
				join country cn on cn.country_id = st.country_id
			    left join serialized_item_ext six on six.serialized_item_id = si.serialized_item_id
                join v_product vpr on vpr.product_id = si.product_id
                where si.latest_coverage_type_id IN (1,3,6,17,20,2,5,10) and si.serialized_item_id=8482738) si -- Changed for ticket GNRC-306 ( Allow real time offer creation for generac suppressed serials)
			JOIN pricing_scheme_lkp psl
			   ON (case
                     when si.country_3byte_cd = 'USA' and si.brand_nm = 'GENERAC' and si.latest_coverage_type_id IN (1,3,6,17,20,10) and parent_category_nm IN ('RESIDENTIAL HKW A/C HSB', 'RESIDENTIAL LKW A/C HSB', 'PORTABLE GAS GENERATORS', 'RESIDENTIAL GASEOUS L/C HSB 1')
                     then
                         case
                              when date_part('YEAR', current_date) - date_part('YEAR', si.purchase_dt) between 6 and 9  then 33    --Products registered 5 or more years ago     --AO 6th year
                              when date_part('YEAR', current_date) - date_part('YEAR', si.purchase_dt) <  5  AND si.latest_coverage_exp_dt >= current_date AND enhanced_warranty_ind = 'N' then 31    --AI
                              when date_part('YEAR', current_date) - date_part('YEAR', si.purchase_dt) <  5  AND si.latest_coverage_exp_dt >= current_date AND enhanced_warranty_ind = 'Y' then 34    --AI Enhanced Warranty
                              when date_part('YEAR', current_date) - date_part('YEAR', si.purchase_dt) <  4  AND si.latest_coverage_exp_dt <  current_date AND enhanced_warranty_ind = 'N' then 34    --RE  --7 and 10 year term
                              when date_part('YEAR', current_date) - date_part('YEAR', si.purchase_dt) <  4  AND si.latest_coverage_exp_dt <  current_date AND enhanced_warranty_ind = 'Y' then 35    --RE Enhanced Warranty --10 year term only
                              when date_part('YEAR', current_date) - date_part('YEAR', si.purchase_dt) in (4, 5)  AND si.latest_coverage_exp_dt <  current_date then 34    --RW   --7 and 10 year term
                         end
                     when si.country_3byte_cd = 'USA' and si.brand_nm = 'GENERAC' and si.latest_coverage_type_id IN (2,5) AND si.latest_coverage_exp_dt >= current_date - interval '6 month' and parent_category_nm IN ('RESIDENTIAL HKW A/C HSB', 'RESIDENTIAL LKW A/C HSB', 'PORTABLE GAS GENERATORS', 'RESIDENTIAL GASEOUS L/C HSB 1')
                     then
                         case
                              when round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5  then 37    --5 year upgrade
                              when round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7  then 36    --3 year upgrade
                         end
                     when si.country_3byte_cd = 'USA' and si.brand_nm = 'HONEYWELL' and si.latest_coverage_type_id IN (1,3,6,17,20,10) and parent_category_nm IN ('RESIDENTIAL HKW A/C HSB', 'RESIDENTIAL LKW A/C HSB', 'PORTABLE GAS GENERATORS', 'RESIDENTIAL GASEOUS L/C HSB 1')
                     then
                         case
                              when extract(day from current_date - si.purchase_dt) < 1600  AND si.latest_coverage_exp_dt >= current_date AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5 then 34    --offer 7 and 10 year terms --Units with 5 year warranty
                              when extract(day from current_date - si.purchase_dt) between 1601 and 1825 AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5 then 33                                    --Products registered approx from 4.4 up to 5 years ago     --AO 6th year pricing --Units with 5 year warranty
                              when extract(day from current_date - si.purchase_dt) < 2340  AND si.latest_coverage_exp_dt >= current_date AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7 then 35    --offer 10 year term only   --Units with 7 year warranty
                              when extract(day from current_date - si.purchase_dt) between 2341 and 2520 AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7 then 33                                    --Products registered approx from 6.4 up to 7 years ago     --AO 6th year pricing --Units with 7 year warranty
                         end
				     when si.country_3byte_cd = 'CAN' and si.brand_nm = 'GENERAC' and si.latest_coverage_type_id IN (1,3,6,17,20) and parent_category_nm IN ('RESIDENTIAL HKW A/C HSB', 'RESIDENTIAL LKW A/C HSB', 'PORTABLE GAS GENERATORS')
                     then
                         case
                              when date_part('YEAR', current_date) - date_part('YEAR', si.purchase_dt) <  5  AND si.latest_coverage_exp_dt >= current_date then 40    --MPOS & AI
                         end
                     when si.country_3byte_cd = 'CAN' and si.brand_nm = 'GENERAC' and si.latest_coverage_type_id IN (2,5) AND si.latest_coverage_exp_dt >= current_date and parent_category_nm IN ('RESIDENTIAL HKW A/C HSB', 'RESIDENTIAL LKW A/C HSB', 'RESIDENTIAL GASEOUS L/C HSB 1')
                     then
                         case
                              when round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5  then 44    --5 year upgrade
                              when round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7  then 43    --3 year upgrade
                         end
                     end = psl.pricing_scheme_id
			      )
			JOIN product_price_tbl ppt
			  ON ( si.product_id = ppt.product_id and psl.pricing_scheme_id = ppt.pricing_scheme_id)
			JOIN policy pol
			  ON ( ppt.POLICY_ID = pol.POLICY_ID AND current_date between pol.effective_dt and pol.exp_dt)
			JOIN COVERAGE_TIMING_STRATEGY CTS
			  ON ( cts.coverage_timing_strategy_id = pol.coverage_timing_strategy_id)
		    JOIN product pr
			  ON pr.product_id = ppt.product_id
            JOIN brand br
              ON br.brand_id = pr.brand_id
	WHERE 1=1
-- 	    AND coalesce(pr.do_not_solicit_ind, 'N') <> 'Y'
--         AND   coalesce(br.do_not_solicit_ind, 'N') <> 'Y'
   ORDER BY ppt.TERM_MONTHS ASC;

+------------------+----------+--------------------------+--------------+-----------+----------+---------------+--------+--------------------------+--------------------------+-----------------+--------+--------------+-----------------------+--------------------------+------------------+---------------+----------------+---------------------+-----------------------+---------+
|serialized_item_id|serial_num|purchase_dt               |purchase_price|currency_cd|product_id|last_updated_by|dml_flag|warranty_expiration_dt    |last_updated_ts           |warranty_start_dt|scrap_dt|end_of_life_dt|latest_coverage_type_id|latest_coverage_exp_dt    |user_input_req_ind|attributes_json|country_3byte_cd|enhanced_warranty_ind|parent_category_nm     |brand_nm |
+------------------+----------+--------------------------+--------------+-----------+----------+---------------+--------+--------------------------+--------------------------+-----------------+--------+--------------+-----------------------+--------------------------+------------------+---------------+----------------+---------------------+-----------------------+---------+
|8482738           |3011928653|2023-05-09 00:00:00.000000|NULL          |USD        |6642002   |gnrc           |NULL    |2025-05-08 00:00:00.000000|2023-07-14 06:52:25.057319|NULL             |NULL    |NULL          |1                      |2025-05-08 00:00:00.000000|NULL              |NULL           |USA             |N                    |RESIDENTIAL HKW A/C HSB|HONEYWELL|
+------------------+----------+--------------------------+--------------+-----------+----------+---------------+--------+--------------------------+--------------------------+-----------------+--------+--------------+-----------------------+--------------------------+------------------+---------------+----------------+---------------------+-----------------------+---------+

    select * from product_price_tbl ppt
			  where  6642002 = ppt.product_id; -- and psl.pricing_scheme_id = ppt.pricing_scheme_id)


+-----------------------+-----------------------+----------------+---------+------------------+----------+----------+--------------------------+
|latest_coverage_type_id|parent_category_nm     |country_3byte_cd|brand_nm |serialized_item_id|serial_num|product_id|purchase_dt               |
+-----------------------+-----------------------+----------------+---------+------------------+----------+----------+--------------------------+
|1                      |RESIDENTIAL HKW A/C HSB|USA             |HONEYWELL|8482738           |3011928653|6642002   |2023-05-09 00:00:00.000000|
+-----------------------+-----------------------+----------------+---------+------------------+----------+----------+--------------------------+

--extract(day from current_date - si.purchase_dt) = 531
--  si.latest_coverage_exp_dt =   2025-05-08
--  round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 2

select --psl.pricing_scheme_id  ,
extract(day from current_date - si.purchase_dt)
,si.latest_coverage_exp_dt
,round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365)
FROM
			(SELECT si.*, cn.country_3byte_cd, coalesce(six.enhanced_warranty_ind, 'N') as enhanced_warranty_ind, vpr.parent_category_nm, vpr.brand_nm
			   from serialized_item si join ownership_xref ox on ox.serialized_item_id = si.serialized_item_id and ox.current_owner_ind = 'Y'
				join customer_tbl cust on cust.customer_id = ox.customer_id
				join address_tbl adr on adr.address_id = cust.primary_address_id
				join state st on st.state_id = adr.state_id
				join country cn on cn.country_id = st.country_id
			    left join serialized_item_ext six on six.serialized_item_id = si.serialized_item_id
                join v_product vpr on vpr.product_id = si.product_id
                where si.latest_coverage_type_id IN (1,3,6,17,20,2,5,10) and si.serialized_item_id=8482738) si -- Changed for ticket GNRC-306 ( Allow real time offer creation for generac suppressed serials)
			JOIN pricing_scheme_lkp psl
			   ON (case

                     when si.country_3byte_cd = 'USA' and si.brand_nm = 'HONEYWELL' and si.latest_coverage_type_id IN (1,3,6,17,20,10) and parent_category_nm IN ('RESIDENTIAL HKW A/C HSB', 'RESIDENTIAL LKW A/C HSB', 'PORTABLE GAS GENERATORS', 'RESIDENTIAL GASEOUS L/C HSB 1')
                     then
                         case
                              when extract(day from current_date - si.purchase_dt) < 1600  AND si.latest_coverage_exp_dt >= current_date AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5 then 34    --offer 7 and 10 year terms --Units with 5 year warranty
                              when extract(day from current_date - si.purchase_dt) between 1601 and 1825 AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 5 then 33                                    --Products registered approx from 4.4 up to 5 years ago     --AO 6th year pricing --Units with 5 year warranty
                              when extract(day from current_date - si.purchase_dt) < 2340  AND si.latest_coverage_exp_dt >= current_date AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7 then 35    --offer 10 year term only   --Units with 7 year warranty
                              when extract(day from current_date - si.purchase_dt) between 2341 and 2520 AND round(extract(day from si.latest_coverage_exp_dt - si.purchase_dt)/365) = 7 then 33                                    --Products registered approx from 6.4 up to 7 years ago     --AO 6th year pricing --Units with 7 year warranty
                         end

                     end = psl.pricing_scheme_id
			      );

select * from pricing_scheme_lkp where pricing_scheme_id in (34,35,33);
+-----------------------+-------------------+--------------------+-----------------+
|latest_coverage_type_id|days_from_covrg_low|days_from_covrg_high|pricing_scheme_id|
+-----------------------+-------------------+--------------------+-----------------+
|1                      |1826               |2191                |33               |
|1                      |-730               |0                   |34               |
|1                      |0                  |365                 |35               |
+-----------------------+-------------------+--------------------+-----------------+


 select pricing_scheme_id,COUNT(*) from pricing_scheme_lkp where pricing_scheme_id  in(31,32,33,34,35,36,37,39,40,41,42,43,44,45)
GROUP BY pricing_scheme_id
order by pricing_scheme_id;