BEGIN
    PK_CAMPAIGN.s_000_pre_campaign_safety_chk;
END;