--
-- BEGIN
--     pk_campaign_utilities.prc_create_campaign('ESPC','CU','Canada Semi-Annual Sweep Upgrade');
-- END;

-- BEGIN
--     pk_campaign_utilities.prc_create_cell_group('CU','CU-01','Semi-Annual Sweep Upgrade 1 Effort CANADA');
-- END;

-- BEGIN
--     pk_campaign_utilities.prc_create_cell('CU-01','CU01HSBGEN60','01','N','Semi-Annual Sweep Upgrade 1 Effort - =60 Month HSB Generac Canada');
--     pk_campaign_utilities.prc_create_cell('CU-01','CU01HSBGEN84','01','N','Semi-Annual Sweep Upgrade 1 Effort - =84 Month HSB Generac Canada');
-- end;

-- BEGIN
--     pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2099','CU','Tuesday');
-- end;

-- BEGIN
--     pk_campaign_utilities.prc_populate_timing_dim('01-JUN-2016','31-DEC-2099','CU','Tuesday');
-- end;


BEGIN
    pk_campaign_utilities.prc_populate_criteria('CU00-HSBGEN60' , 'CU000', '', '', 'between drop_dt +35 and drop_dt +727', '2','>= 60' ,'', 'v_available_universe', 'brand_family_cd= ''GNH'' and Registration_Dt>= DATE ''2017-01-01'' and Residential_Dealer_Ind= ''N'' and NCOA_Ind= ''N'' and Country_Cd= ''CAN'' and Enhanced_Warranty_Ind= ''N''' );
    pk_campaign_utilities.prc_populate_criteria('CU00-HSBGEN84' , 'CU000', '', '', 'between drop_dt +35 and drop_dt +1455', '2','>= 84' ,'', 'v_available_universe', 'brand_family_cd= ''GNH'' and Registration_Dt>= DATE ''2017-01-01'' and Residential_Dealer_Ind= ''N'' and NCOA_Ind= ''N'' and Country_Cd= ''CAN'' and Enhanced_Warranty_Ind= ''N''' );
    pk_campaign_utilities.prc_populate_criteria('CU00-HSBGEN60' , 'CU000', '', '', 'between drop_dt +35 and drop_dt +727', '5','>= 60' ,'', 'v_available_universe', 'brand_family_cd= ''GNH'' and Registration_Dt>= DATE ''2017-01-01'' and Residential_Dealer_Ind= ''N'' and NCOA_Ind= ''N'' and Country_Cd= ''CAN'' and Enhanced_Warranty_Ind= ''N''' );
    pk_campaign_utilities.prc_populate_criteria('CU00-HSBGEN84' , 'CU000', '', '', 'between drop_dt +35 and drop_dt +1455', '5','>= 84' ,'', 'v_available_universe', 'brand_family_cd= ''GNH'' and Registration_Dt>= DATE ''2017-01-01'' and Residential_Dealer_Ind= ''N'' and NCOA_Ind= ''N'' and Country_Cd= ''CAN'' and Enhanced_Warranty_Ind= ''N''' );

end;

BEGIN
   pk_campaign_utilities.prc_populate_criteria_cell('CU00-HSBGEN60','CU01HSBGEN60','','1');
    pk_campaign_utilities.prc_populate_criteria_cell('CU00-HSBGEN84','CU01HSBGEN84','','1');

end;

    SELECT cell_key
    FROM v_cell_lkp
    WHERE 'CU01HSBGEN84' = cell_xid;


    SELECT *
    FROM criteria_dim vcl join CRITERIA_DIM CF on vcl.CRITERIA_KEY = CF.CRITERIA_KEY
    WHERE 'CU00-HSBGEN60' = vcl.criteria_xid;
+------------+-------------+------------+-------------+-----------+----------+
|CRITERIA_KEY|CRITERIA_XID |CRITERIA_KEY|CRITERIA_XID |CRITERIA_CD|ACTIVE_IND|
+------------+-------------+------------+-------------+-----------+----------+
|102464      |CU00-HSBGEN60|102464      |CU00-HSBGEN60|CU000      |Y         |
|102466      |CU00-HSBGEN60|102466      |CU00-HSBGEN60|CU000      |Y         |
+------------+-------------+------------+-------------+-----------+----------+

CREATE TABLE CRITERIA_DIM_HOLD_TWO_ENTRY AS select * from CRITERIA_DIM  where CRITERIA_KEY in(102466,102467) ;
select * from CRITERIA_DIM_HOLD_TWO_ENTRY;
+------------+-------------+-----------+----------+-----------+---------------+-------------------------------------+--------------------+
|CRITERIA_KEY|CRITERIA_XID |CRITERIA_CD|ACTIVE_IND|PURCHASE_DT|REGISTRATION_DT|LATEST_COVERAGE_EXP_DT               |LATEST_COVERAGE_TYPE|
+------------+-------------+-----------+----------+-----------+---------------+-------------------------------------+--------------------+
|102466      |CU00-HSBGEN60|CU000      |Y         |NULL       |NULL           |between drop_dt +35 and drop_dt +727 |5                   |
|102467      |CU00-HSBGEN84|CU000      |Y         |NULL       |NULL           |between drop_dt +35 and drop_dt +1455|5                   |
+------------+-------------+-----------+----------+-----------+---------------+-------------------------------------+--------------------+

delete from CRITERIA_DIM  where CRITERIA_KEY in(102466,102467) ;


select * from CRITERIA_CELL_XREF;
+------------+--------+------------------+--------------+----------------+----------------+
|CRITERIA_KEY|CELL_KEY|PRICING_SCHEME_KEY|POPULATION_PCT|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
+------------+--------+------------------+--------------+----------------+----------------+
|102464      |100867  |NULL              |1.00          |911560          |NULL            |
|102465      |100868  |NULL              |1.00          |911561          |NULL            |
+------------+--------+------------------+--------------+----------------+----------------+

insert Into CRITERIA_DIM
select * from CRITERIA_DIM_HOLD_TWO_ENTRY;
COMMIT;


insert into CRITERIA_CELL_XREF
    (CRITERIA_KEY,CELL_KEY,PRICING_SCHEME_KEY,POPULATION_PCT,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY)
select 102466,CELL_KEY,PRICING_SCHEME_KEY,POPULATION_PCT,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY from CRITERIA_CELL_XREF where CRITERIA_KEY = 102464;
COMMIT;
insert into CRITERIA_CELL_XREF
    (CRITERIA_KEY,CELL_KEY,PRICING_SCHEME_KEY,POPULATION_PCT,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY)
select 102467,CELL_KEY,PRICING_SCHEME_KEY,POPULATION_PCT,INSERT_AUDIT_KEY,UPDATE_AUDIT_KEY from CRITERIA_CELL_XREF where CRITERIA_KEY = 102465;
COMMIT;
+------------+--------+------------------+--------------+----------------+----------------+
|CRITERIA_KEY|CELL_KEY|PRICING_SCHEME_KEY|POPULATION_PCT|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
+------------+--------+------------------+--------------+----------------+----------------+
|102464      |100867  |NULL              |1.00          |911560          |NULL            |
|102465      |100868  |NULL              |1.00          |911561          |NULL            |
|102466      |100867  |NULL              |1.00          |911560          |NULL            |
|102467      |100868  |NULL              |1.00          |911561          |NULL            |
+------------+--------+------------------+--------------+----------------+----------------+

 delete from tmp_messages;
 commit;
insert into tmp_messages
select * from "Message_dim_temp";
Commit;

select * from tmp_messages;
+------------+------+-----------+------------+
|CELL_XID    |EFFORT|MESSAGE_XID|DM_COPY_CODE|
+------------+------+-----------+------------+
|CU00HSBGEN60|1     |GC1DMCU1   |GC1DMCU1    |
|CU00HSBGEN84|1     |GC1DMCU1   |GC1DMCU1    |
+------------+------+-----------+------------+

    BEGIN
        pk_campaign_utilities.prc_build_state_cell_group('CS-1','CU-01');

    end;