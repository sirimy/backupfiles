--https://mail.google.com/mail/u/0/#inbox/WhctKJVzhRvLNqTqWXvCKzTbKNZZKvcKkNWJJvzjHNCwDpXqGMJtZWmrcNLJhqtmQDHhClv
select --CRITERIA_KEY,	CRITERIA_XID,	CRITERIA_CD, REGISTRATION_DT, WARRANTY_MONTHS, ADDITIONAL_SQL_TXT, ai.CREATION_DT     --	LATEST_COVERAGE_EXP_DT, LATEST_COVERAGE_TYPE, ADDITIONAL_SQL_TXT, ai.CREATION_DT
        ai.creation_dt, cri.*, au.creation_dt as updated_dt
  from P_criteria_dim cri left join audit_tbl ai on (ai.audit_key = insert_audit_key)  left join audit_tbl au on (au.audit_key = update_audit_key)
 where 1=1
   and active_ind = 'Y'
--    and active_ind IN ('Y', 'Z', 'X')
   and SELECTION_TBL <> 'v_outbound_universe'
--    and BRAND_NM is null
--    and BRAND_NM = 'HONEYWELL'
--    and BRAND_NM = 'GENERAC'
--    and (CRITERIA_XID like 'A6%' or CRITERIA_XID like 'RW%') -- or CRITERIA_XID like 'RE%')
--   and (criteria_xid LIKE '%MP07%' or criteria_xid LIKE '%MP07%')
--    and criteria_xid like 'MP%-%' --and criteria_xid not like '%N'
--    and CRITERIA_cd like 'M7%'
--       and CRITERIA_CD like 'MC%'
--      and (CRITERIA_CD like 'AI045%' or CRITERIA_CD like 'OAIB04%')
--    and WARRANTY_MONTHS like '%60%'
--       and WARRANTY_MONTHS like '%84%'
--     and warranty_months like '%>=%24'
--   and nvl(WARRANTY_MONTHS, '00') not like '%12'
--      and WARRANTY_MONTHS not in ('24', '60', '84')
--   and WARRANTY_MONTHS is null
--    and criteria_cd not like 'U%'
--    and criteria_cd like 'M%5%'
--    and CRITERIA_KEY = 87105
--    and CRITERIA_XID like '%60%' and CRITERIA_XID not like 'U%'
--    and criteria_xid like 'AI%'
--   and (criteria_xid like 'AI03%' or criteria_cd like 'AI04%')
--   and (criteria_xid like 'IS%' or criteria_cd like 'FS%')
--    and criteria_xid like 'UE%'
--    and criteria_cd like 'RE%'
--    and criteria_xid like 'AI%' --and CRITERIA_XID like '%24'
--   and (CRITERIA_XID like 'US%' or CRITERIA_XID like 'UP%' or CRITERIA_XID like 'UM%' or CRITERIA_XID like 'UN%')
--     and CRITERIA_CD like 'MC%'
--     and CRITERIA_CD like 'OU%'
--   and regexp_like(criteria_cd, 'A[O6QCT]+')
--   and regexp_like(criteria_xid, 'A[IR]+')
--   and criteria_xid not LIKE '%N' and CRITERIA_XID like '%05-%'
--    and criteria_xid like 'L%'
--    and criteria_xid like 'U%'    --60U and 60RU
--      and (criteria_cd like 'AI%' or criteria_cd like 'MC%' or CRITERIA_CD like 'RE%')
--    and criteria_xid not like '%NN'    --NCOA
--    and additional_sql_txt LIKE '%HONEYWELL%'
--    and additional_sql_txt LIKE '%GNH%'
    and additional_sql_txt LIKE '%HNH%'
--    and REGISTRATION_DT is not null
--      and LATEST_COVERAGE_EXP_DT is not null
--   and criteria_xid NOT LIKE '%GENN' and criteria_xid NOT LIKE '%24N'  --exclude NCOA
--   and additional_sql_txt NOT LIKE '%Residential_Dealer_Ind%'
--   and additional_sql_txt LIKE '%Residential_Dealer_Ind= ''Y%'''
   and additional_sql_txt LIKE '%CAN%'
--   and lower(additional_sql_txt) LIKE '%enhanced_warranty_ind%=%y%'
   and criteria_xid LIKE '%HSB%'
--   and criteria_xid LIKE '%POR%'
--   and criteria_xid LIKE 'MD%'
--   and criteria_xid LIKE '%N' and (ADDITIONAL_SQL_TXT like '%NCOA_Ind IN ( ''Y'', ''X'')%' or ADDITIONAL_SQL_TXT like '%NCOA_Ind= ''X''%')
--   and registration_dt is not null
--   and criteria_key in (100441
-- )
--   and CRITERIA_KEY in (select ccx.criteria_key from P_CRITERIA_CELL_XREF ccx where ccx.POPULATION_PCT > 0)
--   and ai.creation_dt < date '2019-12-01'
--   and ai.creation_dt > date '2024-12-01'
--    and ADDITIONAL_SQL_TXT like '%US_Sweep_Leads%'
--    and CRITERIA_KEY in (80364, 80365, 80366)
-- and CRITERIA_KEY in (27399,47748,64158,64159,82386)
--    and LATEST_COVERAGE_TYPE = '1'
--   and LATEST_COVERAGE_TYPE IN ('2', '5')
--    and upper(LATEST_COVERAGE_TYPE) like '%IN%'
-- order by CRITERIA_KEY
--  order by criteria_cd, CRITERIA_XID, criteria_key;
-- order by CRITERIA_CD, CRITERIA_XID, ai.CREATION_DT desc --, LATEST_COVERAGE_TYPE
order by CREATION_DT, CRITERIA_XID
;
 
 --Residential_Dealer_Ind will be added to list of Criteria_Dim Constants

select * from gnrc.criteria_cell_xref join gnrc.criteria_dim using(criteria_key)
 where 1=1
   and active_ind = 'Y'
   and pricing_scheme_key = 1   
--   and additional_sql_txt LIKE '%HONEYWELL%'
   ;

select distinct CREATION_DT, campaign_xid, CAMPAIGN_NM, CRITERIA_KEY, CRITERIA_CD, criteria_xid, WARRANTY_MONTHS, LATEST_COVERAGE_TYPE --, criteria_cd, active_ind --, warranty_months, LATEST_COVERAGE_EXP_DT
        ,ccx.pricing_scheme_key, pricing_scheme_nm
       ,cl.control_ind, cell_key, cell_xid, cell_cd, cell_nm, POPULATION_PCT
       ,cell_group_xid, cell_group_nm
       ,cell_group_key, cg.campaign_key, REGISTRATION_DT, LATEST_COVERAGE_EXP_DT, ADDITIONAL_SQL_TXT, STREAM_LENGTH_DAYS
       --, copy_cd, m.dim_status_cd, form_cd --,
       --,state_key, state_nm, EFFORT_NO
       ,STATE_MACHINE_NM, state_machine_key
  from  gnrc.CRITERIA_CELL_XREF ccx
       join gnrc.criteria_dim cr using (criteria_key)
       left join audit_tbl ai on (ai.audit_key = ccx.insert_audit_key)
       join gnrc.cell_dim cl using (cell_key) join gnrc.cell_group_dim cg using (cell_group_key)
       join gnrc.campaign_dim cmp on (cmp.campaign_key = cg.campaign_key)
       join gnrc.pricing_scheme_dim psd on psd.pricing_scheme_key = ccx.pricing_scheme_key
       left join gnrc.state_message_xref sx using (cell_key)
       --left join gnrc.message_dim m on (m.message_key = sx.message_key)
       left join gnrc.state_tbl s using (state_key)
       left join gnrc.STATE_MACHINE_TBL sm using (state_machine_key)
 where 1=1
   and active_ind = 'Y'
   and coalesce(POPULATION_PCT, 0) > 0 --and upper(CELL_NM) not like '%TEST'
   and selection_tbl <> 'v_outbound_universe'
--    and BRAND_NM = 'GENERAC'
--    and criteria_key = 64271
--    and (CRITERIA_XID like 'A6%' ) -- or CRITERIA_XID like 'RW%' or CRITERIA_XID like 'RE%')
--    and CRITERIA_CD like 'MA%'
--    and criteria_xid like 'MP07%'
--    and criteria_xid like 'R%' and WARRANTY_MONTHS like '%60%'
--    and criteria_xid like 'MP05%24%' and CRITERIA_CD like 'M%'
--    and (criteria_xid like 'AI%'  or criteria_xid like 'AR%')
--    and not (criteria_xid like 'AI%'  or criteria_xid like 'HA%')
--    and CRITERIA_XID like '%24'
--    and criteria_xid like 'R%'
--    and (--CRITERIA_XID like 'US%' or CRITERIA_XID like 'UP%' or
--         CRITERIA_XID like 'UM%' or CRITERIA_XID like 'UN%')
--    and CRITERIA_XID like 'U%'
--    and regexp_like(criteria_cd, 'A[O6QCT]+')
--    and criteria_xid like 'AI03-PORGEN%'
--    and criteria_xid like '%60'
--    and (criteria_xid not like '%60U' and criteria_xid not like '%60RU')
   and criteria_xid NOT LIKE '%POR%'
--    and criteria_xid LIKE '%HSB%'
--    and WARRANTY_MONTHS like '%60%'
--    and WARRANTY_MONTHS like '%60%'
--     and WARRANTY_MONTHS like '%84%'
--      and CAMPAIGN_NM like '%After%'
--    and ADDITIONAL_SQL_TXT LIKE '%GNH%'  --Generac brand only
    and additional_sql_txt LIKE '%HNH%'   --Honeywell brand only
--    and BRAND_NM = 'GENERAC'
--    and CELL_NM NOT LIKE '%NCOA%' and CELL_NM NOT LIKE '%GB 1000%'
   and upper(CELL_NM) LIKE '%CAN%'
--    and upper(CELL_NM) LIKE '%1000%'
--       and CELL_NM like 'Upgrade Early%'
--       and campaign_xid IN ('AJ')
--    and upper(additional_sql_txt) LIKE '%TO_NUMBER%'
   and additional_sql_txt LIKE '%CAN%'
--   and lower(cell_nm) like '%enhanced warranty%'
--    and criteria_xid not like 'U%'
--   and cell_key IN (64219)
--    and cell_cd = '01'
--   and nvl(m.dim_status_cd, 'Y') <> 'N'
--   and m.channel_key = 1
--   and copy_cd = 'GDMMs1a'
   --and form_cd = 'GNFM0417'
--   AND NVL(cl.control_ind, 'N') IN ('Y', 'C')
--    and CONTROL_IND = 'B'
--    and lower(additional_sql_txt) LIKE '%enhanced_warranty_ind%=%y%'
--    and cell_group_key = 17828
--    and ccx.pricing_scheme_key IN (42, 47, 33)
--       and ccx.PRICING_SCHEME_KEY in (select psd.PRICING_SCHEME_KEY from P_PRICING_SCHEME_DIM psd where psd.EFFECTIVE_DT >= date '2025-07-01')
--    and LATEST_COVERAGE_TYPE = '1'
--    and LATEST_COVERAGE_TYPE in ('2', '5')
--  and ai.creation_dt >= date '2025-05-01'
 order by campaign_xid, CRITERIA_CD, criteria_xid, cell_xid, LATEST_COVERAGE_TYPE
-- order by ai.creation_dt, CRITERIA_XID
   ;

select count(*) from gnrc.CRITERIA_CELL_XREF_AUDIT;
--538
select * from gnrc.CRITERIA_CELL_XREF_AUDIT order by INSERTED_DT desc nulls last ;


select count(*), count(distinct bundle_key)
  from gnrc.CRITERIA_DIM cr
       join p_bundle_dim bd using (criteria_key)
       join p_campaign_participation_fct cp using (bundle_key)
       join p_timing_dim tm using (timing_key)
       join p_base_offer_item_xref boix using (bundle_key)
 where ACTIVE_IND = 'Y'
   and SELECTION_TBL <> 'v_outbound_universe'
   and bd.DROP_DT + cr.STREAM_LENGTH_DAYS >= date '2025-08-01'
   and boix.TERM_KEY = 7;
-- COUNT(*),COUNT(DISTINCTBUNDLE_KEY)
-- 1130573,206341


