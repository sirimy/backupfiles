select creation_dt, x.state_key, x.message_key, x.cell_key, state_nm, effort_no, message_nm, cell_nm
  from gnrc.state_message_xref x join audit_tbl a on (audit_key = insert_audit_key)
       join gnrc.state_tbl s on s.state_key = x.state_key
       join gnrc.message_dim m on m.message_key = x.message_key
       join gnrc.cell_dim cl on cl.cell_key = x.cell_key
where creation_dt >= date '2025-01-01'
order by x.state_key, x.cell_key;



