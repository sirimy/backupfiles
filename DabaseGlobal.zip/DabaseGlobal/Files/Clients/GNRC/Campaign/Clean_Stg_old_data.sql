--Clean-up Staging
delete from gnrcStg.CELL_DIM where CELL_KEY in (select CELL_KEY from gnrc.cell_dim);
delete from gnrcStg.CELL_group_DIM where CELL_group_key in (select CELL_group_key from gnrc.CELL_group_DIM);
delete from gnrcStg.CAMPAIGN_DIM where CAMPAIGN_KEY in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_DIM);
delete from gnrcStg.CAMPAIGN_EXT_DIM where CAMPAIGN_KEY in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_EXT_DIM);
delete from gnrcStg.criteria_dim where CRITERIA_KEY in (select CRITERIA_KEY from gnrc.criteria_dim);
commit;



----------------------------------------------------------------------
--Populate staging with required campaign and cell groups
insert into CAMPAIGN_DIM select * from gnrc.CAMPAIGN_DIM where CAMPAIGN_XID in ('CU')
   and CAMPAIGN_KEY not in (select c.CAMPAIGN_KEY from CAMPAIGN_DIM c);
-- rows
commit;

select * from gnrc.CELL_GROUP_DIM where CAMPAIGN_KEY in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_DIM where CAMPAIGN_XID in ( 'CU' ));
insert into CELL_GROUP_DIM
select * from gnrc.CELL_GROUP_DIM where CAMPAIGN_KEY in (select CAMPAIGN_KEY from gnrc.CAMPAIGN_DIM
                                                          where CAMPAIGN_XID in ( 'CU' ))
  and CELL_GROUP_KEY not in (select cg.CELL_GROUP_KEY from CELL_GROUP_DIM cg);
-- rows
commit;
----------------------------------------------------------------------