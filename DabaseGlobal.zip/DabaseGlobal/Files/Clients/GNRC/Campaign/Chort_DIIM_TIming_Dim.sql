
select EXTRACT(YEAR FROM FULL_DT) AS FULL_DT,COUNT(*)  from FAS.DATE_DIM
where  EXTRACT(YEAR FROM FULL_DT) > 2030
group by EXTRACT(YEAR FROM FULL_DT)
;--



-------------------------------------------------------------------------------------------------------------
--Creating data for UE campaign only as it was missing from March pull
-------------------------------------------------------------------------------------------------------------
select * from gnrc.COHORT_DIM where CAMPAIGN_KEY = 76786 and COHORT_DT >= date '2030-12-01';

--Make sure that campaign in question exists in staging else it will raise FK violation
select * from CAMPAIGN_DIM order by CAMPAIGN_XID;

--This proc will not create cohorts, which exist already so it is safe to pass same start-end dates again
begin
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045','UE','Tuesday');
end;

select * from COHORT_DIM ;

select max(COHORT_DT) from gnrc.COHORT_DIM ;
-- 2030-12-31

select CAMPAIGN_XID, max(COHORT_DT) from gnrc.COHORT_DIM join gnrc.CAMPAIGN_DIM using (campaign_key) group by CAMPAIGN_XID order by CAMPAIGN_XID;
+------------+--------------+
|CAMPAIGN_XID|MAX(COHORT_DT)|
+------------+--------------+
|A6          |2030-12-31    |
|AC          |2029-12-25    |
|AI          |2030-12-31    |
|AJ          |2030-12-31    |
|AO          |2029-12-25    |
|AP          |2029-12-25    |
|AQ          |2029-12-25    |
|AR          |2029-12-25    |
|AS          |2029-12-25    |
|AT          |2029-12-25    |
|CH          |2030-12-31    |
|CR          |2030-12-31    |
|CS          |2030-12-31    |
|CT          |2029-12-25    |
|CU          |2030-12-31    |
|FS          |2029-12-25    |
|HA          |2030-12-31    |
|HB          |2030-12-31    |
|HM          |2030-12-31    |
|HN          |2030-12-31    |
|IS          |2029-12-25    |
|LC          |2029-12-25    |
|LS          |2029-12-25    |
|M6          |2030-12-31    |
|MA          |2029-12-25    |
|MB          |2029-12-25    |
|MC          |2030-12-31    |
|MD          |2030-12-31    |
|ME          |2030-12-31    |
|MP          |2030-12-31    |
|MQ          |2030-12-31    |
|MR          |2029-12-25    |
|MS          |2029-12-25    |
|MU          |2029-12-25    |
|MW          |2029-12-25    |
|OA6         |2029-12-25    |
|OAI         |2029-12-25    |
|OAO         |2029-12-25    |
|OMP         |2029-12-25    |
|ORE         |2029-12-25    |
|OUP         |2029-12-25    |
|OUS         |2029-12-25    |
|RD          |2029-12-25    |
|RE          |2030-12-31    |
|RF          |2030-12-31    |
|RR          |2029-12-25    |
|RS          |2029-12-25    |
|RW          |2030-12-31    |
|RX          |2030-12-31    |
|UA          |2029-12-25    |
|UE          |2030-12-31    |
|UM          |2030-12-31    |
|UP          |2030-12-31    |
|US          |2029-12-25    |
+------------+--------------+


begin
    P_PK_CORE_UPDATE.INSERT_TBL('COHORT_DIM');
end;


-------------------------------------------------------------------------------------------------------------
--Now Creating cohort data for all the campaigns (for year 2030 only)
-------------------------------------------------------------------------------------------------------------
select max(COHORT_DT) from gnrc.COHORT_DIM ;
-- 2045-12-26


select CAMPAIGN_XID, max(COHORT_DT) from gnrc.COHORT_DIM join gnrc.CAMPAIGN_DIM using (campaign_key) group by CAMPAIGN_XID order by CAMPAIGN_XID;
+------------+--------------+
|CAMPAIGN_XID|MAX(COHORT_DT)|
+------------+--------------+
|UE          |2045-12-26    |
|A6          |2030-12-31    |
|AI          |2030-12-31    |
|AJ          |2030-12-31    |
|CH          |2030-12-31    |
|CR          |2030-12-31    |
|CS          |2030-12-31    |
|CU          |2030-12-31    |
|HA          |2030-12-31    |
|HB          |2030-12-31    |
|HM          |2030-12-31    |
|HN          |2030-12-31    |
|M6          |2030-12-31    |
|MC          |2030-12-31    |
|MD          |2030-12-31    |
|ME          |2030-12-31    |
|MP          |2030-12-31    |
|MQ          |2030-12-31    |
|RE          |2030-12-31    |
|RF          |2030-12-31    |
|RW          |2030-12-31    |
|RX          |2030-12-31    |
|UM          |2030-12-31    |
|UP          |2030-12-31    |
|AC          |2029-12-25    |
|AO          |2029-12-25    |
|AP          |2029-12-25    |
|AQ          |2029-12-25    |
|AR          |2029-12-25    |
|AS          |2029-12-25    |
|AT          |2029-12-25    |
|CT          |2029-12-25    |
|FS          |2029-12-25    |
|IS          |2029-12-25    |
|LC          |2029-12-25    |
|LS          |2029-12-25    |
|MA          |2029-12-25    |
|MB          |2029-12-25    |
|MR          |2029-12-25    |
|MS          |2029-12-25    |
|MU          |2029-12-25    |
|MW          |2029-12-25    |
|OA6         |2029-12-25    |
|OAI         |2029-12-25    |
|OAO         |2029-12-25    |
|OMP         |2029-12-25    |
|ORE         |2029-12-25    |
|OUP         |2029-12-25    |
|OUS         |2029-12-25    |
|RD          |2029-12-25    |
|RR          |2029-12-25    |
|RS          |2029-12-25    |
|UA          |2029-12-25    |
|US          |2029-12-25    |
+------------+--------------+



--populate all active campaigns into staging to avoid FK violations
insert into CAMPAIGN_DIM (CAMPAIGN_KEY, CAMPAIGN_XID, CAMPAIGN_NM, CAMPAIGN_DSC, START_DT, END_DT, PROGRAM_KEY, CAMPAIGN_STATUS_CD, DIM_STATUS_CD, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY)
select CAMPAIGN_KEY, CAMPAIGN_XID, CAMPAIGN_NM, CAMPAIGN_DSC, START_DT, END_DT, PROGRAM_KEY, CAMPAIGN_STATUS_CD, DIM_STATUS_CD, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY
  from gnrc.CAMPAIGN_DIM
 where CAMPAIGN_KEY in (
select campd.campaign_key
  from p_criteria_dim c
                JOIN p_criteria_cell_xref ccx
                ON (c.criteria_key = ccx.criteria_key)
                JOIN p_cell_dim cd
                ON ccx.cell_key = cd.cell_key
                JOIN p_cell_group_dim cgd
                ON (cd.cell_group_key= cgd.cell_group_key)
                JOIN p_campaign_dim campd
                ON (cgd.campaign_key= campd.campaign_key)
where c.ACTIVE_IND = 'Y' and ccx.POPULATION_PCT > 0
  and SELECTION_TBL <> 'v_outbound_universe'
minus
select campaign_key from CAMPAIGN_DIM)
order by 2, 1;
commit;
-- [2026-05-06 13:20:29] 23 rows affected in 340 ms

select distinct CAMPAIGN_XID,
    'pk_campaign_utilities.prc_populate_cohort_dim(''01-JAN-2013''' || ',' || '''31-DEC-2045''' || ', ''' || CAMPAIGN_XID || ''',' || '''Tuesday''' || ');'
  from p_criteria_dim c
                JOIN p_criteria_cell_xref ccx
                ON (c.criteria_key = ccx.criteria_key)
                JOIN p_cell_dim cd
                ON ccx.cell_key = cd.cell_key
                JOIN p_cell_group_dim cgd
                ON (cd.cell_group_key= cgd.cell_group_key)
                JOIN p_campaign_dim campd
                ON (cgd.campaign_key= campd.campaign_key)
where c.ACTIVE_IND = 'Y' and ccx.POPULATION_PCT > 0
  and SELECTION_TBL <> 'v_outbound_universe'
order by CAMPAIGN_XID;

-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'A6','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'AI','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'AJ','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'CH','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'CR','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'CS','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'CU','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'HA','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'HB','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'HM','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'HN','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'M6','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'MC','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'MD','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'ME','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'MP','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'MQ','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'RE','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'RF','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'RW','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'RX','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'UE','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'UM','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'UP','Tuesday');"


begin
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'A6','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'AI','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'AJ','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'CH','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'CR','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'CS','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'CU','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'HA','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'HB','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'HM','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'HN','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'M6','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'MC','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'MD','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'ME','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'MP','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'MQ','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'RE','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'RF','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'RW','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'RX','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'UE','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'UM','Tuesday');
    pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'UP','Tuesday');

end;


select * from COHORT_DIM ;

select CAMPAIGN_KEY, count(*), min(COHORT_DT), max(COHORT_DT) from COHORT_DIM group by CAMPAIGN_KEY;
--not every campaign had/required cohorts for 2013, 2014 and 2015 but since I used 2013 as the start year for bulk insert here so those old cohorts got created as well
--this won't cause any issues -- just ignore those
+------------+--------+--------------+--------------+
|CAMPAIGN_KEY|COUNT(*)|MIN(COHORT_DT)|MAX(COHORT_DT)|
+------------+--------+--------------+--------------+
|1061        |782     |2031-01-07    |2045-12-26    |
|96385       |782     |2031-01-07    |2045-12-26    |
|108845      |782     |2031-01-07    |2045-12-26    |
|18081       |782     |2031-01-07    |2045-12-26    |
|96384       |782     |2031-01-07    |2045-12-26    |
|96383       |782     |2031-01-07    |2045-12-26    |
|80385       |782     |2031-01-07    |2045-12-26    |
|60961       |782     |2031-01-07    |2045-12-26    |
|67605       |782     |2031-01-07    |2045-12-26    |
|103945      |782     |2031-01-07    |2045-12-26    |
|76785       |782     |2031-01-07    |2045-12-26    |
|46149       |782     |2031-01-07    |2045-12-26    |
|102325      |782     |2031-01-07    |2045-12-26    |
|107181      |782     |2031-01-07    |2045-12-26    |
|1063        |782     |2031-01-07    |2045-12-26    |
|60960       |782     |2031-01-07    |2045-12-26    |
|64327       |782     |2031-01-07    |2045-12-26    |
|96386       |782     |2031-01-07    |2045-12-26    |
|14540       |782     |2031-01-07    |2045-12-26    |
|25801       |782     |2031-01-07    |2045-12-26    |
|18060       |782     |2031-01-07    |2045-12-26    |
|75182       |782     |2031-01-07    |2045-12-26    |
|18082       |782     |2031-01-07    |2045-12-26    |
+------------+--------+--------------+--------------+



select * from COHORT_DIM where CAMPAIGN_KEY = 1061;

begin
    P_PK_CORE_UPDATE.INSERT_TBL('COHORT_DIM');
end;


select CAMPAIGN_XID, max(COHORT_DT) from gnrc.COHORT_DIM join gnrc.CAMPAIGN_DIM using (campaign_key)
                                    where CAMPAIGN_XID in (select t1.CAMPAIGN_XID from CAMPAIGN_DIM t1)
                                    group by CAMPAIGN_XID order by CAMPAIGN_XID;
+------------+--------------+
|CAMPAIGN_XID|MAX(COHORT_DT)|
+------------+--------------+
|A6          |2045-12-26    |
|AI          |2045-12-26    |
|AJ          |2045-12-26    |
|CH          |2045-12-26    |
|CR          |2045-12-26    |
|CS          |2045-12-26    |
|CU          |2045-12-26    |
|HA          |2045-12-26    |
|HB          |2045-12-26    |
|HM          |2045-12-26    |
|HN          |2045-12-26    |
|M6          |2045-12-26    |
|MC          |2045-12-26    |
|MD          |2045-12-26    |
|ME          |2045-12-26    |
|MP          |2045-12-26    |
|MQ          |2045-12-26    |
|RE          |2045-12-26    |
|RF          |2045-12-26    |
|RW          |2045-12-26    |
|RX          |2045-12-26    |
|UE          |2045-12-26    |
|UM          |2045-12-26    |
|UP          |2045-12-26    |
+------------+--------------+


select distinct campd.CAMPAIGN_XID
  from p_criteria_dim c
                JOIN p_criteria_cell_xref ccx
                ON (c.criteria_key = ccx.criteria_key)
                JOIN p_cell_dim cd
                ON ccx.cell_key = cd.cell_key
                JOIN p_cell_group_dim cgd
                ON (cd.cell_group_key= cgd.cell_group_key)
                JOIN p_campaign_dim campd
                ON (cgd.campaign_key= campd.campaign_key)
where c.ACTIVE_IND = 'Y' and ccx.POPULATION_PCT > 0
  and SELECTION_TBL = 'v_outbound_universe' ;
+------------+
|CAMPAIGN_XID|
+------------+
|OAI         |
|ORE         |
|OA6         |
|OMP         |
|OUP         |
|OUS         |
+------------+



select CAMPAIGN_XID, max(COHORT_DT) from gnrc.COHORT_DIM join gnrc.CAMPAIGN_DIM  on  (gnrc.COHORT_DIM.campaign_key= gnrc.CAMPAIGN_DIM.campaign_key)
                                    where CAMPAIGN_XID in (
                                                            'OAI',
                                                            'ORE',
                                                            'OA6',
                                                            'OMP',
                                                            'OUP',
                                                            'OUS'
                                                            )
                                    group by CAMPAIGN_XID order by CAMPAIGN_XID;


;
---=========================================================================-----------------
------------------------v_outbound_universe-----------------------------
---=========================================================================-----------------


select * from COHORT_DIM  ;

select * from CAMPAIGN_DIM  ;

--populate all active campaigns into staging to avoid FK violations
insert into CAMPAIGN_DIM (CAMPAIGN_KEY, CAMPAIGN_XID, CAMPAIGN_NM, CAMPAIGN_DSC, START_DT, END_DT, PROGRAM_KEY, CAMPAIGN_STATUS_CD, DIM_STATUS_CD, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY)
select CAMPAIGN_KEY, CAMPAIGN_XID, CAMPAIGN_NM, CAMPAIGN_DSC, START_DT, END_DT, PROGRAM_KEY, CAMPAIGN_STATUS_CD, DIM_STATUS_CD, INSERT_AUDIT_KEY, UPDATE_AUDIT_KEY
  from gnrc.CAMPAIGN_DIM
 where CAMPAIGN_KEY in (
select campd.campaign_key
  from p_criteria_dim c
                JOIN p_criteria_cell_xref ccx
                ON (c.criteria_key = ccx.criteria_key)
                JOIN p_cell_dim cd
                ON ccx.cell_key = cd.cell_key
                JOIN p_cell_group_dim cgd
                ON (cd.cell_group_key= cgd.cell_group_key)
                JOIN p_campaign_dim campd
                ON (cgd.campaign_key= campd.campaign_key)
where c.ACTIVE_IND = 'Y' and ccx.POPULATION_PCT > 0
  and SELECTION_TBL = 'v_outbound_universe'
minus
select campaign_key from CAMPAIGN_DIM)
order by 2, 1;
commit;
-- [2026-05-06 13:20:29] 23 rows affected in 340 ms

select distinct CAMPAIGN_XID,
    'pk_campaign_utilities.prc_populate_cohort_dim(''01-JAN-2013''' || ',' || '''31-DEC-2045''' || ', ''' || CAMPAIGN_XID || ''',' || '''Tuesday''' || ');'
  from p_criteria_dim c
                JOIN p_criteria_cell_xref ccx
                ON (c.criteria_key = ccx.criteria_key)
                JOIN p_cell_dim cd
                ON ccx.cell_key = cd.cell_key
                JOIN p_cell_group_dim cgd
                ON (cd.cell_group_key= cgd.cell_group_key)
                JOIN p_campaign_dim campd
                ON (cgd.campaign_key= campd.campaign_key)
where c.ACTIVE_IND = 'Y' and ccx.POPULATION_PCT > 0
  and SELECTION_TBL = 'v_outbound_universe'
order by CAMPAIGN_XID;
--
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OA6','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OAI','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OMP','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'ORE','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OUP','Tuesday');"
-- "pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OUS','Tuesday');"
--

begin
        pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OA6','Tuesday');
        pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OAI','Tuesday');
        pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OMP','Tuesday');
        pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'ORE','Tuesday');
        pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OUP','Tuesday');
        pk_campaign_utilities.prc_populate_cohort_dim('01-JAN-2013','31-DEC-2045', 'OUS','Tuesday');

end;


select * from COHORT_DIM ;

select CAMPAIGN_KEY, count(*), min(COHORT_DT), max(COHORT_DT) from COHORT_DIM group by CAMPAIGN_KEY;
--not every campaign had/required cohorts for 2013, 2014 and 2015 but since I used 2013 as the start year for bulk insert here so those old cohorts got created as well
--this won't cause any issues -- just ignore those
-- +------------+--------+--------------+--------------+
-- |CAMPAIGN_KEY|COUNT(*)|MIN(COHORT_DT)|MAX(COHORT_DT)|
-- +------------+--------+--------------+--------------+
-- |24001       |992     |2013-01-01    |2045-12-26    |
-- |71846       |835     |2030-01-01    |2045-12-26    |
-- |13001       |992     |2013-01-01    |2045-12-26    |
-- |9802        |992     |2013-01-01    |2045-12-26    |
-- |47960       |835     |2030-01-01    |2045-12-26    |
-- |71845       |835     |2030-01-01    |2045-12-26    |
-- +------------+--------+--------------+--------------+

begin
    P_PK_CORE_UPDATE.INSERT_TBL('COHORT_DIM');
end;


select CAMPAIGN_XID, max(COHORT_DT) from gnrc.COHORT_DIM join gnrc.CAMPAIGN_DIM using (campaign_key)
                                    where CAMPAIGN_XID in (select t1.CAMPAIGN_XID from CAMPAIGN_DIM t1)
                                    group by CAMPAIGN_XID order by CAMPAIGN_XID;
-- +------------+--------------+
-- |CAMPAIGN_XID|MAX(COHORT_DT)|
-- +------------+--------------+
-- |OA6         |2045-12-26    |
-- |OAI         |2045-12-26    |
-- |OMP         |2045-12-26    |
-- |ORE         |2045-12-26    |
-- |OUP         |2045-12-26    |
-- |OUS         |2045-12-26    |
-- +------------+--------------+





select max(DROP_DT) from gnrc.TIMING_DIM;

select * from TIMING_DIM;

-- pk_campaign_utilities.prc_populate_timing_dim('01-JUN-2016','31-DEC-2099','RW','Tuesday');

select CAMPAIGN_XID, max(DROP_DT) from gnrc.TIMING_DIM join gnrc.CAMPAIGN_DIM  on  (gnrc.TIMING_DIM.campaign_key= gnrc.CAMPAIGN_DIM.campaign_key)
                                    where CAMPAIGN_XID in (
                                                            'OAI',
                                                            'ORE',
                                                            'OA6',
                                                            'OMP',
                                                            'OUP',
                                                            'OUS'
                                                            )
                                    group by CAMPAIGN_XID order by CAMPAIGN_XID;

-- OA6,2029-12-25
-- OAI,2029-12-25
-- OMP,2029-12-25
-- ORE,2029-12-25
-- OUP,2029-12-25
-- OUS,2029-12-25

select distinct CAMPAIGN_XID,
    'pk_campaign_utilities.prc_populate_timing_dim(''01-JAN-2013''' || ',' || '''31-DEC-2045''' || ', ''' || CAMPAIGN_XID || ''',' || '''Tuesday''' || ');'
  from p_criteria_dim c
                JOIN p_criteria_cell_xref ccx
                ON (c.criteria_key = ccx.criteria_key)
                JOIN p_cell_dim cd
                ON ccx.cell_key = cd.cell_key
                JOIN p_cell_group_dim cgd
                ON (cd.cell_group_key= cgd.cell_group_key)
                JOIN p_campaign_dim campd
                ON (cgd.campaign_key= campd.campaign_key)
where c.ACTIVE_IND = 'Y' and ccx.POPULATION_PCT > 0
  and SELECTION_TBL = 'v_outbound_universe'
order by CAMPAIGN_XID;
-- +----------------------------------------------------------------------------------------------------------------------------------------+
-- |'PK_CAMPAIGN_UTILITIES.PRC_POPULATE_TIMING_DIM(''01-JAN-2013'''||','||'''31-DEC-2045'''||','''||CAMPAIGN_XID||''','||'''TUESDAY'''||');'|
-- +----------------------------------------------------------------------------------------------------------------------------------------+
-- |pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OA6','Tuesday');                                            |
-- |pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OAI','Tuesday');                                            |
-- |pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OMP','Tuesday');                                            |
-- |pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'ORE','Tuesday');                                            |
-- |pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OUP','Tuesday');                                            |
-- |pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OUS','Tuesday');                                            |
-- +----------------------------------------------------------------------------------------------------------------------------------------+

begin
            pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OA6','Tuesday');
            pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OAI','Tuesday');
            pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OMP','Tuesday');
            pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'ORE','Tuesday');
            pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OUP','Tuesday');
            pk_campaign_utilities.prc_populate_timing_dim('01-JAN-2013','31-DEC-2045', 'OUS','Tuesday');
end;


select CAMPAIGN_XID, max(DROP_DT) from TIMING_DIM join gnrc.CAMPAIGN_DIM  on  (TIMING_DIM.campaign_key= gnrc.CAMPAIGN_DIM.campaign_key)
                                    where CAMPAIGN_XID in (
                                                            'OAI',
                                                            'ORE',
                                                            'OA6',
                                                            'OMP',
                                                            'OUP',
                                                            'OUS'
                                                            )
                                    group by CAMPAIGN_XID order by CAMPAIGN_XID;
-- OA6,2045-12-26
-- OAI,2045-12-26
-- OMP,2045-12-26
-- ORE,2045-12-26
-- OUP,2045-12-26
-- OUS,2045-12-26



begin
    P_PK_CORE_UPDATE.INSERT_TBL('TIMING_DIM');
end;


select CAMPAIGN_XID, max(DROP_DT) from gnrc.TIMING_DIM join gnrc.CAMPAIGN_DIM using (campaign_key)
                                    where CAMPAIGN_XID in (select t1.CAMPAIGN_XID from CAMPAIGN_DIM t1)
                                    group by CAMPAIGN_XID order by CAMPAIGN_XID;

-- +------------+------------+
-- |CAMPAIGN_XID|MAX(DROP_DT)|
-- +------------+------------+
-- |OA6         |2045-12-26  |
-- |OAI         |2045-12-26  |
-- |OMP         |2045-12-26  |
-- |ORE         |2045-12-26  |
-- |OUP         |2045-12-26  |
-- |OUS         |2045-12-26  |
-- +------------+------------+

select LEAD_SOURCE, sid.LATEST_LEAD_SOURCE, count(si.SERIAL_NO), count(sid.EXTENDED_WARRANTY_END_DT)
  from gnrc.SERIALIZED_ITEM_DIM si join gnrc.SERIALIZED_ITEM_EXT_DIM sid using (si_key)
 group by LEAD_SOURCE, sid.LATEST_LEAD_SOURCE
 order by LEAD_SOURCE, sid.LATEST_LEAD_SOURCE;