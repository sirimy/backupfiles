
select * from tmp_sql where INSERTED_DT > date'2024-01-01';

select count(*), min(uni.REGISTRATION_DT)
  from camp_available_universe_tbl uni join p_criteria_dim cri using (criteria_key)
 where 1=1
--   and wf_suppression_cd is null
  and uni.REGISTRATION_DT < date '2017-01-01';


select brand_nm, count(*) from camp_available_universe_tbl join gnrc.brand_dim using (brand_key)
where WF_SUPPRESSION_CD is null
group by brand_nm;
+---------+--------+
|BRAND_NM |COUNT(*)|
+---------+--------+
|HONEYWELL|3874    |
|GENERAC  |146539  |
+---------+--------+
