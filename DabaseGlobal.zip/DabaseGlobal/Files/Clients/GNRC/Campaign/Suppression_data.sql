select suppression_reason, to_char(CREATION_DT, 'YYYY-MM'),       count(distinct BUNDLE_KEY)
from suppression_tbl sup
    join gnrc.audit_tbl a on (audit_key = insert_audit_key)
    --join gnrc.bundle_dim bd using (bundle_key)
    --join gnrc.CRITERIA_DIM cri using (criteria_key)
    --join gnrc.bundle_item_xref bix using (bundle_key)
where 1=1   and creation_dt >= date '2024-12-17'
group by suppression_reason, to_char(CREATION_DT, 'YYYY-MM')
order by suppression_reason;

select  * --suppression_reason, to_char(CREATION_DT, 'YYYY-MM'),       count(distinct BUNDLE_KEY)
from suppression_tbl sup
    join gnrc.audit_tbl a on (audit_key = insert_audit_key)
    --join gnrc.bundle_dim bd using (bundle_key)
    --join gnrc.CRITERIA_DIM cri using (criteria_key)
    --join gnrc.bundle_item_xref bix using (bundle_key)
where 1=1   and creation_dt >= date '2024-12-17'
--group by suppression_reason, to_char(CREATION_DT, 'YYYY-MM')
order by suppression_reason;