select 'Input', count(*), count(distinct UNIQUE_ROW_IDENTIFIER), max(TAX_DT) from TAX_INPUT_TBL_VERTAX
union all
select 'Input', count(*), count(distinct UNIQUE_ROW_IDENTIFIER), max(to_date(TAX_DT, 'MM/DD/YYYY')) from v_vertex_input
union all
select 'Output', count(*), count(distinct "Document Number"), max(to_date("Document Date", 'MM/DD/YYYY')) from VERTEX_OUTPUT_TBL
union all
select 'Output', count(*), count(distinct DOCUMENT_NUMBER), max(DOCUMENT_DATE) from TAX_OUTPUT_TBL_VERTAX ;