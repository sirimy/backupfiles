
Select AT2.CREATION_DT,PD.* from PROGRAM_DIM PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY;

Select AT2.CREATION_DT,PD.* from CAMPAIGN_DIM PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY;
+--------------------------+------------+------------+--------------------------------+--------------------------------+-------------------+----------+-----------+------------------+-------------+----------------+----------------+
|CREATION_DT               |CAMPAIGN_KEY|CAMPAIGN_XID|CAMPAIGN_NM                     |CAMPAIGN_DSC                    |START_DT           |END_DT    |PROGRAM_KEY|CAMPAIGN_STATUS_CD|DIM_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
+--------------------------+------------+------------+--------------------------------+--------------------------------+-------------------+----------+-----------+------------------+-------------+----------------+----------------+
|2024-03-29 16:42:28.000000|100865      |CU          |Canada Semi-Annual Sweep Upgrade|Canada Semi-Annual Sweep Upgrade|2024-03-29 20:42:28|2999-12-31|40141      |A                 |A            |911537          |NULL            |
+--------------------------+------------+------------+--------------------------------+--------------------------------+-------------------+----------+-----------+------------------+-------------+----------------+----------------+

Select AT2.CREATION_DT,PD.* from CELL_GROUP_DIM PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY;
+--------------------------+--------------+--------------+-----------------------------------------+-----------------------------------------+------------+-------------+----------------+----------------+
|CREATION_DT               |CELL_GROUP_KEY|CELL_GROUP_XID|CELL_GROUP_NM                            |CELL_GROUP_DSC                           |CAMPAIGN_KEY|DIM_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
+--------------------------+--------------+--------------+-----------------------------------------+-----------------------------------------+------------+-------------+----------------+----------------+
|2024-03-29 17:09:39.000000|100866        |CU-01         |Semi-Annual Sweep Upgrade 1 Effort CANADA|Semi-Annual Sweep Upgrade 1 Effort CANADA|100865      |Y            |911538          |NULL            |
+--------------------------+--------------+--------------+-----------------------------------------+-----------------------------------------+------------+-------------+----------------+----------------+

Select AT2.CREATION_DT,PD.* from CELL_DIM PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY;
+--------+------------+-----------------------------------------------------------------+-------+
|CELL_KEY|CELL_XID    |CELL_NM                                                          |CELL_CD|
+--------+------------+-----------------------------------------------------------------+-------+
|100867  |CU01HSBGEN60|Semi-Annual Sweep Upgrade 1 Effort - =60 Month HSB Generac Canada|01     |
|100868  |CU01HSBGEN84|Semi-Annual Sweep Upgrade 1 Effort - =84 Month HSB Generac Canada|01     |
+--------+------------+-----------------------------------------------------------------+-------+
--100866
Select AT2.CREATION_DT,PD.* from state_machine_cell_group_xref PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY;
--select * from state_machine_cell_group_xref;
+-----------------+--------------+----------------+----------------+
|STATE_MACHINE_KEY|CELL_GROUP_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
+-----------------+--------------+----------------+----------------+
|64305            |100866        |911562          |NULL            |
+-----------------+--------------+----------------+----------------+

+--------------------------+--------+------------+-----------------------------------------------------------------+-------+-----------------------------------------------------------------+-----------+--------------+-------------+----------------+----------------+
|CREATION_DT               |CELL_KEY|CELL_XID    |CELL_NM                                                          |CELL_CD|CELL_DSC                                                         |CONTROL_IND|CELL_GROUP_KEY|DIM_STATUS_CD|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
+--------------------------+--------+------------+-----------------------------------------------------------------+-------+-----------------------------------------------------------------+-----------+--------------+-------------+----------------+----------------+
|2024-03-29 17:10:56.000000|100867  |CU01HSBGEN60|Semi-Annual Sweep Upgrade 1 Effort - =60 Month HSB Generac Canada|01     |Semi-Annual Sweep Upgrade 1 Effort - =60 Month HSB Generac Canada|N          |100866        |Y            |911539          |NULL            |
|2024-03-29 17:10:56.000000|100868  |CU01HSBGEN84|Semi-Annual Sweep Upgrade 1 Effort - =84 Month HSB Generac Canada|01     |Semi-Annual Sweep Upgrade 1 Effort - =84 Month HSB Generac Canada|N          |100866        |Y            |911540          |NULL            |
+--------------------------+--------+------------+-----------------------------------------------------------------+-------+-----------------------------------------------------------------+-----------+--------------+-------------+----------------+----------------+

Select AT2.CREATION_DT,PD.* from COHORT_DIM PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY order by at2.CREATION_DT desc;

Select AT2.CREATION_DT, COUNT(PD.COHORT_CD) from COHORT_DIM PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY
                                            Group by AT2.CREATION_DT
                                            order by at2.CREATION_DT desc;
+--------------------------+-------------------+
|CREATION_DT               |COUNT(PD.COHORT_CD)|
+--------------------------+-------------------+
|2024-03-29 17:12:56.000000|887                |
+--------------------------+-------------------+

Select COUNT(*) from GNRC.TIMING_DIM where TIMING_NM like '%Canada Semi-Annual Sweep Upgrade%';--708


Select AT2.CREATION_DT,PD.* from criteria_dim PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY order by at2.CREATION_DT desc;
+--------------------------+------------+-------------+-----------+----------+-----------+---------------+-------------------------------------+--------------------+---------------+--------------+--------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------+----------------+----------------+-----------+------------------+--------+
|CREATION_DT               |CRITERIA_KEY|CRITERIA_XID |CRITERIA_CD|ACTIVE_IND|PURCHASE_DT|REGISTRATION_DT|LATEST_COVERAGE_EXP_DT               |LATEST_COVERAGE_TYPE|WARRANTY_MONTHS|COMMERCIAL_IND|SELECTION_TBL       |ADDITIONAL_SQL_TXT                                                                                                                                                   |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|DESCRIPTION|STREAM_LENGTH_DAYS|BRAND_NM|
+--------------------------+------------+-------------+-----------+----------+-----------+---------------+-------------------------------------+--------------------+---------------+--------------+--------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------+----------------+----------------+-----------+------------------+--------+
|2024-03-29 18:05:02.000000|102464      |CU00-HSBGEN60|CU000      |Y         |NULL       |NULL           |between drop_dt +35 and drop_dt +727 |2                   |>= 60          |NULL          |v_available_universe|brand_family_cd= 'GNH' and Registration_Dt>= DATE '2017-01-01' and Residential_Dealer_Ind= 'N' and NCOA_Ind= 'N' and Country_Cd= 'CAN' and Enhanced_Warranty_Ind= 'N'|911543          |NULL            |NULL       |NULL              |NULL    |
|2024-03-29 18:05:02.000000|102467      |CU00-HSBGEN84|CU000      |Y         |NULL       |NULL           |between drop_dt +35 and drop_dt +1455|5                   |>= 84          |NULL          |v_available_universe|brand_family_cd= 'GNH' and Registration_Dt>= DATE '2017-01-01' and Residential_Dealer_Ind= 'N' and NCOA_Ind= 'N' and Country_Cd= 'CAN' and Enhanced_Warranty_Ind= 'N'|911546          |NULL            |NULL       |NULL              |NULL    |
|2024-03-29 18:05:02.000000|102466      |CU00-HSBGEN60|CU000      |Y         |NULL       |NULL           |between drop_dt +35 and drop_dt +727 |5                   |>= 60          |NULL          |v_available_universe|brand_family_cd= 'GNH' and Registration_Dt>= DATE '2017-01-01' and Residential_Dealer_Ind= 'N' and NCOA_Ind= 'N' and Country_Cd= 'CAN' and Enhanced_Warranty_Ind= 'N'|911545          |NULL            |NULL       |NULL              |NULL    |
|2024-03-29 18:05:02.000000|102465      |CU00-HSBGEN84|CU000      |Y         |NULL       |NULL           |between drop_dt +35 and drop_dt +1455|2                   |>= 84          |NULL          |v_available_universe|brand_family_cd= 'GNH' and Registration_Dt>= DATE '2017-01-01' and Residential_Dealer_Ind= 'N' and NCOA_Ind= 'N' and Country_Cd= 'CAN' and Enhanced_Warranty_Ind= 'N'|911544          |NULL            |NULL       |NULL              |NULL    |
+--------------------------+------------+-------------+-----------+----------+-----------+---------------+-------------------------------------+--------------------+---------------+--------------+--------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------+----------------+----------------+-----------+------------------+--------+


select substr(CRITERIA_XID, 3, 2), cri.* from CRITERIA_DIM cri where STREAM_LENGTH_DAYS is null order by CRITERIA_XID;
--update CRITERIA_DIM set STREAM_LENGTH_DAYS = 42 * substr(CRITERIA_XID, 3, 2)  where STREAM_LENGTH_DAYS is null;
 update CRITERIA_DIM set STREAM_LENGTH_DAYS = 42 * 1  where STREAM_LENGTH_DAYS is null;
--4 rows
commit;


Select AT2.CREATION_DT,PD.* from CRITERIA_CELL_XREF PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY order by at2.CREATION_DT desc;
+--------------------------+------------+--------+------------------+--------------+----------------+----------------+
|CREATION_DT               |CRITERIA_KEY|CELL_KEY|PRICING_SCHEME_KEY|POPULATION_PCT|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|
+--------------------------+------------+--------+------------------+--------------+----------------+----------------+
|2024-04-03 07:52:12.000000|102464      |100867  |44                |1.00          |911560          |NULL            |
|2024-04-03 07:52:12.000000|102467      |100868  |43                |1.00          |911561          |NULL            |
|2024-04-03 07:52:12.000000|102466      |100867  |44                |1.00          |911560          |NULL            |
|2024-04-03 07:52:12.000000|102465      |100868  |43                |1.00          |911561          |NULL            |
+--------------------------+------------+--------+------------------+--------------+----------------+----------------+



Update CRITERIA_CELL_XREF
SET PRICING_SCHEME_KEY = 44
where CRITERIA_KEY in (102464,102466);--CU00-HSBGEN60

Update CRITERIA_CELL_XREF
SET PRICING_SCHEME_KEY = 43
where CRITERIA_KEY in (102467,102465);--CU00-HSBGEN60

Select * from CRITERIA_CELL_XREF where CRITERIA_KEY in (102464,102466);--CU00-HSBGEN60
Select * from CRITERIA_CELL_XREF where CRITERIA_KEY in (102467,102465);--CU00-HSBGEN84

Select * from GNRC.PRICING_SCHEME_DIM order by PRICING_SCHEME_KEY;
+------------------+--------------------------------+------------+----------+----------------+----------------+--------------+
|PRICING_SCHEME_KEY|PRICING_SCHEME_NM               |EFFECTIVE_DT|END_DT    |INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
+------------------+--------------------------------+------------+----------+----------------+----------------+--------------+
|43                |UP HSB - 3 Year Upgrade - CANADA|2024-03-18  |2099-12-31|911557          |NULL            |NULL          |
|44                |UP HSB - 5 Year Upgrade - CANADA|2024-03-18  |2099-12-31|911557          |NULL            |NULL          |
+------------------+--------------------------------+------------+----------+----------------+----------------+--------------+

select * from MESSAGE_DIM;

select * from state_message_xref;

+---------+--------+-----------+----------------+----------------+---------------+
|STATE_KEY|CELL_KEY|MESSAGE_KEY|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|EXPIRATION_DAYS|
+---------+--------+-----------+----------------+----------------+---------------+
|64312    |100867  |102485     |NULL            |NULL            |NULL           |
|64311    |100867  |102485     |NULL            |NULL            |NULL           |
|64311    |100868  |102485     |NULL            |NULL            |NULL           |
|64312    |100868  |102485     |NULL            |NULL            |NULL           |
+---------+--------+-----------+----------------+----------------+---------------+

Select AT2.CREATION_DT,PD.* from GID_METADATA_TBL PD join AUDIT_TBL AT2 ON PD.INSERT_AUDIT_KEY = AT2.AUDIT_KEY order by at2.CREATION_DT desc;


