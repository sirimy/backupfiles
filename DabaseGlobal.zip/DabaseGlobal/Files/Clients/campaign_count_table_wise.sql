SELECT 'bundle_dim' AS table_name, COUNT(*) AS ct FROM bundle_dim
UNION ALL
SELECT 'bundle_item_xref' AS table_name, COUNT(*) AS ct FROM bundle_item_xref
UNION ALL
SELECT 'cell_selection_fct' AS table_name, COUNT(*) AS ct FROM cell_selection_fct
UNION ALL
SELECT 'base_offer_xref' AS table_name, COUNT(*) AS ct FROM base_offer_xref
UNION ALL
SELECT 'base_offer_item_xref' AS table_name, COUNT(*) AS ct FROM base_offer_item_xref
UNION ALL
SELECT 'base_offer_item_discount_xref' AS table_name, COUNT(*) AS ct FROM base_offer_item_discount_xref
UNION ALL
SELECT 'base_offer_discount_xref' AS table_name, COUNT(*) AS ct FROM base_offer_discount_xref
UNION ALL
SELECT 'bundle_state_tbl' AS table_name, COUNT(*) AS ct FROM bundle_state_tbl
UNION ALL
SELECT 'bundle_transition_hist' AS table_name, COUNT(*) AS ct FROM bundle_transition_hist
UNION ALL
SELECT 'campaign_participation_fct' AS table_name, COUNT(*) AS ct FROM campaign_participation_fct
UNION ALL
SELECT 'offer_xref' AS table_name, COUNT(*) AS ct FROM offer_xref
UNION ALL
SELECT 'offer_item_xref' AS table_name, COUNT(*) AS ct FROM offer_item_xref
UNION ALL
SELECT 'offer_discount_xref' AS table_name, COUNT(*) AS ct FROM offer_discount_xref
UNION ALL
SELECT 'offer_item_discount_xref' AS table_name, COUNT(*) AS ct FROM offer_item_discount_xref
UNION ALL
SELECT 'offer_quickreg_xref' AS table_name, COUNT(*) AS ct FROM offer_quickreg_xref
UNION ALL
SELECT 'campaign_spool_file_tbl' AS table_name, COUNT(*) AS ct FROM campaign_spool_file_tbl
UNION ALL
SELECT 'campaign_spool_seed_tbl' AS table_name, COUNT(*) AS ct FROM campaign_spool_seed_tbl
UNION ALL
SELECT 'tax_input_tbl_vertax' AS table_name, COUNT(*) AS ct FROM tax_input_tbl_vertax
UNION ALL
SELECT 'tax_output_tbl_vertax' AS table_name, COUNT(*) AS ct FROM tax_output_tbl_vertax
UNION ALL
SELECT 'ESP_AM_SCR_INPUT_TBL' AS table_name, COUNT(*) AS ct FROM ESP_AM_SCR_INPUT_TBL
UNION ALL
SELECT 'ESP_AM_SCR_OUTPUT_TBL' AS table_name, COUNT(*) AS ct FROM ESP_AM_SCR_OUTPUT_TBL
UNION ALL
SELECT 'ESP_AM_SCR_ERROR_TBL' AS table_name, COUNT(*) AS ct FROM ESP_AM_SCR_ERROR_TBL
UNION ALL
SELECT 'ESP_AM_SCR_VAR_TBL' AS table_name, COUNT(*) AS ct FROM ESP_AM_SCR_VAR_TBL
UNION ALL
SELECT 'BUNDLE_SUMMARY_TBL' AS table_name, COUNT(*) AS ct FROM BUNDLE_SUMMARY_TBL;