

 select * from raw_product_tbl;


select * from product;

select * from SRS_SYNC_REQ_ERR_LOG_TBL order by log_date  desc;

SELECT * FROM aotccaapweb.product_lkp WHERE trim(product_xid)=trim('LC0995');
+-----------+----------+-----------+---------------+--------------------------+
|product_xid|product_id|primary_ind|last_updated_by|last_updated_ts           |
+-----------+----------+-----------+---------------+--------------------------+
|LC0995     |29863391  |Y          |product_service|2025-11-21 03:50:54.365625|
+-----------+----------+-----------+---------------+--------------------------+

SELECT * FROM aotccaapweb.product_lkp WHERE product_id = 29863391;
-- +-----------+----------+-----------+---------------+--------------------------+
-- |product_xid|product_id|primary_ind|last_updated_by|last_updated_ts           |
-- +-----------+----------+-----------+---------------+--------------------------+
-- |LC0995     |29863391  |Y          |product_service|2025-11-21 03:50:54.365625|
-- +-----------+----------+-----------+---------------+--------------------------+

SELECT COUNT(*),COUNT(distinct product_id ),COUNT(distinct product_xid ) FROM aotccaapweb.product_lkp;
-- +-----+-----+-----+
-- |count|count|count|
-- +-----+-----+-----+
-- |4911 |4911 |4911 |
-- +-----+-----+-----+

create table test_product_data_sync_error_dec_12_2025 as
select
			distinct aotccaapweb.get_product_id(upper(trim( t.model_no))) as product_id,
			trim(t.name) as name,
			trim(t.description) as description,
			t.product_category_id,
			upper(trim(t.model_no)) as model_no,
			t.brand_id,
			trim(t.product_xid) as product_xid,
			trim(t.product_xid_nm) as product_xid_nm,
			t.manufacturer_id
		from (
			select
				rpt.product_name as name,
				rpt.product_name as description,
				pc.product_category_id,
				rpt.item_code as model_no,
				bd.brand_id,
				rpt.item_code as product_xid,
				rpt.item_code  as product_xid_nm ,
				--update_product(rpt.product_mdm_id) as attributes_json,
				mft.manufacturer_id
			from
			        aotccaapweb.raw_product_tbl rpt
				join v_product_category pc
				    ON ( upper(trim(pc.prod_cat_xid)) = upper(trim(rpt.product_category_name)))
				join aotccaapweb.brand bd
				    ON ( upper(trim(bd.brand_xid)) = upper(trim(rpt.original_brand)))
				LEFT JOIN aotccaapweb.manufacturer_tbl mft
				    ON case when length(trim(rpt.mdm_factory_code)) = 2 then '1' || upper(rpt.mdm_factory_code) else upper(rpt.mdm_factory_code) end = upper(mft.manufacturer_xid)
			where
			      trim(rpt.error_desc) is null and rpt.created_at  = '2025-12-10 03:50:19.104963'
			group by rpt.product_name ,
				rpt.product_name,
				pc.product_category_id,
				rpt.item_code,
				bd.brand_id,
				rpt.product_mdm_id,
				rpt.product_mdm_id,
				mft.manufacturer_id
			) t
		       ;
commit;

select * from aotccaapweb.manufacturer_tbl -- where manufacturer_xid like '%45%'
                                           order by   last_updated_ts desc;

select product_id,COUNT(*) from test_product_data_sync_error_dec_12_2025
group by product_id
having COUNT(*) > 1
;
-- +----------+-----+
-- |product_id|count|
-- +----------+-----+
-- |29863391  |2    |
-- +----------+-----+

select * from test_product_data_sync_error_dec_12_2025 where product_id = 29863391;
-- +----------+-----------------------------+-----------------------------+-------------------+--------+--------+-----------+--------------+---------------+
-- |product_id|name                         |description                  |product_category_id|model_no|brand_id|product_xid|product_xid_nm|manufacturer_id|
-- +----------+-----------------------------+-----------------------------+-------------------+--------+--------+-----------+--------------+---------------+
-- |29863391  |275/50R22 LS-07 H/T  115 H TL|275/50R22 LS-07 H/T  115 H TL|438465             |LC0995  |19274403|LC0995     |LC0995        |18967441       |
-- |29863391  |275/50R22 LS-07 H/T  115 H TL|275/50R22 LS-07 H/T  115 H TL|438465             |LC0995  |19274403|LC0995     |LC0995        |NULL           |
-- +----------+-----------------------------+-----------------------------+-------------------+--------+--------+-----------+--------------+---------------+



select substr(mdm_factory_code,1,1),length(mdm_factory_code),COUNT(distinct item_code ) from  aotccaapweb.raw_product_tbl rpt
where trim(rpt.error_desc) is null and rpt.created_at  = '2025-12-09 03:50:18.931277'
group by substr(mdm_factory_code,1,1),length(mdm_factory_code)
;
-- +------+------+-----+
-- |substr|length|count|
-- +------+------+-----+
-- |0     |3     |640  |
-- |1     |3     |2738 |
-- +------+------+-----+

select substr(mdm_factory_code,1,1),length(mdm_factory_code),COUNT(distinct item_code) from  aotccaapweb.raw_product_tbl rpt
where trim(rpt.error_desc) is null and rpt.created_at  = '2025-12-10 03:50:19.104963'
group by substr(mdm_factory_code,1,1),length(mdm_factory_code)
;
-- +------+------+-----+
-- |substr|length|count|
-- +------+------+-----+
-- |0     |3     |626  |
-- |1     |3     |2736 |
-- |4     |2     |15   |
-- +------+------+-----+



select mdm_factory_code,COUNT(distinct item_code) from  aotccaapweb.raw_product_tbl rpt
where trim(rpt.error_desc) is null and rpt.created_at  = '2025-12-10 03:50:19.104963'
group by mdm_factory_code
;
-- +----------------+-----+
-- |mdm_factory_code|count|
-- +----------------+-----+
-- |008             |119  |
-- |00K             |211  |
-- |045             |252  |
-- |055             |4    |
-- |07B             |40   |
-- |126             |95   |
-- |12B             |342  |
-- |14F             |47   |
-- |16K             |206  |
-- |16M             |46   |
-- |180             |55   |
-- |18H             |27   |
-- |18M             |456  |
-- |1KA             |784  |
-- |1PT             |11   |
-- |1TB             |413  |
-- |1WU             |110  |
-- |1Y3             |11   |
-- |1YC             |133  |
-- |45              |15   |
-- +----------------+-----+


select * from  aotccaapweb.raw_product_tbl rpt
where rpt.product_name = '275/50R22 LS-07 H/T  115 H TL' and  rpt.product_name = '275/50R22 LS-07 H/T  115 H TL'
and trim(rpt.error_desc) is null and rpt.created_at  = '2025-12-10 03:50:19.104963' and item_code = 'LC0995';
-- +-------------------+-----------------+----------+---------------------+--------------+-----------------------------+---------+----------------------+-----------+---------+-----+------------------+----------------+------------+------+--------------------+--------------+---------------+--------------------------+----------+-----------------+-------------------+
-- |product_type_mdm_id|product_type_name|brand_name|product_category_name|product_mdm_id|product_name                 |item_code|marketing_product_name|tread_depth|item_size|cost |source_system_code|mdm_factory_code|price_level |price |product_price_mdm_id|original_brand|warranty_length|created_at                |error_desc|price_book_mdm_id|product_cost_mdm_id|
-- +-------------------+-----------------+----------+---------------------+--------------+-----------------------------+---------+----------------------+-----------+---------+-----+------------------+----------------+------------+------+--------------------+--------------+---------------+--------------------------+----------+-----------------+-------------------+
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |DunlapKyle  |96.46 |1561731             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |102              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |Fairmount   |92.48 |1562069             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |100019           |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |FOB         |64.48 |1591814             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |137              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |GllgherBlack|97.3  |1577721             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |138              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |Hawaii      |104.18|1563946             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |100031           |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |HRTRot      |97.23 |1565063             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |100027           |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |ITDG        |101.44|1566172             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |100026           |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |KMZurcher   |97.32 |1567333             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |119              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |MidState    |101.78|1568700             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |100015           |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |MidWest     |99.21 |1570263             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |146              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |MidWstHybrid|103.14|1569070             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |100025           |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |PR-DDP      |96.23 |1571519             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |186              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |045             |SEC         |97.3  |1572734             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |151              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |45              |Snider      |97.3  |1582367             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |267              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |45              |TDGeorgia   |97.3  |1582620             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |173              |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |45              |TireDiscount|97.3  |1582873             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |85               |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |45              |TireHub     |97.3  |1583126             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |100011           |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |45              |TreadKing   |93.28 |1592799             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |100029           |71674              |
-- |2                  |Tire             |Lancaster |Light Truck Radial   |97826         |275/50R22 LS-07 H/T  115 H TL|LC0995   |LC0995 - 275/50R22    |10.0       |275/50R22|57.73|2                 |45              |WestCoast   |93.17 |1576195             |Lancaster     |60             |2025-12-10 03:50:19.104963|NULL      |153              |71674              |
-- +-------------------+-----------------+----------+---------------------+--------------+-----------------------------+---------+----------------------+-----------+---------+-----+------------------+----------------+------------+------+--------------------+--------------+---------------+--------------------------+----------+-----------------+-------------------+

select * from  aotccaapweb.raw_product_tbl rpt
    where rpt.product_name = '275/50R22 LS-07 H/T  115 H TL'
            and  rpt.product_name = '275/50R22 LS-07 H/T  115 H TL'
            and trim(rpt.error_desc) is null
            and rpt.created_at  = '2025-12-10 03:50:19.104963'
            and item_code = 'LC0995';

select rpt.created_at,COUNT(*)
    from  aotccaapweb.raw_product_tbl rpt
group by rpt.created_at
order by rpt.created_at desc
;

-- +--------------------------+------+
-- |created_at                |count |
-- +--------------------------+------+
-- |2026-01-07 03:50:21.500428|229527|
-- |2026-01-06 03:50:19.584286|229527|
-- |2026-01-03 03:50:19.294888|229527|
-- |2026-01-02 03:50:18.659683|227435|
-- |2026-01-01 03:50:19.080849|228249|
-- +--------------------------+------+

select * from  aotccaapweb.raw_product_tbl rpt
where rpt.product_name = '275/50R22 LS-07 H/T  115 H TL' and  rpt.product_name = '275/50R22 LS-07 H/T  115 H TL'
and trim(rpt.error_desc) is null and rpt.created_at  = '2026-01-07 03:50:21.500428' and item_code = 'LC0995';

select product_id,COUNT(*) from test_product_data_sync_error_jan_06_2026
group by product_id
having COUNT(*)> 1
;
-- +----------+-----+
-- |product_id|count|
-- +----------+-----+
-- |29863131  |2    |
-- +----------+-----+



select product_type_mdm_id, product_type_name, brand_name, product_category_name, product_mdm_id, product_name, item_code, marketing_product_name,
       tread_depth, item_size, cost, source_system_code, mdm_factory_code, price_level, price, product_price_mdm_id, original_brand,
       warranty_length, created_at, error_desc, price_book_mdm_id, product_cost_mdm_id from  aotccaapweb.raw_product_tbl rpt
where rpt.product_name = 'LT285/75R18 LS-37 A/T 10 129/126 S TL'
and trim(rpt.error_desc) is null and rpt.created_at  = '2026-01-07 03:50:21.500428'  and item_code = 'LC1141';


select * from test_product_data_sync_error_jan_06_2026 where product_id =29863131;
-- +----------+-------------------------------------+-------------------------------------+-------------------+--------+--------+-----------+--------------+---------------+
-- |product_id|name                                 |description                          |product_category_id|model_no|brand_id|product_xid|product_xid_nm|manufacturer_id|
-- +----------+-------------------------------------+-------------------------------------+-------------------+--------+--------+-----------+--------------+---------------+
-- |29863131  |LT285/75R18 LS-37 A/T 10 129/126 S TL|LT285/75R18 LS-37 A/T 10 129/126 S TL|438465             |LC1141  |19274403|LC1141     |LC1141        |18967441       |
-- |29863131  |LT285/75R18 LS-37 A/T 10 129/126 S TL|LT285/75R18 LS-37 A/T 10 129/126 S TL|438465             |LC1141  |19274403|LC1141     |LC1141        |NULL           |
-- +----------+-------------------------------------+-------------------------------------+-------------------+--------+--------+-----------+--------------+---------------+
select * from  aotccaapweb.raw_product_tbl rpt
where rpt.product_name = '275/50R22 LS-07 H/T  115 H TL' and  rpt.product_name = '275/50R22 LS-07 H/T  115 H TL'
and trim(rpt.error_desc) is null and rpt.created_at  = '2026-01-07 03:50:21.500428' and item_code = 'LC1141';


create table test_product_data_sync_error_jan_07_2026 as
select
			distinct aotccaapweb.get_product_id(upper(trim( t.model_no))) as product_id,
			trim(t.name) as name,
			trim(t.description) as description,
			t.product_category_id,
			upper(trim(t.model_no)) as model_no,
			t.brand_id,
			trim(t.product_xid) as product_xid,
			trim(t.product_xid_nm) as product_xid_nm,
			t.manufacturer_id
		from (
			select
				rpt.product_name as name,
				rpt.product_name as description,
				pc.product_category_id,
				rpt.item_code as model_no,
				bd.brand_id,
				rpt.item_code as product_xid,
				rpt.item_code  as product_xid_nm ,
				--update_product(rpt.product_mdm_id) as attributes_json,
				mft.manufacturer_id
			from
			        aotccaapweb.raw_product_tbl rpt
				join v_product_category pc
				    ON ( upper(trim(pc.prod_cat_xid)) = upper(trim(rpt.product_category_name)))
				join aotccaapweb.brand bd
				    ON ( upper(trim(bd.brand_xid)) = upper(trim(rpt.original_brand)))
				LEFT JOIN aotccaapweb.manufacturer_tbl mft
				    ON case when length(trim(rpt.mdm_factory_code)) = 2 then '1' || upper(rpt.mdm_factory_code) else upper(rpt.mdm_factory_code) end = upper(mft.manufacturer_xid)
			where
			      trim(rpt.error_desc) is null and rpt.created_at  = '2026-01-07 03:50:21.500428'
			group by rpt.product_name ,
				rpt.product_name,
				pc.product_category_id,
				rpt.item_code,
				bd.brand_id,
				rpt.product_mdm_id,
				rpt.product_mdm_id,
				mft.manufacturer_id
			) t
		       ;
commit;

select product_id,COUNT(*) from test_product_data_sync_error_jan_07_2026
group by product_id
having COUNT(*)> 1
;
-- +----------+-----+
-- |product_id|count|
-- +----------+-----+
-- |29863131  |2    |
-- +----------+-----+