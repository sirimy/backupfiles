
select created_at,COUNT(*) from raw_product_tbl
where  created_at > '2025-12-09 02:50:19.741650'
group by created_at
order by created_at desc
;
-- +--------------------------+------+
-- |created_at                |count |
-- +--------------------------+------+
-- |2025-12-11 03:50:18.808965|229637|
-- |2025-12-10 03:50:19.104963|229648|
-- |2025-12-09 03:50:18.931277|229946|
-- +--------------------------+------+

-- +--------------------------------------------------------------------------------------------+--------------------------+
-- |err_primary_msg                                                                             |log_date                  |
-- +--------------------------------------------------------------------------------------------+--------------------------+
-- |duplicate key value violates unique constraint "pk_product"::sync_product_raw::product table|2025-12-11 03:50:58.986281|
-- |duplicate key value violates unique constraint "pk_product"::sync_product_raw::product table|2025-12-10 03:50:53.380989|
-- +--------------------------------------------------------------------------------------------+--------------------------+


select distinct dml_flag,COUNT(*) from product_audit
group by dml_flag
;
-- +--------+-------+
-- |dml_flag|count  |
-- +--------+-------+
-- |INSERT  |4911   |
-- |UPDATE  |4931662|
-- +--------+-------+

select * from product_audit
where last_updated_ts = '2025-12-09 04:00:27.771797';
-- +----------+
-- |product_id|
-- +----------+
-- |372415    |
-- |372483    |
-- |372653    |
-- |372739    |
-- |372757    |
-- |372887    |
-- |373017    |
-- |373033    |
-- |373063    |
-- |373221    |
-- |373275    |
-- |373293    |
-- |373301    |
-- |373391    |
-- |373517    |
-- +----------+

select 'MAIN',product_id, name, description, product_category_id, model_no, do_not_solicit_ind, brand_id, image_link, thumbnail_image_link, current_policy_id, price_amt, unit_cnt, marketing_product_id,
       product_xid, product_xid_nm, upc_cd, subscribable_ind, last_updated_by, last_updated_ts, manufacturer_id, attributes_json from product where product_id = 372483
UNION ALL
select 'UPDATE',product_id, name, description, product_category_id, model_no, do_not_solicit_ind, brand_id, image_link, thumbnail_image_link, current_policy_id, price_amt, unit_cnt, marketing_product_id,
       product_xid, product_xid_nm, upc_cd, subscribable_ind, last_updated_by, last_updated_ts, manufacturer_id, attributes_json from product_audit where product_id = 372483
and last_updated_ts < '2025-12-09 04:00:27.771797'
order by last_updated_ts desc
;

select distinct dml_flag,COUNT(*) from product_audit
where last_updated_ts = '2025-12-09 04:00:27.771797'
group by dml_flag
;
-- +--------+-----+
-- |dml_flag|count|
-- +--------+-----+
-- |UPDATE  |3378 |
-- +--------+-----+


select product_id,COUNT(*) from product_audit
where last_updated_ts = '2025-12-09 04:00:27.771797'
group by product_id
Having COUNT(*) > 1
order by product_id;




select last_updated_ts,COUNT(*) from product
group by last_updated_ts
order by last_updated_ts desc
;
-- +--------------------------+-----+
-- |last_updated_ts           |count|
-- +--------------------------+-----+
-- |2025-12-11 03:59:43.403420|3    |
-- |2025-12-10 03:59:49.064645|2    |
-- |2025-12-09 04:00:27.771797|3373 |
-- |2025-12-02 03:59:58.305576|8    |
-- |2025-11-12 04:00:15.203390|3    |
-- |2025-11-11 03:59:24.130603|1    |
-- |2025-11-06 04:00:09.007821|1    |
-- |2025-11-04 04:00:57.802416|4    |
-- |2025-10-28 02:59:22.816246|2    |
-- |2025-10-09 02:59:38.303336|1    |
-- |2025-10-02 02:59:12.363273|1    |
-- |2025-10-01 03:01:05.085558|1    |
-- |2025-09-30 02:58:47.360036|1    |
-- |2025-09-11 02:58:58.179092|7    |
-- |2025-09-10 03:00:32.973880|1    |
-- |2025-09-09 02:59:08.146307|3    |
-- |2025-09-04 02:59:31.170642|4    |
-- |2025-09-02 02:58:56.044246|7    |
-- +--------------------------+-----+

-- duplicate key value violates unique constraint "pk_product"::sync_product_raw::product table