SELECT 'First Name'  || '|' || 'Middle Name'  || '|' || 'Last Name'  || '|' || 'Address'  || '|' || 'City'  || '|' || 'State_Cd'  || '|' || 'Zip5'  || '|' || 'Zip4'  || '|' || 'Unique_Identifier'
                         FROM DUAL
                         UNION ALL
                         SELECT '"' ||
                                replace(FIRST_NM, '|', ' ') || '"|"' ||
                                replace(MIDDLE_NM, '|', ' ') || '"|"' ||
                                replace(LAST_NM, '|', ' ') || '"|"' ||
                                replace(ADDRESS_LINE1_TX  || case when ADDRESS_LINE2_TX is not null then ' ' || ADDRESS_LINE2_TX end, '|', ' ') || '"|"' ||
                                replace(CITY_NM, '|', ' ') || '"|"' ||
                                replace(STATE_CD, '|') || '"|"' ||
                                replace(ZIP_CODE5_TX, '|') || '"|"' ||
                                replace(ZIP_CODE4_TX, '|')|| '"|"' ||
                                ADDRESS_KEY || '"'
                          FROM demo_driver_tbl
                               JOIN  p_address_dim a USING(address_key);

 SELECT  FIRST_NM AS "First Name" ,
    MIDDLE_NM AS "Middle Name",
    LAST_NM AS "Last Name" ,
     replace(ADDRESS_LINE1_TX  || case when ADDRESS_LINE2_TX is not null then ' ' || ADDRESS_LINE2_TX end, ',', ' ') AS "Address",
    CITY_NM AS "City" ,
    STATE_CD AS "State_Cd" ,
    ZIP_CODE5_TX AS "Zip5",
    ZIP_CODE4_TX AS  "Zip4",
    ADDRESS_KEY "Unique_Identifier"
FROM demo_driver_tbl
   JOIN  p_address_dim a USING(address_key);


  SELECT  substr(to_char(ADDRESS_KEY), 1, 30) AS Unique_Identifier ,
                                substr(replace(FIRST_NM, ',', ' '), 1, 40) AS "First Name" ,
                                substr(replace(LAST_NM, ',', ' '), 1, 40) AS "Last Name" ,
                                substr(replace(ADDRESS_LINE1_TX, ',', ' '), 1, 80)  AS Input_Address1,
                                substr(replace(ADDRESS_LINE2_TX, ',', ' '), 1, 110) AS Input_Address2,
                                substr(replace(CITY_NM, ',', ' '), 1, 40)  AS City,
                                substr(replace(STATE_CD, ','), 1, 30) AS State_Cd,
                                substr(replace(ZIP_CODE5_TX || ZIP_CODE4_TX, ','), 1, 10) AS Zip

                          FROM DEMO_DRIVER_TBL_esa_sample_20220323
                               JOIN  p_address_dim a USING(address_key);

SELECT 'Unique_Identifier' || ',' || 'First Name'  || ',' || 'Last Name'  || ',' || 'Input_Address1'  || ',' || 'Input_Address2'  || ',' ||'City'  || ',' || 'State_Cd'  || ',' || 'Zip'
                         FROM DUAL
                         UNION ALL
                         SELECT '"' ||
                                substr(to_char(ADDRESS_KEY), 1, 30) || '","' ||
                                substr(replace(FIRST_NM, ',', ' '), 1, 40) || '","' ||
                                substr(replace(LAST_NM, ',', ' '), 1, 40) || '","' ||
                                substr(replace(ADDRESS_LINE1_TX, ',', ' '), 1, 80) || '","' ||
                                substr(replace(ADDRESS_LINE2_TX, ',', ' '), 1, 110) || '","' ||
                                substr(replace(CITY_NM, ',', ' '), 1, 40) || '","' ||
                                substr(replace(STATE_CD, ','), 1, 30) || '","' ||
                                substr(replace(ZIP_CODE5_TX || ZIP_CODE4_TX, ','), 1, 10)  || '"'

                          FROM DEMO_DRIVER_TBL_esa_sample_20220323
                               JOIN  p_address_dim a USING(address_key);

