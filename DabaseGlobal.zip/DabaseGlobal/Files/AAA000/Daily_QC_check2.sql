
 select distinct si_key
     -- into l_count
        from (
              select si.si_key, count(distinct ccx.contract_key)
                from p_serialized_item_dim si
                     join (
                         select distinct CD.CONTRACT_KEY,OIT.ORDER_KEY,COTX.SI_KEY AS si_key ,2 coverage_type_key,SALES_SOURCE_CD  ,ot.PURCHASE_DT OT_Purchase_DT
                         from BOSH.CONTRACT_DIM  CD
                          JOIN BOSH.CONTRACT_COVERAGE_XREF  COTX on COTX.CONTRACT_KEY = CD.CONTRACT_KEY
                          JOIN BOSH.CONTRACT_ORDER_TBL  COT on COT.CONTRACT_KEY = CD.CONTRACT_KEY
                         JOIN BOSH.ORDER_ITEM_TBL OIT on OIT.ORDER_KEY = COT.ORDER_KEY and OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY
                         join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY
                    ) ccx on ccx.si_key = si.si_key
                     join p_contract_lkp clkp on clkp.contract_key = ccx.contract_key
                     join p_contract_dim con on con.contract_key = clkp.contract_key
                     left join p_policy_ext_tbl pex ON (pex.policy_key = con.policy_key)

              where ccx.coverage_type_key = 2
                and con.retail_amt > 1
                --AND o.sales_source_cd NOT IN ('DEALER_SALES', 'OUTLET_SALES')
                and con.contract_status_key NOT IN (2, 3, 4, 5)
                AND exists (
                        select ccx3.si_key
                        from
                                (
                                    select distinct CD.CONTRACT_KEY,OIT.ORDER_KEY,COTX.SI_KEY AS si_key ,2 coverage_type_key,SALES_SOURCE_CD ,ot.PURCHASE_DT OT_Purchase_DT
                                    from BOSH.CONTRACT_DIM  CD
                                      JOIN BOSH.CONTRACT_COVERAGE_XREF  COTX on COTX.CONTRACT_KEY = CD.CONTRACT_KEY
                                      JOIN BOSH.CONTRACT_ORDER_TBL  COT on COT.CONTRACT_KEY = CD.CONTRACT_KEY
                                     JOIN BOSH.ORDER_ITEM_TBL OIT on OIT.ORDER_KEY = COT.ORDER_KEY and OIT.ORDER_LINE_KEY = COT.ORDER_LINE_KEY
                                      join bosh.ORDER_TBL ot on ot.ORDER_KEY = oit.ORDER_KEY

                                ) ccx3
                                join p_contract_lkp clkp3 on clkp3.contract_key = ccx3.contract_key
                                join p_contract_dim con3 on con3.contract_key = clkp3.contract_key
                                left join p_contract_status_dim cons3 on (cons3.contract_status_key = con3.contract_status_key)
                                join p_policy_ext_tbl pex3 ON (pex3.policy_key = con3.policy_key)
                        where
                              ccx3.coverage_type_key = 2
                        and ccx3.si_key  = ccx.si_key
                        and con3.contract_key <> con.contract_key
                        and
                            (con3.contract_start_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con3.contract_end_dt between con.contract_start_dt and con.contract_end_dt
                             or
                             con.contract_start_dt between con3.contract_start_dt and con3.contract_end_dt
                             or
                             con.contract_end_dt between con3.contract_start_dt and con3.contract_end_dt
                            )
                        and con3.retail_amt > 1
                        AND con3.contract_status_key NOT IN (2, 3, 4, 5)   --canceled/fulfilled/expired
                        and pex3.channels = pex.channels
                        and con3.contract_end_dt >= trunc(sysdate) - 30
                        and NOT  (ccx.SALES_SOURCE_CD = 'OUTLET_SALES'  and ccx3.SALES_SOURCE_CD = 'OUTLET_SALES')
                        and NOT  (ccx.OT_Purchase_DT < SYSDATE - 730  and ccx3.OT_Purchase_DT < SYSDATE - 730)
                       )
                AND SI.SI_KEY not in(3294443,3369966,3538649)----Excluding spceial cases
              group by si.si_key
             having count(distinct ccx.contract_key) >= 2
            );--3



   select *
        from (
                select * from (
                    select si.SI_KEY, si.PRODUCT_KEY, si.MODEL_NO, si.PURCHASE_DT_KEY, si.WARRANTY_EXPIRATION_DT, si.REGISTRATION_DT, si.LATEST_COVERAGE_EXP_DT, si.LATEST_COVERAGE_TYPE
                           ,oit.purchase_dt, oit.coverage_start_dt, oit.coverage_exp_dt
                           ,r.CONTRACT_START_DATE, r.CONTRACT_END_DATE, r.P2_CONTRACT_NO
                           ,row_number() over(partition by si.si_key order by oit.purchase_dt desc) as rno
                      from p_serialized_item_dim  si
                           join p_serialized_item_ext_dim six on six.si_key = si.si_key
                           JOIN p_order_item_tbl oit on oit.serialized_item_key = si.si_key
                           JOIN p_order_tbl o on (oit.order_key = o.order_key)
                           LEFT JOIN bosh.raw_contract_sales_tbl r on oit.order_key || '-' || oit.order_line_key = r.unique_identifier
                     where latest_coverage_type = 1
                --       and duplicate_ind = 'N'
                       and o.CREATED_TS <= SYSDATE - 10
                       and o.CREATED_TS >= TRUNC(SYSDATE) - 730
                       and si.si_key not in (
                              select  oit2.serialized_item_key
                                from   p_contract_dim con2
                                       JOIN p_contract_order_tbl cot2 on (cot2.contract_key = con2.contract_key)
                                       JOIN p_order_item_tbl  oit2 on (oit2.order_key = cot2.order_key and oit2.order_line_key = cot2.order_line_key)
                                WHERE  con2.contract_status_key IN (2, 3)   --canceled?
                              )
                )
                where rno = 1
            );

-- +-------+-----------+---------+---------------+--------------------------+-------------------+----------------------+--------------------+--------------------------+--------------------------+--------------------------+-------------------+-----------------+--------------+---+
-- |SI_KEY |PRODUCT_KEY|MODEL_NO |PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |REGISTRATION_DT    |LATEST_COVERAGE_EXP_DT|LATEST_COVERAGE_TYPE|PURCHASE_DT               |COVERAGE_START_DT         |COVERAGE_EXP_DT           |CONTRACT_START_DATE|CONTRACT_END_DATE|P2_CONTRACT_NO|RNO|
-- +-------+-----------+---------+---------------+--------------------------+-------------------+----------------------+--------------------+--------------------------+--------------------------+--------------------------+-------------------+-----------------+--------------+---+
-- |4308527|31280      |PODMCW31W|12175          |2025-05-02 00:00:00.000000|2025-04-01 20:48:11|2025-05-02            |1                   |2025-04-17 20:42:33.207000|2025-05-03 00:00:00.000000|2030-05-03 00:00:00.000000|05/02/2025         |05/02/2030       |BSH-457061-4  |1  |
-- +-------+-----------+---------+---------------+--------------------------+-------------------+----------------------+--------------------+--------------------------+--------------------------+--------------------------+-------------------+-----------------+--------------+---+