
select oect.*
 from bosh.order_extract_cancel_tbl oect join AUDIT_TBL att on att.AUDIT_KEY = oect.INSERT_AUDIT_KEY
 where att.CREATION_DT > date '2025-05-20'
  and P2CONTRACT_NUMBER in (
     select AGMT_NUMBER from assurant_cancel_detail act
     where 1=1
      and AGREEMENT_TYPE = 'Customer Cancellation'
      and INVOICE_MONTH >= 202504
    );

select * from RAW_CONTRACT_CANCELS_TBL
         where P2_CONTRACT_NO in ('BSH-420833-1','BSH-454041-1','BSH-454041-2')
         order by INSERT_AUDIT_KEY desc;