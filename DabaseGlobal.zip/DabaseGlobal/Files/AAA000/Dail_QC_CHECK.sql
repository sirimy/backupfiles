--There are 99 serials with orders but latest_coverage_type is 1
select CSD.NAME ,CSD.CONTRACT_STATUS_KEY, COUNT(distinct CD.CONTRACT_KEY )
      , COUNT(distinct SI_KEY ), COUNT(distinct COT.ORDER_KEY )
      ,COUNT(CCD.CONTRACT_KEY)
        from (
                select * from (
                    select  oit.ORDER_KEY,oit.ORDER_LINE_KEY,si.SI_KEY, si.PRODUCT_KEY, si.MODEL_NO, si.PURCHASE_DT_KEY, si.WARRANTY_EXPIRATION_DT, si.REGISTRATION_DT, si.LATEST_COVERAGE_EXP_DT, si.LATEST_COVERAGE_TYPE
                           ,oit.purchase_dt, oit.coverage_start_dt, oit.coverage_exp_dt
                           ,r.CONTRACT_START_DATE, r.CONTRACT_END_DATE, r.P2_CONTRACT_NO
                           ,row_number() over(partition by si.si_key order by oit.purchase_dt desc) as rno
                      from p_serialized_item_dim  si
                           join p_serialized_item_ext_dim six on six.si_key = si.si_key
                           JOIN p_order_item_tbl oit on oit.serialized_item_key = si.si_key
                           JOIN p_order_tbl o on (oit.order_key = o.order_key)
                           LEFT JOIN bosh.raw_contract_sales_tbl r on oit.order_key || '-' || oit.order_line_key = r.unique_identifier
                     where latest_coverage_type = 1
                --       and duplicate_ind = 'N'
                       and o.CREATED_TS <= SYSDATE - 10
                       and o.CREATED_TS >= TRUNC(SYSDATE) - 730
                       and si.si_key not in (
                              select  oit2.serialized_item_key
                                from   p_contract_dim con2
                                       JOIN p_contract_order_tbl cot2 on (cot2.contract_key = con2.contract_key)
                                       JOIN p_order_item_tbl  oit2 on (oit2.order_key = cot2.order_key and oit2.order_line_key = cot2.order_line_key)
                                WHERE  con2.contract_status_key IN (2, 3)   --canceled?
                              )
                     --and oit.ORDER_KEY in (449889,438363 ,439297 )
                )
                where rno = 1
            ) T2 LEFT Join BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = T2.ORDER_KEY AND COT.ORDER_LINE_KEY = T2.ORDER_LINE_KEY
                 LEFT JOIN BOSH.CONTRACT_DIM Cd on CD.CONTRACT_KEY = COT.CONTRACT_KEY
                 LEFT JOIN BOSH.CONTRACT_STATUS_DIM CSd on CSd.CONTRACT_STATUS_KEY= CD.CONTRACT_STATUS_KEY
                 LEFT Join BOSH.CONTRACT_CANCELLATION_DIM CCD on CCD.CONTRACT_KEY  =  COT.ORDER_KEY
GROUP BY CSD.NAME,CSD.CONTRACT_STATUS_KEY

;


select CSD.NAME ,CSD.CONTRACT_STATUS_KEY, ( CD.CONTRACT_KEY )
      , ( SI_KEY ), ( COT.ORDER_KEY )
      ,(CCD.CONTRACT_KEY)
        from (
                select * from (
                    select  oit.ORDER_KEY,oit.ORDER_LINE_KEY,si.SI_KEY, si.PRODUCT_KEY, si.MODEL_NO, si.PURCHASE_DT_KEY, si.WARRANTY_EXPIRATION_DT, si.REGISTRATION_DT, si.LATEST_COVERAGE_EXP_DT, si.LATEST_COVERAGE_TYPE
                           ,oit.purchase_dt, oit.coverage_start_dt, oit.coverage_exp_dt
                           ,r.CONTRACT_START_DATE, r.CONTRACT_END_DATE, r.P2_CONTRACT_NO
                           ,row_number() over(partition by si.si_key order by oit.purchase_dt desc) as rno
                      from p_serialized_item_dim  si
                           join p_serialized_item_ext_dim six on six.si_key = si.si_key
                           JOIN p_order_item_tbl oit on oit.serialized_item_key = si.si_key
                           JOIN p_order_tbl o on (oit.order_key = o.order_key)
                           LEFT JOIN bosh.raw_contract_sales_tbl r on oit.order_key || '-' || oit.order_line_key = r.unique_identifier
                     where latest_coverage_type = 1
                --       and duplicate_ind = 'N'
                       and o.CREATED_TS <= SYSDATE - 10
                       and o.CREATED_TS >= TRUNC(SYSDATE) - 730
                       and si.si_key not in (
                              select  oit2.serialized_item_key
                                from   p_contract_dim con2
                                       JOIN p_contract_order_tbl cot2 on (cot2.contract_key = con2.contract_key)
                                       JOIN p_order_item_tbl  oit2 on (oit2.order_key = cot2.order_key and oit2.order_line_key = cot2.order_line_key)
                                WHERE  con2.contract_status_key IN (2, 3)   --canceled?
                              )
                     --and oit.ORDER_KEY in (449889,438363 ,439297 )
                )
                where rno = 1
            ) T2 LEFT Join BOSH.CONTRACT_ORDER_TBL COT on COT.ORDER_KEY = T2.ORDER_KEY AND COT.ORDER_LINE_KEY = T2.ORDER_LINE_KEY
                 LEFT JOIN BOSH.CONTRACT_DIM Cd on CD.CONTRACT_KEY = COT.CONTRACT_KEY
                 LEFT JOIN BOSH.CONTRACT_STATUS_DIM CSd on CSd.CONTRACT_STATUS_KEY= CD.CONTRACT_STATUS_KEY
                 LEFT Join BOSH.CONTRACT_CANCELLATION_DIM CCD on CCD.CONTRACT_KEY  =  COT.ORDER_KEY
--GROUP BY CSD.NAME,CSD.CONTRACT_STATUS_KEY

;
-- +----+-------------------+------------+-------+---------+------------+
-- |NAME|CONTRACT_STATUS_KEY|CONTRACT_KEY|SI_KEY |ORDER_KEY|CONTRACT_KEY|
-- +----+-------------------+------------+-------+---------+------------+
-- |ACTV|1                  |211701      |4308527|457061   |NULL        |
-- +----+-------------------+------------+-------+---------+------------+
select SIL.SI_XID from BOSH.SERIALIZED_ITEM_LKP SIL where SI_KEY =4308527;
-- +------------------------------+
-- |SI_XID                        |
-- +------------------------------+
-- |PODMCW31W/xx-20230502-T7733768|
-- |208018419                     |
-- +------------------------------+
select * from BOSH.SERIALIZED_ITEM_LKP where SI_XID in(     select SIL.SI_XID from BOSH.SERIALIZED_ITEM_LKP SIL where SI_KEY =4308527)and SI_KEY <> 4308527;
-- +-------+------------------------------+----------------+--------------+
-- |SI_KEY |SI_XID                        |SOURCE_SYSTEM_CD|EXT_ID_TYPE_CD|
-- +-------+------------------------------+----------------+--------------+
-- |4308523|PODMCW31W/xx-20230502-T7733768|0               |2             |
-- +-------+------------------------------+----------------+--------------+
select SIL.SI_XID from BOSH.SERIALIZED_ITEM_LKP SIL where SI_KEY =4308523;
-- +------------------------------+
-- |SI_XID                        |
-- +------------------------------+
-- |PODMCW31W/xx-20230502-T7733768|
-- |208018385                     |
-- +------------------------------+
select * from BOSH.SERIALIZED_ITEM_DIM where SI_KEY in(4308527,4308523);
-- +-------+-----------+---------+---------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
-- |SI_KEY |PRODUCT_KEY|SERIAL_NO|MODEL_NO |PURCHASE_DT_KEY|WARRANTY_EXPIRATION_DT    |PURCHASE_AMT|CURRENCY_CD|LAST_UPDATED_LEADS_DT|REGISTRATION_DT    |QUALITY_SCORE|END_DT|DIM_STATUS_CD|LATEST_COVERAGE_EXP_DT|LATEST_COVERAGE_TYPE|INSERT_AUDIT_KEY|UPDATE_AUDIT_KEY|SYNC_AUDIT_KEY|
-- +-------+-----------+---------+---------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
-- |4308523|31280      |NULL     |PODMCW31W|12175          |2025-05-02 00:00:00.000000|NULL        |USD        |NULL                 |2025-04-01 20:37:38|0            |NULL  |A            |2030-05-02            |22                  |943919          |950739          |950739        |
-- |4308527|31280      |NULL     |PODMCW31W|12175          |2025-05-02 00:00:00.000000|NULL        |USD        |NULL                 |2025-04-01 20:48:11|0            |NULL  |A            |2025-05-02            |1                   |943919          |NULL            |943937        |
-- +-------+-----------+---------+---------+---------------+--------------------------+------------+-----------+---------------------+-------------------+-------------+------+-------------+----------------------+--------------------+----------------+----------------+--------------+
select * from BOSH.CONTRACT_ORDER_TBL COT where cot.CONTRACT_KEY = 211701;
select * from AUDIT_TBL where AUDIT_KEY in (950739,950578);
-- +--------------------------------------------------------+---------+--------------------------+--------------------------------------+--------------------------------------------+
-- |DESCRIPTIVE_TX                                          |AUDIT_KEY|CREATION_DT               |PROGRAM_NM                            |PROCESS_NM                                  |
-- +--------------------------------------------------------+---------+--------------------------+--------------------------------------+--------------------------------------------+
-- |Loading Contracts Data                                  |950578   |2025-04-19 11:40:04.000000|PKG_CONTRACT.s_001_load_contract_sales|NULL                                        |
-- |Updating LATEST_COVERAGE_TYPE and LATEST_COVERAGE_EXP_DT|950739   |2025-04-21 00:33:17.000000|PRC_MARK_DUPE_LEADS_SI_EXT            |BOSH-515, BOSH-514: Set latest_coverage_type|
-- +--------------------------------------------------------+---------+--------------------------+--------------------------------------+--------------------------------------------+